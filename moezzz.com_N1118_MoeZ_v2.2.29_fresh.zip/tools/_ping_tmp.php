<?php
define('MOE_ADMIN', true);
require dirname(__DIR__) . '/init.php';
require_once dirname(__DIR__) . '/includes/ai.php';
$c = moe_ai_cfg();
echo "base=" . $c['base'] . "\n";
echo "model=" . $c['model'] . "\n";
echo "key_len=" . strlen($c['key']) . " key_head=" . substr($c['key'], 0, 3) . "***\n";
echo "enabled=" . var_export((bool)$c['enabled'], true) . "\n";
$r = moe_ai_ping();
echo "--- ping result ---\n";
echo "ok=" . var_export($r['ok'], true) . " code={$r['code']} ms={$r['ms']}\n";
echo "err=" . $r['err'] . "\n";
echo "text=" . $r['text'] . "\n";
