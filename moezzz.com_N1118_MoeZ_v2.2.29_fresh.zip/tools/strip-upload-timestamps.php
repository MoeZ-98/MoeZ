<?php
/**
 * MoeZ · 存量附件「剥掉文件名时间串」工具
 * ------------------------------------------------------------
 * 新上传的文件已经不再带 YYYYMMDD_HHMMSS_8位随机_ 前缀（目录 uploads/{类型}/YYYYMM/
 * 本身就按月份归档）。本工具用来把历史附件也统一成「原文件名」或「数字名」。
 *
 * 用法（必须在服务器命令行执行，不能通过 Web 访问）：
 *   php tools/strip-upload-timestamps.php                 预览，不改动任何文件
 *   php tools/strip-upload-timestamps.php --apply        实际改名
 *
 * 重要前提：
 *  1. 执行 --apply 前请先完整备份 uploads/；
 *  2. 文章正文 / 封面里引用的是【旧文件名】，改名后旧链接会 404。
 *     本工具会在 content/archive/ 写出旧名→新名映射表和 Apache / Nginx 兼容规则，
 *     必须把规则应用到服务器（或批量替换数据库正文）后再上线；
 *  3. 本工具只改名、不删除任何文件、不连接数据库、不改动文章正文。
 *
 * 最低 PHP 版本：7.0
 */

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("Forbidden: 仅允许命令行运行\n");
}

$root    = dirname(__DIR__) . '/uploads';
$outDir  = dirname(__DIR__) . '/content/archive';
$apply   = in_array('--apply', $argv, true);
$map     = array();
$skipped = array();
$errors  = array();

if (!is_dir($root)) {
    exit("未找到 uploads/ 目录：{$root}\n");
}

/* 历史命名：20261109_180055_15228377.webp / 20261112_225507_1a8d51f1_原名.webp */
$prefixRe = '/^(\d{8})_(\d{6})_([0-9a-fA-F]{8})(?:_(.+))?\.([A-Za-z0-9]+)$/u';

/* 剥出来的原名段做一次保守净化；含控制字符 / 路径字符 / CP437 制图符时视为乱码，改用数字名 */
function strip_clean_stem($stem)
{
    $stem = (string)$stem;
    if ($stem === '') return '';
    if (function_exists('mb_check_encoding') && !mb_check_encoding($stem, 'UTF-8')) return '';
    if (preg_match('/[\x00-\x1F\x7F\\\\\/\:\*\?"<>\|]/u', $stem)) return '';
    if (preg_match('/[\x{2500}-\x{25FF}\x{0400}-\x{04FF}]/u', $stem)) return '';
    $stem = preg_replace('/\.{2,}/', '.', $stem);
    $stem = trim($stem, ' ._-');
    if (function_exists('mb_substr')) $stem = mb_substr($stem, 0, 60, 'UTF-8');
    return $stem;
}

$files = array();
try {
    $it = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)
    );
    foreach ($it as $f) {
        if ($f->isFile()) $files[] = $f->getPathname();
    }
} catch (Throwable $e) {
    exit("扫描 uploads/ 失败：" . $e->getMessage() . "\n");
}
sort($files);

/* 按目录收集，便于给「无原名的纯时间串文件」分配数字名，以及处理重名 */
$byDir = array();
foreach ($files as $path) {
    $dir  = dirname($path);
    $name = basename($path);
    if (!preg_match($prefixRe, $name, $m)) {
        $skipped[] = $path;
        continue;
    }
    $byDir[$dir][] = array('path' => $path, 'name' => $name, 'm' => $m);
}

foreach ($byDir as $dir => $items) {
    /* 已存在的目标名（含不打算改名的文件），避免覆盖 */
    $taken = array();
    foreach ((array)@scandir($dir) as $n) {
        if ($n !== '.' && $n !== '..') $taken[strtolower($n)] = true;
    }
    $num = 0;
    foreach ($items as $it) {
        $m    = $it['m'];
        $ext  = strtolower($m[5]);
        $stem = isset($m[4]) ? strip_clean_stem($m[4]) : '';

        if ($stem === '') {
            /* 纯时间串 / 乱码段：改用 000001.ext 这类数字名 */
            do {
                $num++;
                $new = str_pad((string)$num, 6, '0', STR_PAD_LEFT) . '.' . $ext;
            } while (isset($taken[strtolower($new)]) && $num < 99999);
        } else {
            $new  = $stem . '.' . $ext;
            $base = $stem;
            $i    = 1;
            while (isset($taken[strtolower($new)]) && $i < 9999) {
                $i++;
                $new = $base . '_' . $i . '.' . $ext;
            }
        }
        $taken[strtolower($new)] = true;
        $rel = 'uploads/' . str_replace('\\', '/', ltrim(substr($it['path'], strlen($root) + 1), '/'));
        $newRel = dirname($rel) . '/' . $new;
        $map[] = array('old' => $rel, 'new' => $newRel, 'changed' => $rel !== $newRel);
    }
}

/* 输出预览 / 改名结果 */
echo ($apply ? "【执行改名】\n" : "【预览模式，未改动任何文件；加 --apply 才实际改名】\n");
echo "扫描文件 " . count($files) . " 个，需要改名 " . count($map) . " 个，已符合规范 " . count($skipped) . " 个\n\n";
foreach ($map as $row) {
    echo "  " . basename($row['old']) . "  ->  " . basename($row['new']) . "\n";
}

/* 生成兼容规则：旧 URL 永久重定向到新文件名 */
$apache = array("# 由 tools/strip-upload-timestamps.php 生成；放入站点根 .htaccess 的 RewriteEngine On 之后");
$nginx  = array("# 由 tools/strip-upload-timestamps.php 生成；放入 server {} 内");
foreach ($map as $row) {
    if (!$row['changed']) continue;
    $oldUri = '/' . $row['old'];
    $newUri = '/' . $row['new'];
    $apache[] = 'RewriteRule ^' . preg_quote(ltrim($oldUri, '/'), '#') . '$ ' . $newUri . ' [R=301,L]';
    $nginx[]  = 'rewrite ^' . preg_quote($oldUri, '#') . '$ ' . $newUri . ' permanent;';
}

if (!is_dir($outDir)) @mkdir($outDir, 0755, true);
if (is_dir($outDir)) {
    @file_put_contents($outDir . '/upload-rename-map.json',
        json_encode($map, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
    @file_put_contents($outDir . '/upload-rewrite.conf',
        implode("\n", $apache) . "\n\n" . implode("\n", $nginx) . "\n");
    echo "\n映射表：content/archive/upload-rename-map.json\n";
    echo "兼容规则：content/archive/upload-rewrite.conf\n";
}

if (!$apply) {
    echo "\n请先把上面的旧名→新名规则和数据库正文处理好，再执行 --apply。\n";
    exit(0);
}

/* 实际改名 */
$done = 0;
foreach ($map as $row) {
    if (!$row['changed']) continue;
    $old = dirname(__DIR__) . '/' . $row['old'];
    $new = dirname(__DIR__) . '/' . $row['new'];
    if (!is_file($old)) { $errors[] = $row['old'] . '：源文件不存在'; continue; }
    if (is_file($new))  { $errors[] = $row['old'] . '：目标已存在，已跳过'; continue; }
    if (@rename($old, $new)) $done++;
    else $errors[] = $row['old'] . '：改名失败（检查目录权限）';
}
echo "\n已改名 {$done} 个文件";
if ($errors) {
    echo "，失败/跳过 " . count($errors) . " 个：\n  " . implode("\n  ", $errors);
}
echo "\n";
echo "别忘了应用 content/archive/upload-rewrite.conf 里的兼容规则，否则旧文章图片会 404。\n";
