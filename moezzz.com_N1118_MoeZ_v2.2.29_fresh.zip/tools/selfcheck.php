<?php
/**
 * MoeZ · 版娘自检程序  v2.1.24
 * ---------------------------------------------------------------
 * 零数据库依赖：只读主题文件做静态断言，浏览器端做运行时诊断。
 *
 * 用法：
 *   php selfcheck.php --cli        命令行文本报告（退出码 0=全通过 / 1=有失败）
 *   /selfcheck.php                 浏览器诊断台（含四音色试听、面板尺寸实测）
 *
 * 检查范围：语音播放链路、病娇音色、聊天窗尺寸、资源版本、文件完整性。
 * 页面不输出任何密钥、账号或绝对路径；诊断完成后可自行删除本文件。
 */

define('SC_VER', '2.1.24');
define('SC_ROOT', dirname(__DIR__)); // 2.2.13 迁入 tools/，探测对象仍是站点根

/* ------------------------------------------------------------------ */
/* 工具                                                                */
/* ------------------------------------------------------------------ */
function sc_read($rel)
{
    $p = SC_ROOT . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
    if (!is_file($p)) return null;
    $s = @file_get_contents($p);
    return $s === false ? null : $s;
}
function sc_has($hay, $needle)
{
    return $hay !== null && $needle !== '' && strpos($hay, $needle) !== false;
}
function sc_ver($src, $name)
{
    if ($src === null) return '';
    if (preg_match('/define\(\s*[\'"]' . preg_quote($name, '/') . '[\'"]\s*,\s*[\'"](\d+(?:\.\d+)+)[\'"]\s*\)/', $src, $m)) return $m[1];
    return '';
}
function sc_vcmp($a, $b)
{
    return $a !== '' && version_compare($a, $b, '>=');
}
/** 从 CSS 里抓某个选择器块的声明 */
function sc_css_block($css, $selector_re)
{
    if ($css === null) return '';
    if (preg_match('/' . $selector_re . '\s*\{([^}]*)\}/s', $css, $m)) return $m[1];
    return '';
}
/** 抓 min(Npx, ...) 里的 N */
function sc_px($decl, $prop)
{
    if (preg_match('/' . $prop . '\s*:\s*(?:min\()?\s*(\d+)px/i', $decl, $m)) return (int)$m[1];
    return 0;
}

$checks = array();
function sc_add($group, $name, $ok, $detail, $failLevel = 'fail')
{
    global $checks;
    $checks[] = array(
        'group'  => $group,
        'name'   => $name,
        'status' => $ok ? 'pass' : $failLevel,
        'detail' => $detail,
    );
}

/* ------------------------------------------------------------------ */
/* 读取被检文件                                                        */
/* ------------------------------------------------------------------ */
$T = 'templates/fomalhaut/';
$lib    = sc_read($T . '_lib.php');
$info   = sc_read($T . 'info.php');
$footer = sc_read($T . 'footer.php');
$header = sc_read($T . 'header.php');
$js     = sc_read($T . 'assets/app.js');
$css    = sc_read($T . 'assets/style.css');
$init   = sc_read('init.php');
$idx    = sc_read('index.php');

$jsOk  = $js !== null && $js !== '';
$cssOk = $css !== null && $css !== '';

/* ------------------------------------------------------------------ */
/* A. 版本与资源缓存                                                    */
/* ------------------------------------------------------------------ */
$foVer = sc_ver($lib, 'FO_ASSET_VER');
$moeVer = sc_ver($init, 'MOE_VERSION');
sc_add('版本与缓存', '主题资源版本号 FO_ASSET_VER', sc_vcmp($foVer, SC_VER),
    $foVer === '' ? '未读到 FO_ASSET_VER' : '当前 ' . $foVer . '，需 ≥ ' . SC_VER . '（决定 app.js / style.css 是否刷新浏览器缓存）');
sc_add('版本与缓存', '程序版本号 MOE_VERSION', sc_vcmp($moeVer, SC_VER),
    $moeVer === '' ? '未读到 MOE_VERSION' : '当前 ' . $moeVer . '，需 ≥ ' . SC_VER);
sc_add('版本与缓存', '样式/脚本带版本参数', sc_has($header, 'assets/style.css') && sc_has($header, 'assets/app.js') && sc_has($header, '?v='),
    'header.php 需同时引用 style.css / app.js 且带 ?v= 参数');
sc_add('版本与缓存', '核心文件未被截断', $init !== null && strlen($init) > 2000 && sc_has($idx, "case 'companion'"),
    'init.php 长度 ' . ($init === null ? 0 : strlen($init)) . ' 字节；index.php companion 路由存在：' . (sc_has($idx, "case 'companion'") ? '是' : '否'));

/* ------------------------------------------------------------------ */
/* B. 语音播放链路（无声根因）                                          */
/* ------------------------------------------------------------------ */
sc_add('语音链路', '用户手势解锁', $jsOk && (sc_has($js, 'unlockVoice') || sc_has($js, 'gestureUnlock')),
    '浏览器自动播放策略会静默拦截首次 speechSynthesis.speak()；需在首次 pointerdown / keydown 预热引擎');
sc_add('语音链路', '逐段串行朗读队列', $jsOk && (sc_has($js, 'speakNext') || sc_has($js, 'queueNext')),
    '一次性 forEach 把 N 段 utterance 塞进队列会被 Chrome 吞句；应改为 onend 驱动下一段');
sc_add('语音链路', '队列装配在停止之后', $jsOk && (bool)preg_match('/stopSpeak\(\);[^\n]*\n\s*voiceQueue\s*=\s*parts\.map/s', $js),
    'stopSpeak() 会清空 voiceQueue；若先装队列再停，队列被清空会导致永远不发声（2.1.24 浏览器实测抓到的回归）');
sc_add('语音链路', 'Chrome 长句保活', $jsOk && (sc_has($js, 'keepAlive') || sc_has($js, 'scKeepAlive')),
    'Chrome 约 15 秒会截断朗读，需定时 pause/resume 保活');
sc_add('语音链路', 'resume 唤醒暂停队列', $jsOk && sc_has($js, 'synth.resume()'),
    'speak 前需 synth.resume()，否则被挂起的队列永远不出声');
sc_add('语音链路', '静默失败可见', $jsOk && (sc_has($js, 'voiceBlocked') || sc_has($js, 'scVoiceBlocked')),
    'onstart 超时未触发时要给出「点一下页面再试」的提示，而不是无声无息');
sc_add('语音链路', '拦截错误显式识别', $jsOk && sc_has($js, "'not-allowed'"),
    'Chrome 无手势朗读会抛 onerror(not-allowed) 且不触发 onstart；必须把它识别为拦截并弹提示，不能静默跳过下一段');
sc_add('语音链路', '取消竞态保护', $jsOk && (sc_has($js, 'speakToken') || sc_has($js, 'voiceToken')),
    'cancel() 后旧队列的 onend 会复活；需要 token 作废并留足重启间隔');
sc_add('语音链路', '语音列表异步就绪', $jsOk && sc_has($js, 'voiceschanged'),
    'getVoices() 首次常返回空，必须监听 voiceschanged 后才能选到中文女声');
sc_add('语音链路', '中文女声优先级', $jsOk && sc_has($js, 'V_RANK') && sc_has($js, '晓晓'),
    'V_RANK 需含 晓晓 / 晓伊 / 瑶瑶 等中文女声，避免选中英文音色读中文');
sc_add('语音链路', '朗读文本清洗与分句', $jsOk && sc_has($js, 'cleanText') && sc_has($js, 'splitText'),
    '去掉链接/emoji 并按句切分，长句才不会被吞');
sc_add('语音链路', '页面卸载停止朗读', $jsOk && sc_has($js, 'pagehide'),
    '避免切走页面后还在后台念');
sc_add('语音链路', '后台开关透传', sc_has($footer, 'data-voice=') && sc_has($footer, 'data-voice-auto=') && sc_has($footer, 'data-voice-style='),
    'footer.php 需输出 data-voice / -auto / -style / -rate / -pitch 供前端读取');
sc_add('语音链路', '小喇叭与重听按钮', sc_has($footer, 'fo-cp-voice') && $jsOk && sc_has($js, 'fo-cp-say'),
    '聊天头部的总开关 + 每条回复旁的重听按钮');

/* ------------------------------------------------------------------ */
/* C. 病娇音色                                                          */
/* ------------------------------------------------------------------ */
sc_add('病娇音色', '后台音色选项含病娇', sc_has($info, "'yandere'"),
    'info.php 的 voice_style.options 需提供 yandere 选项');
sc_add('病娇音色', '输出白名单含病娇', sc_has($footer, "'yandere'") || sc_has($footer, '"yandere"'),
    'footer.php 的 voice_style 白名单需放行 yandere，否则会被重置回 gentle');
sc_add('病娇音色', '前端音色预设含病娇', $jsOk && sc_has($js, 'yandere:') ,
    'V_STYLE 需含 yandere 的 rate / pitch 预设');
sc_add('病娇音色', '病娇台词润色', $jsOk && (sc_has($js, 'yanderize') || sc_has($js, 'scYanderize')),
    '病娇不只是变调：需在句尾加语气词并把情绪写成起伏曲线');
sc_add('病娇音色', '病娇情绪曲线', $jsOk && (sc_has($js, 'emotionCurve') || sc_has($js, 'yandereCurve')),
    '逐段交替 rate/pitch，尾段放慢压低，制造忽快忽慢的语感');
sc_add('病娇音色', '病娇视觉态', $cssOk && sc_has($css, '.is-yandere'),
    '聊天窗 / 立绘 / 气泡在病娇模式下需有独立配色');
sc_add('病娇音色', '前台音色切换按钮', sc_has($footer, 'fo-cp-style') && $jsOk && sc_has($js, 'fo-cp-style'),
    '访客可在聊天窗直接切换音色（存 localStorage），无需进后台');
sc_add('病娇音色', '切换状态持久化', $jsOk && sc_has($js, 'moe_cp_vstyle'),
    '音色选择需写入 localStorage，刷新后保持');

/* ------------------------------------------------------------------ */
/* D. 聊天窗尺寸                                                        */
/* ------------------------------------------------------------------ */
$panelDecl = sc_css_block($css, '\.fo-cp-panel');
$pw = sc_px($panelDecl, 'width');
$ph = sc_px($panelDecl, 'height');
sc_add('聊天窗尺寸', '桌面宽度 ≤ 330px', $pw > 0 && $pw <= 330,
    '当前 .fo-cp-panel width = ' . ($pw ?: '未解析') . 'px（目标 ≤ 330px，原 350px 偏大）');
sc_add('聊天窗尺寸', '桌面高度 ≤ 400px', $ph > 0 && $ph <= 400,
    '当前 .fo-cp-panel height = ' . ($ph ?: '未解析') . 'px（目标 ≤ 400px，原 470px 偏大）');
/* 移动端面板：以「--fo-cp-h: 150px」为锚点向后取紧邻的 .fo-cp-panel 块，
   避免跨过中间若干 @media 误抓到桌面规则 */
$mobDecl = '';
$mobAnchor = $css === null ? false : strpos($css, '--fo-cp-h: 150px');
if ($mobAnchor !== false) {
    $tail = substr($css, $mobAnchor, 700);
    if (preg_match('/\.fo-cp-panel\s*\{([^}]*)\}/s', $tail, $mm)) $mobDecl = $mm[1];
}
$mw = sc_px($mobDecl, 'width');
$mh = sc_px($mobDecl, 'height');
$mobFull = sc_has($mobDecl, 'calc(100vw - 16px)');
sc_add('聊天窗尺寸', '移动端不再整屏宽', $mw > 0 && $mw <= 340 && !$mobFull,
    '当前移动端 width = ' . ($mw ?: '未解析') . 'px；整屏宽 calc(100vw - 16px) = ' . ($mobFull ? '是（需改）' : '否'));
sc_add('聊天窗尺寸', '移动端高度 ≤ 380px', $mh > 0 && $mh <= 380,
    '当前移动端 height = ' . ($mh ?: '未解析') . 'px（原 430px / 66vh 偏高）');
sc_add('聊天窗尺寸', '标准尺寸回退开关', $cssOk && sc_has($css, 'data-panel-size="standard"') && sc_has($info, 'cp_panel_size') && sc_has($footer, 'data-panel-size'),
    '嫌紧凑太小可在模板设置切回「标准」：CSS 规则 + info.php 设置项 + footer 属性三处齐全');

/* ------------------------------------------------------------------ */
/* E. 文件完整性                                                        */
/* ------------------------------------------------------------------ */
$must = array(
    $T . '_lib.php' => $lib, $T . 'info.php' => $info, $T . 'footer.php' => $footer,
    $T . 'header.php' => $header, $T . 'assets/app.js' => $js,
    $T . 'assets/style.css' => $css, 'init.php' => $init, 'index.php' => $idx,
);
$missing = array();
foreach ($must as $rel => $s) if ($s === null || $s === '') $missing[] = $rel;
sc_add('完整性', '关键文件齐全且非空', !$missing,
    $missing ? '缺失/为空：' . implode('、', $missing) : '9 个关键文件均存在且非空');
$utf8Ok = true;
foreach ($must as $s) if ($s !== null && !preg_match('//u', $s)) { $utf8Ok = false; break; }
sc_add('完整性', 'UTF-8 编码有效', $utf8Ok,
    $utf8Ok ? '所有文件通过 UTF-8 校验（中文不会乱码）' : '存在非法 UTF-8 字节，检查是否有 GBK 混入');
$braceOk = $cssOk && (substr_count($css, '{') === substr_count($css, '}'));
sc_add('完整性', 'CSS 花括号配对', $braceOk,
    '{ = ' . substr_count((string)$css, '{') . '，} = ' . substr_count((string)$css, '}'));
$jsSize = $js === null ? 0 : strlen($js);
sc_add('完整性', 'app.js 体积合理', $jsSize > 20000,
    '当前 ' . $jsSize . ' 字节（过低说明脚本被截断）');
sc_add('完整性', '无前端硬编码密钥', $jsOk && !preg_match('/(sk-[A-Za-z0-9]{16,}|api[_-]?key\s*[:=]\s*["\'][A-Za-z0-9]{16,})/i', $js),
    '脚本中不应出现任何 API Key / Token');

/* ------------------------------------------------------------------ */
/* 汇总                                                                */
/* ------------------------------------------------------------------ */
$pass = $warn = $fail = 0;
foreach ($checks as $c) {
    if ($c['status'] === 'pass') $pass++;
    elseif ($c['status'] === 'warn') $warn++;
    else $fail++;
}
$total = count($checks);
$allOk = ($fail === 0);
$verdict = $allOk ? ($warn ? '通过（有提示项）' : '全部通过') : '未通过';

/* ------------------------------------------------------------------ */
/* CLI 模式                                                             */
/* ------------------------------------------------------------------ */
$isCli = (PHP_SAPI === 'cli') || isset($_GET['cli']);
if ($isCli) {
    if (PHP_SAPI !== 'cli') header('Content-Type: text/plain; charset=utf-8');
    echo "MoeZ · 版娘自检程序 v" . SC_VER . "  " . date('Y-m-d H:i:s') . "\n";
    echo str_repeat('=', 66) . "\n";
    $lastGroup = '';
    foreach ($checks as $c) {
        if ($c['group'] !== $lastGroup) { echo "\n[" . $c['group'] . "]\n"; $lastGroup = $c['group']; }
        $tag = $c['status'] === 'pass' ? 'PASS' : ($c['status'] === 'warn' ? 'WARN' : 'FAIL');
        echo sprintf("  %-4s %-24s %s\n", $tag, $c['name'], $c['detail']);
    }
    echo "\n" . str_repeat('-', 66) . "\n";
    echo "合计 {$total} 项：通过 {$pass} / 警告 {$warn} / 失败 {$fail}  →  {$verdict}\n";
    if (!$allOk) echo "提示：以上 FAIL 即修复前基线，改完代码后重跑本脚本应全部 PASS。\n";
    exit($allOk ? 0 : 1);
}

/* ------------------------------------------------------------------ */
/* 浏览器诊断台                                                         */
/* ------------------------------------------------------------------ */
$json = json_encode($checks, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
if ($json === false) $json = '[]';
$e = function ($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); };
?><!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title>版娘自检台 · MoeZ v<?php echo $e(SC_VER); ?></title>
<style>
  :root{
    --paper:#f7f5f0; --card:#fffdfa; --ink:#24313a; --muted:#7d8b93;
    --line:#e2ded5; --mint:#2f8f83; --rose:#c85f78; --amber:#b8842f;
    --ok:#2f8f83; --bad:#c24848; --warn:#b8842f;
    --mono:"SFMono-Regular",Consolas,"Liberation Mono",Menlo,monospace;
    --serif:"Songti SC","Noto Serif CJK SC","Source Han Serif SC",STSong,Georgia,serif;
    --sans:"PingFang SC","Microsoft YaHei","Hiragino Sans GB",system-ui,sans-serif;
  }
  *{ box-sizing:border-box; }
  body{ margin:0; background:var(--paper); color:var(--ink); font-family:var(--sans);
    background-image:radial-gradient(rgba(36,49,58,.045) 1px,transparent 1px);
    background-size:22px 22px; line-height:1.7; }
  .wrap{ max-width:1080px; margin:0 auto; padding:40px 22px 80px; }
  .topbar{ height:3px; background:linear-gradient(90deg,var(--mint),#9fd3ca 42%,var(--rose)); border-radius:3px; }
  header.hd{ display:flex; align-items:flex-end; justify-content:space-between; gap:24px;
    margin:26px 0 30px; padding-bottom:22px; border-bottom:1px solid var(--line); flex-wrap:wrap; }
  .eyebrow{ font:600 11px/1.4 var(--mono); letter-spacing:.22em; text-transform:uppercase; color:var(--mint); }
  h1{ font:700 clamp(30px,5vw,46px)/1.18 var(--serif); letter-spacing:.04em; margin:10px 0 8px; }
  .sub{ color:var(--muted); font-size:13.5px; max-width:620px; }
  .verdict{ text-align:right; min-width:190px; }
  .verdict b{ display:block; font:700 30px/1.2 var(--serif); color:var(--bad); }
  .verdict.is-ok b{ color:var(--ok); }
  .verdict span{ font:12px var(--mono); color:var(--muted); }
  .tally{ display:flex; gap:10px; margin-top:8px; justify-content:flex-end; }
  .tally i{ font:600 11px var(--mono); font-style:normal; padding:2px 8px; border:1px solid var(--line);
    border-radius:99px; background:var(--card); }
  .grid{ display:grid; grid-template-columns:minmax(0,1.32fr) minmax(0,1fr); gap:22px; align-items:start; }
  @media(max-width:860px){ .grid{ grid-template-columns:1fr; } .verdict{ text-align:left; } .tally{ justify-content:flex-start; } }
  .card{ background:var(--card); border:1px solid var(--line); border-radius:4px;
    box-shadow:0 2px 0 rgba(36,49,58,.03),0 14px 34px rgba(36,49,58,.045); }
  .card > h2{ font:700 15px/1.4 var(--serif); letter-spacing:.08em; margin:0; padding:16px 20px;
    border-bottom:1px solid var(--line); display:flex; align-items:center; gap:10px; }
  .card > h2 em{ font:600 10px var(--mono); font-style:normal; color:var(--muted); letter-spacing:.14em; margin-left:auto; }
  .grp{ padding:6px 20px 14px; }
  .grp + .grp{ border-top:1px dashed var(--line); }
  .grp h3{ font:600 10.5px var(--mono); letter-spacing:.18em; color:var(--mint);
    text-transform:uppercase; margin:16px 0 6px; }
  .row{ display:grid; grid-template-columns:20px minmax(0,1fr) auto; gap:10px; align-items:start;
    padding:9px 0; border-bottom:1px solid #f0ede6; }
  .row:last-child{ border-bottom:0; }
  .row .n{ font:11px/1.8 var(--mono); color:#b3b0a8; }
  .row .t{ display:block; font-size:13.5px; font-weight:600; }
  .row .d{ display:block; font-size:11.5px; color:var(--muted); margin-top:2px; word-break:break-word; }
  .badge{ font:700 10px var(--mono); letter-spacing:.06em; padding:3px 9px; border-radius:2px; white-space:nowrap; }
  .badge.pass{ color:var(--ok); background:rgba(47,143,131,.1); border:1px solid rgba(47,143,131,.25); }
  .badge.fail{ color:var(--bad); background:rgba(194,72,72,.09); border:1px solid rgba(194,72,72,.24); }
  .badge.warn{ color:var(--warn); background:rgba(184,132,47,.1); border:1px solid rgba(184,132,47,.26); }
  .badge.wait{ color:var(--muted); background:#f2f0eb; border:1px solid var(--line); }
  .live{ padding:16px 20px 20px; }
  .live p.hint{ font-size:12px; color:var(--muted); margin:0 0 14px; line-height:1.8; }
  .voice-grid{ display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:8px; margin-bottom:16px; }
  .try{ font:600 12.5px var(--sans); padding:10px 8px; border:1px solid var(--line); border-radius:3px;
    background:#fff; color:var(--ink); cursor:pointer; transition:.18s; text-align:left; }
  .try small{ display:block; font:10px var(--mono); color:var(--muted); margin-top:2px; }
  .try:hover{ border-color:var(--mint); background:#f4faf8; transform:translateY(-1px); }
  .try.is-y{ border-color:#d79aae; background:#fff5f8; color:#8c3d55; }
  .try.is-y:hover{ background:#ffeaf1; border-color:var(--rose); }
  .try:disabled{ opacity:.55; cursor:wait; transform:none; }
  #scConsole{ font:11.5px/1.75 var(--mono); background:#222b31; color:#cfe3de; border-radius:3px;
    padding:12px 14px; min-height:96px; max-height:220px; overflow:auto; white-space:pre-wrap; }
  #scConsole .e{ color:#f0a3b2; } #scConsole .ok{ color:#8fe0c4; } #scConsole .w{ color:#e8c987; }
  .kv{ display:grid; grid-template-columns:auto 1fr; gap:6px 14px; font-size:12.5px; margin:0 0 16px; }
  .kv dt{ color:var(--muted); } .kv dd{ margin:0; font-family:var(--mono); font-size:12px; word-break:break-all; }
  .probe{ border:1px dashed #cfc9bd; border-radius:3px; padding:12px; margin:0 0 16px; background:#fdfbf6; }
  .probe .fo-cp-panel{ position:static; width:min(318px,calc(100vw - 28px)); height:min(388px,calc(100vh - 80px));
    min-height:180px; display:flex; flex-direction:column; background:#fff; border:1px solid #e3edf3;
    border-radius:14px; overflow:hidden; opacity:1; visibility:visible; transform:none; }
  .probe .ph{ padding:8px 12px; font-size:11.5px; color:#7b8d9c; border-bottom:1px solid #edf3f7; }
  .probe .pb{ flex:1; padding:10px; font-size:11px; color:#9aabb7; }
  footer.ft{ margin-top:30px; padding-top:16px; border-top:1px solid var(--line);
    font:11px/1.9 var(--mono); color:var(--muted); display:flex; justify-content:space-between; gap:16px; flex-wrap:wrap; }
  footer.ft a{ color:var(--mint); text-decoration:none; }
  .btn{ font:600 12px var(--sans); padding:8px 14px; border:1px solid var(--ink); background:var(--ink);
    color:#fff; border-radius:2px; cursor:pointer; }
  .btn.ghost{ background:transparent; color:var(--ink); }
  .btn:hover{ opacity:.85; }
  .actions{ display:flex; gap:8px; margin-top:12px; flex-wrap:wrap; }
</style>
</head>
<body>
<div class="wrap">
  <div class="topbar"></div>
  <header class="hd">
    <div>
      <div class="eyebrow">MoeZ / Companion Diagnostics</div>
      <h1>版娘自检台</h1>
      <div class="sub">静态核查语音链路、病娇音色与聊天窗尺寸；右侧可真实试听四种音色，并检测浏览器是否拦截了自动朗读。检查不联网、不写数据库、不读取任何密钥。</div>
    </div>
    <div class="verdict<?php echo $allOk ? ' is-ok' : ''; ?>" id="scVerdict">
      <b><?php echo $e($verdict); ?></b>
      <span>v<?php echo $e(SC_VER); ?> · <?php echo $e(date('Y-m-d H:i')); ?></span>
      <div class="tally"><i>PASS <?php echo $pass; ?></i><i>WARN <?php echo $warn; ?></i><i>FAIL <?php echo $fail; ?></i></div>
    </div>
  </header>

  <div class="grid">
    <section class="card">
      <h2>静态核查 <em>STATIC / <?php echo $total; ?> ITEMS</em></h2>
      <div id="scStatic"></div>
    </section>

    <div>
      <section class="card" style="margin-bottom:22px">
        <h2>运行时环境 <em>RUNTIME</em></h2>
        <div class="live">
          <dl class="kv" id="scEnv">
            <dt>浏览器</dt><dd id="scUA">检测中…</dd>
            <dt>语音合成</dt><dd id="scSupport">检测中…</dd>
            <dt>可用语音</dt><dd id="scVoices">检测中…</dd>
            <dt>中文女声</dt><dd id="scZh">检测中…</dd>
            <dt>本地存储</dt><dd id="scLS">检测中…</dd>
          </dl>
          <div id="scLiveRows"></div>
          <div class="actions">
            <button class="btn ghost" type="button" id="scAuto">检测自动播放拦截</button>
            <button class="btn ghost" type="button" id="scSize">实测聊天窗尺寸</button>
          </div>
        </div>
      </section>

      <section class="card" style="margin-bottom:22px">
        <h2>音色试听台 <em>VOICE TEST</em></h2>
        <div class="live">
          <p class="hint">点击即产生用户手势，可绕开浏览器自动播放拦截。每格会回报 <code>onstart / onend / onerror</code>；若一直停在「已提交但没出声」，说明系统缺少中文语音包或输出设备被静音。</p>
          <div class="voice-grid" id="scVoiceGrid"></div>
          <div id="scConsole">等待试听…</div>
        </div>
      </section>

      <section class="card">
        <h2>尺寸探针 <em>GEOMETRY</em></h2>
        <div class="live">
          <p class="hint">按修复后主题规则渲染一个真实面板，用 <code>getBoundingClientRect()</code> 实测宽高，断言不超出 330 × 400。</p>
          <div class="probe"><div class="fo-cp-panel" id="scProbe">
            <div class="ph">小星 · 在线</div><div class="pb">聊天窗尺寸探针<br>（此处只测量，不发送消息）
              <div style="margin-top:12px;padding:8px 10px;background:#f3fbfa;border-radius:10px;color:#3f5464">你好呀，今天想聊点什么？</div>
              <div style="margin-top:8px;padding:8px 10px;background:#fdf3f7;border-radius:10px;color:#3f5464">我一直都在这里陪着你 ✦</div>
            </div>
          </div></div>
          <div id="scSizeOut" class="kv"><dt>实测</dt><dd>点击上方「实测聊天窗尺寸」</dd></div>
        </div>
      </section>
    </div>
  </div>

  <footer class="ft">
    <span>CLI 复检：<code>php selfcheck.php --cli</code>　·　退出码 0 = 全通过</span>
    <span><a href="?cli=1">纯文本报告</a>　·　诊断完成后可删除本文件</span>
  </footer>
</div>

<script>window.SC_STATIC = <?php echo $json; ?>;</script>
<script>
(function () {
  var $ = function (s) { return document.querySelector(s); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };

  /* ---------- 静态核查渲染 ---------- */
  var box = $('#scStatic'), last = '', html = '', i = 0;
  window.SC_STATIC.forEach(function (c) {
    if (c.group !== last) {
      if (last) html += '</div>';
      html += '<div class="grp"><h3>' + esc(c.group) + '</h3>';
      last = c.group;
    }
    i++;
    html += '<div class="row"><span class="n">' + (i < 10 ? '0' : '') + i + '</span>' +
      '<span><span class="t">' + esc(c.name) + '</span><span class="d">' + esc(c.detail) + '</span></span>' +
      '<span class="badge ' + c.status + '">' + c.status.toUpperCase() + '</span></div>';
  });
  if (last) html += '</div>';
  box.innerHTML = html;

  /* ---------- 控制台 ---------- */
  var con = $('#scConsole');
  function log(t, cls) {
    var d = new Date();
    var ts = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2) + ':' + ('0' + d.getSeconds()).slice(-2);
    con.innerHTML += '<span class="' + (cls || '') + '">[' + ts + '] ' + esc(t) + '</span>\n';
    con.scrollTop = con.scrollHeight;
  }
  function live(name, ok, detail) {
    var row = document.createElement('div');
    row.className = 'row';
    row.innerHTML = '<span class="n">·</span><span><span class="t">' + esc(name) + '</span>' +
      '<span class="d">' + esc(detail) + '</span></span><span class="badge ' +
      (ok === true ? 'pass' : (ok === false ? 'fail' : 'warn')) + '">' +
      (ok === true ? 'PASS' : (ok === false ? 'FAIL' : 'WARN')) + '</span>';
    $('#scLiveRows').appendChild(row);
  }

  /* ---------- 环境 ---------- */
  $('#scUA').textContent = navigator.userAgent.replace(/\s*\([^)]*\)/g, '').slice(0, 68) || navigator.userAgent.slice(0, 68);
  var synth = window.speechSynthesis || null;
  var Utter = window.SpeechSynthesisUtterance || null;
  var supported = !!synth && typeof Utter === 'function';
  $('#scSupport').textContent = supported ? ('支持 · SpeechSynthesisUtterance 可用') : '不支持（浏览器缺少语音合成能力）';
  try { localStorage.setItem('sc_probe', '1'); localStorage.removeItem('sc_probe'); $('#scLS').textContent = '可用'; }
  catch (e) { $('#scLS').textContent = '被禁用（音色选择无法记住）'; }

  var voices = [];
  function readVoices() {
    if (!synth) return;
    try { voices = synth.getVoices() || []; } catch (e) { voices = []; }
    var zh = voices.filter(function (v) { return /^(zh|cmn|yue)/i.test(v.lang || ''); });
    var female = zh.filter(function (v) { return /晓晓|晓伊|瑶瑶|慧慧|婷婷|美佳|xiaoxiao|xiaoyi|yaoyao|huihui|tingting|meijia|female|女/i.test(v.name || ''); });
    $('#scVoices').textContent = voices.length ? (voices.length + ' 个语音（中文 ' + zh.length + ' 个）') : '0 个（可能仍在异步加载，或系统未装语音包）';
    $('#scZh').textContent = female.length ? female.slice(0, 3).map(function (v) { return v.name; }).join(' / ') : (zh.length ? zh.slice(0, 2).map(function (v) { return v.name; }).join(' / ') + '（未识别到女声）' : '无 —— 中文很可能念不出来');
    if (!voices.length) live('语音列表就绪', null, 'getVoices() 返回空；已挂 voiceschanged，若一直为空说明系统无语音包');
    else live('语音列表就绪', zh.length > 0, '共 ' + voices.length + ' 个，中文 ' + zh.length + ' 个');
  }
  if (supported) {
    readVoices();
    var voicesDone = false;
    try {
      synth.addEventListener('voiceschanged', function () {
        if (voicesDone) return;
        voicesDone = true;
        $('#scLiveRows').innerHTML = '';
        readVoices();
      });
    } catch (e) { /* 老式 onvoiceschanged 由下方定时器兜底 */ }
    setTimeout(function () { if (!voices.length) { $('#scLiveRows').innerHTML = ''; readVoices(); } }, 1400);
  } else {
    $('#scVoices').textContent = '—';
    $('#scZh').textContent = '—';
    live('语音合成能力', false, '当前浏览器不支持 Web Speech API，请换用 Edge / Chrome');
  }

  /* ---------- 音色试听 ---------- */
  var STYLES = [
    { k: 'gentle',  n: '温柔御姐', d: 'rate 0.90 · pitch 0.80', rate: 0.90, pitch: 0.80,
      t: '你好呀，慢慢来，我在这儿陪着你。' },
    { k: 'sweet',   n: '清甜少女', d: 'rate 1.02 · pitch 1.16', rate: 1.02, pitch: 1.16,
      t: '今天也要开开心心的哦，我们一起去看看吧！' },
    { k: 'natural', n: '系统原声', d: 'rate 1.00 · pitch 1.00', rate: 1.00, pitch: 1.00,
      t: '这是系统默认音色，不做任何调整。' },
    { k: 'yandere', n: '病娇',     d: '1.06 / 1.22 · 起伏', rate: 1.06, pitch: 1.22,
      t: '你终于来看我了……这次，不会再让你走掉了，呐？' }
  ];
  var grid = $('#scVoiceGrid');
  STYLES.forEach(function (s) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = 'try' + (s.k === 'yandere' ? ' is-y' : '');
    b.innerHTML = esc(s.n) + '<small>' + esc(s.d) + '</small>';
    b.addEventListener('click', function () { trySpeak(s, b); });
    grid.appendChild(b);
  });

  function pickVoice() {
    if (!voices.length && synth) { try { voices = synth.getVoices() || []; } catch (e) {} }
    var zh = voices.filter(function (v) { return /^(zh|cmn|yue)/i.test(v.lang || ''); });
    var pool = zh.length ? zh : voices;
    var rank = ['xiaoxiao', '晓晓', 'xiaoyi', '晓伊', 'yaoyao', '瑶瑶', 'huihui', '慧慧', 'tingting', '婷婷'];
    var best = null, score = -1;
    pool.forEach(function (v) {
      var n = String(v.name || '').toLowerCase(), sc = 0;
      for (var i = 0; i < rank.length; i++) { if (n.indexOf(rank[i]) >= 0) { sc = 100 - i * 6; break; } }
      if (/natural|neural|online/.test(n)) sc += 12;
      if (/female|女/.test(n)) sc += 6;
      if (!sc && /zh/i.test(v.lang || '')) sc = 1;
      if (sc > score) { score = sc; best = v; }
    });
    return best || pool[0] || null;
  }

  function trySpeak(s, btn) {
    if (!supported) { log('浏览器不支持语音合成，无法试听', 'e'); return; }
    grid.querySelectorAll('button').forEach(function (x) { x.disabled = true; });
    log('试听「' + s.n + '」→ ' + s.t);
    try { synth.cancel(); } catch (e) {}
    setTimeout(function () {
      var v = pickVoice();
      var u = new Utter(s.t);
      if (v) { try { u.voice = v; } catch (e) {} u.lang = v.lang; }
      else u.lang = 'zh-CN';
      u.rate = s.rate; u.pitch = s.pitch; u.volume = 1;
      var started = false, t0 = Date.now();
      u.onstart = function () { started = true; log('  onstart ✓ 真的出声了（' + (Date.now() - t0) + 'ms）' + (v ? ' · ' + v.name : ''), 'ok'); };
      u.onend = function () { log('  onend ✓ 播放完成', 'ok'); unlock(); };
      u.onerror = function (ev) { log('  onerror ✗ ' + (ev && ev.error ? ev.error : 'unknown') + '（常见：not-allowed / synthesis-failed）', 'e'); unlock(); };
      try { synth.resume(); synth.speak(u); } catch (e) { log('  speak 抛错：' + e.message, 'e'); unlock(); }
      setTimeout(function () {
        if (!started && !synth.speaking && !synth.pending) {
          log('  1.6s 内没有 onstart：被自动播放策略拦截，或系统无可用语音包', 'w');
          live('实际出声', false, '已提交朗读但未收到 onstart，请参考下方排查建议');
          unlock();
        } else if (!started) log('  引擎仍在处理队列，请再稍等…', 'w');
        else live('实际出声', true, '收到 onstart，' + s.n + ' 音色已真正播放');
      }, 1600);
    }, 140);
    function unlock() { grid.querySelectorAll('button').forEach(function (x) { x.disabled = false; }); }
  }

  /* ---------- 自动播放拦截检测 ---------- */
  $('#scAuto').addEventListener('click', function () {
    if (!supported) { log('不支持语音合成，跳过', 'e'); return; }
    log('自动播放检测：延迟 900ms 后无手势提交朗读…');
    setTimeout(function () {
      try { synth.cancel(); } catch (e) {}
      var u = new Utter('检测自动播放');
      u.lang = 'zh-CN'; u.rate = 1; u.pitch = 1; u.volume = 0;
      var fired = false;
      u.onstart = function () { fired = true; log('  onstart 触发：本浏览器允许无手势朗读', 'ok'); live('自动播放策略', true, '无手势也能出声'); };
      u.onerror = function () { fired = true; log('  onerror：无手势朗读被拒绝', 'e'); };
      try { synth.resume(); synth.speak(u); } catch (e) {}
      setTimeout(function () {
        if (!fired) { log('  未收到任何事件：判定为「静默拦截」——这正是版娘无声的头号原因', 'w');
          live('自动播放策略', null, '无手势朗读被静默拦截；修复版已在首次点击时预热引擎，点一下页面/小喇叭即可出声'); }
        try { synth.cancel(); } catch (e) {}
      }, 1300);
    }, 900);
  });

  /* ---------- 尺寸实测 ---------- */
  $('#scSize').addEventListener('click', function () {
    var r = $('#scProbe').getBoundingClientRect();
    var w = Math.round(r.width), h = Math.round(r.height);
    var ok = w <= 330 && h <= 400;
    $('#scSizeOut').innerHTML = '<dt>实测</dt><dd>' + w + ' × ' + h + ' px</dd>' +
      '<dt>阈值</dt><dd>330 × 400 px</dd>' +
      '<dt>视口</dt><dd>' + window.innerWidth + ' × ' + window.innerHeight + ' px</dd>';
    live('聊天窗尺寸实测', ok, w + ' × ' + h + ' px，' + (ok ? '在紧凑区间内' : '仍超出紧凑阈值'));
    log('尺寸探针：' + w + ' × ' + h + ' → ' + (ok ? 'PASS' : 'FAIL'), ok ? 'ok' : 'e');
  });

  log('自检台就绪。静态核查 ' + window.SC_STATIC.length + ' 项，试听 4 种音色。');
  if (!supported) log('当前环境没有语音合成能力，试听项不可用（可用 Edge/Chrome 打开本页复检）', 'w');

  /* ---------- 无人值守自动试听（?auto=1）：回执写进 body[data-auto] 供 --dump-dom 抓取 ---------- */
  if (location.search.indexOf('auto=1') >= 0 && supported) {
    var autoLog = [], ai = 0;
    function autoNext() {
      if (ai >= STYLES.length) { document.body.setAttribute('data-auto', autoLog.join(' | ')); return; }
      var s = STYLES[ai], res = s.k + ':', done = false;
      try { synth.cancel(); } catch (e) {}
      var v = pickVoice();
      var u = new Utter(s.t);
      if (v) { try { u.voice = v; } catch (e) {} u.lang = v.lang; } else u.lang = 'zh-CN';
      u.rate = s.rate; u.pitch = s.pitch; u.volume = 1;
      u.onstart = function () { res += 'onstart'; };
      u.onend = function () { res += '/onend'; autoDone(); };
      u.onerror = function (ev) { res += '/error(' + (ev && ev.error ? ev.error : '?') + ')'; autoDone(); };
      function autoDone() {
        if (done) return;
        done = true;
        autoLog.push(res); ai++;
        log('自动试听 ' + s.n + ' → ' + res, /onstart/.test(res) ? 'ok' : 'w');
        setTimeout(autoNext, 150);
      }
      try { synth.resume(); synth.speak(u); } catch (e) { res += '/throw'; autoDone(); }
      setTimeout(function () { if (!done) { res += '/timeout'; autoDone(); } }, 3200);
    }
    setTimeout(autoNext, 500);
  }
})();
</script>
</body>
</html>
