<?php
/**
 * MoeZ 自检工具 v1.6.4 —— 排查「文件版本不一致 / 覆盖不完整」
 * 用法：放到站点根目录，浏览器访问 https://你的域名/diag.php
 * 原理：将服务器上各文件的 MD5 与 v1.6.4 标准版逐一比对，不匹配即为旧版/损坏
 * ⚠️ 排查完成后请立即删除本文件
 */
header('Content-Type: text/html; charset=utf-8');
error_reporting(0);
$root = dirname(__DIR__);

/* ---------- v1.6.4 标准文件清单（MD5 前 8 位） ---------- */
$baseline = array(
    'init.php' => array('ef2647ea', 1545),
    'index.php' => array('3d423a04', 19532),
    'install.php' => array('734a45b6', 21914),
    '.htaccess'                      => array('2a1d60a8', 991),
    'link.php'                       => array('c6fc46df', 2304),
    'comment.php'                    => array('a408e5ed', 2017),
    'admin/bootstrap.php'            => array('383bcdf9', 1139),
    'admin/post-edit.php' => array('29205089', 31973),
    'admin/settings.php' => array('df1c8e48', 20077),
    'admin/links.php'                => array('605f2356', 10148),
    'admin/comments.php'             => array('2733e642', 7595),
    'admin/themes.php'               => array('11666426', 3303),
    'admin/theme-settings.php'       => array('f2bd4cd6', 5954),
    'admin/posts.php' => array('aae80988', 7034),
    'admin/categories.php'           => array('52d3be7d', 7774),
    'admin/upload.php'               => array('56a24edf', 2255),
    'admin/includes/header.php' => array('64a8af32', 2785),
    'admin/assets/admin.css' => array('6b1d7068', 20408),
    'admin/index.php' => array('4b2b3974', 7897),
    'admin/autosave.php' => array('c81ff1cb', 4158),
    'admin/spiders.php' => array('6b0a93d3', 6916),
    'includes/functions.php'         => array('258db742', 14787),
    'includes/markdown.php'          => array('ceaf7259', 21368),
    'includes/seo.php' => array('1e3905b9', 21565),
    'includes/db.php'                => array('216f558c', 1253),
    'includes/upgrade.php' => array('edb5a6f0', 6862),
    'includes/ipinfo.php'            => array('dbdb06d0', 4633),
    'includes/linkcheck.php'         => array('04ece198', 3735),
    'includes/spider.php' => array('6bc4d6d6', 8461),
    'templates/moezzz/info.php'      => array('bd46c373', 1676),
    'templates/moezzz/header.php'    => array('8f1e2003', 3873),
    'templates/moezzz/footer.php'    => array('441185ee', 7840),
    'templates/moezzz/post.php'      => array('3251c95b', 6240),
    'templates/moezzz/index.php'     => array('0231b785', 11685),
    'templates/moezzz/assets/style.css' => array('dc28b5aa', 35663),
    'templates/flowersink/info.php'  => array('f82cf18e', 5553),
    'templates/flowersink/header.php' => array('8c8b1cae', 6930),
    'templates/flowersink/footer.php' => array('9c1bf0d3', 4810),
    'templates/flowersink/index.php' => array('31310d87', 6905),
    'templates/flowersink/_me-card.php' => array('298319cb', 4358),
    'templates/flowersink/article.php' => array('131bb7ae', 4207),
    'templates/flowersink/category.php' => array('92ea945e', 2934),
    'templates/flowersink/archive.php' => array('d4c0d6cf', 3648),
    'templates/flowersink/life.php'  => array('c0d14431', 6637),
    'templates/flowersink/post.php'  => array('7338e92e', 10500),
    'templates/flowersink/link.php'  => array('6c98a31e', 7698),
    'templates/flowersink/about.php' => array('866b5db2', 2788),
    'templates/flowersink/search.php' => array('f04835a1', 1314),
    'templates/flowersink/page.php'  => array('7a994d1c', 565),
    'templates/flowersink/404.php'   => array('2bc245b6', 448),
    'templates/flowersink/maintenance.php' => array('811f81db', 426),
    'templates/flowersink/assets/style.css' => array('737697ec', 152913),
);

$mustExist = array('config.php');   // 本地生成，不做哈希比对

$rows = array();
$mismatch = 0; $missing = 0; $okCount = 0;
foreach ($baseline as $rel => $ref) {
    $abs = $root . '/' . $rel;
    $exists = is_file($abs);
    $hash = $exists ? substr(md5_file($abs), 0, 8) : '';
    $size = $exists ? filesize($abs) : 0;
    $state = !$exists ? 'missing' : ($hash === $ref[0] ? 'ok' : 'old');
    if ($state === 'missing') $missing++;
    elseif ($state === 'old') $mismatch++;
    else $okCount++;
    $rows[] = array(
        'rel' => $rel, 'state' => $state,
        'size' => $size, 'refSize' => $ref[1],
        'hash' => $hash, 'refHash' => $ref[0],
        'mtime' => $exists ? date('m-d H:i', filemtime($abs)) : '-',
    );
}
foreach ($mustExist as $rel) {
    $exists = is_file($root . '/' . $rel);
    $rows[] = array('rel' => $rel, 'state' => $exists ? 'ok' : 'missing',
        'size' => $exists ? filesize($root . '/' . $rel) : 0, 'refSize' => '-',
        'hash' => '-', 'refHash' => '-', 'mtime' => '-');
    if (!$exists) $missing++;
}

/* ---------- post-edit.php INSERT 列/值数量体检 ---------- */
function check_insert($root) {
    $f = $root . '/admin/post-edit.php';
    if (!is_file($f)) return array('ok' => false, 'msg' => '文件不存在');
    $src = file_get_contents($f);
    $pos = strpos($src, 'INSERT INTO');
    if ($pos === false) return array('ok' => false, 'msg' => '未找到 INSERT INTO posts 语句');

    // 列清单：INSERT INTO ... (col,col,...) VALUES
    if (!preg_match('/\(([^()]*?)\)\s*VALUES/is', $src, $cm, 0, $pos)) {
        return array('ok' => false, 'msg' => '无法解析列清单');
    }
    // 值清单：VALUES (...)' —— 惰性匹配到 SQL 字面量结束的 )'
    if (!preg_match('/\bVALUES\s*\((.*?)\)\'\s*,/s', $src, $vm, 0, $pos + strlen($cm[0]))) {
        return array('ok' => false, 'msg' => '无法解析 VALUES 清单');
    }
    $ncol = substr_count($cm[1], ',') + 1;
    $nval = substr_count($vm[1], ',') + 1;
    $nph  = substr_count($vm[1], '?');
    $nnow = preg_match_all('/\bNOW\s*\(\s*\)/i', $vm[1]);

    // 绑定参数个数：从 VALUES 匹配结束处向后找 array( ... )) 并做括号平衡统计
    $bind = array();
    $tail = substr($src, $pos + strlen($vm[0]));
    if (preg_match('/array\s*\(([\s\S]*)/', $tail, $am)) {
        $depth = 1; $cur = '';
        for ($i = 0, $n = strlen($am[1]); $i < $n; $i++) {
            $c = $am[1][$i];
            if ($c === '(') $depth++;
            elseif ($c === ')') { $depth--; if ($depth === 0) break; }
            if ($c === ',' && $depth === 1) { $bind[] = trim($cur); $cur = ''; continue; }
            $cur .= $c;
        }
        if (trim($cur) !== '') $bind[] = trim($cur);
    }
    $ok = ($ncol === $nval) && ($nph === count($bind));
    $msg = "列 {$ncol} 个 · 值 {$nval} 个（?×{$nph} + NOW()×{$nnow}）· 绑定参数 " . count($bind) . " 个"
         . ($ok ? ' —— 匹配 ✓' : ' —— ⚠ 数量不一致，该文件不是 v1.6.4 标准版');
    return array('ok' => $ok, 'msg' => $msg);
}
$ins = check_insert($root);

/* ---------- 嵌套目录检测 ---------- */
$nested = array();
foreach (array('MoeZ', 'MoeZ', 'MoeZ-master') as $d) {
    if (is_dir($root . '/' . $d)) $nested[] = $d;
}

/* ---------- 结论 ---------- */
if ($nested) {
    $concl = '❌ 检测到子目录 <b>' . htmlspecialchars(implode('、', $nested)) . '</b>：文件被解压进了多余一层目录。'
           . '请把该子目录里的全部文件（含隐藏文件）移动到站点根目录，与 config.php 同级。';
} elseif ($missing > 0) {
    $concl = "❌ 有 <b>{$missing}</b> 个文件缺失（v1.4.0 起新增了 link.php、includes/ipinfo.php、includes/linkcheck.php 等）。"
           . '请把 <b>MoeZ-hotfix-1.6.4.zip</b>解压后<b>整体覆盖</b>到站点根目录 /www/wwwroot/demo.moekuu.com/。';
} elseif ($mismatch > 0 || !$ins['ok']) {
    $concl = "⚠️ 有 <b>{$mismatch}</b> 个文件与 v1.6.4 标准版不一致（表中标「旧版」的行）。"
           . '最省事的做法：把 <b>MoeZ-hotfix-1.6.4.zip</b> 全部解压覆盖到站点根目录，然后在宝塔重启 PHP 清 opcache，刷新本页复查。';
} else {
    $concl = '✅ 全部文件均为 v1.6.4 标准版，INSERT 语句体检通过。若仍报错，请到宝塔「PHP 设置」<b>重启 PHP</b>（清除 opcache 旧缓存）后重试。';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>MoeZ 自检 v1.6.4</title>
<style>
  :root{--ink:#2d2a3e;--muted:#8b86a0;--line:#eae5f4;--ok:#2e9e6b;--bad:#d94a5a;--warn:#d9952e;--bg:#f7f5fc}
  *{box-sizing:border-box}
  body{margin:0;padding:32px 18px 60px;background:var(--bg);color:var(--ink);
       font:14px/1.7 -apple-system,"Segoe UI","Microsoft YaHei",sans-serif}
  .wrap{max-width:960px;margin:0 auto}
  h1{font-size:20px;margin:0 0 6px}
  .sub{color:var(--muted);font-size:12.5px;margin-bottom:22px}
  .card{background:#fff;border:1px solid var(--line);border-radius:14px;padding:18px 20px;
        margin-bottom:16px;box-shadow:0 2px 10px rgba(120,100,180,.05)}
  .concl{font-size:13.5px;line-height:1.85;padding:16px 18px;border-radius:12px;
         background:#fdfbff;border:1px dashed #d9d0ee;margin-bottom:16px}
  table{width:100%;border-collapse:collapse;font-size:12.5px}
  th,td{text-align:left;padding:7px 8px;border-bottom:1px solid #f2eef9}
  th{color:var(--muted);font-weight:600;font-size:11.5px}
  td.n{font-family:Consolas,monospace;color:#4a4560}
  .ok{color:var(--ok);font-weight:600}
  .bad{color:var(--bad);font-weight:600}
  .warn{color:var(--warn);font-weight:600}
  .tag{display:inline-block;font-size:11px;padding:1px 8px;border-radius:999px}
  .tag.ok{background:rgba(46,158,107,.1)}
  .tag.bad{background:rgba(217,74,90,.1)}
  .tag.warn{background:rgba(217,149,46,.12)}
  h2{font-size:13px;margin:0 0 12px;color:var(--muted);font-weight:600}
  .path{font-family:Consolas,monospace;font-size:12px;background:#f4f1fb;padding:2px 8px;border-radius:6px}
</style>
</head>
<body>
<div class="wrap">
  <h1>🌸 MoeZ 自检 v1.6.4</h1>
  <div class="sub">站点根目录：<span class="path"><?php echo htmlspecialchars($root); ?></span></div>

  <div class="concl"><?php echo $concl; ?></div>

  <?php if ($nested): ?>
  <div class="card" style="border-color:#f3c9cf;background:#fff8f9">
    <h2 style="color:#d94a5a">⚠ 发现多余子目录</h2>
    <p style="margin:0;font-size:13px">请进入 <span class="path"><?php echo htmlspecialchars($root . '/' . $nested[0]); ?></span>，
      全选文件剪切到上一级目录（与 config.php 同级）。</p>
  </div>
  <?php endif; ?>

  <div class="card">
    <h2>关键 SQL 体检 · admin/post-edit.php</h2>
    <div style="font-size:13px">
      <?php echo $ins['ok'] ? '<span class="ok">PASS</span>' : '<span class="bad">FAIL</span>'; ?>
      &nbsp;<?php echo htmlspecialchars($ins['msg']); ?>
    </div>
  </div>

  <div class="card">
    <h2>文件比对（共 <?php echo count($baseline) + 1; ?> 项 · 标准 ✓ / 旧版 ⚠ / 缺失 ✗）</h2>
    <table>
      <tr><th style="width:32%">文件</th><th style="width:10%">状态</th><th style="width:16%">实际 MD5</th>
          <th style="width:16%">标准 MD5</th><th style="width:12%">大小</th><th>修改时间</th></tr>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td class="n"><?php echo htmlspecialchars($r['rel']); ?></td>
        <td>
          <?php if ($r['state'] === 'ok'): ?><span class="tag ok">标准</span>
          <?php elseif ($r['state'] === 'old'): ?><span class="tag warn">旧版</span>
          <?php else: ?><span class="tag bad">缺失</span><?php endif; ?>
        </td>
        <td class="n" style="color:var(--muted)"><?php echo htmlspecialchars($r['hash']); ?></td>
        <td class="n" style="color:var(--muted)"><?php echo htmlspecialchars($r['refHash']); ?></td>
        <td style="color:var(--muted)"><?php echo is_numeric($r['size']) ? number_format($r['size']) . ' B' : '-'; ?></td>
        <td style="color:var(--muted);font-size:12px"><?php echo $r['mtime']; ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>

  <div class="card" style="background:#fffdf6;border-color:#f0e2c4">
    <h2 style="color:#b8862e">排查完成后</h2>
    <p style="margin:0;font-size:13px">请立即删除本文件 <span class="path">diag.php</span>，避免泄露服务器路径信息。</p>
  </div>
</div>
</body>
</html>
