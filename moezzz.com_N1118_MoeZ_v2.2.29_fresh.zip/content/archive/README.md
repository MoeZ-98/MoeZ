# 归档中心（不参与运行）

本目录存放**历史 / 开发 / 不再被引用**的文件，只做集中保管，**没有删除任何数据**。

## 为什么放这里

- 在线更新接口 `update-api.php` 生成官方文件清单时，会**整体跳过 `content/`**，
  所以这里的东西不会被打进更新包、也不会推给客户站；
- 本目录有 `.htaccess` 拒绝 Web 访问；Nginx / Caddy 配置里也已加入 deny 规则；
- 后台「资源管理」只扫描 `uploads/`、`upload/`、`content/uploadfile/`，
  不会把归档文件误列成附件。

## 里面有什么

| 子目录 | 来源 | 内容 |
|---|---|---|
| `dev-tests/` | 原根目录 `tests/` | 积分功能自测 `points_test.php` + 16 个页面截图 / HTML（约 2.1M） |
| `theme-packages/` | 原 `templates/` | `Fomalhaut_v2.1.30.zip`、`Fomalhaut_v2.1.31.zip` 两个历史主题安装包 |
| `legacy-assets/` | 原根目录 | `docs.html`（旧说明页）、`favicon.png`（0 引用的旧图标） |

## 怎么恢复

把对应文件拷回原路径即可。注意 `points_test.php` 使用 `__DIR__ . '/out'` 作为输出目录，
整个 `dev-tests/` 一起搬回去就能直接 `php tests/points_test.php` 跑，不需要改代码。

## 什么没有归档

- `uploads/` 里的中文乱码重复图片：**保留原位**，可能被文章引用，需后台按引用计数确认后再删；
- `favicon.ico` / `logo.png`：仍被代码引用；
- `docs1.html`：`update-api.php` 的清单逻辑里提到它；
- `update/`：是版本包投放的功能目录，不是归档目录。
