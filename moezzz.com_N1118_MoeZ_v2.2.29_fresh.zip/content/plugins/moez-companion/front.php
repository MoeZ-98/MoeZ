<?php
/**
 * 萌Z 版娘 · 前台 DOM 渲染
 * 由 templates/fomalhaut/footer.php 的看板娘挂载块迁出，保留全部原有 class 与交互结构，
 * 仅把容器 id 改为 moez-companion（让主题自带 app.js 自动空转），并补上性别 / 调试入口。
 */
if (!defined('MOE_ROOT')) { http_response_code(403); exit('forbidden'); }

function moez_cp_render_dom()
{
    $esc = function_exists('e') ? 'e' : 'htmlspecialchars';
    $name = trim(moez_cp_opt('name', ''));
    if ($name === '') $name = '小星';

    $imgRel = trim(moez_cp_opt('img', ''));
    $img = $imgRel !== '' && function_exists('media_url')
         ? media_url($imgRel)
         : moez_cp_q('?moez_cp_asset=companion.png&v=' . MOEZ_CP_VER);

    $height = (int)trim(moez_cp_opt('height', ''));
    $siteName = function_exists('setting') ? trim((string)setting('site_name', '')) : '';
    if ($siteName === '') $siteName = '小站';

    $greet = trim(moez_cp_opt('greet', ''));
    if ($greet === '') $greet = '在的呀～我是' . $siteName . '的看板娘' . $name . '，可以问我「最新文章」「热门推荐」，也可以直接丢关键词让我帮你找文章。';
    $hint = trim(moez_cp_opt('hint', ''));
    if ($hint === '') $hint = '点我聊天 ✦';

    $voiceOn   = moez_cp_on('voice_on', true) ? '1' : '0';
    $vAuto     = moez_cp_on('voice_autoplay', true) ? '1' : '0';
    $gender    = moez_cp_opt('gender', 'female');
    if (!in_array($gender, array('female', 'male'), true)) $gender = 'female';
    $style     = moez_cp_opt('style', 'gentle');
    if (!in_array($style, array('gentle', 'sweet', 'natural', 'yandere'), true)) $style = 'gentle';
    $rate      = trim(moez_cp_opt('rate', ''));
    $pitch     = trim(moez_cp_opt('pitch', ''));
    $voiceUri  = trim(moez_cp_opt('voice_uri', ''));
    $panelSize = moez_cp_opt('cp_panel_size', 'compact');
    if (!in_array($panelSize, array('compact', 'standard'), true)) $panelSize = 'compact';
    $side      = moez_cp_opt('side', 'left');
    $debugOn   = moez_cp_on('debug_front', true) ? '1' : '0';

    $labels = array('gentle' => '温柔御姐', 'sweet' => '清甜少女', 'natural' => '系统原声', 'yandere' => '病娇');
    $shorts = array('gentle' => '御姐', 'sweet' => '少女', 'natural' => '原声', 'yandere' => '病娇');
    $vlabel = $labels[$style];
    $vshort = $shorts[$style];
    $genderLabel = $gender === 'male' ? '男声' : '女声';
    $genderIcon  = $gender === 'male' ? '♂' : '♀';

    $cls = 'fo-companion moez-companion'
         . ($side === 'right' ? ' fo-companion--right' : '')
         . ($style === 'yandere' ? ' is-yandere' : '');

    $h = '<div class="' . $cls . '" id="moez-companion"'
       . ($height > 80 ? ' style="--fo-cp-h:' . $height . 'px;"' : '')
       . "\n"
       . '     data-api="' . $esc(moez_cp_q('chat.php')) . '"' . "\n"
       . '     data-token="' . $esc(function_exists('csrf_token') ? csrf_token() : '') . '"' . "\n"
       . '     data-name="' . $esc($name) . '"' . "\n"
       . '     data-greet="' . $esc($greet) . '"' . "\n"
       . '     data-panel-size="' . $esc($panelSize) . '"' . "\n"
       . '     data-voice="' . $esc($voiceOn) . '"' . "\n"
       . '     data-voice-auto="' . $esc($vAuto) . '"' . "\n"
       . '     data-voice-style="' . $esc($style) . '"' . "\n"
       . '     data-voice-rate="' . $esc($rate) . '"' . "\n"
       . '     data-voice-pitch="' . $esc($pitch) . '"' . "\n"
       . '     data-voice-gender="' . $esc($gender) . '"' . "\n"
       . '     data-voice-uri="' . $esc($voiceUri) . '"' . "\n"
       . '     data-debug="' . $esc($debugOn) . '">' . "\n";

    $h .= '  <div class="fo-cp-panel">' . "\n"
        . '    <div class="fo-cp-head">' . "\n"
        . '      <span class="fo-cp-dot"></span>' . "\n"
        . '      <span class="fo-cp-head-name">' . $esc($name) . '</span>' . "\n"
        . '      <span class="fo-cp-head-status">在线 · 站内小助手</span>' . "\n"
        . '      <button type="button" class="fo-cp-reset" aria-label="重新开始对话" title="重新开始对话">' . "\n"
        . '        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1"/><path d="M3 4.2v5h5"/></svg>' . "\n"
        . '      </button>' . "\n"
        . '      <button type="button" class="fo-cp-style" aria-label="切换语音音色" title="切换语音音色（当前：' . $esc($vlabel) . '）" aria-pressed="false">' . "\n"
        . '        <span class="fo-cp-style-ico">♪</span><span class="fo-cp-style-name">' . $esc($vshort) . '</span>' . "\n"
        . '      </button>' . "\n"
        . '      <button type="button" class="fo-cp-gender" aria-label="切换男声女声（当前：' . $esc($genderLabel) . '）" title="切换男声 / 女声（当前：' . $esc($genderLabel) . '）" aria-pressed="false">' . $genderIcon . '</button>' . "\n"
        . '      <button type="button" class="fo-cp-voice is-on" aria-label="关闭语音" title="' . $esc($vlabel) . '语音：开">' . "\n"
        . '        <span class="fo-cp-vw"><i></i><i></i><i></i></span>' . "\n"
        . '        <svg class="fo-cp-vico" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/></svg>' . "\n"
        . '        <svg class="fo-cp-voff" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="m17 9 4 6"/><path d="m21 9-4 6"/></svg>' . "\n"
        . '      </button>' . "\n"
        . '      <button type="button" class="fo-cp-close" aria-label="收起对话">&times;</button>' . "\n"
        . '    </div>' . "\n"
        . '    <div class="fo-cp-msgs" id="fo-cp-msgs"></div>' . "\n"
        . '    <div class="fo-cp-chips" id="fo-cp-chips"></div>' . "\n"
        . '    <form class="fo-cp-form" id="fo-cp-form">' . "\n"
        . '      <input type="text" class="fo-cp-input" id="fo-cp-input" maxlength="200" placeholder="和 ' . $esc($name) . ' 说点什么…" autocomplete="off">' . "\n"
        . '      <button type="submit" class="fo-cp-send" aria-label="发送">' . "\n"
        . '        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4Z"/></svg>' . "\n"
        . '      </button>' . "\n"
        . '    </form>' . "\n"
        . '    <button type="button" class="moez-cp-debug-link" aria-label="打开语音调试">🎙 语音调试</button>' . "\n"
        . '  </div>' . "\n"
        . '  <div class="fo-cp-figure" role="button" tabindex="0" aria-label="打开聊天">' . "\n"
        . '    <img src="' . $esc($img) . '" alt="' . $esc($name) . '" draggable="false" decoding="async">' . "\n"
        . '  </div>' . "\n"
        . '  <button type="button" class="fo-cp-mini" aria-label="叫出' . $esc($name) . '" title="叫出' . $esc($name) . '">' . "\n"
        . '    <img src="' . $esc($img) . '" alt="" aria-hidden="true" draggable="false" decoding="async">' . "\n"
        . '    <i aria-hidden="true">✦</i>' . "\n"
        . '  </button>' . "\n"
        . '  <div class="fo-cp-hint">' . $esc($hint) . '</div>' . "\n"
        . '</div>' . "\n";

    return $h;
}
