# 🎙 萌Z 版娘 · 男女语音（MoeZ Companion）

看板娘独立插件。原先整块埋在 `templates/fomalhaut/` 里的 DOM、样式、聊天逻辑，本轮全部迁到这里，
通过 CMS 原生钩子挂载，**2.2.30 起首次部署自动启用**，7 套主题通用。

## 启用 / 停用

- **默认**：第一次访问站点时由 `includes/plugins.php` 自动写入启用列表（一次性 marker）。
- **停用**：后台 → **插件管理** → 找到「🎙 萌Z 版娘 · 男女语音」→ 点「停用」。
  停用后不会被自动重新启用（marker 已置位）。
- **未启用**：fomalhaut 主题继续输出它自己的版娘，其它主题没有版娘（与改造前一致）。
- **已启用**：7 套主题都能显示版娘。fomalhaut 的 `footer.php` 会自动让出自带挂载块，
  主题的 `app.js` 因为找不到 `#fo-companion` 直接返回，所以不会同页出现两套。
- 停用插件即刻回到原样，不需要改任何文件。

## 目录

| 文件 | 作用 |
|---|---|
| `plugin.json` | 插件元信息与钩子清单 |
| `plugin.php` | 设置读取、资产代理、保存 API、5 个钩子注册 |
| `front.php` | 前台 DOM（从 `templates/fomalhaut/footer.php` 迁出） |
| `assets/companion.css` | 版娘样式（从 `templates/fomalhaut/assets/style.css` 迁出）+ 变量兜底 |
| `assets/companion.js` | 聊天逻辑（从 `templates/fomalhaut/assets/app.js` 的独立 IIFE 迁出） |
| `assets/voice-core.js` | 男声 / 女声枚举、打分挑选、试听、引擎诊断（前后台共用） |
| `assets/debug.js` | 前台语音调试浮层 |
| `assets/admin.js` / `admin.css` | 后台语音调试台与新增 UI 样式 |
| `assets/companion.png` | 默认立绘（从 fomalhaut 复制，插件不再依赖主题目录） |

所有静态资产通过 `?moez_cp_asset=文件名` 白名单代理输出，**不依赖 Web 服务器是否放行 `content/`**。
请不要给 `content/plugins/` 整体加 deny，也不要把这个目录当空目录清掉。

## 设置

设置存在 `settings` 表，键前缀 `moez_cp_`。读不到时自动回落 fomalhaut 主题的
`themeopt_fomalhaut_*`，所以迁移前的看板娘名字、立绘、语速等配置不会丢。

| 键 | 含义 | 默认 |
|---|---|---|
| `enabled` | 插件总开关 | `1` |
| `scope` | `all` 全站 / `home` 仅首页 | `all` |
| `name` / `img` / `height` / `side` / `greet` / `hint` | 名字、立绘、高度、左右、招呼语、气泡 | 沿用旧主题设置 |
| `gender` | `female` 女声 / `male` 男声 | `female` |
| `style` | `gentle` / `sweet` / `natural` / `yandere` | `gentle` |
| `rate` / `pitch` | 语速 / 音调（留空用音色预设） | 空 |
| `voice_uri` | 指定系统语音的 `voiceURI` | 空（自动挑） |
| `voice_on` / `voice_autoplay` | 语音总开关 / 自动朗读 | `1` / `1` |
| `debug_front` | 前台是否显示调试入口 | `1` |

## 男女语音

`voice-core.js` 用浏览器内置 `speechSynthesis`，**不调用任何外部 TTS、不产生费用、不上传任何文本**。

- 男声优先：云希 / 云健 / 云扬 / 康康 / Yunxi / Yunjian / Kangkang …
- 女声优先：晓晓 / 晓伊 / 瑶瑶 / 慧慧 / 婷婷 / Xiaoxiao / Xiaoyi …
- 打分维度：中文语音、自然语音（Natural / Neural）、性别匹配、名称优先级。
  原先主题里「识别到男声扣 20 分」的写法已移除。
- 朗读队列、串行播放、首次手势解锁、Chrome 长句保活、移动端跳过 pause/resume、
  四档音色（温柔御姐 / 清甜少女 / 系统原声 / 病娇）全部保留。

**人设与聊天台词没有改**：AI 提示词与本地闲聊仍是原来的设定，本插件只换朗读音色。

## 调试

- **前台**：聊天窗头部 `♀ / ♂` 一键切换；底部「🎙 语音调试」浮层可列出系统全部语音、
  逐个试听、调语速 / 音调、查看引擎诊断。网址加 `?voice_debug=1` 会自动展开。
  访客的切换只对自己生效；登录站长后浮层里才会出现「保存为站点默认」。
- **后台**：侧栏「🎙 语音调试」直达 `settings.php?voice_debug=1`；所有后台页右下角也有 🎙 调试台，
  试听满意后点「保存为站点默认」，前台刷新即生效。

**没声音怎么排查**（调试台「引擎诊断」里有实时数据）：

1. 浏览器要求首次朗读必须由用户手势触发 —— 先点一下页面任意位置，再点「试听」；
2. Windows 需要在系统设置里安装中文语音包，否则中文语音数为 0；
3. 微信 / 部分国产浏览器不提供 `speechSynthesis`，会显示「不支持」；
4. Edge / Chrome 桌面版的「Natural」神经语音效果最好；安卓 Chrome 首次取语音列表可能为空，
   插件会轮询 10 次自动重试。

## 接口安全

- `plugin.php` 顶部有 `MOE_ROOT` 守卫，被 Web 直接请求返回 403。
- `?moez_cp_asset=` 只代理 7 个固定白名单文件，无写操作。
- `?moez_cp_api=save` 要求 `is_admin()` + `moe_is_owner()` + `X-CSRF-TOKEN` 校验，
  字段白名单并做取值校验；前台访客无法保存站点默认。

## 回滚

停用插件即可。若要彻底移除：删除本目录，并从备份恢复 `templates/fomalhaut/footer.php`
（那里只加了一行 `function_exists('moez_cp_plugin_active')` 判断）。
插件不写文章、不动附件、不改数据库结构，删除是安全的。

## 主题设置（2.2.30 全主题适配）

7 套主题的 `info.php` 都声明了 **「版娘与语音」** 分组，后台「模板管理 → 模板设置」里
会单独出现一个页签，共 16 项：显示开关、名字、立绘、高度、位置、范围、欢迎语、提示、
语音性别（男 / 女）、音色、语速、音调、朗读开关、回复后自动朗读、聊天窗尺寸、前台调试入口。

读取优先级（见 `plugin.php` 的 `moez_cp_opt()`）：

```
moez_cp_*（后台「🎙 语音调试」保存的站点默认）
  → themeopt_{当前主题}_*（模板设置）
  → themeopt_fomalhaut_*（迁移前的历史设置）
  → 内置默认值
```

短键与主题长键通过 `$alias` 映射（`gender` / `debug_front` 等新键同名直读）。
主题设置里关掉「显示版娘」时，fomalhaut 也不会回退输出自带版娘 —— 兼容判断改用
`moez_cp_plugin_installed()`，只看插件是否在启用列表里。

