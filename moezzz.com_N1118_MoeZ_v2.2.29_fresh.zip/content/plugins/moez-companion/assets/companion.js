/* 萌Z 版娘 · 聊天逻辑（迁自 templates/fomalhaut/assets/app.js 727-1523）
   仅改动：容器 id、按性别选声、性别切换按钮；队列 / 手势解锁 / 保活 / 病娇音色全部保留。 */
/* ============ 2.1.16 看板娘聊天 ============ */
(function () {
  var root = document.getElementById('moez-companion');
  if (!root) return;
  var figure = root.querySelector('.fo-cp-figure');
  var panel = root.querySelector('.fo-cp-panel');
  var msgs = root.querySelector('.fo-cp-msgs');
  var chipsBox = root.querySelector('.fo-cp-chips');
  var form = root.querySelector('.fo-cp-form');
  var input = root.querySelector('.fo-cp-input');
  var closeBtn = root.querySelector('.fo-cp-close');
  var resetBtn = root.querySelector('.fo-cp-reset');
  if (!figure || !panel || !msgs) return;

  var api = root.getAttribute('data-api') || 'chat.php';
  var token = root.getAttribute('data-token') || '';
  var greet = root.getAttribute('data-greet') || '在的呀～有什么想聊的、想找的，都可以问我。';
  var DEFAULT_CHIPS = [['最新文章', '最新文章'], ['热门推荐', '热门推荐'], ['站点分类', '站点分类'], ['关于小站', '关于小站']];

  /* 2.1.27 她会读你正在看的这一页：把标题、分类、正文摘一段一起带给 AI，
     再配两条「这一页」相关的快捷话题，问「这篇讲了什么」时她真的答得上来 */
  function pageContext() {
    try {
      var body = document.querySelector('.fo-prose') || document.querySelector('.fo-catitem') || document.body;
      if (!body) return '';
      var txt = (body.innerText || body.textContent || '').replace(/\s+/g, ' ').trim();
      if (txt.length > 1600) txt = txt.slice(0, 1600);
      var cat = document.querySelector('.fo-article-meta .fo-chip-mini');
      var sub = document.querySelector('.fo-hero-sub');
      var head = (document.title || '').trim();
      if (cat) head += '｜分类：' + cat.textContent.trim();
      if (sub) head += '｜' + sub.textContent.trim();
      return head + '｜' + txt;
    } catch (e) { return ''; }
  }
  function pageChips() {
    var list = [];
    if (document.querySelector('.fo-prose')) {
      list.push(['这篇讲了什么', '帮我用三句话总结这篇《' + (document.title || '').replace(/\s*[-–|].*$/, '') + '》的要点']);
      list.push(['和我聊聊这页', '随便聊聊我现在看的这一页，说说你的想法']);
    }
    return list.concat(DEFAULT_CHIPS);
  }
  var busy = false, greeted = false;

  /* 2.1.27 触屏适配：手机上「自动聚焦输入框」会把视口顶到聊天窗并弹出键盘，
     看起来就是「她一思考完就跳到聊天框」，很打断阅读。触屏下不再自动聚焦，
     是否输入交给访客自己点。 */
  var isTouch = (function () {
    try {
      return window.matchMedia('(hover: none) and (pointer: coarse)').matches || ('ontouchstart' in window);
    } catch (e) { return false; }
  })();
  function focusInput() {
    if (!input || isTouch) return;
    try { input.focus({ preventScroll: true }); } catch (e) { try { input.focus(); } catch (e2) {} }
  }

  /* 长期记忆的钥匙：访客本地稳定 id（清浏览器数据才会换新） */
  var cid = '';
  try {
    cid = localStorage.getItem('moe_cp_cid');
    if (!cid) {
      cid = 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      localStorage.setItem('moe_cp_cid', cid);
    }
  } catch (er) {}

  /* 聊天记录本地留档：刷新页面、下次再来都能接着聊（最多 30 条） */
  var HIST_KEY = 'moe_cp_hist';
  function histLoad() {
    try { var h = JSON.parse(localStorage.getItem(HIST_KEY) || '[]'); return h && h.length ? h : []; } catch (er) { return []; }
  }
  function histSave(who, t) {
    try {
      var h = histLoad();
      h.push([who, t]);
      if (h.length > 30) h = h.slice(-30);
      localStorage.setItem(HIST_KEY, JSON.stringify(h));
    } catch (er) {}
  }
  function histClear() { try { localStorage.removeItem(HIST_KEY); } catch (er) {} }

  /* ---- 2.1.24 语音：串行队列 + 手势解锁 + 保活 + 病娇音色 ----
     无声根因：Chrome 会静默拦截无手势的 speak()、吞掉一次性塞入的多段队列、
     约 15 秒截断长朗读，cancel() 后立刻重播也会被吞。以下逐条对症处理。 */
  var synth = window.speechSynthesis || null;
  var voiceBtn = root.querySelector('.fo-cp-voice');
  var styleBtn = root.querySelector('.fo-cp-style');
  var statusEl = root.querySelector('.fo-cp-head-status');
  var STYLE_KEYS = ['gentle', 'sweet', 'natural', 'yandere'];
  var STYLE_LABEL = { gentle: '温柔御姐', sweet: '清甜少女', natural: '系统原声', yandere: '病娇' };
  var STYLE_SHORT = { gentle: '御姐', sweet: '少女', natural: '原声', yandere: '病娇' };
  var STYLE_STATUS = {
    gentle: '在线 · 站内小助手', sweet: '在线 · 今天也元气满满',
    natural: '在线 · 系统原声', yandere: '在线 · 只准看着我哦…'
  };
  var voiceBox = {
    on: root.getAttribute('data-voice') !== '0',
    auto: root.getAttribute('data-voice-auto') !== '0',
    style: root.getAttribute('data-voice-style') || 'gentle',
    rate: parseFloat(root.getAttribute('data-voice-rate')) || 0,
    pitch: parseFloat(root.getAttribute('data-voice-pitch')) || 0
  };
  if (STYLE_KEYS.indexOf(voiceBox.style) < 0) voiceBox.style = 'gentle';
  /* 四种预置音色：御姐＝放慢半拍压低；少女＝略快抬高；natural＝原声；病娇＝偏高、忽快忽慢 */
  var V_STYLE = {
    gentle:  { rate: 0.90, pitch: 0.80 },
    sweet:   { rate: 1.02, pitch: 1.16 },
    natural: { rate: 1.00, pitch: 1.00 },
    yandere: { rate: 1.06, pitch: 1.22 }
  };
  /* 系统里的中文女声优先级：晓晓(Edge Natural 最像真人) > 晓伊 > 瑶瑶 > 慧慧 > 婷婷 > 美佳 */
  var V_RANK = ['xiaoxiao', '晓晓', 'xiaoyi', '晓伊', 'yaoyao', '瑶瑶', 'meijia', '美佳', 'huihui', '慧慧', 'tingting', '婷婷', 'hanhan', '涵涵'];
  var voice = null, voiceReady = false, speaking = false, lastSpoken = '', pendingSay = '';
  var voiceTries = 0;   /* 手机端首次取不到语音列表时的重试计数 */
  var voiceQueue = [], voiceIdx = 0, voiceToken = 0;
  var keepAliveTimer = null, startTimer = null, blockedNotified = false, userGestured = false;

  function pickVoice() {
    if (!synth) return;
    var list = [];
    try { list = synth.getVoices() || []; } catch (e) { list = []; }
    if (!list.length) {
      /* 手机端首次取不到语音列表时轮询重试（原行为保留） */
      if (voiceTries++ < 8) setTimeout(pickVoice, 350);
      return;
    }
    voiceTries = 0;
    voiceReady = true;
    /* 萌Z：男声 / 女声由 voice-core.js 统一挑选，旧的「男声扣分」逻辑移除 */
    var V = window.MoeZVoice;
    var g = voiceBox.gender || root.getAttribute('data-voice-gender') || 'female';
    var uri = root.getAttribute('data-voice-uri') || '';
    if (V) {
      voice = V.pick(g, uri);
    } else {
      /* 半套更新兜底：语音核心没加载到时仍能用中文默认声 */
      voice = list.filter(function (v) { return /^(zh|cmn|yue)/i.test(v.lang || ''); })[0] || list[0] || null;
    }
  }

  function voiceSupported() { return !!synth && typeof window.SpeechSynthesisUtterance === 'function'; }
  function styleLabel() { return STYLE_LABEL[voiceBox.style] || STYLE_LABEL.gentle; }

  function setSpeaking(on) {
    speaking = on;
    root.classList.toggle('is-speaking', on);
    if (voiceBtn) {
      voiceBtn.setAttribute('aria-label', on ? '停止朗读' : (voiceBox.on ? '关闭语音' : '开启语音'));
      voiceBtn.setAttribute('title', on ? '正在说话 · 点击停止' : (styleLabel() + '语音：' + (voiceBox.on ? '开' : '关')));
    }
  }

  /* 朗读前清洗：去掉链接、emoji、装饰符号，把省略号与破折号换成停顿 */
  function cleanText(t) {
    if (!t) return '';
    var s = String(t);
    s = s.replace(/https?:\/\/\S+/g, '');
    s = s.replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}\u{200D}]/gu, '');
    s = s.replace(/[「」『』《》【】]/g, '');
    s = s.replace(/[·•✦★☆♪♥]/g, '');
    s = s.replace(/…+|\.{3,}/g, '，');
    s = s.replace(/[—–]{1,}|--/g, '，');
    s = s.replace(/\s+/g, ' ');
    return s.trim();
  }

  /* 长文本按句切分，每段不超过约 40 字 */
  function splitText(t) {
    var raw = t.match(/[^。！？!?；;\n]+[。！？!?；;\n]*/g) || [t];
    var out = [];
    raw.forEach(function (seg) {
      seg = seg.trim();
      if (!seg) return;
      if (seg.length <= 42) { out.push(seg); return; }
      var sub = seg.match(/[^，,、]+[，,、]*/g) || [seg];
      var buf = '';
      sub.forEach(function (p) {
        if ((buf + p).length > 42 && buf) { out.push(buf); buf = p; }
        else buf += p;
      });
      if (buf) out.push(buf);
    });
    return out.filter(function (s) { return s.replace(/[\s，,。！？!?；;]/g, '').length > 0; });
  }

  /* 病娇台词润色：只加语气、不改事实；检索结果 / 带数字的资讯保持原样 */
  function yanderize(t) {
    var s = String(t || '');
    if (/https?|\d{4}年|第\s*\d|\d+\s*(篇|条|个)|分类|搜索|链接|结果|地址/i.test(s)) return s;
    var tails = [
      '……只准看着我哦，呐？',
      '……嘿嘿，我一直都在这里等你呢。',
      '……不许去看别的网站哦？',
      '……你不会突然不见的，对吧？',
      '……嗯，这样就好，我们一直在一起。'
    ];
    var h = 0;
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    s = s.replace('。', '……').replace(/！/g, '…！').replace(/？/g, '…？');
    return s + tails[h % tails.length];
  }

  /* 病娇情绪曲线：逐段交替快慢高低，尾段放慢压低，像忽然贴近耳边低语 */
  function emotionCurve(i, total, st) {
    if (voiceBox.style !== 'yandere') return { rate: st.rate, pitch: st.pitch };
    var swing = [0, 0.14, -0.10, 0.18, -0.06][i % 5];
    var last = (i === total - 1);
    return {
      rate: Math.min(2, Math.max(0.5, st.rate + swing + (last ? -0.16 : 0))),
      pitch: Math.min(2, Math.max(0.3, st.pitch + swing * 1.4 + (last ? -0.28 : 0)))
    };
  }

  function keepAliveStop() {
    if (keepAliveTimer) { clearInterval(keepAliveTimer); keepAliveTimer = null; }
  }
  /* Chrome 约 15 秒会把长朗读截断；定时 pause/resume 让队列保持激活 */
  function keepAlive() {
    keepAliveStop();
    /* 手机端禁用 pause/resume 保活：iOS 会因此整段静音，Android 也会被系统打断 */
    if (isTouch) return;
    keepAliveTimer = setInterval(function () {
      if (!speaking || !synth) { keepAliveStop(); return; }
      try { synth.pause(); synth.resume(); } catch (er) {}
    }, 8000);
  }

  function stopSpeak() {
    voiceToken++;                 /* 作废在途 onstart/onend，避免 cancel 后旧队列复活 */
    voiceQueue = []; voiceIdx = 0;
    if (startTimer) { clearTimeout(startTimer); startTimer = null; }
    keepAliveStop();
    if (synth) { try { synth.cancel(); } catch (er) {} }
    setSpeaking(false);
  }

  /* 静默失败必须可见：告诉访客是浏览器拦了，以及怎么解锁 */
  function voiceBlocked(reason) {
    root.setAttribute('data-voice-blocked', reason === 'error' ? '2' : '1');
    if (!msgs) return;
    var tip = document.createElement('div');
    tip.className = 'fo-cp-msg is-bot is-sys';
    var line = document.createElement('div');
    line.className = 'fo-cp-bubble';
    line.textContent = reason === 'mobile'
      ? '这台手机的浏览器没让我出声…可能是没装中文语音包，或在微信/B站这类内置浏览器里打开了。用系统浏览器打开本站，声音就正常了 ✦'
      : (reason === 'error'
        ? '语音好像没念出来…检查一下系统音量或中文语音包，再点这句话旁的小喇叭试试 ✦'
        : '浏览器把自动朗读挡住啦～点一下页面任意处，再点这句话旁边的小喇叭就能听到我 ✦');
    tip.appendChild(line);
    msgs.appendChild(tip);
    scrollEnd();
  }

  /* 逐段串行：一次只喂一句，onend 后再喂下一句，Chrome 不再吞队列
     2.1.28 手机端两段式重试：先按选中的中文音色念，2.4 秒还没出声就换系统默认发音重念一遍
     （很多安卓机/微信内置浏览器只认默认引擎，指定 voice 反而静默失败），两轮都没声才算失败 */
  function speakNext() {
    if (!voiceBox.on || !voiceSupported() || voiceIdx >= voiceQueue.length) {
      setSpeaking(false); keepAliveStop(); return;
    }
    var token = voiceToken;
    var item = voiceQueue[voiceIdx];
    var stage = 0;
    var started = false;

    function clearTimer() { if (startTimer) { clearTimeout(startTimer); startTimer = null; } }

    function attempt() {
      if (token !== voiceToken || !voiceBox.on) return;
      var useVoice = stage === 0 ? voice : null;
      var u = new SpeechSynthesisUtterance(item.text);
      if (useVoice) { try { u.voice = useVoice; } catch (er) {} u.lang = useVoice.lang || 'zh-CN'; }
      else u.lang = 'zh-CN';
      u.rate = item.rate; u.pitch = item.pitch; u.volume = 1;

      u.onstart = function () {
        if (token !== voiceToken) return;
        started = true;
        setSpeaking(true);
        clearTimer();
      };
      u.onend = function () {
        if (token !== voiceToken) return;
        clearTimer();
        voiceIdx++;
        setTimeout(function () { if (token === voiceToken) speakNext(); }, 45);
      };
      u.onerror = function (ev) {
        if (token !== voiceToken) return;
        clearTimer();
        var err = ev && ev.error ? ev.error : '';
        if (err === 'interrupted' || err === 'canceled') return;
        /* not-allowed = 自动播放策略拦截；这类错误不会触发 onstart，必须显式提示访客怎么解锁 */
        if (err === 'not-allowed') {
          setSpeaking(false); keepAliveStop();
          voiceQueue = []; voiceIdx = 0;
          if (!blockedNotified) { blockedNotified = true; voiceBlocked('autoplay'); }
          return;
        }
        /* 音色不认（synthesis-failed / audio-busy 等）：换默认发音再试一次 */
        if (stage === 0) {
          stage = 1;
          setTimeout(attempt, isTouch ? 320 : 180);
          return;
        }
        setSpeaking(false); keepAliveStop();
        voiceQueue = []; voiceIdx = 0;
        if (!blockedNotified) { blockedNotified = true; voiceBlocked('error'); }
      };

      try { if (synth.paused) synth.resume(); synth.speak(u); } catch (er) { setSpeaking(false); return; }

      clearTimer();
      startTimer = setTimeout(function () {
        if (token !== voiceToken || started) return;
        /* 一轮没出声：换默认发音再来 */
        if (stage === 0 && voice) {
          stage = 1;
          try { synth.cancel(); } catch (er) {}
          setTimeout(attempt, isTouch ? 320 : 180);
          return;
        }
        /* 两轮都没声：手机端不 cancel（慢机首句合成可能 4-6 秒，cancel 就彻底没声），只记录并按需提示 */
        root.setAttribute('data-voice-blocked', '2');
        stopSpeak();
        if (!blockedNotified) { blockedNotified = true; voiceBlocked(isTouch ? 'mobile' : 'timeout'); }
      }, isTouch ? 2400 : 1700);
    }

    attempt();
  }

  function speak(text, force) {
    if (!voiceSupported() || !voiceBox.on || (!voiceBox.auto && !force)) return;
    /* 手机端还没发生过任何触摸手势：先记下来，等第一次点击（解锁语音引擎）后再念 */
    if (isTouch && !userGestured && !force) { pendingSay = text; return; }
    var t = cleanText(text);
    if (!t) return;
    if (!voice) pickVoice();
    lastSpoken = text;
    if (voiceBox.style === 'yandere') t = yanderize(t);
    var st = V_STYLE[voiceBox.style] || V_STYLE.gentle;
    var baseRate = voiceBox.rate > 0 ? voiceBox.rate : st.rate;
    var basePitch = voiceBox.pitch > 0 ? voiceBox.pitch : st.pitch;
    var parts = splitText(t);
    if (!parts.length) return;
    var wasBusy = false;
    try { wasBusy = !!(synth.speaking || synth.pending); } catch (er) {}
    stopSpeak();                  /* 先停上一段：stopSpeak 会清空 voiceQueue，顺序不能颠倒 */
    voiceQueue = parts.map(function (p, i) {
      var emo = emotionCurve(i, parts.length, { rate: baseRate, pitch: basePitch });
      return { text: p, rate: emo.rate, pitch: emo.pitch };
    });
    voiceIdx = 0;
    var token = voiceToken;
    var launch = function () {
      if (token !== voiceToken || !voiceBox.on) return;
      if (!voice) pickVoice();
      keepAlive();
      speakNext();
    };
    /* cancel() 之后立刻 speak() 在安卓 Chrome / iOS 上常被静默丢弃，必须留间隔；
       之前只在「上一段还在念」时才等 180ms，空闲重播就直接被吞了 —— 这正是手机没声的主因 */
    setTimeout(launch, wasBusy ? 240 : (isTouch ? 280 : 130));
  }

  /* 首次用户手势预热语音引擎：Chrome/Edge 会静默拦截无手势的首次 speak()
     2.1.28 不再在 50ms 后 cancel 预热句 —— iOS 上 cancel 紧跟 speak 会把引擎卡死，
     之后整页再也发不出声（手机端「完全没语音」的另一个主因）。预热句用最短文本，自己就结束了 */
  function unlockVoice() {
    if (userGestured) return;
    userGestured = true;
    if (!voiceSupported()) return;          /* 浏览器压根没有语音合成：只记手势，别抛错 */
    try {
      synth.resume();
      var warm = new SpeechSynthesisUtterance('。');
      warm.lang = 'zh-CN'; warm.volume = 0; warm.rate = 2;
      synth.speak(warm);
      if (pendingSay) {
        var pd = pendingSay;
        pendingSay = '';
        /* 留够时间让预热句走完，再念真正的内容 */
        setTimeout(function () { speak(pd, true); }, 420);
      }
    } catch (er) {}
  }
  ['pointerdown', 'touchstart', 'keydown'].forEach(function (ev) {
    document.addEventListener(ev, unlockVoice, { once: true, passive: true, capture: true });
  });

  /* 浏览器不支持语音合成（部分微信/QQ 内置浏览器、老安卓机）：按钮置灰并说明原因，
     别再让访客对着按钮点了没反应 */
  if (!voiceSupported() && voiceBtn) {
    voiceBtn.classList.add('is-na');
    voiceBtn.setAttribute('title', '当前浏览器不支持朗读');
    voiceBtn.setAttribute('aria-disabled', 'true');
    voiceBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (blockedNotified) return;
      blockedNotified = true;
      voiceBlocked('mobile');
    });
  }

  function syncVoiceBtn() {
    if (!voiceBtn) return;
    voiceBtn.classList.toggle('is-on', voiceBox.on);
    voiceBtn.classList.toggle('is-off', !voiceBox.on);
    voiceBtn.setAttribute('title', styleLabel() + '语音：' + (voiceBox.on ? '开' : '关'));
    voiceBtn.setAttribute('aria-label', voiceBox.on ? '关闭语音' : '开启语音');
    voiceBtn.setAttribute('aria-pressed', voiceBox.on ? 'true' : 'false');
  }

  function applyStyle(s, save) {
    if (STYLE_KEYS.indexOf(s) < 0) s = 'gentle';
    voiceBox.style = s;
    blockedNotified = false;
    root.setAttribute('data-voice-style', s);
    root.classList.toggle('is-yandere', s === 'yandere');
    if (styleBtn) {
      var nm = styleBtn.querySelector('.fo-cp-style-name');
      if (nm) nm.textContent = STYLE_SHORT[s];
      styleBtn.setAttribute('title', '切换语音音色（当前：' + STYLE_LABEL[s] + '）');
      styleBtn.setAttribute('aria-label', '切换语音音色，当前' + STYLE_LABEL[s]);
      styleBtn.classList.toggle('is-y', s === 'yandere');
    }
    if (statusEl) { statusEl.textContent = STYLE_STATUS[s]; statusEl.setAttribute('title', STYLE_STATUS[s]); }
    syncVoiceBtn();
    if (save) { try { localStorage.setItem('moe_cp_vstyle', s); } catch (er) {} }
  }

  if (voiceSupported()) {
    pickVoice();
    try { synth.addEventListener('voiceschanged', pickVoice); } catch (er) { synth.onvoiceschanged = pickVoice; }
    /* 关掉页面前停止朗读，避免后台还在念 */
    window.addEventListener('pagehide', stopSpeak);
  } else {
    voiceBox.on = false;
    if (voiceBtn) voiceBtn.hidden = true;
    if (styleBtn) styleBtn.hidden = true;
  }
  /* 站点设置里关掉了语音：彻底隐藏小喇叭与音色按钮，不响应点击 */
  if (root.getAttribute('data-voice') === '0') {
    voiceBox.on = false;
    if (voiceBtn) voiceBtn.hidden = true;
    if (styleBtn) styleBtn.hidden = true;
  }
  /* 访客上次选的音色优先于后台默认值 */
  try {
    var sv = localStorage.getItem('moe_cp_vstyle');
    if (sv && STYLE_KEYS.indexOf(sv) >= 0) voiceBox.style = sv;
  } catch (er) {}
  applyStyle(voiceBox.style, false);
  syncVoiceBtn();

  if (styleBtn) {
    styleBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      var next = STYLE_KEYS[(STYLE_KEYS.indexOf(voiceBox.style) + 1) % STYLE_KEYS.length];
      applyStyle(next, true);
      /* 换音色当场念一句，既验证出声又让访客立刻听出差别 */
      speak(lastSpoken || greet, true);
    });
  }
  if (voiceBtn) {
    voiceBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (speaking) { stopSpeak(); return; }
      voiceBox.on = !voiceBox.on;
      try { localStorage.setItem('moe_cp_voice', voiceBox.on ? '1' : '0'); } catch (er) {}
      syncVoiceBtn();
      if (voiceBox.on) speak(lastSpoken || greet, true);
    });
    /* 记住上次的开关选择（站点设置未强制关闭时） */
    try {
      var saved = localStorage.getItem('moe_cp_voice');
      if (saved === '0' && root.getAttribute('data-voice') === '1') { voiceBox.on = false; syncVoiceBtn(); }
    } catch (er) {}
  }
  function scrollEnd() { msgs.scrollTop = msgs.scrollHeight; }

  /* 表情联动：她说到带（动作）或颜文字的话，立绘跟着跳一下 */
  function emote() {
    if (!figure) return;
    figure.classList.remove('is-emote');
    void figure.offsetWidth;
    figure.classList.add('is-emote');
    setTimeout(function () { figure.classList.remove('is-emote'); }, 1600);
  }
  var EMOTE_RE = /[（(][^（）()]{1,12}[）)]|[✧≧ᴗω☆♪ヽﾉε▼]/;

  function addMsg(text, who, links, opts) {    var div = document.createElement('div');
    div.className = 'fo-cp-msg ' + (who === 'me' ? 'is-me' : 'is-bot');
    if (who !== 'me') {
      var ava = document.createElement('span');
      ava.className = 'fo-cp-ava';
      ava.textContent = '✦';
      div.appendChild(ava);
    }
    var body = document.createElement('div');
    body.className = 'fo-cp-bubble';

    function appendLinks() {
      if (!links || !links.length) return;
      var box = document.createElement('div');
      box.className = 'fo-cp-links';
      links.forEach(function (l) {
        if (!l || !l.u) return;
        var a = document.createElement('a');
        a.href = l.u;
        a.textContent = l.t || l.u;
        a.rel = 'noopener';
        box.appendChild(a);
      });
      if (box.firstChild) body.appendChild(box);
    }

    /* 动作按钮：她可以带你去某个页面、回顶部——你点了才执行 */
    function appendActions() {
      var acts = opts && opts.actions;
      if (!acts || !acts.length) return;
      var box = document.createElement('div');
      box.className = 'fo-cp-acts';
      acts.slice(0, 2).forEach(function (a) {
        if (!a || !a.t) return;
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'fo-cp-act';
        b.textContent = '🪄 ' + (a.label || '执行');
        b.addEventListener('click', function (e) {
          e.stopPropagation();
          if (a.t === 'top') {
            window.scrollTo({ top: 0, behavior: 'smooth' });
          } else if (a.t === 'bottom') {
            window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' });
          } else if (a.u) {
            location.href = a.u;
          }
        });
        box.appendChild(b);
      });
      if (box.firstChild) body.appendChild(box);
    }

    div.appendChild(body);
    msgs.appendChild(div);
    /* 来源标签：让她知道这句是站内答的、AI 想出来的，还是刚从网上查的（放气泡里、链接后面） */
    var srcEl = null;
    if (who !== 'me' && opts && opts.src && opts.src !== 'local') {
      srcEl = document.createElement('span');
      srcEl.className = 'fo-cp-src is-' + opts.src;
      srcEl.textContent = opts.src === 'web' ? '🌐 联网查的' : '✦ AI 想的';
    }
    /* 每条回复旁挂一个「重听」小喇叭，悬停/移动端常显 */
    if (who !== 'me' && text) {
      var say = document.createElement('button');
      say.type = 'button';
      say.className = 'fo-cp-say';
      say.title = '重听这句话';
      say.setAttribute('aria-label', '重听这句话');
      say.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/><path d="M18.8 6a8 8 0 0 1 0 12" opacity=".55"/></svg>';
      say.addEventListener('click', function (e) { e.stopPropagation(); speak(text, true); });
      div.appendChild(say);
    }
    var finish = function () {
      appendLinks();
      appendActions();
      if (srcEl) body.appendChild(srcEl);
      scrollEnd();
      if (who !== 'me' && text) {
        if (!(opts && opts.nosave)) histSave(who, text);
        if (EMOTE_RE.test(text)) emote();
        if (!(opts && opts.quiet)) speak(text);
      } else if (who === 'me' && text && !(opts && opts.nosave)) {
        histSave(who, text);
      }
    };
    if (who === 'bot' && opts && opts.typer && text && text.length > 14) {
      typeText(body, text, finish);
    } else {
      if (text) body.appendChild(document.createTextNode(text));
      finish();
    }
    scrollEnd();
  }

  /* 打字机：模型回复通常一秒来一大段，逐字放出来更像在说话 */
  function typeText(el, text, done) {
    var i = 0;
    var step = Math.max(1, Math.ceil(text.length / 80));
    var timer = setInterval(function () {
      i += step;
      if (i >= text.length) {
        clearInterval(timer);
        el.textContent = text;
        scrollEnd();
        if (done) done();
        return;
      }
      el.textContent = text.slice(0, i);
      scrollEnd();
    }, 20);
  }

  function setChips(list) {
    if (!chipsBox) return;
    chipsBox.innerHTML = '';
    (list && list.length ? list : DEFAULT_CHIPS).forEach(function (c) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'fo-cp-chip';
      b.textContent = c[0];
      b.addEventListener('click', function () { send(c[1] || c[0]); });
      chipsBox.appendChild(b);
    });
  }

  /* 打字气泡：label 可随等待时间变化（想 → 翻资料 → 还在努力） */
  function typing(on, label) {
    var t = msgs.querySelector('.fo-cp-typing');
    if (on) {
      if (t) {
        var lb = t.querySelector('.fo-cp-think');
        if (lb && label) lb.textContent = label;
        return;
      }
      t = document.createElement('div');
      t.className = 'fo-cp-msg is-bot fo-cp-typing';
      t.innerHTML = '<span class="fo-cp-ava">✦</span><div class="fo-cp-bubble"><i></i><i></i><i></i></div>'
        + (label ? '<em class="fo-cp-think">' + label + '</em>' : '');
      msgs.appendChild(t);
      scrollEnd();
    } else if (t) {
      t.remove();
    }
  }

  /* 等待文案：大模型一般 2～10 秒，给点反馈免得像卡住 */
  var waitTimers = [];
  function startWait() {
    clearWait();
    waitTimers.push(setTimeout(function () { typing(true, '正在翻资料…'); }, 2600));
    waitTimers.push(setTimeout(function () { typing(true, '还在想，稍等一下…'); }, 11000));
  }
  function clearWait() {
    waitTimers.forEach(function (t) { clearTimeout(t); });
    waitTimers = [];
  }

  function send(q) {
    q = (q || '').trim();
    if (!q || busy) return;
    busy = true;
    stopSpeak(); /* 用户开口时，她先停下来听 */
    addMsg(q, 'me');
    setChips([]);
    typing(true, '正在想…');
    startWait();
    var fd = new FormData();
    fd.append('q', q);
    fd.append('title', document.title || '');
    fd.append('url', location.href || '');
    /* 页面上下文：服务端认哪个字段就用哪个，多余的字段会被忽略，不影响原有问答 */
    var ctx = pageContext();
    if (ctx) { fd.append('ctx', ctx); fd.append('page_text', ctx); }
    if (cid) fd.append('cid', cid);
    var headers = {};
    if (token) headers['X-CSRF-Token'] = token;
    fetch(api, { method: 'POST', body: fd, credentials: 'same-origin', headers: headers })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        clearWait();
        typing(false);
        if (d && d.ok) {
          addMsg(d.text || '…', 'bot', d.links, { src: d.src, typer: true, actions: d.actions });
          setChips(d.chips);
        } else {
          addMsg((d && d.msg) || '唔…线路好像飘走了，稍后再试试。', 'bot');
          setChips(pageChips());
        }
        busy = false;
        focusInput();
      })
      .catch(function () {
        clearWait();
        typing(false);
        addMsg('网络好像不太稳定，稍后再和我聊聊吧。', 'bot');
        setChips(pageChips());
        busy = false;
      });
  }

  function open() {
    root.classList.add('is-open', 'is-hint-off');
    if (!greeted) {
      greeted = true;
      var old = histLoad();
      if (old.length) {
        /* 上次的聊天还在：安静地回放，让她「记得」你们聊过什么 */
        old.forEach(function (m) { addMsg(m[1], m[0], null, { quiet: true, nosave: true }); });
        setChips(pageChips());
      } else {
        addMsg(greet, 'bot');
        setChips(pageChips());
      }
    }
    setTimeout(focusInput, 260);
  }
  function toggle() {
    if (root.classList.contains('is-open')) { root.classList.remove('is-open'); stopSpeak(); }
    else open();
  }

  figure.addEventListener('click', toggle);
  figure.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
  });
  /* 2.1.30 手机端的小按钮：点一下她才从角落里出来并打开聊天窗 */
  var miniBtn = root.querySelector('.fo-cp-mini');
  if (miniBtn) {
    miniBtn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      open();
    });
  }
  if (closeBtn) closeBtn.addEventListener('click', function () { root.classList.remove('is-open'); stopSpeak(); });

  /* 重新开始：清空界面 + 清掉服务端记忆，然后重新打招呼 */
  if (resetBtn) {
    resetBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      stopSpeak();
      clearWait();
      msgs.innerHTML = '';
      histClear();
      greeted = false;
      var fd = new FormData();
      fd.append('reset', '1');
      if (cid) fd.append('cid', cid);
      var headers = {};
      if (token) headers['X-CSRF-Token'] = token;
      fetch(api, { method: 'POST', body: fd, credentials: 'same-origin', headers: headers }).catch(function () {});
      setTimeout(function () {
        greeted = true;
        addMsg(greet, 'bot');
        setChips(pageChips());
        focusInput();
      }, 120);
    });
  }
  if (form) form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (!input) return;
    send(input.value);
    input.value = '';
  });
  /* Esc 关闭聊天窗（灯箱关闭优先级更高，仅在灯箱未开时生效） */
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && root.classList.contains('is-open') && !document.querySelector('.fo-lightbox.is-open')) {
      root.classList.remove('is-open');
    }
  });

  /* 主动互动：文章页读到接近底部时，她会冒出来提议带你回顶部（每个会话只提醒一次） */
  (function () {
    if (!document.querySelector('.fo-prose')) return; /* 只在文章页 */
    var fired = false;
    try { if (sessionStorage.getItem('moe_cp_read')) return; } catch (e) { return; }
    window.addEventListener('scroll', function () {
      if (fired) return;
      var max = document.documentElement.scrollHeight - window.innerHeight;
      if (max <= 200 || window.scrollY / max < 0.85) return;
      fired = true;
      try { sessionStorage.setItem('moe_cp_read', '1'); } catch (e) {}
      if (root.classList.contains('is-open')) return;
      var tip = document.createElement('div');
      tip.className = 'fo-cp-tip';
      tip.setAttribute('role', 'status');
      tip.innerHTML = '看完啦？我可以<span class="fo-cp-tip-btn" role="button" tabindex="0">带你回顶部</span>';
      var btn = tip.querySelector('.fo-cp-tip-btn');
      var go = function () { tip.remove(); window.scrollTo({ top: 0, behavior: 'smooth' }); };
      btn.addEventListener('click', function (e) { e.stopPropagation(); go(); });
      btn.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
      root.appendChild(tip);
      setTimeout(function () { if (tip.parentNode) tip.remove(); }, 15000);
    }, { passive: true });
  })();
  /* ===== 萌Z：男声 / 女声切换（人设与聊天台词不变，只换朗读音色） ===== */
  var genderBtn = root.querySelector('.fo-cp-gender');
  var gNow = root.getAttribute('data-voice-gender') === 'male' ? 'male' : 'female';
  voiceBox.gender = gNow;
  function syncGenderUI() {
    if (!genderBtn) return;
    genderBtn.textContent = gNow === 'male' ? '♂' : '♀';
    var lb = gNow === 'male' ? '男声' : '女声';
    genderBtn.setAttribute('title', '切换男声 / 女声（当前：' + lb + '）');
    genderBtn.setAttribute('aria-label', '切换男声女声（当前：' + lb + '）');
  }
  function setGender(g, broadcast) {
    gNow = g === 'male' ? 'male' : 'female';
    voiceBox.gender = gNow;
    root.setAttribute('data-voice-gender', gNow);
    root.setAttribute('data-voice-uri', '');
    syncGenderUI();
    if (voiceSupported()) pickVoice();
    if (broadcast !== false) {
      try { window.dispatchEvent(new CustomEvent('moez:gender', { detail: { gender: gNow } })); }
      catch (er) { /* 老浏览器没有 CustomEvent，忽略即可 */ }
    }
  }
  if (genderBtn) genderBtn.addEventListener('click', function () {
    setGender(gNow === 'male' ? 'female' : 'male');
  });
  window.addEventListener('moez:gender', function (e) {
    if (e && e.detail && e.detail.gender && e.detail.gender !== gNow) setGender(e.detail.gender, false);
  });
  syncGenderUI();

})();
