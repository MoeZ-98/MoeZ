/* ============================================================
 * 萌Z 版娘 · 后台「语音调试」面板（挂在所有后台页右下角）
 * 依赖：voice-core.js 的 window.MoeZVoice、plugin.php 注入的 window.MOEZ_CP_ADMIN
 * ============================================================ */
(function (w, d) {
  'use strict';
  if (d.getElementById('moez-vdbg')) return;
  var cfg = w.MOEZ_CP_ADMIN || {};
  var V = w.MoeZVoice;
  if (!V) return;

  var box = d.createElement('div');
  box.id = 'moez-vdbg';
  box.className = 'moez-vdbg';
  box.innerHTML =
    '<button type="button" class="moez-vdbg-toggle" title="语音调试（男声 / 女声）" aria-label="打开语音调试">🎙</button>' +
    '<section class="moez-vdbg-panel" aria-label="语音调试台" hidden>' +
    '  <header class="moez-vdbg-head"><b>🎙 语音调试 · 萌Z 版娘</b>' +
    '    <button type="button" class="moez-vdbg-x" aria-label="关闭">×</button></header>' +
    '  <div class="moez-vdbg-body">' +
    '    <p class="moez-vdbg-tip">浏览器内置语音合成，不调用任何外部接口。不同系统可用的男声 / 女声数量不一样，先点「试听」再保存。</p>' +
    '    <div class="moez-vdbg-row"><label>声音性别</label><div class="moez-vdbg-seg">' +
    '      <button type="button" data-g="female" class="is-on">♀ 女声</button>' +
    '      <button type="button" data-g="male">♂ 男声</button></div></div>' +
    '    <div class="moez-vdbg-row"><label for="moez-vdbg-voice">系统语音</label>' +
    '      <select id="moez-vdbg-voice"></select></div>' +
    '    <div class="moez-vdbg-row"><label for="moez-vdbg-style">音色预设</label>' +
    '      <select id="moez-vdbg-style">' +
    '        <option value="gentle">温柔御姐（放慢 · 压低）</option>' +
    '        <option value="sweet">清甜少女（略快 · 偏高）</option>' +
    '        <option value="natural">系统原声（不调整）</option>' +
    '        <option value="yandere">病娇（起伏 · 尾音上扬）</option>' +
    '      </select></div>' +
    '    <div class="moez-vdbg-row"><label for="moez-vdbg-rate">语速 <span id="moez-vdbg-rate-n">—</span></label>' +
    '      <input id="moez-vdbg-rate" type="range" min="0.5" max="2" step="0.02"></div>' +
    '    <div class="moez-vdbg-row"><label for="moez-vdbg-pitch">音调 <span id="moez-vdbg-pitch-n">—</span></label>' +
    '      <input id="moez-vdbg-pitch" type="range" min="0.3" max="2" step="0.02"></div>' +
    '    <div class="moez-vdbg-row"><label for="moez-vdbg-text">试听文本</label>' +
    '      <input id="moez-vdbg-text" type="text" maxlength="120" value="你好呀，我是萌Z的看板娘，今天也陪你逛站～"></div>' +
    '    <div class="moez-vdbg-btns">' +
    '      <button type="button" class="moez-vdbg-play">▶ 试听</button>' +
    '      <button type="button" class="moez-vdbg-stop">■ 停止</button>' +
    '      <button type="button" class="moez-vdbg-save">保存为站点默认</button></div>' +
    '    <div class="moez-vdbg-status" role="status">准备就绪</div>' +
    '    <details class="moez-vdbg-diag"><summary>引擎诊断 / 无声排查</summary><pre id="moez-vdbg-diag"></pre></details>' +
    '  </div></section>';
  d.body.appendChild(box);

  var $ = function (s) { return box.querySelector(s); };
  var toggle = $('.moez-vdbg-toggle'), panel = $('.moez-vdbg-panel');
  var gender = cfg.gender === 'male' ? 'male' : 'female';
  var voiceSel = $('#moez-vdbg-voice'), styleSel = $('#moez-vdbg-style');
  var rateEl = $('#moez-vdbg-rate'), pitchEl = $('#moez-vdbg-pitch');
  var textEl = $('#moez-vdbg-text'), statusEl = $('.moez-vdbg-status');
  var diagEl = $('#moez-vdbg-diag');

  function say(s) { statusEl.textContent = s; }
  function styleVal() { return V.STYLES[styleSel.value] || V.STYLES.gentle; }
  function syncNums() {
    $('#moez-vdbg-rate-n').textContent = rateEl.value;
    $('#moez-vdbg-pitch-n').textContent = pitchEl.value;
  }
  function applyStyleDefaults() {
    var st = styleVal();
    rateEl.value = cfg.rate !== '' && cfg.rate != null ? cfg.rate : st.rate;
    pitchEl.value = cfg.pitch !== '' && cfg.pitch != null ? cfg.pitch : st.pitch;
    syncNums();
  }

  /* 语音下拉：当前性别优先置顶，其余分组追加；用 DOM API 避免注入 */
  function fillVoices(items) {
    voiceSel.textContent = '';
    var auto = d.createElement('option');
    auto.value = ''; auto.textContent = '自动挑选（' + (gender === 'male' ? '男声' : '女声') + '优先）';
    voiceSel.appendChild(auto);
    var groups = [
      ['当前性别 · 中文', function (x) { return x.zh && x.gender === gender; }],
      ['当前性别 · 其它语言', function (x) { return !x.zh && x.gender === gender; }],
      ['未标注性别 · 中文', function (x) { return x.zh && x.gender === 'unknown'; }],
      ['全部语音', function () { return true; }]
    ];
    groups.forEach(function (g) {
      var arr = items.filter(g[1]);
      if (!arr.length) return;
      var og = d.createElement('optgroup'); og.label = g[0] + '（' + arr.length + '）';
      arr.forEach(function (x) {
        var op = d.createElement('option');
        op.value = x.uri;
        op.textContent = x.name + ' · ' + x.lang + (x.natural ? ' · 自然语音' : '');
        og.appendChild(op);
      });
      voiceSel.appendChild(og);
    });
    if (cfg.voiceUri) {
      voiceSel.value = cfg.voiceUri;
      if (voiceSel.selectedIndex < 0) voiceSel.value = '';
    }
  }

  function refreshDiag() {
    var g = V.diagnose();
    diagEl.textContent =
      '语音合成支持：' + (g.supported ? '是' : '否（当前浏览器不提供 speechSynthesis）') + '\n' +
      '系统语音总数：' + g.voices + '   中文：' + g.zh + '\n' +
      '识别为男声：' + g.male + '   女声：' + g.female + '\n' +
      '正在朗读：' + (g.speaking ? '是' : '否') + '   等待中：' + (g.pending ? '是' : '否') + '\n' +
      '安全上下文：' + (g.secure ? '是' : '否') + '\n' +
      'UA：' + g.ua + '\n\n' +
      '若「试听」无声音：① 先手动点一次页面任意位置（浏览器要求用户手势解锁）；' +
      '② Windows 需安装中文语音包；③ 微信 / 部分国产浏览器不提供语音引擎；' +
      '④ 若中文语音为 0，可换 Edge / Chrome 桌面版再试。';
  }

  /* 交互 */
  toggle.addEventListener('click', function () {
    panel.hidden = !panel.hidden;
    box.classList.toggle('is-open', !panel.hidden);
    if (!panel.hidden) { refreshDiag(); V.onReady(fillVoices); }
  });
  $('.moez-vdbg-x').addEventListener('click', function () {
    panel.hidden = true; box.classList.remove('is-open'); V.stop();
  });
  box.querySelectorAll('.moez-vdbg-seg button').forEach(function (b) {
    b.addEventListener('click', function () {
      gender = b.getAttribute('data-g') === 'male' ? 'male' : 'female';
      box.querySelectorAll('.moez-vdbg-seg button').forEach(function (x) { x.classList.toggle('is-on', x === b); });
      cfg.voiceUri = '';
      V.onReady(fillVoices);
      say('已切换为' + (gender === 'male' ? '男声' : '女声') + '，点「试听」听听看');
    });
  });
  styleSel.addEventListener('change', function () { cfg.rate = ''; cfg.pitch = ''; applyStyleDefaults(); });
  rateEl.addEventListener('input', syncNums);
  pitchEl.addEventListener('input', syncNums);

  $('.moez-vdbg-play').addEventListener('click', function () {
    var r = V.preview(textEl.value, {
      gender: gender, voiceUri: voiceSel.value, style: styleSel.value,
      rate: rateEl.value, pitch: pitchEl.value
    }, function (state, detail) {
      if (state === 'start') say('正在朗读… ' + (r && r.voice ? r.voice : '系统默认语音'));
      else if (state === 'end') say('朗读结束');
      else if (state === 'error') say('朗读失败：' + (detail || '未知错误') + '（见引擎诊断）');
      else if (state === 'unsupported') say('当前浏览器不支持语音合成');
      refreshDiag();
    });
    say(r ? '已发起朗读，若无声音请点一次页面后重试' : '无法发起朗读');
  });
  $('.moez-vdbg-stop').addEventListener('click', function () { V.stop(); say('已停止'); });

  $('.moez-vdbg-save').addEventListener('click', function () {
    if (!cfg.saveApi || !cfg.token) { say('未获取到保存接口，请刷新后台页面'); return; }
    var body = new URLSearchParams();
    body.set('gender', gender);
    body.set('style', styleSel.value);
    body.set('rate', rateEl.value);
    body.set('pitch', pitchEl.value);
    body.set('voice_uri', voiceSel.value);
    say('正在保存…');
    fetch(cfg.saveApi, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-TOKEN': cfg.token },
      body: body.toString(), credentials: 'same-origin'
    }).then(function (r) { return r.json(); }).then(function (j) {
      say(j && j.ok ? '✅ ' + (j.msg || '已保存') + '，前台刷新后生效' : '❌ ' + (j && j.msg || '保存失败'));
    }).catch(function (e) { say('❌ 保存失败：' + e); });
  });

  /* 初始化 */
  box.querySelectorAll('.moez-vdbg-seg button').forEach(function (b) {
    b.classList.toggle('is-on', b.getAttribute('data-g') === gender);
  });
  if (V.STYLES[cfg.style]) styleSel.value = cfg.style;
  applyStyleDefaults();
  V.onReady(fillVoices);
  if (/[?&]voice_debug=1/.test(w.location.search)) {
    panel.hidden = false; box.classList.add('is-open'); refreshDiag();
  }
})(window, document);
