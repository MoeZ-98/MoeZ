/* ============================================================
 * 萌Z 版娘 · 语音核心（前台 / 后台共用，无外部依赖、无网络请求）
 * 暴露 window.MoeZVoice：枚举系统语音、按男声 / 女声挑选、试听、诊断。
 * 浏览器内置 speechSynthesis，不调用任何第三方 TTS、不产生费用。
 * ============================================================ */
(function (w) {
  'use strict';

  var synth = w.speechSynthesis || null;
  var Utt   = w.SpeechSynthesisUtterance || null;

  /* 男声 / 女声特征词：覆盖 Edge Natural、Windows、Google、macOS 常见中文语音名 */
  var MALE = [
    'yunxi', '云希', 'yunjian', '云健', 'yunyang', '云扬', 'yunfeng', '云峰',
    'kangkang', '康康', 'liangliang', '亮亮', 'danny', 'male', '男声', '男'
  ];
  var FEMALE = [
    'xiaoxiao', '晓晓', 'xiaoyi', '晓伊', 'yaoyao', '瑶瑶', 'huihui', '慧慧',
    'tingting', '婷婷', 'meijia', '美佳', 'hanhan', '涵涵', 'xiaomeng', '晓梦',
    'female', '女声', '女'
  ];
  var STYLES = {
    gentle:  { label: '温柔御姐', short: '御姐', rate: 0.90, pitch: 0.80 },
    sweet:   { label: '清甜少女', short: '少女', rate: 1.02, pitch: 1.16 },
    natural: { label: '系统原声', short: '原声', rate: 1.00, pitch: 1.00 },
    yandere: { label: '病娇',     short: '病娇', rate: 1.06, pitch: 1.22 }
  };

  function supported() { return !!synth && typeof Utt === 'function'; }
  function all() { try { return (synth && synth.getVoices()) || []; } catch (e) { return []; } }
  function isZh(v) {
    return /^(zh|cmn|yue)/i.test(v.lang || '') ||
           /中文|普通话|普通話|國語|国语|Chinese/i.test(v.name || '');
  }
  function has(n, words) {
    n = String(n || '').toLowerCase();
    for (var i = 0; i < words.length; i++) if (n.indexOf(String(words[i]).toLowerCase()) >= 0) return true;
    return false;
  }
  function genderOf(v) {
    var n = v.name || '';
    if (has(n, MALE)) return 'male';
    if (has(n, FEMALE)) return 'female';
    return 'unknown';
  }
  function natural(v) { return /natural|neural|online|premium|enhanced/i.test(v.name || ''); }
  function clamp(n, lo, hi, dft) {
    n = parseFloat(n);
    if (!isFinite(n)) return dft;
    return Math.min(hi, Math.max(lo, n));
  }

  /** 结构化列出系统语音 */
  function list() {
    return all().map(function (v, i) {
      return {
        index: i, name: v.name || '(未命名)', lang: v.lang || '',
        uri: v.voiceURI || v.name || '', gender: genderOf(v), zh: isZh(v),
        natural: natural(v), local: !!v.localService, raw: v
      };
    });
  }

  function score(item, gender) {
    var s = 0, n = String(item.name || '').toLowerCase();
    if (item.zh) s += 40; else s -= 30;
    if (item.natural) s += 20;
    if (item.gender === gender) s += 60;
    else if (item.gender !== 'unknown') s -= 25;
    var rank = gender === 'male' ? MALE : FEMALE;
    for (var i = 0; i < rank.length; i++) {
      if (n.indexOf(String(rank[i]).toLowerCase()) >= 0) { s += 30 - i * 2; break; }
    }
    return s;
  }

  /** 挑选语音：优先精确匹配 voiceURI，其次按性别 + 中文 + 自然度打分 */
  function pick(gender, preferUri) {
    var items = list();
    if (!items.length) return null;
    if (preferUri) {
      for (var i = 0; i < items.length; i++) {
        if (items[i].uri === preferUri || items[i].name === preferUri) return items[i].raw;
      }
    }
    var zh = items.filter(function (x) { return x.zh; });
    if (!zh.length) zh = items;
    var best = null, bs = -1e9;
    zh.forEach(function (x) { var s = score(x, gender); if (s > bs) { bs = s; best = x; } });
    return best ? best.raw : null;
  }

  var keepTimer = null;
  function stop() {
    if (keepTimer) { clearInterval(keepTimer); keepTimer = null; }
    if (synth) { try { synth.cancel(); } catch (e) {} }
  }

  /** 试听：返回 {voice, uri, gender}；状态通过 cb(state, detail) 回传 */
  function preview(text, opts, cb) {
    cb = cb || function () {};
    if (!supported()) { cb('unsupported'); return null; }
    stop();
    var o = opts || {};
    var style = STYLES[o.style] || STYLES.gentle;
    var rate  = clamp(o.rate, 0.5, 2, style.rate);
    var pitch = clamp(o.pitch, 0.3, 2, style.pitch);
    var v = pick(o.gender || 'female', o.voiceUri || '');
    var u = new Utt(String(text || '你好，我是萌Z的看板娘，这是一段语音试听。').slice(0, 160));
    if (v) { u.voice = v; if (v.lang) u.lang = v.lang; }
    u.rate = rate; u.pitch = pitch; u.volume = 1;
    u.onstart = function () { cb('start'); };
    u.onend   = function () { if (keepTimer) { clearInterval(keepTimer); keepTimer = null; } cb('end'); };
    u.onerror = function (ev) { if (keepTimer) { clearInterval(keepTimer); keepTimer = null; } cb('error', ev && ev.error); };
    /* Chrome 约 15 秒截断长朗读；桌面端用 pause/resume 保活，移动端跳过（iOS 会整段静音） */
    var touch = ('ontouchstart' in w) || (navigator.maxTouchPoints > 0);
    if (!touch) {
      keepTimer = setInterval(function () {
        if (!synth.speaking) { clearInterval(keepTimer); keepTimer = null; return; }
        try { synth.pause(); synth.resume(); } catch (e) {}
      }, 8000);
    }
    try { synth.speak(u); } catch (e) { cb('error', e && e.message); return null; }
    return {
      voice: v ? v.name : '', uri: v ? (v.voiceURI || '') : '',
      gender: v ? genderOf(v) : 'unknown', rate: rate, pitch: pitch
    };
  }

  /** 环境诊断：排查「为什么没声音」 */
  function diagnose() {
    var items = list();
    return {
      supported: supported(),
      secure: !!(w.isSecureContext),
      voices: items.length,
      zh: items.filter(function (x) { return x.zh; }).length,
      male: items.filter(function (x) { return x.gender === 'male'; }).length,
      female: items.filter(function (x) { return x.gender === 'female'; }).length,
      speaking: !!(synth && synth.speaking),
      pending: !!(synth && synth.pending),
      ua: (navigator.userAgent || '').slice(0, 120)
    };
  }

  /** 语音列表首次为空时（Android Chrome / 微信常见）轮询重试 */
  function onReady(cb) {
    var tries = 0;
    var check = function () {
      if (all().length) { cb(list()); return; }
      if (tries++ < 10) setTimeout(check, 350);
      else cb([]);
    };
    if (synth) { try { synth.addEventListener('voiceschanged', check); } catch (e) { synth.onvoiceschanged = check; } }
    check();
  }

  w.MoeZVoice = {
    supported: supported, list: list, pick: pick, preview: preview,
    stop: stop, diagnose: diagnose, onReady: onReady,
    genderOf: genderOf, STYLES: STYLES,
    maleWords: MALE, femaleWords: FEMALE
  };
})(window);
