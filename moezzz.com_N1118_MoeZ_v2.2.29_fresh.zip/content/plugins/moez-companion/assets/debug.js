/* ============================================================
 * 萌Z 版娘 · 前台语音调试浮层
 * 入口：聊天窗底部「🎙 语音调试」，或网址带 ?voice_debug=1 自动展开
 * 依赖：voice-core.js；性别切换通过 moez:gender 事件同步给 companion.js
 * ============================================================ */
(function (w, d) {
  'use strict';
  var V = w.MoeZVoice, cfg = w.MOEZ_CP_CFG || {};
  if (!V || d.getElementById('moez-cp-dbg')) return;
  var root = d.getElementById('moez-companion');
  if (!root) return;

  var box = d.createElement('div');
  box.id = 'moez-cp-dbg';
  box.className = 'moez-cp-dbg';
  box.innerHTML =
    '<header class="moez-cp-dbg-head"><b>🎙 语音调试</b>' +
    '  <button type="button" class="moez-cp-dbg-x" aria-label="关闭">×</button></header>' +
    '<div class="moez-cp-dbg-body">' +
    '  <div class="moez-vdbg-row"><label>声音性别</label><div class="moez-vdbg-seg">' +
    '    <button type="button" data-g="female">♀ 女声</button>' +
    '    <button type="button" data-g="male">♂ 男声</button></div></div>' +
    '  <div class="moez-vdbg-row"><label for="moez-cp-dbg-voice">系统语音</label>' +
    '    <select id="moez-cp-dbg-voice"></select></div>' +
    '  <div class="moez-vdbg-row"><label for="moez-cp-dbg-rate">语速 <span id="moez-cp-dbg-rate-n">—</span></label>' +
    '    <input id="moez-cp-dbg-rate" type="range" min="0.5" max="2" step="0.02" value="1"></div>' +
    '  <div class="moez-vdbg-row"><label for="moez-cp-dbg-pitch">音调 <span id="moez-cp-dbg-pitch-n">—</span></label>' +
    '    <input id="moez-cp-dbg-pitch" type="range" min="0.3" max="2" step="0.02" value="1"></div>' +
    '  <div class="moez-vdbg-row"><label for="moez-cp-dbg-text">试听文本</label>' +
    '    <input id="moez-cp-dbg-text" type="text" maxlength="120" value="你好呀，今天想看点什么？我可以帮你找文章～"></div>' +
    '  <div class="moez-vdbg-btns">' +
    '    <button type="button" class="moez-vdbg-play">▶ 试听</button>' +
    '    <button type="button" class="moez-vdbg-stop">■ 停止</button>' +
    (cfg.admin ? '    <button type="button" class="moez-vdbg-save">保存为站点默认</button>' : '') +
    '  </div>' +
    '  <div class="moez-vdbg-status" role="status">准备就绪</div>' +
    '  <details class="moez-vdbg-diag"><summary>引擎诊断 / 无声排查</summary><pre></pre></details>' +
    '</div>';
  d.body.appendChild(box);

  var $ = function (s) { return box.querySelector(s); };
  var gender = root.getAttribute('data-voice-gender') === 'male' ? 'male' : 'female';
  var voiceSel = $('#moez-cp-dbg-voice'), rateEl = $('#moez-cp-dbg-rate'), pitchEl = $('#moez-cp-dbg-pitch');
  var textEl = $('#moez-cp-dbg-text'), statusEl = $('.moez-vdbg-status'), diagEl = $('.moez-vdbg-diag pre');
  var st = V.STYLES[root.getAttribute('data-voice-style')] || V.STYLES.gentle;
  rateEl.value = root.getAttribute('data-voice-rate') || st.rate;
  pitchEl.value = root.getAttribute('data-voice-pitch') || st.pitch;

  function say(s) { statusEl.textContent = s; }
  function nums() {
    $('#moez-cp-dbg-rate-n').textContent = rateEl.value;
    $('#moez-cp-dbg-pitch-n').textContent = pitchEl.value;
  }
  function fill(items) {
    voiceSel.textContent = '';
    var auto = d.createElement('option');
    auto.value = ''; auto.textContent = '自动挑选（' + (gender === 'male' ? '男声' : '女声') + '优先）';
    voiceSel.appendChild(auto);
    var arr = items.slice().sort(function (a, b) {
      var s = function (x) { return (x.zh ? 4 : 0) + (x.gender === gender ? 2 : 0) + (x.natural ? 1 : 0); };
      return s(b) - s(a);
    });
    arr.forEach(function (x) {
      var op = d.createElement('option');
      op.value = x.uri;
      op.textContent = x.name + ' · ' + x.lang + (x.gender === 'male' ? ' · 男声' : x.gender === 'female' ? ' · 女声' : '');
      voiceSel.appendChild(op);
    });
    var uri = root.getAttribute('data-voice-uri') || '';
    if (uri) { voiceSel.value = uri; if (voiceSel.selectedIndex < 0) voiceSel.value = ''; }
  }
  function diag() {
    var g = V.diagnose();
    diagEl.textContent =
      '语音合成：' + (g.supported ? '支持' : '不支持') + '   共 ' + g.voices + ' 个语音（中文 ' + g.zh + '）\n' +
      '男声 ' + g.male + ' / 女声 ' + g.female + '\nUA：' + g.ua + '\n\n' +
      '没声音时：先点一下页面（浏览器要求手势解锁），再试听；微信 / 部分国产浏览器无语音引擎；' +
      'Windows 需安装中文语音包；中文语音为 0 时换 Edge / Chrome 桌面版。';
  }
  function setGender(g, notify) {
    gender = g === 'male' ? 'male' : 'female';
    box.querySelectorAll('.moez-vdbg-seg button').forEach(function (b) {
      b.classList.toggle('is-on', b.getAttribute('data-g') === gender);
    });
    root.setAttribute('data-voice-gender', gender);
    root.setAttribute('data-voice-uri', '');
    voiceSel.value = '';
    var gb = root.querySelector('.fo-cp-gender');
    if (gb) { gb.textContent = gender === 'male' ? '♂' : '♀'; gb.title = '切换男声 / 女声（当前：' + (gender === 'male' ? '男声' : '女声') + '）'; }
    if (notify !== false) {
      try { w.dispatchEvent(new CustomEvent('moez:gender', { detail: { gender: gender } })); } catch (e) {}
    }
    say('已切到' + (gender === 'male' ? '男声' : '女声') + '，点「试听」听听看');
  }

  /* 入口按钮与关闭 */
  var link = root.querySelector('.moez-cp-debug-link');
  var open = function () { box.classList.add('is-open'); V.onReady(fill); diag(); };
  var close = function () { box.classList.remove('is-open'); V.stop(); };
  if (link) link.addEventListener('click', function (e) { e.preventDefault(); box.classList.contains('is-open') ? close() : open(); });
  $('.moez-cp-dbg-x').addEventListener('click', close);
  box.querySelectorAll('.moez-vdbg-seg button').forEach(function (b) {
    b.addEventListener('click', function () { setGender(b.getAttribute('data-g')); });
  });
  rateEl.addEventListener('input', nums);
  pitchEl.addEventListener('input', nums);
  $('.moez-vdbg-play').addEventListener('click', function () {
    var r = V.preview(textEl.value, {
      gender: gender, voiceUri: voiceSel.value, style: root.getAttribute('data-voice-style') || 'gentle',
      rate: rateEl.value, pitch: pitchEl.value
    }, function (s, det) {
      if (s === 'start') say('正在朗读… ' + (r && r.voice ? r.voice : '系统默认'));
      else if (s === 'end') say('朗读结束');
      else if (s === 'error') say('朗读失败：' + (det || '未知错误'));
      else if (s === 'unsupported') say('当前浏览器不支持语音合成');
      diag();
    });
    say(r ? '已发起朗读' : '无法发起朗读');
  });
  $('.moez-vdbg-stop').addEventListener('click', function () { V.stop(); say('已停止'); });

  var saveBtn = $('.moez-vdbg-save');
  if (saveBtn) saveBtn.addEventListener('click', function () {
    if (!cfg.saveApi || !cfg.token) { say('未获取到保存接口'); return; }
    var body = new URLSearchParams();
    body.set('gender', gender);
    body.set('style', root.getAttribute('data-voice-style') || 'gentle');
    body.set('rate', rateEl.value); body.set('pitch', pitchEl.value);
    body.set('voice_uri', voiceSel.value);
    fetch(cfg.saveApi, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-CSRF-TOKEN': cfg.token },
      body: body.toString()
    }).then(function (r) { return r.json(); }).then(function (j) {
      say(j && j.ok ? '✅ 已保存为站点默认' : '❌ ' + (j && j.msg || '保存失败'));
    }).catch(function (e) { say('❌ 保存失败：' + e); });
  });

  /* 与 companion.js 的性别按钮双向同步 */
  w.addEventListener('moez:gender', function (e) {
    if (e.detail && e.detail.gender) setGender(e.detail.gender, false);
  });
  setGender(gender, false);
  nums();
  if (/[?&]voice_debug=1/.test(w.location.search)) open();
})(window, document);
