<?php
/**
 * Plugin Name: 🎙 萌Z 版娘 · 男女语音
 * Version:     1.0.0
 * Author:      萌Z MoeZ
 * Description: 看板娘独立插件：全主题通用、可启用停用，支持男声 / 女声切换与前后台语音调试。
 *
 * 目录说明
 *   plugin.php          入口：设置读取、资产代理、保存 API、钩子注册
 *   front.php           前台 DOM 渲染（从 templates/fomalhaut/footer.php 迁出）
 *   assets/companion.css / companion.js   版娘样式与聊天逻辑（从 fomalhaut 主题迁出）
 *   assets/voice-core.js                 前后台共用的语音枚举 / 选声 / 试听核心
 *   assets/debug.js                      前台语音调试浮层
 *   assets/admin.js / admin.css          后台「语音调试」面板
 *
 * 兼容设计
 *   - 首次部署自动启用（marker 幂等）；站长在「插件管理」停用后不再自动打开。
 *   - 启用后本插件改用 id="moez-companion"，主题的 app.js 找不到 #fo-companion 会直接 return，
 *     因此不会出现两套版娘；7 套主题都通过 front_head / front_footer 钩子获得版娘。
 *   - 设置优先级：后台语音调试台（moez_cp_*）→ 当前主题「版娘与语音」设置
 *     → fomalhaut 历史设置（themeopt_fomalhaut_*）→ 默认值，迁移前配置不丢。
 *   - 所有资产走 ?moez_cp_asset= 代理，不依赖 Web 服务器是否放行 content/ 目录。
 */
if (!defined('MOE_ROOT')) { http_response_code(403); exit('forbidden'); }

define('MOEZ_CP_VER', '1.0.0');
require_once __DIR__ . '/front.php';

/* 这两个入口必须在页面路由渲染之前拦截（init.php 末尾会加载本文件） */
if (isset($_GET['moez_cp_asset'])) { moez_cp_asset(); exit; }
if (isset($_GET['moez_cp_api']))   { moez_cp_api();   exit; }

function moez_cp_base()
{
    return function_exists('base_url') ? base_url() : '/';
}
function moez_cp_q($query)
{
    return moez_cp_base() . $query;
}

/** 插件是否已在「插件管理」启用（不看显示开关）：主题据此让出自带版娘。
 *  这样即使站长在主题设置里关掉版娘，fomalhaut 也不会又冒出一套旧的。 */
function moez_cp_plugin_installed()
{
    if (!function_exists('moe_plugins_enabled')) return false;
    return in_array('moez-companion', (array)moe_plugins_enabled(), true);
}

/** 是否真的输出版娘：插件已启用 + 显示开关打开 */
function moez_cp_plugin_active()
{
    return moez_cp_plugin_installed() && moez_cp_on('enabled', true);
}

/** 设置读取：插件设置优先 → 旧 fomalhaut 主题设置 → 默认值
 *  插件内部用短键（name / style …），主题里是长键（mascot_name / voice_style …），
 *  通过 $alias 映射，保证迁移前在「模板设置」里配好的看板娘不会丢。 */
function moez_cp_opt($key, $default = '')
{
    if (!function_exists('setting')) return $default;
    $v = setting('moez_cp_' . $key, null);
    if ($v === null || $v === '') {
        $alias = array(
            'enabled' => 'show_mascot',
            'scope'   => 'mascot_scope',
            'name'    => 'mascot_name',
            'img'     => 'mascot_img',
            'height'  => 'mascot_height',
            'side'    => 'mascot_side',
            'greet'   => 'mascot_greet',
            'hint'    => 'mascot_hint',
            'style'   => 'voice_style',
            'rate'    => 'voice_rate',
            'pitch'   => 'voice_pitch',
        );
        $oldKey = isset($alias[$key]) ? $alias[$key] : $key;
        // 7 套主题的 info.php 都声明了「版娘与语音」设置：当前激活主题优先
        $cur = function_exists('theme') ? basename((string)theme()) : '';
        if ($cur !== '' && $cur !== 'fomalhaut') {
            $tv = setting('themeopt_' . $cur . '_' . $oldKey, null);
            if ($tv !== null && $tv !== '') $v = $tv;
        }
        // 再回落 fomalhaut 的历史设置（迁移前在「模板设置」里配好的值不丢）
        if ($v === null || $v === '') {
            $old = setting('themeopt_fomalhaut_' . $oldKey, null);
            if ($old !== null && $old !== '') $v = $old;
        }
    }
    if ($v === null || $v === '') $v = $default;
    return is_string($v) ? $v : (string)$v;
}
function moez_cp_on($key, $default = true)
{
    $v = strtolower(trim((string)moez_cp_opt($key, $default ? '1' : '0')));
    return !in_array($v, array('0', 'false', 'off', 'no', ''), true);
}

/** 是否首页（scope=home 时用；兼容子目录安装） */
function moez_cp_is_home()
{
    $base = parse_url(moez_cp_base(), PHP_URL_PATH);
    if (!$base) $base = '/';
    $path = parse_url(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH);
    if (!$path) $path = '/';
    if (strpos($path, $base) === 0) $path = substr($path, strlen($base));
    $path = trim($path, '/');
    return $path === '' || $path === 'index.php';
}

/* ============================================================
   一、资产代理（白名单，防路径穿越）
   ============================================================ */
function moez_cp_asset()
{
    $map = array(
        'companion.css' => array('text/css; charset=utf-8',              __DIR__ . '/assets/companion.css'),
        'companion.js'  => array('application/javascript; charset=utf-8', __DIR__ . '/assets/companion.js'),
        'voice-core.js' => array('application/javascript; charset=utf-8', __DIR__ . '/assets/voice-core.js'),
        'debug.js'      => array('application/javascript; charset=utf-8', __DIR__ . '/assets/debug.js'),
        'admin.js'      => array('application/javascript; charset=utf-8', __DIR__ . '/assets/admin.js'),
        'admin.css'     => array('text/css; charset=utf-8',              __DIR__ . '/assets/admin.css'),
        'companion.png' => array('image/png',                             __DIR__ . '/assets/companion.png'),
    );
    $k = isset($_GET['moez_cp_asset']) ? (string)$_GET['moez_cp_asset'] : '';
    if (!isset($map[$k]) || !is_file($map[$k][1])) { http_response_code(404); exit('not found'); }
    header('Content-Type: ' . $map[$k][0]);
    header('Cache-Control: public, max-age=3600');
    header('X-Content-Type-Options: nosniff');
    readfile($map[$k][1]);
    exit;
}

/* ============================================================
   二、保存站点默认语音（仅站长 + CSRF，返回 JSON）
   ============================================================ */
function moez_cp_api()
{
    header('Content-Type: application/json; charset=utf-8');
    $fail = function ($msg, $code = 403) {
        http_response_code($code);
        echo json_encode(array('ok' => 0, 'msg' => $msg), JSON_UNESCAPED_UNICODE);
        exit;
    };
    if (!function_exists('is_admin') || !is_admin()) $fail('请先登录后台');
    if (function_exists('moe_is_owner') && !moe_is_owner()) $fail('仅站长可修改站点默认语音');
    $sess = isset($_SESSION['moe_csrf']) ? (string)$_SESSION['moe_csrf'] : '';
    $tok  = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? (string)$_SERVER['HTTP_X_CSRF_TOKEN'] : '';
    if ($sess === '' || $tok === '' || !hash_equals($sess, $tok)) $fail('令牌校验失败，请刷新页面重试');
    if ((string)$_GET['moez_cp_api'] !== 'save') $fail('未知操作', 400);

    $ok = array('gender' => array('female', 'male'),
                'style'  => array('gentle', 'sweet', 'natural', 'yandere'),
                'debug_front' => array('0', '1'));
    foreach (array('gender', 'style', 'rate', 'pitch', 'voice_uri', 'debug_front') as $k) {
        if (!isset($_POST[$k])) continue;
        $v = trim((string)$_POST[$k]);
        if (isset($ok[$k]) && !in_array($v, $ok[$k], true)) continue;
        if (($k === 'rate' || $k === 'pitch') && $v !== '') {
            if (!is_numeric($v) || (float)$v < 0.3 || (float)$v > 2) continue;
        }
        if ($k === 'voice_uri') $v = substr($v, 0, 200);
        setting_set('moez_cp_' . $k, $v);
    }
    echo json_encode(array('ok' => 1, 'msg' => '语音设置已保存'), JSON_UNESCAPED_UNICODE);
    exit;
}

/* ============================================================
   三、前台钩子
   ============================================================ */
function moez_cp_front_head()
{
    if (!moez_cp_plugin_active()) return '';
    $v = MOEZ_CP_VER;
    $cfg = array(
        'gender'   => moez_cp_opt('gender', 'female'),
        'style'    => moez_cp_opt('style', 'gentle'),
        'rate'     => moez_cp_opt('rate', ''),
        'pitch'    => moez_cp_opt('pitch', ''),
        'voiceUri' => moez_cp_opt('voice_uri', ''),
        'debug'    => moez_cp_on('debug_front', true) ? 1 : 0,
        'admin'    => (function_exists('is_admin') && is_admin()) ? 1 : 0,
        'saveApi'  => moez_cp_q('?moez_cp_api=save'),
        'token'    => function_exists('csrf_token') ? csrf_token() : '',
        'brand'    => '萌Z MoeZ',
    );
    $esc = function_exists('e') ? 'e' : 'htmlspecialchars';
    $json = json_encode($cfg, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $out  = "\n<!-- 萌Z 版娘插件 v" . $v . " -->\n";
    foreach (array('companion.css', 'admin.css') as $f) {
        $out .= '<link rel="stylesheet" href="' . $esc(moez_cp_q('?moez_cp_asset=' . $f . '&v=' . $v)) . '">' . "\n";
    }
    $out .= '<script>window.MOEZ_CP_CFG=' . $json . ';</script>' . "\n";
    foreach (array('voice-core.js', 'companion.js', 'debug.js') as $f) {
        $out .= '<script defer src="' . $esc(moez_cp_q('?moez_cp_asset=' . $f . '&v=' . $v)) . '"></script>' . "\n";
    }
    return $out;
}

function moez_cp_front_footer()
{
    if (!moez_cp_plugin_active()) return '';
    if (!moez_cp_on('enabled', true)) return '';
    if (moez_cp_opt('scope', 'all') === 'home' && !moez_cp_is_home()) return '';
    return moez_cp_render_dom();
}

/* ============================================================
   四、后台钩子：菜单 / 仪表盘卡片 / 全后台可用的调试面板
   ============================================================ */
function moez_cp_admin_menu($menu)
{
    if (!is_array($menu)) return $menu;
    if (function_exists('moe_is_owner') && !moe_is_owner()) return $menu;
    $menu['moez_voice'] = array('🎙', '语音调试', 'settings.php?voice_debug=1');
    return $menu;
}

function moez_cp_admin_dashboard()
{
    return '<div class="card" style="margin-bottom:20px">'
         . '<h2 class="card-title">🎙 萌Z 版娘 · 语音调试</h2>'
         . '<p class="hint" style="margin:0 0 10px">版娘已抽成独立插件并默认启用，可在「插件管理」停用；'
         . '每套主题的「模板设置 → 版娘与语音」也能单独调。这里可试听男声 / 女声、调速调音调，'
         . '并把结果保存为站点默认（优先级高于主题设置）。</p>'
         . '<a class="btn" href="settings.php?voice_debug=1">打开语音调试台</a>'
         . '</div>';
}

function moez_cp_admin_footer()
{
    if (function_exists('moe_is_owner') && !moe_is_owner()) return '';
    $v = MOEZ_CP_VER;
    $esc = function_exists('e') ? 'e' : 'htmlspecialchars';
    $save = moez_cp_q('?moez_cp_api=save');
    $token = function_exists('csrf_token') ? csrf_token() : '';
    $cfg = json_encode(array(
        'gender' => moez_cp_opt('gender', 'female'),
        'style'  => moez_cp_opt('style', 'gentle'),
        'rate'   => moez_cp_opt('rate', ''),
        'pitch'  => moez_cp_opt('pitch', ''),
        'voiceUri' => moez_cp_opt('voice_uri', ''),
        'saveApi' => $save,
        'token'  => $token,
    ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    return "\n" . '<link rel="stylesheet" href="' . $esc(moez_cp_q('?moez_cp_asset=admin.css&v=' . $v)) . '">' . "\n"
         . '<script>window.MOEZ_CP_ADMIN=' . $cfg . ';</script>' . "\n"
         . '<script src="' . $esc(moez_cp_q('?moez_cp_asset=voice-core.js&v=' . $v)) . '"></script>' . "\n"
         . '<script src="' . $esc(moez_cp_q('?moez_cp_asset=admin.js&v=' . $v)) . '"></script>' . "\n";
}

/* ============================================================
   五、注册（函数名统一加 moez_ 前缀，避免与其它插件冲突）
   ============================================================ */
moe_plugin_register('front_head',      'moez_cp_front_head');
moe_plugin_register('front_footer',    'moez_cp_front_footer');
moe_plugin_register('admin_menu',      'moez_cp_admin_menu');
moe_plugin_register('admin_dashboard', 'moez_cp_admin_dashboard');
moe_plugin_register('admin_footer',    'moez_cp_admin_footer');
