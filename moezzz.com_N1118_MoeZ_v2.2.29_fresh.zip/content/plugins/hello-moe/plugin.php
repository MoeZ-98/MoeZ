<?php
/**
 * Plugin Name: 🌸 示例插件
 * Version:     1.0.0
 * Author:      萌Z MoeZ
 * Description: 演示插件钩子的最小示例
 *
 * 本文件只有启用后才会被 include。可以注册任意钩子，
 * 也可以在这里定义自己的函数 / 类（注意避免与其它插件重名）。
 */

moe_plugin_register('front_footer', function () {
    return '<div style="text-align:center;padding:14px;font-size:12px;opacity:.7">🌸 来自「示例插件」的问候 · MoeZ v' . MOE_VERSION . '</div>';
});

moe_plugin_register('admin_dashboard', function () {
    return '<div class="card" style="margin-bottom:20px"><h2 class="card-title">🌸 示例插件已生效</h2>'
         . '<p class="hint" style="margin:0">这段内容由插件钩子 <code>admin_dashboard</code> 输出。'
         . '停用「示例插件」后它会自动消失，说明插件确实在运行。</p></div>';
});
