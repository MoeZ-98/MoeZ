<?php
/**
 * 🎬 视频扩展 · 弹幕 / 播放器配置 API
 * 入口：?plugin=video&video_api=1&ac=video|dm|get|report|list
 *
 * 弹幕存储：优先用 CMS 数据库连接；否则落到插件自带 JSON 文件（data/ 目录），
 * 不依赖任何外部服务，单机即可运行。
 */
if (!defined('MOE_ROOT')) { http_response_code(403); exit('forbidden'); }
require_once __DIR__ . '/video-funcs.php';

function video_api_run()
{
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

    $ac = isset($_REQUEST['ac']) ? strtolower((string)$_REQUEST['ac']) : 'video';
    if (!in_array($ac, array('video', 'dm', 'get', 'report', 'list', 'hb'), true)) {
        video_api_fail('未知操作：' . $ac, 404);
    }
    if (!video_enabled()) {
        video_api_fail('视频功能未开启（请在后台「视频扩展 → 基础设置」开启）', 403);
    }
    if (!video_rate_limit('api_' . $ac, 60, 60)) {
        video_api_fail('请求过于频繁，请稍后再试', 429);
    }
    switch ($ac) {
        case 'video': video_api_video(); break;
        case 'dm':    video_api_dm(); break;
        case 'get':   video_api_dm(true); break;
        case 'report':video_api_report(); break;
        case 'list':  video_api_list(); break;
        case 'hb':    video_api_hb(); break;
    }
}

/* ---------------- 播放器前端配置 ---------------- */
function video_api_video()
{
    $id = isset($_REQUEST['id']) ? (int)$_REQUEST['id'] : 0;
    $slug = isset($_REQUEST['slug']) ? trim((string)$_REQUEST['slug']) : '';
    $url = isset($_REQUEST['url']) ? trim((string)$_REQUEST['url']) : '';
    if ($url === '' && isset($_REQUEST['v'])) { $d = base64_decode((string)$_REQUEST['v'], true); if ($d !== false) $url = trim($d); }

    $post = null;
    if ($id > 0 || $slug !== '') $post = video_get_post($id, $slug);

    $routes = array();
    $access = 'free';
    $trial = 0;
    $cover = '';
    $title = '视频播放';
    $dmId = '';
    if ($post) {
        $meta = isset($post['meta']) ? $post['meta'] : array();
        $routes = isset($meta['routes']) ? $meta['routes'] : array();
        $access = isset($meta['access']) ? $meta['access'] : 'free';
        $trial = isset($meta['trial']) ? (int)$meta['trial'] : 0;
        $cover = isset($meta['cover']) ? $meta['cover'] : (isset($post['cover']) ? $post['cover'] : '');
        $title = isset($post['title']) ? $post['title'] : $title;
        $dmId = 'v' . $post['id'];
    } elseif ($url !== '') {
        // 任意地址播放（试看 / 直链）
        $routes = array(array('name' => '默认线路', 'episodes' => array(array('name' => '视频', 'url' => $url, 'type' => video_source_type($url)))));
        $dmId = 'u' . md5($url);
        $title = basename(parse_url($url, PHP_URL_PATH) ?: $url);
    } else {
        video_api_fail('缺少视频标识：请提供 id / slug / url / v', 400);
    }

    $chk = video_access_check($access, $trial);
    $sign = video_sign($dmId . '|' . $url);
    video_api_ok(array(
        'id'      => $dmId,
        'title'   => $title,
        'cover'   => $cover,
        'routes'  => $routes,
        'access'  => array('level' => $access, 'ok' => $chk['ok'], 'reason' => $chk['reason'], 'trial' => $chk['trial']),
        'danmaku' => video_on('danmaku_on', true) ? 1 : 0,
        'theme'   => array('accent' => video_opt('theme_color', '#8f7bff'), 'empty' => video_opt('theme_empty', '')),
        'ad'      => array('pauseImg' => video_opt('ad_pause_img', ''), 'pauseUrl' => video_opt('ad_pause_url', '')),
        'parse'   => video_parse_apis(),
        'heartbeat' => video_on('heartbeat', true) ? 1 : 0,
        'sign'    => $sign
    ));
}

/* ---------------- 弹幕加载 / 发送 ---------------- */
function video_api_dm($getOnly = false)
{
    $id = isset($_REQUEST['id']) ? trim((string)$_REQUEST['id']) : '';
    if ($id === '') video_api_fail('缺少弹幕 id', 400);
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$getOnly) {
        // 发送弹幕
        if (!video_on('danmaku_on', true)) video_api_fail('弹幕已关闭', 403);
        if (!video_rate_limit('dm_send_' . $id, (int)video_num('dm_limit', 20, 1, 200), 60)) video_api_fail('发送过于频繁', 429);
        $text = isset($_POST['text']) ? trim((string)$_POST['text']) : '';
        $text = mb_substr($text, 0, 400, 'UTF-8');
        if ($text === '') video_api_fail('弹幕内容为空', 400);
        $bw = video_has_ban($text); if ($bw) video_api_fail('弹幕含违禁词：' . $bw, 400);
        $time = isset($_POST['time']) ? (float)$_POST['time'] : 0;
        $mode = isset($_POST['mode']) ? (int)$_POST['mode'] : 1;
        $color = isset($_POST['color']) ? preg_replace('/[^0-9a-fA-F#]/', '', (string)$_POST['color']) : '#ffffff';
        if (!in_array($mode, array(1, 4, 5, 6), true)) $mode = 1;
        $item = array(
            'time' => max(0, $time), 'mode' => $mode, 'color' => $color ? $color : '#ffffff',
            'text' => $text, 'uid' => video_user_role(), 'ts' => time(),
            'ip' => md5(isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '0')
        );
        video_dm_append($id, $item);
        video_api_ok(array('id' => $id, 'ok' => true));
    }
    // 加载
    $items = video_dm_load($id);
    video_api_ok(array('id' => $id, 'items' => $items, 'total' => count($items)));
}

/* ---------------- 举报 ---------------- */
function video_api_report()
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') video_api_fail('请使用 POST 举报', 405);
    $id = isset($_POST['id']) ? trim((string)$_POST['id']) : '';
    $did = isset($_POST['did']) ? (int)$_POST['did'] : 0;
    $reason = isset($_POST['reason']) ? trim((string)$_POST['reason']) : '';
    if ($id === '' || $did <= 0) video_api_fail('参数缺失', 400);
    video_dm_report($id, $did, $reason);
    video_api_ok(array('ok' => true));
}

/* ---------------- 在线人数心跳 ---------------- */
function video_api_hb()
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') video_api_fail('请使用 POST', 405);
    $id = isset($_POST['id']) ? trim((string)$_POST['id']) : '';
    if ($id === '') video_api_fail('缺少 id', 400);
    // 简易在线计数：按分钟维护活跃 IP 集合（文件存储）
    $dir = video_dm_dir();
    $f = $dir . 'hb_' . preg_replace('/[^a-zA-Z0-9_\-]/', '', $id) . '.json';
    $now = time();
    $min = intval($now / 60);
    $data = is_file($f) ? @json_decode(file_get_contents($f), true) : array();
    if (!is_array($data)) $data = array();
    $ip = isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '0';
    $data[$min][$ip] = $now;
    // 仅保留最近 3 分钟
    foreach ($data as $k => $v) { if ($k < $min - 2) unset($data[$k]); }
    @file_put_contents($f, video_json($data));
    $online = 0;
    foreach ($data as $v) $online += count($v);
    video_api_ok(array('online' => $online));
}

/* ---------------- 后台弹幕 / 举报列表 ---------------- */
function video_api_list()
{
    if (!video_is_admin()) video_api_fail('需要管理员权限', 403);
    $id = isset($_REQUEST['id']) ? trim((string)$_REQUEST['id']) : '';
    $out = array('ok' => true, 'items' => array(), 'reports' => array());
    if ($id !== '') {
        $out['items'] = video_dm_load($id);
        $out['reports'] = video_dm_reports($id);
    } else {
        $out['all'] = video_dm_ids();
    }
    video_api_ok($out);
}

/* ============================================================
   弹幕存储（DB 优先；否则 JSON 文件）
   ============================================================ */
function video_dm_dir()
{
    $d = __DIR__ . '/data/';
    if (!is_dir($d)) @mkdir($d, 0755, true);
    return $d;
}
function video_dm_file($id)
{
    $safe = preg_replace('/[^a-zA-Z0-9_\-]/', '', $id);
    return video_dm_dir() . 'dm_' . $safe . '.json';
}
function video_dm_report_file($id)
{
    $safe = preg_replace('/[^a-zA-Z0-9_\-]/', '', $id);
    return video_dm_dir() . 'rp_' . $safe . '.json';
}
function video_dm_load($id)
{
    $db = video_db();
    if ($db) {
        try {
            $st = $db->prepare('SELECT content FROM `plugin_video_danmaku` WHERE vid = ? LIMIT 1');
            $st->execute(array($id)); $v = $st->fetchColumn();
            if ($v !== false) { $d = @json_decode((string)$v, true); if (is_array($d)) return $d; }
        } catch (Throwable $e) {}
    }
    $f = video_dm_file($id);
    if (is_file($f)) { $d = @json_decode(file_get_contents($f), true); if (is_array($d)) return $d; }
    return array();
}
function video_dm_append($id, $item)
{
    $db = video_db();
    if ($db) {
        try {
            $db->exec('CREATE TABLE IF NOT EXISTS `plugin_video_danmaku` (`vid` VARCHAR(64) NOT NULL, `content` MEDIUMTEXT NOT NULL, PRIMARY KEY (`vid`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
            $cur = video_dm_load($id); $cur[] = $item;
            $st = $db->prepare('REPLACE INTO `plugin_video_danmaku` (vid, content) VALUES (?,?)');
            $st->execute(array($id, video_json($cur)));
            return true;
        } catch (Throwable $e) {}
    }
    $f = video_dm_file($id);
    $fp = @fopen($f, 'c+');
    if ($fp && flock($fp, LOCK_EX)) {
        $cur = ''; $sz = filesize($f);
        if ($sz) $cur = (string)stream_get_contents($fp);
        $arr = @json_decode($cur, true); if (!is_array($arr)) $arr = array();
        $arr[] = $item;
        ftruncate($fp, 0); rewind($fp);
        fwrite($fp, video_json($arr)); flock($fp, LOCK_UN); fclose($fp);
        return true;
    }
    if ($fp) fclose($fp);
    return false;
}
function video_dm_report($id, $did, $reason)
{
    $entry = array('did' => $did, 'reason' => mb_substr($reason, 0, 200, 'UTF-8'), 'ts' => time(), 'ip' => md5(isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '0'));
    $f = video_dm_report_file($id);
    $fp = @fopen($f, 'c+');
    if ($fp && flock($fp, LOCK_EX)) {
        $sz = filesize($f); $cur = $sz ? (string)stream_get_contents($fp) : '';
        $arr = @json_decode($cur, true); if (!is_array($arr)) $arr = array();
        $arr[] = $entry; ftruncate($fp, 0); rewind($fp); fwrite($fp, video_json($arr)); flock($fp, LOCK_UN); fclose($fp);
    } elseif ($fp) fclose($fp);
}
function video_dm_reports($id)
{
    $f = video_dm_report_file($id);
    if (is_file($f)) { $d = @json_decode(file_get_contents($f), true); if (is_array($d)) return $d; }
    return array();
}
function video_dm_ids()
{
    $d = video_dm_dir();
    $out = array();
    foreach (glob($d . 'dm_*.json') as $f) { $out[] = str_replace(array($d . 'dm_', '.json'), '', $f); }
    return $out;
}

/* ---------------- 响应辅助 ---------------- */
function video_api_ok($data)
{
    echo video_json(array_merge(array('ok' => true), $data));
    exit;
}
function video_api_fail($msg, $code = 400)
{
    http_response_code($code);
    echo video_json(array('ok' => false, 'error' => $msg, 'code' => $code));
    exit;
}
