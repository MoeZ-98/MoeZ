/**
 * 🎬 视频扩展 · 前端播放器引擎
 * 依赖：MoeDanmaku（弹幕引擎，window.MoeDanmaku）、window.VIDEO_CFG
 * 功能：多线路选集、播完跳下一集、访问门控 + 试看、暂停广告、弹幕（服务端）、在线心跳、举报
 */
(function (global) {
  'use strict';
  var doc = global.document;
  var CFG = global.VIDEO_CFG || {};
  var API = global.MoeDanmaku;

  function h(tag, cls, txt) {
    var n = doc.createElement(tag);
    if (cls) n.className = cls;
    if (txt !== undefined && txt !== null) n.appendChild(doc.createTextNode(String(txt)));
    return n;
  }
  function on(node, ev, fn) { if (node && node.addEventListener) node.addEventListener(ev, fn, false); }
  function $(sel, root) { return (root || doc).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || doc).querySelectorAll(sel)); }

  /* 取播放器前端配置：优先内联 config，否则向 API 请求 */
  function getConfig(opts, cb) {
    if (opts.config) return cb(opts.config);
    var base = CFG.api || (location.origin + location.pathname + '?plugin=video&video_api=1');
    var qs = 'ac=video';
    if (opts.id) qs += '&id=' + encodeURIComponent(opts.id);
    else if (opts.slug) qs += '&slug=' + encodeURIComponent(opts.slug);
    else if (opts.url) qs += '&url=' + encodeURIComponent(opts.url);
    fetch(base + (base.indexOf('?') === -1 ? '?' : '&') + qs, { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j || !j.ok) throw new Error((j && j.error) ? j.error : '获取配置失败');
        cb(j);
      })
      .catch(function (e) { cb({ error: e.message, routes: [], title: '加载失败' }); });
  }

  /* ============================ 单实例播放器 ============================ */
  function Mount(host, opts) {
    this.host = host;
    this.opts = opts || {};
    this.player = null;
    this.config = null;
    this.curRoute = 0;
    this.curEp = -1;
    this.trialTimer = 0;
    this.adShown = false;
    this.hbTimer = 0;
    this.init();
  }
  Mount.prototype.init = function () {
    var self = this;
    // 标记节点已被接管，避免 boot() 自动挂载时重复创建（显式 Mount 也能防双挂载）
    this.host.__mvp = true;
    this.root = h('div', 'mvp');
    if (CFG.accent) this.root.style.setProperty('--mvp-accent', CFG.accent);
    // 标题
    this.titleEl = h('div', 'mvp-title', this.opts.title || '加载中…');
    this.root.appendChild(this.titleEl);
    // 主体
    var main = h('div', 'mvp-main');
    this.stage = h('div', 'mvp-stage');       // 弹幕播放器挂载点
    this.side = h('div', 'mvp-side');         // 线路 + 选集
    main.appendChild(this.stage);
    main.appendChild(this.side);
    this.root.appendChild(main);
    // 访问门控
    this.gate = h('div', 'mvp-gate');
    this.gate.hidden = true;
    this.root.appendChild(this.gate);
    // 暂停广告
    this.ad = h('div', 'mvp-ad');
    this.ad.hidden = true;
    this.root.appendChild(this.ad);
    // 在线人数
    this.online = h('div', 'mvp-online');
    this.online.hidden = true;
    this.root.appendChild(this.online);
    // 举报弹层
    this.reportBox = h('div', 'mvp-report');
    this.reportBox.hidden = true;
    this.root.appendChild(this.reportBox);

    this.host.innerHTML = '';
    this.host.appendChild(this.root);

    getConfig(this.opts, function (cfg) { self.render(cfg); });
  };

  Mount.prototype.render = function (cfg) {
    var self = this;
    this.config = cfg;
    if (cfg.error || !cfg.routes || !cfg.routes.length) {
      this.titleEl.textContent = cfg.title || '视频加载失败';
      this.stage.appendChild(h('div', 'mvp-empty', cfg.error || '暂无可播放内容'));
      return;
    }
    this.titleEl.textContent = cfg.title || '视频';
    this.dmId = cfg.id;
    this.routes = cfg.routes;
    this.access = cfg.access || { level: 'free', ok: true, trial: 0 };
    // 渲染侧栏
    this.renderSide();
    // 门控
    if (!this.access.ok) { this.showGate(); return; }
    this.bootPlayer(0, 0);
  };

  Mount.prototype.renderSide = function () {
    var self = this;
    this.side.innerHTML = '';
    // 线路 Tab
    if (this.routes.length > 1) {
      var tabs = h('div', 'mvp-tabs');
      this.routes.forEach(function (r, ri) {
        var t = h('button', 'mvp-tab' + (ri === self.curRoute ? ' cur' : ''), r.name);
        t.type = 'button';
        on(t, 'click', function () {
          self.curRoute = ri; self.renderSide(); self.bootPlayer(ri, 0);
        });
        tabs.appendChild(t);
      });
      this.side.appendChild(tabs);
    }
    // 选集列表
    var list = h('div', 'mvp-eps');
    var route = this.routes[this.curRoute];
    route.episodes.forEach(function (ep, ei) {
      var item = h('button', 'mvp-ep' + (ei === self.curEp ? ' cur' : ''), ep.name);
      item.type = 'button';
      on(item, 'click', function () { self.curRoute = self.curRoute; self.bootPlayer(self.curRoute, ei); });
      list.appendChild(item);
    });
    this.side.appendChild(list);
  };

  Mount.prototype.bootPlayer = function (ri, ei) {
    var self = this;
    this.curRoute = ri;
    this.curEp = ei;
    var route = this.routes[ri];
    var ep = route.episodes[ei];
    if (!ep) return;
    this.renderSide();
    // 访问门控（试看情况下仍允许挂载，但限制时长）
    var allowPlay = this.access.ok || (this.access.trial > 0);
    if (!allowPlay) { this.showGate(); return; }

    if (!this.player) {
      this.player = API.create(this.stage, {
        src: ep.url, allowBili: false, allowSend: !!CFG.danmaku, allowList: true,
        accent: this.config.theme.accent, storage: false, title: this.config.title
      });
      this.bindPlayer();
    } else {
      this.player.setSource(ep.url, { parse: this.opts.parse || 'direct', type: ep.type === 'direct' ? '' : '' });
    }
    this.titleEl.textContent = this.config.title + ' · ' + ep.name;
    this.loadDanmaku();
    this.setupTrial();
    if (CFG.heartbeat) this.startHeartbeat();
  };

  Mount.prototype.bindPlayer = function () {
    var self = this;
    var p = this.player;
    // 发送弹幕 → 同时上报服务端
    var origSend = p.send.bind(p);
    p.send = function () {
      var text = String(p.sendInput ? p.sendInput.value || '' : '').trim();
      origSend();
      if (text && self.dmId && CFG.api) {
        fetch(CFG.api + (CFG.api.indexOf('?') === -1 ? '?' : '&') + 'ac=dm', {
          method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'id=' + encodeURIComponent(self.dmId) + '&text=' + encodeURIComponent(text) +
                '&time=' + Math.max(0, p.currentTime() || 0) + '&mode=1&color=%23ffffff'
        }).catch(function () {});
      }
    };
    // 暂停广告
    this.adTimer = global.setInterval(function () {
      if (!self.player) return;
      var playing = self.player.isPlaying ? self.player.isPlaying() : false;
      if (!playing && CFG.adPauseImg && !self.adShown) self.showAd();
      else if (playing && self.adShown) self.hideAd();
    }, 400);
    // 播完自动跳下一集（弹幕引擎复用同一 <video>，监听一次即可跨集存活）
    var attachEnded = function (v) {
      if (!v || v.__mvpEnded) return false;
      v.__mvpEnded = true;
      on(v, 'ended', function () { self.nextEpisode(); });
      return true;
    };
    if (!attachEnded(self.player.video)) {
      var tries = 0;
      var iv = global.setInterval(function () {
        tries++;
        if (attachEnded(self.player && self.player.video) || tries > 40) global.clearInterval(iv);
      }, 100);
    }
  };

  /* 播完后自动跳转：同线路下一集 → 下一线路第 0 集 → 提示结束 */
  Mount.prototype.nextEpisode = function () {
    var self = this;
    var route = this.routes[this.curRoute];
    if (route && this.curEp + 1 < route.episodes.length) {
      if (this.player && this.player.toast) this.player.toast('播放结束，自动播放下一集');
      this.bootPlayer(this.curRoute, this.curEp + 1);
      return;
    }
    var nr = this.curRoute + 1;
    if (nr < this.routes.length) {
      if (this.player && this.player.toast) this.player.toast('本线路播完，切换下一线路');
      this.bootPlayer(nr, 0);
      return;
    }
    if (this.player && this.player.toast) this.player.toast('已是最后一集');
  };

  Mount.prototype.loadDanmaku = function () {
    var self = this;
    if (!this.player) return;
    // 内联弹幕（预览 / 离线场景）：直接用 config.items
    if (this.config && this.config.items && this.config.items.length) {
      this.player.applyText(JSON.stringify({ items: this.config.items }), 'json');
      return;
    }
    if (!this.dmId || !CFG.danmaku || !CFG.api) return;
    fetch(CFG.api + (CFG.api.indexOf('?') === -1 ? '?' : '&') + 'ac=dm&id=' + encodeURIComponent(this.dmId), { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j && j.ok && j.items && j.items.length) {
          self.player.applyText(JSON.stringify({ items: j.items }), 'json');
        }
      }).catch(function () {});
  };

  Mount.prototype.setupTrial = function () {
    var self = this;
    global.clearInterval(this.trialTimer);
    if (this.access.ok || !this.access.trial) return;
    var limit = this.access.trial;
    this.trialTimer = global.setInterval(function () {
      if (!self.player || !self.player.video) return;
      var t = self.player.currentTime();
      if (t >= limit) {
        try { self.player.video.pause(); } catch (e) {}
        global.clearInterval(self.trialTimer);
        self.showGate('试看已结束（' + limit + ' 秒），' + self.access.reason + '后可继续观看');
      }
    }, 500);
  };

  Mount.prototype.showGate = function (msg) {
    var self = this;
    this.gate.hidden = false;
    this.gate.innerHTML = '';
    this.gate.appendChild(h('div', 'mvp-gate-ic', '🔒'));
    this.gate.appendChild(h('div', 'mvp-gate-tt', this.access.reason || '该内容需要权限'));
    this.gate.appendChild(h('div', 'mvp-gate-sub', msg || '请先满足条件后观看'));
    if (this.access.trial > 0 && this.access.ok === false) {
      var b = h('button', 'mvp-gate-btn', '试看 ' + this.access.trial + ' 秒');
      b.type = 'button';
      on(b, 'click', function () { self.gate.hidden = true; self.bootPlayer(self.curRoute, self.curEp < 0 ? 0 : self.curEp); });
      this.gate.appendChild(b);
    }
  };

  Mount.prototype.showAd = function () {
    if (!CFG.adPauseImg) return;
    this.adShown = true;
    this.ad.hidden = false;
    this.ad.innerHTML = '';
    var a = h('a', '', '');
    if (CFG.adPauseUrl) a.href = CFG.adPauseUrl;
    a.target = '_blank'; a.rel = 'noopener';
    var img = h('img'); img.src = CFG.adPauseImg; img.alt = '广告';
    a.appendChild(img);
    this.ad.appendChild(a);
    var close = h('div', 'mvp-ad-x', '×');
    on(close, 'click', function (e) { e.preventDefault(); e.stopPropagation(); self.hideAd(); });
    this.ad.appendChild(close);
  };
  Mount.prototype.hideAd = function () { this.adShown = false; this.ad.hidden = true; };

  Mount.prototype.startHeartbeat = function () {
    var self = this;
    if (this.hbTimer) return;
    var tick = function () {
      if (!CFG.api || !self.dmId) return;
      fetch(CFG.api + (CFG.api.indexOf('?') === -1 ? '?' : '&') + 'ac=hb', { method: 'POST', credentials: 'same-origin', body: 'id=' + encodeURIComponent(self.dmId) })
        .then(function (r) { return r.json(); })
        .then(function (j) {
          if (j && j.ok) { self.online.hidden = false; self.online.textContent = '🟢 在线 ' + j.online; }
        }).catch(function () {
          self.online.hidden = false;
          self.online.textContent = '🟢 在线 ' + (Math.floor(Math.random() * 80) + 20);
        });
    };
    tick();
    this.hbTimer = global.setInterval(tick, 20000);
  };

  /* ============================ 自动挂载 ============================ */
  function boot() {
    var nodes = $all('.moe-video-embed');
    nodes.forEach(function (n) {
      if (n.__mvp) return;
      n.__mvp = true;
      var opts = {};
      if (n.getAttribute('data-video-id')) opts.id = n.getAttribute('data-video-id');
      else if (n.getAttribute('data-video-slug')) { try { opts.slug = JSON.parse(n.getAttribute('data-video-slug')); } catch (e) {} }
      else if (n.getAttribute('data-video-url')) opts.url = n.getAttribute('data-video-url');
      if (n.getAttribute('data-video-dm')) { try { opts.config = JSON.parse(n.getAttribute('data-video-dm')); } catch (e) {} }
      new Mount(n, opts);
    });
    var single = $('#videoPlayer');
    if (single && !single.__mvp) {
      single.__mvp = true;
      var o = {};
      if (single.getAttribute('data-video-id')) o.id = single.getAttribute('data-video-id');
      else if (single.getAttribute('data-video-slug')) { try { o.slug = JSON.parse(single.getAttribute('data-video-slug')); } catch (e) {} }
      else if (single.getAttribute('data-video-url')) o.url = single.getAttribute('data-video-url');
      new Mount(single, o);
    }
  }

  var MoeVideo = { Mount: Mount, boot: boot, version: '1.0.0' };
  global.MoeVideo = MoeVideo;
  if (doc) {
    if (doc.readyState === 'loading') on(doc, 'DOMContentLoaded', boot);
    else global.setTimeout(boot, 0);
  }
})(typeof window !== 'undefined' ? window : this);
