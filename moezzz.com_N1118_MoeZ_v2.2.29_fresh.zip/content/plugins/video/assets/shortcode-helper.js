/*!
 * 🎬 弹幕解析播放器 · 后台编辑器短代码助手
 * 只由 admin_footer 钩子在 post-edit.php / pages.php 注入。
 */
(function () {
  'use strict';
  if (document.getElementById('mdpHelperBtn')) return;
  if (!document.getElementById('edText')) return; // 没有正文编辑器就不出现

  var css = document.createElement('style');
  css.textContent = [
    '#mdpHelperBtn{position:fixed;right:18px;bottom:18px;z-index:9998;padding:9px 14px;border:0;border-radius:22px;',
    'background:#8f7bff;color:#fff;font:600 13px/1.4 system-ui,"PingFang SC",sans-serif;cursor:pointer;',
    'box-shadow:0 8px 24px rgba(120,95,220,.35)}',
    '#mdpHelperBtn:hover{filter:brightness(1.1)}',
    '#mdpHelperPanel{position:fixed;right:18px;bottom:62px;z-index:9999;width:min(380px,calc(100vw - 36px));',
    'padding:16px;border-radius:14px;background:#fff;color:#3b3450;box-shadow:0 18px 50px rgba(40,30,80,.28);',
    'font:13px/1.6 system-ui,"PingFang SC",sans-serif}',
    '#mdpHelperPanel h3{margin:0 0 4px;font-size:15px}',
    '#mdpHelperPanel p{margin:0 0 10px;font-size:11px;color:#8b83a0}',
    '#mdpHelperPanel input{width:100%;margin:5px 0;padding:8px 10px;border:1px solid #e6e0f0;border-radius:8px;',
    'font:12px/1.4 system-ui,sans-serif;outline:none}',
    '#mdpHelperPanel input:focus{border-color:#8f7bff}',
    '#mdpHelperPanel textarea{width:100%;min-height:62px;margin:8px 0;padding:8px 10px;border:1px solid #e6e0f0;',
    'border-radius:8px;font:11px/1.5 ui-monospace,Consolas,monospace;resize:vertical}',
    '.mdp-h-row{display:flex;gap:6px;flex-wrap:wrap}',
    '.mdp-h-row button{flex:1 1 auto;padding:7px 10px;border:1px solid #e6e0f0;border-radius:8px;background:#f8f6ff;',
    'color:#5b4fa0;font-size:12px;cursor:pointer}',
    '.mdp-h-row button.mdp-h-main{background:#8f7bff;border-color:#8f7bff;color:#fff;font-weight:600}',
    '.mdp-h-close{position:absolute;right:12px;top:10px;border:0;background:transparent;color:#a39ab8;',
    'font-size:17px;cursor:pointer;line-height:1}'
  ].join('');
  document.head.appendChild(css);

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined) n.textContent = text;
    return n;
  }
  function input(id, ph) {
    var i = el('input'); i.id = id; i.type = 'text'; i.placeholder = ph; return i;
  }

  var btn = el('button', '', '🎬 插入弹幕播放器');
  btn.id = 'mdpHelperBtn'; btn.type = 'button';
  document.body.appendChild(btn);

  var panel = el('div'); panel.id = 'mdpHelperPanel'; panel.style.display = 'none';
  panel.style.position = 'fixed';
  var close = el('button', 'mdp-h-close', '✕'); close.type = 'button'; close.title = '关闭';
  panel.appendChild(close);
  panel.appendChild(el('h3', '', '弹幕播放器短代码'));
  panel.appendChild(el('p', '', '留空 src 即使用纯弹幕时间轴；src 可填 mp4 / m3u8 直链或影视播放页。'));
  panel.appendChild(input('mdpHsrc', '视频地址 src（.mp4 / .m3u8 / 播放页，可留空）'));
  panel.appendChild(input('mdpHdm', '弹幕文件 dm（/uploads/d.xml，可留空）'));
  panel.appendChild(input('mdpHbili', 'B 站链接 / BV号 / CID（可选）'));
  panel.appendChild(input('mdpHparse', '解析接口 parse（direct / p1 / p2…，留空用默认）'));
  panel.appendChild(input('mdpHproxy', '代理 proxy（on / off，留空跟随站点）'));
  panel.appendChild(input('mdpHtitle', '标题（可选）'));
  var out = el('textarea'); out.id = 'mdpHout'; out.readOnly = true;
  panel.appendChild(out);

  var row = el('div', 'mdp-h-row');
  var bBuild = el('button', 'mdp-h-main', '生成');
  var bCopy = el('button', '', '复制');
  var bInsert = el('button', '', '插入正文');
  [bBuild, bCopy, bInsert].forEach(function (b) { b.type = 'button'; row.appendChild(b); });
  panel.appendChild(row);
  document.body.appendChild(panel);

  function attr(k, v) {
    v = (v || '').trim();
    return v ? ' ' + k + '="' + v.replace(/"/g, '&quot;') + '"' : '';
  }
  function build() {
    var code = '[danmaku'
      + attr('src', document.getElementById('mdpHsrc').value)
      + attr('dm', document.getElementById('mdpHdm').value)
      + attr('bili', document.getElementById('mdpHbili').value)
      + attr('parse', document.getElementById('mdpHparse').value)
      + attr('proxy', document.getElementById('mdpHproxy').value)
      + attr('title', document.getElementById('mdpHtitle').value)
      + ']';
    out.value = code;
    return code;
  }
  function flash(msg) {
    var old = bCopy.textContent;
    bCopy.textContent = msg;
    setTimeout(function () { bCopy.textContent = old; }, 1500);
  }
  function toggle(show) {
    panel.style.display = show ? 'block' : 'none';
    if (show) { build(); document.getElementById('mdpHsrc').focus(); }
  }

  btn.addEventListener('click', function () { toggle(panel.style.display === 'none'); });
  close.addEventListener('click', function () { toggle(false); });
  bBuild.addEventListener('click', build);
  bCopy.addEventListener('click', function () {
    var code = build();
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(code).then(function () { flash('已复制 ✓'); }, function () { manual(); flash('请手动复制'); });
    } else { manual(); flash('请手动复制'); }
  });
  function manual() { out.focus(); out.select(); try { document.execCommand('copy'); } catch (e) {} }
  bInsert.addEventListener('click', function () {
    var code = build(), ta = document.getElementById('edText');
    if (!ta) return;
    var s = ta.selectionStart || 0, e = ta.selectionEnd || 0;
    var prefix = (s > 0 && ta.value.charAt(s - 1) !== '\n') ? '\n\n' : '';
    var suffix = (e < ta.value.length && ta.value.charAt(e) !== '\n') ? '\n\n' : '\n';
    var insert = prefix + code + suffix;
    ta.value = ta.value.slice(0, s) + insert + ta.value.slice(e);
    ta.focus();
    try { ta.setSelectionRange(s + insert.length, s + insert.length); } catch (err) {}
    ta.dispatchEvent(new Event('input', { bubbles: true }));
    toggle(false);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && panel.style.display !== 'none') toggle(false);
  });
}());
