/*!
 * Moe Danmaku Player · 弹幕解析播放器引擎
 * ------------------------------------------------------------
 * 零依赖 / 原生 JS / 兼容 PHP 站点的 Moe 酷 CMS 插件，也可单独用于任意网页。
 * 解析：B站 XML、ASS/SSA、JSON(DPlayer/Bili)、SRT/VTT、纯文本
 * 渲染：滚动 / 顶部 / 底部 / 逆向，轨道避让、时间轴同步、跳进度重排
 * 所有用户内容一律通过 textContent 写入，绝不拼 innerHTML。
 */
(function (global) {
  'use strict';

  var VERSION = '1.1.0';
  var doc = global.document;
  var CFG = global.MOE_DANMAKU_CFG || {};
  var PARSE_CFG = CFG.parse || {};

  var DEFAULTS = {
    src: '',            // 视频地址
    dm: '',             // 弹幕文件地址（多个用 | 分隔）
    bili: '',           // B站链接 / BV号 / CID
    poster: '',
    title: '',
    ratio: '16:9',
    autoplay: false,
    loop: false,
    muted: false,
    danmaku: true,      // 默认开启弹幕
    opacity: 0.92,
    fontSize: 24,
    area: 0.85,         // 弹幕显示区域占比
    duration: 8,        // 滚动弹幕穿越屏幕的秒数
    hold: 4,            // 固定弹幕停留秒数
    bold: true,
    stroke: true,
    overlap: false,     // 轨道占满时是否允许重叠
    offset: 0,          // 弹幕整体时间偏移（秒）
    allowBili: true,
    allowSend: true,
    allowList: true,
      accent: '#8f7bff',
      api: '',            // 服务端解析代理（B站弹幕 / 视频地址解析）
      base: '',
      parse: '',          // 解析接口 id（direct / p1 / p2 …）
      proxy: '',          // on / off，留空跟随站点 proxy_mode
      type: 'auto',       // hls / mp4 / auto，一般无需填写
      storage: true
    };

  var FONT_STACK = '"PingFang SC","Microsoft YaHei","Hiragino Sans GB",system-ui,-apple-system,sans-serif';
  var GAP = 24;                 // 同轨道两条弹幕的最小间距(px)
  var MAX_ITEMS = 30000;
  var MAX_TEXT = 400;
  var STORE_SETTINGS = 'mdk.settings.v1';
  var STORE_USER = 'mdk.user.v1:';

  /* ============================================================
     一、工具函数
     ============================================================ */

  function num(v, d) { var n = parseFloat(v); return isFinite(n) ? n : d; }
  function clamp(v, a, b) { return v < a ? a : (v > b ? b : v); }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function fmtTime(t) {
    t = Math.max(0, Math.floor(num(t, 0)));
    var h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60;
    return (h > 0 ? h + ':' + pad2(m) : pad2(m)) + ':' + pad2(s);
  }
  function mix(o) {
    var out = {}, args = Array.prototype.slice.call(arguments), i, k;
    for (i = 0; i < args.length; i++) if (args[i] && typeof args[i] === 'object')
      for (k in args[i]) if (Object.prototype.hasOwnProperty.call(args[i], k)) out[k] = args[i][k];
    return out;
  }
  function h(tag, cls, text) {
    var n = doc.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = String(text);
    return n;
  }
  function on(node, ev, fn, opt) { if (node && node.addEventListener) node.addEventListener(ev, fn, opt || false); }

  /* ============================================================
     视频源：类型嗅探 / HLS 解码库 / 服务端解析通道
     ============================================================ */

  /** mp4、m3u8、还是影视播放页（网页地址需交给解析接口） */
  function sniffStream(url) {
    var s = String(url || '').toLowerCase().split('#')[0];
    if (s.indexOf('.m3u8') !== -1) return 'hls';
    if (/\.(mp4|m4v|mov|webm|mkv|flv|ts|mpg|mpeg|avi)(\?|&|$)/.test(s)) return 'mp4';
    if (/\.(mpd|ism|manifest)(\?|&|$)/.test(s)) return 'page'; // DASH / Smooth 暂不支持
    return 'page';
  }
  function streamLabel(t) { return t === 'hls' ? 'm3u8 / HLS' : (t === 'mp4' ? 'mp4 / 直链' : '网页 / 待解析'); }

  function loadScript(url, cb) {
    if (!doc || !doc.createElement) return cb();
    var s = doc.createElement('script');
    s.src = url; s.async = true;
    s.onload = function () { cb(); };
    s.onerror = function () { if (s.parentNode) s.parentNode.removeChild(s); cb(); };
    (doc.head || doc.body || doc.documentElement).appendChild(s);
  }

  /** hls.js：优先插件内置文件，失败按配置回退 CDN；并行调用会合并成一次加载 */
  var hlsQueue = null;
  function loadHls(cb, fail) {
    if (global.Hls) return cb(global.Hls);
    var mode = PARSE_CFG.hls || 'local', urls = [], cdns = PARSE_CFG.cdn || [], i;
    if (mode === 'cdn') { /* CDN 优先 */ }
    else if (PARSE_CFG.hlsUrl) urls.push(PARSE_CFG.hlsUrl);
    for (i = 0; i < cdns.length; i++) if (urls.indexOf(cdns[i]) === -1) urls.push(cdns[i]);
    // 内置文件始终作为最后兜底，即使配置成 CDN 优先
    if (mode === 'cdn' && PARSE_CFG.hlsUrl && urls.indexOf(PARSE_CFG.hlsUrl) === -1) urls.push(PARSE_CFG.hlsUrl);
    if (!urls.length) urls.push('https://cdn.jsdelivr.net/npm/hls.js@1.5.17/dist/hls.min.js');
    if (hlsQueue) { hlsQueue.push([cb, fail]); return; }
    hlsQueue = [[cb, fail]];
    function finish(ok) {
      var q = hlsQueue; hlsQueue = null;
      for (var k = 0; k < q.length; k++) { try { ok ? q[k][0](global.Hls) : q[k][1](); } catch (e) {} }
    }
    function next(i) {
      if (global.Hls) return finish(true);
      if (i >= urls.length) return finish(false);
      loadScript(urls[i], function () { global.Hls ? finish(true) : next(i + 1); });
    }
    next(0);
  }

  /** 服务端接口多通道回退：404 / 403 / 非 JSON → 试下一个通道；业务错误交给 done 判断 */
  function callApi(apis, qs, done, fail) {
    if (!Array.isArray(apis)) apis = apis ? [apis] : [];
    function attempt(i) {
      if (i >= apis.length) return fail('所有解析通道均不可用');
      var base = String(apis[i] || '');
      if (!base) return attempt(i + 1);
      var url = base + (base.indexOf('?') === -1 ? '?' : '&') + qs;
      fetch(url, { credentials: 'same-origin' }).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.text();
      }).then(function (txt) {
        var j;
        try { j = JSON.parse(txt); } catch (e) { throw new Error('非 JSON'); }
        if (!j || typeof j !== 'object') throw new Error('非 JSON');
        done(j, i);
      }).catch(function () { attempt(i + 1); });
    }
    attempt(0);
  }

  function decodeEntities(s) {
    return String(s || '')
      .replace(/&#x([0-9a-f]+);/gi, function (_, x) { return String.fromCodePoint(parseInt(x, 16)); })
      .replace(/&#(\d+);/g, function (_, x) { return String.fromCodePoint(parseInt(x, 10)); })
      .replace(/&lt;/gi, '<').replace(/&gt;/gi, '>')
      .replace(/&quot;/gi, '"').replace(/&apos;/gi, "'")
      .replace(/&nbsp;/gi, ' ').replace(/&amp;/gi, '&');
  }
  function decodeBuffer(buf) {
    var bytes = new Uint8Array(buf);
    var txt = '';
    if (global.TextDecoder) {
      try { txt = new TextDecoder('utf-8', { fatal: false }).decode(bytes); } catch (e) { txt = ''; }
      if (!txt || txt.indexOf('\uFFFD') !== -1) {
        try {
          var alt = new TextDecoder('gbk').decode(bytes);
          if (alt && alt.indexOf('\uFFFD') === -1) txt = alt;
        } catch (e2) { /* 浏览器不支持 GBK 时保留 UTF-8 结果 */ }
      }
      return txt.replace(/^\uFEFF/, '');
    }
    var i, out = '';
    for (i = 0; i < bytes.length; i++) out += String.fromCharCode(bytes[i]);
    try { return decodeURIComponent(escape(out)).replace(/^\uFEFF/, ''); } catch (e) { return out.replace(/^\uFEFF/, ''); }
  }
  function toHex(n, def) {
    n = Math.floor(num(n, NaN));
    if (!isFinite(n) || n < 0) return def || '#ffffff';
    if (n > 0xffffff) n = n & 0xffffff;
    var s = n.toString(16);
    while (s.length < 6) s = '0' + s;
    return '#' + s;
  }
  function normColor(c, def) {
    if (c === null || c === undefined || c === '') return def || '#ffffff';
    if (typeof c === 'number') return toHex(c, def);
    var s = String(c).trim();
    if (/^#[0-9a-f]{3}$/i.test(s)) return '#' + s[1] + s[1] + s[2] + s[2] + s[3] + s[3];
    if (/^#[0-9a-f]{6}$/i.test(s)) return s;
    if (/^#[0-9a-f]{8}$/i.test(s)) return s.slice(0, 7);
    if (/^0x[0-9a-f]{1,8}$/i.test(s)) return toHex(parseInt(s.slice(2), 16), def);
    if (/^\d+$/.test(s)) return toHex(parseInt(s, 10), def);
    var m = /^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i.exec(s);
    if (m) return toHex((clamp(+m[1], 0, 255) << 16) | (clamp(+m[2], 0, 255) << 8) | clamp(+m[3], 0, 255), def);
    if (/^[a-z]+$/i.test(s)) { // 颜色名交给浏览器，但先过滤掉危险字符
      return s;
    }
    return def || '#ffffff';
  }
  function bgrToHex(v) { // ASS: &HBBGGRR&
    var s = String(v || '').replace(/[^0-9a-f]/gi, '');
    if (s.length < 6) s = ('000000' + s).slice(-6);
    return '#' + s.slice(4, 6) + s.slice(2, 4) + s.slice(0, 2);
  }
  function lowerBound(arr, t) {
    var lo = 0, hi = arr.length, mid;
    while (lo < hi) { mid = (lo + hi) >> 1; if (arr[mid].time < t) lo = mid + 1; else hi = mid; }
    return lo;
  }
  function hashKey(s) {
    var h = 2166136261, i;
    for (i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = (h * 16777619) >>> 0; }
    return h.toString(36);
  }
  function readStore(key, fb) {
    try { var v = global.localStorage.getItem(key); return v ? JSON.parse(v) : fb; } catch (e) { return fb; }
  }
  function writeStore(key, val) {
    try { global.localStorage.setItem(key, JSON.stringify(val)); } catch (e) { /* 隐私模式 */ }
  }

  /* ============================================================
     二、弹幕格式解析
     ============================================================ */

  function detectFormat(text, hint) {
    var t = String(text || '').replace(/^\uFEFF/, '').trim();
    var h = String(hint || '').toLowerCase().split('?')[0].split('#')[0];
    var ext = h.slice(h.lastIndexOf('.') + 1);
    if (!t) return 'plain';
    if (/<\?xml|^<i\b|^<danmaku\b|^<comments\b/i.test(t) || /<d\s+p\s*=/i.test(t.slice(0, 5000))) return 'bili-xml';
    if (/\[Events\]|\[Script Info\]|^Dialogue:/im.test(t)) return 'ass';
    if (/^[{[]/.test(t)) { try { JSON.parse(t); return 'json'; } catch (e) { /* 继续嗅探 */ } }
    if (t.indexOf('-->') !== -1 && /\d{1,3}:\d{2}/.test(t)) return 'srt';
    if (ext === 'xml') return 'bili-xml';
    if (ext === 'ass' || ext === 'ssa') return 'ass';
    if (ext === 'json') return 'json';
    if (ext === 'srt' || ext === 'vtt') return 'srt';
    if (/^<\w+\b[^>]*time\s*=/im.test(t)) return 'generic-xml';
    return 'plain';
  }

  /** B站 XML：<d p="时间,模式,字号,颜色,时间戳,池,用户,ID">内容</d> */
  function parseBiliXml(text) {
    var pairs = [], i;
    if (doc && global.DOMParser) {
      var xdoc;
      try { xdoc = new global.DOMParser().parseFromString(String(text).replace(/^\uFEFF/, ''), 'application/xml'); } catch (e) { xdoc = null; }
      if (xdoc && !xdoc.getElementsByTagName('parsererror').length) {
        var nodes = xdoc.getElementsByTagName('d');
        for (i = 0; i < nodes.length; i++) pairs.push([nodes[i].getAttribute('p') || '', nodes[i].textContent || '']);
      }
    }
    if (!pairs.length) {
      var re = /<d\b([^>]*)>([\s\S]*?)<\/d\s*>/gi, m;
      while ((m = re.exec(String(text))) !== null) {
        var p = /\bp\s*=\s*"([^"]*)"/i.exec(m[1]) || /\bp\s*=\s*'([^']*)'/i.exec(m[1]);
        pairs.push([p ? p[1] : '', m[2].replace(/<[^>]+>/g, '')]);
      }
    }
    var out = [];
    for (i = 0; i < pairs.length; i++) {
      var a = String(pairs[i][0]).split(',');
      var mode = parseInt(a[1], 10);
      var fs = parseInt(a[2], 10) || 25;
      if (mode === 8) continue; // 代码弹幕，安全起见忽略
      out.push({
        time: num(a[0], NaN),
        mode: mode === 4 ? 'bottom' : (mode === 5 || mode === 7 ? 'top' : (mode === 6 ? 'ltr' : 'scroll')),
        color: toHex(num(a[3], 16777215), '#ffffff'),
        size: fs >= 34 ? 1.3 : (fs <= 20 ? 0.82 : 1),
        text: decodeEntities(pairs[i][1]),
        ts: num(a[4], 0),
        uid: a[6] || ''
      });
    }
    return out;
  }

  /** 通用 XML：<c time="12.3" color="#fff" mode="top">文字</c> */
  function parseGenericXml(text) {
    // 只匹配「内容不含子标签」的叶子节点，避免外层 <danmaku> 吃掉内部 <c>
    var out = [], re = /<([a-zA-Z][\w-]*)\b([^>]*)>([^<]*)<\/\1\s*>/g, m;
    var allow = { d: 1, c: 1, item: 1, comment: 1, danmaku: 1, chat: 1, bullet: 1 };
    while ((m = re.exec(String(text))) !== null) {
      if (!allow[m[1].toLowerCase()]) continue;
      var attrs = {}, ar = /([\w:-]+)\s*=\s*"([^"]*)"/g, a;
      while ((a = ar.exec(m[2])) !== null) attrs[a[1].toLowerCase()] = a[2];
      var time = num(attrs.time !== undefined ? attrs.time : (attrs.t !== undefined ? attrs.t :
        (attrs.stime !== undefined ? attrs.stime : (attrs.begin !== undefined ? attrs.begin : attrs.start))), NaN);
      if (!isFinite(time)) continue;
      out.push({
        time: time,
        mode: mapMode(attrs.mode !== undefined ? attrs.mode : attrs.type, 'bili'),
        color: normColor(attrs.color !== undefined ? attrs.color : attrs.colour, '#ffffff'),
        size: attrs.fontsize ? clamp(num(attrs.fontsize, 25) / 25, 0.6, 1.8) : 1,
        text: decodeEntities(m[3].replace(/<[^>]+>/g, ''))
      });
    }
    return out;
  }

  function assTime(s) {
    var m = /^(\d+):(\d{2}):(\d{2})[.,](\d{1,3})$/.exec(String(s || '').trim());
    if (!m) return NaN;
    return (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / Math.pow(10, m[4].length);
  }

  /** ASS / SSA（含 B站导出弹幕的 \move 滚动） */
  function parseAss(text) {
    var lines = String(text).replace(/\r/g, '').split('\n');
    var fields = ['Layer', 'Start', 'End', 'Style', 'Name', 'MarginL', 'MarginR', 'MarginV', 'Effect', 'Text'];
    var textIdx = 9, inEvents = false, out = [], i;
    for (i = 0; i < lines.length; i++) {
      var line = lines[i].trim();
      if (/^\[/.test(line)) { inEvents = /^\[Events\]/i.test(line); continue; }
      if (!inEvents) continue;
      if (/^Format\s*:/i.test(line)) {
        fields = line.slice(line.indexOf(':') + 1).split(',').map(function (s) { return s.trim(); });
        textIdx = -1;
        for (var j = 0; j < fields.length; j++) if (fields[j].toLowerCase() === 'text') textIdx = j;
        if (textIdx < 0) textIdx = fields.length - 1;
        continue;
      }
      if (!/^Dialogue\s*:/i.test(line)) continue;
      var body = line.slice(line.indexOf(':') + 1).trim();
      var parts = body.split(',');
      if (parts.length <= textIdx) continue;
      var raw = parts.slice(textIdx).join(',');
      var start = assTime(parts[1]), end = assTime(parts[2]);
      if (!isFinite(start)) continue;

      var tags = '', tm, tr = /\{([^}]*)\}/g;
      while ((tm = tr.exec(raw)) !== null) tags += tm[1];
      var mode = 'bottom', color = '#ffffff', size = 1;
      if (/\\move\s*\(/i.test(tags)) mode = 'scroll';
      else if (/\\an\s*[789]\b/i.test(tags)) mode = 'top';
      else if (/\\pos\s*\(/i.test(tags)) mode = 'top';
      var cm = /\\c\s*&H([0-9a-f]{1,8})&/i.exec(tags) || /\\1c\s*&H([0-9a-f]{1,8})&/i.exec(tags);
      if (cm) color = bgrToHex(cm[1]);
      var fm = /\\fs\s*(\d+(?:\.\d+)?)/i.exec(tags);
      if (fm) size = clamp(num(fm[1], 25) / 25, 0.6, 1.8);

      var txt = raw.replace(/\{[^}]*\}/g, '')
        .replace(/\\N/gi, ' ').replace(/\\n/gi, ' ').replace(/\\h/g, ' ')
        .replace(/\s+/g, ' ').trim();
      out.push({
        time: start, mode: mode, color: color, size: size, text: txt,
        duration: isFinite(end) && end > start ? Math.min(end - start, 20) : 0
      });
    }
    return out;
  }

  function mapMode(v, style) {
    if (v === null || v === undefined || v === '') return 'scroll';
    if (typeof v === 'string') {
      var s = v.toLowerCase();
      if (/^(top|up|5|7)$/.test(s)) return 'top';
      if (/^(bottom|down|4|2)$/.test(s)) return 'bottom';
      if (/^(ltr|left|reverse|6)$/.test(s)) return 'ltr';
      if (/^(scroll|roll|right|1|3|0)$/.test(s)) return 'scroll';
      if (/^\d+$/.test(s)) v = parseInt(s, 10); else return 'scroll';
    }
    var n = parseInt(v, 10);
    if (!isFinite(n)) return 'scroll';
    if (style === 'dplayer') return n === 1 ? 'top' : (n === 2 ? 'bottom' : 'scroll');
    if (n === 4) return 'bottom';
    if (n === 5 || n === 7 || n === 8) return 'top';
    if (n === 6) return 'ltr';
    return 'scroll';
  }

  function findArray(o, depth) {
    if (Array.isArray(o)) return o;
    if (!o || typeof o !== 'object' || depth > 4) return null;
    var keys = ['danmaku', 'comments', 'data', 'list', 'items', 'dm', 'result', 'bullets', 'd'];
    for (var i = 0; i < keys.length; i++) {
      if (o[keys[i]] !== undefined) { var r = findArray(o[keys[i]], depth + 1); if (r) return r; }
    }
    return null;
  }

  /** JSON：数组对象 / DPlayer 数组 / {data:[]} 等 */
  function parseJsonDanmaku(text) {
    var obj = JSON.parse(String(text).replace(/^\uFEFF/, ''));
    var arr = findArray(obj, 0);
    if (!arr) return [];
    var out = [], i;
    for (i = 0; i < arr.length; i++) {
      var e = arr[i], item = null;
      if (Array.isArray(e)) {
        // DPlayer: [time, type, color, author, content]
        if (e.length >= 5) item = { time: num(e[0], NaN), mode: mapMode(e[1], 'dplayer'), color: normColor(e[2], '#ffffff'), text: String(e[4] === undefined ? '' : e[4]), uid: String(e[3] || '') };
        else if (e.length >= 2) item = { time: num(e[0], NaN), text: String(e[e.length - 1]) };
      } else if (e && typeof e === 'object') {
        var time = num(e.time !== undefined ? e.time : (e.timepoint !== undefined ? e.timepoint :
          (e.progress !== undefined ? e.progress : (e.t !== undefined ? e.t : (e.stime !== undefined ? e.stime : e.start)))), NaN);
        var txt = e.text !== undefined ? e.text : (e.content !== undefined ? e.content :
          (e.msg !== undefined ? e.msg : (e.m !== undefined ? e.m : (e.message !== undefined ? e.message : e.comment))));
        item = {
          time: time / 1000 > 0 && time > 100000 ? time / 1000 : time,
          mode: mapMode(e.mode !== undefined ? e.mode : (e.type !== undefined ? e.type : (e.pos !== undefined ? e.pos : e.position)), e.type !== undefined ? 'dplayer' : 'bili'),
          color: normColor(e.color !== undefined ? e.color : (e.colour !== undefined ? e.colour : e.c), '#ffffff'),
          size: e.size !== undefined ? clamp(num(e.size, 25) / 25, 0.6, 1.8) : (e.fontsize !== undefined ? clamp(num(e.fontsize, 25) / 25, 0.6, 1.8) : 1),
          text: txt === undefined || txt === null ? '' : String(txt),
          ts: num(e.ts !== undefined ? e.ts : e.ctime, 0),
          uid: String(e.uid !== undefined ? e.uid : (e.user !== undefined ? e.user : ''))
        };
      } else if (typeof e === 'string') {
        var mt = /^\s*(\d+(?:\.\d+)?)\s*[:|,]\s*(.+)$/.exec(e);
        if (mt) item = { time: num(mt[1], NaN), text: mt[2] };
      }
      if (item) out.push(item);
    }
    return out;
  }

  function subTime(s) {
    var m = /(\d{1,3}):(\d{2}):(\d{2})[.,](\d{1,3})/.exec(s);
    if (m) return (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / Math.pow(10, m[4].length);
    m = /(\d{1,3}):(\d{2})[.,](\d{1,3})/.exec(s);
    if (m) return (+m[1]) * 60 + (+m[2]) + (+m[3]) / Math.pow(10, m[3].length);
    return NaN;
  }

  /** SRT / WebVTT 字幕 → 底部弹幕 */
  function parseSrt(text) {
    var blocks = String(text).replace(/\r/g, '').replace(/^\uFEFF/, '').split(/\n{2,}/);
    var out = [], i;
    for (i = 0; i < blocks.length; i++) {
      var lines = blocks[i].split('\n'), j, start = NaN, end = NaN, body = [];
      for (j = 0; j < lines.length; j++) {
        var l = lines[j].trim();
        if (l.indexOf('-->') !== -1) {
          var seg = l.split('-->');
          start = subTime(seg[0]); end = subTime(seg[1] || '');
          continue;
        }
        if (!isFinite(start)) continue;
        if (/^\d+$/.test(l) && !body.length) continue;
        if (/^WEBVTT|^NOTE\b|^STYLE\b|^REGION\b/i.test(l)) continue;
        if (/^(?:align|position|vertical|line|size|region)\s*:/i.test(l)) continue;
        body.push(l.replace(/\s*\{\\[^}]*\}\s*/g, '').replace(/<[^>]+>/g, ''));
      }
      if (!isFinite(start) || !body.length) continue;
      out.push({
        time: start, mode: 'bottom', color: '#ffffff', size: 1,
        text: decodeEntities(body.join(' ').replace(/\s+/g, ' ').trim()),
        duration: isFinite(end) && end > start ? Math.min(end - start, 20) : 0
      });
    }
    return out;
  }

  /** 纯文本：12.5 文字 / [01:23.4]文字 */
  function parsePlain(text) {
    var out = [], lines = String(text).replace(/\r/g, '').split('\n'), i;
    for (i = 0; i < lines.length; i++) {
      var l = lines[i].trim();
      if (!l || /^[#;]/.test(l)) continue;
      var m = /^\[?(\d{1,3}):(\d{2})(?:[.:](\d{1,2}))?\]?\s*[,，:：\-]?\s*(.+)$/.exec(l);
      if (!m) continue;
      var t = (+m[1]) * 60 + (+m[2]) + (m[3] ? (+m[3]) / Math.pow(10, m[3].length) : 0);
      out.push({ time: t, mode: 'scroll', color: '#ffffff', size: 1, text: m[4].trim() });
    }
    return out;
  }

  var PARSERS = {
    'bili-xml': parseBiliXml,
    'generic-xml': parseGenericXml,
    'ass': parseAss,
    'json': parseJsonDanmaku,
    'srt': parseSrt,
    'plain': parsePlain
  };
  var FORMAT_LABEL = {
    'bili-xml': 'B站 XML', 'generic-xml': '通用 XML', 'ass': 'ASS / SSA',
    'json': 'JSON', 'srt': 'SRT / WebVTT', 'plain': '纯文本'
  };

  function normalize(items, opts, fmt, warnings) {
    var offset = num(opts.offset, 0), out = [], i;
    for (i = 0; i < items.length && out.length < MAX_ITEMS; i++) {
      var it = items[i];
      if (!it || !isFinite(num(it.time, NaN))) continue;
      var text = String(it.text === undefined || it.text === null ? '' : it.text)
        .replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
      if (!text) continue;
      if (text.length > MAX_TEXT) text = text.slice(0, MAX_TEXT) + '…';
      var mode = it.mode;
      if (mode !== 'top' && mode !== 'bottom' && mode !== 'ltr' && mode !== 'scroll') mode = 'scroll';
      out.push({
        time: Math.max(0, num(it.time, 0) + offset),
        mode: mode,
        color: normColor(it.color, '#ffffff'),
        size: clamp(num(it.size, 1), 0.55, 2),
        text: text,
        duration: clamp(num(it.duration, 0), 0, 30),
        ts: num(it.ts, 0),
        uid: String(it.uid || '')
      });
    }
    out.sort(function (a, b) { return a.time - b.time; });
    if (items.length >= MAX_ITEMS) warnings.push('弹幕数量超过 ' + MAX_ITEMS + ' 条，已截断');
    return {
      format: fmt,
      label: FORMAT_LABEL[fmt] || fmt,
      items: out,
      total: out.length,
      warnings: warnings
    };
  }

  /** 对外主入口：parse(text, { hint, format, offset }) */
  function parse(text, opts) {
    opts = opts || {};
    var raw = String(text == null ? '' : text).replace(/^\uFEFF/, '');
    var forced = opts.format && opts.format !== 'auto' ? String(opts.format).toLowerCase() : '';
    if (forced === 'xml') forced = 'bili-xml';
    var fmt = forced || detectFormat(raw, opts.hint || '');
    var failures = {}, picked = null;

    function run(f) {
      if (!PARSERS[f]) return [];
      try { return PARSERS[f](raw) || []; }
      catch (e) { failures[f] = FORMAT_LABEL[f] + ' 解析失败：' + e.message; return []; }
    }

    if (forced) {
      picked = { f: fmt, list: run(fmt) };
      if (!picked.list.length && (fmt === 'bili-xml' || fmt === 'generic-xml')) {
        var other = fmt === 'bili-xml' ? 'generic-xml' : 'bili-xml';
        var alt = run(other);
        if (alt.length) picked = { f: other, list: alt };
      }
    } else {
      var order = [fmt], all = ['bili-xml', 'generic-xml', 'ass', 'json', 'srt', 'plain'], k;
      for (k = 0; k < all.length; k++) if (order.indexOf(all[k]) === -1) order.push(all[k]);
      for (k = 0; k < order.length; k++) {
        var list = run(order[k]);
        if (list.length) { picked = { f: order[k], list: list }; break; }
      }
      if (!picked) picked = { f: fmt, list: [] };
    }
    var warnings = [];
    if (failures[picked.f]) warnings.push(failures[picked.f]);
    if (!forced && picked.f !== fmt) warnings.push('格式自动识别为「' + (FORMAT_LABEL[picked.f] || picked.f) + '」');
    return normalize(picked.list, opts, picked.f, warnings);
  }

  /* ============================================================
     三、播放器
     ============================================================ */

  function Player(host, options) {
    if (!(this instanceof Player)) return new Player(host, options);
    this.host = host;
    this.opts = mix(DEFAULTS, CFG.defaults, options || {});
    if (!this.opts.api && CFG.api) this.opts.api = CFG.api;
    if (!this.opts.base && CFG.base) this.opts.base = CFG.base;
    this.settings = mix({
      opacity: this.opts.opacity, fontSize: this.opts.fontSize, area: this.opts.area,
      duration: this.opts.duration, hold: this.opts.hold, bold: this.opts.bold,
      stroke: this.opts.stroke, overlap: this.opts.overlap,
      on: this.opts.danmaku, rate: 1
    }, this.opts.storage ? readStore(STORE_SETTINGS, {}) : {});

    this.items = [];
    this.userItems = [];
    this.meta = { format: '—', total: 0, warnings: [] };
    this.active = [];
    this.pending = [];
    this.scrollTracks = [];
    this.topTracks = [];
    this.bottomTracks = [];
    this.idx = 0;
    this.lastT = -1;
    this.lastFrame = 0;
    this.vtime = 0;
    this.vduration = 60;
    // 初始为纯弹幕时间轴；视频地址解析成功并挂载 <video> 后切为视频驱动
    this.virtual = true;
    this.stageW = 0;
    this.stageH = 0;
    this.toastTimer = 0;
    this.players = [];
    /* 视频解析配置 */
    this.pc = mix({
      enabled: true, default: 'direct', apis: [], proxy: 'auto',
      hls: 'local', hlsUrl: '', cdn: [], demo: {}
    }, PARSE_CFG);
    // 独立预览页里用户自己添加的解析接口（CMS 环境下不会下发模板）
    try {
      var localApis = JSON.parse((global.localStorage && global.localStorage.getItem('mdk.parse.local')) || '[]');
      if (Array.isArray(localApis) && localApis.length) {
        this.pc.apis = (this.pc.apis || []).concat(localApis);
      }
    } catch (e) {}
    this.parseKey = this.opts.parse || this.pc.default || 'direct';
    this.srcUrl = this.opts.src || '';
    this.playUrl = '';
    this.playType = '';
    this.playMeta = {};
    this.hls = null;
    this.tryProxy = false;
    this.userKey = STORE_USER + hashKey(this.opts.src + '|' + this.opts.dm + '|' + this.opts.bili);
    this._tick = this.tick.bind(this);
    this.init();
  }

  Player.prototype = {

    init: function () {
      this.build();
      this.bind();
      this.syncSize();
      this.setAccent();
      if (this.opts.src) this.setSource(this.opts.src, {
        quiet: true, silent: true, parse: this.parseKey, proxy: this.opts.proxy, type: this.opts.type
      });
      if (this.opts.dm) this.loadUrls(String(this.opts.dm).split('|'));
      else if (this.opts.bili) this.resolveBili(this.opts.bili, true);
      else this.setItems([], { format: '—', total: 0, warnings: [] });
      this.restoreUser();
      this.updateUI();
      if (global.requestAnimationFrame) global.requestAnimationFrame(this._tick);
    },

    /* ---------- DOM 构建 ---------- */
    build: function () {
      var o = this.opts;
      var root = h('div', 'mdk');
      root.tabIndex = 0;
      root.setAttribute('data-theme', o.theme || 'dark');
      if (o.title) root.setAttribute('aria-label', o.title);

      var wrap = h('div', 'mdk-wrap');
        var media = h('div', 'mdk-media');
        // 先放占位层；视频地址解析成功后再由 ensureVideo() 创建 <video>，
        // 这样解析 / HLS 库加载期间不会黑屏，失败时也能退回纯弹幕时间轴。
        var ph = h('div', 'mdk-placeholder');
        if (o.poster) ph.style.backgroundImage = 'url("' + String(o.poster).replace(/["\\]/g, '') + '")';
        ph.appendChild(h('div', 'mdk-ph-icon', '✦'));
        ph.appendChild(h('div', 'mdk-ph-title', o.title || (o.src ? '正在载入视频' : '弹幕预览')));
        ph.appendChild(h('div', 'mdk-ph-hint', o.src ? '正在解析视频地址…' : '纯弹幕时间轴模式 · 可在「弹幕源」中载入文件'));
        media.appendChild(ph);
        this.placeholder = ph;
        this.media = media;
      var stage = h('div', 'mdk-stage');
      this.stage = stage;
      var center = h('button', 'mdk-center', '▶');
      center.type = 'button';
      center.setAttribute('aria-label', '播放 / 暂停');
      this.center = center;
      var toast = h('div', 'mdk-toast');
      this.toastEl = toast;

      wrap.appendChild(media);
      wrap.appendChild(stage);
      wrap.appendChild(center);
      wrap.appendChild(toast);
      this.wrap = wrap;
      root.appendChild(wrap);

      /* 控制条 */
      var bar = h('div', 'mdk-bar');
      this.btnPlay = this.iconBtn(bar, '▶', '播放 / 暂停 (空格)');
      this.timeEl = h('span', 'mdk-time', '00:00 / 00:00');
      bar.appendChild(this.timeEl);

      var prog = h('div', 'mdk-prog');
      prog.setAttribute('role', 'slider');
      prog.setAttribute('aria-label', '播放进度');
      this.progBuf = h('div', 'mdk-prog-buf');
      this.progPlay = h('div', 'mdk-prog-play');
      this.progDot = h('div', 'mdk-prog-dot');
      prog.appendChild(this.progBuf); prog.appendChild(this.progPlay); prog.appendChild(this.progDot);
      bar.appendChild(prog);
      this.prog = prog;

      this.btnMute = this.iconBtn(bar, '🔊', '静音 (M)');
      var vol = h('input', 'mdk-vol');
      vol.type = 'range'; vol.min = 0; vol.max = 1; vol.step = 0.05; vol.value = 1;
      vol.setAttribute('aria-label', '音量');
      bar.appendChild(vol);
      this.vol = vol;

      var rate = h('select', 'mdk-rate');
      [0.5, 0.75, 1, 1.25, 1.5, 2].forEach(function (r) {
        var op = h('option', '', r === 1 ? '1.0x 正常' : r + 'x');
        op.value = String(r); rate.appendChild(op);
      });
      rate.value = String(this.settings.rate || 1);
      rate.title = '播放速度';
      bar.appendChild(rate);
      this.rateEl = rate;

      this.btnDm = this.iconBtn(bar, '弹', '显示 / 隐藏弹幕 (D)', 'mdk-on');
      this.btnDm.classList.add('mdk-btn-text');
      if (this.opts.allowSend) this.iconBtn(bar, '✎', '发送弹幕', 'mdk-btn-send');
        if (this.opts.allowList) this.iconBtn(bar, '☰', '弹幕列表', 'mdk-btn-list');
        if (this.pc.enabled !== false) this.iconBtn(bar, '🔗', '视频源 / 解析地址 (U)', 'mdk-btn-link');
        this.iconBtn(bar, '⚙', '设置', 'mdk-btn-cfg');
      this.iconBtn(bar, '⛶', '全屏 (F)', 'mdk-btn-fs');
      root.appendChild(bar);

      /* 发送栏 */
      if (this.opts.allowSend) {
        var send = h('div', 'mdk-send');
        var mode = h('select', 'mdk-send-mode');
        [['scroll', '滚动'], ['top', '顶部'], ['bottom', '底部']].forEach(function (p) {
          var op = h('option', '', p[1]); op.value = p[0]; mode.appendChild(op);
        });
        var color = h('input', 'mdk-send-color');
        color.type = 'color'; color.value = '#ffffff'; color.title = '弹幕颜色';
        var input = h('input', 'mdk-send-input');
        input.type = 'text'; input.maxLength = 120; input.placeholder = '发个弹幕见证此刻…（回车发送）';
        var btn = h('button', 'mdk-send-btn', '发送'); btn.type = 'button';
        send.appendChild(mode); send.appendChild(color); send.appendChild(input); send.appendChild(btn);
        root.appendChild(send);
        this.sendMode = mode; this.sendColor = color; this.sendInput = input; this.sendBtn = btn;
      }

      /* 面板 */
      this.panel = h('div', 'mdk-panel');
      this.panel.hidden = true;
      root.appendChild(this.panel);

      root.style.setProperty('--mdk-accent', o.accent || DEFAULTS.accent);
      var ratio = String(o.ratio || '16:9').split(':');
      var rw = num(ratio[0], 16), rh = num(ratio[1], 9);
      wrap.style.paddingTop = (clamp(rh / (rw || 16), 0.3, 1.2) * 100) + '%';

      this.root = root;
      this.host.innerHTML = '';
      this.host.appendChild(root);
      this.host.classList.add('mdk-host');
      if (doc && global.HTMLCanvasElement) this.measureCtx = doc.createElement('canvas').getContext('2d');
    },

    iconBtn: function (parent, label, title, cls) {
      var b = h('button', 'mdk-btn ' + (cls || ''), label);
      b.type = 'button'; b.title = title || label; b.setAttribute('aria-label', title || label);
      parent.appendChild(b);
      return b;
    },

      setAccent: function () { this.root.style.setProperty('--mdk-accent', this.opts.accent || DEFAULTS.accent); },

      /* ---------- 视频源：解析 / HLS / 换源 ---------- */

      apis: function () {
        var a = this.opts.api || CFG.api;
        return Array.isArray(a) ? a : (a ? [a] : []);
      },
      hasServer: function () { return this.apis().length > 0; },

      bindVideo: function (v) {
        var self = this;
        on(v, 'loadedmetadata', function () { self.updateUI(); self.resync(num(v.currentTime, 0)); });
        on(v, 'durationchange', function () { self.updateUI(); });
        on(v, 'timeupdate', function () { self.updateUI(); });
        on(v, 'play', function () { self.updateUI(); });
        on(v, 'pause', function () { self.updateUI(); });
        on(v, 'ended', function () { self.updateUI(); });
        on(v, 'progress', function () {
          if (v.buffered && v.buffered.length && v.duration) {
            self.progBuf.style.width = clamp(v.buffered.end(v.buffered.length - 1) / v.duration, 0, 1) * 100 + '%';
          }
        });
        on(v, 'error', function () {
          if (!self.autoProxyRetry()) self.toast('视频加载失败，可换源或继续纯弹幕预览');
        });
        try { v.playbackRate = this.settings.rate || 1; } catch (e) {}
        if (this.opts.autoplay) { var p = v.play(); if (p && p.catch) p.catch(function () {}); }
      },

      /** 首次成功解析后创建 <video> 并移除占位层 */
      ensureVideo: function () {
        if (this.video) return this.video;
        var o = this.opts, v = h('video', 'mdk-video');
        v.playsInline = true;
        v.setAttribute('playsinline', '');
        v.setAttribute('webkit-playsinline', '');
        v.preload = 'metadata';
        if (o.poster) v.poster = o.poster;
        if (o.loop) v.loop = true;
        if (o.muted || o.autoplay) v.muted = true;
        this.media.insertBefore(v, this.media.firstChild);
        if (this.placeholder && this.placeholder.parentNode) this.placeholder.parentNode.removeChild(this.placeholder);
        this.placeholder = null;
        this.video = v;
        this.virtual = false;   // 时间轴改由 video.currentTime 驱动
        this.vtime = 0;
        this.lastT = -1;
        this.bindVideo(v);
        return v;
      },

      destroyHls: function () {
        if (this.hls) { try { this.hls.destroy(); } catch (e) {} this.hls = null; }
      },

      /** 把可播放地址挂到 <video>：m3u8 走 hls.js（Safari 走原生），其余直接 src */
      attach: function (url, type, meta) {
        var self = this, v, nativeHls = false, token = this.srcToken;
        if (!url) return;
        this.destroyHls();
        v = this.ensureVideo();
        this.playUrl = url;
        this.playType = type;
        this.playMeta = meta || {};
        try { nativeHls = !!(v.canPlayType && v.canPlayType('application/vnd.apple.mpegurl')); } catch (e) {}
        function autoPlay() {
          if (!self.opts.autoplay && !(self.playMeta && self.playMeta.autoplay)) return;
          var p = v.play(); if (p && p.catch) p.catch(function () {});
        }
        if (type === 'hls' && !nativeHls) {
          loadHls(function (Hls) {
            if (token !== self.srcToken) return;             // 期间又换了源，丢弃旧回调
            if (!Hls || !Hls.isSupported || !Hls.isSupported()) {
              if (!self.autoProxyRetry()) self.toast('当前浏览器不支持 HLS 播放');
              return;
            }
            var h = new Hls({ enableWorker: true, lowLatencyMode: false, maxBufferLength: 20 });
            self.hls = h;
            h.on(Hls.Events.ERROR, function (_, data) {
              if (!data || !data.fatal || token !== self.srcToken) return;
              if (data.type === Hls.ErrorTypes.NETWORK_ERROR) { try { h.startLoad(); } catch (e) {} return; }
              if (data.type === Hls.ErrorTypes.MEDIA_ERROR) { try { h.recoverMediaError(); } catch (e) {} return; }
              if (!self.autoProxyRetry()) self.toast('HLS 播放失败：' + (data.details || '未知错误'));
            });
            try {
              h.loadSource(url);
              h.attachMedia(v);
              autoPlay();
            } catch (e) {
              if (!self.autoProxyRetry()) self.toast('HLS 初始化失败：' + e.message);
            }
          }, function () {
            if (token !== self.srcToken) return;
            if (!self.autoProxyRetry()) self.toast('m3u8 解码库加载失败，请检查插件内置 hls.min.js 或改用 mp4');
          });
        } else {
          try { v.src = url; } catch (e) {}
          autoPlay();
        }
        this.updateUI();
        if (!this.playMeta.silent) {
          this.toast('已切换视频源 · ' + streamLabel(type) + (this.playMeta.proxied ? ' · 服务端代理' : ''));
        }
        this.updateSourceInfo();
      },

      /** 直连失败时自动改用服务端代理重试一次 */
      autoProxyRetry: function () {
        if (this.tryProxy || !this.srcUrl || !this.hasServer()) return false;
        if (this.playMeta && this.playMeta.proxied) return false;
        this.tryProxy = true;
        this.toast('直连失败，正在改用服务端代理…');
        this.setSource(this.srcUrl, {
          quiet: true, silent: true, retry: true, parse: this.parseKey, proxy: 'on'
        });
        return true;
      },

      /** 入口：短代码 src / 换源面板都走这里 */
      setSource: function (input, opt) {
        var self = this;
        opt = opt || {};
        input = String(input || '').trim();
        if (!input) return this.toast('请填入视频地址');
        var key = opt.parse || this.parseKey || 'direct';
        var proxy = opt.proxy || this.opts.proxy || '';
        var forcedType = opt.type && opt.type !== 'auto' ? opt.type : '';
        var type = forcedType || sniffStream(input);
        this.parseKey = key;
        this.srcUrl = input;
        this.opts.src = input;
        if (!opt.retry) this.tryProxy = false;
        this.srcToken = (this.srcToken || 0) + 1;
        var token = this.srcToken;
        if (this.pc.enabled === false && type === 'page') return this.toast('站点已关闭视频地址解析');

        if (this.hasServer()) {
          if (!opt.quiet) this.toast('正在解析视频地址…');
          var qs = 'action=resolve&url=' + encodeURIComponent(input)
                 + '&api=' + encodeURIComponent(key)
                 + (proxy ? '&proxy=' + encodeURIComponent(proxy) : '');
          callApi(this.apis(), qs, function (j) {
            if (token !== self.srcToken) return;
            if (!j.ok) return self.toast('解析失败：' + (j.error || '未知错误'));
            if (j.type === 'page') return self.toast('这是网页而非视频直链：' + (j.hint || '请选择解析接口'));
            self.attach(j.play, forcedType || j.type, {
              input: input, parse: key, proxy: proxy, proxied: !!j.proxied,
              target: j.target, via: j.via, silent: !!opt.silent
            });
          }, function () {
            if (token !== self.srcToken) return;
            self.resolveLocal(input, type, key, opt);
          });
        } else {
          this.resolveLocal(input, type, key, opt);
        }
      },

      /** 无服务端（独立预览）时的本地处理：直链直接播，网页地址可用本地模板试解析 */
      resolveLocal: function (input, type, key, opt) {
        var self = this;
        if (type !== 'page') {
          return this.attach(input, type, {
            input: input, parse: key, proxied: false, silent: !!(opt && opt.silent)
          });
        }
        var list = this.pc.apis || [], tpl = '', i;
        for (i = 0; i < list.length; i++) if (list[i].id === key && list[i].tpl) tpl = String(list[i].tpl);
        if (!tpl) return this.toast('影视播放页需要解析接口：请在 CMS 后台「视频解析地址」配置，或改填 m3u8 / mp4 直链');
        var endpoint = tpl.replace(/\{url\}/g, encodeURIComponent(input)).replace(/\{url_raw\}/g, input);
        this.toast('正在调用自定义解析地址…');
        fetch(endpoint).then(function (r) { return r.text(); }).then(function (txt) {
          var s = String(txt).replace(/\\\//g, '/');
          var m = s.match(/https?:\/\/[^\s"'<>\\)]+?\.m3u8[^\s"'<>]*|https?:\/\/[^\s"'<>\\)]+?\.mp4[^\s"'<>]*/i);
          if (!m) return self.toast('解析地址未返回 m3u8/mp4 直链（可能返回的是播放页）');
          self.attach(m[0], sniffStream(m[0]), {
            input: input, parse: key, proxied: false, silent: !!(opt && opt.silent), via: '本地自定义解析'
          });
        }).catch(function () {
          self.toast('自定义解析地址请求失败（多为浏览器 CORS 限制），请在 CMS 插件环境下用服务端解析');
        });
      },

      updateSourceInfo: function () {
        if (!this.srcInfoEl) return;
        var s = this.playUrl
          ? '当前：' + streamLabel(this.playType) + ' · ' + (this.playMeta.via || '内置直连')
            + (this.playMeta.proxied ? ' · 服务端代理' : ' · 直连') + '\n' + this.playUrl
          : '当前：纯弹幕时间轴（未载入视频）';
        this.srcInfoEl.textContent = s;
      },

      /* ---------- 事件绑定 ---------- */
    bind: function () {
      var self = this, o = this.opts;

      on(this.btnPlay, 'click', function () { self.toggle(); });
      on(this.center, 'click', function () { self.toggle(); });
      on(this.media, 'click', function () { self.toggle(); });
      on(this.btnDm, 'click', function () { self.toggleDanmaku(); });
      on(this.btnMute, 'click', function () {
        if (!self.video) return self.toast('纯弹幕模式无音轨');
        self.video.muted = !self.video.muted; self.updateUI();
      });
      on(this.vol, 'input', function () {
        if (!self.video) return;
        self.video.volume = num(this.value, 1); self.video.muted = false; self.updateUI();
      });
      on(this.rateEl, 'change', function () {
        self.settings.rate = num(this.value, 1);
        if (self.video) self.video.playbackRate = self.settings.rate;
        self.saveSettings();
      });

      /* 进度条拖动 */
      var dragging = false;
      function ratioOf(e) {
        var r = self.prog.getBoundingClientRect();
        return clamp((e.clientX - r.left) / (r.width || 1), 0, 1);
      }
      on(this.prog, 'pointerdown', function (e) {
        dragging = true; self.prog.setPointerCapture && self.prog.setPointerCapture(e.pointerId);
        self.seek(ratioOf(e) * self.duration()); e.preventDefault();
      });
      on(this.prog, 'pointermove', function (e) { if (dragging) self.seek(ratioOf(e) * self.duration()); });
      on(this.prog, 'pointerup', function () { dragging = false; });
      on(this.prog, 'pointercancel', function () { dragging = false; });

      /* 全屏 */
      var fsBtn = this.root.querySelector('.mdk-btn-fs');
      on(fsBtn, 'click', function () {
        var r = self.root;
        if (doc.fullscreenElement || doc.webkitFullscreenElement) {
          (doc.exitFullscreen || doc.webkitExitFullscreen).call(doc);
        } else if (r.requestFullscreen) r.requestFullscreen();
        else if (r.webkitRequestFullscreen) r.webkitRequestFullscreen();
        else self.toast('当前浏览器不支持全屏');
      });

      /* 面板按钮 */
      on(this.root.querySelector('.mdk-btn-cfg'), 'click', function () { self.openPanel('settings'); });
        var lb = this.root.querySelector('.mdk-btn-list');
        if (lb) on(lb, 'click', function () { self.openPanel('list'); });
        var lnk = this.root.querySelector('.mdk-btn-link');
        if (lnk) on(lnk, 'click', function () { self.openPanel('source'); });
      var sb = this.root.querySelector('.mdk-btn-send');
      if (sb) on(sb, 'click', function () { if (self.sendInput) { self.sendInput.focus(); self.toast('输入内容后回车发送'); } });

      /* 发送 */
      if (this.sendBtn) {
        on(this.sendBtn, 'click', function () { self.send(); });
        on(this.sendInput, 'keydown', function (e) {
          if (e.key === 'Enter') { e.preventDefault(); self.send(); }
          e.stopPropagation();
        });
      }

      /* 键盘 */
      on(this.root, 'keydown', function (e) {
        var k = e.key.toLowerCase();
        if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
        if (k === ' ' || k === 'k') { e.preventDefault(); self.toggle(); }
        else if (k === 'arrowleft') { e.preventDefault(); self.seek(self.currentTime() - 5); }
        else if (k === 'arrowright') { e.preventDefault(); self.seek(self.currentTime() + 5); }
        else if (k === 'f') { var b = self.root.querySelector('.mdk-btn-fs'); if (b) b.click(); }
        else if (k === 'd') { self.toggleDanmaku(); }
          else if (k === 'm') { self.btnMute.click(); }
          else if (k === 'u') { var l = self.root.querySelector('.mdk-btn-link'); if (l) l.click(); }
          else if (k === 'escape') { self.closePanel(); }
      });

        /* 视频事件（换源后新建的 <video> 也走同一套绑定） */
        if (this.video) this.bindVideo(this.video);

      /* 拖放弹幕文件 */
      on(this.wrap, 'dragover', function (e) { e.preventDefault(); self.wrap.classList.add('mdk-drag'); });
      on(this.wrap, 'dragleave', function () { self.wrap.classList.remove('mdk-drag'); });
      on(this.wrap, 'drop', function (e) {
        e.preventDefault(); self.wrap.classList.remove('mdk-drag');
        if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) self.readFile(e.dataTransfer.files[0]);
      });

      /* 尺寸变化 */
      if (global.ResizeObserver) {
        this.ro = new global.ResizeObserver(function () { self.syncSize(); });
        this.ro.observe(this.wrap);
      } else on(global, 'resize', function () { self.syncSize(); });
    },

    /* ---------- 时间轴 ---------- */
    currentTime: function () { return this.video ? num(this.video.currentTime, 0) : this.vtime; },
    duration: function () {
      if (this.video && isFinite(this.video.duration) && this.video.duration > 0) return this.video.duration;
      if (this.video) return Math.max(60, this.lastItemTime() + 10);
      return Math.max(this.vduration, this.lastItemTime() + 10);
    },
    lastItemTime: function () { return this.items.length ? this.items[this.items.length - 1].time : 0; },
    isPlaying: function () { return this.video ? (!this.video.paused && !this.video.ended) : this.playingVirtual; },

    toggle: function () {
      if (this.video) {
        if (this.video.paused) { var p = this.video.play(); if (p && p.catch) p.catch(function () {}); }
        else this.video.pause();
        } else {
          this.playingVirtual = !this.playingVirtual;
          if (this.playingVirtual && this.vtime >= this.duration() - 0.05) this.vtime = 0;
          // 开始播放后淡出占位文字，避免和弹幕叠在一起
          if (this.playingVirtual && this.root) this.root.classList.add('mdk-started');
          this.updateUI();
        }
      },
    seek: function (t) {
      t = clamp(num(t, 0), 0, this.duration());
      if (this.video) { try { this.video.currentTime = t; } catch (e) { /* 元数据未就绪 */ } }
      else this.vtime = t;
      this.resync(t);
      this.updateUI();
    },

    tick: function (ts) {
      var dt = this.lastFrame ? clamp((ts - this.lastFrame) / 1000, 0, 0.25) : 0;
      this.lastFrame = ts;
      if (this.virtual && this.isPlaying()) {
        this.vtime += dt * this.settings.rate;
        if (this.vtime >= this.duration()) {
          if (this.opts.loop) { this.vtime = 0; this.resync(0); }
          else { this.vtime = this.duration(); this.playingVirtual = false; this.updateUI(); }
        }
      }
      var t = this.currentTime();
      if (this.lastT < 0 || t < this.lastT - 0.25 || t > this.lastT + 1.6) this.resync(t);
      this.lastT = t;

      if (this.settings.on) {
        var i, p;
        for (i = this.pending.length - 1; i >= 0; i--) {
          p = this.pending[i];
          if (t > p.until || this.spawn(p.item, t)) this.pending.splice(i, 1);
        }
        while (this.idx < this.items.length && this.items[this.idx].time <= t + 0.02) {
          var it = this.items[this.idx++];
          if (!this.spawn(it, t)) this.pending.push({ item: it, until: t + 0.7 });
        }
      }
      this.updateActive(t);
      if (this.virtual && this.isPlaying()) this.updateProgress();
      if (global.requestAnimationFrame) global.requestAnimationFrame(this._tick);
    },

    syncSize: function () {
      if (!this.wrap) return;
      this.stageW = this.wrap.clientWidth || this.stage.clientWidth || 640;
      this.stageH = this.wrap.clientHeight || this.stage.clientHeight || 360;
    },

    resync: function (t) {
      this.stage.textContent = '';
      this.active = [];
      this.pending = [];
      this.scrollTracks = [];
      this.topTracks = [];
      this.bottomTracks = [];
      this.idx = lowerBound(this.items, t - 0.02);
      this.lastT = t;
      this.syncSize();
    },

    /* ---------- 弹幕渲染 ---------- */
    measure: function (text, font) {
      if (!this.measureCtx) return Math.max(40, text.length * 16);
      this.measureCtx.font = font;
      return this.measureCtx.measureText(text).width + 12;
    },

    makeNode: function (item) {
      var size = Math.round(clamp(this.settings.fontSize * item.size, 10, 64));
      var font = (this.settings.bold ? '700 ' : '500 ') + size + 'px ' + FONT_STACK;
      var width = this.measure(item.text, font);
      var n = h('div', 'mdk-dm mdk-dm-' + item.mode, item.text);
      n.style.font = font;
      n.style.color = item.color;
      n.style.opacity = String(this.settings.opacity);
      n.style.position = 'absolute';
      n.style.whiteSpace = 'nowrap';
      n.style.pointerEvents = 'none';
      n.style.willChange = 'transform';
      n.style.lineHeight = '1.25';
      if (this.settings.stroke) {
        n.style.textShadow = '0 1px 2px rgba(0,0,0,.95), 0 0 1px rgba(0,0,0,.9), 1px 0 1px rgba(0,0,0,.8), -1px 0 1px rgba(0,0,0,.8)';
        n.style.webkitTextStroke = '0.5px rgba(0,0,0,.65)';
      }
      this.stage.appendChild(n);
      return { node: n, width: width, lineH: Math.ceil(size * 1.35) };
    },

    spawn: function (item, t) {
      var d = this.makeNode(item);
      var lineH = d.lineH, W = this.stageW, H = this.stageH;
      var count = Math.max(1, Math.floor(clamp(H * this.settings.area / lineH, 1, 40)));
      var pxPerSec = (W + 260) / clamp(this.settings.duration, 2, 30);
      var i, found = -1, last, d2;

      if (item.mode === 'scroll' || item.mode === 'ltr') {
        if (this.scrollTracks.length !== count) {
          var old = this.scrollTracks;
          this.scrollTracks = [];
          for (i = 0; i < count; i++) this.scrollTracks[i] = old[i] || null;
        }
        var best = -1, bestFree = Infinity;
        for (i = 0; i < count; i++) {
          last = this.scrollTracks[i];
          var freeAt = last ? last.t + (last.w + GAP) / pxPerSec : -Infinity;
          if (freeAt <= t) { found = i; break; }
          if (freeAt < bestFree) { bestFree = freeAt; best = i; }
        }
        if (found < 0) {
          if (!this.settings.overlap) { d.node.remove(); return false; }
          found = best >= 0 ? best : 0;
        }
        this.scrollTracks[found] = { t: t, w: d.width };
        d.node.style.top = (found * lineH) + 'px';
        d.node.style.left = '0px';
        d.t = t;
        d.mode = item.mode;
        d.startX = item.mode === 'ltr' ? -d.width : W;
        d.dir = item.mode === 'ltr' ? 1 : -1;
        d.speed = pxPerSec;
        d.exitT = t + (W + d.width + 40) / pxPerSec;
        d.node.style.transform = 'translate3d(' + d.startX.toFixed(1) + 'px,0,0)';
      } else {
        var tracks = item.mode === 'top' ? this.topTracks : this.bottomTracks;
        var hold = clamp(item.duration || this.settings.hold, 1.2, 30);
        if (tracks.length !== count) {
          var old2 = tracks;
          for (i = 0; i < old2.length; i++) tracks[i] = old2[i];
          tracks.length = count;
        }
        for (i = 0; i < count; i++) if (!tracks[i] || tracks[i] <= t) { found = i; break; }
        if (found < 0) {
          if (!this.settings.overlap) { d.node.remove(); return false; }
          found = 0;
        }
        tracks[found] = t + hold;
        var y = item.mode === 'top'
          ? found * lineH
          : Math.max(0, H - (found + 1) * lineH);
        d.node.style.top = y + 'px';
        d.node.style.left = '50%';
        d.node.style.transform = 'translateX(-50%)';
        d.mode = item.mode;
        d.exitT = t + hold;
      }
      d.item = item;
      this.active.push(d);
      return true;
    },

    updateActive: function (t) {
      for (var i = this.active.length - 1; i >= 0; i--) {
        var d = this.active[i];
        if (t >= d.exitT || !d.node.parentNode) {
          if (d.node.parentNode) d.node.remove();
          this.active.splice(i, 1);
          continue;
        }
        if (d.mode === 'scroll' || d.mode === 'ltr') {
          var x = d.startX + d.dir * (t - d.t) * d.speed;
          d.node.style.transform = 'translate3d(' + x.toFixed(1) + 'px,0,0)';
        }
      }
    },

    toggleDanmaku: function () {
      this.settings.on = !this.settings.on;
      this.saveSettings();
      this.resync(this.currentTime());
      this.updateUI();
      this.toast(this.settings.on ? '弹幕已开启' : '弹幕已关闭');
    },

    /* ---------- 数据载入 ---------- */
    resolveUrl: function (u) {
      u = String(u || '').trim();
      if (!u) return '';
      if (/^(https?:)?\/\//i.test(u) || /^data:/i.test(u) || /^blob:/i.test(u)) return u;
      if (u.charAt(0) === '/') return u;
      var base = this.opts.base || (global.location ? global.location.href : '');
      try { return new global.URL(u, base).href; } catch (e) { return u; }
    },

    parseOpts: function (hint) {
      var o = { hint: hint || '', offset: this.opts.offset };
      if (this.opts.format && this.opts.format !== 'auto') o.format = this.opts.format;
      return o;
    },

    loadUrls: function (list) {
      var self = this, all = [], left = list.length, warns = [], label = '';
      list = list.filter(function (u) { return String(u || '').trim() !== ''; });
      if (!list.length) return;
      this.toast('正在载入弹幕…');
      list.forEach(function (u) {
        var url = self.resolveUrl(u);
        fetch(url).then(function (r) {
          if (!r.ok) throw new Error('HTTP ' + r.status);
          return r.text();
        }).then(function (txt) {
          var res = parse(txt, self.parseOpts(url));
          all = all.concat(res.items);
          label = res.label;
          warns = warns.concat(res.warnings);
        }).catch(function (e) {
          warns.push('载入失败 ' + url + '：' + e.message + '（可尝试拖入本地文件）');
        }).then(function () {
          if (--left === 0) self.setItems(all, { format: label || '已合并', total: all.length, warnings: warns });
        });
      });
    },

    readFile: function (file) {
      var self = this;
      if (file.size > 12 * 1024 * 1024) return this.toast('文件过大（上限 12MB）');
      var fr = new global.FileReader();
      fr.onload = function () {
        self.applyText(decodeBuffer(fr.result), file.name);
        self.toast('已载入 ' + file.name);
      };
      fr.onerror = function () { self.toast('文件读取失败'); };
      fr.readAsArrayBuffer(file);
    },

    applyText: function (text, hint) {
      var res = parse(text, this.parseOpts(hint));
      this.setItems(res.items, res);
      return res;
    },

    setItems: function (items, meta) {
      this.items = (items || []).concat(this.userItems).slice(0, MAX_ITEMS);
      this.items.sort(function (a, b) { return a.time - b.time; });
      this.meta = meta || { format: '—', total: this.items.length, warnings: [] };
      this.vduration = Math.max(60, Math.ceil(this.lastItemTime() + 12));
      this.resync(this.currentTime());
      this.updateUI();
      var w = (this.meta.warnings || []).join('；');
      this.toast('已载入 ' + this.items.length + ' 条弹幕 · ' + (this.meta.label || this.meta.format || '—') + (w ? ' · ' + w : ''));
      if (this.panel && !this.panel.hidden && this.panelMode === 'list') this.openPanel('list');
    },

    parseBiliValue: function (v) {
      var s = String(v || '').trim(), q = {}, bv = /BV[0-9A-Za-z]{10,12}/.exec(s), av = /(?:^|\/|av)(?:av)?(\d{6,})/i.exec(s);
      var cid = /(?:cid|oid)\s*[=:]\s*(\d{3,})/i.exec(s);
      var pg = /(?:[?&]p=|\/p=|第)(\d{1,3})/i.exec(s);
      if (bv) q.bvid = bv[0];
      else if (av) q.aid = av[1];
      if (!q.bvid && !q.aid && /^\d{3,}$/.test(s)) q.cid = s;
      if (cid && !q.cid) q.cid = cid[1];
      if (pg) q.p = clamp(parseInt(pg[1], 10), 1, 100);
      return q;
    },

      resolveBili: function (value, quiet) {
        var self = this, q = this.parseBiliValue(value);
        if (!this.opts.allowBili) return this.toast('站点未开启 B 站弹幕解析');
        if (!q.bvid && !q.aid && !q.cid) return this.toast('未识别到 BV号 / av号 / CID');
        if (!quiet) this.toast('正在解析 B 站弹幕…');

        // 服务端解析通道可以有多个：核心入口优先，独立 api.php 兜底
        var apis = this.opts.api;
        if (!Array.isArray(apis)) apis = apis ? [apis] : [];
        var qs = [], k;
        for (k in q) if (Object.prototype.hasOwnProperty.call(q, k)) qs.push(encodeURIComponent(k) + '=' + encodeURIComponent(q[k]));
        qs.unshift('action=bili');

        function accept(j) {
          var res = self.applyText(j.raw || '', 'danmaku.xml');
          if (!res.total) self.toast('解析成功但该视频暂无弹幕');
          else self.toast('解析成功 · ' + res.total + ' 条弹幕' + (j.title ? ' · ' + j.title : ''));
        }
        function direct() {
          if (!q.cid) {
            self.toast('缺少服务端解析通道；请填写 CID、上传弹幕文件，或在 CMS 插件环境下使用');
            return;
          }
          fetch('https://api.bilibili.com/x/v1/dm/list.so?oid=' + q.cid).then(function (r) { return r.text(); }).then(function (txt) {
            var res = self.applyText(txt, 'danmaku.xml');
            self.toast(res.total ? '解析成功 · ' + res.total + ' 条弹幕' : '未取到弹幕');
          }).catch(function () { self.toast('浏览器直连被 CORS 拦截，请上传弹幕文件或在 CMS 插件环境下使用'); });
        }
        function attempt(i) {
          if (i >= apis.length) return direct();
          var base = String(apis[i]);
          var url = base + (base.indexOf('?') === -1 ? '?' : '&') + qs.join('&');
          fetch(url, { credentials: 'same-origin' }).then(function (r) {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.text();
          }).then(function (txt) {
            var j;
            try { j = JSON.parse(txt); } catch (e) { throw new Error('__NONJSON__'); }
            if (!j || typeof j !== 'object') throw new Error('__NONJSON__');
            if (!j.ok) throw new Error('__FINAL__' + (j.error || '解析失败'));
            accept(j);
          }).catch(function (e) {
            var msg = (e && e.message) ? e.message : String(e);
            // 端点通了但业务失败（风控 / 未启用 / 参数错）：不回退，直接告知
            if (msg.indexOf('__FINAL__') === 0) return self.toast('解析失败：' + msg.slice(9));
            // 404 / 403 / 返回 HTML / 非 JSON（插件目录 PHP 被禁）→ 试下一个通道
            attempt(i + 1);
          });
        }
        attempt(0);
      },

    restoreUser: function () {
      if (!this.opts.storage) return;
      var saved = readStore(this.userKey, []);
      if (!Array.isArray(saved) || !saved.length) return;
      this.userItems = normalize(saved, {}, 'json', []).items.slice(-500);
      this.items = this.items.concat(this.userItems);
      this.items.sort(function (a, b) { return a.time - b.time; });
      this.resync(this.currentTime());
      this.updateUI();
    },

    send: function () {
      var text = String(this.sendInput.value || '').trim().slice(0, 120);
      if (!text) return;
      var item = normalize([{
        time: this.currentTime() + 0.05, mode: this.sendMode.value,
        color: this.sendColor.value, size: 1, text: text, uid: 'local'
      }], {}, 'json', []).items[0];
      this.items.push(item);
      this.userItems.push(item);
      this.items.sort(function (a, b) { return a.time - b.time; });
      if (this.opts.storage) {
        var saved = readStore(this.userKey, []);
        if (!Array.isArray(saved)) saved = [];
        saved.push({ time: item.time, mode: item.mode, color: item.color, size: 1, text: item.text, uid: 'local' });
        writeStore(this.userKey, saved.slice(-500));
      }
      this.vduration = Math.max(this.vduration, Math.ceil(item.time + 12));
      this.spawn(item, this.currentTime());
      this.sendInput.value = '';
      this.updateUI();
      this.toast('弹幕已发送 ✨');
    },

    /* ---------- UI 状态 ---------- */
    updateUI: function () {
      if (!this.root) return;
      var playing = this.isPlaying();
      this.btnPlay.textContent = playing ? '❚❚' : '▶';
      this.center.style.display = playing ? 'none' : 'flex';
      this.btnDm.classList.toggle('mdk-on', !!this.settings.on);
      this.btnDm.style.opacity = this.settings.on ? '1' : '.45';
      if (this.video) {
        this.btnMute.textContent = (this.video.muted || this.video.volume === 0) ? '🔇' : '🔊';
        this.vol.value = String(this.video.muted ? 0 : this.video.volume);
      }
      if (this.countEl) this.countEl.textContent = '弹幕 ' + this.items.length + ' 条';
      this.updateProgress();
    },

    updateProgress: function () {
      if (!this.prog) return;
      var d = this.duration(), t = clamp(this.currentTime(), 0, d), p = d ? (t / d) * 100 : 0;
      this.progPlay.style.width = p + '%';
      this.progDot.style.left = p + '%';
      this.timeEl.textContent = fmtTime(t) + ' / ' + fmtTime(d);
      this.prog.setAttribute('aria-valuenow', String(Math.round(t)));
    },

    toast: function (msg) {
      if (!this.toastEl) return;
      this.toastEl.textContent = String(msg || '');
      this.toastEl.classList.add('mdk-show');
      var self = this;
      global.clearTimeout(this.toastTimer);
      this.toastTimer = global.setTimeout(function () { self.toastEl.classList.remove('mdk-show'); }, 3200);
    },

    saveSettings: function () {
      if (this.opts.storage) writeStore(STORE_SETTINGS, this.settings);
    },
    closePanel: function () { this.panel.hidden = true; this.panel.textContent = ''; this.panelMode = ''; },
    openPanel: function (mode) {
      if (this.panelMode === mode && !this.panel.hidden) return this.closePanel();
      this.panel.textContent = '';
      this.panel.hidden = false;
      this.panelMode = mode;
      var head = h('div', 'mdk-panel-head');
      head.appendChild(h('strong', '', mode === 'settings' ? '播放设置' : (mode === 'list' ? '弹幕列表' : '视频源 / 弹幕源')));
      var close = h('button', 'mdk-panel-close', '✕'); close.type = 'button';
      var self = this;
      on(close, 'click', function () { self.closePanel(); });
      head.appendChild(close);
      this.panel.appendChild(head);
      var body = h('div', 'mdk-panel-body');
      this.panel.appendChild(body);
      if (mode === 'settings') this.buildSettings(body);
      else if (mode === 'list') this.buildList(body);
      else this.buildSource(body);
    },

    buildSettings: function (body) {
      var self = this;
      var defs = [
        { k: 'opacity', label: '不透明度', min: 0.2, max: 1, step: 0.05, fmt: function (v) { return Math.round(v * 100) + '%'; } },
        { k: 'fontSize', label: '字号', min: 14, max: 46, step: 1, fmt: function (v) { return v + ' px'; } },
        { k: 'area', label: '显示区域', min: 0.25, max: 1, step: 0.05, fmt: function (v) { return Math.round(v * 100) + '%'; } },
        { k: 'duration', label: '滚动时长', min: 3, max: 18, step: 0.5, fmt: function (v) { return v + ' s'; } },
        { k: 'hold', label: '固定停留', min: 1.5, max: 12, step: 0.5, fmt: function (v) { return v + ' s'; } }
      ];
      defs.forEach(function (d) {
        var row = h('label', 'mdk-row');
        row.appendChild(h('span', 'mdk-row-label', d.label));
        var inp = h('input', 'mdk-range'); inp.type = 'range';
        inp.min = d.min; inp.max = d.max; inp.step = d.step; inp.value = self.settings[d.k] !== undefined ? self.settings[d.k] : DEFAULTS[d.k];
        var val = h('span', 'mdk-row-val', d.fmt(num(inp.value, DEFAULTS[d.k])));
        on(inp, 'input', function () {
          var v = num(this.value, DEFAULTS[d.k]);
          self.settings[d.k] = v;
          val.textContent = d.fmt(v);
          self.saveSettings();
          self.resync(self.currentTime());
        });
        row.appendChild(inp); row.appendChild(val); body.appendChild(row);
      });
      [{ k: 'bold', label: '粗体' }, { k: 'stroke', label: '描边阴影' }, { k: 'overlap', label: '允许重叠（占满轨道时）' }].forEach(function (d) {
        var row = h('label', 'mdk-row mdk-row-check');
        var cb = h('input'); cb.type = 'checkbox'; cb.checked = !!self.settings[d.k];
        on(cb, 'change', function () { self.settings[d.k] = this.checked; self.saveSettings(); self.resync(self.currentTime()); });
        row.appendChild(cb); row.appendChild(h('span', '', d.label)); body.appendChild(row);
      });
      var tip = h('p', 'mdk-tip', '设置保存在本机浏览器；快捷键：空格播放 / ←→ 快退快进 / D 弹幕 / F 全屏 / M 静音');
      body.appendChild(tip);
    },

    buildList: function (body) {
      var self = this;
      var info = h('div', 'mdk-src-info', '共 ' + this.items.length + ' 条 · 格式 ' + (this.meta.label || this.meta.format || '—') + ' · 点击可跳转');
      body.appendChild(info);
      var search = h('input', 'mdk-search');
      search.type = 'search'; search.placeholder = '筛选弹幕内容…';
      body.appendChild(search);
      var box = h('div', 'mdk-list');
      body.appendChild(box);
      function render(kw) {
        box.textContent = '';
        var frag = doc.createDocumentFragment(), n = 0;
        for (var i = 0; i < self.items.length && n < 2000; i++) {
          var it = self.items[i];
          if (kw && it.text.toLowerCase().indexOf(kw) === -1) continue;
          var row = h('div', 'mdk-list-row');
          row.appendChild(h('span', 'mdk-list-time', fmtTime(it.time)));
          var bubble = h('span', 'mdk-list-text', it.text);
          bubble.style.color = it.mode === 'scroll' ? '' : it.color;
          row.appendChild(bubble);
          (function (t) { on(row, 'click', function () { self.seek(t); }); })(it.time);
          frag.appendChild(row); n++;
        }
        if (!n) box.appendChild(h('div', 'mdk-empty', '没有匹配的弹幕'));
        else box.appendChild(frag);
        if (n >= 2000) box.appendChild(h('div', 'mdk-empty', '仅显示前 2000 条'));
      }
      var tm = 0;
      on(search, 'input', function () {
        var kw = this.value.trim().toLowerCase();
        global.clearTimeout(tm);
        tm = global.setTimeout(function () { render(kw); }, 160);
      });
      render('');
      var warns = this.meta.warnings || [];
      if (warns.length) body.appendChild(h('p', 'mdk-tip', '提示：' + warns.join('；')));
    },

    buildSource: function (body) {
      var self = this;
      function section(title, tipText) {
        var s = h('div', 'mdk-src-sec');
        s.appendChild(h('div', 'mdk-src-title', title));
        if (tipText) s.appendChild(h('div', 'mdk-src-tip', tipText));
        body.appendChild(s);
        return s;
      }
      function row(sec, input, btnLabel, handler) {
        var r = h('div', 'mdk-src-row');
        r.appendChild(input);
        var b = h('button', 'mdk-btn-sm', btnLabel); b.type = 'button';
        on(b, 'click', function () { handler(input.value); });
        r.appendChild(b); sec.appendChild(r);
        return b;
      }

        /* 视频源 / 解析地址 */
        if (this.pc.enabled !== false) {
          var s0 = section('🎞️ 视频源 / 解析地址', 'mp4、m3u8 直链可直接播放；影视播放页请选择解析接口');
          var i0 = h('input', 'mdk-src-input');
          i0.type = 'text'; i0.value = this.srcUrl || '';
          i0.placeholder = 'https://…/v.m3u8 或 .mp4 或影视播放页';
          var sel = h('select', 'mdk-src-select');
          sel.title = '解析接口';
          var apiList = (this.pc.apis && this.pc.apis.length)
            ? this.pc.apis : [{ id: 'direct', name: '内置直连 · m3u8 / mp4' }];
          apiList.forEach(function (a) {
            var op = h('option', '', a.name || a.id); op.value = a.id; sel.appendChild(op);
          });
          sel.value = this.parseKey;
          var r0 = h('div', 'mdk-src-row');
          r0.appendChild(i0); r0.appendChild(sel);
          var b0 = h('button', 'mdk-btn-sm', '解析并播放'); b0.type = 'button';
          on(b0, 'click', function () { self.setSource(i0.value, { parse: sel.value, proxy: self.opts.proxy }); });
          r0.appendChild(b0); s0.appendChild(r0);

          var quick = h('div', 'mdk-src-row');
          var demo = this.pc.demo || {};
          if (demo.hls) {
            var bh = h('button', 'mdk-btn-sm mdk-btn-ghost', '演示 m3u8'); bh.type = 'button';
            on(bh, 'click', function () { i0.value = demo.hls; sel.value = 'direct'; self.setSource(demo.hls, { parse: 'direct' }); });
            quick.appendChild(bh);
          }
          if (demo.mp4) {
            var bm = h('button', 'mdk-btn-sm mdk-btn-ghost', '演示 mp4'); bm.type = 'button';
            on(bm, 'click', function () { i0.value = demo.mp4; sel.value = 'direct'; self.setSource(demo.mp4, { parse: 'direct' }); });
            quick.appendChild(bm);
          }
          s0.appendChild(quick);

          if (!this.hasServer()) {
            var ti = h('input', 'mdk-src-input');
            ti.type = 'text'; ti.placeholder = '自定义解析地址，如 https://…/parse.php?url={url}';
            var tb = h('button', 'mdk-btn-sm mdk-btn-ghost', '添加接口'); tb.type = 'button';
            on(tb, 'click', function () {
              var tpl = String(ti.value || '').trim();
              if (!/^https?:\/\//i.test(tpl) || (tpl.indexOf('{url}') === -1 && tpl.indexOf('{url_raw}') === -1)) {
                return self.toast('解析地址需为 http(s) 且包含 {url}');
              }
              var id = 'l' + String(Date.now()).slice(-7);
              var item = { id: id, name: '自定义 ' + (self.pc.apis.length + 1), tpl: tpl, local: true };
              self.pc.apis.push(item);
              try {
                var saved = self.pc.apis.filter(function (a) { return !!a.local; });
                if (global.localStorage) global.localStorage.setItem('mdk.parse.local', JSON.stringify(saved));
              } catch (e) {}
              var op = h('option', '', item.name); op.value = id; sel.appendChild(op); sel.value = id;
              self.toast('已添加自定义解析地址（保存在本机浏览器）');
            });
            var rq = h('div', 'mdk-src-row'); rq.appendChild(ti); rq.appendChild(tb);
            s0.appendChild(rq);
            s0.appendChild(h('div', 'mdk-src-tip', '独立预览模式下由浏览器直连解析接口，可能受 CORS 限制；CMS 插件环境走服务端解析。'));
          }

          var info = h('div', 'mdk-src-info');
          info.style.whiteSpace = 'pre-wrap';
          this.srcInfoEl = info;
          s0.appendChild(info);
          this.updateSourceInfo();
        }

        if (this.opts.allowBili) {
          var s1 = section('B 站弹幕解析', '粘贴视频链接 / BV号 / av号 / CID，服务端解析后自动载入');
        var i1 = h('input', 'mdk-src-input'); i1.type = 'text'; i1.placeholder = 'https://www.bilibili.com/video/BV… 或 BV… 或 CID';
        row(s1, i1, '解析', function (v) { self.resolveBili(v); });
      }
      var s2 = section('弹幕文件地址', '支持 .xml / .ass / .json / .srt / .vtt / .txt，多个地址用 | 分隔');
      var i2 = h('input', 'mdk-src-input'); i2.type = 'text'; i2.placeholder = '/uploads/2026/danmaku.xml';
      row(s2, i2, '载入', function (v) { self.loadUrls(String(v).split('|')); });

      var s3 = section('粘贴弹幕文本', '自动识别格式；也可直接把弹幕文件拖到画面上');
      var ta = h('textarea', 'mdk-src-text');
      ta.rows = 4; ta.placeholder = '<i><d p="1.5,1,25,16777215,...">第一条弹幕</d></i>';
      s3.appendChild(ta);
      var r3 = h('div', 'mdk-src-row');
      var b3 = h('button', 'mdk-btn-sm', '解析并载入'); b3.type = 'button';
      on(b3, 'click', function () { self.applyText(ta.value, ''); });
      var f3 = h('label', 'mdk-file', '选择本地文件');
      var fi = h('input'); fi.type = 'file'; fi.accept = '.xml,.ass,.ssa,.json,.srt,.vtt,.txt'; fi.style.display = 'none';
      on(fi, 'change', function () { if (this.files && this.files[0]) self.readFile(this.files[0]); });
      f3.appendChild(fi);
      var b4 = h('button', 'mdk-btn-sm mdk-btn-ghost', '导出 JSON'); b4.type = 'button';
      on(b4, 'click', function () { self.exportJson(); });
      r3.appendChild(b3); r3.appendChild(f3); r3.appendChild(b4);
      s3.appendChild(r3);

      var info = h('div', 'mdk-src-info', '当前：' + this.items.length + ' 条 · ' + (this.meta.label || this.meta.format || '—'));
      body.appendChild(info);
      this.countEl = info;
      this.updateUI();
    },

    exportJson: function () {
      var data = this.items.map(function (i) {
        return { time: +i.time.toFixed(3), mode: i.mode, color: i.color, size: i.size, text: i.text };
      });
      var blob = new global.Blob([JSON.stringify(data, null, 2)], { type: 'application/json;charset=utf-8' });
      var url = global.URL.createObjectURL(blob);
      var a = h('a'); a.href = url; a.download = 'danmaku-' + Date.now() + '.json';
      doc.body.appendChild(a); a.click(); a.remove();
      global.setTimeout(function () { global.URL.revokeObjectURL(url); }, 1000);
      this.toast('已导出 ' + data.length + ' 条弹幕');
    },

    destroy: function () {
      if (this.ro) this.ro.disconnect();
      if (this.root && this.root.parentNode) this.root.remove();
    }
  };

  /* ============================================================
     四、自动挂载（短代码 / data 标记）
     ============================================================ */

  var ATTR_RE = /([\w-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s\]]+))/g;
  var SHORT_RE = /\[danmaku\b([^\]]*)\]/gi;
  var instances = [];

  function parseAttrs(s) {
    var out = {}, m;
    ATTR_RE.lastIndex = 0;
    while ((m = ATTR_RE.exec(s)) !== null) out[m[1].toLowerCase()] = m[2] !== undefined ? m[2] : (m[3] !== undefined ? m[3] : m[4]);
    return out;
  }
  function dsOpts(node) {
    var o = {}, d = node.dataset || {}, k;
    for (k in d) if (Object.prototype.hasOwnProperty.call(d, k)) {
      var key = k.replace(/-([a-z])/g, function (_, c) { return c.toUpperCase(); });
      o[key] = d[k];
    }
    return o;
  }
  function boolish(v, d) {
    if (v === undefined || v === '') return d;
    return !(/^(0|false|off|no)$/i.test(String(v)));
  }
  function normalizeOpts(raw) {
    var o = mix({}, raw);
    ['autoplay', 'loop', 'muted', 'overlap', 'bold', 'stroke'].forEach(function (k) {
      if (o[k] !== undefined) o[k] = boolish(o[k], DEFAULTS[k]);
    });
    if (o.danmaku !== undefined) o.danmaku = boolish(o.danmaku, true);
    ['opacity', 'fontSize', 'fontsize', 'area', 'duration', 'offset', 'hold'].forEach(function (k) {
      if (o[k] !== undefined) o[k] = num(o[k], DEFAULTS[k]);
    });
    if (o.fontsize !== undefined) { o.fontSize = o.fontsize; delete o.fontsize; }
    if (o.bv !== undefined && !o.bili) o.bili = o.bv;
    if (o.dmformat) {
      o.format = o.dmformat === 'xml' ? 'bili-xml' : o.dmformat;
      o.hint = 'danmaku.' + o.dmformat;
    }
    return o;
  }
  function mount(node, raw) {
    if (!node || node.getAttribute('data-mdk-mounted')) return null;
    node.setAttribute('data-mdk-mounted', '1');
    var p = new Player(node, normalizeOpts(raw || {}));
    instances.push(p);
    return p;
  }

  function scan(root) {
    root = root || doc;
    if (!root) return [];
    var made = [], i, nodes, node;

    /* 1. 显式标记：<div data-moe-danmaku data-src="..." data-dm="..."></div> */
    nodes = root.querySelectorAll ? root.querySelectorAll('[data-moe-danmaku], .moe-danmaku-player, video[data-dm]') : [];
    for (i = 0; i < nodes.length; i++) {
      node = nodes[i];
      if (node.getAttribute('data-mdk-mounted')) continue;
      var raw = dsOpts(node);
      delete raw.moeDanmaku;
      if (node.tagName === 'VIDEO') {
        if (!raw.src) raw.src = node.getAttribute('src') || node.getAttribute('data-src') || '';
        var holder = h('div', 'mdk-mount');
        node.parentNode.insertBefore(holder, node);
        node.remove();
        node = holder;
      }
      var p1 = mount(node, raw);
      if (p1) made.push(p1);
    }

    /* 2. 正文中短代码 [danmaku src="..." dm="..."] */
    var walker, skip = { SCRIPT: 1, STYLE: 1, CODE: 1, PRE: 1, TEXTAREA: 1, SELECT: 1, OPTION: 1, VIDEO: 1, AUDIO: 1 };
    if (!doc.createTreeWalker) return made;
    walker = doc.createTreeWalker(root, 4 /* NodeFilter.SHOW_TEXT */, null, false);
    var texts = [], tn;
    while ((tn = walker.nextNode())) {
      if (!tn.nodeValue || tn.nodeValue.indexOf('[danmaku') === -1) continue;
      var par = tn.parentNode;
      if (!par || par.classList && par.classList.contains('mdk')) continue;
      if (skip[par.tagName]) continue;
      texts.push(tn);
    }
    for (i = 0; i < texts.length; i++) {
      var tnode = texts[i];
      if (!tnode.parentNode) continue;
      var value = tnode.nodeValue;
      SHORT_RE.lastIndex = 0;
      var m, frag = doc.createDocumentFragment(), cursor = 0, changed = false;
      while ((m = SHORT_RE.exec(value)) !== null) {
        changed = true;
        if (m.index > cursor) frag.appendChild(doc.createTextNode(value.slice(cursor, m.index)));
        var holder2 = h('div', 'mdk-mount');
        var p2 = mount(holder2, parseAttrs(m[1] || ''));
        if (p2) made.push(p2);
        frag.appendChild(holder2);
        cursor = m.index + m[0].length;
      }
      if (!changed) continue;
      if (cursor < value.length) frag.appendChild(doc.createTextNode(value.slice(cursor)));
      var parent = tnode.parentNode;
      if (parent.tagName === 'P' && /^\s*$/.test(parent.textContent.replace(/\[danmaku[^\]]*\]/g, ''))) {
        // 独占一段时整段替换为播放器，避免 div 嵌在 p 里
          var kids = [], c;
          while ((c = frag.firstChild)) { frag.removeChild(c); kids.push(c); }
        var before = parent;
        for (var j = 0; j < kids.length; j++) {
          if (/^\s*$/.test(kids[j].nodeValue || '') && kids[j].nodeType === 3) continue;
          parent.parentNode.insertBefore(kids[j], before);
        }
        parent.remove();
      } else {
        parent.replaceChild(frag, tnode);
      }
    }
    for (i = 0; i < made.length; i++) made[i].syncSize();
    return made;
  }

  /* ============================================================
     五、对外 API
     ============================================================ */

  var API = {
    version: VERSION,
    defaults: DEFAULTS,
    parse: parse,
    detect: detectFormat,
    create: function (host, opts) {
      if (typeof host === 'string') host = doc.querySelector(host);
      if (!host) throw new Error('MoeDanmaku.create: 找不到挂载节点');
      var holder = host;
      if (host.tagName === 'DIV' && !host.classList.contains('mdk-mount')) {
        holder = h('div', 'mdk-mount');
        host.appendChild(holder);
      }
      return mount(holder, opts || {});
    },
    scan: scan,
    Player: Player,
    players: instances,
    util: { fmtTime: fmtTime, normColor: normColor, decodeBuffer: decodeBuffer }
  };
  global.MoeDanmaku = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API; // Node / 打包器

  if (doc) {
    var boot = function () { if (CFG.auto !== false) { try { scan(doc); } catch (e) { if (global.console) global.console.warn('[MoeDanmaku]', e); } } };
    if (doc.readyState === 'loading') on(doc, 'DOMContentLoaded', boot);
    else boot();
  }

})(typeof window !== 'undefined' ? window : this);
