<?php
/**
 * Plugin Name: 🎬 视频扩展
 * Version:     1.0.0
 * Author:      Moe 酷 CMS
 * Description: 基于文章与分类的视频发布扩展。多线路选集、访问权限与试看防盗、内置弹幕播放器、片库中心与伪静态入口。
 *
 * 入口说明（与后台说明一致）
 *   ?plugin=video                  片库中心（/?plugin=video 或 /video）
 *   ?plugin=video&play=1&url=      播放页
 *   ?plugin=video&play=1&v=        Base64 编码地址的播放页
 *   ?plugin=video&video_api=1      弹幕 / 播放器配置 API（ac=video|dm|get|report|list）
 *   ?plugin=video&admin=base       后台：基础设置
 *   ?plugin=video&admin=publish     后台：发布视频
 *   ?plugin=video&admin=danmaku     后台：弹幕 / 举报管理
 *
 * 兼容说明
 *   本插件优先使用 CMS 原生钩子（front_head / front_footer / admin_footer 等）。
 *   即使 CMS 没有原生 ?plugin= 路由，本文件顶部也会拦截 ?plugin=video 直接渲染，
 *   因此「片库 / 播放页 / API / 后台」在所有环境下都可用。
 */
if (!defined('MOE_ROOT')) { http_response_code(403); exit('forbidden'); }

require_once __DIR__ . '/video-funcs.php';

/* ============================================================
   顶部分发：?plugin=video 系列请求（整页输出，直接 exit）
   ============================================================ */
if (!empty($_GET['plugin']) && $_GET['plugin'] === 'video') {
    if (!empty($_GET['video_api'])) {
        require_once __DIR__ . '/video-api.php';
        video_api_run();
        exit;
    }
    if (isset($_GET['admin'])) {
        require_once __DIR__ . '/video-admin.php';
        video_admin_run();
        exit;
    }
    require_once __DIR__ . '/video-front.php';
    if (!empty($_GET['play'])) video_front_play();
    else video_front_library();
    exit;
}

/* ============================================================
   常规装载：注册钩子，注入资产 / 短代码 / 后台入口
   ============================================================ */
/** 前台头部：注入播放器资产与全局配置 */
function video_front_head()
{
    if (!video_enabled()) return;
    $cfg = array(
        'base'       => video_base_url(),
        'asset'      => video_asset(''),
        'api'        => video_base_url() . '?plugin=video&video_api=1',
        'accent'     => video_opt('theme_color', '#8f7bff'),
        'themeEmpty' => video_opt('theme_empty', ''),
        'adPauseImg' => video_opt('ad_pause_img', ''),
        'adPauseUrl' => video_opt('ad_pause_url', ''),
        'danmaku'    => video_on('danmaku_on', true) ? 1 : 0,
        'danmakuInterval' => (int)video_num('dm_interval', 3, 0, 60),
        'heartbeat'  => video_on('heartbeat', true) ? 1 : 0,
        'parse'      => video_parse_apis(),
    );
    $esc = function_exists('e') ? 'e' : 'htmlspecialchars';
    echo "\n<!-- 🎬 视频扩展 -->\n";
    echo '<link rel="stylesheet" href="' . video_asset('assets/danmaku.css') . '?v=' . VIDEO_VER . '">' . "\n";
    echo '<link rel="stylesheet" href="' . video_asset('assets/player.css') . '?v=' . VIDEO_VER . '">' . "\n";
    echo '<script>window.VIDEO_CFG = ' . video_json($cfg) . ';</script>' . "\n";
    echo '<script src="' . video_asset('assets/danmaku.js') . '?v=' . VIDEO_VER . '"></script>' . "\n";
    echo '<script src="' . video_asset('assets/player.js') . '?v=' . VIDEO_VER . '"></script>' . "\n";
}
/** 把 [video id=123] / [video slug=x] 短代码替换为占位节点（内容过滤器） */
function video_shortcode_replace($content)
{
    if (!is_string($content)) return $content;
    if (strpos($content, '[video') === false) return $content;
    $content = preg_replace_callback('/\[video\s+([^\]]*?)\]/i', function ($m) {
        $attrs = video_parse_attrs($m[1]);
        $id = isset($attrs['id']) ? (int)$attrs['id'] : 0;
        $slug = isset($attrs['slug']) ? $attrs['slug'] : '';
        $dm = isset($attrs['dm']) ? $attrs['dm'] : '';
        $h = '<div class="moe-video-embed"';
        if ($id) $h .= ' data-video-id="' . $id . '"';
        if ($slug) $h .= ' data-video-slug="' . video_json($slug) . '"';
        if ($dm) $h .= ' data-video-dm="' . video_json($dm) . '"';
        $h .= '></div>';
        return $h;
    }, $content);
    return $content;
}
function video_parse_attrs($str)
{
    $out = array();
    if (preg_match_all('/(\w+)\s*=\s*("([^"]*)"|\'([^\']*)\'|(\S+))/', $str, $m, PREG_SET_ORDER)) {
        foreach ($m as $x) { $out[$x[1]] = isset($x[3]) && $x[3] !== '' ? $x[3] : (isset($x[4]) && $x[4] !== '' ? $x[4] : $x[5]); }
    }
    return $out;
}
/** 文章内容过滤器：替换短代码 + 视频文章自动挂载播放器 */
function video_content_filter($content)
{
    if (!video_enabled()) return $content;
    $content = video_shortcode_replace($content);
    // 视频文章：按设置位置自动注入播放器
    $pid = video_current_post_id();
    if ($pid && video_flag_get($pid)) {
        $pos = video_opt('player_pos', 'below');
        $embed = '<div class="moe-video-embed" data-video-id="' . $pid . '"></div>';
        if ($pos === 'above') $content = $embed . $content;
        elseif ($pos === 'below') $content = $content . $embed;
        // custom 标签由主题自行放置 #video
    }
    return $content;
}
function video_current_post_id()
{
    if (function_exists('get_the_id')) { $v = get_the_id(); if ($v) return (int)$v; }
    if (isset($_GET['id']) && is_numeric($_GET['id'])) return (int)$_GET['id'];
    if (isset($_GET['post']) && is_numeric($_GET['post'])) return (int)$_GET['post'];
    return 0;
}
/** 尝试注册内容过滤器（兼容不同 CMS 钩子名） */
function video_register_filters()
{
    $cbs = array('video_content_filter');
    $hooks = array('the_content', 'post_content', 'content', 'moe_content');
    foreach ($hooks as $h) {
        if (function_exists('add_filter')) { add_filter($h, 'video_content_filter', 12); break; }
    }
    // 兜底：直接挂载到 front_footer，扫描并渲染（不依赖内容钩子）
}
/** 解析接口列表（后台配置的解析地址） */
function video_parse_apis()
{
    $raw = video_opt('parse_apis', '');
    $list = array(array('id' => 'direct', 'name' => '内置直连'));
    if ($raw) {
        $i = 1;
        foreach (preg_split('/\r\n|\r|\n/', $raw) as $ln) {
            $ln = trim($ln); if (!$ln || $ln[0] === '#') continue;
            $p = strpos($ln, '|');
            if ($p === false) continue;
            $name = trim(substr($ln, 0, $p));
            $url = trim(substr($ln, $p + 1));
            if (!$url) continue;
            $list[] = array('id' => 'p' . $i, 'name' => $name, 'tpl' => $url);
            $i++;
            if ($i > 20) break;
        }
    }
    return $list;
}

/* ============================================================
   后台入口：在「插件管理」页追加「🎬 视频扩展」页签
   （沿用 danmaku 插件的成熟方案：admin_footer 注入，避免依赖
    后台独立 PHP 文件被 Web 直接执行）
   ============================================================ */
function video_admin_footer()
{
    $tabLabel = '🎬 视频扩展';
    $self = video_base_url() . '?plugin=video&admin=';
    $h = '';
    $h .= '<div id="videoPaneRaw" hidden>' . "\n";
    $h .= video_admin_overview_html();
    $h .= '</div>' . "\n";
    $h .= '<script>(function(){' . "\n";
    $h .= 'var tabs=document.getElementById("plugTabs"),raw=document.getElementById("videoPaneRaw");if(!raw)return;' . "\n";
    $h .= 'if(!tabs){raw.removeAttribute("hidden");raw.className="card";raw.style.margin="18px 0";return;}' . "\n";
    $h .= 'var tab=document.createElement("button");tab.type="button";tab.className="set-tab";tab.id="tab-plug-video";' . "\n";
    $h .= 'tab.setAttribute("data-pane","plug-video");tab.setAttribute("role","tab");tab.setAttribute("aria-selected","false");' . "\n";
    $h .= 'tab.textContent="' . $tabLabel . '";tabs.appendChild(tab);' . "\n";
    $h .= 'raw.removeAttribute("hidden");raw.id="plug-video";raw.className="card set-pane";' . "\n";
    $h .= 'tabs.parentNode.insertBefore(raw,tabs.nextSibling);' . "\n";
    $h .= 'tab.addEventListener("click",function(){tabs.querySelectorAll(".set-tab").forEach(function(b){b.classList.remove("cur");b.setAttribute("aria-selected","false");});tab.classList.add("cur");tab.setAttribute("aria-selected","true");document.querySelectorAll(".set-pane").forEach(function(p){p.classList.remove("cur");});raw.classList.add("cur");if(location.hash!=="#plug-video")location.hash="plug-video";});' . "\n";
    $h .= 'if(/[?&]plugin=video(?:&|$)/.test(location.search)||location.hash==="#plug-video")tab.click();' . "\n";
    $h .= '})();</script>' . "\n";
    echo $h;
}
/** 后台总览 / 快捷入口面板（注入到插件页页签内） */
function video_admin_overview_html()
{
    $self = video_base_url() . '?plugin=video&admin=';
    $enabled = video_enabled();
    $lib = video_page_url();
    $on = function_exists('e') ? 'e' : 'htmlspecialchars';
    $h = '';
    $h .= '<div style="padding:4px 2px 14px"><h2 class="card-title" style="margin:6px 0 10px">🎬 视频扩展 · 概览</h2>';
    $h .= '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px">';
    $h .= '<a class="btn" href="' . $on($self . 'base') . '" target="_blank" rel="noopener">⚙ 基础设置</a>';
    $h .= '<a class="btn" href="' . $on($self . 'publish') . '" target="_blank" rel="noopener">➕ 发布视频</a>';
    $h .= '<a class="btn" href="' . $on($self . 'danmaku') . '" target="_blank" rel="noopener">📝 弹幕 / 举报管理</a>';
    $h .= '<a class="btn ghost" href="' . $on($lib) . '" target="_blank" rel="noopener">🎞️ 片库中心 ↗</a>';
    $h .= '</div>';
    $h .= '<p style="color:var(--sub,#888);font-size:13px;line-height:1.8;margin:0">总开关：<b>' . ($enabled ? '已开启' : '未开启') . '</b>　|　片库入口：<code>' . $on($lib) . '</code><br>';
    $h .= '提示：在「基础设置」中开启视频功能、配置解析接口 / 主题色 / 广告 / 弹幕规则后，到文章页将文章标记为视频并填写线路即可。</p>';
    $h .= '</div>';
    return $h;
}

/* ============================================================
   钩子注册
   ============================================================ */
if (function_exists('add_action')) {
    add_action('front_head', 'video_front_head');
    add_action('front_footer', 'video_register_filters');
    add_action('admin_footer', 'video_admin_footer');
    if (function_exists('add_filter')) {
        add_filter('the_content', 'video_content_filter', 12);
        add_filter('post_content', 'video_content_filter', 12);
    }
} else {
    // 部分 CMS 通过简单的钩子数组调用；这里兜底声明将被核心扫描
}
