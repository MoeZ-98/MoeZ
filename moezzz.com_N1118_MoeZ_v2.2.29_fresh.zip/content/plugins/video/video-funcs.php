<?php
/**
 * 🎬 视频扩展 · 共享函数库
 * ------------------------------------------------------------
 * 本文件只做「与 CMS 解耦的适配器 + 业务函数」，不输出任何 HTML。
 * 所有 CMS 相关调用都走防御式封装：若当前 CMS 暴露了对应函数 / 数据表，
 * 则自动启用；否则优雅降级（返回示例数据 / 标记为未启用），不影响插件装载。
 *
 * 适配要点（如你的 CMS 字段名不同，改下面 VIDEO_SCHEMA 即可）：
 *   - 文章表 / 分类表 的列名
 *   - 用户角色判定函数
 */

if (!defined('MOE_ROOT')) { http_response_code(403); exit('forbidden'); }

define('VIDEO_ID', 'video');
define('VIDEO_VER', '1.0.0');
if (!defined('VIDEO_DIR')) define('VIDEO_DIR', basename(__DIR__));

/* ============================================================
   一、站点 / 资源 / 配置 基础
   ============================================================ */
function video_base_url()
{
    return function_exists('base_url') ? base_url() : '/';
}
function video_asset($path)
{
    return video_base_url() . 'content/plugin/' . VIDEO_DIR . '/' . ltrim((string)$path, '/');
}
function video_opt($key, $default = '')
{
    return function_exists('setting') ? setting('video_' . $key, $default) : $default;
}
function video_on($key, $default = true)
{
    $v = strtolower(trim((string)video_opt($key, $default ? '1' : '0')));
    return !in_array($v, array('0', 'false', 'off', 'no', ''), true);
}
function video_num($key, $default, $min, $max)
{
    $v = (float)video_opt($key, $default);
    if (!is_finite($v)) $v = (float)$default;
    return max($min, min($max, $v));
}
function video_json($data)
{
    $out = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
    return $out === false ? '{}' : $out;
}
/** 是否开启了视频功能总开关（弹幕播放器 → 基础设置 → 视频功能） */
function video_enabled()
{
    return video_on('enabled', false);
}
/** 伪静态前缀，如 "video"；关闭则为空 */
function video_prefix()
{
    return video_on('rewrite', false) ? trim((string)video_opt('prefix', 'video')) : '';
}

/* ============================================================
   二、数据库适配器（尽量复用 CMS 连接）
   ============================================================ */
/**
 * 取得 CMS 的 PDO 连接（若暴露）。返回 null 表示无法取得。
 */
function video_db()
{
    if (isset($GLOBALS['db']) && $GLOBALS['db'] instanceof PDO) return $GLOBALS['db'];
    foreach (array('pdo', 'DB', 'conn', 'mysql') as $k) {
        if (isset($GLOBALS[$k]) && $GLOBALS[$k] instanceof PDO) return $GLOBALS[$k];
    }
    // 常见对象式封装
    if (class_exists('DB') && method_exists('DB', 'instance')) {
        try { $o = DB::instance(); if ($o instanceof PDO) return $o; } catch (Throwable $e) {}
    }
    return null;
}

/**
 * 各 CMS 的表 / 列名可能不同，集中在此便于一处修改。
 * 默认按「博客派生型」常见命名；如你的 CMS 不同，直接改这里。
 */
function video_schema()
{
    return array(
        'posts'    => video_opt('tbl_posts', 'posts'),
        'cat'      => video_opt('tbl_cat', 'category'),
        'col_id'   => 'id',
        'col_title'=> 'title',
        'col_alias'=> 'alias',
        'col_cid'  => 'cid',
        'col_views'=> 'views',
        'col_time' => 'date',           // 发布时间列
        'col_cover'=> 'cover',
    );
}

/* ============================================================
   三、文章自定义字段（视频元数据）
   设计：优先使用 CMS 原生自定义字段函数；否则用本插件自建的
   `plugin_video_meta` 表（按需建表）。两者都表现为「按文章 id 的键值」。
   ============================================================ */
/** 取得文章视频元数据（array） */
function video_meta_get($post_id)
{
    $post_id = (int)$post_id;
    if ($post_id <= 0) return array();
    // 1) 尝试原生函数
    if (function_exists('get_post_meta')) {
        $raw = get_post_meta($post_id, 'video_data', true);
        if ($raw) { $d = is_array($raw) ? $raw : @json_decode((string)$raw, true); if (is_array($d)) return $d; }
    }
    // 2) 自建表
    $db = video_db();
    if ($db) {
        try {
            $st = $db->prepare('SELECT meta_value FROM `plugin_video_meta` WHERE post_id = ? AND meta_key = ? LIMIT 1');
            $st->execute(array($post_id, 'data'));
            $v = $st->fetchColumn();
            if ($v !== false) { $d = @json_decode((string)$v, true); if (is_array($d)) return $d; }
        } catch (Throwable $e) {}
    }
    return array();
}
/** 保存文章视频元数据 */
function video_meta_set($post_id, $data)
{
    $post_id = (int)$post_id;
    if ($post_id <= 0) return false;
    $json = video_json($data);
    if (function_exists('update_post_meta')) {
        return update_post_meta($post_id, 'video_data', $json) !== false;
    }
    $db = video_db();
    if ($db) {
        try {
            $db->exec('CREATE TABLE IF NOT EXISTS `plugin_video_meta` (' .
                '`post_id` INT UNSIGNED NOT NULL, `meta_key` VARCHAR(64) NOT NULL, ' .
                '`meta_value` MEDIUMTEXT NOT NULL, PRIMARY KEY (`post_id`,`meta_key`)) ' .
                'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
            $st = $db->prepare('REPLACE INTO `plugin_video_meta` (post_id, meta_key, meta_value) VALUES (?,?,?)');
            return $st->execute(array($post_id, 'data', $json));
        } catch (Throwable $e) {}
    }
    return false;
}
/** 把某文章标记为视频类型（用于片库检索） */
function video_flag_set($post_id, $is_video = 1)
{
    $post_id = (int)$post_id;
    if (function_exists('update_post_meta')) { update_post_meta($post_id, 'video_type', $is_video ? '1' : '0'); return true; }
    $db = video_db();
    if ($db) {
        try {
            $db->exec('CREATE TABLE IF NOT EXISTS `plugin_video_meta` (' .
                '`post_id` INT UNSIGNED NOT NULL, `meta_key` VARCHAR(64) NOT NULL, ' .
                '`meta_value` MEDIUMTEXT NOT NULL, PRIMARY KEY (`post_id`,`meta_key`)) ' .
                'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
            $st = $db->prepare('REPLACE INTO `plugin_video_meta` (post_id, meta_key, meta_value) VALUES (?,?,?)');
            return $st->execute(array($post_id, 'type', $is_video ? '1' : '0'));
        } catch (Throwable $e) {}
    }
    return false;
}
function video_flag_get($post_id)
{
    $post_id = (int)$post_id;
    if (function_exists('get_post_meta')) return (string)get_post_meta($post_id, 'video_type', true) === '1';
    $db = video_db();
    if ($db) {
        try {
            $st = $db->prepare('SELECT meta_value FROM `plugin_video_meta` WHERE post_id = ? AND meta_key = ? LIMIT 1');
            $st->execute(array($post_id, 'type'));
            return $st->fetchColumn() === '1';
        } catch (Throwable $e) {}
    }
    return false;
}

/* ============================================================
   四、线路 / 选集 解析
   格式（与后台「线路与剧集」一致）：
     每行一条，集数名称$播放地址
     以 @线路名 开头的行，其后的 名称$地址 归入该线路，直到下一个 @ 或结尾
   例：
     @默认线路
     第01集$https://a/ep1.m3u8
     第02集$https://a/ep2.m3u8
     @高清线路
     第01集$https://b/ep1.m3u8
   支持来源类型识别：bilibili / youtube / iframe / 本地 / 外链
   ============================================================ */
function video_parse_routes($raw)
{
    $raw = (string)$raw;
    $lines = preg_split('/\r\n|\r|\n/', $raw);
    $routes = array();
    $cur = '默认线路';
    $routes[$cur] = array();
    foreach ($lines as $ln) {
        $ln = trim($ln);
        if ($ln === '' || $ln[0] === '#') continue;
        if ($ln[0] === '@') { $cur = trim(substr($ln, 1)); if (!isset($routes[$cur])) $routes[$cur] = array(); continue; }
        $pos = strpos($ln, '$');
        if ($pos === false) continue;
        $name = trim(substr($ln, 0, $pos));
        $url  = trim(substr($ln, $pos + 1));
        if ($url === '') continue;
        $routes[$cur][] = array(
            'name' => $name ? $name : ('第' . (count($routes[$cur]) + 1) . '集'),
            'url'  => $url,
            'type' => video_source_type($url)
        );
    }
    // 过滤空线路
    $out = array();
    foreach ($routes as $name => $eps) { if ($eps) $out[] = array('name' => $name, 'episodes' => $eps); }
    if (!$out) $out = array(array('name' => '默认线路', 'episodes' => array()));
    return $out;
}
function video_source_type($url)
{
    $s = strtolower((string)$url);
    if (strpos($url, 'bilibili.com') !== false || (strpos($s, 'bvid=') !== false) || preg_match('/bv[0-9a-z]+/i', $s)) return 'bilibili';
    if (strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false) return 'youtube';
    if (strpos($s, '<iframe') !== false) return 'iframe';
    if (preg_match('/\.(mp4|webm|m3u8|flv|mkv|mov|m4v)(\?|$)/i', $s)) return 'direct';
    if (strpos($s, '/content/upload/') !== false || strpos($s, '/upload/') !== false) return 'local';
    return 'direct';
}
/** 把解析结果拍平成「全部可播地址」便于试看 / 统计 */
function video_all_urls($routes)
{
    $urls = array();
    foreach ($routes as $r) foreach ($r['episodes'] as $e) $urls[] = $e['url'];
    return $urls;
}

/* ============================================================
   五、用户角色与访问控制
   角色：guest（未登录）/ login（已登录）/ vip / pay（已付费）
   ============================================================ */
function video_user_role()
{
    // 优先调用 CMS 提供的角色判定
    if (function_exists('moe_user_role')) { $r = moe_user_role(); if ($r) return (string)$r; }
    if (function_exists('user_role'))     { $r = user_role(); if ($r) return (string)$r; }
    if (function_exists('is_login') && is_login()) {
        // 进一步判定 vip / pay
        if (function_exists('is_vip') && is_vip()) return 'vip';
        if (function_exists('is_pay') && is_pay()) return 'pay';
        return 'login';
    }
    if (function_exists('is_user_logged_in') && is_user_logged_in()) {
        if (function_exists('current_user_vip') && current_user_vip()) return 'vip';
        if (function_exists('current_user_paid') && current_user_paid()) return 'pay';
        return 'login';
    }
    return 'guest';
}
function video_is_admin()
{
    if (function_exists('moe_is_owner')) return moe_is_owner();
    if (function_exists('is_admin')) return is_admin();
    if (function_exists('require_admin')) { try { require_admin(); return true; } catch (Throwable $e) { return false; } }
    return false;
}
/** 访问级别权重 */
function video_level_weight($lv)
{
    static $w = array('free' => 0, 'login' => 1, 'vip' => 2, 'pay' => 3);
    return isset($w[$lv]) ? $w[$lv] : 0;
}
/**
 * 校验某视频对某用户是否可播。
 * @return array {ok:bool, reason:string, trial:int}
 */
function video_access_check($access, $trial = 0)
{
    $access = strtolower((string)($access ?: 'free'));
    $role = video_user_role();
    if ($access === 'free') return array('ok' => true, 'reason' => '', 'trial' => 0);
    $need = video_level_weight($access);
    $have = video_level_weight($role);
    if ($have >= $need) return array('ok' => true, 'reason' => '', 'trial' => 0);
    // 不足：若有试看则放行试看时长
    $trial = (int)$trial;
    if ($trial > 0) return array('ok' => true, 'reason' => 'trial', 'trial' => $trial);
    $label = array('login' => '登录后观看', 'vip' => 'VIP 会员专享', 'pay' => '付费内容');
    return array('ok' => false, 'reason' => isset($label[$access]) ? $label[$access] : '无权观看', 'trial' => 0);
}

/* ============================================================
   六、播放凭证（HMAC 防盗链）
   前端拿到的播放地址不直接暴露原始直链，而是带 sign 的代理地址；
   服务端校验 sign 与时间窗，防止被轻易扒走直链。
   ============================================================ */
function video_secret()
{
    static $s = null;
    if ($s !== null) return $s;
    $cfgFile = dirname(__DIR__, 3) . '/config.php';
    $pass = '';
    if (is_file($cfgFile)) { $cfg = @include $cfgFile; if (is_array($cfg) && isset($cfg['db']['pass'])) $pass = (string)$cfg['db']['pass']; }
    $s = 'video-v1|' . $pass . '|' . (isset($_SERVER['HTTP_HOST']) ? (string)$_SERVER['HTTP_HOST'] : '');
    return $s;
}
function video_sign($url, $expire = 600)
{
    $exp = time() + $expire;
    $raw = $exp . '|' . $url;
    return $exp . '.' . hash_hmac('sha256', $raw, video_secret());
}
function video_sign_verify($token, $url)
{
    if (!is_string($token) || strpos($token, '.') === false) return false;
    list($exp, $mac) = explode('.', $token, 2);
    if (!is_numeric($exp) || (int)$exp < time()) return false;
    $raw = $exp . '|' . $url;
    return hash_equals(hash_hmac('sha256', $raw, video_secret()), (string)$mac);
}

/* ============================================================
   七、片库查询（列表 / 分类 / 搜索 / 排行）
   返回统一结构，便于前台渲染；数据库不可用时回退示例数据。
   ============================================================ */
function video_demo_posts()
{
    return array(
        array(
            'id' => 101, 'title' => '示例剧集 · 第一季', 'alias' => 'demo-s1', 'cid' => 1, 'cat' => '电视剧', 'cover' => '', 'views' => 1823, 'date' => date('Y-m-d'),
            'meta' => array(
                'cover' => '', 'access' => 'free', 'trial' => 0,
                'routes' => array(
                    array('name' => '默认线路', 'episodes' => array(
                        array('name' => '第01集', 'url' => 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8', 'type' => 'direct'),
                        array('name' => '第02集', 'url' => 'https://test-streams.mux.dev/test_001/stream.m3u8', 'type' => 'direct')
                    ))
                )
            )
        ),
        array(
            'id' => 102, 'title' => '示例电影 · 正片', 'alias' => 'demo-movie', 'cid' => 2, 'cat' => '电影', 'cover' => '', 'views' => 942, 'date' => date('Y-m-d'),
            'meta' => array(
                'cover' => '', 'access' => 'login', 'trial' => 60,
                'routes' => array(
                    array('name' => '正片', 'episodes' => array(
                        array('name' => '正片', 'url' => 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4', 'type' => 'direct')
                    ))
                )
            )
        )
    );
}
/**
 * 取得视频文章列表。
 * @param array $args {cat, q, sort(views|date|rand), page, per}
 */
function video_get_posts($args = array())
{
    $args = array_merge(array('cat' => 0, 'q' => '', 'sort' => 'date', 'page' => 1, 'per' => 12), $args);
    $db = video_db();
    $sc = video_schema();
    if (!$db) return video_demo_posts();
    try {
        $wh = array();
        $pr = array();
        $j = '';
        // 仅取被标记为视频的文章（自建 meta 表）
        $j = ' INNER JOIN `plugin_video_meta` vm ON vm.post_id = p.`' . $sc['col_id'] . '` AND vm.meta_key = \'type\' AND vm.meta_value = \'1\'';
        if ($args['cat'] > 0) { $wh[] = 'p.`' . $sc['col_cid'] . '` = ?'; $pr[] = $args['cat']; }
        if ($args['q'] !== '') { $wh[] = 'p.`' . $sc['col_title'] . '` LIKE ?'; $pr[] = '%' . $args['q'] . '%'; }
        $order = $args['sort'] === 'views' ? ('p.`' . $sc['col_views'] . '` DESC') :
                 ($args['sort'] === 'rand' ? 'RAND()' : 'p.`' . $sc['col_time'] . '` DESC');
        $sql = 'SELECT p.`' . $sc['col_id'] . '` AS id, p.`' . $sc['col_title'] . '` AS title, p.`' . $sc['col_alias'] . '` AS alias, ' .
               'p.`' . $sc['col_cid'] . '` AS cid, p.`' . $sc['col_views'] . '` AS views, p.`' . $sc['col_time'] . '` AS date' .
               ' FROM `' . $sc['posts'] . '` p ' . $j;
        if ($wh) $sql .= ' WHERE ' . implode(' AND ', $wh);
        $sql .= ' ORDER BY ' . $order . ' LIMIT ' . ((int)max(1, $args['page']) - 1) * (int)$args['per'] . ',' . (int)$args['per'];
        $st = $db->prepare($sql);
        $st->execute($pr);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        $out = array();
        foreach ($rows as $r) {
            $r['cat'] = '';
            $r['meta'] = video_meta_get($r['id']);
            if (empty($r['meta'])) { $r['meta'] = array('access' => 'free', 'trial' => 0, 'routes' => array(array('name' => '默认线路', 'episodes' => array()))); }
            $out[] = $r;
        }
        return $out;
    } catch (Throwable $e) {
        return video_demo_posts();
    }
}
/** 取得单个视频文章（含元数据） */
function video_get_post($id = 0, $slug = '')
{
    $db = video_db();
    $sc = video_schema();
    if ($db) {
        try {
            if ($id > 0) $wh = 'p.`' . $sc['col_id'] . '` = ?';
            else { $wh = 'p.`' . $sc['col_alias'] . '` = ?'; $id = $slug; }
            $sql = 'SELECT p.`' . $sc['col_id'] . '` AS id, p.`' . $sc['col_title'] . '` AS title, p.`' . $sc['col_alias'] . '` AS alias, ' .
                   'p.`' . $sc['col_cid'] . '` AS cid, p.`' . $sc['col_views'] . '` AS views, p.`' . $sc['col_time'] . '` AS date, ' .
                   'p.`' . $sc['col_cover'] . '` AS cover' .
                   ' FROM `' . $sc['posts'] . '` p WHERE ' . $wh . ' LIMIT 1';
            $st = $db->prepare($sql);
            $st->execute(array($id));
            $r = $st->fetch(PDO::FETCH_ASSOC);
            if ($r) {
                $r['meta'] = video_meta_get($r['id']);
                if (empty($r['meta'])) $r['meta'] = array('access' => 'free', 'trial' => 0, 'routes' => array(array('name' => '默认线路', 'episodes' => array())));
                return $r;
            }
        } catch (Throwable $e) {}
    }
    // 回退示例
    foreach (video_demo_posts() as $d) { if (($id > 0 && $d['id'] == $id) || ($slug && $d['alias'] == $slug)) return $d; }
    return null;
}
/** 分类列表 */
function video_get_cats()
{
    $db = video_db();
    $sc = video_schema();
    if ($db) {
        try {
            $st = $db->query('SELECT `' . (isset($sc['col_id']) ? $sc['col_id'] : 'id') . '` AS id, `name` AS name FROM `' . $sc['cat'] . '` ORDER BY id ASC');
            if ($st) return $st->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {}
    }
    return array(array('id' => 1, 'name' => '电视剧'), array('id' => 2, 'name' => '电影'));
}

/* ============================================================
   八、安全：限流 / 违禁词
   ============================================================ */
function video_rate_limit($key, $max = 30, $window = 60)
{
    if (!function_exists('session_start')) return true;
    if (session_status() !== PHP_SESSION_ACTIVE) { @session_start(); }
    $k = 'video_rl_' . $key;
    $now = time();
    $hits = isset($_SESSION[$k]) ? $_SESSION[$k] : array();
    $hits = array_filter($hits, function ($t) use ($now, $window) { return $t > $now - $window; });
    if (count($hits) >= $max) { $_SESSION[$k] = $hits; return false; }
    $hits[] = $now; $_SESSION[$k] = $hits; return true;
}
function video_ban_words()
{
    $raw = video_opt('ban_words', '');
    if (!$raw) return array();
    return array_filter(array_map('trim', preg_split('/[\r\n,]/', $raw)), function ($x) { return $x !== ''; });
}
function video_has_ban($text)
{
    $text = (string)$text;
    foreach (video_ban_words() as $w) { if ($w !== '' && strpos($text, $w) !== false) return $w; }
    return false;
}

/* ============================================================
   九、主题对接函数（供 Conch / Cinema 等主题调用）
   ============================================================ */
if (!function_exists('video_require')) {
    function video_require() { require_once __DIR__ . '/video-funcs.php'; }
}
if (!function_exists('conch_require_video')) {
    function conch_require_video() { require_once __DIR__ . '/video-funcs.php'; }
}
/** 片库页地址（兼容 /video 伪静态） */
function video_page_url($path = '')
{
    $pre = video_prefix();
    if ($pre) return video_base_url() . $pre . ($path ? '/' . ltrim($path, '/') : '');
    return video_base_url() . '?plugin=video' . ($path ? '&' . ltrim($path, '&?') : '');
}
/** 片库分发钩子（主题可将请求交给插件渲染） */
if (!function_exists('video_center_dispatch')) {
    function video_center_dispatch() { return video_page_url(); }
}
