<?php
/**
 * 🎬 视频扩展 · 前台页面
 *   video_front_library() 片库中心（/?plugin=video 或 /video）
 *   video_front_play()    播放页（?plugin=video&play=1&id=|slug=|url=|v=）
 *
 * 渲染策略：若 CMS 提供 get_header()/get_footer() 则套用主题；
 * 否则输出自包含 HTML，保证任何环境下都可用。
 */
if (!defined('MOE_ROOT')) { http_response_code(403); exit('forbidden'); }
require_once __DIR__ . '/video-funcs.php';

function video_front_shell($title, $body, $extraHead = '')
{
    if (function_exists('get_header')) { get_header($title); echo $body; if (function_exists('get_footer')) get_footer(); return; }
    $accent = video_opt('theme_color', '#8f7bff');
    $asset = video_asset('');
    echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>' . htmlspecialchars($title) . '</title>';
    echo '<link rel="stylesheet" href="' . video_asset('assets/danmaku.css') . '?v=' . VIDEO_VER . '">';
    echo '<link rel="stylesheet" href="' . video_asset('assets/player.css') . '?v=' . VIDEO_VER . '">';
    echo '<style>:root{--v-accent:' . htmlspecialchars($accent) . '}body{margin:0;background:#0f0f14;color:#eee;font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif}a{color:inherit;text-decoration:none}img{display:block;max-width:100%}.v-wrap{max-width:1180px;margin:0 auto;padding:24px 18px 48px}</style>';
    echo $extraHead . '</head><body>' . $body . '</body></html>';
}

/* ============================================================
   片库中心
   ============================================================ */
function video_front_library()
{
    $cat = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
    $q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
    $sort = isset($_GET['sort']) ? trim((string)$_GET['sort']) : 'date';
    $p = isset($_GET['p']) ? max(1, (int)$_GET['p']) : 1;
    $posts = video_get_posts(array('cat' => $cat, 'q' => $q, 'sort' => $sort, 'page' => $p, 'per' => 24));
    $cats = video_get_cats();
    $prefix = video_prefix();
    $libUrl = video_page_url();

    $playUrl = function ($post) use ($prefix) {
        if ($prefix) return video_base_url() . $prefix . '/play/' . $post['id'];
        return video_base_url() . '?plugin=video&play=1&id=' . $post['id'];
    };
    $link = function ($over = array()) use ($libUrl, $cat, $q, $sort) {
        $a = array('plugin' => 'video', 'cat' => $cat, 'q' => $q, 'sort' => $sort);
        $a = array_merge($a, $over);
        $qstr = http_build_query(array_filter($a, function ($v) { return $v !== '' && $v !== 0; }));
        return video_base_url() . '?' . $qstr;
    };

    $body = '<div class="v-wrap">';
    $body .= '<header style="display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:18px">';
    $body .= '<h1 style="margin:0;font-size:24px">🎬 片库中心</h1>';
    $body .= '<form method="get" action="' . htmlspecialchars(video_base_url()) . '" style="display:flex;gap:8px;flex:1 1 260px;max-width:420px">';
    $body .= '<input type="hidden" name="plugin" value="video"><input type="hidden" name="cat" value="' . $cat . '">';
    $body .= '<input name="q" value="' . htmlspecialchars($q) . '" placeholder="搜索影片…" style="flex:1;padding:9px 12px;border:1px solid #2a2a35;border-radius:10px;background:#17171f;color:#fff">';
    $body .= '<button style="padding:9px 16px;border:0;border-radius:10px;background:var(--v-accent,#8f7bff);color:#fff;cursor:pointer">搜索</button>';
    $body .= '</form></header>';

    // 分类 + 排序
    $body .= '<nav style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px">';
    $body .= '<a href="' . htmlspecialchars($link(array('cat' => 0))) . '" style="padding:6px 14px;border-radius:20px;background:' . ($cat ? '#17171f' : 'var(--v-accent,#8f7bff)') . '">' . '全部</a>';
    foreach ($cats as $c) {
        $active = ($cat == $c['id']);
        $body .= '<a href="' . htmlspecialchars($link(array('cat' => $c['id']))) . '" style="padding:6px 14px;border-radius:20px;background:' . ($active ? 'var(--v-accent,#8f7bff)' : '#17171f') . '">' . htmlspecialchars($c['name']) . '</a>';
    }
    $body .= '</nav>';
    $body .= '<div style="display:flex;gap:8px;margin-bottom:20px;font-size:13px;color:#aaa">排序：';
    foreach (array('date' => '最新', 'views' => '最热', 'rand' => '随机') as $k => $lab) {
        $body .= '<a href="' . htmlspecialchars($link(array('sort' => $k))) . '" style="color:' . ($sort === $k ? 'var(--v-accent,#8f7bff)' : '#aaa') . '">' . $lab . '</a>';
    }
    $body .= '</div>';

    // 网格
    $body .= '<div class="v-grid">';
    if (!$posts) {
        $body .= '<p style="color:#888;padding:40px 0">暂无视频，去后台发布一个吧。</p>';
    }
    foreach ($posts as $p) {
        $cover = isset($p['cover']) ? $p['cover'] : (isset($p['meta']['cover']) ? $p['meta']['cover'] : '');
        $access = isset($p['meta']['access']) ? $p['meta']['access'] : 'free';
        $badge = $access === 'free' ? '' : ('<span class="v-badge v-' . htmlspecialchars($access) . '">' . htmlspecialchars($access === 'login' ? '登录' : ($access === 'vip' ? 'VIP' : '付费')) . '</span>');
        $body .= '<a class="v-card" href="' . htmlspecialchars($playUrl($p)) . '">';
        $body .= '<div class="v-thumb">' . ($cover ? '<img loading="lazy" src="' . htmlspecialchars($cover) . '" alt="">' : '<span class="v-play">▶</span>') . $badge . '</div>';
        $body .= '<div class="v-title">' . htmlspecialchars($p['title']) . '</div>';
        $body .= '<div class="v-meta"><span>' . htmlspecialchars(isset($p['cat']) ? $p['cat'] : '') . '</span><span>▶ ' . (int)(isset($p['views']) ? $p['views'] : 0) . '</span></div>';
        $body .= '</a>';
    }
    $body .= '</div></div>';

    $extra = '<style>.v-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(172px,1fr));gap:16px}.v-card{background:#14141b;border-radius:14px;overflow:hidden;transition:transform .15s,box-shadow .15s}.v-card:hover{transform:translateY(-3px);box-shadow:0 10px 30px rgba(0,0,0,.4)}.v-thumb{position:relative;aspect-ratio:16/9;background:#000;display:flex;align-items:center;justify-content:center}.v-thumb img{width:100%;height:100%;object-fit:cover}.v-play{font-size:34px;color:#555}.v-badge{position:absolute;top:8px;left:8px;font-size:11px;padding:2px 8px;border-radius:8px;background:rgba(0,0,0,.65)}.v-vip{color:#ffd479}.v-pay{color:#ff8fb0}.v-login{color:#9fd0ff}.v-title{padding:9px 10px 2px;font-size:14px;line-height:1.4;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.v-meta{padding:0 10px 10px;display:flex;justify-content:space-between;font-size:12px;color:#8a8a95}</style>';
    video_front_shell('片库中心', $body, $extra);
}

/* ============================================================
   播放页
   ============================================================ */
function video_front_play()
{
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    $slug = isset($_GET['slug']) ? trim((string)$_GET['slug']) : '';
    $url = isset($_GET['url']) ? trim((string)$_GET['url']) : '';
    if ($url === '' && isset($_GET['v'])) { $d = base64_decode((string)$_GET['v'], true); if ($d !== false) $url = trim($d); }

    // 数据属性交给前端 player.js 再向 API 取完整配置
    $attr = '';
    if ($id) $attr .= ' data-video-id="' . $id . '"';
    elseif ($slug) $attr .= ' data-video-slug="' . htmlspecialchars($slug) . '"';
    elseif ($url) $attr .= ' data-video-url="' . htmlspecialchars($url) . '"';

    $title = '视频播放';
    if ($id || $slug) { $post = video_get_post($id, $slug); if ($post) $title = $post['title']; }

    $body = '<div class="v-wrap" style="max-width:1080px">';
    $body .= '<div id="videoPlayer" class="moe-video-player"' . $attr . '></div>';
    $body .= '<p style="margin:14px 2px 0;color:#9a9aa5;font-size:13px">提示：本页为弹幕播放器入口；如需嵌入文章，请使用短代码 <code>[video id=' . ($id ? $id : 1) . ']</code>。片库：<a href="' . htmlspecialchars(video_page_url()) . '" style="color:var(--v-accent,#8f7bff)">返回片库</a></p>';
    $body .= '</div>';
    $extraHead = '<script>window.VIDEO_CFG=' . video_json(array(
        'base' => video_base_url(), 'asset' => video_asset(''), 'api' => video_base_url() . '?plugin=video&video_api=1',
        'accent' => video_opt('theme_color', '#8f7bff'), 'themeEmpty' => video_opt('theme_empty', ''),
        'adPauseImg' => video_opt('ad_pause_img', ''), 'adPauseUrl' => video_opt('ad_pause_url', ''),
        'danmaku' => video_on('danmaku_on', true) ? 1 : 0, 'heartbeat' => video_on('heartbeat', true) ? 1 : 0,
        'parse' => video_parse_apis()
    )) . ';</script>';
    $extraHead .= '<script src="' . video_asset('assets/danmaku.js') . '?v=' . VIDEO_VER . '"></script>';
    $extraHead .= '<script src="' . video_asset('assets/player.js') . '?v=' . VIDEO_VER . '"></script>';
    $extraHead .= '<style>.moe-video-player{max-width:100%}</style>';
    video_front_shell($title, $body, $extraHead);
}
