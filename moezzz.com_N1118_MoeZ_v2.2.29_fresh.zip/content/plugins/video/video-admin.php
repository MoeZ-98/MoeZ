<?php
/**
 * 🎬 视频扩展 · 后台管理
 *   ?plugin=video&admin=base      基础设置（模块开关 / 伪静态 / 播放器位置 / 解析 / 主题 / 广告 / 弹幕规则）
 *   ?plugin=video&admin=publish   发布视频（填写封面 / 线路 / 选集 / 权限）
 *   ?plugin=video&admin=danmaku   弹幕 / 举报管理
 */
if (!defined('MOE_ROOT')) { http_response_code(403); exit('forbidden'); }
require_once __DIR__ . '/video-funcs.php';

function video_admin_run()
{
    if (!video_is_admin()) {
        header('Content-Type: text/html; charset=utf-8');
        echo '<p style="padding:40px;font-family:sans-serif">需要管理员权限。请先登录后台。</p>';
        exit;
    }
    $act = isset($_GET['admin']) ? strtolower((string)$_GET['admin']) : 'base';
    if ($act === 'publish') video_admin_publish();
    elseif ($act === 'danmaku') video_admin_danmaku();
    else video_admin_base();
}

function video_admin_head($title)
{
    header('Content-Type: text/html; charset=utf-8');
    $accent = video_opt('theme_color', '#8f7bff');
    echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<title>' . htmlspecialchars($title) . ' · 视频扩展</title>';
    echo '<style>body{margin:0;background:#0f0f14;color:#e8e8ee;font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;font-size:14px}a{color:var(--a,#8f7bff)}.wrap{max-width:920px;margin:0 auto;padding:26px 18px 60px}.card{background:#16161e;border:1px solid #262633;border-radius:14px;padding:20px;margin-bottom:18px}.card-title{font-size:18px;margin:0 0 14px}.f{display:flex;flex-direction:column;gap:6px;margin-bottom:14px}.f label{font-size:13px;color:#b8b8c4}.f input,.f textarea,.f select{padding:9px 11px;border:1px solid #2c2c3a;border-radius:9px;background:#0f0f16;color:#fff;font-size:14px;outline:none}.f .hint{font-size:12px;color:#8a8a95}.btn{padding:9px 18px;border:0;border-radius:10px;background:var(--a,#8f7bff);color:#fff;cursor:pointer;font-size:14px}.btn.ghost{background:#22222e}.seg{display:flex;gap:8px;flex-wrap:wrap}.seg label{display:flex;align-items:center;gap:6px;background:#0f0f16;border:1px solid #2c2c3a;padding:8px 12px;border-radius:9px;cursor:pointer}.ok{background:#16331f;color:#9fe6b0;padding:10px 12px;border-radius:9px;margin-bottom:14px}.tabs{display:flex;gap:8px;margin-bottom:16px}.tabs a{padding:8px 14px;border-radius:9px;background:#1b1b25}.tabs a.cur{background:var(--a,#8f7bff)}table{width:100%;border-collapse:collapse;font-size:13px}td,th{padding:8px 10px;border-bottom:1px solid #262633;text-align:left}.badge{padding:2px 8px;border-radius:7px;background:#22222e;font-size:12px}</style>';
    echo '</head><body><div class="wrap">';
    echo '<div class="tabs"><a href="?plugin=video&admin=base"' . ($_GET['admin'] === 'base' ? ' class="cur"' : '') . '>⚙ 基础设置</a>';
    echo '<a href="?plugin=video&admin=publish"' . ($_GET['admin'] === 'publish' ? ' class="cur"' : '') . '>➕ 发布视频</a>';
    echo '<a href="?plugin=video&admin=danmaku"' . ($_GET['admin'] === 'danmaku' ? ' class="cur"' : '') . '>📝 弹幕管理</a>';
    echo '<a href="' . htmlspecialchars(video_page_url()) . '" target="_blank" rel="noopener">🎞️ 片库 ↗</a></div>';
}

/* ---------------- 基础设置 ---------------- */
function video_admin_base()
{
    $msg = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (function_exists('csrf_verify') && !csrf_verify()) { $msg = 'CSRF 校验失败'; }
        else {
            $map = array('enabled','rewrite','prefix','player_pos','parse_apis','theme_color','theme_empty',
                         'ad_pause_img','ad_pause_url','danmaku_on','dm_interval','dm_limit','ban_words','heartbeat');
            foreach ($map as $k) {
                $v = isset($_POST[$k]) ? (is_array($_POST[$k]) ? implode(',', $_POST[$k]) : trim((string)$_POST[$k])) : '';
                if (function_exists('setting_set')) setting_set('video_' . $k, $v);
            }
            if (function_exists('moe_content_changed')) moe_content_changed();
            $msg = '设置已保存';
        }
    }
    video_admin_head('基础设置');
    $v = function ($k, $d = '') { return video_opt($k, $d); };
    $on = function ($k, $d = true) { return video_on($k, $d) ? ' checked' : ''; };
    if ($msg) echo '<div class="ok">' . htmlspecialchars($msg) . '</div>';
    echo '<form method="post" class="card">';
    echo '<h2 class="card-title">模块开关</h2>';
    echo '<div class="seg" style="margin-bottom:6px">';
    echo '<label><input type="checkbox" name="enabled" value="1"' . $on('enabled', false) . '> 开启视频功能</label>';
    echo '<label><input type="checkbox" name="rewrite" value="1"' . $on('rewrite', false) . '> 开启 /video 伪静态</label>';
    echo '<label><input type="checkbox" name="danmaku_on" value="1"' . $on('danmaku_on', true) . '> 开启弹幕</label>';
    echo '<label><input type="checkbox" name="heartbeat" value="1"' . $on('heartbeat', true) . '> 在线人数心跳</label>';
    echo '</div>';
    echo '<div class="f"><label>伪静态前缀</label><input name="prefix" value="' . htmlspecialchars($v('prefix', 'video')) . '" placeholder="video"><span class="hint">开启伪静态后，片库地址为 /video，播放页为 /video/play/{id}；依赖站点全局 URL 重写。</span></div>';

    echo '<h2 class="card-title">播放器位置</h2>';
    $pos = $v('player_pos', 'below');
    echo '<div class="seg"><label><input type="radio" name="player_pos" value="above"' . ($pos === 'above' ? ' checked' : '') . '> 内容上方</label>';
    echo '<label><input type="radio" name="player_pos" value="below"' . ($pos === 'below' ? ' checked' : '') . '> 内容下方</label>';
    echo '<label><input type="radio" name="player_pos" value="custom"' . ($pos === 'custom' ? ' checked' : '') . '> 自定义标签 [#video]</label></div>';

    echo '<h2 class="card-title">视频解析地址</h2>';
    echo '<div class="f"><label>解析接口（每行：名称|含 {url} 的地址）</label>';
    echo '<textarea name="parse_apis" rows="4" placeholder="自建解析$https://your.com/api?url={url}">' . htmlspecialchars($v('parse_apis')) . '</textarea>';
    echo '<span class="hint">内置「内置直连」通道始终可用；这里填写你自己的 JSON / 直链解析服务。仅保存于服务端，前端只传编号。</span></div>';

    echo '<h2 class="card-title">界面主题</h2>';
    echo '<div class="f"><label>主题色</label><input name="theme_color" value="' . htmlspecialchars($v('theme_color', '#8f7bff')) . '" placeholder="#8f7bff"></div>';
    echo '<div class="f"><label>空地址页主题（留空用默认）</label><input name="theme_empty" value="' . htmlspecialchars($v('theme_empty')) . '"></div>';

    echo '<h2 class="card-title">视频广告</h2>';
    echo '<div class="f"><label>暂停广告图片</label><input name="ad_pause_img" value="' . htmlspecialchars($v('ad_pause_img')) . '" placeholder="https://…/ad.jpg"></div>';
    echo '<div class="f"><label>广告跳转链接</label><input name="ad_pause_url" value="' . htmlspecialchars($v('ad_pause_url')) . '"></div>';

    echo '<h2 class="card-title">弹幕规则</h2>';
    echo '<div style="display:flex;gap:14px;flex-wrap:wrap">';
    echo '<div class="f" style="flex:1 1 160px"><label>发送间隔（秒）</label><input name="dm_interval" value="' . htmlspecialchars($v('dm_interval', '3')) . '"></div>';
    echo '<div class="f" style="flex:1 1 160px"><label>每分钟限发（条）</label><input name="dm_limit" value="' . htmlspecialchars($v('dm_limit', '20')) . '"></div>';
    echo '</div>';
    echo '<div class="f"><label>违禁词（逗号或换行分隔）</label><textarea name="ban_words" rows="3" placeholder="广告,加微信">' . htmlspecialchars($v('ban_words')) . '</textarea></div>';

    echo '<div style="margin-top:8px"><button class="btn" type="submit">保存设置</button></div>';
    echo '</form>';
    echo '</div></body></html>';
}

/* ---------------- 发布视频 ---------------- */
function video_admin_publish()
{
    $msg = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (function_exists('csrf_verify') && !csrf_verify()) { $msg = 'CSRF 校验失败'; }
        else {
            $postId = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
            $meta = array(
                'cover' => isset($_POST['cover']) ? trim((string)$_POST['cover']) : '',
                'access' => isset($_POST['access']) ? trim((string)$_POST['access']) : 'free',
                'trial' => isset($_POST['trial']) ? max(0, (int)$_POST['trial']) : 0,
                'routes' => video_parse_routes(isset($_POST['routes']) ? (string)$_POST['routes'] : '')
            );
            // 创建文章（若 CMS 暴露 post_add）
            if ($postId <= 0 && function_exists('post_add')) {
                $pid = post_add(array(
                    'title' => isset($_POST['title']) ? trim((string)$_POST['title']) : '未命名视频',
                    'cid' => isset($_POST['cid']) ? (int)$_POST['cid'] : 0,
                    'alias' => isset($_POST['alias']) ? trim((string)$_POST['alias']) : '',
                    'content' => isset($_POST['content']) ? (string)$_POST['content'] : ''
                ));
                $postId = is_numeric($pid) ? (int)$pid : 0;
            }
            if ($postId > 0) {
                video_meta_set($postId, $meta);
                video_flag_set($postId, 1);
                if (function_exists('moe_content_changed')) moe_content_changed();
                $msg = '已保存（文章 #' . $postId . '）。片库：' . video_page_url();
            } else {
                $msg = '未指定文章 ID，且当前 CMS 未暴露 post_add；请在「post_id」填入已有文章编号后保存。';
            }
        }
    }
    video_admin_head('发布视频');
    $cats = video_get_cats();
    if ($msg) echo '<div class="ok">' . htmlspecialchars($msg) . '</div>';
    echo '<form method="post" class="card">';
    echo '<h2 class="card-title">发布视频</h2>';
    echo '<div class="f"><label>文章标题</label><input name="title" placeholder="影片名称"></div>';
    echo '<div style="display:flex;gap:14px;flex-wrap:wrap">';
    echo '<div class="f" style="flex:1 1 160px"><label>分类</label><select name="cid">';
    foreach ($cats as $c) echo '<option value="' . htmlspecialchars($c['id']) . '">' . htmlspecialchars($c['name']) . '</option>';
    echo '</select></div>';
    echo '<div class="f" style="flex:1 1 160px"><label>别名 / slug</label><input name="alias" placeholder="video-alias"></div>';
    echo '<div class="f" style="flex:1 1 160px"><label>已有文章 ID（可选）</label><input name="post_id" placeholder="留空则新建"></div>';
    echo '</div>';
    echo '<div class="f"><label>封面图 URL</label><input name="cover" placeholder="https://…/cover.jpg"></div>';
    echo '<h2 class="card-title">访问权限</h2>';
    echo '<div style="display:flex;gap:14px;flex-wrap:wrap">';
    echo '<div class="f" style="flex:1 1 180px"><label>权限等级</label><select name="access"><option value="free">免费</option><option value="login">登录</option><option value="vip">VIP</option><option value="pay">付费</option></select></div>';
    echo '<div class="f" style="flex:1 1 180px"><label>试看时长（秒，0=不试看）</label><input name="trial" value="0"></div></div>';
    echo '<h2 class="card-title">线路与选集</h2>';
    echo '<div class="f"><label>每行一条：集数名称$播放地址</label>';
    echo '<textarea name="routes" rows="8" placeholder="@默认线路&#10;第01集$https://a/ep1.m3u8&#10;第02集$https://a/ep2.m3u8&#10;@高清线路&#10;第01集$https://b/ep1.m3u8"></textarea>';
    echo '<span class="hint">以 @线路名 开头切换线路，其后条目归入该线路；多线路前台以 Tab 切换。支持 m3u8/mp4/flv、B 站、YouTube、iframe、本地上传。</span></div>';
    echo '<div class="f"><label>正文（可选）</label><textarea name="content" rows="4"></textarea></div>';
    echo '<div style="margin-top:8px"><button class="btn" type="submit">发布视频</button></div>';
    echo '</form>';
    echo '</div></body></html>';
}

/* ---------------- 弹幕 / 举报管理 ---------------- */
function video_admin_danmaku()
{
    video_admin_head('弹幕管理');
    $id = isset($_GET['id']) ? trim((string)$_GET['id']) : '';
    echo '<div class="card">';
    echo '<h2 class="card-title">弹幕 ID 列表</h2>';
    $ids = video_dm_ids();
    if (!$ids) echo '<p style="color:#8a8a95">暂无弹幕。</p>';
    else { echo '<div style="display:flex;gap:8px;flex-wrap:wrap">'; foreach ($ids as $i) echo '<a class="badge" href="?plugin=video&admin=danmaku&id=' . urlencode($i) . '">' . htmlspecialchars($i) . '</a>'; echo '</div>'; }
    echo '</div>';
    if ($id) {
        $items = video_dm_load($id);
        $reports = video_dm_reports($id);
        echo '<div class="card"><h2 class="card-title">弹幕明细：' . htmlspecialchars($id) . '（' . count($items) . ' 条）</h2>';
        echo '<table><tr><th>#</th><th>时间</th><th>模式</th><th>颜色</th><th>内容</th><th>用户</th></tr>';
        foreach ($items as $k => $it) {
            echo '<tr><td>' . $k . '</td><td>' . (isset($it['time']) ? (float)$it['time'] : 0) . '</td><td>' . (isset($it['mode']) ? (int)$it['mode'] : 1) . '</td><td>' . htmlspecialchars(isset($it['color']) ? $it['color'] : '') . '</td><td>' . htmlspecialchars(isset($it['text']) ? $it['text'] : '') . '</td><td>' . htmlspecialchars(isset($it['uid']) ? $it['uid'] : '') . '</td></tr>';
        }
        echo '</table></div>';
        echo '<div class="card"><h2 class="card-title">举报（' . count($reports) . ' 条）</h2>';
        if ($reports) { echo '<table><tr><th>弹幕#</th><th>理由</th><th>时间</th></tr>'; foreach ($reports as $r) echo '<tr><td>' . (int)$r['did'] . '</td><td>' . htmlspecialchars($r['reason']) . '</td><td>' . date('Y-m-d H:i', $r['ts']) . '</td></tr>'; echo '</table>'; }
        else echo '<p style="color:#8a8a95">暂无举报。</p>';
        echo '</div>';
    }
    echo '</div></body></html>';
}
