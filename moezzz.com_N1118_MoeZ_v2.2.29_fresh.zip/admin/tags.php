<?php
/**
 * 后台 · 标签管理（1.8.3）
 * 统计所有文章标签；重命名 / 删除 / 为无标签文章一键自动生成
 */
require __DIR__ . '/bootstrap.php';
$active = 'tags';
$page_title = '标签管理';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (function_exists('moe_content_changed')) moe_content_changed();   // 1.9.0：内容变更 → 清理统计/导航缓存与页面缓存
    $act = (string)($_POST['act'] ?? '');
    $tag = trim((string)($_POST['tag'] ?? ''));
    $like = '%' . addcslashes($tag, '%_\\') . '%';

    if ($act === 'rename' && $tag !== '') {
        $new = trim((string)($_POST['new_name'] ?? ''));
        if ($new === '') {
            flash('新名称不能为空', 'bad');
        } elseif ($new === $tag) {
            flash('新名称与原名相同', 'warn');
        } else {
            $n = 0;
            foreach ((array)rows('SELECT id, tags FROM ' . moe_table('posts') . " WHERE type='post' AND tags LIKE ?", array($like)) as $r) {
                $list = post_tags($r);
                if (!in_array($tag, $list, true)) continue;
                $out = array();
                foreach ($list as $t) $out[] = ($t === $tag) ? $new : $t;
                q('UPDATE ' . moe_table('posts') . ' SET tags=? WHERE id=?', array(moe_tags_normalize(implode(',', $out)), (int)$r['id']));
                $n++;
            }
            flash($n > 0 ? "已把 {$n} 篇文章的「{$tag}」重命名为「{$new}」✅" : "没有文章使用「{$tag}」", 'warn');
        }
    } elseif ($act === 'delete' && $tag !== '') {
        $n = 0;
        foreach ((array)rows('SELECT id, tags FROM ' . moe_table('posts') . " WHERE type='post' AND tags LIKE ?", array($like)) as $r) {
            $list = post_tags($r);
            if (!in_array($tag, $list, true)) continue;
            $out = array_values(array_diff($list, array($tag)));
            q('UPDATE ' . moe_table('posts') . ' SET tags=? WHERE id=?', array(implode(',', $out), (int)$r['id']));
            $n++;
        }
        flash($n > 0 ? "已从 {$n} 篇文章中移除标签「{$tag}」🗑" : "没有文章使用「{$tag}」", 'warn');
    } elseif ($act === 'batch_delete') {
        // 2.2.20：批量删除标签（勾选多个一次移除）
        $tags = array();
        foreach ((array)($_POST['tags'] ?? array()) as $tv) {
            $tv = trim((string)$tv);
            if ($tv !== '') $tags[] = $tv;
        }
        if (!$tags) {
            flash('请先勾选要删除的标签', 'bad');
        } else {
            $n = 0; $nPosts = 0;
            foreach ($tags as $tg) {
                $tlike = '%' . addcslashes($tg, '%_\\') . '%';
                foreach ((array)rows('SELECT id, tags FROM ' . moe_table('posts') . " WHERE type='post' AND tags LIKE ?", array($tlike)) as $r) {
                    $list = post_tags($r);
                    if (!in_array($tg, $list, true)) continue;
                    $out = array_values(array_diff($list, array($tg)));
                    q('UPDATE ' . moe_table('posts') . ' SET tags=? WHERE id=?', array(implode(',', $out), (int)$r['id']));
                    $n++;
                }
                $nPosts++;
            }
            flash('已删除 ' . count($tags) . ' 个标签（从 ' . $n . ' 篇文章中移除）🗑');
        }
    } elseif ($act === 'autofill') {
        // 为所有无标签的已发布文章自动生成标签（每次最多处理 50 篇，避免超时）
        $targets = rows('SELECT id, title, content FROM ' . moe_table('posts')
            . " WHERE type='post' AND status='published' AND (tags IS NULL OR tags = '') ORDER BY id DESC LIMIT 50");
        $n = 0;
        foreach ((array)$targets as $r) {
            $tags = moe_auto_tags($r['title'], $r['content'], 6);
            if (empty($tags)) continue;
            q('UPDATE ' . moe_table('posts') . ' SET tags=? WHERE id=?', array(implode(',', $tags), (int)$r['id']));
            $n++;
        }
        flash($n > 0 ? "已为 {$n} 篇文章自动生成标签 ✨（还有剩余的话，再点一次继续）" : '所有文章都已有标签，或暂时无法提取出关键词 ✅');
    }
    redirect('tags.php');
}

// 全站标签统计
$stat = array();
foreach ((array)rows('SELECT id, tags FROM ' . moe_table('posts') . " WHERE type='post' AND tags <> ''") as $r) {
    foreach (post_tags($r) as $t) {
        if (!isset($stat[$t])) $stat[$t] = 0;
        $stat[$t]++;
    }
}
uasort($stat, function ($a, $b) { return $b - $a; });

$noTag = (int)one('SELECT COUNT(*) FROM ' . moe_table('posts') . " WHERE type='post' AND status='published' AND (tags IS NULL OR tags = '')");
include 'includes/header.php';
?>

<style>
  /* 1.9.4：全部标签网格布局 */
  .tag-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 12px; }
  .tag-cell { border: 1.5px solid #eee6f5; border-radius: 12px; padding: 10px 12px; background: #fdfbff; }
  .tag-cell-top { display: flex; align-items: center; gap: 8px; }
  .tag-cell-top .tag-name { color: var(--violet); font-weight: 600; text-decoration: none; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 1; min-width: 0; }
  .tag-cell-top .tag-name:hover { text-decoration: underline; }
  .tag-cell .tag-ren { display: flex; gap: 6px; align-items: center; margin-top: 8px; }
  .tag-cell .tag-ren input { flex: 1; min-width: 0; width: auto; padding: 6px 10px; border: 1.5px solid #e8e2f0; border-radius: 8px; }
  /* 1.9.6：手机端网格自适应（minmax(0,1fr) 强制可收缩，避免卡片内不可断行元素把网格撑破） */
  @media (max-width: 700px) {
    .tag-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
    .tag-cell { padding: 10px; min-width: 0; }
    .tag-cell-top { flex-wrap: wrap; }
  }
  @media (max-width: 480px) {
    .tag-grid { grid-template-columns: minmax(0, 1fr); }
  }
</style>

<div class="card">
  <h2 class="card-title">自动生成标签</h2>
  <p class="hint" style="margin:-6px 0 14px">
    发布文章时若未填标签，会<b>自动生成核心标签</b>（纯本地分析，不调用外部接口）；
    也可以在编辑文章时点「✨ 自动生成」单篇处理。此处按钮用于给历史文章补标签。
  </p>
  <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
    <form method="post" onsubmit="return confirm('为 <?php echo (int)$noTag; ?> 篇无标签文章自动生成标签？')">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="act" value="autofill">
      <button class="btn" type="submit" <?php echo $noTag === 0 ? 'disabled' : ''; ?>>🪄 一键生成（<?php echo (int)$noTag; ?> 篇待处理）</button>
    </form>
    <span class="hint" style="margin:0">每次最多处理 50 篇，剩余的再点一次继续；生成后可在文章编辑里微调</span>
  </div>
</div>

<div class="card">
  <h2 class="card-title">全部标签（<?php echo count($stat); ?>）</h2>
  <?php if (empty($stat)): ?>
    <p class="hint" style="margin:0">还没有任何标签。新发布的文章会自动生成，也可以在编辑文章时手动填写。</p>
  <?php else: ?>
  <!-- 2.2.20：批量删除工具条（勾选标签后一键移除；form 不嵌套，提交时由 JS 动态填充勾选项） -->
  <form method="post" id="tagBatchForm" style="display:none">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="batch_delete">
    <span id="tagBatchFields"></span>
  </form>
  <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:0 0 12px;padding:10px 12px;border:1px dashed #e0d5ee;border-radius:10px;background:#fbf8ff">
    <label style="font-size:13px;display:flex;gap:6px;align-items:center;font-weight:600">
      <input type="checkbox" id="tagCheckAll" style="width:auto"> 全选
    </label>
    <span class="hint" style="margin:0">勾选标签后可批量删除（会从所有文章中移除，不影响文章本身）</span>
    <span style="flex:1"></span>
    <button class="btn danger sm" type="button" id="tagBatchBtn">🗑 批量删除选中</button>
  </div>
  <div class="tag-grid">
    <?php foreach ($stat as $tag => $cnt): ?>
      <div class="tag-cell">
        <div class="tag-cell-top">
          <input type="checkbox" class="tag-check" value="<?php echo e($tag); ?>" style="width:auto;flex:none" title="选中后可批量删除">
          <a class="tag-name" href="<?php echo e(post_tag_url($tag)); ?>" target="_blank" title="<?php echo e($tag); ?>">#<?php echo e($tag); ?></a>
          <span class="pill violet" title="文章数"><?php echo (int)$cnt; ?></span>
          <form method="post" onsubmit="return confirm('从所有文章中移除标签「<?php echo e($tag); ?>」？')">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="act" value="delete">
            <input type="hidden" name="tag" value="<?php echo e($tag); ?>">
            <button class="btn danger sm" type="submit">删除</button>
          </form>
        </div>
        <form method="post" class="tag-ren">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="act" value="rename">
          <input type="hidden" name="tag" value="<?php echo e($tag); ?>">
          <input type="text" name="new_name" value="<?php echo e($tag); ?>" title="改为新名称">
          <button class="btn sm" type="submit">重命名</button>
        </form>
      </div>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<script>
/* 2.2.20：批量删除 —— 全选 + JS 收集勾选项提交独立 form（避免 form 嵌套） */
(function () {
  var all = document.getElementById('tagCheckAll');
  if (!all) return;
  all.addEventListener('change', function () {
    Array.prototype.forEach.call(document.querySelectorAll('.tag-check'), function (c) { c.checked = all.checked; });
  });
  document.getElementById('tagBatchBtn').addEventListener('click', function () {
    var checked = Array.prototype.filter.call(document.querySelectorAll('.tag-check'), function (c) { return c.checked; });
    if (!checked.length) { window.alert('请先勾选要删除的标签'); return; }
    if (!window.confirm('确定删除勾选的 ' + checked.length + ' 个标签？标签会从所有文章中移除。')) return;
    var box = document.getElementById('tagBatchFields');
    box.innerHTML = '';
    checked.forEach(function (c) {
      var i = document.createElement('input');
      i.type = 'hidden'; i.name = 'tags[]'; i.value = c.value;
      box.appendChild(i);
    });
    document.getElementById('tagBatchForm').submit();
  });
})();
</script>

<p class="hint" style="margin-top:16px">
  💡 标签会显示在文章页底部，前台访问 <code>/tag/标签名</code> 可查看同标签文章；标签同时会补充进文章的 SEO 关键词。
</p>

<?php include 'includes/footer.php'; ?>
