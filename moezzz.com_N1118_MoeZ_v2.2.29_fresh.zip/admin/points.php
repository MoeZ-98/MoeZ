<?php
/**
 * 后台 · 积分商城管理（2.1.0，仅站长）
 * ------------------------------------------------------------
 * 数据层在 includes/points.php（核心模块，与模板无关）：
 *   - 商品：新增 / 编辑 / 上下架 / 排序 / 删除
 *   - 订单：查看兑换记录、撤销并退分
 *   - 会员：手动加减积分（写流水，会员在用户中心能看到）
 *   - 规则：积分名称、签到积分、连签加成、评论得分与每日上限、开关
 */
require __DIR__ . '/bootstrap.php';

$active = 'points';
$page_title = '积分商城';

$me = current_user();
if (!$me) redirect('login.php');
if (!moe_is_owner()) { flash('只有站长可以管理积分商城', 'bad'); redirect('index.php'); }

/* ---- 2.2.4：页签路由 —— 商城资源（默认）｜金币充值（原独立菜单已并入本页） ---- */
$ptTab = (string)($_GET['tab'] ?? 'goods') === 'recharge' ? 'recharge' : 'goods';
if ($ptTab === 'recharge') {
    require __DIR__ . '/includes/recharge-panel.php';
    if (!function_exists('moe_recharge_handle_post')) {
        include 'includes/header.php';
        echo '<div class="card"><p class="hint">充值面板缺失：请重新上传 admin/includes/recharge-panel.php</p></div>';
        include 'includes/footer.php';
        exit;
    }
    moe_recharge_handle_post();
    include 'includes/header.php';
    $page_title = '金币充值';
    // 2.2.9：页签与主页面完全一致（4 个），当前页签高亮；其余页签跳回主页面并自动切到对应面板
    echo '<div class="card" style="padding:10px 14px;margin-bottom:14px"><div class="set-tabs" style="margin:0">'
        . '<a class="set-tab" href="points.php">🛒 商城资源</a>'
        . '<a class="set-tab" href="points.php#orders">📦 兑换与会员</a>'
        . '<a class="set-tab" href="points.php#rules">⚙️ 积分规则</a>'
        . '<a class="set-tab cur" href="points.php?tab=recharge">💰 金币充值</a></div></div>';
    echo moe_recharge_render();
    include 'includes/footer.php';
    exit;
}

if (!function_exists('moe_pt_ready')) {
    include 'includes/header.php';
    echo '<div class="card"><h2 class="card-title">积分模块缺失</h2>'
       . '<p class="hint">找不到 <code>includes/points.php</code>，请重新上传完整程序包（含 includes 目录）。</p></div>';
    include 'includes/footer.php';
    exit;
}

$ready = moe_pt_ready();
$unit  = moe_pt_name();

/* ============================================================
   写操作
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = (string)($_POST['act'] ?? '');

    if ($act === 'save') {
        $id = (int)($_POST['id'] ?? 0);
        $title = trim((string)($_POST['title'] ?? ''));
        if ($title === '') {
            flash('资源名称不能为空', 'bad');
            redirect('points.php' . ($id > 0 ? '?edit=' . $id : ''));
        }
        // 2.2.7：定价方式三选一 —— 仅萌豆 / 仅金币 / 双币同售（不参与的币种存 -1 哨兵）
        $mode = (string)($_POST['price_mode'] ?? 'both');
        if (!in_array($mode, array('points', 'coins', 'both'), true)) $mode = 'both';
        $saved = moe_pt_goods_save(array(
            'title'        => $title,
            'summary'      => (string)($_POST['summary'] ?? ''),
            'cat'          => mb_substr(trim((string)($_POST['cat'] ?? '')), 0, 30, 'UTF-8'),
            'post_id'      => (int)($_POST['post_id'] ?? 0),
            'cover'        => (string)($_POST['cover'] ?? ''),
            'price'        => $mode === 'coins' ? -1 : round(max(0, (float)($_POST['price'] ?? 0)), 2),
            'price_coins'  => $mode === 'points' ? -1 : round(max(0, (float)($_POST['price_coins'] ?? 0)), 2),
            'download_pwd' => trim((string)($_POST['download_pwd'] ?? '')),
            'download_url' => (string)($_POST['download_url'] ?? ''),
            'status'       => ($_POST['status'] ?? 'on') === 'on' ? 'on' : 'off',
            'sort'         => (int)($_POST['sort'] ?? 0),
        ), $id);
        flash($saved !== false ? ($id > 0 ? '资源已更新 ✅' : '资源已添加 ✅') : '保存失败，请检查数据库写入权限',
            $saved !== false ? 'ok' : 'bad');
        redirect('points.php');
    }

    if ($act === 'cats') {
        // 2.2.7：商城分类统一管理（一行一个，存 settings 的 pt_cats）
        $list = array();
        foreach (preg_split('/[\r\n,，]+/u', (string)($_POST['cats'] ?? '')) as $__c) {
            $__c = trim($__c);
            if ($__c !== '' && mb_strlen($__c, 'UTF-8') <= 30 && !in_array($__c, $list, true)) $list[] = $__c;
        }
        setting_set('pt_cats', implode(',', $list));
        flash('分类已保存 ✅ 共 ' . count($list) . ' 个分类', 'ok');
        redirect('points.php');
    }

    if ($act === 'status') {
        $id = (int)($_POST['id'] ?? 0);
        $to = (string)($_POST['to'] ?? 'off');
        $ok = moe_pt_goods_status($id, $to);
        flash($ok ? ($to === 'on' ? '已上架' : '已下架') : '操作失败', $ok ? 'ok' : 'bad');
        redirect('points.php');
    }

    if ($act === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        $ok = moe_pt_goods_delete($id);
        flash($ok ? '资源已删除（已兑换的订单保留，会员仍可下载）' : '删除失败', $ok ? 'ok' : 'bad');
        redirect('points.php');
    }

    if ($act === 'revoke') {
        $r = moe_pt_order_revoke((int)($_POST['id'] ?? 0));
        flash((string)$r['msg'], !empty($r['ok']) ? 'ok' : 'bad');
        redirect('points.php#orders');
    }

    if ($act === 'adjust') {
        $key = trim((string)($_POST['user'] ?? ''));
        $amount = round((float)($_POST['amount'] ?? 0), 2);
        $note = trim((string)($_POST['note'] ?? ''));
        $currency = ($_POST['currency'] ?? 'points') === 'coins' ? 'coins' : 'points';
        $cName = $currency === 'coins' ? '金币' : $unit;
        if ($key === '' || $amount == 0.0) {
            flash('请填写会员与调整数量（正数加分、负数扣分）', 'bad');
            redirect('points.php#adjust');
        }
        $u = null;
        try {
            $u = row('SELECT id, username, nickname FROM ' . moe_table('users')
                . ' WHERE username = ? OR nickname = ? ORDER BY id ASC LIMIT 1', array($key, $key));
        } catch (Throwable $e) { $u = null; }
        if (!$u) {
            flash('没有找到会员「' . $key . '」', 'bad');
            redirect('points.php#adjust');
        }
        $r = moe_pt_add((int)$u['id'], $amount, 'admin', $note !== '' ? $note : '站长调整', $currency);
        flash($r['ok']
            ? ('已' . ($amount > 0 ? '增加' : '扣除') . ' ' . moe_pt_num($amount) . ' ' . $cName . '，当前余额 ' . moe_pt_num($r['balance']))
            : ('调整失败：' . $r['msg']), $r['ok'] ? 'ok' : 'bad');
        redirect('points.php#adjust');
    }

    if ($act === 'settings') {
        $name = trim((string)($_POST['points_name'] ?? ''));
        if ($name === '') $name = '积分';
        setting_set('points_name', mb_substr($name, 0, 8, 'UTF-8'));
        setting_set('points_sign_base', (string)max(0, (int)($_POST['sign_base'] ?? 5)));
        setting_set('points_sign_bonus', (string)max(0, (int)($_POST['sign_bonus'] ?? 2)));
        setting_set('points_sign_maxdays', (string)max(0, min(30, (int)($_POST['sign_maxdays'] ?? 6))));
        setting_set('points_comment', (string)max(0, (int)($_POST['comment'] ?? 2)));
        setting_set('points_comment_daily', (string)max(0, min(50, (int)($_POST['comment_daily'] ?? 3))));
        // 2.2.9：积分 ⇄ 金币互兑比例（0 = 关闭对应方向）；2.2.10：金币自定义名称
        setting_set('points_ex_p2c', (string)max(0, (float)($_POST['ex_p2c'] ?? 0)));
        setting_set('points_ex_c2p', (string)max(0, (float)($_POST['ex_c2p'] ?? 0)));
        $__coin = trim((string)($_POST['coin_name'] ?? ''));
        setting_set('coin_name', $__coin !== '' ? mb_substr($__coin, 0, 8, 'UTF-8') : '金币');
        setting_set('points_enabled', isset($_POST['enabled']) ? '1' : '0');
        setting_set('points_shop_enabled', isset($_POST['shop']) ? '1' : '0');
        flash('规则已保存 ✅ 前台立即生效');
        redirect('points.php#rules');
    }

    if ($act === 'rebuild') {
        setting_set('points_ready', '');
        setting_set('points_ready_fail', '0');
        $ok = moe_pt_ready(true);
        flash($ok ? '数据表检查完成 ✅' : '建表失败：请确认数据库账号有 CREATE TABLE 权限', $ok ? 'ok' : 'bad');
        redirect('points.php');
    }

    redirect('points.php');
}

/* ============================================================
   读取
   ============================================================ */
$edit = null;
if (isset($_GET['edit'])) {
    $edit = moe_pt_good((int)$_GET['edit']);
}

$stat = moe_pt_stats();
$goods = $ready ? (array)rows('SELECT * FROM ' . moe_pt_table('goods') . ' ORDER BY sort ASC, id DESC') : array();

/* 2.2.7：分类统一管理 —— 后台「分类管理」维护的清单（settings pt_cats）优先，
   再补充已用过的分类和常用预置；资源表单和商城筛选胶囊共用这份清单 */
$catOptions = array();
foreach (preg_split('/[\r\n,，]+/u', (string)setting('pt_cats', '')) as $__c) {
    $__c = trim($__c);
    if ($__c !== '' && !in_array($__c, $catOptions, true)) $catOptions[] = $__c;
}
foreach ($goods as $__g) {
    $__c = trim((string)($__g['cat'] ?? ''));
    if ($__c !== '' && !in_array($__c, $catOptions, true)) $catOptions[] = $__c;
}
foreach (array('主题', '插件', '素材', '模板', '工具', '程序') as $__c) {
    if (!in_array($__c, $catOptions, true)) $catOptions[] = $__c;
}
$postOptions = array();
try {
    $postOptions = (array)rows('SELECT id, title FROM ' . moe_table('posts')
        . " WHERE type='post' AND status='published' ORDER BY created_at DESC LIMIT 100");
} catch (Throwable $e) { $postOptions = array(); }
$orders = array();
$logs = array();
$topUsers = array();
$users = array();
if ($ready) {
    try {
        $orders = rows('SELECT o.*, g.title, u.username, u.nickname FROM ' . moe_pt_table('orders') . ' o'
            . ' LEFT JOIN ' . moe_pt_table('goods') . ' g ON g.id = o.goods_id'
            . ' LEFT JOIN ' . moe_table('users') . ' u ON u.id = o.user_id'
            . ' ORDER BY o.id DESC LIMIT 40');
    } catch (Throwable $e) { $orders = array(); }
    try {
        $logs = rows('SELECT l.*, u.username, u.nickname FROM ' . moe_pt_table('log') . ' l'
            . ' LEFT JOIN ' . moe_table('users') . ' u ON u.id = l.user_id'
            . " WHERE l.type = 'admin' OR l.type = 'refund' ORDER BY l.id DESC LIMIT 12");
    } catch (Throwable $e) { $logs = array(); }
    try {
        $topUsers = rows('SELECT p.balance, p.earned, p.spent, u.username, u.nickname, u.id FROM ' . moe_pt_table('points') . ' p'
            . ' LEFT JOIN ' . moe_table('users') . ' u ON u.id = p.user_id'
            . ' ORDER BY p.balance DESC LIMIT 8');
    } catch (Throwable $e) { $topUsers = array(); }
    try {
        $users = rows('SELECT id, username, nickname FROM ' . moe_table('users') . ' ORDER BY id ASC LIMIT 300');
    } catch (Throwable $e) { $users = array(); }
}

include 'includes/header.php';
?>
<div class="card" style="padding:10px 14px;margin-bottom:14px">
  <div class="set-tabs" id="ptTabs" style="margin:0">
    <button type="button" class="set-tab cur" id="tab-pt-pane-goods" data-pane="pt-pane-goods" role="tab" aria-selected="true">🛒 商城资源</button>
    <button type="button" class="set-tab" id="tab-pt-pane-orders" data-pane="pt-pane-orders" role="tab" aria-selected="false">📦 兑换与会员</button>
    <button type="button" class="set-tab" id="tab-pt-pane-rules" data-pane="pt-pane-rules" role="tab" aria-selected="false">⚙️ 积分规则</button>
    <a class="set-tab" href="points.php?tab=recharge">💰 金币充值</a>
  </div>
</div>

<style>
  .pt-pane { display: none; }
  .pt-pane.cur { display: block; }
  .ptm-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:12px; }
  .ptm-kpi { border:1px solid var(--line); border-radius:14px; padding:14px 16px; background:#fdfcff; }
  .ptm-kpi b { display:block; font-size:24px; color:var(--violet); line-height:1.2; }
  .ptm-kpi span { font-size:12px; color:var(--muted); }
  .ptm-thumb { width:46px; height:46px; border-radius:10px; object-fit:cover; background:#f4f0ff; display:block; }
  .ptm-thumb.is-empty { display:flex; align-items:center; justify-content:center; color:#a18cd1; font-weight:800; }
  .ptm-name { display:flex; align-items:center; gap:10px; min-width:180px; }
  .ptm-name b { font-size:13.5px; }
  .ptm-name small { display:block; color:var(--muted); font-size:11.5px; max-width:280px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
  .ptm-form2 { display:grid; grid-template-columns:1fr 1fr; gap:0 14px; }
  .ptm-two { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
  .ptm-note { font-size:12px; color:var(--muted); margin:-4px 0 12px; line-height:1.8; }
  .ptm-top { display:flex; gap:10px; flex-wrap:wrap; align-items:center; margin-bottom:14px; }
  @media (max-width:820px) { .ptm-form2, .ptm-two { grid-template-columns:1fr; } }
</style>

<div class="pt-pane cur" id="pt-pane-goods">
<div class="card">
  <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
    <h2 class="card-title" style="margin:0">积分 · 签到 · 商城</h2>
    <?php if (!$ready): ?><span class="pill bad">数据表未就绪</span><?php endif; ?>
    <?php if ($ready && !moe_pt_shop_on()): ?><span class="pill warn">商城已关闭</span><?php endif; ?>
    <span style="flex:1"></span>
    <a class="btn ghost sm" href="<?php echo e(base_url() . 'shop'); ?>" target="_blank">🛒 前台商城 ↗</a>
    <a class="btn ghost sm" href="<?php echo e(base_url() . 'user?a=points'); ?>" target="_blank">🎁 签到页 ↗</a>
  </div>
  <p class="hint" style="margin:8px 0 16px">
    积分与商城现在由核心模块 <code>includes/points.php</code> 提供，<b>与模板无关</b>：换任何模板，用户中心的「签到积分 / 积分商城 / 我的下载」都在。
    会员签到、发评论自动得分，在商城兑换后即可下载资源。
  </p>

  <div class="ptm-grid">
    <div class="ptm-kpi"><b><?php echo (int)$stat['goods']; ?></b><span>资源总数（在售 <?php echo (int)$stat['on']; ?>）</span></div>
    <div class="ptm-kpi"><b><?php echo (int)$stat['orders']; ?></b><span>累计兑换</span></div>
    <div class="ptm-kpi"><b><?php echo (int)$stat['sign_today']; ?></b><span>今日签到人数</span></div>
    <div class="ptm-kpi"><b><?php echo (int)$stat['points']; ?></b><span>会员<?php echo e($unit); ?>总量</span></div>
    <div class="ptm-kpi"><b><?php echo (int)$stat['members']; ?></b><span>有<?php echo e($unit); ?>的会员</span></div>
  </div>

  <?php if (!$ready): ?>
    <div class="alert bad" style="margin-top:16px">
      数据表还没建好，前台会提示「积分数据表未就绪」。请确认数据库账号有 <code>CREATE TABLE</code> 权限后点下面的按钮重试。
    </div>
    <form method="post" style="margin-top:10px">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="rebuild">
      <button class="btn" type="submit">🔧 重建 / 检查数据表</button>
    </form>
  <?php endif; ?>
</div>

<div class="card" id="add">
  <h2 class="card-title"><?php echo $edit ? '✏️ 编辑资源' : '＋ 上架新资源'; ?></h2>
  <p class="ptm-note">
    下载地址支持两种写法：<b>外链</b>（<code>https://…/file.zip</code>，下载时 302 跳转）或
    <b>站内文件</b>（<code>uploads/2026/11/file.zip</code>，下载时直接输出文件流）。
    价格填 0 表示免费领取（仍需登录点一次「免费领取」）。
  </p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="save">
    <input type="hidden" name="id" value="<?php echo $edit ? (int)$edit['id'] : 0; ?>">
    <div class="ptm-form2">
      <div class="field"><label>资源名称 *</label>
        <input type="text" name="title" required maxlength="120" placeholder="如：Fomalhaut 模板源码包"
               value="<?php echo $edit ? e($edit['title']) : ''; ?>"></div>
      <?php
      // 2.2.7：定价方式三选一
      $pm = $edit ? moe_pt_price_mode_of($edit) : 'both';
      $fPrice  = $edit ? max(0, (float)$edit['price']) : 10;      // 仅金币时价格为 -1，显示默认
      $fCoins  = $edit ? max(0, (float)($edit['price_coins'] ?? 0)) : 0;
      ?>
      <div class="field full"><label>定价方式（三选一）</label>
        <div style="display:flex;gap:16px;flex-wrap:wrap">
          <label style="display:flex;align-items:center;gap:6px;font-size:13.5px"><input type="radio" name="price_mode" value="points" style="width:auto" <?php echo $pm === 'points' ? 'checked' : ''; ?>> 仅<?php echo e($unit); ?>兑换</label>
          <label style="display:flex;align-items:center;gap:6px;font-size:13.5px"><input type="radio" name="price_mode" value="coins" style="width:auto" <?php echo $pm === 'coins' ? 'checked' : ''; ?>> 仅金币兑换</label>
          <label style="display:flex;align-items:center;gap:6px;font-size:13.5px"><input type="radio" name="price_mode" value="both" style="width:auto" <?php echo $pm === 'both' ? 'checked' : ''; ?>> 双币同售（<?php echo e($unit); ?> + 金币）</label>
        </div>
        <p class="hint">「仅<?php echo e($unit); ?>」会员只能用<?php echo e($unit); ?>兑换；「仅金币」只能用金币兑换；「双币同售」两种都可以选。</p>
      </div>
      <div class="field" id="f-price"><label>价格（<?php echo e($unit); ?>，0 = 免费）</label>
        <input type="number" name="price" min="0" step="0.01" value="<?php echo e(moe_pt_num($fPrice)); ?>"></div>
      <div class="field" id="f-coins"><label>价格（金币，0 = 与<?php echo e($unit); ?>同价）</label>
        <input type="number" name="price_coins" min="0" step="0.01" value="<?php echo e(moe_pt_num($fCoins)); ?>">
        <p class="hint">金币单独定价填这里，填 0 按<?php echo e($unit); ?>价格扣（仅金币时 0 = 免费）。</p></div>
      <script>
      (function () {
        function sync() {
          var m = document.querySelector('input[name="price_mode"]:checked');
          if (!m) return;
          var v = m.value, p = document.getElementById('f-price'), c = document.getElementById('f-coins');
          if (p) p.style.display = (v === 'coins') ? 'none' : '';
          if (c) c.style.display = (v === 'points') ? 'none' : '';
        }
        document.querySelectorAll('input[name="price_mode"]').forEach(function (r) { r.addEventListener('change', sync); });
        sync();
      })();
      </script>
      <div class="field"><label>一句话简介</label>
        <input type="text" name="summary" maxlength="255" placeholder="显示在商品卡片上"
               value="<?php echo $edit ? e($edit['summary']) : ''; ?>"></div>
      <div class="field"><label>分类（商城按此归类筛选）</label>
        <select name="cat">
          <option value="">（不分类）</option>
          <?php foreach ($catOptions as $__c): ?>
            <option value="<?php echo e($__c); ?>" <?php echo $edit && trim((string)($edit['cat'] ?? '')) === $__c ? 'selected' : ''; ?>><?php echo e($__c); ?></option>
          <?php endforeach; ?>
          <?php if ($edit && trim((string)($edit['cat'] ?? '')) !== '' && !in_array(trim((string)$edit['cat']), $catOptions, true)): ?>
            <option value="<?php echo e(trim((string)$edit['cat'])); ?>" selected><?php echo e(trim((string)$edit['cat'])); ?>（历史分类，可在下方分类管理中收录）</option>
          <?php endif; ?>
        </select>
        <p class="hint">分类清单在下方「🗂 分类管理」统一维护，商城顶部按这里选的分类展示筛选胶囊。</p></div>
      <div class="field"><label>关联文章（选填，商城卡片可点击前往）</label>
        <select name="post_id">
          <option value="0">不关联</option>
          <?php foreach ($postOptions as $__p): ?>
            <option value="<?php echo (int)$__p['id']; ?>" <?php echo $edit && (int)($edit['post_id'] ?? 0) === (int)$__p['id'] ? 'selected' : ''; ?>>
              <?php echo e(mb_substr((string)$__p['title'], 0, 40, 'UTF-8')); ?>（#<?php echo (int)$__p['id']; ?>）
            </option>
          <?php endforeach; ?>
        </select>
        <p class="hint">选一篇文章介绍这个资源，商城里点封面或标题就能跳过去。</p></div>
      <div class="field"><label>封面图地址（可留空）</label>
        <input type="text" name="cover" maxlength="255" placeholder="https://… 或 uploads/…"
               value="<?php echo $edit ? e($edit['cover']) : ''; ?>"></div>
      <div class="field" style="grid-column:1/-1"><label>下载地址 *</label>
        <input type="text" name="download_url" maxlength="1000" placeholder="https://…/file.zip、uploads/2026/11/file.zip 或网盘分享链接"
               value="<?php echo $edit ? e($edit['download_url']) : ''; ?>">
        <p class="hint">支持媒体库 / 任意 zip 直链（最快最稳）；也支持蓝奏云、微云等网盘分享链接——有密码时把密码填到下方「下载密码」栏即可，程序在线更新会自动解析成临时直链下载（百度网盘分享需登录账号，服务器端无法直取，请勿使用）。</p></div>
      <div class="field" style="grid-column:1/-1"><label>下载密码（选填）</label>
        <input type="text" name="download_pwd" maxlength="64" placeholder="资源没有密码就留空"
               value="<?php echo $edit ? e($edit['download_pwd'] ?? '') : ''; ?>">
        <p class="hint">网盘提取码 / 解压密码都可填这里：在线更新下载网盘文件时会自动带上；同时下载卡片上会给未兑换的读者显示 🔒 标记，已兑换的读者直接看到密码。</p></div>
      <div class="field"><label>排序（小的在前）</label>
        <input type="number" name="sort" step="1" value="<?php echo $edit ? (int)$edit['sort'] : 0; ?>"></div>
      <div class="field"><label>状态</label>
        <select name="status">
          <option value="on" <?php echo (!$edit || (string)$edit['status'] === 'on') ? 'selected' : ''; ?>>上架（前台可见）</option>
          <option value="off" <?php echo ($edit && (string)$edit['status'] === 'off') ? 'selected' : ''; ?>>下架（前台隐藏）</option>
        </select></div>
    </div>
    <div class="form-foot" style="border-top:1px dashed var(--line);padding-top:16px;margin-top:6px">
      <button class="btn" type="submit"><?php echo $edit ? '💾 保存修改' : '＋ 添加到商城'; ?></button>
      <?php if ($edit): ?><a class="btn ghost" href="points.php">取消编辑</a><?php endif; ?>
    </div>
  </form>
</div>

<div class="card">
  <h2 class="card-title">🗂 分类管理 <span style="color:var(--muted);font-weight:400;font-size:12.5px">商城筛选胶囊与资源表单共用这份清单</span></h2>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="cats">
    <div style="display:flex;gap:14px;align-items:flex-start;flex-wrap:wrap">
      <textarea name="cats" rows="4" style="flex:1;min-width:260px;padding:11px 14px;border:1.5px solid #e8e2f0;border-radius:12px;outline:none;resize:vertical;font-family:inherit;font-size:13.5px;line-height:1.9" placeholder="一行一个分类，如：&#10;主题&#10;插件&#10;素材&#10;程序"><?php echo e(implode("\n", $catOptions)); ?></textarea>
      <div style="flex:none;max-width:280px;font-size:12.5px;color:var(--muted);line-height:1.9">
        一行一个分类，保存后：<br>· 新增/编辑资源的「分类」下拉直接选<br>· 商城顶部按这份清单展示筛选胶囊<br>· 当前共 <?php echo count($catOptions); ?> 个分类
      </div>
    </div>
    <p style="margin-top:12px"><button class="btn sm" type="submit">💾 保存分类</button></p>
  </form>
</div>

<div class="card">
  <h2 class="card-title">🛒 资源列表（<?php echo count($goods); ?>）</h2>
  <?php if (!$goods): ?>
    <p class="hint">还没有资源，用上面的表单上架第一个吧～</p>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead><tr><th>资源</th><th>价格</th><th>下载数</th><th>状态</th><th>排序</th><th>操作</th></tr></thead>
      <tbody>
      <?php foreach ($goods as $g): $cid = (int)$g['id']; ?>
        <tr>
          <td class="t-title">
            <div class="ptm-name">
              <?php if (trim((string)$g['cover']) !== ''): ?>
                <img class="ptm-thumb" src="<?php echo e(media_url((string)$g['cover'])); ?>" alt="">
              <?php else: ?>
                <span class="ptm-thumb is-empty"><?php echo e(mb_substr((string)$g['title'], 0, 1, 'UTF-8')); ?></span>
              <?php endif; ?>
              <div><b><?php echo e($g['title']); ?></b><small><?php echo e((string)$g['summary'] !== '' ? $g['summary'] : '—'); ?></small></div>
            </div>
          </td>
          <td><?php $pmk = moe_pt_price_mode_of($g); ?><span class="pill violet"><?php echo e(moe_pt_price_label_of($g)); ?></span>
            <?php if ($pmk === 'coins'): ?><span class="pill" title="定价方式：仅金币">仅金币</span>
            <?php elseif ($pmk === 'points'): ?><span class="pill" title="定价方式：仅<?php echo e($unit); ?>">仅<?php echo e($unit); ?></span><?php endif; ?>
            <?php if ((int)($g['post_id'] ?? 0) > 0): ?><span class="pill ok" title="已关联文章">📖</span><?php endif; ?></td>
          <td><?php echo (int)$g['downloads']; ?></td>
          <td><span class="pill <?php echo (string)$g['status'] === 'on' ? 'ok' : 'warn'; ?>"><?php echo (string)$g['status'] === 'on' ? '在售' : '已下架'; ?></span></td>
          <td><?php echo (int)$g['sort']; ?></td>
          <td>
            <div class="acts">
              <a class="btn ghost sm" href="points.php?edit=<?php echo $cid; ?>">编辑</a>
              <form method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="status">
                <input type="hidden" name="id" value="<?php echo $cid; ?>">
                <input type="hidden" name="to" value="<?php echo (string)$g['status'] === 'on' ? 'off' : 'on'; ?>">
                <button class="btn ghost sm" type="submit"><?php echo (string)$g['status'] === 'on' ? '下架' : '上架'; ?></button>
              </form>
              <form method="post" onsubmit="return confirm('删除「<?php echo e($g['title']); ?>」？已兑换的订单会保留。')">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="delete">
                <input type="hidden" name="id" value="<?php echo $cid; ?>">
                <button class="btn danger sm" type="submit">删除</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>
</div><!-- /pt-pane-goods -->

<div class="pt-pane" id="pt-pane-orders">
<div class="card" id="orders">
  <h2 class="card-title">📦 兑换订单（最近 <?php echo count($orders); ?> 条）</h2>
  <p class="ptm-note">撤销订单会把积分退回会员并删除订单记录，会员需要重新兑换。</p>
  <?php if (!$orders): ?>
    <p class="hint">还没有兑换记录。</p>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead><tr><th>会员</th><th>资源</th><th>花费</th><th>时间</th><th>操作</th></tr></thead>
      <tbody>
      <?php foreach ($orders as $o): ?>
        <tr>
          <td><b><?php echo e(trim((string)$o['nickname']) !== '' ? $o['nickname'] : (string)$o['username']); ?></b>
            <small style="color:var(--muted);display:block">@<?php echo e((string)$o['username']); ?></small></td>
          <td class="t-title"><?php echo e(trim((string)$o['title']) !== '' ? $o['title'] : '（资源已删除）'); ?></td>
          <td><span class="pill violet"><?php echo moe_pt_num($o['price']); ?> <?php echo e($unit); ?></span></td>
          <td style="color:var(--muted);font-size:12.5px"><?php echo e(date('Y-m-d H:i', strtotime((string)$o['created_at']))); ?></td>
          <td>
            <form method="post" onsubmit="return confirm('撤销这笔订单并把 <?php echo moe_pt_num($o['price']); ?> <?php echo e($unit); ?> 退回会员？')">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="act" value="revoke">
              <input type="hidden" name="id" value="<?php echo (int)$o['id']; ?>">
              <button class="btn ghost sm" type="submit">撤销并退分</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<div class="ptm-two">
  <div class="card" id="adjust">
    <h2 class="card-title">🎁 手动调分</h2>
    <p class="ptm-note">用于补偿、活动奖励或扣除异常积分。调整会写进流水，会员在用户中心能看到备注。</p>
    <form method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="act" value="adjust">
      <div class="field"><label>会员（用户名 / 昵称）</label>
        <input type="text" name="user" list="ptm-users" required placeholder="输入后从下拉选择">
        <datalist id="ptm-users">
          <?php foreach ($users as $u): ?>
            <option value="<?php echo e((string)$u['username']); ?>"><?php echo e(trim((string)$u['nickname']) !== '' ? $u['nickname'] : $u['username']); ?></option>
          <?php endforeach; ?>
        </datalist>
      </div>
      <div class="field"><label>数量（正数加分 / 负数扣分）</label>
        <input type="number" name="amount" step="0.01" required placeholder="例如 20、-10 或 0.5"></div>
      <div class="field"><label>调整对象</label>
        <select name="currency">
          <option value="points"><?php echo e($unit); ?>（签到 / 评论获得）</option>
          <option value="coins">金币（充值获得）</option>
        </select></div>
      <div class="field"><label>备注</label>
        <input type="text" name="note" maxlength="160" placeholder="如：活动奖励 / 补发签到积分"></div>
      <button class="btn" type="submit">写入流水</button>
    </form>
  </div>

  <div class="card">
    <h2 class="card-title">🏆 <?php echo e($unit); ?>排行</h2>
    <?php if (!$topUsers): ?>
      <p class="hint">还没有会员获得<?php echo e($unit); ?>。</p>
    <?php else: ?>
      <div class="table-wrap">
        <table class="tbl">
          <thead><tr><th>会员</th><th>余额</th><th>累计获得</th></tr></thead>
          <tbody>
          <?php foreach ($topUsers as $i => $t): ?>
            <tr>
              <td><b><?php echo (int)$i + 1; ?>. <?php echo e(trim((string)$t['nickname']) !== '' ? $t['nickname'] : (string)$t['username']); ?></b></td>
              <td><span class="pill violet"><?php echo moe_pt_num($t['balance']); ?></span></td>
              <td style="color:var(--muted)"><?php echo (int)$t['earned']; ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
    <?php if ($logs): ?>
      <h3 style="font-size:13px;margin:18px 0 8px;color:var(--muted)">最近手动调整 / 退回</h3>
      <?php foreach ($logs as $l): ?>
        <div style="display:flex;justify-content:space-between;gap:10px;padding:7px 0;border-bottom:1px dashed var(--line);font-size:12.5px">
          <span><?php echo e(trim((string)$l['nickname']) !== '' ? $l['nickname'] : (string)$l['username']); ?>
            · <?php echo e((string)$l['note']); ?></span>
          <b style="color:<?php echo (float)$l['amount'] >= 0 ? 'var(--ok)' : 'var(--bad)'; ?>">
            <?php echo (float)$l['amount'] > 0 ? '+' : ''; ?><?php echo moe_pt_num($l['amount']); ?></b>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
</div><!-- /pt-pane-orders -->

<div class="pt-pane" id="pt-pane-rules">
<div class="card" id="rules">
  <h2 class="card-title">⚙️ 积分规则</h2>
  <p class="ptm-note">改完保存立即生效：签到弹窗、评论提示、商城价格单位都会跟着变。</p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="settings">
    <div class="ptm-form2">
      <div class="field"><label>积分名称（最多 8 字）</label>
        <input type="text" name="points_name" maxlength="8" value="<?php echo e((string)moe_pt_opt('name')); ?>" placeholder="积分 / 星币 / 萌">
        <p class="hint">前台所有位置统一显示这个名称。</p></div>
      <div class="field"><label>每日签到基础积分</label>
        <input type="number" name="sign_base" min="0" step="1" value="<?php echo (int)moe_pt_opt('sign_base', '5'); ?>"></div>
      <div class="field"><label>连签加成（每天多加）</label>
        <input type="number" name="sign_bonus" min="0" step="1" value="<?php echo (int)moe_pt_opt('sign_bonus', '2'); ?>">
        <p class="hint">连签第 2 天 +1 档、第 3 天 +2 档…</p></div>
      <div class="field"><label>连签加成最多算几天</label>
        <input type="number" name="sign_maxdays" min="0" max="30" step="1" value="<?php echo (int)moe_pt_opt('sign_maxdays', '6'); ?>">
        <p class="hint">防止长期连签无限刷分，默认 6 天封顶。</p></div>
      <div class="field"><label>每条评论得分</label>
        <input type="number" name="comment" min="0" step="1" value="<?php echo (int)moe_pt_opt('comment', '2'); ?>">
        <p class="hint">填 0 表示关闭评论得分。</p></div>
      <div class="field"><label>评论得分每日上限（次）</label>
        <input type="number" name="comment_daily" min="0" max="50" step="1" value="<?php echo (int)moe_pt_opt('comment_daily', '3'); ?>">
        <p class="hint">填 0 表示不限次数。</p></div>
      <div class="field"><label>金币名称（前台展示用，最多 8 字）</label>
        <input type="text" name="coin_name" maxlength="8" value="<?php echo e(function_exists('moe_pt_coin_name') ? moe_pt_coin_name() : '金币'); ?>">
        <p class="hint">例如改成「萌豆币」「钻石」，商城、充值、互兑里的「金币」都会跟随显示。</p></div>
      <div class="field"><label>积分兑金币比例（多少<?php echo e((string)moe_pt_opt('name')); ?> = 1 <?php echo e(function_exists('moe_pt_coin_name') ? moe_pt_coin_name() : '金币'); ?>）</label>
        <input type="number" name="ex_p2c" min="0" step="0.1" value="<?php echo e((string)moe_pt_opt('ex_p2c', '0')); ?>">
        <p class="hint">填 100 表示 100<?php echo e((string)moe_pt_opt('name')); ?>可兑 1 个；填 0 关闭该方向。</p></div>
      <div class="field"><label><?php echo e(function_exists('moe_pt_coin_name') ? moe_pt_coin_name() : '金币'); ?>兑<?php echo e((string)moe_pt_opt('name')); ?>比例（1 个 = 多少<?php echo e((string)moe_pt_opt('name')); ?>）</label>
        <input type="number" name="ex_c2p" min="0" step="0.1" value="<?php echo e((string)moe_pt_opt('ex_c2p', '0')); ?>">
        <p class="hint">填 50 表示 1 个可兑 50<?php echo e((string)moe_pt_opt('name')); ?>；填 0 关闭该方向。</p></div>
    </div>
    <div class="check-row" style="margin:6px 0 4px">
      <label><input type="checkbox" name="enabled" value="1" <?php echo moe_pt_on() ? 'checked' : ''; ?>> 启用积分功能（关闭后签到、评论得分都停止）</label>
    </div>
    <div class="check-row" style="margin-bottom:14px">
      <label><input type="checkbox" name="shop" value="1" <?php echo moe_pt_shop_on() ? 'checked' : ''; ?>> 开放积分商城与下载</label>
    </div>
    <div class="form-foot" style="border-top:1px dashed var(--line);padding-top:16px">
      <button class="btn" type="submit">💾 保存规则</button>
      <a class="btn ghost" href="settings.php">站点设置</a>
    </div>
  </form>
</div>
</div><!-- /pt-pane-rules -->

<script>
(function () {
  /* 2.2.8：页签切换（与站点设置同款交互，记住上次停留的页签） */
  var box = document.getElementById('ptTabs');
  if (!box) return;
  var panes = document.querySelectorAll('.pt-pane');
  function show(id) {
    Array.prototype.forEach.call(box.querySelectorAll('.set-tab[data-pane]'), function (t) {
      var on = t.dataset.pane === id;
      t.className = on ? 'set-tab cur' : 'set-tab';
      t.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    Array.prototype.forEach.call(panes, function (p) {
      p.className = p.id === id ? 'pt-pane cur' : 'pt-pane';
    });
    try { localStorage.setItem('moe_pt_tab', id); } catch (e) {}
  }
  box.addEventListener('click', function (ev) {
    var t = ev.target;
    while (t && t !== box && !(t.dataset && t.dataset.pane)) t = t.parentNode;
    if (t && t !== box && t.dataset && t.dataset.pane) show(t.dataset.pane);
  });
  /* 锚点优先：撤销订单（#orders）、调分（#adjust）等操作后自动回到对应页签 */
  var h = (location.hash || '').replace('#', '');
  if (h && document.getElementById(h)) {
    var host = document.getElementById(h).closest('.pt-pane');
    if (host) { show(host.id); return; }
  }
  var last = null;
  try { last = localStorage.getItem('moe_pt_tab'); } catch (e) {}
  if (last && document.getElementById(last)) show(last);
})();
</script>

<?php include 'includes/footer.php'; ?>
