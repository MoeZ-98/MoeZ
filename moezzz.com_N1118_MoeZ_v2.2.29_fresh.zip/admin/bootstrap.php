<?php
/**
 * MoeZ - 后台引导（除 login.php 外所有后台页面均引入本文件）
 */
define('MOE_ADMIN', true);
require dirname(__DIR__) . '/init.php';

// 兼容：若 init.php 仍是旧版（未加载新增模块），这里补载一次
// 场景：覆盖上传不完整时，避免出现 Call to undefined function content_words() 之类的白屏
if (!function_exists('content_words') && is_file(dirname(__DIR__) . '/includes/markdown.php')) {
    require_once dirname(__DIR__) . '/includes/markdown.php';
}
if (!function_exists('post_url') && is_file(dirname(__DIR__) . '/includes/seo.php')) {
    require_once dirname(__DIR__) . '/includes/seo.php';
}

// 结构自愈：init.php 未同步覆盖 / 升级被跳过时，这里补一次缺失字段（补全后零开销）
if (function_exists('moe_ensure_schema')) moe_ensure_schema();

// 后台固定 utf-8
header('Content-Type: text/html; charset=utf-8');

// 已登录且访问 login.php 的直接进仪表盘（在 login.php 内处理）
require_admin();

// 2.0.0：细粒度权限 —— 作者可进后台写内容，但不能碰设置 / 模板 / 用户管理
if (function_exists('moe_admin_guard')) moe_admin_guard();

/** 输出后台消息提示 */
function flash($msg, $type = 'ok') {
    $_SESSION['moe_flash'][] = array('msg' => $msg, 'type' => $type);
}
function take_flash() {
    $f = isset($_SESSION['moe_flash']) ? $_SESSION['moe_flash'] : array();
    unset($_SESSION['moe_flash']);
    return $f;
}
