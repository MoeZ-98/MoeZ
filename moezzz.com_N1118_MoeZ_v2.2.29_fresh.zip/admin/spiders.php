<?php
/**
 * 后台 · 蜘蛛来访记录
 * 只展示国内主流搜索引擎（百度 / 360 / 搜狗 / 必应）已校验身份的真实蜘蛛，
 * 支持按单个蜘蛛单独查看，并可一键清理无效（伪装 / 非国内引擎）历史记录
 */
require __DIR__ . '/bootstrap.php';
$active = 'spiders';
$page_title = '蜘蛛来访';

$engines = function_exists('moe_spider_engines')
    ? array_keys(moe_spider_engines())
    : array('百度', '360搜索', '搜狗', '必应');
$enginePlace = implode(',', array_fill(0, count($engines), '?'));
$ico = function_exists('moe_spider_icons') ? moe_spider_icons() : array('百度' => '🐾', '360搜索' => '🔄', '搜狗' => '🐕', '必应' => '🅱');

$engine = trim((string)($_GET['engine'] ?? ''));
if ($engine !== '' && !in_array($engine, $engines, true)) $engine = '';
$page = max(1, (int)($_GET['page'] ?? 1));
$per  = 30;

/* ---- 清理无效记录 ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (($_POST['act'] ?? '') === 'clean') {
        $removed = 0;
        try {
            // 1) 非国内搜索引擎的历史记录直接清理
            $st = q('DELETE FROM ' . moe_table('spiders') . ' WHERE spider NOT IN (' . $enginePlace . ')', $engines);
            $removed += $st->rowCount();

            // 2) 重新校验 IP（每次最多 60 组，结果带缓存），只删除明确伪造的记录
            $ips = rows('SELECT DISTINCT ip, spider FROM ' . moe_table('spiders') . ' LIMIT 60');
            foreach ((array)$ips as $r) {
                $ip = (string)$r['ip'];
                if ($ip === '') continue;
                if (moe_spider_is_fake($ip, (string)$r['spider'])) {
                    $st = q('DELETE FROM ' . moe_table('spiders') . ' WHERE ip = ? AND spider = ?', array($ip, (string)$r['spider']));
                    $removed += $st->rowCount();
                }
            }
            flash($removed > 0 ? '已清理 ' . $removed . ' 条无效蜘蛛记录' : '没有发现无效记录，现存记录均为已校验的真实蜘蛛');
        } catch (Throwable $e) {
            flash('清理失败：' . $e->getMessage(), 'bad');
        }
    }
    redirect('spiders.php' . ($engine !== '' ? '?engine=' . rawurlencode($engine) : ''));
}

/* ---- 列表 ---- */
$where = ' WHERE spider IN (' . $enginePlace . ')';
$args  = $engines;
if ($engine !== '') { $where .= ' AND spider = ?'; $args[] = $engine; }

$total = 0; $items = array(); $summary = array(); $today = array(); $allTotal = 0;
try {
    $total = (int)one('SELECT COUNT(*) FROM ' . moe_table('spiders') . $where, $args);
    $offset = ($page - 1) * $per;
    $items = rows('SELECT * FROM ' . moe_table('spiders') . $where . ' ORDER BY id DESC LIMIT ' . $offset . ', ' . $per, $args);

    $summary = rows('SELECT spider, COUNT(*) AS n, MAX(created_at) AS last_at FROM ' . moe_table('spiders')
        . ' WHERE spider IN (' . $enginePlace . ') GROUP BY spider ORDER BY n DESC', $engines);
    foreach ((array)$summary as $r) $allTotal += (int)$r['n'];

    foreach (rows('SELECT spider, COUNT(*) AS n FROM ' . moe_table('spiders')
        . ' WHERE created_at >= CURDATE() AND spider IN (' . $enginePlace . ') GROUP BY spider', $engines) as $r) {
        $today[$r['spider']] = (int)$r['n'];
    }
} catch (Throwable $e) { /* 表未就绪，按空列表渲染 */ }

$pageBase = 'spiders.php?' . ($engine !== '' ? 'engine=' . rawurlencode($engine) . '&' : '') . 'page=';

/**
 * 解析蜘蛛抓取的路径为可读内容：类型徽章 + 标题 + 前台链接
 * 支持首页 / robots.txt / sitemap.xml / RSS / 搜索 / 标签 / 分类 /
 * 文章（/{分类}/{编号}.html 与 /{编号}.html 两种样式）/ 独立页面（/{slug}.html 与 /{slug}）
 */
function moe_spider_describe($raw)
{
    $raw  = (string)$raw;
    $path = preg_replace('#^/index\.php#i', '', $raw);   // 伪静态不彻底的 /index.php/xxx 前缀先剥掉
    if ($path === '' || $path === '/' || $path === null) {
        return array('type' => '首页', 'cls' => 'ok', 'label' => '网站首页', 'url' => base_url(), 'raw' => $raw);
    }

    $decoded = rawurldecode($path);
    $segs = array_values(array_filter(explode('/', trim($decoded, '/')), 'strlen'));

    $look = function ($sql, $args) {
        try { return row($sql, $args); } catch (Throwable $e) { return null; }
    };

    /* 特殊文件 */
    if (count($segs) === 1) {
        $f = strtolower($segs[0]);
        if ($f === 'robots.txt')  return array('type' => '协议', 'cls' => '',      'label' => '🤖 Robots 协议文件', 'url' => base_url() . 'robots.txt',  'raw' => $raw);
        if ($f === 'sitemap.xml') return array('type' => '地图', 'cls' => '',      'label' => '🗺 站点地图',        'url' => base_url() . 'sitemap.xml', 'raw' => $raw);
        if ($f === 'favicon.ico') return array('type' => '图标', 'cls' => '',      'label' => '站点图标',          'url' => base_url() . 'favicon.ico', 'raw' => $raw);
        if ($f === 'rss' || $f === 'feed' || $f === 'rss.xml') {
            return array('type' => '订阅', 'cls' => '', 'label' => '📡 RSS 订阅', 'url' => base_url() . 'rss', 'raw' => $raw);
        }
    }

    if (!empty($segs)) {
        $s0 = $segs[0];

        if (strcasecmp($s0, 'search') === 0) {
            $kw = isset($segs[1]) ? $segs[1] : '';
            return array('type' => '搜索', 'cls' => '', 'label' => '搜索「' . ($kw !== '' ? $kw : '…') . '」', 'url' => base_url() . 'search/' . rawurlencode($kw), 'raw' => $raw);
        }
        if (strcasecmp($s0, 'tag') === 0) {
            $kw = isset($segs[1]) ? $segs[1] : '';
            return array('type' => '标签', 'cls' => '', 'label' => '标签「' . ($kw !== '' ? $kw : '…') . '」聚合页', 'url' => base_url() . 'tag/' . rawurlencode($kw), 'raw' => $raw);
        }
        /* /category/{slug} */
        if (count($segs) === 2 && strcasecmp($s0, 'category') === 0) {
            $cat = $look('SELECT * FROM ' . moe_table('categories') . ' WHERE slug = ?', array($segs[1]));
            if ($cat) return array('type' => '分类', 'cls' => 'violet', 'label' => '分类「' . $cat['name'] . '」', 'url' => cat_url($cat), 'raw' => $raw);
        }
        /* /{分类别名}/{编号}.html → 分类下的文章 */
        if (count($segs) === 2 && preg_match('#^(\d+)\.html$#', $segs[1], $m)) {
            $cat = $look('SELECT * FROM ' . moe_table('categories') . ' WHERE slug = ?', array($s0));
            if ($cat) {
                $post = $look('SELECT * FROM ' . moe_table('posts') . " WHERE type='post' AND status='published' AND category_id = ? AND url_num = ?",
                    array((int)$cat['id'], (int)$m[1]));
                if ($post) return array('type' => '文章', 'cls' => 'ok', 'label' => $post['title'], 'url' => post_url($post), 'raw' => $raw);
                return array('type' => '分类', 'cls' => 'violet', 'label' => '分类「' . $cat['name'] . '」列表', 'url' => cat_url($cat), 'raw' => $raw);
            }
        }
        /* /{编号}.html → 文章（编号直链样式） */
        if (count($segs) === 1 && preg_match('#^(\d+)\.html$#', $s0, $m)) {
            $post = $look('SELECT * FROM ' . moe_table('posts') . " WHERE type='post' AND status='published' AND id = ?", array((int)$m[1]));
            if ($post) return array('type' => '文章', 'cls' => 'ok', 'label' => $post['title'], 'url' => post_url($post), 'raw' => $raw);
        }
        /* /{slug}.html → 独立页面 */
        if (count($segs) === 1 && preg_match('#^(.+)\.html$#', $s0, $m)) {
            $pg = $look('SELECT * FROM ' . moe_table('posts') . " WHERE type='page' AND slug = ?", array($m[1]));
            if ($pg && $pg['status'] === 'published') {
                return array('type' => '页面', 'cls' => 'violet', 'label' => '页面「' . $pg['title'] . '」', 'url' => page_url($pg), 'raw' => $raw);
            }
        }
        /* /{slug} → 分类或页面（无后缀） */
        if (count($segs) === 1 && preg_match('#^[a-zA-Z0-9_\-\x{4e00}-\x{9fa5}]+$#u', $s0)) {
            $cat = $look('SELECT * FROM ' . moe_table('categories') . ' WHERE slug = ?', array($s0));
            if ($cat) return array('type' => '分类', 'cls' => 'violet', 'label' => '分类「' . $cat['name'] . '」列表', 'url' => cat_url($cat), 'raw' => $raw);
            $pg = $look('SELECT * FROM ' . moe_table('posts') . " WHERE type='page' AND slug = ?", array($s0));
            if ($pg && $pg['status'] === 'published') {
                return array('type' => '页面', 'cls' => 'violet', 'label' => '页面「' . $pg['title'] . '」', 'url' => page_url($pg), 'raw' => $raw);
            }
        }
    }

    /* 未匹配（抓了不存在的地址 / 外部程序路径）：橙色提示，仍可点击打开 */
    return array('type' => '未匹配', 'cls' => 'warn', 'label' => '蜘蛛抓取了不在站内的地址', 'url' => base_url() . ltrim($path, '/'), 'raw' => $raw);
}

include 'includes/header.php';
?>

<div class="card">
  <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:14px">
    <h2 class="card-title" style="margin:0">🕷 蜘蛛来访记录（<?php echo $total; ?>）</h2>
    <span style="flex:1"></span>
    <form method="post" onsubmit="return confirm('将清理非国内引擎与身份校验失败的蜘蛛记录，确定继续吗？')">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="act" value="clean">
      <button class="btn ghost sm" type="submit">🧹 校验并清理无效记录</button>
    </form>
  </div>

  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px">
    <a class="pill <?php echo $engine === '' ? 'violet' : ''; ?>"
       style="border:1.5px solid var(--line);padding:5px 14px" href="spiders.php">全部 <?php echo $allTotal; ?></a>
    <?php foreach ($engines as $en): ?>
      <?php
      $n = 0;
      foreach ((array)$summary as $r) { if ($r['spider'] === $en) { $n = (int)$r['n']; break; } }
      ?>
      <a class="pill <?php echo $engine === $en ? 'violet' : ''; ?>"
         style="border:1.5px solid var(--line);padding:5px 14px"
         href="spiders.php?engine=<?php echo rawurlencode($en); ?>"
         title="只查看「<?php echo e($en); ?>」的抓取记录">
        <?php echo $ico[$en] ?? '🕷'; ?> <?php echo e($en); ?> <?php echo $n; ?>
        <?php if (!empty($today[$en])): ?><span style="color:var(--muted)">（今日 <?php echo (int)$today[$en]; ?>）</span><?php endif; ?>
      </a>
    <?php endforeach; ?>
  </div>

  <?php if (empty($items)): ?>
    <p style="color:var(--muted);text-align:center;padding:30px">
      暂无记录。这里只保留已校验身份的真实蜘蛛（百度 / 360 / 搜狗 / 必应），伪装与无效蜘蛛会自动屏蔽。
    </p>
  <?php endif; ?>
  <?php foreach ($items as $s): $d = moe_spider_describe($s['path']); ?>
    <?php $rawFull = base_url() . ltrim((string)$s['path'], '/'); ?>
    <div style="border:1.5px solid #e8e2f0;border-radius:26px;padding:9px 18px;margin-bottom:10px;background:#fff;
                display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <span style="font-size:12px;color:var(--muted);white-space:nowrap"><?php echo e(format_time($s['created_at'], 'm-d H:i:s')); ?></span>
      <span style="flex:none;font-size:12px;font-weight:600;padding:3px 12px;border-radius:99px;background:#f4effb;color:#7a5fae;white-space:nowrap">
        <?php echo $ico[$s['spider']] ?? '🕷'; ?> <?php echo e($s['spider']); ?>
      </span>
      <code style="flex:none;font-size:11.5px;padding:3px 10px;border-radius:99px;background:#f6f7f9;color:#7a6d95;border:1px solid #ececf2;white-space:nowrap"><?php echo e($s['ip'] !== '' ? $s['ip'] : '—'); ?></code>
      <a href="<?php echo e($d['url']); ?>" target="_blank" rel="noopener" style="color:inherit;text-decoration:none;min-width:0">
        <span class="pill <?php echo $d['cls']; ?>" style="vertical-align:1px"><?php echo e($d['type']); ?></span>
        <b style="font-size:12.5px;color:#4a4060"><?php echo e($d['label']); ?></b>
      </a>
      <span style="flex:1"></span>
      <a href="<?php echo e($rawFull); ?>" target="_blank" rel="noopener" title="蜘蛛请求的完整地址（点击打开）"
         style="font-size:11.5px;color:#8f9bb3;word-break:break-all;min-width:140px;text-decoration:none">↳ <?php echo e($rawFull); ?></a>
    </div>
  <?php endforeach; ?>

  <div class="pager">
    <?php
    if ($total > $per) {
      $pages = (int)ceil($total / $per);
      for ($i = 1; $i <= $pages; $i++) {
        if ($pages > 12 && abs($i - $page) > 3 && $i > 2 && $i < $pages - 1) { if ($i === 3) echo '<span>…</span>'; continue; }
        echo $i === $page
          ? '<span class="cur">' . $i . '</span>'
          : '<a href="' . e($pageBase . $i) . '">' . $i . '</a>';
      }
    }
    ?>
  </div>

  <p class="hint" style="margin-top:12px">
    判定方式：UA 命中 → 反向 DNS 落在引擎自有域名（百度 *.baidu.com、360 *.360.cn、搜狗 *.sogou.com、必应 *.search.msn.com）并正向解析回同一 IP；
    反向 DNS 不可用时用引擎官方 IP 段兜底。伪装蜘蛛不会写入记录。<br>
    「抓取内容」列会把请求路径自动解析成对应的文章 / 分类 / 页面 / 协议文件，点击可直达前台；「未匹配」表示蜘蛛抓了站内不存在的地址（可能是死链或探测路径），可据此排查。
  </p>
</div>

<?php include 'includes/footer.php'; ?>