<?php
/**
 * 后台 · Markdown / HTML 实时预览接口
 */
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

$token = isset($_POST['_token']) ? (string)$_POST['_token'] : '';
if ($token === '' || empty($_SESSION['moe_csrf']) || !hash_equals((string)$_SESSION['moe_csrf'], $token)) {
    json_exit(false, '令牌校验失败，请刷新页面重试');
}

$content = isset($_POST['content']) ? (string)$_POST['content'] : '';
$format  = (isset($_POST['format']) && $_POST['format'] === 'html') ? 'html' : 'markdown';

json_exit(true, '', array(
    'html'  => render_content($content, $format),
    'words' => content_words($content, $format),
));
