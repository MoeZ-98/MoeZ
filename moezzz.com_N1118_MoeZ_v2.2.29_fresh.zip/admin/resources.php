<?php
/**
 * 后台 · 资源管理（1.8.4）
 * 列出 uploads/ 下全部图片 / 视频 / 音频 / 附件文件：
 *   - 图片直接缩略图预览；显示大小、修改时间、被文章/页面引用次数
 *   - 支持多选批量删除（被引用的文件会给出提示但也可以强制删除）
 */
require __DIR__ . '/bootstrap.php';
$active = 'resources';
$page_title = '资源管理';

if (!function_exists('moe_list_upload_files')) {
    // 兼容覆盖上传不完整：核心函数缺失时动态补载
    if (is_file(dirname(__DIR__) . '/includes/functions.php')) require_once dirname(__DIR__) . '/includes/functions.php';
}

/* ---- 批量删除 ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = $_POST['act'] ?? '';
    if ($act === 'delete' && function_exists('moe_upload_path_safe')) {
        // 2.2.10：单文件删除（卡片右下角删除按钮）；rel64 优先，兼容历史编码文件名
        $rel = str_replace('\\', '/', trim((string)($_POST['rel'] ?? '')));
        $rel64 = (string)($_POST['rel64'] ?? '');
        if ($rel64 !== '') {
            $dec = base64_decode($rel64, true);
            if ($dec !== false && $dec !== '') $rel = str_replace('\\', '/', $dec);
        }
        $force = !empty($_POST['force']);
        if ($rel === '' || !moe_upload_path_safe($rel)) {
            flash('文件不存在或路径不合法', 'bad');
        } else {
            $refs = function_exists('moe_asset_collect_refs') ? moe_asset_collect_refs() : array();
            $used = function_exists('moe_asset_usage_count') ? moe_asset_usage_count($rel, $refs) : 0;
            if ($used > 0 && !$force) {
                flash('「' . basename($rel) . '」仍被 ' . $used . ' 处内容引用，已跳过删除。'
                    . '如确认要删，请再点一次删除按钮并选择「强制删除」', 'bad');
            } elseif (@unlink(dirname(__DIR__) . '/' . $rel)) {
                flash('已删除 ' . basename($rel) . ' 🧹');
            } else {
                flash('删除失败，请检查文件权限', 'bad');
            }
        }
        redirect('resources.php');
    }
    if ($act === 'batch_delete' && function_exists('moe_upload_path_safe')) {
        $targets = array();
        foreach ((array)($_POST['files'] ?? array()) as $v) {
            $v = str_replace('\\', '/', trim((string)$v));
            if ($v !== '' && moe_upload_path_safe($v)) $targets[] = $v;
        }
        if (empty($targets)) {
            flash('请先勾选要删除的文件', 'bad');
        } else {
            $root = dirname(__DIR__);
            $ok = 0; $fail = 0; $inUse = 0;
            // 2.2.20：引用检测覆盖全站引用源（文章/页面正文封面 + 设置 + 友链图标 + 商城资源 + 头像）
            $refs = function_exists('moe_asset_collect_refs') ? moe_asset_collect_refs() : array();
            $force = !empty($_POST['force']);
            foreach ($targets as $rel) {
                if (!$force && function_exists('moe_asset_usage_count') && moe_asset_usage_count($rel, $refs) > 0) {
                    $inUse++;
                    continue;
                }
                if (@unlink($root . '/' . $rel)) { $ok++; }
                else { $fail++; }
            }
            $msg = $ok > 0 ? '已删除 ' . $ok . ' 个文件 🧹' : '没有文件被删除';
            if ($fail) $msg .= "，{$fail} 个删除失败（权限？）";
            if ($inUse) $msg .= "，{$inUse} 个仍被文章引用已跳过（勾选「强制删除」可连引用的一起删）";
            flash($msg, $ok > 0 || $inUse ? '' : 'bad');
        }
    }
    redirect('resources.php');
}

/* ---- 扫描 uploads/（含旧版 upload/、content/uploadfile/ 遗留附件） ---- */
$root = dirname(__DIR__);
$files = function_exists('moe_list_upload_files') ? moe_list_upload_files() : array();

/* 2.2.4 兜底：共享函数返回空（如线上 functions.php 未同步覆盖 / OPcache 残留旧版）时，
   本页自行递归扫描同样的三个目录，保证与编辑器「资源媒体库」看到的内容永远一致 */
if (empty($files)) {
    $files = array();
    $scanFallback = function ($dir, $prefix) use (&$scanFallback, &$files) {
        if (!is_dir($dir)) return;
        $items = @scandir($dir);
        foreach (is_array($items) ? $items : array() as $it) {
            if ($it === '.' || $it === '..') continue;
            $p = rtrim($dir, '/\\') . '/' . $it;
            if (is_dir($p)) { $scanFallback($p, $prefix); continue; }
            if (!is_file($p)) continue;
            $rel = $prefix . str_replace('\\', '/', substr($p, strlen(rtrim($dir, '/\\')) + 1));
            $files[$rel] = @filemtime($p) ?: 0;
        }
    };
    foreach (array('uploads', 'upload', 'content/uploadfile') as $d) {
        $scanFallback($root . '/' . $d, $d . '/');
    }
    arsort($files);
    $files = array_keys($files);
}

/* 引用计数：2.2.20 起扫描全站引用源（文章/页面 + 设置/模板设置 + 友链图标 + 商城资源 + 用户头像），
   并兼容中文文件名的 URL 编码形式，修复「引用却显示未引用」导致的误删风险 */
$refs = function_exists('moe_asset_collect_refs') ? moe_asset_collect_refs() : array();

function moe_fmt_size($b) {
    if ($b >= 1048576) return round($b / 1048576, 1) . ' MB';
    if ($b >= 1024)    return round($b / 1024, 1) . ' KB';
    return $b . ' B';
}

/** 显示名：历史文件剥掉「日期_时间_随机串_」前缀露出原名；新命名本身即原名，原样返回 */
function moe_res_display_name($name) {
    $name = (string)$name;
    if (preg_match('/^\d{8}_\d{6}_[0-9a-f]{8}_(.+)$/u', $name, $m) && $m[1] !== '') return $m[1];
    return $name;
}

$IMG_EXT = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg', 'bmp', 'ico');
$VID_EXT = array('mp4', 'webm', 'm4v', 'mov', 'm3u8');
$AUD_EXT = array('mp3', 'wav', 'flac', 'ogg', 'm4a', 'aac');

$items = array();
$totalSize = 0;
$cntImg = $cntVid = $cntAud = $cntDoc = $cntUnused = 0;
foreach ($files as $rel) {
    $fs = $root . '/' . $rel;
    if (!is_file($fs)) continue;
    $size = (int)@filesize($fs);
    $mtime = (int)@filemtime($fs);
    $ext = strtolower(pathinfo($fs, PATHINFO_EXTENSION));
    $kind = in_array($ext, $IMG_EXT, true) ? 'image' : (in_array($ext, $VID_EXT, true) ? 'video' : (in_array($ext, $AUD_EXT, true) ? 'audio' : 'file'));
    $used = function_exists('moe_asset_usage_count') ? moe_asset_usage_count($rel, $refs) : 0;
    if ($used === 0) $cntUnused++;
    if ($kind === 'image') $cntImg++;
    elseif ($kind === 'video') $cntVid++;
    elseif ($kind === 'audio') $cntAud++;
    else $cntDoc++;
    $totalSize += $size;
    $items[] = array('rel' => $rel, 'size' => $size, 'mtime' => $mtime, 'kind' => $kind, 'used' => $used, 'ext' => $ext);
}
$base = function_exists('base_url') ? base_url() : '/';

/** 2.2.5：相对路径 → 可访问 URL（逐段 rawurlencode，修复中文 / 空格 / 括号文件名预览异常） */
if (!function_exists('moe_res_file_url')) {
    function moe_res_file_url($rel, $base)
    {
        return $base . implode('/', array_map('rawurlencode', explode('/', str_replace('\\', '/', $rel))));
    }
}

include 'includes/header.php';
?>

<div class="card">
  <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:14px">
    <h2 class="card-title" style="margin:0">资源管理（<?php echo count($items); ?> 个文件 · 共 <?php echo moe_fmt_size($totalSize); ?>）</h2>
    <span style="flex:1"></span>
    <span class="pill violet">🖼 图片 <?php echo $cntImg; ?></span>
    <span class="pill violet">🎬 视频 <?php echo $cntVid; ?></span>
    <span class="pill violet">🎵 音频 <?php echo $cntAud; ?></span>
    <span class="pill violet">📎 其他 <?php echo $cntDoc; ?></span>
    <?php if ($cntUnused > 0): ?><span class="pill warn">未引用 <?php echo $cntUnused; ?></span><?php endif; ?>
  </div>

  <?php if (empty($items)): ?>
    <?php
    // 2.2.4：空列表时给出精确诊断，而不是笼统的「还是空的」
    $upDir = $root . '/uploads';
    $diag = array();
    $diag[] = '核心列表函数返回 0 个文件' . (function_exists('moe_list_upload_files') ? '' : '（functions.php 中该函数缺失，已用本页内置扫描兜底）');
    $diag[] = '<code>uploads/</code> 目录' . (is_dir($upDir) ? '<span style="color:#268a5b">存在</span>且为空（或没有可列出的文件）' : '<span style="color:#d9506b">不存在</span>（文章编辑器上传时会自动创建）');
    foreach (array('upload' => 'upload/', 'content/uploadfile' => 'content/uploadfile/') as $d => $label) {
        $n = 0;
        if (is_dir($root . '/' . $d)) {
            $it2 = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root . '/' . $d, FilesystemIterator::SKIP_DOTS));
            foreach ($it2 as $f2) if ($f2->isFile()) $n++;
        }
        if ($n > 0) $diag[] = '检测到旧版目录 <code>' . $label . '</code> 有 <b>' . $n . '</b> 个文件 —— 保存设置后刷新本页会自动纳入管理';
    }
    ?>
    <p style="color:var(--muted);text-align:center;padding:26px 0">这里只列出<b>上传到本站服务器</b>的文件（uploads/ 等）；<br>文章里引用的<b>图床外链</b>（其他域名地址）不会出现在资源管理中。</p>
    <div style="max-width:520px;margin:0 auto;padding:0 0 30px;font-size:13px;color:var(--muted);line-height:2">
      <?php foreach ($diag as $d): ?><div>· <?php echo $d; ?></div><?php endforeach; ?>
    </div>
  <?php else: ?>
  <form method="post" id="resForm">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="batch_delete">
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:14px">
      <button class="btn danger" type="submit" id="resDel">🗑 批量删除选中</button>
      <label class="hint" style="display:flex;align-items:center;gap:6px;margin:0">
        <input type="checkbox" name="force" value="1" style="width:auto"> 强制删除（连同仍被文章引用的文件一起删，删除后文章里会显示失效图）
      </label>
      <span style="flex:1"></span>
      <label class="hint" style="display:flex;align-items:center;gap:6px;margin:0"><input type="checkbox" id="resAll" style="width:auto"> 全选 / 取消全选</label>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(215px,1fr));gap:14px">
    <?php foreach ($items as $it): $furl = moe_res_file_url($it['rel'], $base); ?>
      <div style="background:#fff;border:1px solid #e8e2f0;border-radius:15px;overflow:hidden;display:flex;flex-direction:column;
                  transition:transform .15s,box-shadow .15s" onmouseover="this.style.transform='translateY(-3px)';this.style.boxShadow='0 12px 30px rgba(146,120,200,.16)'"
                  onmouseout="this.style.transform='';this.style.boxShadow=''">
        <div style="aspect-ratio:16/10;background:#f6f2ff;overflow:hidden;display:flex;align-items:center;justify-content:center;position:relative">
          <label style="position:absolute;top:8px;left:8px;z-index:2;background:rgba(255,255,255,.92);border-radius:99px;padding:3px 8px;cursor:pointer">
            <input type="checkbox" class="resSel" name="files[]" value="<?php echo e($it['rel']); ?>" style="width:auto;vertical-align:middle">
          </label>
          <?php if ($it['kind'] === 'image'): ?>
            <a href="<?php echo e($furl); ?>" target="_blank" referrerpolicy="no-referrer" style="display:block;width:100%;height:100%">
              <img src="<?php echo e($furl); ?>" alt="" loading="lazy" referrerpolicy="no-referrer"
                   style="width:100%;height:100%;object-fit:cover;display:block">
            </a>
          <?php else: ?>
            <a href="<?php echo e($furl); ?>" target="_blank" style="font-size:42px;text-decoration:none">
              <?php echo $it['kind'] === 'video' ? '🎬' : ($it['kind'] === 'audio' ? '🎵' : '📎'); ?>
            </a>
          <?php endif; ?>
        </div>
        <div style="padding:11px 13px 13px;display:flex;flex-direction:column;flex:1">
          <div style="word-break:break-all;font-size:12.5px;font-weight:600;color:#4a4060;line-height:1.5"><?php echo e(moe_res_display_name(basename($it['rel']))); ?></div>
          <div style="word-break:break-all;color:var(--muted);font-size:11px;margin-top:3px"><?php echo e($it['rel']); ?></div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:auto;padding-top:9px;align-items:center">
            <span class="pill"><?php echo strtoupper($it['ext']); ?></span>
            <span style="font-size:11.5px;color:var(--muted);white-space:nowrap"><?php echo moe_fmt_size($it['size']); ?></span>
            <span style="font-size:11.5px;color:var(--muted);white-space:nowrap"><?php echo e(format_time(date('Y-m-d H:i:s', $it['mtime']), 'm-d H:i')); ?></span>
            <?php if ($it['used'] > 0): ?>
              <span class="pill ok" title="仍被文章/页面引用，删除会导致文中图片失效">引用 ×<?php echo (int)$it['used']; ?></span>
            <?php else: ?>
              <span class="pill warn" title="未被任何文章/页面引用">未引用</span>
            <?php endif; ?>
            <span style="flex:1"></span>
            <button type="button" class="res-del" title="删除这个文件"
                    data-rel64="<?php echo e(base64_encode($it['rel'])); ?>"
                    data-name="<?php echo e(moe_res_display_name(basename($it['rel']))); ?>"
                    data-used="<?php echo (int)$it['used']; ?>"
                    style="border:none;background:none;cursor:pointer;font-size:14px;line-height:1;padding:2px 4px;border-radius:6px;color:#c76a7a"
                    onmouseover="this.style.background='rgba(217,74,90,.1)'" onmouseout="this.style.background=''">🗑</button>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
    </div>
  </form>

  <script>
  (function () {
    var all = document.getElementById('resAll');
    var boxes = Array.prototype.slice.call(document.querySelectorAll('input.resSel'));
    var form = document.getElementById('resForm');
    if (!all || !boxes.length) return;
    all.addEventListener('change', function () { boxes.forEach(function (b) { b.checked = all.checked; }); });
    boxes.forEach(function (b) {
      b.addEventListener('change', function () { all.checked = boxes.every(function (x) { return x.checked; }); });
    });
    if (form) {
      form.addEventListener('submit', function (ev) {
        var n = document.querySelectorAll('input.resSel:checked').length;
        if (!n) { ev.preventDefault(); alert('请先勾选要删除的文件'); return; }
        var force = form.querySelector('input[name="force"]').checked;
        var tip = '确定删除选中的 ' + n + ' 个文件吗？该操作不可恢复！';
        if (!force) tip += '\n\n仍被文章引用的文件会自动跳过。';
        else tip += '\n\n已勾选「强制删除」：被文章引用的文件也会一并删除，文中图片会失效！';
        if (!confirm(tip)) ev.preventDefault();
      });
    }

    /* 单文件删除（卡片右下角 🗑）：独立隐藏表单提交，避免嵌套在批量表单里 */
    var delForm = document.createElement('form');
    delForm.method = 'post';
    delForm.action = '';
    delForm.style.display = 'none';
    delForm.innerHTML = '<input type="hidden" name="act" value="delete">'
      + '<input type="hidden" name="rel64" value=""><input type="hidden" name="force" value="">';
    document.body.appendChild(delForm);
    document.querySelectorAll('button.res-del').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var used = parseInt(btn.getAttribute('data-used') || '0', 10);
        var name = btn.getAttribute('data-name') || '该文件';
        var tip = '确定删除「' + name + '」吗？该操作不可恢复！';
        if (used > 0) tip = '「' + name + '」仍被 ' + used + ' 处内容引用，删除后文中会显示失效图。\n确定要强制删除吗？';
        if (!confirm(tip)) return;
        delForm.querySelector('input[name="rel64"]').value = btn.getAttribute('data-rel64') || '';
        delForm.querySelector('input[name="force"]').value = used > 0 ? '1' : '';
        delForm.submit();
      });
    });
  })();
  </script>
  <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
