<?php
/**
 * MoeZ - 后台登录（1.8.0 全新改版）
 * 大背景 + 右侧悬浮卡片，样式仿「账户登录」卡片式设计：
 *   - 背景图 / 卡片底色可在 后台 → 站点设置 → 邮箱与登录 自定义
 *   - 图形验证码开关（login_captcha）
 *   - 记住登录状态（勾选后 Session Cookie 延长到 14 天）
 */
define('MOE_ADMIN', true);
require dirname(__DIR__) . '/init.php';

// 已登录直接进仪表盘
if (is_admin()) redirect('index.php');

$capOn = setting('login_captcha', '0') === '1';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $name = trim($_POST['username'] ?? '');
    $pass = (string)($_POST['password'] ?? '');

    // 图形验证码校验（开启时；不区分大小写）
    if ($capOn) {
        $inp = strtoupper(trim((string)($_POST['captcha'] ?? '')));
        $ses = isset($_SESSION['moe_captcha']) ? strtoupper((string)$_SESSION['moe_captcha']) : '';
        unset($_SESSION['moe_captcha']);          // 一次性，防重放
        if ($ses === '' || $inp === '' || !hash_equals($ses, $inp)) {
            $error = '验证码不正确或已过期，点图片可刷新～';
        }
    }

    if ($error === '') {
        // 2.0.0：统一走用户模块（支持用户名 / 邮箱登录，校验账号状态与角色）
        // 后台登录只放行站长与作者；会员请走前台 /user
        $r = function_exists('moe_user_login')
            ? moe_user_login($name, $pass, false)
            : array(false, '用户模块缺失，请重新上传 includes/user.php', null);
        if ($r[0]) {
            // 记住登录状态：会话 id 已在登录时重建，这里只需把 Cookie 延长到 14 天
            if (!empty($_POST['remember'])) {
                $p = session_get_cookie_params();
                @setcookie(session_name(), session_id(), time() + 86400 * 14, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
            }
            redirect('index.php');
        }
        $error = $r[1];
    }
}

$__loginLogo = trim((string)setting('login_logo', ''));
if ($__loginLogo === '') $__loginLogo = trim((string)setting('admin_logo', ''));
// 2.1.25：都没设置时回退网站根目录的 logo.png；站名始终显示在 logo 旁
$__siteName = trim((string)setting('site_name', ''));
if ($__siteName === '') $__siteName = 'MoeZ';
$__logoUrl = $__loginLogo !== '' ? media_url($__loginLogo) : base_url() . 'logo.png';
$__bg   = trim((string)setting('login_bg', ''));
$__card = trim((string)setting('login_card_bg', ''));
if ($__card === '') $__card = '#ffffff';
$__bgUrl = $__bg !== '' ? media_url($__bg) : '';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>登录 · 萌Z MoeZ 管理中心</title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  html, body { height:100%; }
  body {
    font-family:-apple-system,'PingFang SC','Microsoft YaHei',sans-serif;
    background:#2b2440 url('<?php echo $__bgUrl !== '' ? e($__bgUrl) : ''; ?>') center/cover no-repeat fixed;
  }
  /* 没设置背景图时的粉紫渐变兜底 */
  /* 2.1.25：登录卡片改为居中（原先靠右悬浮） */
  .login-stage {
    position:relative; min-height:100vh; display:flex; align-items:center; justify-content:center;
    padding:40px max(6vw, 24px);
  }
  .login-veil {
    position:absolute; inset:0;
    background:linear-gradient(115deg, rgba(43,36,64,.28), rgba(43,36,64,.05) 55%);
    pointer-events:none;
  }
  .card {
    position:relative; z-index:2;
    width:min(430px, 100%);
    background:<?php echo e($__card); ?>;
    border-radius:22px;
    box-shadow:0 24px 70px rgba(20,14,40,.4);
    padding:38px 36px 30px;
  }
  .card h1 { font-size:24px; color:#2b2440; letter-spacing:.5px; }
  .card h1 .en { font-size:12.5px; color:#9a8fae; font-weight:500; margin-left:8px; letter-spacing:0; }
  .card .sub { font-size:13px; color:#9a8fae; margin:10px 0 26px; }
  .frow {
    display:flex; align-items:center; gap:10px;
    border-bottom:1.5px solid #eee6f6; padding:6px 2px 11px; margin-bottom:20px;
    transition:border-color .2s;
  }
  .frow:focus-within { border-color:#c9a7e8; }
  .frow .ico { font-size:17px; opacity:.55; flex:none; width:20px; text-align:center; }
  .frow input { flex:1; border:0; outline:0; background:transparent; font-size:14.5px; color:#2b2440; min-width:0; }
  .frow input::placeholder { color:#b3aac5; }
  .frow .capimg { height:40px; border-radius:8px; cursor:pointer; flex:none; display:block; }
  .rem-row { display:flex; align-items:center; gap:8px; font-size:13px; color:#6f6488; margin:-4px 0 22px; cursor:pointer; user-select:none; }
  .rem-row input { width:16px; height:16px; accent-color:#a18cd1; cursor:pointer; }
  .btn-login {
    display:block; width:100%; border:0; cursor:pointer;
    padding:14px; border-radius:14px; font-size:15.5px; font-weight:600; color:#fff;
    background:linear-gradient(135deg,#ff7eb3,#a18cd1,#8ec5fc);
    background-size:150% 150%;
    box-shadow:0 10px 26px rgba(161,140,209,.45);
    transition:transform .15s, box-shadow .15s;
    font-family:inherit;
  }
  .btn-login:hover { transform:translateY(-2px); box-shadow:0 14px 32px rgba(161,140,209,.55); }
  .btn-login:active { transform:translateY(0); }
  .foot-links { margin-top:16px; text-align:center; font-size:12.5px; }
  .foot-links a { color:#9a8fae; text-decoration:none; margin:0 10px; }
  .foot-links a:hover { color:#a18cd1; }
  .alert {
    background:#fdeef1; color:#e0566b; border-radius:12px; padding:11px 14px;
    font-size:13px; margin-bottom:20px; line-height:1.6;
  }
  .brand-mini {
    position:absolute; left:max(6vw,24px); top:26px; z-index:2;
    display:flex; align-items:center; gap:8px; font-size:14px; font-weight:600; color:rgba(255,255,255,.92);
    text-shadow:0 2px 10px rgba(20,14,40,.5);
  }
  .brand-mini .mark {
    width:32px; height:32px; border-radius:10px; background:rgba(255,255,255,.2); backdrop-filter:blur(6px);
    display:inline-flex; align-items:center; justify-content:center; font-size:17px;
  }
  /* 2.1.25：logo 完整展示（图标 + 站点名称），未设置时回退网站根 logo */
  .logo-row { display:flex; align-items:center; justify-content:center; gap:12px; margin-bottom:16px; }
  .logo-face { width:54px; height:54px; border-radius:16px; object-fit:cover; box-shadow:0 8px 22px rgba(146,120,200,.35); }
  .logo-name { font-size:21px; font-weight:700; color:#2b2440; letter-spacing:.5px; }
  @media (max-width:760px) {
    .login-stage { justify-content:center; }
    .brand-mini { position:fixed; }
  }
</style>
</head>
<body>
<div class="login-stage">
  <div class="login-veil"></div>
  <div class="brand-mini">
    <span class="mark">🌸</span> 萌Z MoeZ
  </div>

  <div class="card">
    <div class="logo-row">
      <img class="logo-face" src="<?php echo e($__logoUrl); ?>" alt="logo" onerror="this.style.display='none'">
      <span class="logo-name"><?php echo e($__siteName); ?></span>
    </div>
    <h1>账户登录 <span class="en">MoeZ</span></h1>
    <p class="sub">欢迎回来，登录后即可参与评论与互动</p>

    <?php if ($error): ?><div class="alert"><?php echo e($error); ?></div><?php endif; ?>

    <form method="post" autocomplete="off">
      <?php echo csrf_field(); ?>
      <div class="frow">
        <span class="ico">👤</span>
        <input type="text" name="username" required autofocus placeholder="用户名 / 邮箱">
      </div>
      <div class="frow">
        <span class="ico">🔒</span>
        <input type="password" name="password" required placeholder="请输入密码">
      </div>
      <?php if ($capOn): ?>
      <div class="frow">
        <span class="ico">🛡</span>
        <input type="text" name="captcha" required maxlength="4" placeholder="图形验证码" style="text-transform:uppercase;letter-spacing:2px">
        <img class="capimg" id="capImg" src="captcha.php?t=<?php echo time(); ?>" alt="验证码"
             title="看不清？点我刷新" onclick="this.src='captcha.php?t='+Date.now()">
      </div>
      <?php endif; ?>
      <label class="rem-row">
        <input type="checkbox" name="remember" value="1"> 记住登录状态（14 天内免登录）
      </label>
      <button class="btn-login" type="submit">登 录</button>
    </form>

    <div class="foot-links">
      <a href="<?php echo e(base_url()); ?>">← 返回首页</a>
    </div>
    <?php /* 程序作者署名：樊不烦 开发制作（仅保留在代码中，不在界面展示） */ ?>
  </div>
</div>
</body>
</html>
