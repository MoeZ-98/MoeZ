<?php
/**
 * 后台 · 模板管理（一键更换前台模板）
 * 模板放置于 /templates/{目录}/，须提供 info.php 返回数组：
 *   array('name'=>..., 'version'=>..., 'author'=>..., 'desc'=>...)
 * 可选 screenshot.png 作为预览图。
 * 1.8.0：模板设置恢复独立页面 theme-settings.php（侧栏「🖌 模板设置」）
 * 2.2.20：新增「上传主题」(zip 安装) 与「开发说明」页签（对齐插件管理的体验）
 */
require __DIR__ . '/bootstrap.php';
$active = 'themes';
$page_title = '模板管理';

if (!function_exists('moe_theme_rm_dir')) {
    /** 递归删除目录（清理临时目录专用，只接受 templates/ 下的路径） */
    function moe_theme_rm_dir($dir)
    {
        if (!is_string($dir) || $dir === '' || strpos(realpath($dir) ?: '', realpath(dirname(__DIR__)) . DIRECTORY_SEPARATOR . 'templates') !== 0) return;
        foreach (glob($dir . '/*') ?: array() as $f) is_dir($f) ? moe_theme_rm_dir($f) : @unlink($f);
        foreach (glob($dir . '/.*') ?: array() as $f) if (basename($f) !== '.' && basename($f) !== '..') is_dir($f) ? moe_theme_rm_dir($f) : @unlink($f);
        @rmdir($dir);
    }
}

if (!function_exists('moe_theme_install_zip')) {
/**
 * 2.2.20：从 zip 包安装主题到 /templates/{dir}/
 * 安全约束与插件安装一致：禁止越界路径 / 绝对路径 / 非白名单扩展；
 * 必须包含 info.php；单主题 ≤ 400 文件 / 60MB（主题普遍比插件大）。
 * 同名主题不允许直接覆盖（提示先删除旧主题，避免误覆盖在用主题）。
 */
function moe_theme_install_zip($tmpFile, $origName, &$err)
{
    $err = '';
    if (!class_exists('ZipArchive')) { $err = '服务器未开启 php-zip 扩展，请先在宝塔面板的 PHP 设置中安装 zip 扩展'; return false; }
    $root = dirname(__DIR__) . '/templates';
    if (!is_dir($root) && !@mkdir($root, 0755, true)) { $err = '模板目录不可写：' . $root; return false; }

    $z = new ZipArchive();
    if ($z->open($tmpFile) !== true) { $err = '不是有效的 zip 压缩包'; return false; }

    $allow = array('php', 'json', 'css', 'js', 'map', 'md', 'txt', 'xml', 'html', 'htm',
                   'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico', 'avif',
                   'ttf', 'woff', 'woff2', 'eot', 'otf', 'mp3', 'mp4', 'webm');
    $maxFiles = 400;
    $maxBytes = 60 * 1024 * 1024;
    $total = 0;
    $items = array();
    for ($i = 0; $i < $z->numFiles; $i++) {
        $st = $z->statIndex($i);
        if (!is_array($st)) continue;
        $name = str_replace('\\', '/', (string)$st['name']);
        // 2.2.23：Windows / 好压等工具压缩的中文文件名多为 GBK 编码，ZipArchive 原样返回字节流
        // 不转码的话落盘文件名全是乱码，主题也取不到正确目录名；UTF-8 合法则原样保留
        if (!function_exists('mb_check_encoding') || !mb_check_encoding($name, 'UTF-8')) {
            if (function_exists('iconv')) {
                $conv = @iconv('GBK', 'UTF-8//IGNORE', $name);
                if (is_string($conv) && $conv !== '' && !strpos($conv, "\0")) $name = $conv;
            }
        }
        // 去掉控制字符，避免路径里藏不可见字节
        $name = preg_replace('/[\x00-\x1f\x7f]/', '', $name);
        if ($name === '' || $name[0] === '/' || strpos($name, "\0") !== false) { $z->close(); $err = '压缩包包含非法路径'; return false; }
        if (preg_match('#(^|/)\.\.(/|$)#', $name) || preg_match('/^[A-Za-z]:/', $name)) {
            $z->close(); $err = '压缩包包含越界路径（已阻止 ZipSlip 攻击）'; return false;
        }
        if (substr($name, -1) === '/') continue;
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (!in_array($ext, $allow, true)) { $z->close(); $err = '不允许的文件类型：.' . $ext; return false; }
        $total += (int)$st['size'];
        $items[] = array('i' => $i, 'name' => $name);
    }
    if (count($items) > $maxFiles) { $z->close(); $err = '压缩包文件数超过 ' . $maxFiles . ' 个'; return false; }
    if ($total > $maxBytes) { $z->close(); $err = '解压后体积超过 60MB'; return false; }
    if (!$items) { $z->close(); $err = '压缩包是空的'; return false; }

    $stage = $root . '/.stage_' . bin2hex(function_exists('random_bytes') ? random_bytes(6) : mt_rand());
    if (!@mkdir($stage, 0755, true)) { $z->close(); $err = '无法创建临时目录，请检查 templates/ 权限'; return false; }
    foreach ($items as $it) {
        $dest = $stage . '/' . $it['name'];
        if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0755, true);
        $data = $z->getFromIndex($it['i']);
        if ($data === false || @file_put_contents($dest, $data) === false) {
            $z->close();
            foreach (glob($root . '/.stage_*', GLOB_ONLYDIR) as $d) { foreach (glob($d . '/*') ?: array() as $f) @unlink($f); @rmdir($d); }
            $err = '解压写入失败，请检查目录权限'; return false;
        }
    }
    $z->close();

    // 若包内只有一个顶层目录，则把它当作主题根目录
    $tops = glob($stage . '/*');
    $topDirs = glob($stage . '/*', GLOB_ONLYDIR);
    $src = (count($tops) === 1 && count($topDirs) === 1) ? $topDirs[0] : $stage;

    // 主题 ID：info.php 所在目录名 > 顶层目录名 > zip 文件名
    $dir = '';
    if (is_file($src . '/info.php')) {
        $dir = basename($src);
    } elseif (count($topDirs) === 1) {
        $dir = basename($topDirs[0]);
    } else {
        $dir = pathinfo((string)$origName, PATHINFO_FILENAME);
    }
    // 2.2.23：目录名允许中文 —— 上传「xxx主题」不再被过滤成空名而回退成 theme-日期 之类的随机目录
    $dir = trim((string)$dir);
    $dir = preg_replace('/[^\x{4e00}-\x{9fa5}a-zA-Z0-9_-]+/u', '', $dir);
    $dir = trim($dir, '-');
    // 兜底链：目录名被过滤空 → 依次尝试 zip 文件名 → info.php 里的 name 字段 → 时间戳
    if ($dir === '' || $dir === '-') {
        $dir = trim((string)pathinfo((string)$origName, PATHINFO_FILENAME));
        $dir = preg_replace('/[^\x{4e00}-\x{9fa5}a-zA-Z0-9_-]+/u', '', $dir);
    }
    if ($dir === '' && is_file($src . '/info.php')) {
        $infoSrc = (string)@file_get_contents($src . '/info.php');
        if (preg_match("/'name'\\s*=>\\s*'([^']{1,40})'/", $infoSrc, $m)) {
            $dir = preg_replace('/[^\x{4e00}-\x{9fa5}a-zA-Z0-9_-]+/u', '', $m[1]);
        }
    }
    if ($dir === '' || mb_strlen($dir, 'UTF-8') > 30) $dir = 'theme-' . date('Ymd-His');
    if ($dir[0] === '.') $dir = 't' . $dir;

    if (is_dir($root . '/' . $dir)) {
        // 覆盖保护：同名主题不直接删除，交给站长确认
        foreach (glob($root . '/.stage_*', GLOB_ONLYDIR) as $d) {
            foreach (glob($d . '/*') ?: array() as $f) @unlink($f);
            foreach (glob($d . '/.*') ?: array() as $f) if (basename($f) !== '.' && basename($f) !== '..') @unlink($f);
            @rmdir($d);
        }
        $err = '已存在同名主题「' . $dir . '」。请先在列表中删除它，或把压缩包内的主题目录改个名字再上传。';
        return false;
    }
    if (!@rename($src, $root . '/' . $dir)) {
        $err = '安装失败：无法移动主题目录（权限不足？）';
        return false;
    }
    if ($stage !== $src) {
        foreach (glob($stage . '/*') ?: array() as $f) { is_dir($f) ? @rmdir($f) : @unlink($f); }
        @rmdir($stage);
    }
    if (!is_file($root . '/' . $dir . '/info.php')) {
        $err = '主题包缺少 info.php（主题信息文件），已安装到「' . $dir . '」但无法正常使用，请核对包结构';
    }
    return $dir;
}
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = (string)($_POST['act'] ?? 'switch');

    // 2.2.20：上传安装主题 zip
    if ($act === 'upload') {
        @set_time_limit(300);
        // 2.2.23：清理历史遗留的临时目录 —— 旧版本解压中断留下的 stage_xxx（无点前缀）
        // 与超过 1 小时的 .stage_xxx，不清理会一直堆在模板列表旁边
        foreach (array_merge(glob($root = dirname(__DIR__) . '/templates' . '/stage_*', GLOB_ONLYDIR) ?: array(), glob(dirname(__DIR__) . '/templates/.stage_*', GLOB_ONLYDIR) ?: array()) as $d) {
            if (basename($d) === '_admin-patch') continue;
            if (preg_match('/^\.?stage_[0-9a-f]{8,}$/i', basename($d)) || @filemtime($d) < time() - 3600) {
                foreach (glob($d . '/*') ?: array() as $f) is_dir($f) ? moe_theme_rm_dir($f) : @unlink($f);
                foreach (glob($d . '/.*') ?: array() as $f2) if (basename($f2) !== '.' && basename($f2) !== '..') is_dir($f2) ? moe_theme_rm_dir($f2) : @unlink($f2);
                @rmdir($d);
            }
        }
        $f = $_FILES['zipfile'] ?? null;
        if (!$f || (int)$f['error'] !== UPLOAD_ERR_OK) {
            flash($f ? '上传失败（错误码 ' . (int)$f['error'] . '），请检查 PHP 上传限制' : '请先选择要上传的 .zip 主题包', 'bad');
        } elseif (strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION)) !== 'zip') {
            flash('只接受 .zip 格式的主题包', 'bad');
        } else {
            $err = '';
            $dir = moe_theme_install_zip($f['tmp_name'], (string)$f['name'], $err);
            if ($dir !== false) {
                flash('主题「' . $dir . '」安装成功 🎨 · 在列表里点「启用此模板」即可切换' . ($err !== '' ? '（注意：' . $err . '）' : ''), $err !== '' ? 'warn' : '');
            } else {
                flash($err !== '' ? $err : '安装失败', 'bad');
            }
        }
        redirect('themes.php');
    }

    $dir = trim($_POST['dir'] ?? '');
    // 切换模板：校验目录合法且真实存在 info.php
    // 2.2.23：切换模板允许中文目录名（模板名即目录名，如「星空主题」）
    if ($dir !== '' && preg_match('/^[\x{4e00}-\x{9fa5}a-zA-Z0-9_-]+$/u', $dir) && $dir[0] !== '.' && is_file(dirname(__DIR__) . '/templates/' . $dir . '/info.php')) {
        setting_set('theme', $dir);
        flash('模板已切换为「' . $dir . '」🎨 · 模板设置请前往侧栏「🖌 模板设置」');
    } else {
        flash('模板不存在', 'bad');
    }
    redirect('themes.php');
}

$themes = themes_list();
$curTheme = theme();
// 当前使用中的模板排在第一位，其余保持原顺序
$curList = array(); $restList = array();
foreach ($themes as $t) {
    if ($t['dir'] === $curTheme) $curList[] = $t; else $restList[] = $t;
}
$themes = array_merge($curList, $restList);
$hasOpts = !empty(theme_settings($curTheme));
// 2.2.23：与官方版本清单比对（授权检测结果缓存，只读不联网），卡片标「可更新 / 已是最新」
$remote = function_exists('moe_auth_remote_versions')
    ? moe_auth_remote_versions()
    : array('themes' => array(), 'plugins' => array());
$zipOk = class_exists('ZipArchive');
include 'includes/header.php';
?>

<div class="set-tabs" role="tablist" aria-label="模板管理">
  <button type="button" class="set-tab cur" id="tab-th-list" data-pane="th-list" role="tab" aria-selected="true" aria-controls="th-list">🎨 全部模板 <span style="opacity:.75"><?php echo count($themes); ?></span></button>
  <button type="button" class="set-tab" id="tab-th-upload" data-pane="th-upload" role="tab" aria-selected="false" aria-controls="th-upload">📤 上传主题</button>
  <button type="button" class="set-tab" id="tab-th-dev" data-pane="th-dev" role="tab" aria-selected="false" aria-controls="th-dev">📖 开发说明</button>
</div>

<!-- ============ 全部模板 ============ -->
<div class="set-pane cur" id="th-list" role="tabpanel" aria-labelledby="tab-th-list">
<div class="card" style="background:linear-gradient(135deg,#fff1f4,#f3f0ff)">
  <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">
    <span style="font-size:30px">🎨</span>
    <div>
      <h2 style="font-size:15.5px">当前使用模板：<b style="background:var(--grad);-webkit-background-clip:text;background-clip:text;color:transparent"><?php echo e($curTheme); ?></b></h2>
      <p style="font-size:12.5px;color:var(--muted)">模板需包含 index.php、post.php、category.php、page.php、search.php、404.php 及 info.php。模板设置在侧栏「🖌 模板设置」。</p>
    </div>
  </div>
</div>

<div class="theme-grid">
  <?php foreach ($themes as $t):
      // 2.2.23：官方版本比对
      $rv     = isset($remote['themes'][$t['dir']]) ? (string)$remote['themes'][$t['dir']] : '';
      $hasNew = $rv !== '' && version_compare($rv, (string)$t['version'], '>');
  ?>
    <div class="theme-card <?php echo $t['dir'] === $curTheme ? 'active' : ''; ?>">
      <div class="shot">
        <?php if ($t['screenshot']): ?>
          <img src="<?php echo e(media_url($t['screenshot'])); ?>" alt="">
        <?php else: ?>🌸<?php endif; ?>
      </div>
      <div class="info">
        <h3><?php echo e($t['name']); ?>
          <?php if ($t['dir'] === $curTheme): ?><span class="pill ok">使用中</span><?php endif; ?>
          <?php if ($hasNew): ?>
            <span class="pill warn" title="官方已发布新版本">⬆ 新版 v<?php echo e($rv); ?></span>
          <?php elseif ($rv !== ''): ?>
            <span class="pill ok" title="已与官方版本同步">✓ 最新</span>
          <?php endif; ?>
        </h3>
        <div class="meta">v<?php echo e($t['version']); ?><?php echo $t['author'] ? ' · ' . e($t['author']) : ''; ?></div>
        <p style="font-size:12.5px;color:var(--muted);margin-bottom:14px"><?php echo e($t['desc']); ?></p>
        <div class="row">
          <?php if ($t['dir'] !== $curTheme): ?>
            <form method="post" onsubmit="return confirm('切换模板为「<?php echo e($t['name']); ?>」？')">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="act" value="switch">
              <input type="hidden" name="dir" value="<?php echo e($t['dir']); ?>">
              <button class="btn sm" type="submit">✔ 启用此模板</button>
            </form>
          <?php else: ?>
            <?php if ($hasOpts): ?>
              <a class="btn sm" href="theme-settings.php">🖌 模板设置</a>
            <?php endif; ?>
            <a class="btn ghost sm" href="<?php echo e(base_url()); ?>" target="_blank">查看效果 ↗</a>
          <?php endif; ?>
          <?php if (function_exists('moe_auth_check')):
            if ($hasNew): ?>
            <!-- 2.2.23：官方有新版 → 高亮「更新到 vX」 -->
            <form data-upd method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="act" value="auth_update_theme">
              <input type="hidden" name="slug" value="<?php echo e($t['dir']); ?>">
              <input type="hidden" name="mode" value="zip">
              <button class="btn sm" type="submit" style="background:var(--grad);color:#fff;border:0"
                      title="官方最新版 v<?php echo e($rv); ?>，点击在线更新">⬆ 更新到 v<?php echo e($rv); ?></button>
            </form>
            <?php elseif ($rv === ''): ?>
            <!-- 官方清单里没有该主题（未授权 / 未收录）→ 保留手动尝试入口 -->
            <form data-upd method="post">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="act" value="auth_update_theme">
              <input type="hidden" name="slug" value="<?php echo e($t['dir']); ?>">
              <input type="hidden" name="mode" value="zip">
              <button class="btn ghost sm" type="submit" title="尝试从官方更新源获取该主题的最新版">⬆ 检查更新</button>
            </form>
            <?php endif; /* rv!=='' 且无新版：不显示更新按钮（已是最新） */ ?>
            <?php if ($t['dir'] !== $curTheme): ?>
            <form data-upd method="post" data-confirm="确定删除主题「<?php echo e($t['name']); ?>」？原文件会先备份到 content/backups/（误删可找回）。">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="act" value="auth_delete_theme">
              <input type="hidden" name="slug" value="<?php echo e($t['dir']); ?>">
              <button class="btn ghost sm" type="submit" style="color:#d9506b;border-color:#f2c6cf">🗑 删除</button>
            </form>
            <?php endif; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>
</div>

<!-- ============ 上传主题 ============ -->
<div class="card set-pane" id="th-upload" role="tabpanel" aria-labelledby="tab-th-upload">
  <h2 class="card-title">上传主题包</h2>
  <p class="hint" style="margin:-6px 0 16px">
    选择 <b>.zip</b> 主题包上传，程序会解压到 <code>/templates/</code> 并自动识别主题目录（须包含 <code>info.php</code>）。
    安装完成后回到「全部模板」点「启用此模板」即可切换。
  </p>

  <?php if (!$zipOk): ?>
    <div class="alert bad" style="margin-bottom:14px">
      ⚠️ 当前 PHP 未开启 <b>zip 扩展</b>，无法解压主题包。请在宝塔面板 → 软件商店 → PHP 设置 → 安装「zip」扩展后重启 PHP。
      也可以手动把主题文件夹上传到 <code>/templates/</code> 目录。
    </div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="upload">
    <div class="field">
      <label>主题压缩包（.zip，≤ 60MB）</label>
      <input type="file" name="zipfile" accept=".zip,application/zip" required>
    </div>
    <p class="hint" style="margin:0 0 14px">
      安全限制：包内不允许 <code>..</code> 越界路径、绝对路径、可执行文件；仅放行 php / json / css / js / 图片 / 字体 / 音视频 / 文本，
      最多 400 个文件、解压后合计 60MB。同名主题不会被覆盖（会提示先删除旧主题），避免误覆盖正在使用的主题。
    </p>
    <div class="form-foot" style="border-top:1px dashed var(--line);padding-top:16px;margin-top:6px">
      <button class="btn" type="submit" <?php echo !$zipOk ? 'disabled' : ''; ?>>📤 上传并安装</button>
    </div>
  </form>
</div>

<!-- ============ 开发说明 ============ -->
<div class="card set-pane" id="th-dev" role="tabpanel" aria-labelledby="tab-th-dev">
  <h2 class="card-title">主题开发说明</h2>

  <div class="sub-h plain" style="margin-bottom:8px">目录结构（必须）</div>
  <pre style="background:#f7f3fc;border:1px solid #e8e2f0;border-radius:10px;padding:12px 14px;font-size:12.5px;line-height:1.7;overflow:auto">templates/my-theme/
├── info.php          主题信息（必须）
├── screenshot.png    预览图（可选，列表卡片展示）
├── index.php         首页（必须）
├── post.php          文章详情页（必须）
├── category.php      分类 / 标签列表页（必须）
├── page.php          独立页面（必须）
├── search.php        搜索结果页（必须）
├── 404.php           未找到页（必须）
└── footer.php 等     其余按需拆分的局部模板</pre>

  <div class="sub-h plain" style="margin:14px 0 8px">info.php 写法</div>
  <pre style="background:#f7f3fc;border:1px solid #e8e2f0;border-radius:10px;padding:12px 14px;font-size:12.5px;line-height:1.7;overflow:auto">&lt;?php
return array(
    'name'    =&gt; '我的主题',
    'version' =&gt; '1.0.0',
    'author'  =&gt; '作者名',
    'desc'    =&gt; '一句话介绍这个主题',
);</pre>

  <div class="sub-h plain" style="margin:14px 0 8px">常用函数</div>
  <p style="font-size:13px;line-height:2">
    <code>render('post')</code> 渲染模板文件（当前主题缺失时自动回落到 <code>templates/default/</code>）·
    <code>theme_opt('key', '默认值')</code> 读取「🖌 模板设置」里的配置 ·
    <code>media_url($path)</code> 补全媒体地址 ·
    <code>e($str)</code> HTML 转义输出 ·
    <code>post_url($p) / category_url($c) / tag_url($t)</code> 生成前台链接 ·
    <code>posts_query()</code> 取文章列表 ·
    <code>current_user()</code> 当前登录用户 ·
    <code>moe_chat_name()</code> 看板娘名字 ·
    <code>moe_pt_name() / moe_pt_coin_name()</code> 积分 / 金币自定义名称（商城文案务必用这两个函数，不要写死「积分」「金币」）。
  </p>

  <div class="sub-h plain" style="margin:14px 0 8px">支持模板设置项（可选）</div>
  <p style="font-size:13px;line-height:2">
    在主题目录放 <code>settings.php</code> 返回配置数组，即可在侧栏「🖌 模板设置」里生成表单，站长保存后通过
    <code>theme_opt()</code> 读取。具体字段格式可参考 <code>templates/fomalhaut/settings.php</code>。
  </p>

  <p class="hint" style="margin-top:14px">
    💡 开发好后把整个主题目录压成 zip（确保 zip 里包含 info.php），在「📤 上传主题」安装即可。
    想发布给其他站长？把它作为「主题」资源上传到官方积分商城，其他站长就能在线一键更新。
  </p>
</div>

<script>
/* 2.2.20：页签切换（上传主题 / 开发说明） */
(function () {
  var box = document.querySelector('.set-tabs');
  if (!box) return;
  Array.prototype.forEach.call(box.querySelectorAll('.set-tab[data-pane]'), function (t) {
    t.addEventListener('click', function () {
      Array.prototype.forEach.call(box.querySelectorAll('.set-tab'), function (x) {
        x.classList.remove('cur'); x.setAttribute('aria-selected', 'false');
      });
      t.classList.add('cur'); t.setAttribute('aria-selected', 'true');
      Array.prototype.forEach.call(document.querySelectorAll('.set-pane'), function (p) { p.classList.remove('cur'); });
      var pane = document.getElementById(t.getAttribute('data-pane'));
      if (pane) pane.classList.add('cur');
      try { localStorage.setItem('moe_themes_tab', t.getAttribute('data-pane')); } catch (e) {}
    });
  });
  try {
    var last = localStorage.getItem('moe_themes_tab');
    if (last) { var b = document.getElementById('tab-' + last); if (b) b.click(); }
  } catch (e) {}
})();
</script>

<script>
/* 2.2.5：在线更新 / 删除 —— fetch 提交到 update-check.php，弹窗显示结果后刷新
   2.2.16：更新走蓝奏云分享链接时后端要多步解析 + 下载，耗时可达 1~2 分钟，
   按钮实时显示已用时；结果弹窗改为「点确定后再刷新」，避免提示一闪而过；
   fetch 增加 HTTP 状态检查，网关超时（502/504）时给出明确提示。 */
(function () {
  Array.prototype.forEach.call(document.querySelectorAll('form[data-upd]'), function (f) {
    f.addEventListener('submit', function (ev) {
      ev.preventDefault();
      if (f.dataset.confirm && !window.confirm(f.dataset.confirm)) return;
      var btn = f.querySelector('button');
      var orig = btn ? btn.textContent : '';
      if (btn) { btn.disabled = true; btn.textContent = '⏳ 处理中…'; }
      var fd = new FormData(f);
      fd.set('confirm', '1');
      /* 蓝奏云解析 + 下载较慢：计时器让等待过程可见，避免像「卡死」 */
      var t0 = Date.now();
      var timer = setInterval(function () {
        if (!btn) return;
        var s = Math.round((Date.now() - t0) / 1000);
        btn.textContent = '⏳ 处理中 ' + s + 's（解析+下载约 1~2 分钟，请勿关闭）';
      }, 1000);
      fetch('update-check.php', { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) {
          if (!r.ok) throw new Error('服务器返回 HTTP ' + r.status + '（网关超时会报 502/504，可稍后重试）');
          return r.text();
        })
        .then(function (t) {
          clearInterval(timer);
          var m = null;
          try { m = JSON.parse(t); } catch (e) { /* 非 JSON（HTML 错误页） */ }
          var msg = m ? ((m.ok ? '✅ ' : '❌ ') + (m.msg || m.error || '操作完成')) : t.slice(0, 400);
          window.alert(msg, function () { window.location.reload(); });
        })
        .catch(function (e) {
          clearInterval(timer);
          window.alert('❌ 请求失败：' + e + '\n\n常见原因：蓝奏云解析 / 大文件下载耗时较长被服务器网关掐断（502/504）。可再试一次；多次失败建议改用官方站直链 zip 或「上传更新包」。', function () {
            if (btn) { btn.disabled = false; btn.textContent = orig; }
          });
        });
    });
  });
})();
</script>

<?php include 'includes/footer.php'; ?>
