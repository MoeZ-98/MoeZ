<?php
/**
 * 兼容入口：2.1.0 起积分商城管理统一到 admin/points.php
 * ------------------------------------------------------------
 * 老书签 / 老文档里的 /admin/theme-shop.php 仍然可用，
 * 这里只做一次带提示的跳转，避免出现「两套后台读两套表」的问题。
 */
require __DIR__ . '/bootstrap.php';

if (!moe_is_owner()) { flash('只有站长可以管理积分商城', 'bad'); redirect('index.php'); }

flash('积分商城管理已升级为核心功能，已为你打开新页面', 'ok');
redirect('points.php');
