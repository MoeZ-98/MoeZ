<?php
/**
 * 后台 · 分类管理（增删改 + 排序）
 */
require __DIR__ . '/bootstrap.php';
$active = 'cats';
$page_title = '分类管理';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (function_exists('moe_content_changed')) moe_content_changed();   // 1.9.0：内容变更 → 清理统计/导航缓存与页面缓存
    $act = $_POST['act'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    if ($act === 'create') {
        $name = trim($_POST['name'] ?? '');
        $slug = trim($_POST['slug'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $sort = (int)($_POST['sort'] ?? 0);
        $link = trim($_POST['link'] ?? '');
        if ($name === '') { flash('分类名称不能为空', 'bad'); redirect('categories.php'); }
        // 1.8.2：别名不再「格式不对就拒绝创建」——自动净化（中文/空格/符号转 -），再自动去重
        $slug = moe_slug_clean($slug, $name);
        $slug = moe_cat_slug_unique($slug);
        q('INSERT INTO ' . moe_table('categories') . ' (name,slug,description,link,sort) VALUES (?,?,?,?,?)', array($name, $slug, $desc, $link, $sort));
        flash('分类「' . $name . '」已创建 🎉 别名：' . $slug . ($link !== '' ? '（导航点击将跳转自定义链接）' : ''));
    } elseif ($act === 'update') {
        $name = trim($_POST['name'] ?? '');
        $slug = trim($_POST['slug'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $sort = (int)($_POST['sort'] ?? 0);
        $link = trim($_POST['link'] ?? '');
        if ($name !== '') {
            // 别名没改动就原样保留：历史分类可能用了 life / links 等「保留词」（如点滴分类），
            // 不能因为一次改名操作被连带换成 cat-xxx 而破坏原有链接
            $curSlug = (string)one('SELECT slug FROM ' . moe_table('categories') . ' WHERE id = ?', array($id));
            if ($slug === '' || $slug !== $curSlug) {
                $slug = moe_cat_slug_unique(moe_slug_clean($slug, $name), $id);
            }
            q('UPDATE ' . moe_table('categories') . ' SET name=?, slug=?, description=?, link=?, sort=? WHERE id=?',
                array($name, $slug, $desc, $link, $sort, $id));
            flash('分类已更新（别名：' . $slug . '）');
        }
    } elseif ($act === 'update_seo') {
        q('UPDATE ' . moe_table('categories') . ' SET seo_title=?, seo_keywords=?, seo_desc=? WHERE id=?',
            array(trim($_POST['seo_title'] ?? ''), trim($_POST['seo_keywords'] ?? ''), trim($_POST['seo_desc'] ?? ''), $id));
        flash('分类 SEO 已保存');
    } elseif ($act === 'delete') {
        q('UPDATE ' . moe_table('posts') . ' SET category_id = 0 WHERE category_id = ?', array($id));
        q('DELETE FROM ' . moe_table('categories') . ' WHERE id = ?', array($id));
        flash('分类已删除，其下文章已移至「未分类」');
    }
    redirect('categories.php');
}

$cats = rows('SELECT c.*, (SELECT COUNT(*) FROM ' . moe_table('posts') . " p WHERE p.category_id = c.id AND p.type='post') AS cnt
             FROM " . moe_table('categories') . ' c ORDER BY c.sort, c.id');
include 'includes/header.php';
?>

<div class="dash-cols">
  <div class="card" style="margin-bottom:0">
    <h2 class="card-title">新建分类</h2>
    <form method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="act" value="create">
      <div class="field"><label>名称 *</label><input type="text" name="name" placeholder="如：碎碎念" required></div>
      <div class="field"><label>别名（slug，留空自动生成）</label><input type="text" name="slug" placeholder="essay">
        <p class="hint">会作为文章链接目录：/别名/1.html。可留空；填中文或符号会自动转换（如「碎碎念」→ suisuinian 不可用时用 cat-xxx），重名自动加 -2</p>
      </div>
      <div class="field"><label>描述</label><input type="text" name="description" placeholder="这个分类用来放什么？"></div>
      <div class="field"><label>自定义链接（选填）</label><input type="text" name="link" placeholder="如 https://example.com 或 /life">
        <p class="hint">填了以后，前台导航和列表里点这个分类会直接跳转到该链接（支持站内路径或外部网址）；留空则正常打开分类文章列表</p>
      </div>
      <div class="field"><label>排序（越小越靠前）</label><input type="number" name="sort" value="0"></div>
      <button class="btn wide" type="submit">＋ 创建分类</button>
    </form>
  </div>

  <div class="card" style="margin-bottom:0">
    <h2 class="card-title">全部分类（<?php echo count($cats); ?>）</h2>
    <div class="table-wrap">
      <table class="tbl">
        <thead><tr><th>名称</th><th>别名</th><th>文章数</th><th>操作</th></tr></thead>
        <tbody>
        <?php foreach ($cats as $c): ?>
          <tr>
            <td>
              <form method="post" style="display:flex;gap:6px;align-items:center">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="update">
                <input type="hidden" name="id" value="<?php echo (int)$c['id']; ?>">
                <input type="text" name="name" value="<?php echo e($c['name']); ?>" style="width:110px;padding:6px 10px;border:1.5px solid #e8e2f0;border-radius:8px">
                <input type="text" name="slug" value="<?php echo e($c['slug']); ?>" title="别名" style="width:90px;padding:6px 10px;border:1.5px solid #e8e2f0;border-radius:8px">
                <input type="text" name="link" value="<?php echo e(!empty($c['link']) ? $c['link'] : ''); ?>" title="自定义链接（填了则导航点击直接跳转）" placeholder="自定义链接（选填）" style="width:130px;padding:6px 10px;border:1.5px solid #e8e2f0;border-radius:8px">
                <input type="number" name="sort" value="<?php echo (int)$c['sort']; ?>" title="排序" style="width:56px;padding:6px 10px;border:1.5px solid #e8e2f0;border-radius:8px">
                <button class="btn sm" type="submit">保存</button>
              </form>
            </td>
            <td style="color:var(--muted)"><?php echo e($c['slug']); ?></td>
            <td><span class="pill violet"><?php echo (int)$c['cnt']; ?></span></td>
            <td>
              <form method="post" onsubmit="return confirm('删除该分类？其下文章会变成未分类')">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="delete">
                <input type="hidden" name="id" value="<?php echo (int)$c['id']; ?>">
                <button class="btn danger sm" type="submit">删除</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="card" style="margin-top:20px">
  <h2 class="card-title">分类 SEO（TKD）</h2>
  <p class="hint" style="margin:-8px 0 14px">留空则自动使用：标题=分类名、关键词=分类名+站点关键词、描述=分类描述</p>
  <?php foreach ($cats as $c): ?>
    <form method="post" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;padding:10px 0;border-bottom:1px dashed var(--line)">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="act" value="update_seo">
      <input type="hidden" name="id" value="<?php echo (int)$c['id']; ?>">
      <b style="min-width:90px;font-size:13.5px"><?php echo e($c['name']); ?></b>
      <input type="text" name="seo_title" value="<?php echo e($c['seo_title']); ?>" placeholder="SEO 标题"
             style="flex:1;min-width:150px;padding:7px 11px;border:1.5px solid #e8e2f0;border-radius:9px;font-size:13px">
      <input type="text" name="seo_keywords" value="<?php echo e($c['seo_keywords']); ?>" placeholder="关键词，逗号分隔"
             style="flex:1;min-width:150px;padding:7px 11px;border:1.5px solid #e8e2f0;border-radius:9px;font-size:13px">
      <input type="text" name="seo_desc" value="<?php echo e($c['seo_desc']); ?>" placeholder="SEO 描述"
             style="flex:1.4;min-width:180px;padding:7px 11px;border:1.5px solid #e8e2f0;border-radius:9px;font-size:13px">
      <button class="btn sm" type="submit">保存</button>
    </form>
  <?php endforeach; ?>
</div>

<?php include 'includes/footer.php'; ?>
