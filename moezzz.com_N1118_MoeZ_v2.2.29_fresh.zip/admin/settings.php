<?php
/**
 * 后台 · 站点设置
 * 选项卡布局：SEO / 收录推送 / 链接与伪静态 / 品牌与外观 / 邮箱与登录 / 缓存 / 功能设置
 * 2.0.1：个人资料 / 社交与展示 / 账户安全 三个页签已移到「用户中心」(profile.php)
 * 一个 form 包裹全部选项卡，任意页签内的「保存」均提交全部设置项
 * 1.6.6：品牌与外观（logo / 配色 / 欢迎语）、Redis 缓存（社交链接动态列表 2.0.1 已迁至用户中心）
 */
require __DIR__ . '/bootstrap.php';
$active = 'settings';
$page_title = '站点设置';

$boolKeys = array('page_cache', 'comment_edit', 'comment_enabled', 'seo_canonical', 'seo_og', 'seo_jsonld', 'seo_sitemap', 'seo_push_auto', 'welcome_enabled', 'redis_enabled', 'login_captcha', 'smtp_enabled', 'mail_notify_link', 'mail_notify_comment', 'user_register', 'user_comment_login', 'ai_enabled', 'ai_web');
// 标题相关：网站标题（site_name）、浏览器标题（browser_title，只上首页）、标题显示方式（title_mode）
// 说明：site_sub / site_url / seo_noindex_search 不在本页接收（避免误清空或误关推荐行为）
$keys = array(
    'site_name', 'browser_title', 'title_mode',
    'site_keywords', 'site_desc',
    'footer_text', 'posts_per_page', 'comment_enabled', 'site_status',
    'seo_canonical', 'seo_og', 'seo_jsonld', 'seo_sitemap',
    'url_style', 'upload_max_mb',
    'seo_push_baidu', 'seo_push_360', 'seo_push_sogou', 'seo_push_bing', 'seo_push_auto',
    'admin_accent', 'admin_c1', 'admin_c2', 'admin_c3',
    'admin_logo', 'login_logo',
    'welcome_enabled', 'welcome_text',
    'redis_enabled', 'page_cache',
    'redis_host', 'redis_port', 'redis_auth', 'redis_db',
    'page_cache_ttl',
    // 1.8.0：登录页外观 / 验证码 / SMTP 邮箱 / 审核通知
    'login_bg', 'login_card_bg',
    'login_captcha',
    'smtp_enabled', 'smtp_host', 'smtp_port', 'smtp_secure', 'smtp_user', 'smtp_pass', 'smtp_from', 'smtp_from_name',
    'mail_notify_link', 'mail_notify_comment',
    'mail_test_to',
    // 2.0.0：用户中心（复选框必须同时出现在 $boolKeys 与 $keys，参考 1.9.3 的坑）
    'user_register', 'user_comment_login',
    // 2.1.2：会员编辑自己的评论开关
    'comment_edit',
    // 2.1.18：AI 助手（看板娘大脑）
    'ai_enabled', 'ai_base', 'ai_key', 'ai_model', 'ai_temp', 'ai_web', 'ai_daily', 'ai_timeout', 'ai_persona', 'ai_price_in', 'ai_price_out',
    // 2.2.22：正文编辑器选择（markdown / ueditor）
    'editor_mode',
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    foreach ($keys as $k) {
        if ($k === 'posts_per_page') {
            setting_set($k, max(1, (int)($_POST[$k] ?? 6)));
        } elseif ($k === 'upload_max_mb') {
            $v = (int)($_POST[$k] ?? 50);
            setting_set($k, ($v < 1 ? 1 : ($v > 2048 ? 2048 : $v)));
        } elseif ($k === 'page_cache_ttl') {
            $v = (int)($_POST[$k] ?? 120);
            setting_set($k, $v < 10 ? 10 : ($v > 3600 ? 3600 : $v));
        } elseif (in_array($k, $boolKeys, true)) {
            setting_set($k, isset($_POST[$k]) ? '1' : '0');
        } elseif ($k === 'site_status') {
            setting_set($k, ($_POST[$k] ?? 'open') === 'closed' ? 'closed' : 'open');
        } elseif ($k === 'title_mode') {
            setting_set($k, ($_POST[$k] ?? 'browser') === 'site' ? 'site' : 'browser');
        } elseif ($k === 'url_style') {
            $v = (string)($_POST[$k] ?? 'cat_num');
            setting_set($k, array_key_exists($v, url_styles()) ? $v : 'cat_num');
        } elseif ($k === 'editor_mode') {
            setting_set($k, ($_POST[$k] ?? 'markdown') === 'ueditor' ? 'ueditor' : 'markdown');   // 2.2.22
        } elseif ($k === 'admin_accent') {
            $v = trim((string)($_POST[$k] ?? ''));
            setting_set($k, in_array($v, array('', 'sakura', 'sunset', 'sky', 'mint', 'grape', 'custom'), true) ? $v : '');
        } else {
            setting_set($k, trim((string)($_POST[$k] ?? '')));
        }
    }
    // Redis 端口合法性
    $rp = (int)setting('redis_port', '6379');
    if ($rp < 1 || $rp > 65535) setting_set('redis_port', '6379');

    // 2.2.8：保存后如果启用了 Redis，立刻用新配置实测连接 —— 切换成功/失败当场给出结论
    if (setting('redis_enabled', '0') === '1') {
        require_once dirname(__DIR__) . '/includes/cache.php';
        if (function_exists('moe_cache_status')) {
            $cst = moe_cache_status(true);   // 2.2.29：强制用刚保存的新配置 + 全新连接检测，不复用请求早前的旧尝试
            if (!empty($cst['connected'])) {
                flash('⚡ Redis 已启用并连接成功，站点缓存已切换到 Redis' . ($cst['ver'] !== '' ? '（Redis ' . $cst['ver'] . '）' : ''), 'ok');
            } elseif (!$cst['ext']) {
                flash('⚠ Redis 已启用，但 PHP 未安装 phpredis 扩展，缓存已停用（数据直接查库，不做文件兜底。宝塔：PHP 设置 → 安装扩展 → redis）', 'bad');
            } else {
                flash('⚠ Redis 已启用，但连接失败，缓存已停用（数据直接查库，不做文件兜底）' . ($cst['err'] !== '' ? '：' . $cst['err'] : ''), 'bad');
            }
        }
    }

    // 先保存所有字段，再处理动作按钮（推送 / 测试等用的是刚保存的新配置）
    $act = (string)($_POST['act'] ?? '');
    if ($act === 'push_all') {
        require_once dirname(__DIR__) . '/includes/push.php';
        @set_time_limit(300);
        $urls = moe_push_targets();
        $res  = moe_push_urls($urls);
        $sum  = moe_push_summary($res);
        setting_set('seo_push_last', '[' . date('Y-m-d H:i') . '] ' . count($urls) . ' 条 · ' . $sum);
        if (function_exists('moe_push_log_results')) moe_push_log_results(count($urls), $res);   // 2.2.8：写入提交记录
        flash('推送完成 📮 ' . $sum, '');
        redirect('settings.php');
    }
    if ($act === 'renumber') {
        $n = function_exists('moe_reindex_cat_nums') ? moe_reindex_cat_nums(null) : 0;
        flash($n > 0 ? "编号已自动补全：{$n} 篇文章的编号被重排为连续序号 🔢" : '编号已经是连续的，无需调整 ✅');
        redirect('settings.php');
    }
    if ($act === 'redis_test') {
        require_once dirname(__DIR__) . '/includes/cache.php';
        $res = moe_cache_test($_POST['redis_host'] ?? '', $_POST['redis_port'] ?? '', $_POST['redis_auth'] ?? '', $_POST['redis_db'] ?? '');
        flash(($res['ok'] ? '' : '❌ ') . $res['msg'], $res['ok'] ? '' : 'bad');
        redirect('settings.php');
    }
    if ($act === 'cache_flush') {
        require_once dirname(__DIR__) . '/includes/cache.php';
        $n = 0;
        if (moe_cache_ready()) $n += (int)cache_flush();
        // 1.9.0：文件缓存与页面缓存一并清理
        if (function_exists('moe_fcache_flush')) {
            $n += (int)moe_fcache_flush('data');
            $n += (int)moe_fcache_flush('pc');
        }
        if (function_exists('moe_pcache_bump')) moe_pcache_bump();
        flash($n > 0 ? "已清空 {$n} 条程序缓存 ⚡" : '当前没有可清理的缓存');
        redirect('settings.php');
    }
    if ($act === 'mail_test') {
        // 用刚保存的 SMTP 配置发一封测试邮件
        $to = trim((string)($_POST['mail_test_to'] ?? setting('mail_test_to', '')));
        if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
            flash('请先填写一个用于接收测试邮件的邮箱地址', 'bad');
            redirect('settings.php');
        }
        setting_set('mail_test_to', $to);
        require_once dirname(__DIR__) . '/includes/mail.php';
        $subject = '【' . moe_mail_from_name() . '】SMTP 配置测试邮件 ✉️';
        $html = moe_mail_template(
            'SMTP 配置成功 🎉',
            array(
                '这是一封测试邮件，说明你的 SMTP 邮箱配置已生效。',
                '之后友链 / 评论审核结果通知会通过这个邮箱通道发出（需在下方开启对应通知开关）。',
            ),
            '进入站点',
            base_url()
        );
        $res = moe_mail_send($to, $subject, $html);
        flash(($res['ok'] ? '✉️ 测试邮件已发送至 ' . $to . '，请查收（垃圾箱也翻一翻）' : '❌ 发送失败：' . $res['msg']), $res['ok'] ? '' : 'bad');
        redirect('settings.php');
    }

    if ($act === 'ai_test') {
        require_once dirname(__DIR__) . '/includes/ai.php';
        $r = moe_ai_ping();
        // 2.2.13：把最近一次连通检测结果落盘，供「AI 状态」监控卡展示（后台 / 前台小屋都能看到）
        setting_set('ai_last_check', empty($r['ok']) ? '0' : '1');
        setting_set('ai_last_check_at', date('Y-m-d H:i'));
        setting_set('ai_last_check_note', empty($r['ok'])
            ? ('连接失败：' . (isset($r['err']) && $r['err'] !== '' ? $r['err'] : ('HTTP ' . (int)$r['code'])))
            : ('连通正常 · ' . (int)$r['ms'] . ' ms · 模型回话：' . mb_substr((string)$r['text'], 0, 40, 'UTF-8')));
        if (empty($r['ok'])) {
            $why = isset($r['err']) && $r['err'] !== '' ? $r['err'] : ('HTTP ' . (int)$r['code']);
            flash('❌ 连接失败：' . $why, 'bad');
        } else {
            flash('✅ 连接成功（' . (int)$r['ms'] . ' ms）模型回话：' . mb_substr((string)$r['text'], 0, 60, 'UTF-8'));
        }
        redirect('settings.php');
    }

    flash('站点设置已保存 ⚙️✨');
    redirect('settings.php');
}
$nginx = "location / {\n"
       . "    try_files \$uri \$uri/ /index.php?\$query_string;\n"
       . "}";
$hasHtaccess = is_file(MOE_ROOT . '/.htaccess');
$curStyle = url_style();

// 示例数据：站点名 / 首个分类 / 最新文章
$sampleCat = null;
try { $sampleCat = row('SELECT * FROM ' . moe_table('categories') . ' ORDER BY sort, id LIMIT 1'); } catch (Throwable $e) {}
$samplePost = null;
try { $samplePost = row('SELECT * FROM ' . moe_table('posts') . " WHERE type='post' AND status='published' ORDER BY id DESC LIMIT 1"); } catch (Throwable $e) {}

// 选项卡通用底部（同一 form，全部设置一起提交）
function set_foot() {
    echo '<div class="form-foot" style="border-top:1px dashed var(--line);padding-top:16px;margin-top:20px">'
       . '<button class="btn" type="submit">💾 保存所有设置</button>'
       . '<a class="btn ghost" href="' . e(base_url()) . '" target="_blank">前台预览 ↗</a>'
       . '</div>';
}

include 'includes/header.php';
?>

<form method="post">
  <?php echo csrf_field(); ?>

  <!-- ================= 选项卡栏 ================= -->
  <div class="set-tabs" id="setTabs" role="tablist" aria-label="站点设置">
    <button type="button" class="set-tab cur" id="tab-pane-seo" data-pane="pane-seo" role="tab" aria-selected="true" aria-controls="pane-seo">🔍 SEO 设置</button>
    <button type="button" class="set-tab" id="tab-pane-push" data-pane="pane-push" role="tab" aria-selected="false" aria-controls="pane-push">📮 收录推送</button>
    <button type="button" class="set-tab" id="tab-pane-url" data-pane="pane-url" role="tab" aria-selected="false" aria-controls="pane-url">🔗 链接与伪静态</button>
    <button type="button" class="set-tab" id="tab-pane-brand" data-pane="pane-brand" role="tab" aria-selected="false" aria-controls="pane-brand">🎨 品牌与外观</button>
    <button type="button" class="set-tab" id="tab-pane-mail" data-pane="pane-mail" role="tab" aria-selected="false" aria-controls="pane-mail">📧 邮箱与登录</button>
    <button type="button" class="set-tab" id="tab-pane-cache" data-pane="pane-cache" role="tab" aria-selected="false" aria-controls="pane-cache">⚡ 缓存设置</button>
    <button type="button" class="set-tab" id="tab-pane-func" data-pane="pane-func" role="tab" aria-selected="false" aria-controls="pane-func">⚙️ 功能设置</button>
    <button type="button" class="set-tab" id="tab-pane-ai" data-pane="pane-ai" role="tab" aria-selected="false" aria-controls="pane-ai">🤖 AI 助手</button>
  </div>

  <!-- ================= 选项卡 1 · SEO（TKD） ================= -->
  <div class="card set-pane cur" id="pane-seo" role="tabpanel">
      <h2 class="card-title">SEO · TKD 自定义</h2>

      <div class="sub-h plain">标题设置</div>
      <div class="form-grid">
        <div class="field full"><label>网站标题（网站正式名称）</label>
          <input type="text" name="site_name" value="<?php echo e(setting('site_name', '')); ?>" placeholder="例如：MoeZ">
          <p class="hint">站点正式名称：分类页 / 文章页的浏览器标签都用它收尾，前台主题显示的站点名也取它。</p>
        </div>
        <div class="field full"><label>浏览器标题（只显示在首页）</label>
          <input type="text" name="browser_title" value="<?php echo e(setting('browser_title', '')); ?>"
                 placeholder="留空则使用网站标题；可用 {site} 代表网站标题">
          <p class="hint">只在首页的浏览器标签显示，可写得比网站标题更长更好点；<code>{site}</code> 代表网站标题。</p>
        </div>
        <div class="field full"><label>标题显示方式</label>
          <select name="title_mode">
            <option value="browser" <?php echo seo_title_mode() === 'browser' ? 'selected' : ''; ?>>浏览器标题（首页显示浏览器标题）</option>
            <option value="site" <?php echo seo_title_mode() === 'site' ? 'selected' : ''; ?>>网站标题（首页也显示网站标题）</option>
          </select>
          <p class="hint">二选一，决定首页标签用哪个标题。分类页 / 文章页始终是「页面名 - 网站标题」，例如：<b><?php echo e(seo_content_title('文章标题')); ?></b></p>
        </div>
      </div>

      <p class="hint">浏览器标签页（<code>&lt;title&gt;</code>）里实际显示的文字由「网站标题 / 浏览器标题 / 标题显示方式」决定，保存后前台即刻生效。</p>

      <div class="sub-h plain">Keywords · Description</div>
      <div class="form-grid">
        <div class="field full"><label>站点关键词（Keywords）</label>
          <input type="text" name="site_keywords" value="<?php echo e(setting('site_keywords')); ?>" placeholder="个人主页,博客,MoeZ">
          <p class="hint">英文逗号分隔。分类页 / 文章页会自动追加自身关键词</p>
        </div>
        <div class="field full"><label>站点描述（Description）</label>
          <textarea name="site_desc" rows="3" style="width:100%;padding:10px 13px;border:1.5px solid #e8e2f0;border-radius:10px;outline:none;resize:vertical"
                    placeholder="一句话介绍你的站点，建议 80-160 字"><?php echo e(setting('site_desc')); ?></textarea>
        </div>
      </div>

      <div class="sub-h plain">收录输出</div>
      <div class="seo-grid">
        <label class="seo-item">
          <input type="checkbox" name="seo_canonical" <?php echo setting('seo_canonical', '1') === '1' ? 'checked' : ''; ?>>
          <span class="seo-ico">🔗</span>
          <span class="seo-txt"><b>canonical 规范链接</b><small>告诉搜索引擎每篇文章的权威地址</small></span>
        </label>
        <label class="seo-item">
          <input type="checkbox" name="seo_og" <?php echo setting('seo_og', '1') === '1' ? 'checked' : ''; ?>>
          <span class="seo-ico">📣</span>
          <span class="seo-txt"><b>分享卡片（Open Graph）</b><small>QQ / 微博 / Twitter 分享时显示标题缩略图</small></span>
        </label>
        <label class="seo-item">
          <input type="checkbox" name="seo_jsonld" <?php echo setting('seo_jsonld', '1') === '1' ? 'checked' : ''; ?>>
          <span class="seo-ico">🧩</span>
          <span class="seo-txt"><b>JSON-LD 结构化数据</b><small>搜索引擎与 AI 引用站点信息用</small></span>
        </label>
        <label class="seo-item">
          <input type="checkbox" name="seo_sitemap" <?php echo setting('seo_sitemap', '1') === '1' ? 'checked' : ''; ?>>
          <span class="seo-ico">🗺</span>
          <span class="seo-txt"><b>开放 sitemap.xml</b><small>站点地图，收录推送的标配</small></span>
        </label>
      </div>

      <p class="hint" style="margin-top:12px">
        🗺 站点地图：<a href="<?php echo e(sitemap_url()); ?>" target="_blank" style="color:var(--violet)"><?php echo e(sitemap_url()); ?></a>
        &nbsp;·&nbsp; 🤖 <?php echo e(base_url()); ?>robots.txt
        &nbsp;·&nbsp; 搜索结果页已自动 noindex（避免重复收录，无需设置）
      </p>
      <?php set_foot(); ?>
  </div>

  <!-- ================= 选项卡 2 · 搜索引擎收录推送 ================= -->
  <div class="card set-pane" id="pane-push" role="tabpanel">
      <h2 class="card-title">搜索引擎收录推送</h2>
      <p class="hint" style="margin-bottom:16px">
        填好平台给的 token / 密钥即表示启用该引擎，留空则不推送。推送内容为：首页 + 全部分类页 + 已发布文章 + 独立页面。
      </p>

      <div class="form-grid">
        <div class="field"><label>🐾 百度 · token</label>
          <input type="text" name="seo_push_baidu" value="<?php echo e(setting('seo_push_baidu', '')); ?>" placeholder="填 token 或直接粘贴完整 API 推送地址">
          <p class="hint">接口 <code>data.zz.baidu.com</code> · 单次最多 2000 条 · <b>可直接粘贴完整接口地址</b>，自动提取 token</p>
        </div>
        <div class="field"><label>🟢 360 搜索 · token</label>
          <input type="text" name="seo_push_360" value="<?php echo e(setting('seo_push_360', '')); ?>" placeholder="填 token 或直接粘贴完整 API 推送地址">
          <p class="hint">接口 <code>data.360.cn</code> · 单次最多 500 条 · 可直接粘贴完整接口地址，自动提取 token</p>
        </div>
        <div class="field"><label>🐶 搜狗 · 接收邮箱</label>
          <input type="text" name="seo_push_sogou" value="<?php echo e(setting('seo_push_sogou', '')); ?>" placeholder="you@example.com">
          <p class="hint">搜狗未开放批量 API，走站长平台收录提交，<b>每次最多 10 条</b>，日常建议用 sitemap</p>
        </div>
        <div class="field"><label>🅱️ 必应 · API 密钥</label>
          <input type="text" name="seo_push_bing" value="<?php echo e(setting('seo_push_bing', '')); ?>" placeholder="Bing Webmaster → 设置 → API 访问 → API 密钥">
          <p class="hint">接口 <code>ssl.bing.com/webmaster</code> · 单次最多 500 条</p>
        </div>
      </div>

      <div class="sub-h plain">推送操作</div>
      <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">
        <button class="btn" type="submit" name="act" value="push_all"
                onclick="return confirm('把全站链接推送给已填写的搜索引擎？站点文章较多时会耗时几十秒。')">📮 立即推送全站链接</button>
        <span class="hint" style="margin:0">推送前会自动保存本页所有设置，token 输入后可直接点这里</span>
      </div>

      <?php $lastPush = (string)setting('seo_push_last', ''); ?>
      <?php if ($lastPush !== ''): ?>
        <div class="alert ok" style="margin-top:14px;margin-bottom:0;word-break:break-all">最近一次推送：<?php echo e($lastPush); ?></div>
      <?php endif; ?>

      <?php
      /* 2.2.8：提交记录 —— 每次推送（含发文自动推送）都会留档，失败原因可回溯 */
      $pushLog = function_exists('moe_push_log_read') ? moe_push_log_read() : array();
      if ($pushLog):
          $plRow = function ($pl, $compact = false) {
              $items = (array)($pl['items'] ?? array());
              $h = '<div style="border:1px solid var(--line);border-radius:12px;padding:10px 14px;background:#fdfcff;font-size:12.5px">'
                 . '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">'
                 . '<span class="pill violet">' . e(date('m-d H:i', strtotime((string)$pl['time']))) . '</span>'
                 . '<span style="color:var(--muted)">' . (int)$pl['urls'] . ' 条链接</span>';
              foreach ($items as $it) {
                  $ok = !empty($it['ok']); $warn = !empty($it['warn']);
                  $h .= '<span class="pill ' . ($ok ? 'ok' : ($warn ? 'warn' : 'bad')) . '" title="' . e((string)$it['msg']) . '">'
                      . e((string)$it['engine']) . ' ' . ($ok ? '✅ ' . (int)$it['n'] . ' 条' : ($warn ? '⚠️ 今日配额已用完' : '✖ 失败')) . '</span>';
              }
              $h .= '</div>';
              if (!$compact) {
                  $badMsg = '';
                  foreach ($items as $it) {
                      if (empty($it['ok']) && !empty($it['msg'])) $badMsg .= e((string)$it['engine']) . '：' . e((string)$it['msg']) . '；';
                  }
                  if ($badMsg !== '') $h .= '<div style="color:var(--muted);margin-top:5px;word-break:break-all">' . $badMsg . '</div>';
              }
              return $h . '</div>';
          };
      ?>
      <div class="sub-h plain" style="margin-top:22px">提交记录（共 <?php echo count($pushLog); ?> 次）</div>
      <div style="display:flex;flex-direction:column;gap:8px">
        <?php foreach (array_slice($pushLog, 0, 8) as $pl) echo $plRow($pl); ?>
      </div>
      <?php if (count($pushLog) > 8): ?>
        <details style="margin-top:10px">
          <summary style="cursor:pointer;color:var(--violet);font-size:13px;font-weight:600">📋 查看更多（还有 <?php echo count($pushLog) - 8; ?> 条记录）</summary>
          <div style="display:flex;flex-direction:column;gap:8px;margin-top:10px">
            <?php foreach (array_slice($pushLog, 8) as $pl) echo $plRow($pl, true); ?>
          </div>
          <p class="hint" style="margin-top:8px">记录最多保留 200 条，更早的会自动清理。</p>
        </details>
      <?php endif; ?>
      <?php endif; ?>

      <div class="sub-h plain">自动推送</div>
      <div class="field full" style="margin-bottom:0">
        <label class="check-row"><input type="checkbox" name="seo_push_auto" <?php echo setting('seo_push_auto') === '1' ? 'checked' : ''; ?>>
          🚀 发布文章时自动把该文章链接推送给百度 / 360 / 必应（搜狗不参与，避免拖慢发布）</label>
        <p class="hint">提示：各平台的每日提交额度有限，文章量大的站点建议只在重要文章发布时使用，或定时手动推送全站。</p>
      </div>

      <p class="hint" style="margin-top:16px">
        📌 各平台入口：
        <a href="https://ziyuan.baidu.com/" target="_blank" style="color:var(--violet)">百度搜索资源平台</a> ·
        <a href="https://zhanzhang.so.com/" target="_blank" style="color:var(--violet)">360 站长平台</a> ·
        <a href="https://zhanzhang.sogou.com/" target="_blank" style="color:var(--violet)">搜狗站长平台</a> ·
        <a href="https://www.bing.com/webmasters" target="_blank" style="color:var(--violet)">Bing Webmaster</a>
      </p>
      <?php set_foot(); ?>
  </div>

  <!-- ================= 选项卡 3 · URL 样式 ================= -->
  <div class="card set-pane" id="pane-url" role="tabpanel">
      <h2 class="card-title">URL 样式（伪静态）</h2>
      <div class="form-grid">
        <div class="field full"><label>文章链接样式</label>
          <select name="url_style" id="urlStyle">
            <?php foreach (url_styles() as $code => $info): ?>
              <option value="<?php echo e($code); ?>" <?php echo $curStyle === $code ? 'selected' : ''; ?>>
                <?php echo e($info[0]); ?> · <?php echo e($info[1]); ?>
              </option>
            <?php endforeach; ?>
          </select>
          <p class="hint">切换后立即生效，旧链接（/post/xxx、/archives/1.html、?p=post&amp;id=1）仍可访问</p>
        </div>

        <div class="field"><label>示例预览</label>
          <div id="stylePreview" class="mono-box"><?php echo e(url_style_sample($curStyle, $sampleCat ? $sampleCat['slug'] : 'fenlei')); ?></div>
        </div>
        <div class="field"><label>真实内容预览</label>
          <div class="mono-box">
            <?php if ($samplePost): ?>
              <?php echo e(post_url($samplePost)); ?>
            <?php else: ?>
              还没有已发布文章，发布后这里会显示真实链接
            <?php endif; ?>
          </div>
        </div>

        <div class="field full">
          <div class="hint" style="margin:0">
            <b>编号规则</b>：「分类目录 / 编号」样式下，编号按分类独立计算，每个分类都从 <b>1</b> 开始（如
            <code>fenlei/1.html</code>、<code>fenlei2/1.html</code>）；切换分类或新建文章时自动分配，删除文章不会影响其他文章编号。
            未分类的文章放在 <code>uncategorized/编号.html</code>。
          </div>
        </div>
      </div>

      <div class="sub-h plain">文章编号</div>
      <div class="form-grid">
        <div class="field full">
          <div class="hint" style="margin:0 0 10px">
            <b>自动补全</b>：删除文章后，该分类的编号会自动重排为连续的 1、2、3…
            （例：原本 1~4 号，删掉 2、3 后，4 号自动变成 2 号）。历史遗留的空号可点下面按钮手动整理一次。
            注意：重排会改变文章链接，已发布到外部的旧链接可能失效。
          </div>
          <button class="btn ghost" type="submit" name="act" value="renumber"
                  onclick="return confirm('重新整理所有分类的文章编号？被删除留下的空号会被补全，相关文章链接会变化。')">🔢 立即整理全部编号</button>
        </div>
      </div>

      <?php if (!$hasHtaccess): ?>
        <div class="alert warn" style="margin-top:14px">未检测到 .htaccess 文件：Apache 环境下两种静态样式都会 404，请重新上传程序根目录的 .htaccess。</div>
      <?php endif; ?>

      <div style="margin-top:16px">
        <label style="font-size:12.5px;color:var(--muted)">Nginx 伪静态规则（Apache 已内置 .htaccess，无需设置）</label>
        <textarea readonly rows="3" onclick="this.select()" class="mono-box" style="width:100%;margin-top:6px;border:1.5px solid #e8e2f0;resize:vertical"><?php echo e($nginx); ?></textarea>
        <p class="hint">宝塔面板：网站 → 设置 → 伪静态 → 粘贴上面的规则并保存即可。</p>
        <div style="margin-top:10px;display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <button type="button" class="btn ghost sm" id="btnCheck">🔍 检测伪静态是否生效</button>
          <span class="hint" id="checkMsg" style="margin:0">检测方式：访问 sitemap.xml（需开启站点地图），返回正常即表示重写规则可用</span>
        </div>
      </div>
      <?php set_foot(); ?>
  </div>

  <!-- ================= 选项卡 6 · 品牌与外观 ================= -->
  <div class="card set-pane" id="pane-brand" role="tabpanel">
      <h2 class="card-title">品牌与外观</h2>

      <div class="sub-h plain">程序标识</div>
      <div class="form-grid">
        <div class="field full">
          <?php /* 程序作者署名：樊不烦 开发制作（仅保留在代码中，不在界面展示） */ ?>
          <div class="hint" style="margin:0 0 10px">程序：<b>萌Z · MoeZ</b>（英文名 MoeZ，中文名「萌Z」——萌，取自 Moe；家，取自 Home）</div>
        </div>
      </div>

      <div class="sub-h plain">Logo</div>
      <div class="form-grid">
        <div class="field"><label>后台 Logo（侧栏 + 登录页默认）</label>
          <div class="logo-pick">
            <img id="admLogoPrev" src="<?php $al = setting('admin_logo', ''); echo $al !== '' ? e(media_url($al)) : ''; ?>" alt=""
                 style="width:44px;height:44px;border-radius:12px;object-fit:cover;<?php echo $al === '' ? 'display:none' : '' ?>">
            <div style="flex:1">
              <input type="text" name="admin_logo" id="admLogoInput" value="<?php echo e(setting('admin_logo', '')); ?>" placeholder="留空显示 🌸 默认图标">
              <div style="display:flex;gap:8px;margin-top:8px;align-items:center">
                <label class="btn ghost sm" style="cursor:pointer">📤 上传
                  <input type="file" data-logo-target="admLogo" accept="image/*" style="display:none">
                </label>
                <button type="button" class="btn ghost sm" onclick="document.getElementById('admLogoInput').value='';document.getElementById('admLogoPrev').style.display='none'">🗑 清除</button>
              </div>
            </div>
          </div>
        </div>
        <div class="field"><label>登录页 Logo（留空用后台 Logo）</label>
          <div class="logo-pick">
            <img id="logLogoPrev" src="<?php $ll = setting('login_logo', ''); echo $ll !== '' ? e(media_url($ll)) : ''; ?>" alt=""
                 style="width:44px;height:44px;border-radius:12px;object-fit:cover;<?php echo $ll === '' ? 'display:none' : '' ?>">
            <div style="flex:1">
              <input type="text" name="login_logo" id="logLogoInput" value="<?php echo e(setting('login_logo', '')); ?>" placeholder="留空使用后台 Logo">
              <div style="display:flex;gap:8px;margin-top:8px;align-items:center">
                <label class="btn ghost sm" style="cursor:pointer">📤 上传
                  <input type="file" data-logo-target="logLogo" accept="image/*" style="display:none">
                </label>
                <button type="button" class="btn ghost sm" onclick="document.getElementById('logLogoInput').value='';document.getElementById('logLogoPrev').style.display='none'">🗑 清除</button>
              </div>
            </div>
          </div>
          <p class="hint">建议 128×128 以上的正方形图片（png / svg），圆角自动处理</p>
        </div>
      </div>

      <div class="sub-h plain">后台配色</div>
      <div class="accent-grid">
        <label class="accent-item"><input type="radio" name="admin_accent" value="" <?php echo setting('admin_accent', '') === '' ? 'checked' : ''; ?>><span class="sw" style="background:linear-gradient(135deg,#ff7eb3,#a18cd1,#8ec5fc)"></span>默认 粉紫</label>
        <label class="accent-item"><input type="radio" name="admin_accent" value="sunset" <?php echo setting('admin_accent', '') === 'sunset' ? 'checked' : ''; ?>><span class="sw" style="background:linear-gradient(135deg,#ff9a6c,#ff6f91,#ffc36c)"></span>落日橙红</label>
        <label class="accent-item"><input type="radio" name="admin_accent" value="sky" <?php echo setting('admin_accent', '') === 'sky' ? 'checked' : ''; ?>><span class="sw" style="background:linear-gradient(135deg,#5ba7ff,#7cc6ee,#6ee0d5)"></span>晴空海蓝</label>
        <label class="accent-item"><input type="radio" name="admin_accent" value="mint" <?php echo setting('admin_accent', '') === 'mint' ? 'checked' : ''; ?>><span class="sw" style="background:linear-gradient(135deg,#4fd1a5,#63c7b2,#9be15d)"></span>薄荷青绿</label>
        <label class="accent-item"><input type="radio" name="admin_accent" value="grape" <?php echo setting('admin_accent', '') === 'grape' ? 'checked' : ''; ?>><span class="sw" style="background:linear-gradient(135deg,#7f6bff,#b06cf0,#f06cf0)"></span>暗夜葡萄</label>
        <label class="accent-item"><input type="radio" name="admin_accent" value="custom" id="accentCustomRadio" <?php echo setting('admin_accent', '') === 'custom' ? 'checked' : ''; ?>><span class="sw" style="background:conic-gradient(#ff7eb3,#ffc36c,#4fd1a5,#5ba7ff,#a18cd1,#ff7eb3)"></span>自定义</label>
      </div>
      <div id="customColors" style="display:<?php echo setting('admin_accent', '') === 'custom' ? 'flex' : 'none' ?>;gap:16px;flex-wrap:wrap;margin-top:10px">
        <div class="field" style="margin:0"><label>主色（按钮 / 高亮）</label>
          <input type="color" name="admin_c1" value="<?php echo e(setting('admin_c1', '#ff7eb3') ?: '#ff7eb3'); ?>" style="width:52px;height:38px;padding:2px;border:1.5px solid #e8e2f0;border-radius:10px;cursor:pointer">
        </div>
        <div class="field" style="margin:0"><label>辅色（渐变中段）</label>
          <input type="color" name="admin_c2" value="<?php echo e(setting('admin_c2', '#a18cd1') ?: '#a18cd1'); ?>" style="width:52px;height:38px;padding:2px;border:1.5px solid #e8e2f0;border-radius:10px;cursor:pointer">
        </div>
        <div class="field" style="margin:0"><label>点缀色（渐变尾段）</label>
          <input type="color" name="admin_c3" value="<?php echo e(setting('admin_c3', '#8ec5fc') ?: '#8ec5fc'); ?>" style="width:52px;height:38px;padding:2px;border:1.5px solid #e8e2f0;border-radius:10px;cursor:pointer">
        </div>
      </div>
      <p class="hint">配色即时生效：保存后刷新任意后台页面即可看到按钮、菜单高亮与渐变横幅换新装。</p>

      <div class="sub-h plain">欢迎祝福语（仪表盘顶部横幅）</div>
      <div class="form-grid">
        <div class="field full">
          <label class="check-row"><input type="checkbox" name="welcome_enabled" <?php echo setting('welcome_enabled', '1') === '1' ? 'checked' : ''; ?>> 🏠 在仪表盘顶部横幅展示「欢迎回家」祝福语</label>
        </div>
        <div class="field full">
          <label>自定义祝福语（每行一条，进入仪表盘时随机展示一条；留空使用内置祝福语）</label>
          <textarea name="welcome_text" rows="4" style="width:100%;padding:10px 13px;border:1.5px solid #e8e2f0;border-radius:10px;outline:none;resize:vertical"
                    placeholder="欢迎回家～今天也是元气满满的一天 🌸&#10;回家啦！先看看今天有没有新评论吧 ☕"><?php echo e(setting('welcome_text', '')); ?></textarea>
        </div>
      </div>
      <?php set_foot(); ?>
  </div>

  <!-- ================= 选项卡 · 邮箱与登录 ================= -->
  <div class="card set-pane" id="pane-mail" role="tabpanel">
      <h2 class="card-title">邮箱与登录</h2>

      <div class="sub-h plain">登录页外观</div>
      <div class="form-grid">
        <div class="field full"><label>登录页大背景图（全屏铺满，建议 1920×1080 横图）</label>
          <div class="logo-pick">
            <img id="loginBgPrev" src="<?php $lb = setting('login_bg', ''); echo $lb !== '' ? e(media_url($lb)) : ''; ?>" alt=""
                 style="width:96px;height:56px;border-radius:10px;object-fit:cover;<?php echo $lb === '' ? 'display:none' : '' ?>">
            <div style="flex:1">
              <input type="text" name="login_bg" id="loginBgInput" value="<?php echo e(setting('login_bg', '')); ?>" placeholder="图片地址，或点「上传」选择本地图片；留空显示粉紫渐变">
              <div style="display:flex;gap:8px;margin-top:8px;align-items:center">
                <label class="btn ghost sm" style="cursor:pointer">📤 上传
                  <input type="file" data-logo-target="loginBg" accept="image/*" style="display:none">
                </label>
                <button type="button" class="btn ghost sm" onclick="document.getElementById('loginBgInput').value='';document.getElementById('loginBgPrev').style.display='none'">🗑 清除</button>
              </div>
            </div>
          </div>
        </div>
        <div class="field"><label>登录卡片背景色</label>
          <input type="color" name="login_card_bg" value="<?php echo e(setting('login_card_bg', '#ffffff') ?: '#ffffff'); ?>" style="width:52px;height:38px;padding:2px;border:1.5px solid #e8e2f0;border-radius:10px;cursor:pointer">
          <p class="hint">右侧悬浮卡片的底色，默认纯白</p>
        </div>
        <div class="field">
          <label class="check-row" style="margin-top:8px"><input type="checkbox" name="login_captcha" <?php echo setting('login_captcha', '0') === '1' ? 'checked' : ''; ?>> 🛡 登录时要求输入图形验证码</label>
          <p class="hint">开启后登录页显示验证码输入框，可有效防机器人爆破</p>
        </div>
      </div>

      <div class="sub-h plain">SMTP 发件邮箱（用于系统通知邮件）</div>
      <p class="hint" style="margin-bottom:14px">
        填好并启用后，系统可通过该邮箱给用户发通知（友链 / 评论审核结果）。
        QQ / 163 等邮箱请使用「<b>授权码</b>」作为密码（邮箱设置里开启 SMTP 并生成授权码）。
      </p>
      <div class="form-grid">
        <div class="field full">
          <label class="check-row"><input type="checkbox" name="smtp_enabled" <?php echo setting('smtp_enabled', '0') === '1' ? 'checked' : ''; ?>> ✉️ 启用 SMTP 发件</label>
        </div>
        <div class="field"><label>SMTP 服务器</label>
          <input type="text" name="smtp_host" value="<?php echo e(setting('smtp_host', '')); ?>" placeholder="如 smtp.qq.com / smtp.163.com / smtp.gmail.com">
        </div>
        <div class="field"><label>端口</label>
          <input type="number" name="smtp_port" value="<?php echo e(setting('smtp_port', '465')); ?>" min="1" max="65535">
          <p class="hint">SSL 一般 465；STARTTLS 一般 587；不加密一般 25</p>
        </div>
        <div class="field"><label>加密方式</label>
          <select name="smtp_secure">
            <option value="ssl" <?php echo setting('smtp_secure', 'ssl') === 'ssl' ? 'selected' : ''; ?>>SSL（端口 465，推荐）</option>
            <option value="tls" <?php echo setting('smtp_secure', 'ssl') === 'tls' ? 'selected' : ''; ?>>STARTTLS（端口 587）</option>
            <option value="none" <?php echo setting('smtp_secure', 'ssl') === 'none' ? 'selected' : ''; ?>>无加密（不推荐）</option>
          </select>
        </div>
        <div class="field"><label>SMTP 账号（发件邮箱）</label>
          <input type="text" name="smtp_user" value="<?php echo e(setting('smtp_user', '')); ?>" placeholder="you@example.com">
        </div>
        <div class="field"><label>SMTP 密码 / 授权码</label>
          <input type="password" name="smtp_pass" value="<?php echo e(setting('smtp_pass', '')); ?>" placeholder="QQ / 163 请填授权码，不是登录密码">
        </div>
        <!-- 2.0.1 自检补回：此前 smtp_from 在 $keys 里却没有表单入口，保存设置会被清空 -->
        <div class="field"><label>发件人地址（留空用 SMTP 账号）</label>
          <input type="text" name="smtp_from" value="<?php echo e(setting('smtp_from', '')); ?>" placeholder="留空自动使用上面的 SMTP 账号">
        </div>
        <div class="field"><label>发件人显示名（留空用站点名）</label>
          <input type="text" name="smtp_from_name" value="<?php echo e(setting('smtp_from_name', '')); ?>" placeholder="<?php echo e(setting('site_name', 'MoeZ') ?: 'MoeZ'); ?>">
        </div>
        <div class="field"><label>测试收件邮箱</label>
          <input type="text" name="mail_test_to" value="<?php echo e(setting('mail_test_to', '')); ?>" placeholder="填你的邮箱，点「发送测试邮件」验证配置">
        </div>
      </div>
      <div style="margin-top:6px">
        <button class="btn" type="submit" name="act" value="mail_test"
                onclick="return confirm('先保存本页设置，再发送一封测试邮件到上面的「测试收件邮箱」？')">✉️ 发送测试邮件</button>
      </div>

      <div class="sub-h plain">审核结果邮件通知</div>
      <p class="hint" style="margin-bottom:14px">
        需要先在上面启用 SMTP 并测试通过。通知对象为申请友链的用户 / 评论者（从其联系方式或邮箱中提取）。
      </p>
      <div class="form-grid">
        <div class="field full">
          <label class="check-row"><input type="checkbox" name="mail_notify_link" <?php echo setting('mail_notify_link', '0') === '1' ? 'checked' : ''; ?>> 🔗 友链申请审核结果通知（自动通过 / 待人工审核 时发邮件告知申请者）</label>
        </div>
        <div class="field full">
          <label class="check-row"><input type="checkbox" name="mail_notify_comment" <?php echo setting('mail_notify_comment', '0') === '1' ? 'checked' : ''; ?>> 💬 评论审核结果通知（评论通过展示时发邮件告知评论者，需对方留了邮箱）</label>
        </div>
      </div>
      <?php set_foot(); ?>
  </div>

  <!-- ================= 选项卡 7 · 缓存设置 ================= -->
  <div class="card set-pane" id="pane-cache" role="tabpanel">
      <h2 class="card-title">缓存设置（Redis）</h2>
      <p class="hint" style="margin-bottom:16px">
        开启后，站点设置等热点数据会缓存在 Redis（有效期 5 分钟，保存设置时自动刷新缓存），减轻数据库压力。
        需要服务器 PHP 已安装 <b>phpredis</b> 扩展（宝塔：PHP 设置 → 安装扩展 → redis）。
        <b>2.2.27 起：数据缓存只走 Redis —— 未启用 / 扩展缺失 / 连接失败时一律不缓存、直接查库，不再使用文件兜底缓存。</b>
      </p>

      <?php
      /* 2.2.8：实时状态 —— 扩展 / 配置 / 连接三步逐项展示，切换是否成功一目了然 */
      $cst = function_exists('moe_cache_status') ? moe_cache_status() : null;
      if ($cst): ?>
      <div style="border:1px solid var(--line);border-radius:14px;padding:14px 16px;background:linear-gradient(135deg,#f8fdfd,#f3f9ff);margin-bottom:16px;font-size:13px">
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <b style="color:var(--violet)">当前状态</b>
          <span class="pill <?php echo $cst['ext'] ? 'ok' : 'bad'; ?>"><?php echo $cst['ext'] ? '✅ phpredis 扩展已安装' : '✖ phpredis 扩展未安装'; ?></span>
          <span class="pill <?php echo $cst['enabled'] ? 'ok' : 'warn'; ?>"><?php echo $cst['enabled'] ? '✅ 已启用 Redis' : '未启用（不缓存，直接查库）'; ?></span>
          <?php if ($cst['enabled'] && $cst['ext']): ?>
            <span class="pill <?php echo $cst['connected'] ? 'ok' : 'bad'; ?>"><?php echo $cst['connected'] ? '✅ 连接正常，已切换到 Redis' . ($cst['ver'] !== '' ? ' ' . $cst['ver'] : '') : '✖ 连接失败，缓存停用（直接查库）'; ?></span>
          <?php endif; ?>
        </div>
        <?php if ($cst['enabled'] && $cst['ext'] && !$cst['connected'] && $cst['err'] !== ''): ?>
          <div style="color:var(--bad);margin-top:8px;word-break:break-all">失败原因：<?php echo e($cst['err']); ?>（<?php echo e($cst['err_at']); ?>）</div>
        <?php endif; ?>
        <?php if (!$cst['ext']): ?>
          <div style="color:var(--muted);margin-top:8px">提示：扩展装好后回来刷新本页，「连接失败」会变成「连接正常」。</div>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <div class="form-grid">
        <div class="field full">
          <label class="check-row"><input type="checkbox" name="redis_enabled" <?php echo setting('redis_enabled', '0') === '1' ? 'checked' : ''; ?>> ⚡ 启用 Redis 缓存</label>
        </div>
        <div class="field"><label>主机地址</label>
          <input type="text" name="redis_host" value="<?php echo e(setting('redis_host', '127.0.0.1')); ?>" placeholder="127.0.0.1">
        </div>
        <div class="field"><label>端口</label>
          <input type="number" name="redis_port" value="<?php echo e(setting('redis_port', '6379')); ?>" min="1" max="65535">
        </div>
        <div class="field"><label>密码（auth，无密码留空）</label>
          <input type="text" name="redis_auth" value="<?php echo e(setting('redis_auth', '')); ?>" placeholder="Redis 6+ 可填 user:password">
        </div>
        <div class="field"><label>数据库编号（db，一般 0）</label>
          <input type="number" name="redis_db" value="<?php echo e(setting('redis_db', '0')); ?>" min="0" max="15">
        </div>
      </div>

      <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-top:6px">
        <button class="btn" type="submit" name="act" value="redis_test"
                onclick="return confirm('用上面填写的配置测试 Redis 连接？（会先保存本页设置）')">🔌 测试连接</button>
        <button class="btn ghost" type="submit" name="act" value="cache_flush">🧹 清空程序缓存</button>
        <span class="hint" style="margin:0">测试前会先保存本页所有设置</span>
      </div>

      <div class="sub-h plain" style="margin-top:22px">页面缓存（1.9.0）</div>
      <p class="hint" style="margin-bottom:14px">
        开启后，访客访问首页 / 文章 / 分类 / 独立页面时直接输出已生成的 HTML，<b>不查数据库、不跑模板</b>，响应速度提升最明显。
        访客的评论表单令牌会按会话单独替换，不影响评论；你本人（已登录后台）始终看到最新内容。
        发文 / 审核评论 / 改设置时缓存自动刷新，无需手动清理。
      </p>
      <div class="form-grid">
        <div class="field full">
          <label class="check-row"><input type="checkbox" name="page_cache" <?php echo setting('page_cache', '1') === '1' ? 'checked' : ''; ?>> 🚀 启用页面缓存（推荐开启）</label>
          <p class="hint">关闭则每次访问都实时查询数据库，服务器负载会明显升高</p>
        </div>
        <div class="field"><label>缓存有效期（秒）</label>
          <input type="number" name="page_cache_ttl" value="<?php echo e(setting('page_cache_ttl', '120')); ?>" min="10" max="3600">
          <p class="hint">建议 60~300 秒。越短内容越实时，越长速度越快</p>
        </div>
      </div>
      <?php set_foot(); ?>
  </div>

  <!-- ================= 选项卡 8 · 功能设置 ================= -->
  <div class="card set-pane" id="pane-func" role="tabpanel">
      <h2 class="card-title">功能设置</h2>
      <div class="form-grid">
        <div class="field"><label>每页文章数</label>
          <input type="number" name="posts_per_page" value="<?php echo e(setting('posts_per_page', '6')); ?>" min="1" max="50">
        </div>
        <div class="field"><label>上传大小上限（MB）</label>
          <input type="number" name="upload_max_mb" value="<?php echo e(setting('upload_max_mb', '50')); ?>" min="1" max="2048">
          <p class="hint">编辑器上传图片 / 视频共用此上限。注意：若超过 PHP 自身的 upload_max_filesize / post_max_size，需要在宝塔 PHP 设置中同步调大</p>
        </div>
        <div class="field"><label>站点状态</label>
          <select name="site_status">
            <option value="open" <?php echo setting('site_status') !== 'closed' ? 'selected' : ''; ?>>正常开放</option>
            <option value="closed" <?php echo setting('site_status') === 'closed' ? 'selected' : ''; ?>>维护模式（前台显示维护页）</option>
          </select>
        </div>
        <div class="field"><label>正文编辑器（2.2.22）</label>
          <select name="editor_mode">
            <option value="markdown" <?php echo moe_editor_mode() === 'markdown' ? 'selected' : ''; ?>>Markdown 编辑器（默认 · 自研轻量）</option>
            <option value="ueditor" <?php echo moe_editor_mode() === 'ueditor' ? 'selected' : ''; ?>>UEditorPlus 富文本编辑器</option>
          </select>
          <p class="hint">切换后：后台发文与用户中心「投稿」都会使用这里选中的编辑器；UEditorPlus 为所见即所得富文本，正文按 HTML 格式保存</p>
        </div>
        <div class="field full">
          <label class="check-row"><input type="checkbox" name="comment_enabled" <?php echo setting('comment_enabled') !== '0' ? 'checked' : ''; ?>> 💬 开启文章评论（含 60 秒防灌水）</label>
          <label class="check-row" style="display:flex;margin-bottom:8px"><input type="checkbox" name="comment_edit" <?php echo setting('comment_edit', '1') === '1' ? 'checked' : ''; ?>> ✏️ 允许会员在用户中心编辑自己发表的评论（前台自己的评论会显示「编辑」入口）</label>
        </div>
        <!-- 2.0.0：用户中心设置 -->
        <div class="field full" style="border-top:1px dashed var(--line);padding-top:15px;margin-top:4px">
          <label style="display:block;font-weight:600;font-size:13.5px;margin-bottom:11px">👥 用户中心</label>
          <label class="check-row" style="display:flex;margin-bottom:8px"><input type="checkbox" name="user_register" <?php echo setting('user_register', '0') === '1' ? 'checked' : ''; ?>> 🌱 开放访客注册（默认关闭）</label>
          <label class="check-row" style="display:flex;margin-bottom:10px"><input type="checkbox" name="user_comment_login" <?php echo setting('user_comment_login', '0') === '1' ? 'checked' : ''; ?>> 🔒 仅登录用户可发表评论</label>
          <p class="hint" style="margin-top:2px">👤 个人资料、💬 社交与展示、🔐 账户安全已统一移到 <a href="profile.php">用户中心</a>：改昵称头像、社交链接、登录密码都去那里，站点设置只保留站点级配置。</p>
          <p class="hint">注册账号固定为「会员」，作者 / 站长权限请在 <a href="users.php">用户管理</a> 授予。用户中心 <code>/user</code>，作者主页 <code>/author/用户ID</code>；<a href="profile.php">我的用户中心</a> 可改头像、昵称、密码。</p>
        </div>
        <div class="field full"><label>页脚文字</label>
          <input type="text" name="footer_text" value="<?php echo e(setting('footer_text')); ?>" placeholder="© 2026 My MoeZ · Powered by 萌Z">
        </div>
      </div>
      <p class="hint" style="margin-top:6px">编辑器可在上方「正文编辑器」处切换 Markdown / UEditorPlus（2.2.22 起支持）。</p>
      <?php set_foot(); ?>
  </div>

  <!-- ================= 选项卡 9 · AI 助手（2.1.18） ================= -->
  <div class="card set-pane" id="pane-ai" role="tabpanel">
      <h2 class="card-title">AI 助手 · 看板娘的大脑</h2>
      <?php
      /* 2.2.13：AI 状态监控卡 —— 配置状态 / 最近连通检测 / 今日配额 / 用量与花费，后台一眼看清 */
      $__aiStats = function_exists('moe_ai_usage_stats') ? moe_ai_usage_stats() : array('total' => array('req' => 0, 'in' => 0, 'out' => 0), 'today' => array('req' => 0, 'in' => 0, 'out' => 0), 'cost_total' => 0, 'cost_today' => 0);
      $__aiCfg = function_exists('moe_ai_cfg') ? moe_ai_cfg() : array('on' => false, 'key' => '', 'model' => '', 'daily' => 200);
      $__aiQuota = function_exists('moe_ai_quota_used') ? moe_ai_quota_used() : 0;
      $__aiDaily = (int)$__aiCfg['daily'];
      $__aiLastOk = setting('ai_last_check', '') === '1';
      $__aiLastAt = trim((string)setting('ai_last_check_at', ''));
      $__aiLastNote = trim((string)setting('ai_last_check_note', ''));
      ?>
      <div style="border:1px solid var(--line);border-radius:14px;padding:16px 18px;margin:0 0 20px;background:#fbfaff">
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:12px">
          <b style="font-size:14.5px">📡 AI 运行状态</b>
          <span style="padding:3px 12px;border-radius:999px;font-size:12px;font-weight:700;background:<?php echo ($__aiCfg['on'] && $__aiCfg['key'] !== '') ? '#e4f9ef;color:#17946a' : '#fff0f0;color:#c04a4a'; ?>">
            <?php echo ($__aiCfg['on'] && $__aiCfg['key'] !== '') ? '● 已启用' : ($__aiCfg['key'] === '' ? '● 未配置密钥' : '● 已停用'); ?>
          </span>
          <?php if ($__aiLastAt !== '') { ?>
          <span style="padding:3px 12px;border-radius:999px;font-size:12px;font-weight:700;background:<?php echo $__aiLastOk ? '#e4f9ef;color:#17946a' : '#fff4e0;color:#a8741a'; ?>">
            最近检测：<?php echo e($__aiLastAt); ?> <?php echo $__aiLastOk ? '✓' : '✗'; ?>
          </span>
          <?php } ?>
          <span class="hint" style="margin-left:auto">模型：<?php echo e($__aiCfg['model'] !== '' ? $__aiCfg['model'] : 'deepseek-v4-flash'); ?></span>
        </div>
        <?php if ($__aiLastNote !== '') { ?><p class="hint" style="margin:0 0 10px">最近检测详情：<?php echo e($__aiLastNote); ?></p><?php } ?>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;font-size:13px">
          <div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:10px 12px">
            今日对话<b style="display:block;font-size:17px;color:var(--primary-deep)"><?php echo (int)$__aiQuota; ?></b>
            <span class="hint">条 / 上限 <?php echo $__aiDaily > 0 ? $__aiDaily : '不限'; ?></span>
          </div>
          <div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:10px 12px">
            今日 tokens<b style="display:block;font-size:17px;color:var(--primary-deep)"><?php echo (int)$__aiStats['today']['in']; ?> / <?php echo (int)$__aiStats['today']['out']; ?></b>
            <span class="hint">输入 / 输出</span>
          </div>
          <div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:10px 12px">
            今日花费<b style="display:block;font-size:17px;color:var(--primary-deep)">¥<?php echo e(number_format((float)$__aiStats['cost_today'], 4)); ?></b>
            <span class="hint">按后台单价估算</span>
          </div>
          <div style="background:#fff;border:1px solid var(--line);border-radius:10px;padding:10px 12px">
            累计调用<b style="display:block;font-size:17px;color:var(--primary-deep)"><?php echo (int)$__aiStats['total']['req']; ?></b>
            <span class="hint">次 · ¥<?php echo e(number_format((float)$__aiStats['cost_total'], 4)); ?></span>
          </div>
        </div>
        <p class="hint" style="margin:10px 0 0">前台监控：访客可在 <a href="<?php echo e(base_url()); ?>companion" target="_blank">版娘小屋 /companion</a> 看到同款用量统计（任意主题可用，无需主题适配）；每日对话超出上限自动降级站内引擎，不会产生超支账单。</p>
      </div>
      <div class="form-grid">
        <div class="field full">
          <label class="check-row"><input type="checkbox" name="ai_enabled" <?php echo setting('ai_enabled', '0') === '1' ? 'checked' : ''; ?>> 🤖 启用大模型对话（看板娘自由聊天）</label>
          <p class="hint">开启并填好密钥后，她就能自由聊天、解答站内功能问题，遇到不懂的自动联网查资料。
            没填密钥或调用失败时会安静退回站内规则引擎，前台不会报错。</p>
        </div>
        <div class="field"><label>接口地址（OpenAI 兼容）</label>
          <input type="text" name="ai_base" value="<?php echo e(setting('ai_base', '')); ?>" placeholder="https://api.deepseek.com/v1/chat/completions" autocomplete="off">
          <p class="hint">留空默认 DeepSeek。也可填 OpenAI / Moonshot / 通义 / 硅基流动等兼容地址，只填到 <code>/v1</code> 会自动补全
            <code>/chat/completions</code></p>
        </div>
        <div class="field"><label>API 密钥</label>
          <input type="password" name="ai_key" value="<?php echo e(setting('ai_key', '')); ?>" placeholder="sk-..." autocomplete="new-password">
          <p class="hint">只保存在本站数据库，前台和访客都拿不到。DeepSeek 可在 platform.deepseek.com 申请</p>
        </div>
        <div class="field"><label>模型名称</label>
          <input type="text" name="ai_model" value="<?php echo e(setting('ai_model', 'deepseek-v4-flash')); ?>" placeholder="deepseek-v4-flash">
          <p class="hint">DeepSeek：deepseek-v4-flash（推荐，快且便宜）/ deepseek-v4-pro（更强但贵且慢）；旧名 deepseek-chat / deepseek-reasoner 仍兼容</p>
        </div>
        <div class="field"><label>温度（0 ～ 1.5）</label>
          <input type="number" step="0.1" min="0" max="1.5" name="ai_temp" value="<?php echo e(setting('ai_temp', '0.7')); ?>">
          <p class="hint">越高越发散。聊天建议 0.7 ～ 0.9，太低了回答会刻板</p>
        </div>
        <div class="field"><label>每日对话上限</label>
          <input type="number" min="0" max="100000" name="ai_daily" value="<?php echo e(setting('ai_daily', '200')); ?>">
          <p class="hint">全站合计条数，<code>0</code> = 不限。防止被恶意刷爆 API 账单，超出后自动退回站内引擎（不报错）</p>
        </div>
        <div class="field"><label>单次超时（秒）</label>
          <input type="number" min="8" max="45" name="ai_timeout" value="<?php echo e(setting('ai_timeout', '22')); ?>">
          <p class="hint">模型迟迟不回就放弃并降级。网络差的服务器可调大</p>
        </div>
        <div class="field"><label>单价 · 输入（元 / 百万 tokens）</label>
          <input type="number" step="0.01" min="0" name="ai_price_in" value="<?php echo e(setting('ai_price_in', '1')); ?>">
          <p class="hint">用于「版娘」小屋统计页的成本估算，按 DeepSeek v4-flash 官方价默认 1</p>
        </div>
        <div class="field"><label>单价 · 输出（元 / 百万 tokens）</label>
          <input type="number" step="0.01" min="0" name="ai_price_out" value="<?php echo e(setting('ai_price_out', '2')); ?>">
          <p class="hint">同上，输出单价默认 2；改成 0 可隐藏金额只显示 tokens</p>
        </div>
        <div class="field full">
          <label class="check-row"><input type="checkbox" name="ai_web" <?php echo setting('ai_web', '1') === '1' ? 'checked' : ''; ?>> 🌐 允许联网搜索（回答站外问题时抓取公开网页）</label>
          <p class="hint">开启后，她不了解的事会先去 Bing / DuckDuckGo / 维基百科查资料再回答，并在气泡旁显示「联网」标签。
            只抓公开网页、不登录任何站点；关掉则只能凭模型自身知识回答。</p>
        </div>
        <div class="field full"><label>人设补充（追加在系统提示词后面）</label>
          <textarea name="ai_persona" rows="4" placeholder="例如：称呼访客为「你」，不要叫「亲」；遇到技术问题要给具体步骤而不是泛泛而谈。"><?php echo e(setting('ai_persona', '')); ?></textarea>
          <p class="hint">默认人设：活泼可爱、主打情感陪伴、知书达理带点学霸气质的看板娘，说话口语化、回答简短（1～3 句），会自然用小动作和颜文字。这里可以追加称呼、口头禅、禁忌话题等</p>
        </div>
        <div class="field full" style="border-top:1px dashed var(--line);padding-top:15px">
          <button type="submit" name="act" value="ai_test" class="btn ghost">🧪 保存并测试连接</button>
          <p class="hint" style="margin-top:8px">会先保存当前页面所有设置，再用新配置发一条极短测试消息；成功会提示耗时和模型回话，失败会给出具体原因（密钥错 / 余额不足 / 网络不通 / 地址错）。</p>
          <p class="hint">💡 没配密钥也能用：看板娘会用站内数据回答最新文章、分类、搜索、评论规则、积分玩法；本地答不上来且开启联网时，会直接给联网资料摘要。</p>
        </div>
      </div>
      <?php set_foot(); ?>
  </div>
</form>
<script>
(function () {
  /* ---------- 选项卡切换（记住上次停留的页签） ---------- */
  var tabBox = document.getElementById('setTabs');
  var panes = document.querySelectorAll('.set-pane');
  function showPane(id) {
    var ts = tabBox ? tabBox.querySelectorAll('.set-tab') : [];
    Array.prototype.forEach.call(ts, function (t) {
      var on = t.dataset.pane === id;
      t.className = on ? 'set-tab cur' : 'set-tab';
      t.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    Array.prototype.forEach.call(panes, function (p) {
      p.className = p.id === id ? 'card set-pane cur' : 'card set-pane';
    });
    try { localStorage.setItem('moe_set_tab', id); } catch (e) {}
  }
  if (tabBox) {
    tabBox.addEventListener('click', function (ev) {
      var t = ev.target;
      while (t && t !== tabBox && !(t.dataset && t.dataset.pane)) t = t.parentNode;
      if (t && t !== tabBox && t.dataset && t.dataset.pane) showPane(t.dataset.pane);
    });
    (function () {
      var last = null;
      try { last = localStorage.getItem('moe_set_tab'); } catch (e) {}
      if (last && document.getElementById(last)) showPane(last);
    })();
  }

  /* ---------- 通用图片上传（data-logo-target / id 前缀） ---------- */
  function bindUpload(fileInput, inputId, prevId, round) {
    fileInput.addEventListener('change', function () {
      if (!this.files[0]) return;
      var fd = new FormData(), xhr = new XMLHttpRequest();
      fd.append('file', this.files[0]);
      fd.append('_token', '<?php echo csrf_token(); ?>');
      var input = document.getElementById(inputId), prev = prevId ? document.getElementById(prevId) : null;
      xhr.open('POST', 'upload.php');
      xhr.onload = function () {
        try {
          var d = JSON.parse(xhr.responseText);
          if (d.ok) {
            input.value = d.url;
            // 预览容器可能是 <img> 本身，也可能是包着 <img> 的 div（如头像 #avaPrev），两种都要能刷新
            if (prev) {
              var im = prev.tagName === 'IMG' ? prev : prev.querySelector('img');
              if (im) { im.src = d.url; } else { prev.innerHTML = '<img src="' + d.url + '" style="width:100%;height:100%;object-fit:cover">'; }
            }
            fileInput.parentNode && (fileInput.parentNode.title = '✅ 上传成功，记得保存设置');
          } else { alert('上传失败：' + d.msg); }
        } catch (e) { alert('上传失败'); }
      };
      xhr.send(fd);
    });
  }
  document.querySelectorAll('input[type=file][data-logo-target]').forEach(function (f) {
    var t = f.getAttribute('data-logo-target');
    bindUpload(f, t + 'Input', t + 'Prev');
  });
  /* ---------- URL 样式预览 ---------- */
  var samples = <?php echo json_encode(url_style_samples(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
  var sel = document.getElementById('urlStyle'), box = document.getElementById('stylePreview');
  if (sel && box) {
    sel.addEventListener('change', function () {
      box.textContent = samples[sel.value] || '';
    });
  }

  /* ---------- 伪静态检测 ---------- */
  var btnCheck = document.getElementById('btnCheck'), checkMsg = document.getElementById('checkMsg');
  if (btnCheck) {
    btnCheck.addEventListener('click', function () {
      var base = <?php echo json_encode(base_url()); ?>;
      checkMsg.style.color = '#9a8fae';
      checkMsg.textContent = '检测中…';
      fetch(base + 'sitemap.xml?t=' + Date.now(), { headers: { 'Accept': 'application/xml' } })
        .then(function (r) {
          if (r.ok) {
            checkMsg.style.color = '#3fb984';
            checkMsg.textContent = '✅ 伪静态正常，静态链接可正常访问';
          } else {
            checkMsg.style.color = '#e0566b';
            checkMsg.textContent = '❌ 返回 ' + r.status + '，请先配置伪静态规则再使用静态 URL';
          }
        })
        .catch(function () {
          checkMsg.style.color = '#e0566b';
          checkMsg.textContent = '❌ 请求失败，请检查伪静态规则';
        });
    });
  }

  /* ---------- 配色自定义显隐 ---------- */
  var customBox = document.getElementById('customColors');
  if (customBox) {
    document.querySelectorAll('input[name=admin_accent]').forEach(function (r) {
      r.addEventListener('change', function () {
        customBox.style.display = this.value === 'custom' ? 'flex' : 'none';
      });
    });
  }
})();
</script>

<?php include 'includes/footer.php'; ?>
