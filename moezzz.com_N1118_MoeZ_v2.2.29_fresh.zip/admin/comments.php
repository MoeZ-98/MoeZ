<?php
/**
 * 后台 · 评论管理（通过 / 待审 / 垃圾 / 删除）
 */
require __DIR__ . '/bootstrap.php';

if (is_file(dirname(__DIR__) . '/includes/ipinfo.php')) {
    require_once dirname(__DIR__) . '/includes/ipinfo.php';
}

$active = 'comments';
$page_title = '评论管理';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (function_exists('moe_content_changed')) moe_content_changed();   // 1.9.0：内容变更 → 清理统计/导航缓存与页面缓存
    $act = $_POST['act'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    if ($act === 'delete') {
        q('DELETE FROM ' . moe_table('comments') . ' WHERE id = ?', array($id));
        flash('评论已删除');
    } elseif ($act === 'save') {
        // 站长编辑评论：作者 / 邮箱 / 内容 / 状态
        $author  = trim($_POST['author'] ?? '');
        $email   = trim($_POST['email'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $status  = in_array($_POST['status'] ?? '', array('approved', 'pending', 'spam'), true) ? $_POST['status'] : 'approved';
        if ($author === '' || $content === '') {
            flash('作者和内容不能为空', 'bad');
            redirect('comments.php?edit=' . $id);
        }
        if (function_exists('mb_substr')) {
            $author = mb_substr($author, 0, 64, 'UTF-8');
            $email  = mb_substr($email, 0, 128, 'UTF-8');
        }
        q('UPDATE ' . moe_table('comments') . ' SET author=?, email=?, content=?, status=? WHERE id=?',
            array($author, $email, $content, $status, $id));
        flash('评论已保存 ✅');
        redirect('comments.php' . (!empty($_POST['back']) ? '?' . $_POST['back'] : ''));
    } elseif (in_array($act, array('approved', 'pending', 'spam'), true)) {
        $c0 = row('SELECT c.*, p.title AS post_title FROM ' . moe_table('comments') . ' c
            LEFT JOIN ' . moe_table('posts') . ' p ON p.id = c.post_id WHERE c.id = ?', array($id));
        q('UPDATE ' . moe_table('comments') . ' SET status = ? WHERE id = ?', array($act, $id));
        // 待审核 → 通过：按后台开关给评论者发通知邮件（需对方留了邮箱且原本不是已通过状态）
        if ($act === 'approved' && $c0 && $c0['status'] !== 'approved' && function_exists('moe_notify_comment_result')) {
            $pUrl = function_exists('post_url') ? post_url(array('id' => (int)$c0['post_id'], 'slug' => '')) : base_url();
            moe_notify_comment_result((string)$c0['author'], (string)$c0['email'], (string)($c0['post_title'] ?: ''), $pUrl, (string)$c0['content']);
        }
        flash('评论状态已更新');
    } elseif ($act === 'fillloc') {
        // 补全历史评论的 IP 归属地（逐条调用查询接口，带缓存字段，只补空值）
        @set_time_limit(300);
        $n = 0;
        $todo = rows('SELECT DISTINCT ip FROM ' . moe_table('comments') . " WHERE (location = '' OR location IS NULL) AND ip <> '' LIMIT 200");
        foreach ((array)$todo as $t) {
            $loc = function_exists('moe_ip_location') ? moe_ip_location($t['ip']) : '';
            if ($loc !== '') {
                q('UPDATE ' . moe_table('comments') . ' SET location = ? WHERE ip = ? AND (location = \'\' OR location IS NULL)', array($loc, $t['ip']));
                $n++;
            }
        }
        flash($n > 0 ? "已为 {$n} 个 IP 补全归属地 🌏" : '没有需要补全的评论（或归属地查询接口暂时不可用）');
    }
    redirect('comments.php' . (!empty($_POST['back']) ? '?' . $_POST['back'] : ''));
}

$stf = $_GET['status'] ?? '';
if (!in_array($stf, array('approved', 'pending', 'spam'), true)) $stf = '';
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 15;

$where = $stf ? ' WHERE c.status = ?' : '';
$args = $stf ? array($stf) : array();
$total = (int)one('SELECT COUNT(*) FROM ' . moe_table('comments') . ' c' . $where, $args);
$offset = ($page - 1) * $per;
$comments = rows('SELECT c.*, p.title AS post_title, p.id AS pid FROM ' . moe_table('comments') . ' c
    LEFT JOIN ' . moe_table('posts') . ' p ON p.id = c.post_id' . $where .
    " ORDER BY c.id DESC LIMIT $offset, $per", $args);
$qs = $stf ? 'status=' . $stf . '&' : '';

// 编辑中的评论（?edit=ID）
$editId = (int)($_GET['edit'] ?? 0);
$editCmt = null;
if ($editId > 0) {
    $editCmt = row('SELECT c.*, p.title AS post_title FROM ' . moe_table('comments') . ' c
        LEFT JOIN ' . moe_table('posts') . ' p ON p.id = c.post_id WHERE c.id = ?', array($editId));
    if (!$editCmt) flash('评论不存在或已删除', 'bad');
}
include 'includes/header.php';
?>

<?php if ($editCmt): ?>
<div class="card">
  <h2 class="card-title">编辑评论 <span style="color:var(--muted);font-weight:400;font-size:12.5px">#<?php echo (int)$editCmt['id']; ?> · <?php echo e($editCmt['post_title'] ?: '文章已删除'); ?></span></h2>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="save">
    <input type="hidden" name="id" value="<?php echo (int)$editCmt['id']; ?>">
    <input type="hidden" name="back" value="<?php echo e($qs . 'page=' . $page); ?>">
    <div class="form-grid">
      <div class="field"><label>作者</label>
        <input type="text" name="author" value="<?php echo e($editCmt['author']); ?>" required>
      </div>
      <div class="field"><label>邮箱</label>
        <input type="text" name="email" value="<?php echo e($editCmt['email']); ?>" placeholder="不公开，仅用于头像 / 通知">
      </div>
      <div class="field"><label>状态</label>
        <select name="status">
          <option value="approved" <?php echo $editCmt['status'] === 'approved' ? 'selected' : ''; ?>>已通过（前台展示）</option>
          <option value="pending" <?php echo $editCmt['status'] === 'pending' ? 'selected' : ''; ?>>待审核</option>
          <option value="spam" <?php echo $editCmt['status'] === 'spam' ? 'selected' : ''; ?>>垃圾</option>
        </select>
      </div>
      <div class="field full"><label>评论内容</label>
        <textarea name="content" rows="6" style="width:100%;padding:11px 14px;border:1.5px solid #e8e2f0;border-radius:12px;outline:none;resize:vertical;font-family:inherit;font-size:14px;line-height:1.8"><?php echo e($editCmt['content']); ?></textarea>
        <p class="hint">保存后前台立即生效，请避免删除他人评论中的有效信息。</p>
      </div>
    </div>
    <div class="form-foot">
      <button class="btn" type="submit">💾 保存评论</button>
      <a class="btn ghost" href="comments.php<?php echo $qs ? '?' . e(rtrim($qs, '&')) : ''; ?>">取消</a>
    </div>
  </form>
</div>
<?php endif; ?>

<div class="card">
  <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:16px">
    <h2 class="card-title" style="margin:0">评论列表（<?php echo $total; ?>）</h2>
    <span style="flex:1"></span>
    <?php
    // 2.2.7：筛选改为胶囊样式（当前项高亮填充）
    // 2.2.30 优化：四个筛选胶囊的计数合并为一条条件聚合查询（4 次 SQL → 1 次）
    $cStat = row('SELECT COUNT(*) AS all_c,'
        . " SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) AS ok_c,"
        . " SUM(CASE WHEN status = 'pending'  THEN 1 ELSE 0 END) AS pd_c,"
        . " SUM(CASE WHEN status = 'spam'     THEN 1 ELSE 0 END) AS spam_c"
        . ' FROM ' . moe_table('comments'));
    $cAll = (int)(is_array($cStat) && isset($cStat['all_c'])  ? $cStat['all_c']  : 0);
    $cOk  = (int)(is_array($cStat) && isset($cStat['ok_c'])   ? $cStat['ok_c']   : 0);
    $cPd  = (int)(is_array($cStat) && isset($cStat['pd_c'])   ? $cStat['pd_c']   : 0);
    $cSp  = (int)(is_array($cStat) && isset($cStat['spam_c']) ? $cStat['spam_c'] : 0);
    $capTabs = array(
      ''        => array('全部', $cAll),
      'approved' => array('已通过', $cOk),
      'pending'  => array('待审核', $cPd),
      'spam'     => array('垃圾', $cSp),
    );
    foreach ($capTabs as $k => $v) {
      $cur = $stf === $k;
      echo '<a href="comments.php' . ($k !== '' ? '?status=' . $k : '') . '" style="padding:5px 14px;border-radius:99px;font-size:12.5px;'
        . 'text-decoration:none;white-space:nowrap;font-weight:600;'
        . ($cur ? 'background:linear-gradient(135deg,#f77fbe,#b78ff0);color:#fff;'
                : 'background:#f4effb;color:#7a6d95;border:1px solid #e8e2f0;') . '">'
        . e($v[0]) . ' ' . (int)$v[1] . '</a>';
    }
    ?>
    <form method="post" onsubmit="return confirm('逐个查询未标注归属地的评论 IP（最多 200 个）？需要几秒到几十秒。')" style="margin-left:6px">
      <?php echo csrf_field(); ?><input type="hidden" name="act" value="fillloc">
      <button class="btn sm" type="submit">🌏 补全历史归属地</button>
    </form>
  </div>

  <?php if (empty($comments)): ?>
    <p style="color:var(--muted);text-align:center;padding:30px">暂无评论～</p>
  <?php endif; ?>
  <?php foreach ($comments as $c): ?>
    <?php
    $acLoc = isset($c['location']) && $c['location'] !== '' ? $c['location']
           : (function_exists('moe_ip_private') && moe_ip_private($c['ip'] ?? '') ? '内网 / 保留地址' : '');
    $acUa = function_exists('moe_ua_info') && !empty($c['ua']) ? moe_ua_info($c['ua']) : '';
    $stLabel = array('approved' => '已通过', 'pending' => '待审核', 'spam' => '垃圾')[$c['status']] ?? $c['status'];
    ?>
    <div style="border:1px solid #e8e2f0;border-radius:15px;padding:14px 17px;margin-bottom:12px;background:#fff">
      <div style="display:flex;align-items:center;gap:9px;flex-wrap:wrap">
        <b style="font-size:13.5px;color:#4a4060"><?php echo e($c['author']); ?></b>
        <span style="font-size:11.5px;color:var(--muted)"><?php echo e($c['email'] ?: '无邮箱'); ?></span>
        <span style="flex:1"></span>
        <span style="font-size:11.5px;color:var(--muted)"><?php echo e(format_time($c['created_at'], 'm-d H:i')); ?></span>
        <span class="pill <?php echo $c['status'] === 'approved' ? 'ok' : ($c['status'] === 'pending' ? 'warn' : 'bad'); ?>"><?php echo e($stLabel); ?></span>
      </div>
      <div class="cmt-text" style="margin-top:9px;font-size:13.5px;line-height:1.75;color:#544a6b"><?php echo nl2br(e(excerpt_text($c['content'], 200))); ?></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:10px;font-size:12px;color:var(--muted)">
        <span>📄 <a href="<?php echo e(post_url(array('id' => $c['pid'], 'slug' => ''))); ?>" target="_blank" style="color:inherit"><?php echo e($c['post_title'] ?: '已删除'); ?></a></span>
        <?php if ($acLoc !== ''): ?><span>📍 <?php echo e($acLoc); ?></span><?php endif; ?>
        <?php if ($acUa !== ''): ?><span>💻 <?php echo e($acUa); ?></span><?php endif; ?>
        <?php if ($acLoc === '' && $acUa === '' && !empty($c['ip'])): ?><span><?php echo e($c['ip']); ?></span><?php endif; ?>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:11px;padding-top:10px;border-top:1px dashed #f0eaf8">
        <a class="btn ghost sm" href="comments.php?edit=<?php echo (int)$c['id']; ?><?php echo $stf ? '&status=' . e($stf) : ''; ?>&page=<?php echo (int)$page; ?>">✏️ 编辑</a>
        <?php if ($c['status'] !== 'approved'): ?>
        <form method="post">
          <?php echo csrf_field(); ?><input type="hidden" name="act" value="approved">
          <input type="hidden" name="id" value="<?php echo (int)$c['id']; ?>">
          <input type="hidden" name="back" value="<?php echo e($qs . 'page=' . $page); ?>">
          <button class="btn sm" type="submit">✔ 通过</button>
        </form>
        <?php endif; ?>
        <?php if ($c['status'] !== 'spam'): ?>
        <form method="post">
          <?php echo csrf_field(); ?><input type="hidden" name="act" value="spam">
          <input type="hidden" name="id" value="<?php echo (int)$c['id']; ?>">
          <input type="hidden" name="back" value="<?php echo e($qs . 'page=' . $page); ?>">
          <button class="btn ghost sm" type="submit">🚫 垃圾</button>
        </form>
        <?php endif; ?>
        <form method="post" onsubmit="return confirm('确定删除这条评论？')">
          <?php echo csrf_field(); ?><input type="hidden" name="act" value="delete">
          <input type="hidden" name="id" value="<?php echo (int)$c['id']; ?>">
          <input type="hidden" name="back" value="<?php echo e($qs . 'page=' . $page); ?>">
          <button class="btn danger sm" type="submit">🗑 删除</button>
        </form>
      </div>
    </div>
  <?php endforeach; ?>

  <div class="pager">
    <?php
    if ($total > $per) {
      $pages = (int)ceil($total / $per);
      for ($i = 1; $i <= $pages; $i++) {
        if ($pages > 12 && abs($i - $page) > 3 && $i > 2 && $i < $pages - 1) { if ($i === 3) echo '<span>…</span>'; continue; }
        echo $i === $page
          ? '<span class="cur">' . $i . '</span>'
          : '<a href="comments.php?' . e($qs . 'page=' . $i) . '">' . $i . '</a>';
      }
    }
    ?>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
