<?php
/**
 * 后台 · 自动检测 / 在线更新 Ajax 端点（2.0.3）
 * ------------------------------------------------------------
 * 仅站长可调用；CSRF + 角色 + 二次确认三重校验。
 * act = check            自动检测（10 分钟缓存，force=1 可强制）
 *     = save_feed        保存在线更新源
 *     = online_update    按 version.json 的 download 下载官方 zip 并覆盖
 *     = upload_update    上传本地官方 zip 覆盖包
 * 后两者共用 moe_update_apply_zip()：自动备份、失败自动回滚。
 */
define('MOE_ADMIN', true);
require dirname(__DIR__) . '/init.php';

header('Content-Type: application/json; charset=utf-8');

function upd_die($msg, $extra = array())
{
    echo json_encode(array_merge(array('ok' => 0, 'msg' => $msg), $extra), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') upd_die('请求方式不正确');
if (session_status() === PHP_SESSION_NONE) session_start();

$token = (string)($_POST['_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
if (!hash_equals((string)($_SESSION['moe_csrf'] ?? ''), $token)) upd_die('令牌校验失败，请刷新页面重试');
if (empty($_SESSION['moe_uid'])) upd_die('请先登录');
if (!function_exists('moe_is_owner') || !moe_is_owner()) upd_die('仅站长可检测与更新');
if (!function_exists('moe_update_check')) upd_die('系统模块缺失：请重新上传 includes/system.php');

$act = (string)($_POST['act'] ?? '');

/* ---------- 保存在线更新源 ---------- */
if ($act === 'save_feed') {
    $url = trim((string)($_POST['url'] ?? ''));
    if ($url !== '') {
        $err = '';
        if (!moe_update_feed_valid($url, $err)) upd_die($err);
    }
    setting_set('update_check_url', $url);
    setting_set('update_check_cache', '');
    echo json_encode(array('ok' => 1, 'msg' => $url === '' ? '已清除在线更新源，将使用随包版本清单' : '更新源已保存', 'feed' => $url),
                     JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ---------- 自动检测 ---------- */
if ($act === 'check') {
    $force = (string)($_POST['force'] ?? '') === '1';
    $r = moe_update_check($force);
    echo json_encode(array_merge(array('ok' => 1), $r), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ---------- 在线更新 / 上传包更新 ---------- */
if ($act === 'online_update' || $act === 'upload_update') {
    @set_time_limit(180);
    if ((string)($_POST['confirm'] ?? '') !== '1') upd_die('缺少二次确认，请从仪表盘点击更新按钮');

    // 脚本任何路径退出都清理临时 zip
    $tmpFile = '';
    register_shutdown_function(function () use (&$tmpFile) {
        if ($tmpFile !== '' && is_file($tmpFile)) @unlink($tmpFile);
    });

    $werr = '';
    $ws = moe_update_workspace($werr);
    if ($ws === '') upd_die($werr);
    $tmpFile = $ws . '/_tmp-' . date('Ymd-His') . '-' . substr(md5(uniqid('', true)), 0, 8) . '.zip';

    if ($act === 'online_update') {
        $r = moe_update_check(false);       // 用检测结果，避免重复请求 version.json
        $url = trim((string)($r['download'] ?? ''));
        if ($url === '') upd_die('官方未提供在线更新包地址（version.json 缺少 download 字段），请改用「📦 上传更新包」');
        $err = '';
        if (!moe_update_feed_valid($url, $err)) upd_die('更新包地址不合法：' . $err);
        $err = '';
        if (!moe_update_download($url, $tmpFile, $err)) upd_die($err);
        $origin = 'online:' . (string)parse_url($url, PHP_URL_HOST);
    } else {
        $f = isset($_FILES['zip']) && is_array($_FILES['zip']) ? $_FILES['zip'] : array();
        if (!$f) upd_die('没有收到更新包文件（若文件较大，请调高 PHP 的 upload_max_filesize / post_max_size）');
        $errno = (int)($f['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($errno !== UPLOAD_ERR_OK) {
            $map = array(
                UPLOAD_ERR_INI_SIZE   => '超过 upload_max_filesize',
                UPLOAD_ERR_FORM_SIZE  => '超过表单限制 MAX_FILE_SIZE',
                UPLOAD_ERR_PARTIAL    => '文件只上传了一部分',
                UPLOAD_ERR_NO_FILE    => '没有选择文件',
                UPLOAD_ERR_NO_TMP_DIR => '服务器缺少临时目录',
                UPLOAD_ERR_CANT_WRITE => '服务器写入临时文件失败',
            );
            upd_die('上传失败：' . (isset($map[$errno]) ? $map[$errno] : '错误码 ' . $errno));
        }
        $size = (int)($f['size'] ?? 0);
        if ($size <= 0 || $size > 30 * 1024 * 1024) upd_die('更新包需为 0～30MB 的 zip 文件');
        if (strtolower((string)pathinfo((string)($f['name'] ?? ''), PATHINFO_EXTENSION)) !== 'zip') {
            upd_die('只接受 .zip 格式的官方覆盖包');
        }
        $src = (string)($f['tmp_name'] ?? '');
        if ($src === '' || !is_uploaded_file($src)) upd_die('上传的临时文件无效');
        if (!@move_uploaded_file($src, $tmpFile) && !@copy($src, $tmpFile)) {
            upd_die('无法保存上传的更新包，请检查 content/ 写入权限');
        }
        $origin = 'upload:' . basename((string)($f['name'] ?? 'package.zip'));
    }

    $res = moe_update_apply_zip($tmpFile, $origin);
    echo json_encode($res, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ---------- 授权：保存授权码 / 授权检测 / 增量更新（2.2.0） ---------- */
if ($act === 'auth_save') {
    $hub  = rtrim(trim((string)($_POST['hub'] ?? '')), '/');
    $code = trim((string)($_POST['code'] ?? ''));
    if ($hub !== '') {
        $err = '';
        if (!moe_update_feed_valid($hub . '/update-api.php?act=verify&code=x&domain=x', $err)) {
            upd_die('授权服务器地址不合法：' . $err);
        }
    }
    if (!function_exists('moe_auth_check')) upd_die('授权模块缺失：请更新 includes/auth.php');
    setting_set('auth_hub_url', $hub);
    setting_set('auth_code', $code);
    setting_set('auth_check_cache', '');
    echo json_encode(array('ok' => 1, 'msg' => $code === '' ? '已清除授权，保存的更新源不变' : '已保存，正在验证授权…'),
                     JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($act === 'auth_check') {
    if (!function_exists('moe_auth_check')) upd_die('授权模块缺失：请更新 includes/auth.php');
    $force = (string)($_POST['force'] ?? '') === '1';
    $r = moe_auth_check($force);
    echo json_encode($r, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($act === 'auth_update_program' || $act === 'auth_update_theme' || $act === 'auth_update_plugin') {
    if (!function_exists('moe_auth_incremental_apply')) upd_die('授权模块缺失：请更新 includes/auth.php');
    @set_time_limit(300);
    $slug = trim((string)($_POST['slug'] ?? ''));
    $type = $act === 'auth_update_theme' ? 'theme' : ($act === 'auth_update_plugin' ? 'plugin' : 'program');

    // mode=zip：不走增量，直接从官方提供的直链下载整包覆盖
    // 2.2.2：主题 / 插件的直链来自官方「积分商城 → 资源」里填的下载地址（download_url）
    if ((string)($_POST['mode'] ?? '') === 'zip') {
        if ((string)($_POST['confirm'] ?? '') !== '1') upd_die('缺少二次确认，请从仪表盘点击更新按钮');
        $c = function_exists('moe_auth_check') ? moe_auth_check(false) : array();
        if (empty($c['authed'])) upd_die('授权无效或未验证，请先验证授权');

        if ($type === 'program') {
            $url = trim((string)($c['program']['download'] ?? ''));
            $dlPwd = trim((string)($c['program']['download_pwd'] ?? ''));
            if ($url === '') upd_die('官方未提供整包直链（version.json 缺少 download 字段），请使用增量更新');
        } else {
            $entry = null;
            foreach ((array)($c[$type === 'theme' ? 'themes' : 'plugins'] ?? array()) as $e2) {
                if (is_array($e2) && ($e2['dir'] ?? '') === $slug) { $entry = $e2; break; }
            }
            $url = is_array($entry) ? trim((string)($entry['download'] ?? '')) : '';
            $dlPwd = is_array($entry) ? trim((string)($entry['download_pwd'] ?? '')) : '';
            if ($url === '') {
                upd_die('官方没有为该' . ($type === 'theme' ? '主题' : '插件')
                    . '配置整包直链（官方后台「积分商城 → 资源」里填下载地址后可用），请使用增量更新');
            }
        }
        $err = '';
        if (!moe_update_feed_valid($url, $err)) upd_die('整包地址不合法：' . $err);
        $werr = '';
        $ws = moe_update_workspace($werr);
        if ($ws === '') upd_die($werr);
        $tmp = $ws . '/_tmp-' . date('Ymd-His') . '-' . substr(md5(uniqid('', true)), 0, 8) . '.zip';
        register_shutdown_function(function () use ($tmp) { if (is_file($tmp)) @unlink($tmp); });
        $err = '';
        if (!moe_update_download($url, $tmp, $err, array('pwd' => $dlPwd))) upd_die($err);
        if ($type === 'program') {
            $res = moe_update_apply_zip($tmp, 'hub-zip:' . (string)parse_url($url, PHP_URL_HOST));
        } else {
            if (!function_exists('moe_auth_zip_apply')) upd_die('授权模块缺失：请更新 includes/auth.php');
            $res = moe_auth_zip_apply($tmp, $type, $slug, 'hub-goods-zip');
        }
        echo json_encode($res, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $res = moe_auth_incremental_apply($type, $slug, (string)($_POST['confirm'] ?? ''));
    echo json_encode($res, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ---------- 授权站：站点档案 / 状态管控 / 违规邮件提醒（2.2.1） ---------- */
if (!function_exists('moe_hub_sites_file')) {
    /** 授权站点档案：content/updates/auth-sites.json（含状态 / 邮箱 / 备注） */
    function moe_hub_sites_load()
    {
        $f = MOE_ROOT . '/content/updates/auth-sites.json';
        $j = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
        return is_array($j) ? $j : array();
    }
    function moe_hub_sites_save($sites)
    {
        $f = MOE_ROOT . '/content/updates/auth-sites.json';
        if (!is_dir(dirname($f))) @mkdir(dirname($f), 0755, true);
        @file_put_contents($f, json_encode(array_values($sites), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), LOCK_EX);
    }
}

if ($act === 'hub_issue') {
    if (!function_exists('moe_auth_code_generate')) upd_die('授权模块缺失：请更新 includes/auth.php');
    $domain = trim((string)($_POST['domain'] ?? ''));
    $days   = (int)($_POST['days'] ?? 0);          // 0 = 永久授权
    $note   = trim((string)($_POST['note'] ?? ''));
    $email  = trim((string)($_POST['email'] ?? ''));
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) upd_die('站长邮箱格式不正确');
    $r = moe_auth_code_generate($domain, $days, (string)setting('update_hub_secret', ''));
    if (empty($r['ok'])) upd_die($r['msg']);
    // 站点档案（授权记录 + 状态管控 + 违规提醒收件邮箱）
    $sites = moe_hub_sites_load();
    $tail = substr($r['code'], -8);
    $found = false;
    foreach ($sites as $i => $s) {
        if (is_array($s) && (($s['tail'] ?? '') === $tail || ($s['domain'] ?? '') === $r['domain'])) {
            $sites[$i] = array_merge($sites[$i], array('tail' => $tail, 'domain' => $r['domain'],
                'email' => $email, 'expire' => $r['expire'], 'note' => $note,
                'status' => 'ok', 'status_note' => '', 'issued_at' => date('Y-m-d H:i:s')));
            $found = true; break;
        }
    }
    if (!$found) {
        array_unshift($sites, array('tail' => $tail, 'domain' => $r['domain'], 'email' => $email,
            'expire' => $r['expire'], 'note' => $note, 'status' => 'ok', 'status_note' => '',
            'issued_at' => date('Y-m-d H:i:s')));
    }
    if (count($sites) > 500) $sites = array_slice($sites, 0, 500);
    moe_hub_sites_save($sites);
    echo json_encode(array('ok' => 1, 'code' => $r['code'], 'domain' => $r['domain'], 'expire' => $r['expire']),
                     JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($act === 'hub_sites') {
    echo json_encode(array('ok' => 1, 'sites' => array_values(moe_hub_sites_load())),
                     JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($act === 'hub_site_status') {
    $tail = trim((string)($_POST['tail'] ?? ''));
    $status = (string)($_POST['status'] ?? '');
    $note = trim((string)($_POST['note'] ?? ''));
    if (!in_array($status, array('ok', 'warn', 'banned'), true)) upd_die('状态值不合法');
    $sites = moe_hub_sites_load();
    $found = false;
    foreach ($sites as $i => $s) {
        if (is_array($s) && ($s['tail'] ?? '') === $tail) {
            $sites[$i]['status'] = $status;
            $sites[$i]['status_note'] = $note;
            $sites[$i]['status_at'] = date('Y-m-d H:i:s');
            $found = true; break;
        }
    }
    if (!$found) upd_die('没有找到该授权站点，请重新发放或核对记录');
    moe_hub_sites_save($sites);
    $label = array('ok' => '已恢复授权与更新服务', 'warn' => '已标记待整改（客户端会显示警告横幅）', 'banned' => '已下架：该站点将无法验证授权与更新');
    echo json_encode(array('ok' => 1, 'msg' => $label[$status]), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($act === 'hub_remind') {
    $tail = trim((string)($_POST['tail'] ?? ''));
    $note = trim((string)($_POST['note'] ?? ''));
    $sites = moe_hub_sites_load();
    $site = null;
    foreach ($sites as $s) {
        if (is_array($s) && ($s['tail'] ?? '') === $tail) { $site = $s; break; }
    }
    if (!$site) upd_die('没有找到该授权站点');
    $email = trim((string)($site['email'] ?? ''));
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        upd_die('该站点没有登记站长邮箱，发放授权码时请填写「站长邮箱」后再提醒');
    }
    if (!function_exists('moe_mail_send')) upd_die('邮件模块缺失：请更新 includes/mail.php');
    $domain = (string)($site['domain'] ?? '');
    $lines = array(
        '站点：' . $domain,
        '提醒内容：' . ($note !== '' ? $note : '你的站点被举报或检测到疑似违规内容（如违法信息、色情低俗等），请立即自查整改。'),
        '处理方式：请于 72 小时内完成整改并回复本邮件说明情况。',
        '逾期后果：未按期整改，官方将直接下架该站点的授权，停止程序与主题 / 插件的更新服务。',
    );
    $html = function_exists('moe_mail_template') ? moe_mail_template('授权违规整改提醒', $lines) : '<p>' . implode('<br>', $lines) . '</p>';
    $r = moe_mail_send($email, '【重要】授权违规整改提醒 · ' . $domain, $html);
    if (empty($r['ok'])) upd_die('邮件发送失败：' . (string)($r['msg'] ?? '未知错误'));
    // 同步把站点标记为待整改
    foreach ($sites as $i => $s) {
        if (($s['tail'] ?? '') === $tail) {
            $sites[$i]['status'] = 'warn';
            $sites[$i]['status_note'] = $note !== '' ? $note : '已邮件提醒整改';
            $sites[$i]['status_at'] = date('Y-m-d H:i:s');
            break;
        }
    }
    moe_hub_sites_save($sites);
    echo json_encode(array('ok' => 1, 'msg' => '提醒邮件已发送至 ' . $email . '，站点已标记为「待整改」'),
                     JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ---------- 授权站（官方主站）：初始化密钥 / 发放授权码 ---------- */
if ($act === 'hub_init') {
    $secret = trim((string)setting('update_hub_secret', ''));
    if ($secret === '') {
        $secret = bin2hex(function_exists('random_bytes') ? random_bytes(32) : md5(uniqid('', true) . mt_rand()));
        setting_set('update_hub_secret', $secret);
        setting_set('update_hub_since', date('Y-m-d H:i:s'));
    }
    echo json_encode(array('ok' => 1, 'msg' => '授权服务已就绪：根目录 update-api.php 现在可对外提供授权验证与增量更新'),
                     JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ---------- 删除本地主题 / 插件（2.2.2） ---------- */
if ($act === 'auth_delete_theme') {
    $slug = preg_replace('/[^a-zA-Z0-9_-]/', '', trim((string)($_POST['slug'] ?? '')));
    if ($slug === '') upd_die('主题目录名不合法');
    $dir = MOE_ROOT . '/templates/' . $slug;
    if (!is_file($dir . '/info.php')) upd_die('本地没有该主题：' . $slug);
    if (function_exists('theme') && theme() === $slug) upd_die('该主题正在使用中，请先到「模板管理」切换其他主题后再删除');
    // 先整目录搬进 content/backups/ 再算删除成功：误删可随时找回
    $werr = '';
    $ws = function_exists('moe_update_workspace') ? moe_update_workspace($werr) : '';
    if ($ws === '') upd_die($werr);
    $dest = $ws . '/del-' . date('Ymd-His') . '-' . $slug;
    if (!@rename($dir, $dest)) upd_die('删除失败：无法移动主题目录（权限？），主题未被改动');
    echo json_encode(array('ok' => 1, 'msg' => '主题「' . $slug . '」已删除，原文件备份在 content/backups/' . basename($dest) . '（误删可找回）'),
                     JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($act === 'auth_delete_plugin') {
    $slug = trim((string)($_POST['slug'] ?? ''));
    if (!function_exists('moe_plugin_id_valid') || !moe_plugin_id_valid($slug)) upd_die('插件 ID 不合法');
    if (!is_dir(moe_plugins_dir() . '/' . $slug)) upd_die('本地没有该插件：' . $slug);
    // 删除前先停用，避免残留启用配置
    if (function_exists('moe_plugins_enabled') && function_exists('moe_plugins_set_enabled')) {
        moe_plugins_set_enabled(array_values(array_diff((array)moe_plugins_enabled(), array($slug))));
    }
    $ok = function_exists('moe_plugin_remove_dir') ? moe_plugin_remove_dir(moe_plugins_dir() . '/' . $slug) : false;
    if (!$ok) upd_die('删除失败，请检查 content/plugins/ 目录权限');
    if (function_exists('moe_content_changed')) moe_content_changed();
    echo json_encode(array('ok' => 1, 'msg' => '插件「' . $slug . '」已删除（同时已停用）'),
                     JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

upd_die('未知操作');
