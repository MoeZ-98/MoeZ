<?php
/**
 * 后台 · 文章管理
 */
require __DIR__ . '/bootstrap.php';
$active = 'posts';
$page_title = '文章管理';

/* ---- 操作 ---- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (function_exists('moe_content_changed')) moe_content_changed();   // 1.9.0：内容变更 → 清理统计/导航缓存与页面缓存
    $act = $_POST['act'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    if ($act === 'delete') {
        // 1.8.4：删除前先收集文章引用的本站附件，删除后按「是否随文章删附件」清理
        $withFiles = !empty($_POST['with_files']);
        $assets = array();
        try {
            foreach (rows('SELECT content, cover FROM ' . moe_table('posts') . ' WHERE id = ?', array($id)) as $r) {
                foreach (moe_extract_upload_paths((string)$r['content'] . ' ' . (string)$r['cover']) as $ap) $assets[$ap] = true;
            }
        } catch (Throwable $e) {}
        // 删除前记住所属分类，删除后把该分类的编号重排为连续序号（补掉空号）
        $delCat = 0;
        try { $delCat = (int)one('SELECT category_id FROM ' . moe_table('posts') . ' WHERE id = ?', array($id)); } catch (Throwable $e) {}
        q('DELETE FROM ' . moe_table('posts') . " WHERE id = ? AND type='post'", array($id));
        q('DELETE FROM ' . moe_table('comments') . ' WHERE post_id = ?', array($id));
        $fixed = function_exists('moe_reindex_cat_nums') ? moe_reindex_cat_nums($delCat) : 0;
        $msg = $fixed > 0 ? "文章已删除，同分类 {$fixed} 篇文章的编号已自动补全 🔢" : '文章已删除';
        if (!empty($assets) && function_exists('moe_post_assets_cleanup')) {
            list($rm, $kp) = moe_post_assets_cleanup(array_keys($assets), $withFiles);
            if ($rm > 0) $msg .= '；已一并删除 ' . $rm . ' 个不再使用的图片/附件 🧹';
            if ($kp > 0) $msg .= '；' . $kp . ' 个图片/附件已保留，可在「资源管理」中查看或删除';
        }
        flash($msg);
    } elseif ($act === 'toggle_status') {
        $p = row('SELECT status FROM ' . moe_table('posts') . ' WHERE id = ?', array($id));
        if ($p) {
            $new = $p['status'] === 'published' ? 'draft' : 'published';
            q('UPDATE ' . moe_table('posts') . ' SET status = ? WHERE id = ?', array($new, $id));
            flash($new === 'published' ? '文章已发布' : '文章已转为草稿');
        }
    } elseif ($act === 'review') {
        // 2.2.22：用户中心投稿审核 —— 通过则发布并联动商城商品上架，退回则转草稿，均发邮件通知作者
        $pass = (string)($_POST['decision'] ?? '') === 'pass';
        $p = row('SELECT id, title, user_id FROM ' . moe_table('posts') . ' WHERE id = ?', array($id));
        if ($p) {
            $new = $pass ? 'published' : 'draft';
            q('UPDATE ' . moe_table('posts') . ' SET status = ?, updated_at = ? WHERE id = ?',
                array($new, date('Y-m-d H:i:s'), $id));
            // 投稿时若附带资源，商城商品先以 off 状态挂着，通过审核才上架
            $goods = 0;
            try {
                $goods = (int)one('SELECT COUNT(*) FROM ' . moe_table('pt_goods') . ' WHERE post_id = ?', array($id));
                if ($goods > 0) {
                    q('UPDATE ' . moe_table('pt_goods') . ' SET status = ?, updated_at = ? WHERE post_id = ?',
                        array($pass ? 'on' : 'off', date('Y-m-d H:i:s'), $id));
                }
            } catch (Throwable $e) { /* 未开启商城 */ }
            if (function_exists('moe_uc_contribute_notify')) {
                moe_uc_contribute_notify((string)$p['title'], (int)$p['user_id'], $pass);
            }
            $msg = $pass ? '投稿已通过并发布 🎉' : '投稿已退回（转存为草稿）';
            if ($pass && $goods > 0) $msg .= '，关联资源已同步上架积分商城 🛒';
            if (function_exists('moe_mail_ready') && !moe_mail_ready()) $msg .= '；邮件服务未配置，通知未发出';
            flash($msg, $pass ? 'ok' : 'warn');
        }
    } elseif ($act === 'toggle_top') {
        q('UPDATE ' . moe_table('posts') . ' SET is_top = 1 - is_top WHERE id = ?', array($id));
        flash('置顶状态已更新');
    } elseif ($act === 'clean_drafts') {
        // 清理旧版遗留的「编辑草稿」副本（draft_of 指向原文），原文与新自动草稿均不受影响
        try {
            $n = (int)one('SELECT COUNT(*) FROM ' . moe_table('posts') . " WHERE type='post' AND status='draft' AND draft_of > 0");
            q('DELETE FROM ' . moe_table('posts') . " WHERE type='post' AND status='draft' AND draft_of > 0");
            flash($n > 0 ? "已清理 {$n} 份历史编辑草稿 🧹" : '没有需要清理的编辑草稿');
        } catch (Throwable $e) {
            flash('清理失败：' . $e->getMessage(), 'bad');
        }
    } elseif ($act === 'batch_delete') {
        // 批量删除：只删文章与它的评论，删后把涉及分类的编号重排补空号；1.8.4 支持随删附件
        $ids = array();
        foreach ((array)($_POST['ids'] ?? array()) as $v) { $v = (int)$v; if ($v > 0) $ids[] = $v; }
        if (empty($ids)) {
            flash('请先勾选要删除的文章', 'bad');
        } else {
            $withFiles = !empty($_POST['with_files']);
            $pt = moe_table('posts');
            $in = implode(',', array_fill(0, count($ids), '?'));
            $assets = array();
            try {
                foreach (rows('SELECT content, cover FROM ' . $pt . " WHERE type='post' AND id IN ($in)", $ids) as $r) {
                    foreach (moe_extract_upload_paths((string)$r['content'] . ' ' . (string)$r['cover']) as $ap) $assets[$ap] = true;
                }
            } catch (Throwable $e) {}
            $delCats = array();
            try {
                foreach (rows('SELECT DISTINCT category_id FROM ' . $pt . " WHERE type='post' AND id IN ($in)", $ids) as $r) {
                    $delCats[] = (int)$r['category_id'];
                }
            } catch (Throwable $e) {}
            q('DELETE FROM ' . $pt . " WHERE type='post' AND id IN ($in)", $ids);
            q('DELETE FROM ' . moe_table('comments') . " WHERE post_id IN ($in)", $ids);
            $fixed = 0;
            if (function_exists('moe_reindex_cat_nums')) {
                foreach ($delCats as $cid) $fixed += (int)moe_reindex_cat_nums($cid);
            }
            $msg = '已批量删除 ' . count($ids) . ' 篇文章 🗑' . ($fixed > 0 ? '，相关分类 ' . $fixed . ' 篇编号已补全' : '');
            if (!empty($assets) && function_exists('moe_post_assets_cleanup')) {
                list($rm, $kp) = moe_post_assets_cleanup(array_keys($assets), $withFiles);
                if ($rm > 0) $msg .= '；已一并删除 ' . $rm . ' 个不再使用的图片/附件 🧹';
                if ($kp > 0) $msg .= '；' . $kp . ' 个图片/附件已保留，可在「资源管理」中查看或删除';
            }
            flash($msg);
        }
    }
    redirect('posts.php' . (isset($_POST['back']) ? '?' . $_POST['back'] : ''));
}

/* ---- 列表与筛选 ---- */
$kw = trim($_GET['q'] ?? '');
$catf = (int)($_GET['cat'] ?? 0);
$stf = $_GET['status'] ?? '';
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 12;

$where = " WHERE p.type='post'";
$args = array();
if ($kw !== '') { $where .= ' AND p.title LIKE ?'; $args[] = '%' . $kw . '%'; }
if ($catf) { $where .= ' AND p.category_id = ?'; $args[] = $catf; }
if (in_array($stf, array('published', 'draft', 'pending'), true)) { $where .= ' AND p.status = ?'; $args[] = $stf; }

$total = (int)one('SELECT COUNT(*) FROM ' . moe_table('posts') . ' p' . $where, $args);
$offset = ($page - 1) * $per;
$posts = rows('SELECT p.*, c.name AS cat_name FROM ' . moe_table('posts') . ' p
    LEFT JOIN ' . moe_table('categories') . ' c ON c.id = p.category_id' . $where .
    " ORDER BY p.is_top DESC, p.id DESC LIMIT $offset, $per", $args);
$cats = rows('SELECT * FROM ' . moe_table('categories') . ' ORDER BY sort, id');

// 2.0.0：作者映射（一次查询，避免列表里逐篇查用户）
$__authors = array();
try {
    foreach (rows('SELECT id, username, nickname FROM ' . moe_table('users')) as $__au) {
        $__n = trim((string)($__au['nickname'] ?? ''));
        $__authors[(int)$__au['id']] = $__n !== '' ? $__n : (string)$__au['username'];
    }
} catch (Throwable $e) { $__authors = array(); }

// 旧版遗留的「编辑草稿」副本数量（新版不再生成，提供一键清理）
$legacyCopies = 0;
try { $legacyCopies = (int)one('SELECT COUNT(*) FROM ' . moe_table('posts') . " WHERE type='post' AND status='draft' AND draft_of > 0"); } catch (Throwable $e) {}
// 2.2.22：用户中心投稿待审核数量
$pendCount = 0;
try { $pendCount = (int)one('SELECT COUNT(*) FROM ' . moe_table('posts') . " WHERE type='post' AND status='pending'"); } catch (Throwable $e) {}
$qs = http_build_query(array_filter(array('q' => $kw, 'cat' => $catf, 'status' => $stf)));
include 'includes/header.php';
?>

<div class="card">
  <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:18px">
    <h2 class="card-title" style="margin:0">文章列表（<?php echo $total; ?>）</h2>
    <span style="flex:1"></span>
    <form method="post" id="batchForm" style="display:inline"
          onsubmit="var n=document.querySelectorAll('input.rowSel:checked').length; if(!n){alert('请先勾选要删除的文章');return false;} if(!confirm('确定删除选中的 '+n+' 篇文章吗？该操作不可恢复！'))return false; var d=confirm('是否同时删除这些文章里的图片和附件？\n\n【确定】= 一并删除不再被其他文章使用的附件\n【取消】= 仅删除文章，附件保留（可在「资源管理」中管理）'); if(d){var h=document.createElement('input');h.type='hidden';h.name='with_files';h.value='1';this.appendChild(h);} return true;">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="act" value="batch_delete">
      <input type="hidden" name="back" value="<?php echo e($qs ? $qs . '&page=' . $page : 'page=' . $page); ?>">
      <button class="btn danger" type="submit">🗑 批量删除</button>
    </form>
    <?php if ($legacyCopies > 0): ?>
    <form method="post" style="display:inline" onsubmit="return confirm('将删除 <?php echo $legacyCopies; ?> 份历史「编辑草稿」副本，原文不受影响，确认清理？')">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="act" value="clean_drafts">
      <button class="btn ghost" type="submit">🧹 清理编辑草稿（<?php echo $legacyCopies; ?>）</button>
    </form>
    <?php endif; ?>
    <a class="btn" href="post-edit.php">＋ 发布新文章</a>
  </div>

  <p class="hint" style="margin:-10px 0 16px">未发布的文章空闲 5 分钟会自动保存为草稿（同一篇只保留一份），在下方列表里以「草稿」标识显示，点标题即可继续编辑；文章发布后不再生成草稿。</p>

  <?php if ($pendCount > 0): ?>
  <div class="alert warn" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
    <span>📝 有 <b><?php echo $pendCount; ?></b> 篇用户投稿等待审核，审核通过后会自动发布并邮件通知作者。</span>
    <span style="flex:1"></span>
    <a class="btn sm" href="posts.php?status=pending">立即审核 →</a>
  </div>
  <?php endif; ?>

  <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px">
    <input type="text" name="q" placeholder="搜索标题…" value="<?php echo e($kw); ?>"
           style="padding:8px 13px;border:1.5px solid #e8e2f0;border-radius:10px;outline:none">
    <select name="cat" style="padding:8px 13px;border:1.5px solid #e8e2f0;border-radius:10px;background:#fff">
      <option value="0">全部分类</option>
      <?php foreach ($cats as $c): ?>
        <option value="<?php echo (int)$c['id']; ?>" <?php echo $catf == $c['id'] ? 'selected' : ''; ?>><?php echo e($c['name']); ?></option>
      <?php endforeach; ?>
    </select>
    <select name="status" style="padding:8px 13px;border:1.5px solid #e8e2f0;border-radius:10px;background:#fff">
      <option value="">全部状态</option>
      <option value="published" <?php echo $stf === 'published' ? 'selected' : ''; ?>>已发布</option>
      <option value="draft" <?php echo $stf === 'draft' ? 'selected' : ''; ?>>草稿</option>
      <option value="pending" <?php echo $stf === 'pending' ? 'selected' : ''; ?>>待审核投稿<?php echo $pendCount > 0 ? '（' . $pendCount . '）' : ''; ?></option>
    </select>
    <button class="btn ghost" type="submit">筛选</button>
  </form>

  <div class="table-wrap">
    <table class="tbl">
      <thead><tr><th style="width:34px"><input type="checkbox" id="selAll" form="batchForm" title="全选 / 取消全选"></th><th>标题</th><th>分类</th><th>作者</th><th>浏览</th><th>状态</th><th>发布时间</th><th>操作</th></tr></thead>
      <tbody>
      <?php if (empty($posts)): ?><tr><td colspan="8" style="color:var(--muted);text-align:center;padding:30px">没有找到文章～</td></tr><?php endif; ?>
      <?php foreach ($posts as $p): ?>
        <tr>
          <td><input type="checkbox" class="rowSel" name="ids[]" value="<?php echo (int)$p['id']; ?>" form="batchForm"></td>
          <td class="t-title">
            <a href="post-edit.php?id=<?php echo (int)$p['id']; ?>"><?php echo e($p['title']); ?></a>
            <?php if ($p['is_top']): ?><span class="pill violet">置顶</span><?php endif; ?>
            <?php if (($p['src'] ?? '') === 'contribute'): ?><span class="pill src" style="margin-left:6px" title="来自用户中心投稿">投稿</span><?php endif; ?>
            <?php if (!empty($p['draft_of'])): ?><span class="pill warn" style="margin-left:6px" title="自动保存的编辑草稿：打开后保存会合并回原文">编辑草稿</span><?php endif; ?>
            <?php if (!empty($p['auto_draft'])): ?><span class="pill" style="margin-left:6px;background:#efeaff;color:#7c5cbf" title="系统自动保存的草稿（全局只保留一篇，文章发布后自动清除）">自动草稿</span><?php endif; ?>
          </td>
          <td><?php echo $p['cat_name'] ? e($p['cat_name']) : '—'; ?></td>
          <td style="font-size:12.5px"><?php
            $__uid = (int)($p['user_id'] ?? 0);
            $__an  = $__uid > 0 && isset($__authors[$__uid]) ? $__authors[$__uid] : '—';
            echo $__uid > 0 && $__an !== '—'
                ? '<a href="' . e(base_url() . 'author/' . $__uid) . '" target="_blank" style="color:var(--violet)">' . e($__an) . '</a>'
                : e($__an);
          ?></td>
          <td><?php echo (int)$p['views']; ?></td>
          <td>
            <?php if ($p['status'] === 'pending'): ?>
              <span class="pill warn" title="用户中心投稿，等待站长审核">待审核</span>
            <?php else: ?>
            <form method="post" style="display:inline">
              <?php echo csrf_field(); ?><input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
              <input type="hidden" name="back" value="<?php echo e($qs ? $qs . '&page=' . $page : 'page=' . $page); ?>">
              <button class="pill <?php echo $p['status'] === 'published' ? 'ok' : 'warn'; ?>" name="act" value="toggle_status"
                      style="border:0;cursor:pointer" title="点击切换状态">
                <?php echo $p['status'] === 'published' ? '已发布' : '草稿'; ?>
              </button>
            </form>
            <?php endif; ?>
          </td>
          <td style="color:var(--muted);font-size:12.5px"><?php echo e(format_time($p['created_at'], 'Y-m-d H:i')); ?></td>
          <td>
            <div class="acts">
              <?php if ($p['status'] === 'pending'): ?>
              <form method="post" onsubmit="return confirm('通过审核？文章将立即公开发布，作者会收到邮件通知。')">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="review">
                <input type="hidden" name="decision" value="pass">
                <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                <input type="hidden" name="back" value="<?php echo e($qs ? $qs . '&page=' . $page : 'page=' . $page); ?>">
                <button class="btn sm" type="submit">✅ 通过</button>
              </form>
              <form method="post" onsubmit="return confirm('退回这篇投稿？会转为草稿并邮件通知作者修改。')">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="review">
                <input type="hidden" name="decision" value="reject">
                <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                <input type="hidden" name="back" value="<?php echo e($qs ? $qs . '&page=' . $page : 'page=' . $page); ?>">
                <button class="btn ghost sm" type="submit">↩ 退回</button>
              </form>
              <?php endif; ?>
              <?php if ($p['status'] !== 'pending'): ?>
              <a class="btn ghost sm" href="<?php echo e(post_url($p)); ?>" target="_blank">预览</a>
              <?php endif; ?>
              <a class="btn sm" href="post-edit.php?id=<?php echo (int)$p['id']; ?>">编辑</a>
              <form method="post" onsubmit="if(!confirm('确定删除这篇文章吗？该操作不可恢复！'))return false; var d=confirm('是否同时删除文章里的图片和附件？\n\n【确定】= 一并删除不再被其他文章使用的附件\n【取消】= 仅删除文章，附件保留（可在「资源管理」中管理）'); if(d){var h=document.createElement('input');h.type='hidden';h.name='with_files';h.value='1';this.appendChild(h);} return true;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="delete">
                <input type="hidden" name="id" value="<?php echo (int)$p['id']; ?>">
                <input type="hidden" name="back" value="<?php echo e($qs ? $qs . '&page=' . $page : 'page=' . $page); ?>">
                <button class="btn danger sm" type="submit">删除</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <script>
  (function () {
    var all = document.getElementById('selAll');
    var boxes = Array.prototype.slice.call(document.querySelectorAll('input.rowSel'));
    if (!all || !boxes.length) return;
    all.addEventListener('change', function () {
      boxes.forEach(function (b) { b.checked = all.checked; });
    });
    boxes.forEach(function (b) {
      b.addEventListener('change', function () {
        all.checked = boxes.every(function (x) { return x.checked; });
      });
    });
  })();
  </script>

  <div class="pager">
    <?php
    if ($total > $per) {
      $pages = (int)ceil($total / $per);
      for ($i = 1; $i <= $pages; $i++) {
        if ($pages > 12 && abs($i - $page) > 3 && $i > 2 && $i < $pages - 1) { if ($i === 3) echo '<span>…</span>'; continue; }
        echo $i === $page
          ? '<span class="cur">' . $i . '</span>'
          : '<a href="posts.php?' . e($qs . ($qs ? '&' : '') . 'page=' . $i) . '">' . $i . '</a>';
      }
    }
    ?>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
