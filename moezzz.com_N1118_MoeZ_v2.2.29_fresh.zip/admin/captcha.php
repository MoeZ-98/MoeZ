<?php
/**
 * 后台登录 · 图形验证码（1.8.0）
 * GD 生成 4 位字符验证码（去掉易混淆的 0/O/1/I/l），存入 Session。
 * 开关：后台 → 站点设置 → 邮箱与登录 → 登录验证码
 */
define('MOE_ADMIN', true);
require dirname(__DIR__) . '/init.php';

if (setting('login_captcha', '0') !== '1') {
    http_response_code(404);
    exit('验证码未开启');
}

// 验证码字符集（去除易混淆字符）
$pool = '23456789ABCDEFGHJKMNPQRSTUVWXYZ';
$len = function_exists('mb_strlen') ? mb_strlen($pool, 'UTF-8') : strlen($pool);
$code = '';
for ($i = 0; $i < 4; $i++) {
    $code .= $pool[random_int(0, $len - 1)];
}
$_SESSION['moe_captcha'] = $code;

// 打乱字符颜色
$colors = array(
    array(168, 120, 200),  // 紫
    array(236, 100, 140),  // 粉红
    array(90, 150, 220),   // 蓝
    array(70, 170, 140),   // 青
);
$bgColor = array(240, 236, 248);

if (!function_exists('imagecreatetruecolor')) {
    // 无 GD：降级为纯文本（极少见，宝塔 PHP 默认带 GD）
    header('Content-Type: text/plain; charset=utf-8');
    echo 'IMG:' . $code;
    exit;
}

$w = 150; $h = 46;
$img = imagecreatetruecolor($w, $h);

// 背景：淡紫 → 白 的渐变
$c = imagecolorallocate($img, $bgColor[0], $bgColor[1], $bgColor[2]);
imagefill($img, 0, 0, $c);
for ($x = 0; $x < $w; $x++) {
    $t = $x / $w;
    $line = imagecolorallocate(
        $img,
        (int)($bgColor[0] + (255 - $bgColor[0]) * $t),
        (int)($bgColor[1] + (255 - $bgColor[1]) * $t),
        (int)($bgColor[2] + (255 - $bgColor[2]) * $t)
    );
    imageline($img, $x, 0, $x, $h, $line);
}

// 干扰线 + 噪点
for ($i = 0; $i < 4; $i++) {
    $nc = imagecolorallocate($img, random_int(140, 200), random_int(120, 190), random_int(160, 220));
    imageline($img, random_int(0, $w), random_int(0, $h), random_int(0, $w), random_int(0, $h), $nc);
}
for ($i = 0; $i < 260; $i++) {
    $nc = imagecolorallocate($img, random_int(120, 220), random_int(110, 210), random_int(130, 230));
    imagesetpixel($img, random_int(0, $w - 1), random_int(0, $h - 1), $nc);
}

// 字符：优先 TTF 字体（Windows 自带 Arial / 宋体），否则用内置点阵
$drawn = false;
$fontCandidates = array(
    'C:/Windows/Fonts/arial.ttf',
    'C:/Windows/Fonts/Arial.ttf',
    'C:/Windows/Fonts/verdana.ttf',
    '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
    '/usr/share/fonts/dejavu/DejaVuSans.ttf',
);
foreach ($fontCandidates as $font) {
    if (is_file($font)) {
        for ($i = 0; $i < 4; $i++) {
            $ch = $code[$i];
            $col = $colors[array_rand($colors)];
            $cc = imagecolorallocate($img, $col[0], $col[1], $col[2]);
            $x = 14 + $i * 32 + random_int(-2, 2);
            $y = 12 + random_int(0, 6);
            @imagettftext($img, 21, random_int(-14, 14), $x, $y + 20, $cc, $font, $ch);
        }
        $drawn = true;
        break;
    }
}
if (!$drawn) {
    // 内置点阵放大绘制
    for ($i = 0; $i < 4; $i++) {
        $ch = $code[$i];
        $col = $colors[$i % count($colors)];
        $cc = imagecolorallocate($img, $col[0], $col[1], $col[2]);
        imagestring($img, 5, 18 + $i * 30, random_int(8, 18), $ch, $cc);
    }
}

header('Content-Type: image/png');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
imagepng($img);
imagedestroy($img);
