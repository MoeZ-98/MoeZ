<?php
/**
 * 后台 · 仪表盘
 * ------------------------------------------------------------
 * 2.0.3：按需求移除「最新文章 / 最新评论 / 蜘蛛来访（含最近抓取）/
 *        阅读排行 Top 8」四组卡片，连同对应的 7 条统计 SQL 一并删除；
 *        仪表盘保留欢迎横幅 + 四个统计数字 + 软件信息（含插件钩子）。
 *        软件信息升级为「自动检测 + 在线更新」：进页面自动检测，
 *        可一键下载官方 zip 覆盖，也可上传本地 zip 包更新，
 *        覆盖前自动备份、失败自动回滚（实现见 includes/system.php）。
 */
require __DIR__ . '/bootstrap.php';
$active = 'index';
$page_title = '仪表盘';

// 2.0.3：只保留顶部四个数字需要的查询
$stats = site_stats();
$stats['drafts'] = (int)one('SELECT COUNT(*) FROM ' . moe_table('posts') . " WHERE status='draft'");
$stats['views']  = (int)one('SELECT COALESCE(SUM(views),0) FROM ' . moe_table('posts'));
$me = current_user();

// 顶部横幅祝福语（不再弹窗）：站点设置 → 品牌与外观 可开关 / 自定义文案
unset($_SESSION['moe_welcome']);   // 兼容旧版登录标记，直接清理
$heroLine = setting('welcome_enabled', '1') === '1'
    ? moe_welcome_line()
    : '今天也是元气满满的一天，要写点什么记录下来呢？';

// 软件信息 / 自动检测首屏结果（只读 10 分钟缓存，不联网，避免拖慢仪表盘）
$sysInfo   = function_exists('moe_system_info') ? moe_system_info() : array();
$updCached = function_exists('moe_update_cached') ? moe_update_cached() : array();

/* ============================================================
 * 2.2.20 · 安全自检 + AI 辅助审计（站长专属）
 * 本地静态检查一键跑完，AI 深度分析复用后台配置的大模型
 * ============================================================ */
if (!function_exists('moe_security_scan')) {
function moe_security_scan()
{
    $root = dirname(__DIR__);
    $items = array();   // array(level, title, detail)  level: ok|warn|bad

    // ① 安装脚本残留
    $items[] = array(is_file($root . '/install.php') ? 'bad' : 'ok',
        is_file($root . '/install.php') ? 'install.php 安装脚本仍然存在' : '安装脚本已移除',
        is_file($root . '/install.php') ? '任何人都可以访问 /install.php 重装并接管你的站点！请立即删除或改名。' : '');

    // ② 诊断脚本公开暴露
    $diag = array('tools/diag.php', 'tools/selfcheck.php', 'tools/_ping_tmp.php');
    $exposed = array();
    foreach ($diag as $d) if (is_file($root . '/' . $d)) $exposed[] = '/' . $d;
    $items[] = array($exposed ? 'warn' : 'ok',
        $exposed ? '诊断脚本公开可访问：' . implode('、', $exposed) : '诊断脚本无残留',
        $exposed ? '诊断页会泄露服务器路径 / PHP 配置等信息，建议删除或加后台鉴权。' : '');

    // ③ config.php 权限与备份残留
    $cfg = $root . '/config.php';
    if (is_file($cfg)) {
        $perm = substr(sprintf('%o', fileperms($cfg)), -4);
        $items[] = array($perm === '0777' || $perm === '0666' ? 'warn' : 'ok',
            'config.php 权限 ' . $perm,
            $perm === '0777' || $perm === '0666' ? '全局可写太宽松，建议 644（仅属主可写）。' : '');
    }
    $baks = array();
    foreach (array('config.php.bak', 'config.php~', 'config.bak', 'config.old', 'config.txt') as $b) {
        if (is_file($root . '/' . $b)) $baks[] = $b;
    }
    $items[] = array($baks ? 'bad' : 'ok',
        $baks ? '根目录存在配置备份文件：' . implode('、', $baks) : '无配置备份残留',
        $baks ? '备份文件可能被直接下载泄露数据库账号！请立即删除。' : '');

    // ④ uploads 目录混入可执行 PHP
    $phpInUploads = array();
    $scanPhp = function ($dir) use (&$scanPhp, &$phpInUploads) {
        if (!is_dir($dir)) return;
        foreach ((array)@scandir($dir) as $it) {
            if ($it === '.' || $it === '..') continue;
            $p = $dir . '/' . $it;
            if (is_dir($p)) { $scanPhp($p); continue; }
            if (strtolower(pathinfo($p, PATHINFO_EXTENSION)) === 'php') $phpInUploads[] = str_replace('\\', '/', $p);
            if (count($phpInUploads) >= 5) return;
        }
    };
    $scanPhp($root . '/uploads');
    $items[] = array($phpInUploads ? 'bad' : 'ok',
        $phpInUploads ? '上传目录发现 PHP 文件（' . count($phpInUploads) . ' 个）' : '上传目录无可执行脚本',
        $phpInUploads ? '上传目录不应有 .php（可能是被上传的 webshell！）：' . implode('、', array_slice($phpInUploads, 0, 5)) . ' 请人工确认后删除。' : '防止上传的文件被当作脚本执行是建站安全底线。');

    // ⑤ HTTPS
    $isHttps = stripos((string)base_url(), 'https://') === 0;
    $items[] = array($isHttps ? 'ok' : 'warn',
        $isHttps ? '站点已启用 HTTPS' : '站点未启用 HTTPS',
        $isHttps ? '' : '登录密码与 Cookie 明文传输有被窃听风险，建议在宝塔申请 SSL 证书并强制 HTTPS。');

    // ⑥ 错误信息外泄
    $de = (string)ini_get('display_errors');
    $items[] = array(in_array(strtolower($de), array('1', 'on', 'true'), true) ? 'warn' : 'ok',
        in_array(strtolower($de), array('1', 'on', 'true'), true) ? 'display_errors 已开启' : 'display_errors 已关闭',
        in_array(strtolower($de), array('1', 'on', 'true'), true) ? '报错详情会暴露路径与代码结构，生产环境建议关闭（php.ini 设 display_errors=Off）。' : '');

    // ⑦ Cookie 安全属性
    $httponly = strtolower((string)ini_get('session.cookie_httponly'));
    $items[] = array(in_array($httponly, array('1', 'on', 'true'), true) ? 'ok' : 'warn',
        in_array($httponly, array('1', 'on', 'true'), true) ? 'Session Cookie 已开启 HttpOnly' : 'Session Cookie 未开启 HttpOnly',
        in_array($httponly, array('1', 'on', 'true'), true) ? '' : 'php.ini 设 session.cookie_httponly=1 可防 XSS 窃取 Cookie。');

    // ⑧ 关键密钥
    $hubSecret = trim((string)setting('update_hub_secret', ''));
    $rcSecret  = trim((string)setting('recharge_secret', ''));
    $items[] = array($hubSecret !== '' ? 'ok' : 'warn',
        $hubSecret !== '' ? '授权服务密钥已配置' : '授权服务未初始化（update_hub_secret 为空）',
        $hubSecret !== '' ? '注意：密钥泄露 = 任何人可伪造授权码；更换密钥会使历史授权码全部失效，请妥善保管并定期备份。' : '');
    $items[] = array($rcSecret !== '' ? 'ok' : 'warn',
        $rcSecret !== '' ? '支付回调密钥已配置' : '支付回调密钥未配置（recharge_secret 为空）',
        $rcSecret !== '' ? '' : '使用第三方支付网关时必须配置回调密钥，否则回调可被伪造刷金币。');

    // ⑨ PHP 版本
    $ver = PHP_VERSION;
    $items[] = array(version_compare($ver, '7.4.0', '>=') ? 'ok' : 'warn',
        'PHP 版本 ' . $ver,
        version_compare($ver, '7.4.0', '>=') ? '' : 'PHP 7.4 以下已停止安全维护，建议升级到 8.x。');

    // ⑩ .htaccess 保护（Apache）
    if (is_file($root . '/.htaccess')) {
        $ht = (string)@file_get_contents($root . '/.htaccess');
        $items[] = array(strpos($ht, 'cache') !== false || strpos($ht, 'content') !== false ? 'ok' : 'warn',
            '.htaccess 存在', strpos($ht, 'cache') !== false || strpos($ht, 'content') !== false ? '' : '未见对 cache / content 目录的访问保护规则，数据文件可能被直接下载。');
    } else {
        $items[] = array('warn', '.htaccess 不存在（Nginx 环境？）', 'Nginx 需在站点配置里手动禁止访问 /cache/、/content/ 目录，防止订单 / 授权记录被下载。');
    }

    $nBad = 0; $nWarn = 0;
    foreach ($items as $it) { if ($it[0] === 'bad') $nBad++; elseif ($it[0] === 'warn') $nWarn++; }
    return array('items' => $items, 'bad' => $nBad, 'warn' => $nWarn, 'time' => date('Y-m-d H:i'));
}
}

$secScan = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && moe_is_owner()) {
    $secAct = (string)($_POST['act'] ?? '');
    if ($secAct === 'security_scan' || $secAct === 'security_ai') {
        csrf_verify();
        @set_time_limit(120);
        $secScan = moe_security_scan();
        if ($secAct === 'security_ai') {
            // AI 深度分析：把自检摘要交给后台配置的大模型做风险评级与修复建议
            if (!function_exists('moe_ai_chat')) {
                $aiFile = dirname(__DIR__) . '/includes/ai.php';
                if (is_file($aiFile)) require_once $aiFile;
            }
            if (function_exists('moe_ai_ready') && moe_ai_ready()) {
                $summary = '';
                foreach ($secScan['items'] as $it) {
                    $summary .= '- [' . strtoupper($it[0]) . '] ' . $it[1] . ($it[2] !== '' ? '：' . $it[2] : '') . "\n";
                }
                $prompt = "你是 PHP 建站程序安全审计专家。以下是「萌Z MoeZ v" . MOE_VERSION . "」博客系统的安全自检结果：\n"
                    . $summary . "\n"
                    . "请输出：1) 总体风险评级（低/中/高）；2) 按优先级排序的修复建议（最多 5 条，每条一行、具体可执行）；"
                    . "3) 针对 MoeZ 这类 PHP 博客系统的 2 条通用加固建议。全部用简体中文，直接给结论，不要客套。";
                $r = moe_ai_chat(array(array('role' => 'user', 'content' => $prompt)), array('max_tokens' => 700));
                $secScan['ai'] = !empty($r['ok']) ? trim((string)$r['text']) : ('AI 分析失败：' . (string)($r['err'] ?? '未知错误'));
            } else {
                $secScan['ai'] = '';
                $secScan['ai_unconfigured'] = true;
            }
        }
    }
}

include 'includes/header.php';
?>

<div class="dash-hero">
  <h2><?php echo e($me['nickname'] ?: $me['username']); ?>，欢迎回来～ 🌸</h2>
  <p><?php echo e($heroLine); ?></p>
  <div style="margin-top:18px"><a class="btn ghost" href="post-edit.php" style="background:rgba(255,255,255,.92)">✏️ 写新文章</a></div>
</div>

<div class="stat-grid">
  <div class="stat"><div class="ico p1">📝</div><b><?php echo $stats['posts']; ?></b><span>已发布文章</span></div>
  <div class="stat"><div class="ico p2">💬</div><b><?php echo $stats['comments']; ?></b><span>评论总数</span></div>
  <div class="stat"><div class="ico p3">👀</div><b><?php echo $stats['views']; ?></b><span>累计浏览</span></div>
  <div class="stat"><div class="ico p4">🗃</div><b><?php echo $stats['drafts']; ?></b><span>草稿箱</span></div>
</div>

<!-- ============ 2.0.3 · 软件信息 / 自动检测 / 在线更新 ============ -->
<div class="card" id="software">
  <h2 class="card-title">🖥 软件信息</h2>
  <div class="sys-grid">
    <?php foreach ($sysInfo as $si): ?>
      <div class="sys-item">
        <div class="k"><?php echo e($si['k']); ?></div>
        <div class="v"><?php echo e($si['v']); ?><?php if ($si['s'] !== ''): ?><br><small><?php echo e($si['s']); ?></small><?php endif; ?></div>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="upd-bar">
    <div class="upd-txt">
      <div class="upd-line">
        当前版本 <b>v<?php echo e(MOE_VERSION); ?></b>
        · <span class="upd-state" id="updState">自动检测中…</span>
        <a href="javascript:;" class="upd-recheck" id="updReCheck" title="忽略 10 分钟缓存，重新检测">重新检测 ↻</a>
        <a href="javascript:;" class="upd-recheck" id="updFeed" title="配置在线更新源（指向 version.json 的直链）">⚙ 更新源</a>
      </div>
      <div class="upd-sub" id="updHint">正在自动核对最新版本…</div>
    </div>
    <div class="upd-acts">
      <button class="btn sm" type="button" id="updOnline" style="display:none">⬆ 在线更新</button>
    </div>
  </div>

  <!-- 新版本更新内容：默认折叠成几行，点击展开；无新版时不显示 -->
  <div class="upd-log" id="updLog" style="display:none" title="点击展开 / 收起更新内容"></div>
  <!-- 在线更新执行日志 -->
  <div class="upd-run" id="updRun" style="display:none"></div>

  <p class="hint" style="margin:8px 0 0">
    每次打开仪表盘<b>自动检测</b>（结果缓存 10 分钟）。检测与更新优先走下方「🎫 授权与主题更新」的官方授权服务
    （程序 / 主题 / 插件独立检测、增量在线更新）；官方若在版本清单提供 <code>download</code> 网盘直链，
    也可直接整包在线更新。<code>config.php</code> 与 <code>content/</code> 下的用户数据永远不会被覆盖。
  </p>
</div>

<?php if (moe_is_owner()): ?>
<?php $isHub = trim((string)setting('update_hub_secret', '')) !== ''; /* 2.2.23：本站自己就是授权站时，两张授权卡都不显示（签发走用户中心「我的授权码」） */ ?>
<?php if (!$isHub): ?>
<!-- ============ 2.2.0 · 授权与主题更新（客户站视角；授权站自己无需连自己） ============ -->
<div class="card" id="authCard">
  <h2 class="card-title">🎫 授权与主题更新</h2>
  <div class="upd-bar">
    <div class="upd-txt">
      <div class="upd-line">授权状态：<span class="upd-state" id="authState">检测中…</span></div>
      <div class="upd-sub" id="authHint">填入官方授权码后，自动检测程序与全部主题的最新版本，并可一键增量更新（只下载有变化的文件）</div>
    </div>
    <div class="upd-acts">
      <a href="javascript:;" class="upd-recheck" id="authReCheck" title="忽略缓存重新检测">重新检测 ↻</a>
    </div>
  </div>
  <div class="upd-src">
    <label for="authHub">授权服务器</label>
    <input type="text" id="authHub" value="<?php echo e(function_exists('moe_auth_hub_url') ? moe_auth_hub_url() : ''); ?>"
           placeholder="https://官方主站域名（如 https://moezzz.com）" spellcheck="false" style="flex:1 1 220px">
    <label for="authCode" style="margin-left:6px">授权码</label>
    <input type="text" id="authCode" value="<?php echo e(function_exists('moe_auth_code') ? moe_auth_code() : ''); ?>"
           placeholder="MH-…" spellcheck="false" style="flex:1 1 200px">
    <button class="btn ghost sm" type="button" id="authSave">💾 保存并验证</button>
  </div>
  <div id="authResult" style="margin-top:14px"></div>
</div>

<?php endif; ?>

<!-- ============ 2.2.20 · 安全检测 + AI 辅助审计 ============ -->
<!-- 2.2.26：仪表盘「🎟 授权发放」卡整体移除 —— 授权服务签发/管理统一在用户中心「🔑 我的授权码」，
     后台不再展示发放入口（update-api.php 的 hub 接口与授权站初始化后端逻辑保留不受影响）。 -->
<div class="card" id="secCard">
  <h2 class="card-title">🛡 安全检测
    <span style="font-weight:400;font-size:12px;color:var(--muted)">本地静态检查一键跑完 · AI 辅助深度分析（复用「站点设置 → AI 助手」的配置）</span>
  </h2>
  <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
    <form method="post" style="margin:0">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="act" value="security_scan">
      <button class="btn sm" type="submit" id="secRunBtn">🛡 开始安全检测</button>
    </form>
    <form method="post" style="margin:0" onsubmit="this.querySelector('button').textContent='🤖 AI 分析中（约 10~30 秒）…';this.querySelector('button').disabled=true;return true">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="act" value="security_ai">
      <button class="btn ghost sm" type="submit" id="secAiBtn" title="先跑本地自检，再把结果交给 AI 做风险评级与修复建议">🤖 AI 深度分析</button>
    </form>
    <span class="hint" style="margin:0">检测项：安装脚本残留 / 诊断页暴露 / config 权限与备份 / 上传目录 webshell / HTTPS / 错误外泄 / Cookie 属性 / 密钥配置 / PHP 版本 / 数据目录保护</span>
  </div>

  <?php if ($secScan): ?>
  <div style="margin-top:16px;border-top:1px dashed var(--line);padding-top:14px">
    <p style="font-size:13px;font-weight:600;margin:0 0 10px">
      检测完成（<?php echo e($secScan['time']); ?>）：
      <?php if ($secScan['bad'] > 0): ?><span class="pill" style="background:#fdecef;color:#c33a55">🔴 高危 <?php echo (int)$secScan['bad']; ?></span><?php endif; ?>
      <?php if ($secScan['warn'] > 0): ?><span class="pill" style="background:#fff6e5;color:#a8791c">🟡 需留意 <?php echo (int)$secScan['warn']; ?></span><?php endif; ?>
      <?php if ($secScan['bad'] === 0 && $secScan['warn'] === 0): ?><span class="pill ok">全部通过 ✅</span><?php endif; ?>
    </p>
    <table style="width:100%;border-collapse:collapse;font-size:13px">
      <?php foreach ($secScan['items'] as $it): ?>
        <tr style="border-top:1px solid var(--line,#eee)">
          <td style="padding:8px 6px;width:64px">
            <?php if ($it[0] === 'bad'): ?><span style="color:#c33a55;font-weight:700">🔴 高危</span>
            <?php elseif ($it[0] === 'warn'): ?><span style="color:#a8791c;font-weight:700">🟡 留意</span>
            <?php else: ?><span style="color:#268a5b;font-weight:700">✅ 通过</span><?php endif; ?>
          </td>
          <td style="padding:8px 6px;font-weight:600"><?php echo e($it[1]); ?></td>
          <td style="padding:8px 6px;color:var(--muted);font-size:12.5px"><?php echo $it[2] !== '' ? e($it[2]) : '—'; ?></td>
        </tr>
      <?php endforeach; ?>
    </table>
    <?php if (isset($secScan['ai_unconfigured']) && $secScan['ai_unconfigured']): ?>
      <p class="hint" style="margin-top:12px">🤖 未配置 AI：到「站点设置 → AI 助手」填入 API 密钥后即可使用 AI 深度分析。</p>
    <?php elseif (!empty($secScan['ai'])): ?>
      <div style="margin-top:14px;padding:14px 16px;background:linear-gradient(135deg,#f5f2ff,#fff2f7);border-radius:12px">
        <div style="font-size:13px;font-weight:700;margin-bottom:8px">🤖 AI 审计结论</div>
        <div style="font-size:13px;line-height:1.9;white-space:pre-line"><?php echo e($secScan['ai']); ?></div>
      </div>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</div>

<script>
(function () {
  'use strict';
  var TOKEN = <?php echo json_encode(csrf_token(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
  var $ = function (id) { return document.getElementById(id); };
  if (!$('authCard')) return;

  function esc(v) {
    return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function post(data, cb) {
    var fd = new FormData();
    fd.append('_token', TOKEN);
    Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
    fetch('update-check.php', { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(cb)
      .catch(function (e) { cb({ ok: 0, msg: '请求失败：' + e.message }); });
  }

  function runSteps(res, okReload) {
    var box = $('authResult');
    var lines = (res.steps || []).slice();
    if (res.ok) {
      lines.push('✅ ' + (res.msg || '更新完成') + (res.version ? '（v' + esc(res.version) + '）' : ''));
      if (res.backup) lines.push('🗂 备份目录：' + esc(res.backup));
      lines.push(okReload ? '🔄 页面即将自动刷新…' : '');
      box.innerHTML = '<div class="upd-run ok" style="white-space:pre-line">' + esc(lines.filter(Boolean).join('\n')) + '</div>';
      if (okReload) setTimeout(function () { location.reload(); }, 3500);
      else setTimeout(function () { check(true); }, 2000);
    } else {
      lines.push('❌ ' + (res.msg || '更新失败') + (res.rolled_back ? '（已自动回滚）' : ''));
      box.innerHTML = '<div class="upd-run bad" style="white-space:pre-line">' + esc(lines.join('\n')) + '</div>';
    }
  }

  function updateBtn(act, slug, label, okReload) {
    if (!window.confirm('⚠️ 即将执行「' + label + '」：\n\n'
      + '· 只下载有变化的官方文件并覆盖\n'
      + '· 覆盖前自动备份，失败自动回滚\n'
      + '· config.php 与 content/ 数据不会被覆盖\n\n确定继续吗？')) return;
    post({ act: act, slug: slug || '', confirm: '1' }, function (res) { runSteps(res, okReload); });
  }

  function render(d) {
    var state = $('authState'), hint = $('authHint'), box = $('authResult');
    if (!d || !d.ok) {
      state.textContent = '检测失败';
      hint.textContent = (d && d.msg) ? d.msg : '请稍后重试';
      return;
    }
    if (!d.authed) {
      state.textContent = '未授权';
      state.className = 'upd-state';
      hint.textContent = d.msg || '填入官方授权码后保存并验证';
      box.innerHTML = '';
      return;
    }
    var auth = d.auth || {};
    state.textContent = '✅ 已授权 · ' + esc(auth.domain || '') + ' · ' + (auth.expire || '永久');
    state.className = 'upd-state ok';
    hint.textContent = d.msg || '';

    var html = '';
    // 违规警告横幅（授权站下发）
    if (d.notice) {
      html += '<div class="alert bad" style="margin-bottom:12px">' + esc(d.notice) + '</div>';
    }
    // 程序：增量更新 / 网盘直链整包更新
    var prog = d.program || {};
    if (prog.has_new) {
      html += '<div class="upd-bar" style="border-top:1px dashed #eee7f5;padding-top:12px"><div class="upd-txt">'
        + '<div class="upd-line">🖥 程序发现新版 <b>v' + esc(prog.version) + '</b>（当前 v<?php echo e(MOE_VERSION); ?>）'
        + (prog.date ? ' · ' + esc(prog.date) : '') + '</div>'
        + (prog.changelog ? '<div class="upd-sub">' + esc(prog.changelog) + '</div>' : '')
        + '</div><div class="upd-acts">'
        + '<button class="btn sm" id="authUpdProg">⬆ 增量更新程序</button>'
        + (prog.download ? '<button class="btn ghost sm" id="authUpdZip" title="官方网盘直链整包覆盖">📦 整包更新</button>' : '')
        + '</div></div>';
    } else {
      html += '<div class="upd-sub">🖥 程序已是最新版本 v' + esc(prog.version || '<?php echo e(MOE_VERSION); ?>') + '</div>';
    }
    // 主题：独立检测 / 更新 / 安装（已最新的折叠成一行汇总，只展开需要处理的）
    var themes = d.themes || [];
    if (themes.length) {
      var tOk = themes.filter(function (t) { return t.installed && !t.has_new; });
      var tTodo = themes.filter(function (t) { return !t.installed || t.has_new; });
      html += '<div style="margin-top:10px;font-size:13px;font-weight:600">🎨 主题（独立检测与更新）</div>'
        + (tOk.length ? '<div class="upd-sub" style="color:#268a5b">✓ ' + tOk.length + ' 套主题已最新：'
          + esc(tOk.map(function (t) { return t.name || t.dir; }).join('、')) + '</div>' : '');
      themes.forEach(function (t) {
        if (t.installed && !t.has_new) return;
        var st = t.installed
          ? 'v' + esc(t.current) + ' → <b style="color:#d5568e">v' + esc(t.latest) + '</b>'
          : '<span style="color:#8a7ba8">未安装</span>　官方最新 v' + esc(t.latest || '?');
        html += '<div class="upd-bar" style="padding:10px 0;border-bottom:1px dashed #f0eaf8"><div class="upd-txt">'
          + '<div class="upd-line">' + esc(t.name || t.dir) + '　' + st + '</div>'
          + (t.desc ? '<div class="upd-sub">' + esc(t.desc) + '</div>' : '')
          + '</div><div class="upd-acts" style="display:flex;gap:8px;flex-wrap:wrap">'
          + (t.installed ? '<a class="btn ghost sm" href="theme-settings.php">⚙ 设置</a>' : '')
          + (t.has_new ? '<button class="btn warn sm" data-theme="' + esc(t.dir) + '">更新</button>' : '')
          + (t.has_new && t.download ? '<button class="btn ghost sm" data-themezip="' + esc(t.dir) + '" title="整包直链：' + esc(t.download) + '">📦 整包</button>' : '')
          + (t.installed ? '<button class="btn ghost sm" data-themedel="' + esc(t.dir) + '" style="color:#d9506b;border-color:#f2c6cf">🗑 删除</button>' : '')
          + (!t.installed ? '<button class="btn ghost sm" data-theme="' + esc(t.dir) + '" data-inst="1">⬇ 安装主题</button>' : '')
          + '</div></div>';
      });
    }
    // 插件：独立检测 / 更新 / 安装
    var plugins = d.plugins || [];
    if (plugins.length) {
      var pOk = plugins.filter(function (p) { return p.installed && !p.has_new; });
      var pTodo = plugins.filter(function (p) { return !p.installed || p.has_new; });
      html += '<div style="margin-top:10px;font-size:13px;font-weight:600">🧩 插件（独立检测与更新）</div>'
        + (pOk.length ? '<div class="upd-sub" style="color:#268a5b">✓ ' + pOk.length + ' 个插件已最新：'
          + esc(pOk.map(function (p) { return p.name || p.dir; }).join('、')) + '</div>' : '');
      plugins.forEach(function (p) {
        if (p.installed && !p.has_new) return;
        var st = p.installed
          ? 'v' + esc(p.current) + ' → <b style="color:#d5568e">v' + esc(p.latest) + '</b>'
          : '<span style="color:#8a7ba8">未安装</span>　官方最新 v' + esc(p.latest || '?');
        html += '<div class="upd-bar" style="padding:10px 0;border-bottom:1px dashed #f0eaf8"><div class="upd-txt">'
          + '<div class="upd-line">' + esc(p.name || p.dir) + '　' + st + '</div>'
          + (p.desc ? '<div class="upd-sub">' + esc(p.desc) + '</div>' : '')
          + '</div><div class="upd-acts" style="display:flex;gap:8px;flex-wrap:wrap">'
          + (p.installed ? '<a class="btn ghost sm" href="plugins.php">⚙ 设置</a>' : '')
          + (p.has_new ? '<button class="btn warn sm" data-plugin="' + esc(p.dir) + '">更新</button>' : '')
          + (p.has_new && p.download ? '<button class="btn ghost sm" data-pluginzip="' + esc(p.dir) + '" title="整包直链：' + esc(p.download) + '">📦 整包</button>' : '')
          + (p.installed ? '<button class="btn ghost sm" data-plugindel="' + esc(p.dir) + '" style="color:#d9506b;border-color:#f2c6cf">🗑 删除</button>' : '')
          + (!p.installed ? '<button class="btn ghost sm" data-plugin="' + esc(p.dir) + '" data-inst="1">⬇ 安装插件</button>' : '')
          + '</div></div>';
      });
    }
    box.innerHTML = html;
    var up = $('authUpdProg');
    if (up) up.addEventListener('click', function () { updateBtn('auth_update_program', '', '增量更新程序到 v' + (d.program.version || ''), true); });
    var upZip = $('authUpdZip');
    if (upZip) upZip.addEventListener('click', function () {
      post({ act: 'auth_update_program', mode: 'zip', confirm: '1' }, function (res) { runSteps(res, true); });
    });
    box.querySelectorAll('button[data-theme]').forEach(function (b) {
      b.addEventListener('click', function () {
        var inst = b.getAttribute('data-inst') === '1';
        updateBtn('auth_update_theme', b.getAttribute('data-theme'),
          (inst ? '安装主题 ' : '更新主题 ') + b.getAttribute('data-theme'), !inst);
      });
    });
    box.querySelectorAll('button[data-themedel]').forEach(function (b) {
      b.addEventListener('click', function () {
        var dir = b.getAttribute('data-themedel');
        if (!window.confirm('确定删除本地主题「' + dir + '」？\n\n· 删除前会自动把整个主题目录备份到 content/backups/\n· 误删可从备份找回\n\n确定继续吗？')) return;
        post({ act: 'auth_delete_theme', slug: dir }, function (d2) {
          window.alert((d2.ok ? '✅ ' : '❌ ') + (d2.msg || ''));
          if (d2.ok) check(true);
        });
      });
    });
    box.querySelectorAll('button[data-themezip]').forEach(function (b) {
      b.addEventListener('click', function () {
        if (!window.confirm('即将从官方资源直链下载整包并覆盖该主题：\n\n· 自动备份被覆盖文件\n· 失败自动回滚\n\n确定继续吗？')) return;
        post({ act: 'auth_update_theme', slug: b.getAttribute('data-themezip'), mode: 'zip', confirm: '1' },
          function (res) { runSteps(res, false); });
      });
    });
    box.querySelectorAll('button[data-plugin]').forEach(function (b) {
      b.addEventListener('click', function () {
        var inst = b.getAttribute('data-inst') === '1';
        updateBtn('auth_update_plugin', b.getAttribute('data-plugin'),
          (inst ? '安装插件 ' : '更新插件 ') + b.getAttribute('data-plugin'), false);
      });
    });
    box.querySelectorAll('button[data-plugindel]').forEach(function (b) {
      b.addEventListener('click', function () {
        var dir = b.getAttribute('data-plugindel');
        if (!window.confirm('确定删除本地插件「' + dir + '」？该操作不可恢复。')) return;
        post({ act: 'auth_delete_plugin', slug: dir }, function (d2) {
          window.alert((d2.ok ? '✅ ' : '❌ ') + (d2.msg || ''));
          if (d2.ok) check(true);
        });
      });
    });
    box.querySelectorAll('button[data-pluginzip]').forEach(function (b) {
      b.addEventListener('click', function () {
        if (!window.confirm('即将从官方资源直链下载整包并覆盖该插件：\n\n· 自动备份被覆盖文件\n· 失败自动回滚\n\n确定继续吗？')) return;
        post({ act: 'auth_update_plugin', slug: b.getAttribute('data-pluginzip'), mode: 'zip', confirm: '1' },
          function (res) { runSteps(res, false); });
      });
    });
  }

  function check(force) {
    if (force) $('authState').textContent = '检测中…';
    post({ act: 'auth_check', force: force ? '1' : '0' }, render);
  }

  $('authSave').addEventListener('click', function () {
    var b = this;
    b.disabled = true;
    b.textContent = '⏳ 验证中…';
    post({ act: 'auth_save', hub: $('authHub').value.trim(), code: $('authCode').value.trim() }, function (d) {
      b.disabled = false;
      b.textContent = '💾 保存并验证';
      var box = $('authResult');
      if (!d.ok) {
        $('authHint').textContent = d.msg || '保存失败';
        if (box) box.innerHTML = '<div class="alert bad">' + esc(d.msg || '保存失败') + '</div>';
        return;
      }
      if (box) box.innerHTML = '<div class="alert ok">已保存授权信息，正在重新验证…</div>';
      check(true);
    });
  });
  $('authReCheck').addEventListener('click', function () { check(true); });

  check(false);

  /* 2.2.26：授权发放卡已移除，hub_init 前端入口一并下线（后端 act 保留） */
})();
</script>
<?php endif; ?>

<script>
(function () {
  'use strict';
  var TOKEN = <?php echo json_encode(csrf_token(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
  var INITIAL = <?php echo json_encode($updCached, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
  var FEED = <?php echo json_encode(function_exists('moe_update_feed_url') ? moe_update_feed_url() : '', JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
  var $ = function (id) { return document.getElementById(id); };
  var st = { checked: false, zipReady: false, writable: false, reason: '', download: '', latest: '' };
  if (!$('updState')) return;

  function esc(v) {
    return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function post(data, cb) {
    var fd = new FormData();
    fd.append('_token', TOKEN);
    Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
    fetch('update-check.php', { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(cb)
      .catch(function (e) { cb({ ok: 0, msg: '请求失败：' + e.message }); });
  }
  function actions(on) {
    $('updOnline').disabled = !on;
    $('updReCheck').style.pointerEvents = on ? '' : 'none';
  }

  function render(d) {
    if (!d || !d.ok) {
      $('updState').textContent = '检测失败';
      $('updHint').textContent = (d && d.msg) ? d.msg : '自动检测失败，请稍后点「重新检测」';
      return;
    }
    st.zipReady  = !!d.zip_ready;
    st.writable  = !!d.writable;
    st.checked   = true;
    st.reason    = d.ready_reason || '';
    st.download  = d.download || '';
    st.latest    = d.latest || '';

    var state = $('updState');
    state.textContent = d.has_new ? ('发现新版 v' + esc(d.latest)) : '已是最新版本';
    state.className = 'upd-state' + (d.has_new ? ' new' : '');

    var sub = (d.source === 'remote' ? '在线检测' : '离线核对') + ' · ' + esc(d.checked_at || '');
    if (d.feed) FEED = d.feed;
    if (d.has_new && !d.can_online && st.reason) sub += ' · ' + esc(st.reason);
    else if (d.source === 'local') sub += d.feed ? '' : ' · 未配置在线更新源（点「⚙ 更新源」添加）';
    $('updHint').textContent = sub;

    var online = $('updOnline');
    if (d.has_new && d.can_online) {
      online.style.display = '';
      online.textContent = '⬆ 在线更新到 v' + esc(d.latest);
    } else {
      online.style.display = 'none';
    }

    var log = $('updLog');
    if (d.has_new && (d.changelog || d.date || d.download)) {
      var parts = [];
      if (d.changelog) parts.push(d.changelog);
      if (d.date) parts.push('发布日期：' + d.date);
      if (d.download) parts.push('更新包：' + d.download);
      log.textContent = parts.join('\n\n') + '\n\n（点击展开 / 收起）';
      log.style.display = 'block';
      log.className = 'upd-log';
    } else {
      log.style.display = 'none';
    }
  }

  function check(force, silent) {
    if (!silent) $('updState').textContent = '自动检测中…';
    post({ act: 'check', force: force ? '1' : '0' }, render);
  }

  function runUpdate(fd, label, okMsg) {
    if (!window.confirm('⚠️ 即将执行「' + label + '」：\n\n'
      + '· 会自动备份被覆盖的文件到 content/backups/\n'
      + '· 然后覆盖程序文件，中途请勿关闭页面\n'
      + '· 失败会自动回滚到更新前的状态\n'
      + '· config.php 和 content/ 下的数据不会被覆盖\n\n确定继续吗？')) return;
    fd.append('_token', TOKEN);
    fd.append('confirm', '1');
    actions(false);
    var run = $('updRun');
    run.style.display = 'block';
    run.textContent = '⏳ 正在' + label + '，请勿关闭页面…';
    fetch('update-check.php', { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        var lines = (d.steps || []).slice();
        if (d.ok) {
          lines.push('✅ ' + (okMsg || '更新完成') + (d.version ? '（v' + d.version + '）' : ''));
          if (d.backup) lines.push('🗂 备份目录：' + d.backup);
          lines.push('🔄 页面即将自动刷新…');
          run.textContent = lines.join('\n');
          run.className = 'upd-run ok';
          setTimeout(function () { location.reload(); }, 3500);
        } else {
          lines.push('❌ ' + (d.msg || '更新失败') + (d.rolled_back ? '（已自动回滚到更新前状态）' : ''));
          run.textContent = lines.join('\n');
          run.className = 'upd-run bad';
          actions(true);
        }
        run.scrollTop = run.scrollHeight;
      })
      .catch(function (e) {
        run.textContent = '❌ 请求失败：' + e.message + '\n如页面异常，请用 content/backups/ 里的备份手工恢复。';
        run.className = 'upd-run bad';
        actions(true);
      });
  }

  $('updOnline').addEventListener('click', function () {
    var fd = new FormData();
    fd.append('act', 'online_update');
    runUpdate(fd, '在线更新到 v' + st.latest, '更新完成');
  });

  $('updReCheck').addEventListener('click', function () { check(true, false); });

  $('updFeed').addEventListener('click', function () {
    var url = window.prompt(
      '在线更新源：指向官方 version.json 的完整直链（JSON 需含 version 字段，\n'
      + '可选 date / changelog / download / notice）。\n'
      + '留空并确定 = 清除更新源，改用随程序包的版本清单。',
      FEED || '');
    if (url === null) return;
    url = String(url).trim();
    post({ act: 'save_feed', url: url }, function (d2) {
      FEED = url;
      window.alert((d2.ok ? '✅ ' : '❌ ') + (d2.msg || ''));
      if (d2.ok) check(true, false);   // 保存成功立即按新源重新检测
    });
  });

  $('updLog').addEventListener('click', function () {
    this.className = this.className.indexOf('expand') >= 0 ? 'upd-log' : 'upd-log expand';
  });

  // 自动检测：有缓存先渲染（不闪屏），再静默核对一次
  if (INITIAL && INITIAL.ok) { render(INITIAL); check(false, true); }
  else check(false, false);
})();
</script>

<?php if (function_exists('moe_plugin_render')) echo moe_plugin_render('admin_dashboard'); ?>

<?php include 'includes/footer.php'; ?>
