<?php
/**
 * 后台 · 资源媒体库 Ajax 接口（2.0.4 / 2.2.9 加固）
 * ------------------------------------------------------------
 * act=list   列出 uploads/ 下的文件（支持关键词 / 类型 / 分页）
 * act=delete 删除单个文件（路径白名单 + 引用检测 + 强制删除）
 *
 * 2.2.9b：act=list 的引用计数改为「按当前页文件逐个 SQL COUNT」，
 *         不再把全库文章 content/cover 载入内存 —— 文章多时原先会
 *         撑爆 memory_limit，PHP-FPM 返回 200 空白页（即「接口无响应 HTTP 200」）。
 *         新增 act=ping 轻量探针便于诊断。
 */
define('MOE_ADMIN', true);

/* 致命错误兜底提前到 init.php 之前 —— init 链路里任何致命错误也返回 JSON */
ob_start();
register_shutdown_function(function () {
    $e = error_get_last();
    if ($e && in_array($e['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR), true)) {
        while (ob_get_level() > 0) { ob_end_clean(); }
        if (!headers_sent()) {
            http_response_code(500);
            header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode(array(
            'ok' => 0,
            'msg' => '服务器内部错误：' . $e['message'] . '（' . basename((string)$e['file']) . ' 第 ' . $e['line'] . ' 行）',
        ), JSON_UNESCAPED_UNICODE);
    }
});
require dirname(__DIR__) . '/init.php';

/* 丢弃加载过程中可能混入的警告 / 通知输出，保证响应是纯 JSON */
while (ob_get_level() > 0) { ob_end_clean(); }
ob_start();
header('Content-Type: application/json; charset=utf-8');

/* 登录态与权限单独判断 —— 不走 require_admin 的 302 跳转 */
if (empty($_SESSION['moe_uid'])) {
    json_exit(false, '登录已过期，请刷新页面重新登录');
}
if (!is_admin()) {
    json_exit(false, '当前账号没有后台权限，请用管理员账号登录');
}
/* CSRF 校验失败也返回 JSON（原先 die() 输出纯文本，前端解析不了） */
$_token = (string)($_POST['_token'] ?? '');
if (!isset($_SESSION['moe_csrf']) || !hash_equals((string)$_SESSION['moe_csrf'], $_token)) {
    json_exit(false, '令牌校验失败，请刷新编辑页后重新打开媒体库');
}

if (!function_exists('moe_list_upload_files')) {
    json_exit(false, '核心函数缺失，请重新上传 includes/functions.php');
}

@set_time_limit(60);

/* ---------------- 帮助函数 ---------------- */

/** 文件类型归类 */
function moe_media_kind($ext)
{
    static $IMG = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg', 'bmp', 'ico');
    static $VID = array('mp4', 'webm', 'm4v', 'mov', 'm3u8');
    static $AUD = array('mp3', 'wav', 'flac', 'ogg', 'm4a', 'aac');
    if (in_array($ext, $IMG, true)) return 'image';
    if (in_array($ext, $VID, true)) return 'video';
    if (in_array($ext, $AUD, true)) return 'audio';
    return 'file';
}

/** 人类可读体积 */
function moe_media_size($b)
{
    if ($b >= 1048576) return round($b / 1048576, 1) . ' MB';
    if ($b >= 1024)    return round($b / 1024, 1) . ' KB';
    return $b . ' B';
}

/** 相对路径 → 可直接访问的 URL（逐段编码，兼容中文文件名） */
function moe_media_url($rel)
{
    return base_url() . implode('/', array_map('rawurlencode', explode('/', $rel)));
}

/** 非法 UTF-8（历史 GBK 文件名等）→ 尽量转成可显示的 UTF-8 */
function moe_media_utf8($s)
{
    $s = (string)$s;
    if (preg_match('//u', $s)) return $s;
    $c = function_exists('mb_convert_encoding')
        ? @mb_convert_encoding($s, 'UTF-8', 'GBK, GB2312, BIG5, UTF-8') : '';
    return is_string($c) && preg_match('//u', $c) ? $c : '';
}

/** 显示名：剥掉上传时自动加的「日期_时间_随机串_」前缀，露出原始文件名；
 *  没有前缀（纯随机名）就保持原样 */
function moe_media_display_name($name)
{
    $name = (string)$name;
    if (preg_match('/^\d{8}_\d{6}_[0-9a-f]{8}_(.+)$/u', $name, $m)) {
        $plain = $m[1];
        if ($plain !== '') return $plain;
    }
    return $name;
}

/** 引用次数：SQL LIKE 计数，不在内存里载全库文章（2.2.9b 修复 200 空白） */
function moe_media_used($rel)
{
    /* 正文里可能存的是 URL 编码后的文件名，两种形式都比对 */
    $enc  = implode('/', array_map('rawurlencode', explode('/', $rel)));
    $args = array();
    $cond = array();
    foreach (array_unique(array($rel, $enc)) as $p) {
        $like   = '%' . addcslashes($p, "%_\\") . '%';
        $cond[] = 'content LIKE ?';
        $args[] = $like;
        $cond[] = 'cover LIKE ?';
        $args[] = $like;
    }
    try {
        $st = moe_db()->prepare('SELECT COUNT(*) FROM ' . moe_table('posts') . ' WHERE ' . implode(' OR ', $cond));
        $st->execute($args);
        return (int)$st->fetchColumn();
    } catch (Throwable $e) {
        return 0;   /* 表结构异常时按「未引用」处理 */
    }
}

/* ---------------- 业务分发（try-catch 包裹，异常也返回 JSON） ---------------- */

$act = (string)($_POST['act'] ?? 'list');

try {
    if ($act === 'ping') {
        json_exit(true, '', array(
            'ver' => defined('MOE_VERSION') ? MOE_VERSION : '?',
            'mem' => (string)ini_get('memory_limit'),
            'files' => count(moe_list_upload_files()),
        ));
    }

    if ($act === 'list') {
        $q     = trim((string)($_POST['q'] ?? ''));
        $kind  = (string)($_POST['kind'] ?? 'all');
        $page  = max(1, (int)($_POST['page'] ?? 1));
        $per   = 24;
        $files = moe_list_upload_files();          // 已按修改时间倒序

        $matched = array();
        foreach ($files as $rel) {
            $fs = dirname(__DIR__) . '/' . $rel;   // 兼容 uploads/、upload/、content/uploadfile/ 三种前缀
            if (!is_file($fs)) continue;
            $ext  = strtolower(pathinfo($rel, PATHINFO_EXTENSION));
            $k    = moe_media_kind($ext);
            if ($kind !== 'all' && $k !== $kind) continue;
            $name = basename($rel);
            if ($q !== '' && stripos($name, $q) === false && stripos($rel, $q) === false) continue;
            $matched[] = array(
                /* rel64 = 原始路径字节的 base64：文件名若是历史 GBK 编码，
                 * 原始字节无法进 JSON，删除/定位必须走这条无损通道 */
                'rel64'     => base64_encode($rel),
                'rel'       => moe_media_utf8($rel),
                'name'      => moe_media_utf8(moe_media_display_name($name)),
                'url'       => moe_media_url($rel),
                'kind'      => $k,
                'ext'       => strtoupper($ext),
                'size'      => moe_media_size((int)@filesize($fs)),
                'time'      => date('Y-m-d H:i', (int)@filemtime($fs)),
                'used'      => 0,
            );
        }

        $total = count($matched);
        $items = array_slice($matched, ($page - 1) * $per, $per);
        /* 引用计数只查当前页这 24 个文件，避免整库 LIKE 扫描 */
        foreach ($items as $i => $it) {
            $items[$i]['used'] = moe_media_used($it['rel']);
        }
        json_exit(true, '', array(
            'items'    => $items,
            'total'    => $total,
            'page'     => $page,
            'has_more' => ($page * $per) < $total,
        ));
    }

    if ($act === 'delete') {
        $rel   = str_replace('\\', '/', trim((string)($_POST['rel'] ?? '')));
        /* 优先使用 rel64（原始字节的 base64），避免 GBK 文件名在 JSON 往返中损坏 */
        $rel64 = (string)($_POST['rel64'] ?? '');
        if ($rel64 !== '') {
            $dec = base64_decode($rel64, true);
            if ($dec !== false && $dec !== '') {
                $rel = str_replace('\\', '/', $dec);
            }
        }
        $force = !empty($_POST['force']);
        if (!moe_upload_path_safe($rel)) json_exit(false, '文件不存在或路径不合法');

        if (!$force) {
            $used = moe_media_used($rel);
            if ($used > 0) {
                json_exit(false, '这个文件仍被 ' . $used . ' 处内容引用，删除后文中会显示失效。确定要强制删除吗？',
                    array('in_use' => $used));
            }
        }
        if (!@unlink(dirname(__DIR__) . '/' . $rel)) json_exit(false, '删除失败，请检查 uploads/ 目录写入权限');
        json_exit(true, '已删除 ' . basename($rel));
    }

    json_exit(false, '未知操作');
} catch (Throwable $e) {
    json_exit(false, '接口异常：' . $e->getMessage() . '（' . basename($e->getFile()) . ' 第 ' . $e->getLine() . ' 行）');
}
