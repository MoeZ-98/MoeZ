<?php
/**
 * 后台 · 草稿自动保存（AJAX）
 *
 * 规则（1.6.7 起）：
 *  - 只有「未发布」的内容会被自动保存：新建文章 / 状态为草稿的文章
 *  - 同一篇始终原地更新，只保留一份草稿，不会新增副本
 *  - 文章一旦发布，自动保存立即停止，不再生成任何「编辑草稿」，线上内容也不会被改动
 */
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

$token = isset($_POST['_token']) ? (string)$_POST['_token'] : '';
if ($token === '' || empty($_SESSION['moe_csrf']) || !hash_equals((string)$_SESSION['moe_csrf'], $token)) {
    json_exit(false, '令牌校验失败，请刷新页面重试');
}

$type = (($_POST['type'] ?? 'post') === 'page') ? 'page' : 'post';
$act  = (string)($_POST['act'] ?? 'autosave');

/* ---- 丢弃一份自动保存的草稿（只允许删草稿，绝不删已发布内容） ---- */
if ($act === 'discard') {
    $did = (int)($_POST['id'] ?? 0);
    if ($did <= 0) json_exit(false, '参数缺失');
    try {
        q('DELETE FROM ' . moe_table('posts') . " WHERE id = ? AND type = ? AND status = 'draft'", array($did, $type));
        json_exit(true, '已丢弃草稿');
    } catch (Throwable $e) {
        json_exit(false, '丢弃失败：' . $e->getMessage());
    }
}

$id      = (int)($_POST['id'] ?? 0);
$title   = trim((string)($_POST['title'] ?? ''));
$content = (string)($_POST['content'] ?? '');
$catId   = (int)($_POST['category_id'] ?? 0);
$slug    = trim((string)($_POST['slug'] ?? ''));
$excerpt = trim((string)($_POST['excerpt'] ?? ''));
$cover   = trim((string)($_POST['cover'] ?? ''));
$tags    = function_exists('moe_tags_normalize') ? moe_tags_normalize((string)($_POST['tags'] ?? '')) : trim((string)($_POST['tags'] ?? ''));
$format  = 'markdown';

if ($title === '' && trim($content) === '') json_exit(false, '内容为空，无需保存');

$setSql = 'category_id=?, title=?, slug=?, excerpt=?, content=?, content_format=?, cover=?, tags=?, updated_at=NOW()';
$setVal = array($catId, $title, $slug, $excerpt, $content, $format, $cover, $tags);

try {
    $post = null;
    if ($id > 0) {
        $post = row('SELECT * FROM ' . moe_table('posts') . ' WHERE id = ? AND type = ?', array($id, $type));
        if (!$post) json_exit(false, '内容不存在或已被删除');
    }

    // 已发布：彻底停止自动保存草稿（不改线上内容，也不另存副本）
    if ($post && $post['status'] === 'published') {
        json_exit(false, '文章已发布，不再自动保存草稿');
    }

    // 未发布（新建后自动保存的草稿 / 草稿状态）：原地更新，始终只有这一篇
    if ($post) {
        q('UPDATE ' . moe_table('posts') . ' SET ' . $setSql . ' WHERE id = ?', array_merge($setVal, array((int)$post['id'])));
        json_exit(true, '草稿已自动保存', array('id' => (int)$post['id'], 'copy' => 0, 'saved_at' => date('H:i')));
    }

    // 全新内容：自动草稿全局只保留一个槽位（auto_draft=1），重复触发原地更新同一篇，
    // 不会在文章列表里越攒越多；槽位会在文章成功发布/保存后被清除（见 post-edit.php）
    $slot = row('SELECT * FROM ' . moe_table('posts') . " WHERE type = ? AND status = 'draft' AND auto_draft = 1 ORDER BY id DESC LIMIT 1", array($type));
    if ($slot) {
        q('UPDATE ' . moe_table('posts') . ' SET ' . $setSql . ' WHERE id = ?', array_merge($setVal, array((int)$slot['id'])));
        json_exit(true, '草稿已自动保存', array('id' => (int)$slot['id'], 'copy' => 0, 'saved_at' => date('H:i')));
    }

    $t = $title !== '' ? $title : '未命名草稿';
    q('INSERT INTO ' . moe_table('posts') . ' (user_id,category_id,type,title,slug,excerpt,content,content_format,cover,tags,auto_draft,status,is_top,created_at,updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,1,\'draft\',0,NOW(),NOW())',
        array($_SESSION['moe_uid'], $catId, $type, $t, $slug, $excerpt, $content, $format, $cover, $tags));
    json_exit(true, '草稿已自动保存', array('id' => (int)last_id(), 'copy' => 0, 'saved_at' => date('H:i')));
} catch (Throwable $e) {
    json_exit(false, '自动保存失败：' . $e->getMessage());
}
