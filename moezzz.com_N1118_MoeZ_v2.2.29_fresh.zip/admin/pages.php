<?php
/**
 * 后台 · 独立页面管理（如「关于我」）
 * 1.8.2：新增「自定义添加」——填标题 + 别名 + 正文即可创建，不必进编辑器
 */
require __DIR__ . '/bootstrap.php';
$active = 'pages';
$page_title = '独立页面';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (function_exists('moe_content_changed')) moe_content_changed();   // 1.9.0：内容变更 → 清理统计/导航缓存与页面缓存
    $act = $_POST['act'] ?? '';
    $id  = (int)($_POST['id'] ?? 0);

    if ($act === 'delete') {
        q('DELETE FROM ' . moe_table('posts') . " WHERE id = ? AND type='page'", array($id));
        flash('页面已删除');
    } elseif ($act === 'toggle_status') {
        // 1.9.7 严重修复：原 UPDATE 漏了 WHERE，点一次会把全站文章/页面状态一起改掉
        $p = row('SELECT status FROM ' . moe_table('posts') . ' WHERE id = ? AND type = ?', array($id, 'page'));
        if ($p) {
            q('UPDATE ' . moe_table('posts') . ' SET status = ?, updated_at = NOW() WHERE id = ? AND type = ?',
                array($p['status'] === 'published' ? 'draft' : 'published', $id, 'page'));
        }
        flash('状态已更新');
    } elseif ($act === 'pretty_slug') {
        // 1.9.7：把历史生成的 page-随机串 别名改成按标题生成的可读别名
        $p = row('SELECT id, title, slug FROM ' . moe_table('posts') . ' WHERE id = ? AND type = ?', array($id, 'page'));
        if ($p && function_exists('moe_page_slug_from_title')) {
            $new = moe_page_slug_unique(moe_page_slug_from_title($p['title']), array((int)$p['id']));
            if ($new !== '' && $new !== (string)$p['slug']) {
                q('UPDATE ' . moe_table('posts') . ' SET slug = ?, updated_at = NOW() WHERE id = ? AND type = ?',
                    array($new, (int)$p['id'], 'page'));
                flash('链接已优化为 /' . $new . '.html（旧链接会失效，若已被收录请自行设置跳转）', 'warn');
            } else {
                flash('该页面无需优化', 'warn');
            }
        }
    }
    redirect('pages.php');
}

$pages = rows('SELECT * FROM ' . moe_table('posts') . " WHERE type='page' ORDER BY id DESC");
include 'includes/header.php';
?>

<div class="card">
  <div style="display:flex;gap:12px;align-items:center;margin-bottom:18px">
    <h2 class="card-title" style="margin:0">页面列表（<?php echo count($pages); ?>）</h2>
    <span style="flex:1"></span>
    <a class="btn" href="post-edit.php?type=page">＋ 新建页面（完整编辑器）</a>
  </div>

  <div class="table-wrap">
    <table class="tbl">
      <thead><tr><th>标题</th><th>链接（别名）</th><th>浏览</th><th>状态</th><th>更新时间</th><th>操作</th></tr></thead>
      <tbody>
      <?php if (empty($pages)): ?><tr><td colspan="6" style="color:var(--muted);text-align:center;padding:30px">还没有独立页面，点右上角「＋ 新建页面」建一个「关于我」怎么样？</td></tr><?php endif; ?>
      <?php foreach ($pages as $pg): $u = page_url($pg); ?>
        <tr>
          <td class="t-title"><a href="post-edit.php?type=page&id=<?php echo (int)$pg['id']; ?>"><?php echo e($pg['title']); ?></a></td>
          <td>
            <a href="<?php echo e($u); ?>" target="_blank" style="color:var(--violet);font-size:12.5px;word-break:break-all"><?php echo e($u); ?></a>
            <button type="button" class="btn ghost sm" data-copy="<?php echo e($u); ?>" style="margin-left:6px">复制</button>
            <?php if (preg_match('/^page-[0-9a-f]{6,}$/i', (string)$pg['slug'])): ?>
              <form method="post" style="display:inline;margin-left:6px"
                    onsubmit="return confirm('把该链接改成按标题生成的可读别名？\n旧链接会失效，请确认未被搜索引擎收录。')">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="pretty_slug">
                <input type="hidden" name="id" value="<?php echo (int)$pg['id']; ?>">
                <button class="btn ghost sm" type="submit" title="把 page-随机串 换成标题别名">✨ 优化链接</button>
              </form>
            <?php endif; ?>
          </td>
          <td><?php echo (int)$pg['views']; ?></td>
          <td>
            <form method="post" style="display:inline">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="id" value="<?php echo (int)$pg['id']; ?>">
              <button class="pill <?php echo $pg['status'] === 'published' ? 'ok' : 'warn'; ?>" name="act" value="toggle_status"
                      style="border:0;cursor:pointer" title="点击切换状态"><?php echo $pg['status'] === 'published' ? '已发布' : '草稿'; ?></button>
            </form>
          </td>
          <td style="color:var(--muted);font-size:12.5px"><?php echo e(format_time($pg['updated_at'], 'Y-m-d H:i')); ?></td>
          <td>
            <div class="acts">
              <a class="btn ghost sm" href="<?php echo e($u); ?>" target="_blank">预览</a>
              <a class="btn sm" href="post-edit.php?type=page&id=<?php echo (int)$pg['id']; ?>">编辑</a>
              <form method="post" onsubmit="return confirm('确定删除该页面吗？')">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="delete">
                <input type="hidden" name="id" value="<?php echo (int)$pg['id']; ?>">
                <button class="btn danger sm" type="submit">删除</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
(function () {
  document.querySelectorAll('[data-copy]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var t = btn.getAttribute('data-copy');
      function done() { var o = btn.textContent; btn.textContent = '已复制 ✓'; setTimeout(function () { btn.textContent = o; }, 1200); }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(t).then(done).catch(function () {});
      } else {
        var ta = document.createElement('textarea');
        ta.value = t; document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); done(); } catch (e) {}
        ta.remove();
      }
    });
  });
})();
</script>

<?php include 'includes/footer.php'; ?>
