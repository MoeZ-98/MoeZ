<?php
/**
 * 后台 · 用户中心（2.0.1）
 * 站长 / 作者都能访问：查看自己的资料与数据、改头像昵称邮箱、改登录账户与密码。
 * 2.0.1：原「站点设置」的 个人资料 / 社交与展示 / 账户安全 三个页签统一收拢到这里。
 * 2.0.2：本页改为胶囊式选项卡（概览 / 个人资料 / 社交与展示 / 站点展示 / 账户安全），
 *        与站点设置共用 .set-tabs / .set-pane；提交后自动回到原页签（支持旧锚点）。
 *   - 编辑个人资料：登录账号自己的昵称 / 邮箱 / 头像 / 简介
 *   - 社交与展示：站点社交链接 + RSS 入口（站点级，仅站长可改）
 *   - 站点展示：首页 / SEO 用的作者名 / 签名 / 站点头像（站点级，仅站长可改）
 *   - 账户安全：全站唯一的改用户名 / 密码入口
 */
require __DIR__ . '/bootstrap.php';
$active = 'profile';
$page_title = '用户中心';

$me = current_user();
if (!$me) redirect('login.php');
$owner = function_exists('moe_is_owner') && moe_is_owner();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = (string)($_POST['act'] ?? '');
    if ($act === 'profile') {
        $r = moe_user_save_profile($me['id'], $_POST);
        flash($r[1], $r[0] ? 'ok' : 'bad');
    } elseif ($act === 'account') {
        $r = moe_user_change_account($me['id'], $_POST);
        flash($r[1], $r[0] ? 'ok' : ($r[2] ? 'warn' : 'bad'));
    } elseif ($act === 'social' || $act === 'display') {
        if (!$owner) {
            flash('站点展示与社交链接仅站长可修改', 'bad');
        } elseif ($act === 'social') {
            setting_set('social_links', moe_social_clean($_POST['social_links'] ?? '[]'));
            setting_set('social_rss', isset($_POST['social_rss']) ? '1' : '0');
            flash('社交与展示已保存 💬✨');
        } else {
            $author = mb_substr(trim((string)($_POST['site_author'] ?? '')), 0, 60, 'UTF-8');
            $sign   = mb_substr(trim((string)($_POST['site_signature'] ?? '')), 0, 120, 'UTF-8');
            $ava    = trim((string)($_POST['site_avatar'] ?? ''));
            if (preg_match('#^\s*(javascript|data|vbscript|file)\s*:#i', $ava)) $ava = '';
            setting_set('site_author', $author);
            setting_set('site_signature', $sign);
            setting_set('site_avatar', $ava);
            flash('站点展示信息已保存 🌸');
        }
    }
    if (function_exists('moe_content_changed')) moe_content_changed();
    $anchors = array('social' => '#uc-social', 'display' => '#uc-display',
                     'account' => '#uc-account', 'profile' => '#uc-profile');
    redirect('profile.php' . ($anchors[$act] ?? '#uc-overview'));
}

$stats = moe_user_stats($me['id']);
$role  = moe_user_role($me);

// 2.0.1：从站点设置移植过来的数据
$socialList  = function_exists('moe_social_list') ? moe_social_list() : array();
$avaCur      = trim((string)setting('site_avatar', ''));
$avaDefault  = 'templates/default/assets/avatar.svg';
$avaPresets  = array(
    array('src' => 'templates/default/assets/avatar.svg',    'name' => '经典萌头像'),
    array('src' => 'templates/moezzz/assets/favicon.svg',    'name' => '萌Z Favicon'),
    array('src' => 'templates/flowersink/assets/favicon.svg','name' => '沉花 Favicon'),
    array('src' => 'templates/bingyu/assets/favicon.svg',    'name' => '冰语 Favicon'),
    array('src' => 'templates/sumi233/assets/avatar.webp',   'name' => '墨染头像'),
);
include 'includes/header.php';
?>

<style>
  .uc-hero { display:flex; align-items:center; gap:20px; flex-wrap:wrap; }
  .uc-hero .uc-ava { width:84px; height:84px; border-radius:50%; object-fit:cover; border:3px solid #fff; box-shadow:0 6px 20px rgba(146,120,200,.25); }
  .uc-hero .uc-name { font-size:20px; font-weight:700; display:flex; align-items:center; gap:9px; flex-wrap:wrap; }
  .uc-hero .uc-meta { color:var(--muted); font-size:12.5px; margin-top:5px; line-height:1.8; }
  .uc-quick { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:11px; }
  .uc-quick a { display:block; padding:14px 15px; border:1.5px solid #eee7f5; border-radius:13px; background:#fdfcff; color:var(--text); text-decoration:none; font-size:13.5px; font-weight:600; transition:transform .15s,border-color .15s; }
  .uc-quick a:hover { transform:translateY(-2px); border-color:#c9b3ee; text-decoration:none; }
  .uc-quick small { display:block; color:var(--muted); font-weight:400; font-size:12px; margin-top:4px; }
  .uc-ava-row { display:flex; gap:10px; align-items:center; flex-wrap:wrap; }
  .uc-ava-row img { width:58px; height:58px; border-radius:50%; object-fit:cover; flex:none; }
  .uc-ava-row input[type=text] { flex:1; min-width:170px; }
  .card[id] { scroll-margin-top: 16px; }
  @media (max-width:700px) {
    .uc-hero { gap:14px; } .uc-hero .uc-ava { width:66px; height:66px; }
    .uc-quick { grid-template-columns:repeat(2,minmax(0,1fr)); }
  }
  @media (max-width:480px) { .uc-quick { grid-template-columns:1fr; } }
</style>

<div class="set-tabs" id="ucTabs" role="tablist" aria-label="用户中心">
  <button type="button" class="set-tab cur" id="tab-uc-overview" data-pane="uc-overview" role="tab" aria-selected="true" aria-controls="uc-overview">🏠 概览</button>
  <button type="button" class="set-tab" id="tab-uc-profile" data-pane="uc-profile" role="tab" aria-selected="false" aria-controls="uc-profile">✏️ 个人资料</button>
  <button type="button" class="set-tab" id="tab-uc-social" data-pane="uc-social" role="tab" aria-selected="false" aria-controls="uc-social">💬 社交与展示</button>
  <?php if ($owner): ?>
  <button type="button" class="set-tab" id="tab-uc-display" data-pane="uc-display" role="tab" aria-selected="false" aria-controls="uc-display">🌸 站点展示</button>
  <?php endif; ?>
  <button type="button" class="set-tab" id="tab-uc-account" data-pane="uc-account" role="tab" aria-selected="false" aria-controls="uc-account">🔐 账户安全</button>
</div>

<div class="card set-pane cur" id="uc-overview" role="tabpanel" aria-labelledby="tab-uc-overview">
  <h2 class="card-title">我的账号</h2>
  <div class="uc-hero">
    <img class="uc-ava" id="ucAvaPrev" src="<?php echo e(moe_user_avatar($me)); ?>" alt="">
    <div>
      <div class="uc-name">
        <?php echo e(moe_user_display($me)); ?>
        <span class="pill <?php echo $role === 'admin' ? 'violet' : 'ok'; ?>"><?php echo e(moe_user_role_label($role)); ?></span>
      </div>
      <div class="uc-meta">
        登录账号 @<?php echo e($me['username']); ?> ·
        加入于 <?php echo e(date('Y-m-d', strtotime((string)$me['created_at']))); ?>
        <?php if (!empty($me['last_login'])): ?> · 上次登录 <?php echo e((string)$me['last_login']); ?><?php endif; ?><br>
        <?php echo e(trim((string)($me['bio'] ?? '')) !== '' ? $me['bio'] : '还没有填写个人简介～'); ?>
      </div>
    </div>
  </div>
  <div class="stat-grid" style="margin-top:18px">
    <div class="stat"><div class="ico">📝</div><b><?php echo (int)$stats['posts']; ?></b><span>已发布文章</span></div>
    <div class="stat"><div class="ico">💬</div><b><?php echo (int)$stats['comments']; ?></b><span>我的评论</span></div>
    <div class="stat"><div class="ico">🌐</div><b><?php echo e(moe_user_role_label($role)); ?></b><span>账号身份</span></div>
  </div>
  <div class="sub-h" style="margin-top:24px">快捷入口</div>
  <div class="uc-quick">
    <a href="post-edit.php">✏️ 写新文章<small>打开 Markdown 编辑器</small></a>
    <a href="<?php echo e(moe_user_url($me)); ?>" target="_blank">🌐 我的公开主页<small>访客看到的作者页 ↗</small></a>
    <a href="<?php echo e(base_url() . 'user'); ?>" target="_blank">🏠 前台用户中心<small>会员视角预览 ↗</small></a>
    <a href="#uc-social">💬 社交与展示<small><?php echo $owner ? '前台社交链接 / RSS' : '查看站点社交链接'; ?></small></a>
    <?php if ($owner): ?>
      <a href="#uc-display">🌸 站点展示<small>首页作者名 / 头像 / 签名</small></a>
      <a href="users.php">👥 用户管理<small>角色 / 启停 / 重置密码</small></a>
      <a href="settings.php">⚙️ 站点设置<small>站点级配置</small></a>
    <?php endif; ?>
    <a href="#uc-account">🔐 账户安全<small>改登录用户名 / 密码</small></a>
  </div>
</div>

<div class="card set-pane" id="uc-profile" role="tabpanel" aria-labelledby="tab-uc-profile">
  <h2 class="card-title">✏️ 编辑个人资料</h2>
  <p class="hint" style="margin:-6px 0 16px">这里是<b>登录账号自己</b>的资料，用于评论署名、作者主页与后台顶栏；和首页展示用的站点作者名互不覆盖。</p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="profile">
    <div class="form-grid">
      <div class="field"><label>昵称</label>
        <input type="text" name="nickname" value="<?php echo e($me['nickname'] ?? ''); ?>" placeholder="留空显示登录账号">
      </div>
      <div class="field"><label>邮箱</label>
        <input type="email" name="email" value="<?php echo e($me['email'] ?? ''); ?>" placeholder="用于登录与通知">
      </div>
      <div class="field"><label>QQ 号</label>
        <input type="text" id="ucQQ" name="qq" value="<?php echo e($me['qq'] ?? ''); ?>" placeholder="填 QQ 号可一键获取头像">
      </div>
      <div class="field"><label>个人网站</label>
        <input type="text" name="site" value="<?php echo e($me['site'] ?? ''); ?>" placeholder="https://...">
      </div>
      <div class="field full"><label>头像</label>
        <div class="uc-ava-row">
          <img id="ucAvaPrev2" src="<?php echo e(moe_user_avatar($me)); ?>" alt="">
          <input type="text" id="ucAvaInput" name="avatar" value="<?php echo e($me['avatar'] ?? ''); ?>" placeholder="图片地址，留空使用站点默认头像">
          <button class="btn ghost sm" type="button" id="ucQQBtn">🐧 用 QQ 头像</button>
        </div>
        <p class="hint">头像用于前台评论、作者主页与后台顶栏；也可粘贴任意图片地址。</p>
      </div>
      <div class="field full"><label>个人简介</label>
        <textarea name="bio" maxlength="120" rows="3" placeholder="一句话介绍自己"><?php echo e($me['bio'] ?? ''); ?></textarea>
      </div>
    </div>
    <div class="form-foot" style="border-top:1px dashed var(--line);padding-top:16px;margin-top:6px">
      <button class="btn" type="submit">💾 保存资料</button>
    </div>
  </form>
</div>

<!-- ============ 2.0.1：社交与展示（原站点设置页签） ============ -->
<div class="card set-pane" id="uc-social" role="tabpanel" aria-labelledby="tab-uc-social">
  <h2 class="card-title">💬 社交与展示</h2>
  <?php if ($owner): ?>
    <p class="hint" style="margin:-6px 0 14px">
      自定义前台社交链接：可 <b>新增 / 编辑 / 删除</b>，数量不限；图标可填 emoji（如 🐱），也可上传图片或填图片地址，前台按设置的顺序展示。
      <b>此处为站点级配置，仅站长可修改</b>，已从「站点设置」迁移至此。
    </p>
    <form method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="act" value="social">
      <?php echo moe_social_editor_html($socialList, 'upload.php', csrf_token()); ?>
      <div class="sub-h plain">订阅入口</div>
      <div class="field full" style="margin-bottom:0">
        <label class="check-row"><input type="checkbox" name="social_rss" <?php echo setting('social_rss') === '1' ? 'checked' : ''; ?>> 📡 前台展示 RSS 订阅入口</label>
      </div>
      <div class="form-foot" style="border-top:1px dashed var(--line);padding-top:16px;margin-top:20px">
        <button class="btn" type="submit">💾 保存社交与展示</button>
        <a class="btn ghost" href="<?php echo e(base_url()); ?>" target="_blank">前台预览 ↗</a>
      </div>
    </form>
  <?php else: ?>
    <p class="hint" style="margin:-6px 0 14px">站点社交链接与 RSS 入口由站长维护，这里可以预览前台展示效果。</p>
    <?php echo moe_social_preview_html($socialList); ?>
    <p class="hint" style="margin-top:14px">如需修改，请联系站长，或让自己成为站长后再编辑。</p>
  <?php endif; ?>
</div>

<?php if ($owner): ?>
<!-- ============ 2.0.1：站点展示（原站点设置「个人资料」页签） ============ -->
<div class="card set-pane" id="uc-display" role="tabpanel" aria-labelledby="tab-uc-display">
  <h2 class="card-title">🌸 站点展示 · 首页与 SEO</h2>
  <p class="hint" style="margin:-6px 0 14px">
    这里设置的是<b>站点展示用</b>的作者名、个性签名与头像（首页打字机、站点头像、SEO author 用到）；
    你自己的账号昵称 / 邮箱 / 头像请在上方「编辑个人资料」修改。
  </p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="display">
    <div class="field"><label>昵称 / 作者名</label>
      <input type="text" name="site_author" value="<?php echo e(setting('site_author', '')); ?>">
    </div>
    <div class="field"><label>个性签名（首页打字机效果）</label>
      <input type="text" name="site_signature" value="<?php echo e(setting('site_signature', '')); ?>" placeholder="如：把日子过成诗 ✨">
    </div>
    <div class="field" style="margin-bottom:0">
      <label>站点头像</label>
      <div class="cover-pick">
        <div class="preview" id="avaPrev" style="border-radius:50%;width:76px;height:76px">
          <img src="<?php echo e(media_url($avaCur !== '' ? $avaCur : $avaDefault)); ?>" alt="" style="width:100%;height:100%;border-radius:50%;object-fit:cover">
        </div>
        <div style="flex:1;min-width:230px">
          <input type="text" name="site_avatar" id="avaInput" value="<?php echo e($avaCur); ?>"
                 placeholder="图片地址，或用下面三种方式设置"
                 style="width:100%;padding:9px 12px;border:1.5px solid #e8e2f0;border-radius:10px;outline:none">
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;align-items:center">
            <label class="btn ghost sm" style="cursor:pointer;margin:0">
              📤 上传头像
              <input type="file" id="avaFile" accept="image/*" style="display:none">
            </label>
            <button type="button" class="btn ghost sm" id="avaReset">🔄 恢复默认头像</button>
          </div>
          <p class="hint" id="avaMsg" style="margin:6px 0 0">支持 jpg / png / gif / webp，2MB 以内；改动后点「保存站点展示」生效</p>
        </div>
      </div>

      <div style="margin-top:14px;padding-top:12px;border-top:1px dashed #e8e2f0">
        <label style="font-weight:600;font-size:13.5px">🐧 方式一 · QQ 号自动获取头像</label>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:8px">
          <input type="text" id="avaQQ" placeholder="填你的 QQ 号，如 10001" autocomplete="off"
                 style="width:210px;padding:9px 12px;border:1.5px solid #e8e2f0;border-radius:10px;outline:none">
          <button type="button" class="btn sm" id="avaQQBtn">获取头像</button>
          <span class="hint" style="margin:0">使用 QQ 官方头像接口（640 高清），填完点「保存站点展示」</span>
        </div>
      </div>

      <div style="margin-top:14px;padding-top:12px;border-top:1px dashed #e8e2f0">
        <label style="font-weight:600;font-size:13.5px">🎨 方式二 · 更换默认头像（点击即用）</label>
        <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:10px">
          <?php foreach ($avaPresets as $ap): ?>
            <button type="button" class="ava-preset"
                    data-src="<?php echo e($ap['src']); ?>" data-preview="<?php echo e(media_url($ap['src'])); ?>"
                    title="<?php echo e($ap['name']); ?>"
                    style="padding:0;border:2.5px solid <?php echo $avaCur === $ap['src'] ? '#8f7bff' : '#e8e2f0'; ?>;border-radius:50%;background:none;cursor:pointer;line-height:0;transition:border-color .15s">
              <img src="<?php echo e(media_url($ap['src'])); ?>" alt="<?php echo e($ap['name']); ?>"
                   style="width:48px;height:48px;border-radius:50%;object-fit:cover">
            </button>
          <?php endforeach; ?>
        </div>
        <p class="hint" style="margin:8px 0 0">以上为程序内置头像，点击圆形图标即可选用；也可用「上传头像」换成自己的图片</p>
      </div>
    </div>
    <div class="form-foot" style="border-top:1px dashed var(--line);padding-top:16px;margin-top:20px">
      <button class="btn" type="submit">💾 保存站点展示</button>
    </div>
  </form>
</div>
<?php endif; ?>

<div class="card set-pane" id="uc-account" role="tabpanel" aria-labelledby="tab-uc-account">
  <h2 class="card-title">🔐 账户安全</h2>
  <p class="hint" style="margin:-6px 0 16px">修改登录用户名或密码前，需要输入<b>当前密码</b>确认身份。当前登录状态不会被踢出。这里也是全站唯一的改密入口。</p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="account">
    <div class="form-grid">
      <div class="field full"><label>当前密码 *（必填）</label>
        <input type="password" name="cur_pass" required autocomplete="current-password" placeholder="输入现在的登录密码">
      </div>
      <div class="field"><label>新用户名（留空 = 不修改）</label>
        <input type="text" name="username" value="" autocomplete="username"
               placeholder="留空保持「<?php echo e($me['username']); ?>」不变">
      </div>
      <div class="field"><label>新密码（留空 = 不修改）</label>
        <input type="password" name="new_pass" autocomplete="new-password" placeholder="至少 6 位">
      </div>
      <div class="field"><label>确认新密码</label>
        <input type="password" name="new_pass2" autocomplete="new-password" placeholder="再输入一遍新密码">
      </div>
    </div>
    <div class="form-foot" style="border-top:1px dashed var(--line);padding-top:16px;margin-top:6px">
      <button class="btn" type="submit">🔐 保存账户信息</button>
    </div>
  </form>
</div>

<script>
/* ---------- 2.0.2 胶囊式选项卡：切换 / 记忆 / 兼容旧锚点 ---------- */
(function () {
  'use strict';
  var box = document.getElementById('ucTabs');
  if (!box) return;
  var alias = { overview: 'uc-overview', profile: 'uc-profile', social: 'uc-social',
                display: 'uc-display', account: 'uc-account' };
  function normalize(h) {
    h = (h || '').replace(/^#/, '');
    if (alias[h]) return alias[h];
    if (/^uc-[a-z]+$/.test(h) && document.getElementById(h)) return h;
    return '';
  }
  function show(id, remember) {
    if (!document.getElementById(id)) id = 'uc-overview';
    Array.prototype.forEach.call(box.querySelectorAll('.set-tab'), function (t) {
      var on = t.dataset.pane === id;
      t.className = on ? 'set-tab cur' : 'set-tab';
      t.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    Array.prototype.forEach.call(document.querySelectorAll('.set-pane'), function (p) {
      p.className = (p.id === id ? 'card set-pane cur' : 'card set-pane');
    });
    if (remember) {
      try { localStorage.setItem('moe_uc_tab', id); } catch (e) {}
      if (history.replaceState) history.replaceState(null, '', '#' + id);
    }
  }
  box.addEventListener('click', function (ev) {
    var t = ev.target;
    while (t && t !== box && !(t.dataset && t.dataset.pane)) t = t.parentNode;
    if (t && t !== box && t.dataset && t.dataset.pane) show(t.dataset.pane, true);
  });
  window.addEventListener('hashchange', function () {
    var id = normalize(location.hash);
    if (id) show(id, false);
  });
  (function () {
    var id = normalize(location.hash);
    if (!id) { try { id = normalize(localStorage.getItem('moe_uc_tab')); } catch (e) {} }
    show(id || 'uc-overview', false);
  })();
})();
</script>

<script>
/* ---------- 登录账号头像：QQ 一键获取 + 输入实时预览 ---------- */
document.getElementById('ucQQBtn').addEventListener('click', function () {
  var el = document.getElementById('ucQQ'), q = (el.value || '').trim();
  if (!/^\d{5,12}$/.test(q)) { alert('请填写正确的 QQ 号（5~12 位数字）'); return; }
  var url = 'https://q1.qlogo.cn/g?b=qq&nk=' + q + '&s=640';
  document.getElementById('ucAvaInput').value = url;
  document.getElementById('ucAvaPrev').src = url;
  document.getElementById('ucAvaPrev2').src = url;
});
document.getElementById('ucAvaInput').addEventListener('input', function () {
  var v = this.value.trim();
  if (v) { document.getElementById('ucAvaPrev').src = v; document.getElementById('ucAvaPrev2').src = v; }
});

/* ---------- 站点展示头像：QQ / 上传 / 恢复默认 / 内置预设 ---------- */
(function () {
  var input = document.getElementById('avaInput');
  if (!input) return;                       // 非站长不渲染站点展示卡片
  var prev  = document.querySelector('#avaPrev img');
  var msg   = document.getElementById('avaMsg');
  var DEFAULT_PATH = <?php echo json_encode($avaDefault, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
  var DEFAULT_URL  = <?php echo json_encode(media_url($avaDefault), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
  var TOKEN        = <?php echo json_encode(csrf_token()); ?>;
  function say(t) { if (msg) msg.textContent = t; }
  function show(url) { if (prev && url) prev.src = url; }

  input.addEventListener('input', function () { show(input.value.trim()); });

  var file = document.getElementById('avaFile');
  if (file) file.addEventListener('change', function () {
    if (!this.files[0]) return;
    var fd = new FormData(), xhr = new XMLHttpRequest();
    fd.append('file', this.files[0]);
    fd.append('_token', TOKEN);
    xhr.open('POST', 'upload.php');
    xhr.onload = function () {
      try {
        var d = JSON.parse(xhr.responseText);
        if (d.ok) { input.value = d.url; show(d.url); say('✅ 上传成功，点「保存站点展示」生效'); }
        else { alert('上传失败：' + d.msg); }
      } catch (e) { alert('上传失败'); }
    };
    xhr.send(fd);
  });

  var qqBtn = document.getElementById('avaQQBtn');
  if (qqBtn) qqBtn.addEventListener('click', function () {
    var qq = (document.getElementById('avaQQ').value || '').trim();
    if (!/^\d{5,12}$/.test(qq)) { say('⚠️ 请填写正确的 QQ 号（5~12 位数字）'); return; }
    input.value = 'https://q1.qlogo.cn/g?b=qq&nk=' + qq + '&s=640';
    show(input.value);
    say('✅ 已获取 QQ ' + qq + ' 的头像，点「保存站点展示」生效');
  });
  var qqInput = document.getElementById('avaQQ');
  if (qqInput && qqBtn) qqInput.addEventListener('keydown', function (ev) {
    if (ev.key === 'Enter') { ev.preventDefault(); qqBtn.click(); }
  });

  var reset = document.getElementById('avaReset');
  if (reset) reset.addEventListener('click', function () {
    input.value = DEFAULT_PATH;
    show(DEFAULT_URL);
    document.querySelectorAll('.ava-preset').forEach(function (b) { b.style.borderColor = '#e8e2f0'; });
    say('🔄 已恢复默认头像，点「保存站点展示」生效');
  });

  document.querySelectorAll('.ava-preset').forEach(function (b) {
    b.addEventListener('click', function () {
      input.value = this.getAttribute('data-src');
      show(this.getAttribute('data-preview'));
      document.querySelectorAll('.ava-preset').forEach(function (x) { x.style.borderColor = '#e8e2f0'; });
      this.style.borderColor = '#8f7bff';
      say('✅ 已选用内置头像，点「保存站点展示」生效');
    });
  });
})();
</script>

<?php include 'includes/footer.php'; ?>
