<?php
/**
 * 后台 · 友情链接管理
 * 字段：图标(logo) / 网站标题(name) / 网站描述(description) / 地址(url) / 排序
 * 支持前台申请：自动回链检测，已加本站链接自动通过，未加转人工审核
 */
require __DIR__ . '/bootstrap.php';

// 1.6.5 兜底：确保 links 表有 logo / description 字段（自动升级未生效时自动补齐）
if (function_exists('moe_ensure_links_columns')) moe_ensure_links_columns();

if (!function_exists('moe_check_backlink') && is_file(dirname(__DIR__) . '/includes/linkcheck.php')) {
    require_once dirname(__DIR__) . '/includes/linkcheck.php';
}

$active = 'links';
$page_title = '友情链接';

/** 读取单条友链 */
function link_one($id)
{
    return row('SELECT * FROM ' . moe_table('links') . ' WHERE id = ?', array((int)$id));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (function_exists('moe_content_changed')) moe_content_changed();   // 1.9.0：内容变更 → 清理统计/导航缓存与页面缓存
    $act = $_POST['act'] ?? '';
    $id  = (int)($_POST['id'] ?? 0);

    if ($act === 'create' || $act === 'update') {
        $name = trim($_POST['name'] ?? '');
        $url  = trim($_POST['url'] ?? '');
        $logo = trim($_POST['logo'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $sort = (int)($_POST['sort'] ?? 0);
        if ($name === '' || $url === '') {
            flash('网站标题和地址不能为空', 'bad');
            redirect('links.php' . ($act === 'update' ? '?edit=' . $id : ''));
        }
        if (!preg_match('#^https?://#i', $url)) $url = 'https://' . $url;
        if ($desc !== '' && function_exists('mb_substr')) $desc = mb_substr($desc, 0, 120, 'UTF-8');
        if ($act === 'create') {
            q('INSERT INTO ' . moe_table('links') . ' (name,url,logo,description,sort,status,created_at) VALUES (?,?,?,?,?,\'approved\',NOW())',
                array($name, $url, $logo, $desc, $sort));
            flash('友链已添加 🔗');
        } else {
            q('UPDATE ' . moe_table('links') . ' SET name=?, url=?, logo=?, description=?, sort=? WHERE id=?',
                array($name, $url, $logo, $desc, $sort, $id));
            flash('友链已更新 ✅');
        }
    } elseif ($act === 'delete') {
        q('DELETE FROM ' . moe_table('links') . ' WHERE id = ?', array($id));
        flash('友链已删除');
    } elseif ($act === 'status' && in_array($_POST['status'] ?? '', array('approved', 'pending'), true)) {
        $l = link_one($id);
        q('UPDATE ' . moe_table('links') . ' SET status = ? WHERE id = ?', array($_POST['status'], $id));
        if ($_POST['status'] === 'approved' && $l && (isset($l['status']) ? $l['status'] : '') !== 'approved') {
            // 刚从待审核转为通过：给申请者发通知邮件（开关见 设置 → 邮箱与登录）
            if (function_exists('moe_notify_link_result')) {
                moe_notify_link_result($l['name'], $l['url'], true, (string)($l['contact'] ?? ''));
            }
        }
        flash($_POST['status'] === 'approved' ? '友链已通过并展示 ✅' : '友链已转入待审核');
    } elseif ($act === 'check') {
        // 单个回链检测
        $l = link_one($id);
        if ($l) {
            $res = moe_check_backlink($l['url']);
            // 顺带补全标题 / 描述 / 图标（留空的才补，不覆盖站长手填内容）
            $fix = array();
            $vals = array();
            if (trim((string)$l['name']) === '' && !empty($res['title'])) { $fix[] = 'name=?'; $vals[] = $res['title']; }
            if (trim((string)($l['description'] ?? '')) === '' && !empty($res['desc'])) { $fix[] = 'description=?'; $vals[] = mb_substr($res['desc'], 0, 120, 'UTF-8'); }
            if (trim((string)($l['logo'] ?? '')) === '' && !empty($res['icon'])) { $fix[] = 'logo=?'; $vals[] = $res['icon']; }
            q('UPDATE ' . moe_table('links') . ' SET check_result = ?, last_check = NOW()' .
                ($fix ? ', ' . implode(', ', $fix) : '') . ' WHERE id = ?',
                array_merge(array($res['msg']), $vals, array($id)));
            if ($res['ok'] && $l['status'] !== 'approved') {
                q('UPDATE ' . moe_table('links') . ' SET status = \'approved\' WHERE id = ?', array($id));
                if (function_exists('moe_notify_link_result')) {
                    moe_notify_link_result($l['name'], $l['url'], true, (string)($l['contact'] ?? ''));
                }
                flash('检测到回链，已自动通过审核 ✅');
            } else {
                flash($res['msg'], $res['ok'] ? '' : 'bad');
            }
        }
    } elseif ($act === 'checkall') {
        // 批量检测全部友链
        @set_time_limit(300);
        $n = 0; $okN = 0;
        foreach ((array)rows('SELECT id, url, status FROM ' . moe_table('links')) as $l) {
            $res = moe_check_backlink($l['url']);
            $n++;
            if ($res['ok']) {
                $okN++;
                q('UPDATE ' . moe_table('links') . ' SET check_result = ?, last_check = NOW(), status = \'approved\' WHERE id = ?',
                    array($res['msg'], (int)$l['id']));
            } else {
                q('UPDATE ' . moe_table('links') . ' SET check_result = ?, last_check = NOW() WHERE id = ?',
                    array($res['msg'], (int)$l['id']));
            }
        }
        flash("批量检测完成：共 {$n} 个友链，{$okN} 个检测到回链 🔍");
    }
    redirect('links.php' . (!empty($_GET['status']) ? '?status=' . urlencode($_GET['status']) : ''));
}

$editId = (int)($_GET['edit'] ?? 0);
$editing = $editId > 0 ? link_one($editId) : null;

$stf = $_GET['status'] ?? '';
if (!in_array($stf, array('approved', 'pending'), true)) $stf = '';
$where = $stf ? ' WHERE status = ?' : '';
$args  = $stf ? array($stf) : array();
try {
    $links = rows('SELECT * FROM ' . moe_table('links') . $where . ' ORDER BY (status=\'approved\') DESC, sort, id', $args);
    $cntPending = (int)one('SELECT COUNT(*) FROM ' . moe_table('links') . ' WHERE status = \'pending\'');
} catch (Throwable $e) {
    // 表尚未升级：提示刷新（init 加载时 upgrade 会自动补字段）
    $links = array(); $cntPending = 0;
}
include 'includes/header.php';
?>

<div class="dash-cols">
  <!-- ============ 左：添加 / 编辑 ============ -->
  <div class="card" style="margin-bottom:0">
    <h2 class="card-title"><?php echo $editing ? '编辑友链' : '添加友链'; ?></h2>
    <form method="post">
      <?php echo csrf_field(); ?>
      <input type="hidden" name="act" value="<?php echo $editing ? 'update' : 'create'; ?>">
      <?php if ($editing): ?><input type="hidden" name="id" value="<?php echo (int)$editing['id']; ?>"><?php endif; ?>

      <div class="field"><label>网站标题 *</label>
        <input type="text" name="name" value="<?php echo e($editing ? $editing['name'] : ''); ?>" placeholder="如：小明的博客" required>
      </div>

      <div class="field"><label>网站描述</label>
        <input type="text" name="description" value="<?php echo e($editing ? ($editing['description'] ?? '') : ''); ?>"
               placeholder="一句话介绍这个站点，前台友链卡片会显示">
      </div>

      <div class="field"><label>地址 *</label>
        <input type="text" name="url" value="<?php echo e($editing ? $editing['url'] : ''); ?>" placeholder="https://example.com" required>
      </div>

      <div class="field">
        <label>图标（favicon / logo 地址）</label>
        <div style="display:flex;gap:10px;align-items:flex-start">
          <div id="logoPrev" style="width:44px;height:44px;border-radius:12px;background:var(--grad);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;overflow:hidden;flex-shrink:0">
            <?php if ($editing && !empty($editing['logo'])): ?>
              <img src="<?php echo e(media_url($editing['logo'])); ?>" style="width:100%;height:100%;object-fit:cover" onerror="this.remove()">
            <?php else: ?>🌸<?php endif; ?>
          </div>
          <div style="flex:1;min-width:0">
            <input type="text" name="logo" id="logoInput" value="<?php echo e($editing ? ($editing['logo'] ?? '') : ''); ?>"
                   placeholder="留空则自动用对方 /favicon.ico，失败显示首字母">
            <label class="btn ghost sm" style="margin-top:8px;cursor:pointer">
              📤 上传图标
              <input type="file" id="logoFile" accept="image/*" style="display:none">
            </label>
            <p class="hint" id="logoMsg">支持 jpg / png / svg / webp / ico，2MB 以内</p>
          </div>
        </div>
      </div>

      <div class="field"><label>排序（越小越靠前）</label>
        <input type="number" name="sort" value="<?php echo (int)($editing ? $editing['sort'] : 0); ?>">
      </div>

      <button class="btn wide" type="submit"><?php echo $editing ? '💾 保存修改' : '＋ 添加友链'; ?></button>
      <?php if ($editing): ?>
        <a class="btn ghost wide" style="margin-top:10px" href="links.php">取消编辑</a>
      <?php endif; ?>
    </form>

    <?php if (!$editing): ?>
    <p class="hint" style="margin-top:10px">💡 前台友链区的「申请友链」表单会自动抓取站点名并检测回链：已加本站链接自动通过，未加转人工审核。2.2.20 起回链检测覆盖<b>首页 + 友链独立页 + 常见内页</b>（/links、/yqlj、/about 等 20+ 个路径），放在内页的友链也能检测到。</p>
    <div style="margin-top:14px;border-top:1px dashed #e8e2f0;padding-top:14px">
      <form method="post" onsubmit="return confirm('逐个访问全部友链检测回链（含首页与常见友链内页）？站点较多时耗时较长。')">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="act" value="checkall">
        <button class="btn ghost wide" type="submit">🔍 一键检测全部回链</button>
      </form>
    </div>
    <?php endif; ?>
  </div>

  <!-- ============ 右：列表 ============ -->
  <div class="card" style="margin-bottom:0">
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:14px">
      <h2 class="card-title" style="margin:0">全部友链（<?php echo count($links); ?>）</h2>
      <span style="flex:1"></span>
      <a class="btn ghost sm <?php echo $stf === '' ? 'cur' : ''; ?>" href="links.php">全部</a>
      <a class="btn ghost sm <?php echo $stf === 'pending' ? 'cur' : ''; ?>" href="links.php?status=pending">待审核（<?php echo $cntPending; ?>）</a>
      <a class="btn ghost sm <?php echo $stf === 'approved' ? 'cur' : ''; ?>" href="links.php?status=approved">已通过</a>
    </div>
    <div class="table-wrap">
      <table class="tbl">
        <thead><tr><th style="width:56px">图标</th><th>网站标题</th><th>网站描述</th><th>地址</th><th>状态</th><th>操作</th></tr></thead>
        <tbody>
        <?php if (empty($links)): ?><tr><td colspan="6" style="color:var(--muted);text-align:center;padding:26px">还没有友链，去交个朋友吧～</td></tr><?php endif; ?>
        <?php foreach ($links as $l): ?>
          <?php
            $lLogo = trim((string)($l['logo'] ?? ''));
            $lHost = parse_url($l['url'], PHP_URL_HOST) ?: $l['url'];
          ?>
          <tr>
            <td>
              <div style="width:36px;height:36px;border-radius:10px;background:var(--grad);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;overflow:hidden">
                <?php if ($lLogo !== ''): ?>
                  <img src="<?php echo e(media_url($lLogo)); ?>" alt="" style="width:100%;height:100%;object-fit:cover" onerror="this.parentNode.textContent='<?php echo e(mb_substr($l['name'], 0, 1, 'UTF-8')); ?>'">
                <?php else: ?>
                  <?php echo e(mb_substr($l['name'], 0, 1, 'UTF-8')); ?>
                <?php endif; ?>
              </div>
            </td>
            <td style="font-weight:600;min-width:110px">
              <?php echo e($l['name']); ?>
              <?php if (!empty($l['contact'])): ?><br><span style="font-size:11.5px;color:var(--muted);font-weight:400">联系：<?php echo e($l['contact']); ?></span><?php endif; ?>
            </td>
            <td style="font-size:12.5px;color:var(--muted);max-width:230px">
              <?php
                $lDesc = trim((string)($l['description'] ?? ''));
                echo $lDesc !== '' ? e($lDesc) : '<span style="opacity:.55">—</span>';
              ?>
            </td>
            <td style="max-width:190px">
              <a href="<?php echo e($l['url']); ?>" target="_blank" rel="noopener" style="color:var(--violet);font-size:12.5px;word-break:break-all"><?php echo e($lHost); ?></a>
              <?php if (!empty($l['check_result'])): ?>
                <div style="font-size:11px;color:var(--muted);margin-top:3px"><?php echo e(excerpt_text($l['check_result'], 40)); ?></div>
              <?php endif; ?>
            </td>
            <td>
              <span class="pill <?php echo ($l['status'] ?? 'approved') === 'approved' ? 'ok' : 'warn'; ?>">
                <?php echo ($l['status'] ?? 'approved') === 'approved' ? '已通过' : '待审核'; ?>
              </span>
            </td>
            <td>
              <div class="acts">
                <a class="btn ghost sm" href="links.php?edit=<?php echo (int)$l['id']; ?><?php echo $stf ? '&status=' . e($stf) : ''; ?>">编辑</a>
                <?php if (($l['status'] ?? '') !== 'approved'): ?>
                <form method="post">
                  <?php echo csrf_field(); ?><input type="hidden" name="act" value="status"><input type="hidden" name="status" value="approved">
                  <input type="hidden" name="id" value="<?php echo (int)$l['id']; ?>">
                  <button class="btn sm" type="submit">通过</button>
                </form>
                <?php else: ?>
                <form method="post">
                  <?php echo csrf_field(); ?><input type="hidden" name="act" value="status"><input type="hidden" name="status" value="pending">
                  <input type="hidden" name="id" value="<?php echo (int)$l['id']; ?>">
                  <button class="btn ghost sm" type="submit">下架</button>
                </form>
                <?php endif; ?>
                <form method="post" onsubmit="return confirm('访问对方站点检测是否已加本站链接？')">
                  <?php echo csrf_field(); ?><input type="hidden" name="act" value="check">
                  <input type="hidden" name="id" value="<?php echo (int)$l['id']; ?>">
                  <button class="btn ghost sm" type="submit">检测回链</button>
                </form>
                <form method="post" onsubmit="return confirm('删除该友链？')">
                  <?php echo csrf_field(); ?><input type="hidden" name="act" value="delete">
                  <input type="hidden" name="id" value="<?php echo (int)$l['id']; ?>">
                  <button class="btn danger sm" type="submit">删除</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
(function () {
  var file = document.getElementById('logoFile'),
      input = document.getElementById('logoInput'),
      prev = document.getElementById('logoPrev'),
      msg = document.getElementById('logoMsg');
  if (!file || !input) return;
  input.addEventListener('input', function () {
    prev.innerHTML = this.value.trim() ? '<img src="' + this.value.trim() + '" style="width:100%;height:100%;object-fit:cover">' : '🌸';
  });
  file.addEventListener('change', function () {
    if (!this.files[0]) return;
    var fd = new FormData(), xhr = new XMLHttpRequest();
    fd.append('file', this.files[0]);
    fd.append('_token', '<?php echo csrf_token(); ?>');
    msg.textContent = '上传中…';
    xhr.open('POST', 'upload.php');
    xhr.onload = function () {
      try {
        var d = JSON.parse(xhr.responseText);
        if (d.ok) {
          input.value = d.url;
          prev.innerHTML = '<img src="' + d.url + '" style="width:100%;height:100%;object-fit:cover">';
          msg.textContent = '✅ 上传成功，记得保存'; msg.style.color = '#3fb984';
        } else { msg.textContent = '❌ ' + d.msg; msg.style.color = '#e0566b'; }
      } catch (e) { msg.textContent = '❌ 上传失败'; msg.style.color = '#e0566b'; }
    };
    xhr.send(fd);
  });
})();
</script>

<?php include 'includes/footer.php'; ?>
