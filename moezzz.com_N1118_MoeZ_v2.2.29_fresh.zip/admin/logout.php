<?php
/** 退出登录 */
require dirname(__DIR__) . '/init.php';
$_SESSION = array();
session_destroy();
header('Location: login.php');
exit;
