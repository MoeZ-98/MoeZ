<?php
/**
 * 后台 · Ajax 上传（图片 / 视频 / 音频 / 文档 / 压缩包）
 * 大小上限在 后台设置 → 上传设置 中配置（upload_max_mb）
 * 2.0.4：scope=attach 由「资源媒体库」调用，放行全部附件类型；
 *        编辑器封面等普通上传仍只允许图片 / 视频，并在拒绝时给出准确提示。
 * 2.2.30 工程化：命名与落盘统一走 includes/upload.php（参照 emlog upload()/checkUpload()），
 *        鉴权 / CSRF / 白名单 / 大小 / 返回字段全部保持原样。
 */
define('MOE_ADMIN', true);
require dirname(__DIR__) . '/init.php';
require_once dirname(__DIR__) . '/includes/upload.php';
require_admin();
csrf_verify();

header('Content-Type: application/json; charset=utf-8');

function up_fail($msg) { json_exit(false, $msg); }

/* ---------- 允许的类型 ---------- */
$IMG = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg', 'bmp', 'ico');
$VID = array('mp4', 'webm', 'm4v', 'mov', 'm3u8');
// 1.8.4：附件模式（scope=attach）额外放行 文档 / 音频 / 压缩包 等常见类型
$DOC = array('pdf', 'txt', 'md', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'csv', 'epub');
$AUD = array('mp3', 'wav', 'flac', 'ogg', 'm4a', 'aac');
$ARC = array('zip', 'rar', '7z', 'tar', 'gz');
$attach = (($_POST['scope'] ?? '') === 'attach');

if (empty($_FILES['file'])) up_fail('没有收到文件');
$f = $_FILES['file'];

/* 上传中断 / 超出 PHP 自身限制时给出友好提示 */
if ($f['error'] === UPLOAD_ERR_INI_SIZE) up_fail('文件超过服务器 PHP 限制（upload_max_filesize），请调大 PHP 配置');
if ($f['error'] === UPLOAD_ERR_PARTIAL)   up_fail('上传不完整，请重试或调小文件');
if ($f['error'] !== UPLOAD_ERR_OK)        up_fail('上传出错（代码 ' . $f['error'] . '）');

$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
$isImg = in_array($ext, $IMG, true);
$isVid = in_array($ext, $VID, true);
$isDoc = $attach && in_array($ext, $DOC, true);
$isAud = $attach && in_array($ext, $AUD, true);
$isArc = $attach && in_array($ext, $ARC, true);
if (!$isImg && !$isVid && !$isDoc && !$isAud && !$isArc) {
    up_fail($attach
        ? '不支持 .' . $ext . '：媒体库支持图片 jpg/png/gif/webp/avif/svg/bmp/ico、视频 mp4/webm/m4v/mov/m3u8、'
          . '音频 mp3/wav/flac/ogg/m4a/aac、文档 pdf/txt/md/doc/docx/xls/xlsx/ppt/pptx/csv/epub、压缩包 zip/rar/7z/tar/gz'
        : '仅支持图片 jpg/jpeg/png/gif/webp/avif/svg/bmp/ico 或视频 mp4/webm/m4v/mov/m3u8；'
          . '上传文档 / 音频 / 压缩包请点编辑器里的「📎 附件」打开资源媒体库');
}

/* 大小校验：后台可配置（默认 50MB） */
$maxMb = (int)setting('upload_max_mb', 50);
if ($maxMb < 1) $maxMb = 1;
if ($f['size'] > $maxMb * 1024 * 1024) {
    up_fail('文件超过 ' . $maxMb . 'MB 限制（可在 设置 → 上传设置 调整）');
}

/* 图片做真实内容校验；视频只按扩展名放行 */
if ($isImg && $ext !== 'svg') {
    $info = @getimagesize($f['tmp_name']);
    if ($info === false) up_fail('文件不是有效的图片');
}

/* 统一服务：真实 MIME / SVG 脚本扫描 + 按 YYYYMM 归档 + 原名/数字编号命名 + 落盘 */
$bad = moe_up_check($f, $ext, $isImg);
if ($bad !== '') up_fail($bad);

$sub = $isVid ? 'video' : ($isImg ? 'image' : ($isAud ? 'audio' : ($isArc || $isDoc ? 'file' : 'file')));
$res = moe_up_store($f, $sub, $f['name'], $ext);
if (!$res['ok']) up_fail($res['msg']);

json_exit(true, '上传成功', array(
    'url'  => $res['url'],
    'name' => $res['display'],
    'type' => $isVid ? 'video' : ($isImg ? 'image' : ($isAud ? 'audio' : 'file')),
));
