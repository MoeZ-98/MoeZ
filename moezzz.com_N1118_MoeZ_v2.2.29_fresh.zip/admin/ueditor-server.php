<?php
/**
 * 后台 · UEditorPlus 富文本编辑器上传服务端（2.2.22）
 * ------------------------------------------------------------
 * 实现 UEditor 前端协议：
 *   GET  ?action=config                  → 返回上传配置（动作名 / 字段名 / 大小 / 白名单）
 *   POST ?action=uploadimage|uploadvideo|uploadfile（字段 upfile）→ 保存并返回 UEditor 格式 JSON
 * 仅站长可用（require_admin）；CSRF 通过 serverUrl 上的 _token 参数校验；
 * 文件规则与 admin/upload.php 保持一致（类型白名单 + upload_max_mb 上限 + 按月归档）。
 * 2.2.30 工程化：命名与落盘统一走 includes/upload.php。
 */
define('MOE_ADMIN', true);
require dirname(__DIR__) . '/init.php';
require_once dirname(__DIR__) . '/includes/upload.php';
require_admin();

/* CSRF：UEditor 无法带自定义请求头，走 serverUrl 查询参数 */
$t = (string)($_REQUEST['_token'] ?? '');
if ($t === '' || !hash_equals((string)($_SESSION['moe_csrf'] ?? ''), $t)) {
    ue_out(array('state' => '令牌校验失败，请刷新编辑器页面重试'));
}

header('Content-Type: application/json; charset=utf-8');

function ue_out($payload)
{
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

/* ---------- 允许的类型（与 admin/upload.php 对齐） ---------- */
$IMG = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'bmp', 'ico');
$VID = array('mp4', 'webm', 'm4v', 'mov');
$ARC_DOC = array('zip', 'rar', '7z', 'tar', 'gz', 'pdf', 'txt', 'md', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'csv', 'epub', 'mp3', 'wav', 'flac', 'ogg', 'm4a', 'aac', 'svg');

$action = (string)($_GET['action'] ?? ($_POST['action'] ?? ''));

/* ---------- 配置下发 ---------- */
if ($action === 'config') {
    $maxBytes = max(1, (int)setting('upload_max_mb', 50)) * 1024 * 1024;
    $allowImg = preg_replace('/^([^\.]+)/', '.$1', $IMG);
    $allowVid = preg_replace('/^([^\.]+)/', '.$1', $VID);
    $allowFil = preg_replace('/^([^\.]+)/', '.$1', $ARC_DOC);
    ue_out(array(
        'state' => 'SUCCESS',
        'imageActionName' => 'uploadimage', 'imageFieldName' => 'upfile', 'imageMaxSize' => $maxBytes, 'imageAllowFiles' => array_values($allowImg), 'imageCompressEnable' => false, 'imageInsertAlign' => 'none', 'imageUrlPrefix' => '',
        'videoActionName' => 'uploadvideo', 'videoFieldName' => 'upfile', 'videoMaxSize' => $maxBytes, 'videoAllowFiles' => array_values($allowVid),
        'fileActionName' => 'uploadfile', 'fileFieldName' => 'upfile', 'fileMaxSize' => $maxBytes, 'fileAllowFiles' => array_values($allowFil),
        'catcherActionName' => 'catchimage', 'catcherLocalDomain' => array(), 'catcherAllowFiles' => array('.jpg', '.png', '.gif', '.webp'),
    ));
}

/* ---------- 上传 ---------- */
if (!in_array($action, array('uploadimage', 'uploadvideo', 'uploadfile', 'uploadscrawl'), true)) {
    ue_out(array('state' => '不支持的操作：' . $action));
}
if ($action === 'uploadscrawl') ue_out(array('state' => '不支持涂鸦功能，请直接上传图片'));

$map = array('uploadimage' => $IMG, 'uploadvideo' => $VID, 'uploadfile' => $ARC_DOC);
$allow = $map[$action];

if (empty($_FILES['upfile'])) ue_out(array('state' => '没有收到文件'));
$f = $_FILES['upfile'];
if ($f['error'] === UPLOAD_ERR_INI_SIZE) ue_out(array('state' => '文件超过服务器 PHP 限制（upload_max_filesize）'));
if ($f['error'] !== UPLOAD_ERR_OK)       ue_out(array('state' => '上传出错（代码 ' . $f['error'] . '）'));

$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
if (!in_array($ext, $allow, true)) ue_out(array('state' => '不支持 .' . $ext . ' 文件'));

$maxMb = max(1, (int)setting('upload_max_mb', 50));
if ($f['size'] > $maxMb * 1024 * 1024) ue_out(array('state' => '文件超过 ' . $maxMb . 'MB 限制（可在 设置 → 上传设置 调整）'));

if (in_array($ext, array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'), true)) {
    $info = @getimagesize($f['tmp_name']);
    if ($info === false) ue_out(array('state' => '文件不是有效的图片'));
}

/* 统一服务：真实 MIME / SVG 脚本扫描 + 按 YYYYMM 归档 + 原名/数字编号命名 + 落盘 */
$bad = moe_up_check($f, $ext, in_array($ext, $IMG, true));
if ($bad !== '') ue_out(array('state' => $bad));

$sub = in_array($ext, $VID, true) ? 'video' : (in_array($ext, $IMG, true) ? 'image' : 'file');
$res = moe_up_store($f, $sub, $f['name'], $ext);
if (!$res['ok']) ue_out(array('state' => $res['msg']));

ue_out(array(
    'state'    => 'SUCCESS',
    'url'      => $res['url'],
    'title'    => $res['stem'],
    'original' => $res['stem'],
    'size'     => (int)$f['size'],
    'type'     => '.' . $ext,
));
