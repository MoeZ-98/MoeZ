<?php
/**
 * 后台 · 金币充值面板（2.2.4）
 * ------------------------------------------------------------
 * 被积分商城页（points.php?tab=recharge）引用，不再是独立菜单页。
 * admin/recharge.php 保留为 301 跳转，兼容旧链接。
 * 提供：收款设置（比例 / 收款码 / 第三方网关 / 回调密钥）+ 充值订单管理。
 */
if (!defined('MOE_ADMIN')) exit;

function moe_recharge_handle_post()
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
    csrf_verify();
    $act = (string)($_POST['act'] ?? '');
    if ($act === 'save_settings') {
        setting_set('recharge_on', (string)($_POST['on'] ?? '0') === '1' ? '1' : '0');
        setting_set('recharge_rate', (string)max(0.01, (float)($_POST['rate'] ?? 1)));
        // 2.2.20：多张收款码 —— textarea 每行一个地址（最多 5 张），兼容旧单码字段
        $qrs = array();
        foreach (preg_split('/\r\n|\r|\n/', (string)($_POST['qrcodes'] ?? '')) as $line) {
            $line = trim($line);
            if ($line !== '' && ($line[0] === '/' || preg_match('#^https?://#i', $line))) $qrs[] = $line;
            if (count($qrs) >= 5) break;
        }
        setting_set('recharge_qrcodes', $qrs ? json_encode($qrs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : '');
        setting_set('recharge_qrcode', $qrs ? $qrs[0] : trim((string)($_POST['qrcode'] ?? '')));   // 兼容旧字段
        setting_set('recharge_api_url', trim((string)($_POST['api'] ?? '')));
        $secret = trim((string)($_POST['secret'] ?? ''));
        if ($secret !== '' && (string)($_POST['secret_old'] ?? '') === '' && (string)setting('recharge_secret', '') === '') {
            setting_set('recharge_secret', $secret);
        } elseif ((string)($_POST['secret_reset'] ?? '') === '1') {
            setting_set('recharge_secret', $secret !== '' ? $secret : bin2hex(function_exists('random_bytes') ? random_bytes(16) : md5(uniqid('', true) . mt_rand())));
        }
        flash('收款设置已保存');
        redirect('points.php?tab=recharge');
    }
    if ($act === 'approve' || $act === 'reject') {
        $r = moe_rc_admin_review(trim((string)($_POST['no'] ?? '')), $act, (string)($_POST['reason'] ?? ''));
        flash((string)$r['msg'], !empty($r['ok']) ? 'ok' : 'bad');
        redirect('points.php?tab=recharge');
    }
    redirect('points.php?tab=recharge');
}

function moe_recharge_render()
{
    if (!function_exists('moe_rc_orders_load')) {
        return '<div class="card"><p class="hint">充值模块缺失：请重新上传 includes/recharge.php</p></div>';
    }
    $orders  = moe_rc_orders_load();
    $pendingN = 0;
    foreach ($orders as $o) if (($o['status'] ?? '') === 'pending') $pendingN++;
    $users = array();
    foreach ($orders as $o) {
        $uid = (int)($o['user_id'] ?? 0);
        if ($uid && !isset($users[$uid])) {
            $uu = moe_user_by($uid);
            $users[$uid] = $uu ? (moe_user_display($uu) . '(@' . $uu['username'] . ')') : ('用户 #' . $uid);
        }
    }
    $secretSet = trim((string)setting('recharge_secret', '')) !== '';
    ob_start();
?>
<div class="card" style="background:linear-gradient(135deg,#fff8ec,#fdf0ff)">
  <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">
    <span style="font-size:30px">💰</span>
    <div>
      <h2 style="font-size:15.5px">金币充值<?php echo $pendingN ? ' · <span style="color:#a8791c">' . $pendingN . ' 笔待确认</span>' : ''; ?></h2>
      <p style="font-size:12.5px;color:var(--muted)">用户在前台商城页扫码或在线支付充值，到账自动刷新。第三方网关回调地址：<code><?php echo e(base_url()); ?>pay/pay-notify.php</code>（旧地址 /pay-notify.php 仍然兼容，网关后台已配置的不用改）</p>
    </div>
  </div>
</div>

<div class="card">
  <h2 class="card-title">⚙ 收款设置</h2>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="save_settings">
    <div style="display:flex;gap:14px;flex-wrap:wrap">
      <div style="flex:1;min-width:220px">
        <label style="display:flex;gap:8px;align-items:center;font-weight:600;font-size:13px">
          <input type="checkbox" name="on" value="1" <?php echo setting('recharge_on', '0') === '1' ? 'checked' : ''; ?>> 开启用户充值
        </label>
        <p style="font-size:12.5px;color:var(--muted);margin:10px 0 0">充值比例（元 = 金币）</p>
        <input type="number" name="rate" step="0.01" min="0.01" value="<?php echo e(setting('recharge_rate', '1')); ?>"
               style="width:120px;padding:8px 10px;border:1.5px solid #e8e2f0;border-radius:9px;margin-top:4px">
      </div>
      <div style="flex:1;min-width:260px">
        <p style="font-size:12.5px;color:var(--muted);margin:0 0 4px">收款二维码图片地址（可填多张，每行一个，最多 5 张）</p>
        <?php
          $__qrList = array();
          $__qrJson = trim((string)setting('recharge_qrcodes', ''));
          if ($__qrJson !== '') $__qrList = (array)json_decode($__qrJson, true);
          if (!$__qrList && trim((string)setting('recharge_qrcode', '')) !== '') $__qrList = array(trim((string)setting('recharge_qrcode', '')));
        ?>
        <textarea name="qrcodes" rows="4" spellcheck="false" placeholder="https://.../qr-wechat.png&#10;https://.../qr-alipay.png 或站内图片地址"
                  style="width:100%;padding:8px 10px;border:1.5px solid #e8e2f0;border-radius:9px;font-family:inherit"><?php echo e(implode("\n", $__qrList)); ?></textarea>
        <p style="font-size:12.5px;color:var(--muted);margin:6px 0 0">用户端会以页签方式展示多张收款码（微信 / 支付宝 / QQ 各一张更方便）。留空则前台不显示扫码支付。</p>
        <p style="font-size:12.5px;color:var(--muted);margin:8px 0 0">第三方支付网关地址（自动到账，无需站长确认）</p>
        <input type="text" name="api" value="<?php echo e(setting('recharge_api_url', '')); ?>" placeholder="https://pay.example.com/submit" spellcheck="false"
               style="width:100%;padding:8px 10px;border:1.5px solid #e8e2f0;border-radius:9px">
      </div>
    </div>
    <div style="margin-top:12px">
      <p style="font-size:12.5px;color:var(--muted);margin:0 0 4px">
        回调密钥 <?php echo $secretSet ? '<span style="color:#268a5b">已配置（勾选下方重置可更换）</span>' : '（未配置，第三方模式不可用）'; ?>
      </p>
      <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
        <input type="text" name="secret" placeholder="留空则忽略" spellcheck="false"
               style="width:280px;padding:8px 10px;border:1.5px solid #e8e2f0;border-radius:9px">
        <label style="font-size:12.5px;display:flex;gap:6px;align-items:center">
          <input type="checkbox" name="secret_reset" value="1"> 重置（留空则自动生成新密钥）
        </label>
      </div>
    </div>
    <div style="margin-top:14px"><button class="btn sm" type="submit">💾 保存设置</button></div>
  </form>
</div>

<div class="card">
  <h2 class="card-title">🧾 充值订单</h2>
  <?php if (!$orders): ?>
    <p class="hint">暂无充值订单。</p>
  <?php else: ?>
    <table style="width:100%;border-collapse:collapse;font-size:13px">
      <tr style="color:var(--muted);text-align:left">
        <th style="padding:8px 6px">时间</th><th>用户</th><th>金额</th><th>金币</th><th>单号 / 凭证</th><th>状态</th><th>操作</th>
      </tr>
      <?php foreach ($orders as $o): $st = (string)($o['status'] ?? ''); ?>
        <tr style="border-top:1px solid var(--line,#eee)">
          <td style="padding:9px 6px"><?php echo e($o['time'] ?? ''); ?></td>
          <td><?php echo e($users[(int)($o['user_id'] ?? 0)] ?? ('用户 #' . (int)($o['user_id'] ?? 0))); ?></td>
          <td>¥<?php echo e($o['amount'] ?? ''); ?></td>
          <td>+<?php echo e($o['coins'] ?? ''); ?></td>
          <td style="font-family:monospace;font-size:12px">
            <?php echo e(($o['trans'] ?? '') !== '' ? $o['trans'] : $o['no'] ?? ''); ?>
            <?php if (($o['contact'] ?? '') !== ''): ?><br><small style="color:var(--muted)">联系：<?php echo e($o['contact']); ?></small><?php endif; ?>
          </td>
          <td>
            <?php if ($st === 'approved'): ?><span style="color:#268a5b">✓ 已到账</span>
            <?php elseif ($st === 'rejected'): ?><span style="color:#d9506b">已驳回<?php echo ($o['done_note'] ?? '') !== '' ? '（' . e($o['done_note']) . '）' : ''; ?></span>
            <?php else: ?><span style="color:#a8791c">待确认</span><?php endif; ?>
          </td>
          <td style="white-space:nowrap">
            <?php if ($st === 'pending'): ?>
              <form method="post" style="display:inline" onsubmit="return confirm('确认该订单已收到款并加金币？')">
                <?php echo csrf_field(); ?><input type="hidden" name="act" value="approve">
                <input type="hidden" name="no" value="<?php echo e($o['no'] ?? ''); ?>">
                <button class="btn sm" type="submit">✓ 确认到账</button>
              </form>
              <form method="post" style="display:inline;margin-left:6px" onsubmit="var r=prompt('驳回原因（选填）');if(r===null)return false;this.querySelector('[name=reason]').value=r">
                <?php echo csrf_field(); ?><input type="hidden" name="act" value="reject">
                <input type="hidden" name="no" value="<?php echo e($o['no'] ?? ''); ?>">
                <input type="hidden" name="reason" value="">
                <button class="btn ghost sm" type="submit">驳回</button>
              </form>
            <?php else: ?>
              <small style="color:var(--muted)"><?php echo e($o['done_at'] ?? ''); ?></small>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </table>
    <p class="hint" style="margin-top:10px">订单保存在 <code>content/recharge/orders.json</code>；「确认到账」写入金币流水（类型 recharge），重复确认不会重复入账；确认后用户页面会在 4 秒内自动刷新到账。</p>
  <?php endif; ?>
</div>
<?php
    return ob_get_clean();
}
