    </div><!-- /.content -->
  </div><!-- /.main -->
</div><!-- /.frame -->
<script>
/* 2.2.16 · 后台弹窗居中：接管原生 alert（浏览器原生弹窗位置不可控），
   改用屏幕正中央的模态框展示，支持 ESC / 点遮罩关闭。
   2.2.16：alert 支持第二个回调参数 alert(msg, cb)——用户点「确定」后才执行 cb。
   原生 alert 是阻塞的，之前接管后变成非阻塞，「alert 后立即 reload」的旧代码
   会瞬间刷新页面、弹窗一闪而过甚至来不及显示（模板/插件更新结果提示丢失）。
   旧调用 alert(msg) 行为不变；新调用 alert(msg, function(){ location.reload(); })
   会等用户点确定后再刷新。 */
(function () {
  'use strict';
  var native = window.alert;
  var ov = null, txt = null, btn = null, pending = null;

  function build() {
    ov = document.createElement('div');
    ov.style.cssText = 'position:fixed;inset:0;background:rgba(15,18,34,.45);z-index:2147483647;'
      + 'display:none;align-items:center;justify-content:center;animation:moeAlertFade .18s ease;';
    var box = document.createElement('div');
    box.style.cssText = 'max-width:min(560px,86vw);background:#fff;border-radius:14px;'
      + 'box-shadow:0 18px 50px rgba(15,18,34,.35);padding:22px 24px 18px;'
      + 'font:14px/1.7 system-ui,-apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;color:#2b3252;'
      + 'animation:moeAlertPop .18s ease;';
    txt = document.createElement('div');
    txt.style.cssText = 'white-space:pre-wrap;word-break:break-word;max-height:56vh;overflow:auto;';
    btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = '确定';
    btn.style.cssText = 'display:block;margin:16px 0 0 auto;padding:7px 26px;border:0;border-radius:9px;'
      + 'background:linear-gradient(135deg,#7c5cff,#5aa2ff);color:#fff;font-size:14px;font-weight:600;cursor:pointer;';
    box.appendChild(txt); box.appendChild(btn); ov.appendChild(box);
    document.body.appendChild(ov);
    btn.addEventListener('click', close);
    ov.addEventListener('click', function (e) { if (e.target === ov) close(); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && ov.style.display === 'flex') close();
    });
  }
  function close() {
    if (ov) ov.style.display = 'none';
    if (typeof pending === 'function') { var cb = pending; pending = null; try { cb(); } catch (e) {} }
  }

  var st = document.createElement('style');
  st.textContent = '@keyframes moeAlertFade{from{opacity:0}to{opacity:1}}'
    + '@keyframes moeAlertPop{from{opacity:0;transform:scale(.94) translateY(8px)}to{opacity:1;transform:none}}';
  document.head.appendChild(st);

  window.alert = function (m, cb) {
    try {
      if (!ov) build();
      pending = typeof cb === 'function' ? cb : null;
      txt.textContent = String(m == null ? '' : m);
      ov.style.display = 'flex';
      btn.focus();
    } catch (e) { native(String(m)); if (typeof cb === 'function') cb(); }
  };
  window.moeAlert = window.alert;   /* 别名，便于需要回调语义的代码显式使用 */
})();
</script>
<script>
/* 1.9.6 · 手机端表格自动卡片化（1.9.1 引入，1.9.6 重构）
   把 <thead> 列名写进每个 <td data-label="…">，
   配合 admin.css ≤700px 时显示「字段名 → 值」卡片，
   并给标题列 / 勾选列 / 操作列打标记。纯展示层，不改数据。 */
(function () {
  'use strict';

  function labelizeTable(tb) {
    var ths = [];
    Array.prototype.forEach.call(tb.querySelectorAll('thead th'), function (th) {
      ths.push((th.textContent || '').replace(/\s+/g, ' ').trim());
    });
    Array.prototype.forEach.call(tb.querySelectorAll('tbody tr'), function (tr) {
      Array.prototype.forEach.call(tr.children, function (td, i) {
        if (td.tagName !== 'TD') return;
        if (!td.hasAttribute('data-label')) td.setAttribute('data-label', ths[i] || '');
        // 空表头的勾选列自动识别
        if (!ths[i] && td.querySelector('input[type=checkbox],input[type=radio]')) {
          td.classList.add('cell-check');
        }
        if (td.classList.contains('t-title') || td.querySelector('.t-title')) td.classList.add('cell-title');
        if (td.classList.contains('acts') || td.querySelector('.acts')) td.classList.add('cell-acts');
      });
    });
  }

  function labelize() {
    var tables = document.querySelectorAll('table.tbl');
    for (var i = 0; i < tables.length; i++) labelizeTable(tables[i]);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', labelize);
  } else {
    labelize();
  }
})();
</script>
<?php if (function_exists('moe_plugin_render')) echo moe_plugin_render('admin_footer'); ?>
</body>
</html>
