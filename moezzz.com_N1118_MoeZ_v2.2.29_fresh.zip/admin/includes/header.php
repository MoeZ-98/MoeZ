<?php
/**
 * 后台公共布局：侧边栏 + 顶栏（页面设置 $active 与 $page_title 后引入）
 * @var string $active @var string $page_title
 * 1.6.6：模板设置并入模板管理（吸附式面板）；后台配色 / logo 可自定义
 * 2.0.3：仪表盘更新区样式改版，CSS 版本号升 v=14 强制刷新浏览器缓存
 * 2.0.4：编辑器资源媒体库弹窗样式，CSS 版本号升 v=15
 */
$me = current_user();
$pending = (int)one('SELECT COUNT(*) FROM ' . moe_table('comments') . " WHERE status='pending'");
$menu = array(
    // ── 概览 ──
    'index'       => array('📊', '仪表盘', 'index.php'),
    // ── 内容管理 ──
    'posts'       => array('📝', '文章管理', 'posts.php'),
    'pages'       => array('📄', '独立页面', 'pages.php'),
    'cats'        => array('🗂', '分类管理', 'categories.php'),
    'tags'        => array('🏷', '标签管理', 'tags.php'),
    'resources'   => array('📁', '资源管理', 'resources.php'),
    // ── 互动管理 ──
    'comments'    => array('💬', '评论管理', 'comments.php'),
    'links'       => array('🔗', '友情链接', 'links.php'),
    'spiders'     => array('🕷', '蜘蛛来访', 'spiders.php'),
    // ── 外观与扩展 ──
    'themes'      => array('🎨', '模板管理', 'themes.php'),
    'themeopts'   => array('🖌', '模板设置', 'theme-settings.php'),
    'plugins'     => array('🧩', '插件管理', 'plugins.php'),       // 2.0.2
    // ── 商城与用户 ──
    'points'      => array('🛒', '积分商城', 'points.php'),        // 2.1.0 核心模块（不依赖模板；2.2.4 充值并入本页 tab）
    'users'       => array('👥', '用户管理', 'users.php'),         // 2.0.0
    'profile'     => array('👤', '用户中心', 'profile.php'),      // 2.0.0
    // ── 系统 ──
    'settings'    => array('⚙️', '站点设置', 'settings.php'),
);
/* 2.2.20：侧栏菜单分组显示（相关菜单放一起，组与组之间有小标题分隔） */
$moeMenuGroups = array(
    'index'     => '概览',
    'posts'     => '内容管理',
    'comments'  => '互动管理',
    'themes'    => '外观与扩展',
    'points'    => '商城与用户',
    'settings'  => '系统',
);
// 2.0.0：作者只看得到内容类菜单；站点设置 / 模板 / 用户管理等仅站长可见
if (function_exists('moe_is_owner') && !moe_is_owner()) {
    $__ownerKeys = array('cats', 'tags', 'resources', 'spiders', 'links', 'themes', 'themeopts', 'points', 'users', 'settings', 'plugins');
    foreach ($__ownerKeys as $__k) unset($menu[$__k]);
    unset($__ownerKeys, $__k);
}
// 2.0.2：插件钩子 —— 可往后台菜单追加入口，返回菜单数组；返回值异常时保留原菜单
if (function_exists('moe_plugin_apply')) {
    $__pm = moe_plugin_apply('admin_menu', $menu);
    if (is_array($__pm)) $menu = $__pm;
    unset($__pm);
}

// 后台配色（预设 / 自定义三色，作用于 --pink / --violet / --blue）
$__accents = array(
    'sakura' => array('#ff7eb3', '#a18cd1', '#8ec5fc'),  // 🌸 樱花粉紫（默认）
    'sunset' => array('#ff9a6c', '#ff6f91', '#ffc36c'),  // 🌅 落日橙红
    'sky'    => array('#5ba7ff', '#7cc6ee', '#6ee0d5'),  // 🌊 晴空海蓝
    'mint'   => array('#4fd1a5', '#63c7b2', '#9be15d'),  // 🍃 薄荷青绿
    'grape'  => array('#7f6bff', '#b06cf0', '#f06cf0'),  // 🍇 暗夜葡萄
);
$__accentCss = '';
$__ak = trim((string)setting('admin_accent', ''));
if ($__ak !== '' && $__ak !== 'sakura') {
    if ($__ak === 'custom') {
        $__c = array(setting('admin_c1', '#ff7eb3'), setting('admin_c2', '#a18cd1'), setting('admin_c3', '#8ec5fc'));
    } else {
        $__c = isset($__accents[$__ak]) ? $__accents[$__ak] : null;
    }
    if ($__c) {
        $__ok = true;
        foreach ($__c as $__cv) { if (!preg_match('/^#[0-9a-fA-F]{6}$/', trim($__cv))) { $__ok = false; break; } }
        if ($__ok) {
            $__accentCss = '<style>:root{--pink:' . trim($__c[0]) . ';--violet:' . trim($__c[1])
                         . ';--blue:' . trim($__c[2]) . ';}</style>';
        }
    }
}
$__adminLogo = trim((string)setting('admin_logo', ''));
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo e(isset($page_title) ? $page_title . ' · ' : ''); ?>萌Z MoeZ 管理中心</title>
<script>try{if(localStorage.getItem('moe_admin_layout')==='top')document.documentElement.classList.add('layout-top');}catch(e){}</script>
<link rel="stylesheet" href="assets/admin.css?v=16">
<?php echo $__accentCss; ?>
</head>
<body>
<div class="frame">
  <aside class="side">
    <a class="brand" href="index.php" title="返回仪表盘" aria-label="返回仪表盘">
      <?php if ($__adminLogo !== ''): ?>
        <img src="<?php echo e(media_url($__adminLogo)); ?>" alt="logo" style="width:30px;height:30px;border-radius:9px;object-fit:cover">
      <?php else: ?>
        <span class="mark">🌸</span>
      <?php endif; ?>
      <span>萌Z <small style="font-size:11px;opacity:.75;font-weight:400">MoeZ</small></span>
    </a>
    <div class="sep"></div>
    <nav>
      <?php $__lastGroup = ''; foreach ($menu as $k => $m):
        if (isset($moeMenuGroups[$k]) && $moeMenuGroups[$k] !== $__lastGroup) {
          $__lastGroup = $moeMenuGroups[$k];
          echo '<div class="menu-group-title">' . e($__lastGroup) . '</div>';
        } ?>
        <a class="<?php echo isset($active) && $active === $k ? 'cur' : ''; ?>" href="<?php echo e($m[2]); ?>">
          <span><?php echo $m[0]; ?></span><?php echo e($m[1]); ?>
          <?php if ($k === 'comments' && $pending > 0): ?><span class="badge"><?php echo $pending; ?></span><?php endif; ?>
        </a>
      <?php endforeach; ?>
    </nav>
    <style>
      /* 2.2.20：侧栏分组小标题 */
      .menu-group-title{font-size:10.5px;color:rgba(255,255,255,.42);padding:12px 14px 4px;letter-spacing:1px;user-select:none}
      nav a:first-of-type{margin-top:0}
    </style>
    <div class="side-foot">
      <?php /* 程序作者署名：樊不烦 开发制作（仅保留在代码中，不在界面展示） */ ?>
      萌Z MoeZ v<?php echo MOE_VERSION; ?><br>
      <a href="<?php echo e(base_url()); ?>" target="_blank">查看站点 ↗</a>
    </div>
  </aside>
  <div class="side-mask" id="sideMask"></div>
  <script>
  /* 手机端抽屉侧边栏：☰ 开 / 点遮罩或菜单项收
     注意：本段脚本在顶栏按钮之前解析，必须等 DOM 就绪再取元素，否则 #navToggle 取不到 */
  document.addEventListener('DOMContentLoaded', function () {
    var t = document.getElementById('navToggle'),
        s = document.querySelector('.side'),
        m = document.getElementById('sideMask');
    if (!t || !s || !m) return;
    function close() {
      s.classList.remove('open'); m.classList.remove('show');
      document.body.classList.remove('nav-open');
    }
    var lb = document.getElementById('layoutToggle');
    if (lb) lb.addEventListener('click', function () {
      var on = document.documentElement.classList.toggle('layout-top');
      try { localStorage.setItem('moe_admin_layout', on ? 'top' : 'side'); } catch (e2) {}
      /* 切到顶栏模式时清掉抽屉残留，避免 body 被锁滚动 */
      s.classList.remove('open'); m.classList.remove('show');
      document.body.classList.remove('nav-open');
    });

    t.addEventListener('click', function (e) {
      e.preventDefault();
      var on = s.classList.toggle('open');
      m.classList.toggle('show', on);
      document.body.classList.toggle('nav-open', on);   /* 1.9.1：锁定背景滚动 */
    });
    m.addEventListener('click', close);
    s.addEventListener('click', function (e) {
      var a = e.target.closest ? e.target.closest('a') : null;
      if (a) close();
    });
    // 窗口放大回桌面尺寸时复位，避免残留 open / 遮罩
    window.addEventListener('resize', function () { if (window.innerWidth > 860) close(); });
  });
  </script>

  <div class="main">
    <div class="topbar">
      <button class="nav-toggle" id="navToggle" type="button" aria-label="打开菜单">☰</button>
      <div>
        <h1><?php echo e(isset($page_title) ? $page_title : '管理中心'); ?></h1>
        <div class="breadcrumb">MoeZ · <?php echo e(setting('site_name', '')); ?></div>
      </div>
      <div class="spacer"></div>
      <div class="top-actions">
        <div class="who">
          <span class="ava"><?php echo e(initial($me['username'])); ?></span>
          <?php echo e($me['username']); ?>
        </div>
        <!-- 2.0.2：切换侧栏 / 顶栏两种后台布局 -->
        <button type="button" class="btn ghost sm layout-btn" id="layoutToggle"
                title="切换后台布局（侧栏 / 顶栏）" aria-label="切换后台布局">
          <span class="lb-full">⇄ 布局</span><span class="lb-ico">⇄</span>
        </button>
        <!-- 1.9.7：顶栏前台预览入口；桌面显示全名，平板显示「预览」，手机收成图标 -->
        <a class="btn ghost sm top-view" href="<?php echo e(base_url()); ?>" target="_blank" rel="noopener"
           title="新窗口打开站点前台" aria-label="前台预览">
          <span class="tv-ico">🏠</span><span class="tv-full">前台预览</span><span class="tv-short">预览</span>
        </a>
        <a class="btn ghost sm" href="logout.php">退出</a>
      </div>
    </div>

    <div class="content">
    <?php foreach (take_flash() as $f): ?>
      <div class="alert <?php echo $f['type'] === 'bad' ? 'bad' : ($f['type'] === 'warn' ? 'warn' : 'ok'); ?>"><?php echo e($f['msg']); ?></div>
    <?php endforeach; ?>
