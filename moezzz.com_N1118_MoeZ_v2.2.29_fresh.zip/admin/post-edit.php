<?php
/**
 * 后台 · 发布 / 编辑文章与页面
 * Markdown 优先编辑器 + 实时预览 + SEO 面板
 * 2.0.4：附件上传改为「资源媒体库」弹窗（上传 / 搜索 / 插入文章 / 设为封面 / 删除），
 *        「📎 附件」与工具栏 📤 统一入口，修复附件被「仅支持图片/视频」挡住的问题。
 */
require __DIR__ . '/bootstrap.php';

// 就地兜底：本页强依赖 Markdown 内核（content_words / render_content）与 SEO 助手（post_url）
// 即使 init.php / bootstrap.php 仍是旧版，只要 includes/ 文件在，本页也能正常工作
if (!function_exists('content_words') && is_file(dirname(__DIR__) . '/includes/markdown.php')) {
    require_once dirname(__DIR__) . '/includes/markdown.php';
}
if (!function_exists('post_url') && is_file(dirname(__DIR__) . '/includes/seo.php')) {
    require_once dirname(__DIR__) . '/includes/seo.php';
}

$active = isset($_GET['type']) && $_GET['type'] === 'page' ? 'pages' : 'posts';

// 自动保存生成的草稿 id 通过隐藏域回传，编辑中途刷新也不丢
$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
$type = (($_GET['type'] ?? $_POST['type'] ?? 'post') === 'page') ? 'page' : 'post';
$post = null;
if ($id) {
    $post = row('SELECT * FROM ' . moe_table('posts') . ' WHERE id = ? AND type = ?', array($id, $type));
    if (!$post) { flash('内容不存在', 'bad'); redirect($type === 'page' ? 'pages.php' : 'posts.php'); }
    $active = $type === 'page' ? 'pages' : 'posts';
    // 「编辑草稿」副本（draft_of 指向原文）：状态与编号沿用原文，避免把线上文章误存成草稿、也避免给草稿占用编号
    if (!empty($post['draft_of'])) {
        $origPost = row('SELECT * FROM ' . moe_table('posts') . ' WHERE id = ? AND type = ?', array((int)$post['draft_of'], $type));
        if ($origPost) {
            $post['status']  = $origPost['status'];
            $post['url_num'] = $origPost['url_num'];
        }
    }
}
$page_title = $post ? '编辑' . ($type === 'page' ? '页面' : '文章') : '发布' . ($type === 'page' ? '页面' : '文章');

$cats = rows('SELECT * FROM ' . moe_table('categories') . ' ORDER BY sort, id');
// 2.2.22：UEditorPlus 富文本模式开关（站点设置 → 功能设置 → 正文编辑器）
$ueditor = function_exists('moe_editor_mode') && moe_editor_mode() === 'ueditor';

/**
 * 发布后自动推送该链接（仅在设置里开启「自动推送」时执行）
 * 只推百度 / 360 / 必应，搜狗为逐条提交会明显拖慢发布
 */
function moe_auto_push($url)
{
    if ((string)setting('seo_push_auto', '0') !== '1') return;
    $f = dirname(__DIR__) . '/includes/push.php';
    if (!is_file($f)) return;
    require_once $f;
    if (!function_exists('moe_push_urls')) return;
    @set_time_limit(60);
    $res = moe_push_urls(array($url), array('baidu', '360', 'bing'));
    if (function_exists('moe_push_log_results')) moe_push_log_results(1, $res);   // 2.2.8：自动推送也留档
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (function_exists('moe_content_changed')) moe_content_changed();   // 1.9.0：内容变更 → 清理统计/导航缓存与页面缓存
    $title = trim($_POST['title'] ?? '');
    $slug = trim($_POST['slug'] ?? '');
    $catId = (int)($_POST['category_id'] ?? 0);
    $excerpt = trim($_POST['excerpt'] ?? '');
    $content = (string)($_POST['content'] ?? '');
    // 2.2.22：编辑器可切换 —— UEditorPlus 产出 HTML，Markdown 编辑器产出 Markdown
    $format = function_exists('moe_editor_mode') && moe_editor_mode() === 'ueditor' ? 'html' : 'markdown';
    $cover = trim($_POST['cover'] ?? '');
    $statusIn = (string)($_POST['status'] ?? 'published');
    $status = in_array($statusIn, array('draft', 'pending'), true) ? $statusIn : 'published';
    // 2.2.22：原本是用户投稿的，站长在编辑器里改成「公开发布」即视为通过审核
    $wasPending = $post && (string)($post['status'] ?? '') === 'pending';
    $isTop = isset($_POST['is_top']) ? 1 : 0;
    // 1.8.3：文章标签（逗号分隔；自动去重 / 去空 / 最多 8 个）
    $tags = moe_tags_normalize((string)($_POST['tags'] ?? ''));
    // 1.9.4：发布时未填标签 → 自动生成核心标签（本地词频分析，无需外部接口）
    //   草稿不生成，转正发布时再补；手动填过的标签优先，不会被覆盖
    if ($tags === '' && $status === 'published' && trim($content) !== '' && function_exists('moe_auto_tags')) {
        $auto = moe_auto_tags($title, $content, 6);
        if (!empty($auto)) $tags = implode(',', array_slice($auto, 0, 8));
    }

    // 校验错误单独收集，不再依赖会话里的 flash（残留的旧提示会导致保存被静默跳过）
    $errs = moe_content_errors($type, $title, $content);
    // 别名自动净化（1.8.2）：不再「格式不对就拒绝保存」
    //   独立页面：允许中文，重名自动加 -2（支持 /别名 直接访问）
    //   文章：只保留 URL 安全字符，留空即无别名
    // 1.9.7：页面别名留空时直接用标题生成（中文可用），不再出现 page-随机串
    if ($type === 'page') {
        $slug = moe_page_slug_clean($slug);
        if ($slug === '' && $title !== '') {
            $slug = function_exists('moe_page_slug_from_title')
                ? moe_page_slug_from_title($title) : moe_page_slug_clean($title);
        }
        // 排除「本条」与它对应的原文（编辑草稿副本），避免误判重名后加上 -2
        $exIds = $post ? array((int)$post['id'], !empty($post['draft_of']) ? (int)$post['draft_of'] : 0) : array();
        $slug = moe_page_slug_unique($slug, $exIds);
    } elseif ($slug !== '') {
        $slug = trim(preg_replace('/[^a-zA-Z0-9_-]+/', '-', $slug), '-_');
        $slug = substr(strtolower($slug), 0, 100);
    }
    if ($excerpt === '' && trim($content) !== '') {
        $plain = content_plain($content, $format);
        $excerpt = function_exists('mb_substr') && mb_strlen($plain, 'UTF-8') > 160
            ? mb_substr($plain, 0, 160, 'UTF-8') : $plain;
    }
    // 未设置封面时自动取正文第一张图片作为封面
    if ($cover === '' && trim($content) !== '' && function_exists('moe_first_image')) {
        $cover = moe_first_image($content);
    }

    if (empty($errs)) {
        if ($post) {
            // 「编辑草稿」副本：保存时合并回原文（线上内容不会被草稿覆盖），并删除副本
            $targetId = (int)$post['id'];
            if (!empty($post['draft_of'])) {
                $orig = row('SELECT * FROM ' . moe_table('posts') . ' WHERE id = ? AND type = ?', array((int)$post['draft_of'], $type));
                if ($orig) $targetId = (int)$orig['id'];
            }
            $oldCat = (int)one('SELECT category_id FROM ' . moe_table('posts') . ' WHERE id = ?', array($targetId));
            // 不再携带 seo_* 字段：编辑页已移除 SEO 设置，数据库中已有的 SEO 值原样保留
            // auto_draft=0：这条内容正式转正，不再是「自动草稿槽位」
            q('UPDATE ' . moe_table('posts') . ' SET category_id=?, title=?, slug=?, excerpt=?, content=?, content_format=?, cover=?, status=?, is_top=?, tags=?, draft_of=0, auto_draft=0, updated_at=NOW() WHERE id=?',
                array($catId, $title, $slug, $excerpt, $content, $format, $cover, $status, $isTop, $tags, $targetId));
            // 换了分类：在新分类里重新分配编号；原分类与新分类都重排一次，避免留下空号
            if ($type === 'post') {
                if ($oldCat !== $catId) {
                    q('UPDATE ' . moe_table('posts') . ' SET url_num = 0 WHERE id = ?', array($targetId));
                }
                moe_ensure_post_num($targetId);
                if ($oldCat !== $catId && function_exists('moe_reindex_cat_nums')) {
                    moe_reindex_cat_nums($oldCat);
                    moe_reindex_cat_nums($catId);
                }
            }
            if ($status === 'published') {
                moe_auto_push($type === 'page' ? page_url($targetId) : post_url($targetId));
            }
            // 合并后清理自动保存的编辑草稿副本；并清掉自动草稿槽位（发布/保存后不再保留草稿）
            q('DELETE FROM ' . moe_table('posts') . ' WHERE type = ? AND draft_of = ? AND id <> ?', array($type, $targetId, $targetId));
            q('DELETE FROM ' . moe_table('posts') . ' WHERE type = ? AND auto_draft = 1 AND id <> ?', array($type, $targetId));
            // 2.2.22：投稿转正 —— 联动上架关联的商城资源，并邮件通知投稿作者
            if ($wasPending && $status === 'published') {
                try {
                    q('UPDATE ' . moe_table('pt_goods') . ' SET status = ?, updated_at = ? WHERE post_id = ?',
                        array('on', date('Y-m-d H:i:s'), $targetId));
                } catch (Throwable $e) { /* 未开启商城 */ }
                if (function_exists('moe_uc_contribute_notify')) {
                    moe_uc_contribute_notify($title, (int)($post['user_id'] ?? 0), true);
                }
            }
            // 2.2.23：编辑器「上架资源」勾选时同步关联商品（封面自动取文章封面）
            if ($type === 'post' && ($_POST['res_on'] ?? '') === '1'
                && function_exists('moe_pt_ready') && moe_pt_ready() && function_exists('moe_pt_goods_sync_from_post')) {
                $resMode = (string)($_POST['res_mode'] ?? 'both');
                if (!in_array($resMode, array('points', 'coins', 'both'), true)) $resMode = 'both';
                moe_pt_goods_sync_from_post($targetId, array(
                    'cat'          => (string)($_POST['res_cat'] ?? '其他'),
                    'price'        => $resMode === 'coins' ? -1 : round(max(0, (float)($_POST['res_price'] ?? 0)), 2),
                    'price_coins'  => $resMode === 'points' ? -1 : round(max(0, (float)($_POST['res_coins'] ?? 0)), 2),
                    'download_url' => (string)($_POST['res_url'] ?? ''),
                    'summary'      => $excerpt,
                    'status'       => 'on',
                ));
            }
            flash('保存成功 ✅');
            // 已发布 / 保存后返回文章管理（独立页面则回页面管理）
            if ($status === 'published') {
                redirect($type === 'page' ? 'pages.php' : 'posts.php');
            }
            redirect('post-edit.php?id=' . $targetId . '&type=' . $type);
        } else {
            q('INSERT INTO ' . moe_table('posts') . ' (user_id,category_id,type,title,slug,excerpt,content,content_format,cover,status,is_top,tags,created_at,updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW(),NOW())',
                array($_SESSION['moe_uid'], $catId, $type, $title, $slug, $excerpt, $content, $format, $cover, $status, $isTop, $tags));
            $nid = (int)last_id();
            if ($type === 'post') moe_ensure_post_num($nid);   // 分类内编号，从 1 开始
            // 2.2.23：编辑器「上架资源」勾选时同步关联商品（封面自动取文章封面）
            if ($type === 'post' && ($_POST['res_on'] ?? '') === '1'
                && function_exists('moe_pt_ready') && moe_pt_ready() && function_exists('moe_pt_goods_sync_from_post')) {
                $resMode = (string)($_POST['res_mode'] ?? 'both');
                if (!in_array($resMode, array('points', 'coins', 'both'), true)) $resMode = 'both';
                moe_pt_goods_sync_from_post($nid, array(
                    'cat'          => (string)($_POST['res_cat'] ?? '其他'),
                    'price'        => $resMode === 'coins' ? -1 : round(max(0, (float)($_POST['res_price'] ?? 0)), 2),
                    'price_coins'  => $resMode === 'points' ? -1 : round(max(0, (float)($_POST['res_coins'] ?? 0)), 2),
                    'download_url' => (string)($_POST['res_url'] ?? ''),
                    'summary'      => $excerpt,
                    'status'       => 'on',
                ));
            }
            // 正式内容已入库：清掉自动草稿槽位（发布过后不再保留草稿）
            q('DELETE FROM ' . moe_table('posts') . ' WHERE type = ? AND auto_draft = 1 AND id <> ?', array($type, $nid));
            if ($status === 'published') {
                moe_auto_push($type === 'page' ? page_url($nid) : post_url($nid));
            }
            flash($status === 'published' ? '发布成功 🎉' : '草稿已保存 📝');
            // 确认发布后返回文章管理；存为草稿则留在编辑器继续写作
            if ($status === 'published') {
                redirect($type === 'page' ? 'pages.php' : 'posts.php');
            }
            redirect('post-edit.php?id=' . $nid . '&type=' . $type);
        }
    } else {
        foreach ($errs as $er) flash($er, 'bad');
    }
    // 校验失败时回填
    $post = array_merge($post ?: array(), array(
        'title' => $title, 'slug' => $slug, 'category_id' => $catId, 'excerpt' => $excerpt,
        'content' => $content, 'content_format' => $format, 'cover' => $cover, 'status' => $status, 'is_top' => $isTop,
        'tags' => $tags,
    ));
}

// 编辑已有内容时：若存在自动保存的「编辑草稿」，提示是否恢复；
// 全新内容页：接续「自动草稿槽位」（全局唯一一篇），避免每次新开页面都攒出一条新草稿
$autoDraft = null;
if ($post && empty($post['draft_of']) && !empty($post['id'])) {
    try {
        $autoDraft = row('SELECT id, title, content, updated_at FROM ' . moe_table('posts')
            . ' WHERE type = ? AND draft_of = ? ORDER BY id DESC LIMIT 1', array($type, (int)$post['id']));
    } catch (Throwable $e) { $autoDraft = null; }
} elseif (!$post) {
    try {
        $autoDraft = row('SELECT id, title, content, updated_at FROM ' . moe_table('posts')
            . " WHERE type = ? AND status = 'draft' AND auto_draft = 1 AND (title <> '' OR content <> '') ORDER BY id DESC LIMIT 1", array($type));
    } catch (Throwable $e) { $autoDraft = null; }
}

$words = content_words($post ? $post['content'] : '', 'markdown');
$readMin = max(1, (int)ceil($words / 350));
// 旧数据是 HTML 格式时给个提示（保存后按 Markdown 渲染，内嵌 HTML 标签仍保留）
$legacyHtml = $post && !empty($post['content_format']) && $post['content_format'] === 'html';

/* 2.2.23：「上架资源」卡片的数据 —— 已关联的商品、分类清单（与后台积分商城共用 pt_cats 设置） */
$ptReady = false; $resGoods = null; $ptCats = array();
if ($type === 'post' && function_exists('moe_pt_ready') && moe_pt_ready()) {
    $ptReady = true;
    try {
        $resGoods = $post && !empty($post['id'])
            ? row('SELECT * FROM ' . moe_table('pt_goods') . ' WHERE post_id = ? LIMIT 1', array((int)$post['id']))
            : null;
        if (!$resGoods && !empty($_POST['res_on'])) $resGoods = null;   // 保存失败回填时保持表单值
    } catch (Throwable $e) { $resGoods = null; }
    $ptCats = array('主题', '插件', '程序', '授权码', '其他');
    foreach (preg_split('/[\r\n,，]+/u', (string)setting('pt_cats', '')) as $__c) {
        $__c = trim((string)$__c);
        if ($__c !== '' && !in_array($__c, $ptCats, true)) $ptCats[] = $__c;
    }
    try {
        foreach (rows('SELECT DISTINCT cat FROM ' . moe_table('pt_goods') . ' WHERE cat <> "" LIMIT 20') as $__g) {
            $__c = trim((string)($__g['cat'] ?? ''));
            if ($__c !== '' && !in_array($__c, $ptCats, true)) $ptCats[] = $__c;
        }
    } catch (Throwable $e) {}
}

// 链接预览需要：分类别名表 + 当前文章编号
$catSlugs = array('0' => moe_uncat_slug());
foreach ($cats as $c) {
    $catSlugs[(string)(int)$c['id']] = $c['slug'] !== '' ? $c['slug'] : ('cat-' . (int)$c['id']);
}
$curNum = ($post && $type === 'post') ? post_url_num($post) : 0;
$curCat = $post && $type === 'post' ? (int)$post['category_id'] : 0;

/* 2.1.6：编辑器「插入下载卡片」可选的资源列表（积分商城已上架的资源） */
$dlGoods = array();
if (function_exists('moe_pt_goods')) {
    try {
        foreach ((array)moe_pt_goods(true) as $dg) {
            $dlGoods[] = array(
                'id'    => (int)$dg['id'],
                'title' => (string)$dg['title'],
                'price' => (int)$dg['price'],
                'dl'    => (int)$dg['downloads'],
            );
        }
    } catch (Throwable $e) { $dlGoods = array(); }
}

// 各分类下一个可用编号（换分类时链接预览用）
$nextNums = array();
try {
    $pt = moe_table('posts');
    // 2.2.30 优化：原来按分类逐条 MAX(url_num)（N+1），改为一条 GROUP BY 取回全部。
    // 排除 category_id IS NULL：原逐类查询 category_id = ? 也不会匹配 NULL，保持等价。
    $nextMap = array();
    foreach (rows('SELECT category_id, COALESCE(MAX(url_num),0)+1 AS n FROM ' . $pt
        . " WHERE type='post' AND category_id IS NOT NULL GROUP BY category_id") as $r) {
        $nextMap[(string)(int)$r['category_id']] = (int)$r['n'];
    }
    foreach ($cats as $c) {
        $cid = (int)$c['id'];
        $nextNums[(string)$cid] = isset($nextMap[(string)$cid]) ? $nextMap[(string)$cid] : 1;
    }
    $nextNums['0'] = isset($nextMap['0']) ? $nextMap['0'] : 1;
} catch (Throwable $e) {
    $nextNums = array();
}

include 'includes/header.php';
$v = function ($k, $d = '') use ($post) { return e($post && isset($post[$k]) ? $post[$k] : $d); };
?>

<form method="post" id="postForm">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="id" id="postId" value="<?php echo (int)($post && !empty($post['id']) ? $post['id'] : 0); ?>">
  <input type="hidden" name="type" value="<?php echo e($type); ?>">

  <?php if ($autoDraft): ?>
  <div class="alert warn" id="autoDraftBar" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
    <span>发现 <?php echo e(format_time($autoDraft['updated_at'], 'Y-m-d H:i')); ?> 自动保存的草稿</span>
    <button type="button" class="btn sm" id="autoDraftUse">恢复这份草稿</button>
    <button type="button" class="btn ghost sm" id="autoDraftDrop">丢弃</button>
  </div>
  <?php endif; ?>

  <div class="form-grid">
    <div class="card full">
      <div class="field">
        <label>标题 *</label>
        <input type="text" name="title" id="titleInput" value="<?php echo $v('title'); ?>" placeholder="给这篇<?php echo $type === 'page' ? '页面' : '文章'; ?>起个好听的名字吧～" required>
      </div>

      <?php if (!$ueditor): ?>
      <!-- 2.1.7 标题框下方的胶囊快捷按钮（UEditorPlus 模式不显示：锁定包裹为 Markdown 语法） -->
      <div class="ed-pills" id="edPills">
        <button type="button" class="ed-pill" id="pillDl" title="插入资源下载卡片（@[download](ID)）">📥 下载资源</button>
        <button type="button" class="ed-pill" data-lock="login" title="把选中内容包进「登录可见」">🔒 登录可见</button>
        <button type="button" class="ed-pill" data-lock="comment" title="把选中内容包进「评论可见」">💬 评论可见</button>
        <span class="ed-pill-hint">选中正文再点「登录 / 评论可见」，即可把这部分内容包起来，访客看不到</span>
      </div>

      <div class="field" style="margin-bottom:0">
        <div class="ed">
          <div class="ed-bar">
            <div class="ed-tabs"><span class="ed-tab cur">✍️ Markdown</span></div>
            <span class="ed-grow"></span>
            <span class="ed-stat" id="edStat"><?php echo $words; ?> 字 · 约 <?php echo $readMin; ?> 分钟</span>
            <!-- 2.2.23：恢复「预览 / 分栏」切换；「📎 附件」媒体库按钮已按站长要求移除（封面处仍可上传） -->
            <button type="button" class="ed-view" id="edView" title="切换：编辑 → 分栏 → 预览">◫ 分栏</button>
          </div>

          <div class="ed-toolbar" id="edToolbar">
            <button type="button" data-wk="h2" title="二级标题">H2</button>
            <button type="button" data-wk="h3" title="三级标题">H3</button>
            <span class="ed-div"></span>
            <button type="button" data-wk="bold" title="加粗 Ctrl+B"><b>B</b></button>
            <button type="button" data-wk="italic" title="斜体 Ctrl+I"><i>I</i></button>
            <button type="button" data-wk="strike" title="删除线"><s>S</s></button>
            <button type="button" data-wk="code" title="行内代码">`</button>
            <span class="ed-div"></span>
            <button type="button" data-wk="quote" title="引用">❝</button>
            <button type="button" data-wk="ul" title="无序列表">•</button>
            <button type="button" data-wk="ol" title="有序列表">1.</button>
            <button type="button" data-wk="task" title="任务列表">☑</button>
            <span class="ed-div"></span>
            <button type="button" data-wk="link" title="链接 Ctrl+K">🔗</button>
            <button type="button" data-wk="image" title="插入图片">🖼</button>
            <button type="button" data-wk="video" title="插入视频（mp4 / m3u8 直接播放）">🎬</button>
            <button type="button" data-wk="download" title="插入资源下载卡片（积分商城里的资源）">📥</button>
            <button type="button" data-wk="table" title="插入表格">▦</button>
            <button type="button" data-wk="codeblock" title="代码块">&lt;/&gt;</button>
            <button type="button" data-wk="hr" title="分割线">―</button>
          </div>

          <div class="ed-body write" id="edBody">
            <div class="ed-pane ed-write">
              <textarea name="content" id="edText" spellcheck="false"
                        placeholder="# 开始写点什么&#10;&#10;支持 **加粗**、*斜体*、`代码`、- 列表、> 引用、| 表格 |&#10;按 Ctrl+S 保存草稿"><?php echo $v('content'); ?></textarea>
            </div>
            <!-- 2.2.23：恢复预览面板（分栏 / 预览模式渲染正文） -->
            <div class="ed-pane ed-preview" id="edPreview"><div class="md-body" id="pvBody"><p class="hint">点右上「◫ 分栏」查看实时预览</p></div></div>
          </div>
        </div>
        <?php if ($type === 'page'): ?>
        <p class="hint">📄 页面正文可以留空：商城、下载中心这类由主题按别名渲染的页面，只需要标题与别名。</p>
        <?php endif; ?>
        <p class="hint" id="edHint">💡 Markdown 专注写作，Tab 缩进 · Ctrl+B 加粗 · Ctrl+K 链接 · Ctrl+S 保存 · ◫ 分栏可实时预览</p>
        <?php if ($legacyHtml): ?>
          <p class="hint" style="color:var(--warn)">⚠️ 这篇是旧版 HTML 格式内容，已按 Markdown 编辑器打开：内嵌的 HTML 标签会原样保留，保存后正文按 Markdown 渲染。</p>
        <?php endif; ?>
      </div>
      <?php else: ?>
      <!-- 2.2.22：UEditorPlus 富文本模式（所见即所得，正文按 HTML 保存） -->
      <div class="field" style="margin-bottom:0">
        <div class="ed">
          <div class="ed-bar">
            <div class="ed-tabs"><span class="ed-tab cur">🌈 UEditorPlus 富文本</span></div>
            <span class="ed-grow"></span>
            <span class="ed-stat">正文按 HTML 格式保存 · 图片 / 视频 / 附件可直接上传插入</span>
          </div>
          <div style="padding:10px;background:#fff;border-radius:0 0 12px 12px">
            <textarea name="content" id="edText" style="width:100%;height:420px"><?php echo $v('content'); ?></textarea>
          </div>
        </div>
        <?php if ($type === 'page'): ?>
        <p class="hint">📄 页面正文可以留空：商城、下载中心这类由主题按别名渲染的页面，只需要标题与别名。</p>
        <?php endif; ?>
        <p class="hint">💡 UEditorPlus 为所见即所得编辑器，图片 / 视频 / 附件直接在工具栏上传；可在 站点设置 → 功能设置 切换回 Markdown</p>
      </div>
      <?php endif; ?>
    </div>

    <div class="card" style="margin-bottom:0">
      <h2 class="card-title">发布设置</h2>
      <div class="field">
        <label>状态</label>
        <select name="status">
          <option value="published" <?php echo !$post || $post['status'] === 'published' ? 'selected' : ''; ?>>公开发布</option>
          <option value="draft" <?php echo $post && $post['status'] === 'draft' ? 'selected' : ''; ?>>存为草稿</option>
          <?php if ($post && $post['status'] === 'pending'): ?>
          <option value="pending" selected>待审核（保持不公开）</option>
          <?php endif; ?>
        </select>
        <?php if ($post && $post['status'] === 'pending'): ?>
        <p class="hint" style="color:#b7791f">📝 这是用户投稿，尚未公开。选「公开发布」保存＝通过审核，会邮件通知作者并同步上架关联资源。</p>
        <?php else: ?>
        <p class="hint" id="autoSaveHint">💾 未发布的内容空闲 5 分钟会自动存草稿（同一篇只保留一份）；发布后不再生成草稿</p>
        <?php endif; ?>
      </div>
      <?php if ($type === 'post'): ?>
      <div class="field">
        <label>分类</label>
        <select name="category_id">
          <option value="0">未分类</option>
          <?php foreach ($cats as $c): ?>
            <option value="<?php echo (int)$c['id']; ?>" <?php echo $post && $post['category_id'] == $c['id'] ? 'selected' : ''; ?>><?php echo e($c['name']); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label>标签（逗号分隔，最多 8 个）
          <button type="button" class="btn ghost sm" id="autoTagBtn" style="margin-left:8px">✨ 自动生成</button>
        </label>
        <input type="text" name="tags" id="tagsInput" value="<?php echo $v('tags'); ?>" placeholder="如：php,萌Z,教程">
        <p class="hint" id="tagHint">标签显示在文章页底部，点击可查看同标签文章；「自动生成」根据标题和正文提取关键词</p>
      </div>
      <div class="field">
        <label class="check-row" style="margin-top:4px">
          <input type="checkbox" name="is_top" <?php echo $post && $post['is_top'] ? 'checked' : ''; ?>> 📌 置顶这篇文章
        </label>
      </div>
      <?php else: ?>
      <input type="hidden" name="category_id" value="0">
      <?php endif; ?>
      <div class="field" style="margin-bottom:0">
        <label>别名（slug，<?php echo $type === 'page' ? '决定页面链接 /别名.html，也可直接用 /别名 访问' : '选填 · 仅作内部标识'; ?>）</label>
        <input type="text" name="slug" id="slugInput" value="<?php echo $v('slug'); ?>"
               placeholder="<?php echo $type === 'page' ? '留空自动用标题，如「关于我」' : '如 my-first-post'; ?>">
        <p class="hint" id="urlPreview"><?php echo e($post ? ($type === 'page' ? page_url($post) : post_url($post)) : ''); ?></p>
        <?php if ($type === 'page'): ?>
          <p class="hint">支持中文别名（如「开发文档」）；留空自动用<b>标题</b>生成，链接形如 <code>/关于我.html</code>；重名自动加 -2</p>
        <?php endif; ?>
      </div>
    </div>

    <div>
      <div class="card">
        <h2 class="card-title">封面图</h2>
        <div class="cover-pick">
          <div class="preview" id="coverPrev">
            <?php if ($post && $post['cover']): ?>
              <img src="<?php echo e(media_url($post['cover'])); ?>" alt="">
            <?php else: ?>🌸<?php endif; ?>
          </div>
          <div style="flex:1">
            <input type="text" name="cover" id="coverInput" value="<?php echo $v('cover'); ?>"
                   placeholder="粘贴图片 URL，或点击右侧上传" style="width:100%;padding:9px 12px;border:1.5px solid #e8e2f0;border-radius:10px;outline:none">
            <label class="btn ghost sm" style="margin-top:8px;cursor:pointer">
              📤 上传封面
              <input type="file" id="coverFile" accept="image/*" style="display:none">
            </label>
            <button type="button" class="btn ghost sm" id="coverLibBtn" style="margin-top:8px;margin-left:6px" title="从资源媒体库挑一张图片当封面">📚 媒体库</button>
          </div>
        </div>
        <p class="hint" id="upMsg">支持 jpg / png / gif / webp，<?php echo e(setting('upload_max_mb', '50')); ?>MB 以内（后台设置可调）</p>
      </div>

      <div class="card">
        <h2 class="card-title">摘要</h2>
        <div class="field" style="margin-bottom:0">
          <textarea name="excerpt" id="excerptInput" rows="4" style="width:100%;padding:10px 13px;border:1.5px solid #e8e2f0;border-radius:10px;outline:none;resize:vertical"
                    placeholder="留空则自动截取正文前 160 字"><?php echo $v('excerpt'); ?></textarea>
          <p class="hint">摘要会用于列表页与 SEO 描述（留空自动截取正文前 160 字）</p>
        </div>
      </div>

      <?php if ($type === 'post' && $ptReady): ?>
      <!-- 2.2.23：上架资源 —— 一篇文章可直接挂一个商城资源，封面自动取文章封面 -->
      <div class="card">
        <h2 class="card-title">上架资源</h2>
        <label style="display:flex;align-items:center;gap:7px;font-size:13.5px;cursor:pointer;margin-bottom:10px">
          <input type="checkbox" name="res_on" id="resOn" value="1" <?php echo $resGoods ? 'checked' : ''; ?>> 📦 把这篇文章作为资源上架到积分商城
        </label>
        <div id="resBox" style="<?php echo $resGoods ? '' : 'display:none'; ?>">
          <div class="field">
            <label>资源分类</label>
            <select name="res_cat">
              <?php foreach ($ptCats as $__c): ?>
                <option value="<?php echo e($__c); ?>" <?php echo ($resGoods && $resGoods['cat'] === $__c) ? 'selected' : ''; ?>><?php echo e($__c); ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label>定价方式</label>
            <select name="res_mode" id="resMode">
              <option value="both" <?php echo !$resGoods || ($resGoods['price'] >= 0 && $resGoods['price_coins'] >= 0) ? 'selected' : ''; ?>>双币同售（萌豆 + 金币）</option>
              <option value="points" <?php echo $resGoods && $resGoods['price'] < 0 ? 'selected' : ''; ?>>仅金币</option>
              <option value="coins" <?php echo $resGoods && $resGoods['price_coins'] < 0 ? 'selected' : ''; ?>>仅萌豆</option>
            </select>
          </div>
          <div class="field">
            <label>萌豆价格（0 = 免费）</label>
            <input type="number" name="res_price" min="0" step="1" value="<?php echo $resGoods && $resGoods['price'] >= 0 ? e($resGoods['price']) : '0'; ?>">
          </div>
          <div class="field">
            <label>金币价格（0 = 免费）</label>
            <input type="number" name="res_coins" min="0" step="1" value="<?php echo $resGoods && $resGoods['price_coins'] >= 0 ? e($resGoods['price_coins']) : '0'; ?>">
          </div>
          <div class="field" style="margin-bottom:0">
            <label>下载地址（站内 uploads 路径或网盘直链）</label>
            <input type="text" name="res_url" value="<?php echo $resGoods ? e($resGoods['download_url']) : ''; ?>" placeholder="uploads/file/202611/xxx.zip 或 https://…">
            <p class="hint">封面自动使用本文的文章封面；保存后可在「积分商城」里微调，用户兑换后点「下载」即可自动下载文件</p>
          </div>
        </div>
      </div>
      <script>
      (function () {
        var on = document.getElementById('resOn'), box = document.getElementById('resBox');
        if (on && box) on.addEventListener('change', function () { box.style.display = on.checked ? '' : 'none'; });
      })();
      </script>
      <?php endif; ?>
    </div>

    <div class="form-foot full">
      <button class="btn" type="submit" id="saveBtn">💾 <?php echo $post ? '保存修改' : '立即发布'; ?></button>
      <a class="btn ghost" href="<?php echo $type === 'page' ? 'pages.php' : 'posts.php'; ?>">返回列表</a>
      <?php if ($post): ?>
        <a class="btn ghost" href="<?php echo e($type === 'page' ? page_url($post) : post_url($post)); ?>" target="_blank">前台预览 ↗</a>
      <?php endif; ?>
      <span class="ed-saved" id="edSaved"></span>
    </div>
  </div>
</form>

<!-- ================= 2.0.4 · 资源媒体库弹窗 ================= -->
<div class="ml-mask" id="mlMask" hidden>
  <div class="ml-win" role="dialog" aria-modal="true" aria-labelledby="mlTitle">
    <div class="ml-head">
      <div class="ml-title" id="mlTitle">📚 资源媒体库 <small id="mlCount"></small></div>
      <button type="button" class="ml-x" id="mlClose" title="关闭" aria-label="关闭">✕</button>
    </div>

    <div class="ml-bar">
      <label class="ml-upload" for="mlFile" id="mlUploadBtn">⬆ 上传图片/文件</label>
      <input type="file" id="mlFile" multiple hidden
             accept="image/*,video/*,audio/*,.pdf,.txt,.md,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.csv,.epub,.zip,.rar,.7z,.tar,.gz,.m3u8">
      <span class="ml-grow"></span>
      <div class="ml-search">
        <input type="text" id="mlQ" placeholder="搜索资源文件名…" autocomplete="off" spellcheck="false">
        <button type="button" id="mlSearch" title="搜索" aria-label="搜索">🔍</button>
      </div>
    </div>

    <div class="ml-filters" id="mlFilters" role="tablist" aria-label="资源类型">
      <button type="button" class="ml-chip cur" data-kind="all">全部</button>
      <button type="button" class="ml-chip" data-kind="image">🖼 图片</button>
      <button type="button" class="ml-chip" data-kind="video">🎬 视频</button>
      <button type="button" class="ml-chip" data-kind="audio">🎵 音频</button>
      <button type="button" class="ml-chip" data-kind="file">📎 文件</button>
    </div>

    <div class="ml-status" id="mlStatus"></div>
    <div class="ml-grid" id="mlGrid"></div>
    <div class="ml-foot">
      <button type="button" class="btn ghost sm" id="mlMore">加载更多</button>
      <span class="ml-tip">支持图片 / 视频 / 音频 / 文档 / 压缩包 · 图片可直接设为封面</span>
    </div>
  </div>
</div>

<?php if ($ueditor): ?>
<!-- 2.2.22：UEditorPlus 静态资源（本站自托管，免外部依赖） -->
<link rel="stylesheet" href="<?php echo e(base_url()); ?>assets/editor/ueditor/themes/iframe.css">
<script>window.UEDITOR_HOME_URL = <?php echo json_encode(base_url() . 'assets/editor/ueditor/'); ?>;</script>
<script src="<?php echo e(base_url()); ?>assets/editor/ueditor/ueditor.config.js"></script>
<script src="<?php echo e(base_url()); ?>assets/editor/ueditor/ueditor.all.js"></script>
<?php endif; ?>
<script>
(function () {
  var CSRF      = <?php echo json_encode(csrf_token()); ?>;
  var BASE      = <?php echo json_encode(base_url()); ?>;
  var STYLE     = <?php echo json_encode(url_style()); ?>;
  var PID       = <?php echo json_encode($post ? (int)$post['id'] : 0); ?>;
  var IS_PAGE   = <?php echo $type === 'page' ? 'true' : 'false'; ?>;
  var CATS      = <?php echo json_encode($catSlugs, JSON_UNESCAPED_UNICODE); ?>;
  var NEXT      = <?php echo json_encode($nextNums, JSON_UNESCAPED_UNICODE); ?>;
  var CUR_NUM   = <?php echo (int)$curNum; ?>;
  var CUR_CAT   = <?php echo (int)$curCat; ?>;
  /* 2.1.6：正文下载卡片可选的资源（后台「积分商城」已上架） */
  var DL_GOODS  = <?php echo json_encode($dlGoods, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
  var DL_UNIT   = <?php echo json_encode(function_exists('moe_pt_name') ? moe_pt_name() : '积分', JSON_UNESCAPED_UNICODE); ?>;
  var DRAFT_KEY = 'moedraft_<?php echo $type; ?>_' + (PID || 'new');
  var SAVED_TS = <?php echo (int)($post && !empty($post['updated_at']) ? strtotime($post['updated_at']) : 0); ?>; // 库里当前版本时间戳（秒）

  /* 2.2.22：UEditorPlus 富文本模式 —— 跳过 Markdown 工具栏 / 自动草稿 / 统计逻辑，正文由富文本编辑器接管 */
  var UE_MODE = <?php echo $ueditor ? 'true' : 'false'; ?>;
  if (UE_MODE) {
    var edForm2 = document.getElementById('postForm');
    var edReady2 = false;
    var edInit2 = function () {
      if (!window.UE) { setTimeout(edInit2, 120); return; }
      try {
        var ed = window.UE.getEditor('edText', {
          initialFrameHeight: 480,
          autoHeightEnabled: false,
          serverUrl: <?php echo json_encode(base_url() . 'admin/ueditor-server.php'); ?> + '?_token=' + encodeURIComponent(CSRF),
          maxUndoCount: 40
        });
        ed.addListener('ready', function () { edReady2 = true; });
        if (edForm2) edForm2.addEventListener('submit', function () {
          try { if (edReady2) ed.sync(); } catch (e2) {}
        });
      } catch (e1) {
        document.getElementById('edText').style.display = 'block';
        document.getElementById('edText').style.height = '420px';
      }
    };
    edInit2();
    return;
  }

  var text    = document.getElementById('edText'),
      body    = document.getElementById('edBody'),
      toolbar = document.getElementById('edToolbar'),
      statEl  = document.getElementById('edStat'),
      savedEl = document.getElementById('edSaved');

  /* 2.2.23：恢复「预览 / 分栏」—— 点击右上按钮在 编辑 → 分栏 → 预览 之间循环 */
  var viewMode  = 'write';
  var pvBody    = document.getElementById('pvBody');
  var edViewBtn = document.getElementById('edView');
  var pvTimer   = null;
  function applyView() {
    body.classList.remove('write', 'split', 'preview');
    if (viewMode === 'write')   body.classList.add('write');
    if (viewMode === 'preview') body.classList.add('preview');
    if (edViewBtn) edViewBtn.textContent = viewMode === 'write' ? '◫ 分栏' : (viewMode === 'split' ? '👁 预览' : '✏️ 编辑');
    if (viewMode !== 'write') updatePreview(true);
  }
  function updatePreview(force) {
    if (!pvBody) return;
    if (viewMode === 'write' && !force) return;
    if (pvTimer) clearTimeout(pvTimer);
    pvTimer = setTimeout(function () {
      var fd = new FormData();
      fd.append('_token', CSRF);
      fd.append('content', text.value);
      fd.append('format', <?php echo $legacyHtml ? "'html'" : "'markdown'"; ?>);
      fetch('preview.php', { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (d) { if (d && d.ok) pvBody.innerHTML = d.html || ''; })
        .catch(function () {});
    }, force ? 0 : 600);
  }
  if (edViewBtn) edViewBtn.addEventListener('click', function () {
    viewMode = viewMode === 'write' ? 'split' : (viewMode === 'split' ? 'preview' : 'write');
    applyView();
  });
  function countWords(t) {
    var cjk = (t.match(/[\u4e00-\u9fa5\u3040-\u30ff]/g) || []).length;
    var en  = (t.match(/[A-Za-z0-9]+/g) || []).length;
    return cjk + en;
  }
  function updateStat() {
    var w = countWords(text.value);
    statEl.textContent = w + ' 字 · 约 ' + Math.max(1, Math.ceil(w / 350)) + ' 分钟';
  }

  /* ---------- 工具栏 ---------- */
  function setRange(str, selStart, selEnd) {
    text.focus();
    if (typeof text.setRangeText === 'function') {
      text.setRangeText(str, selStart, selEnd, 'end');
    } else {
      text.value = text.value.slice(0, selStart) + str + text.value.slice(selEnd);
    }
    onChange();
  }
  function wrap(before, after, ph) {
    var s = text.selectionStart, e = text.selectionEnd, sel = text.value.slice(s, e);
    var inner = sel || ph || '';
    setRange(before + inner + after, s, e);
    if (!sel) text.setSelectionRange(s + before.length, s + before.length + inner.length);
  }
  /** 插入 Markdown 元素并把光标落在「地址」占位符上（选中整个 URL，直接粘贴即替换） */
  function insertMd(head, desc, urlPh) {
    var s = text.selectionStart, e = text.selectionEnd;
    var sel = text.value.slice(s, e);
    // 选中内容像 URL → 直接作为地址；否则当作描述文字
    var looksUrl = /^https?:\/\/\S+$/i.test(sel);
    var d = looksUrl ? (desc === '' ? '' : (desc || '')) : (sel || desc || '');
    var url = looksUrl ? sel : urlPh;
    var str = head + d + '](' + url + ')';
    setRange(str, s, e);
    var start = s + str.indexOf('(') + 1;
    text.setSelectionRange(start, start + url.length);
  }
  function prefixLines(prefix) {
    var s = text.selectionStart, e = text.selectionEnd;
    var start = text.value.lastIndexOf('\n', s - 1) + 1;
    var end = text.value.indexOf('\n', e);
    if (end === -1) end = text.value.length;
    var block = text.value.slice(start, end);
    var out = block.split('\n').map(function (l) { return prefix + l; }).join('\n');
    setRange(out, start, end);
  }
  function insertBlock(str) {
    var s = text.selectionStart;
    var needNl = s > 0 && text.value.charAt(s - 1) !== '\n' ? '\n\n' : '';
    setRange(needNl + str + '\n', s, text.selectionEnd);
  }

  var actions = {
    h2:        function () { prefixLines('## '); },
    h3:        function () { prefixLines('### '); },
    bold:      function () { wrap('**', '**', '加粗文字'); },
    italic:    function () { wrap('*', '*', '斜体文字'); },
    strike:    function () { wrap('~~', '~~', '删除线'); },
    code:      function () { wrap('`', '`', 'code'); },
    quote:     function () { prefixLines('> '); },
    ul:        function () { prefixLines('- '); },
    ol:        function () { prefixLines('1. '); },
    task:      function () { prefixLines('- [ ] '); },
    link:      function () { insertMd('[', '链接文字', 'https://链接地址'); },
    image:     function () { insertMd('![', '图片描述', 'https://图片地址.jpg'); },
    video:     function () { insertMd('@[video](', '', 'https://视频地址.mp4或.m3u8'); },
    table:     function () { insertBlock('| 列一 | 列二 |\n| --- | --- |\n| 内容 | 内容 |'); },
    codeblock: function () { insertBlock('```php\n// 代码\n```'); },
    hr:        function () { insertBlock('---'); },
    upload:    function () { if (window.__moeMediaOpen) window.__moeMediaOpen('insert'); },
    download:  function () { openDlPicker(); }
  };

  /* ============================================================
     2.1.6 · 插入资源下载卡片
     ------------------------------------------------------------
     从「积分商城」已上架的资源里挑一个，插入 @[download](ID)。
     正文渲染时变成一张下载卡：已兑换→立即下载、未兑换→直接兑换、
     未登录→登录入口；兑换成功回到文章原位置。
     ============================================================ */
  function openDlPicker() {
    if (document.getElementById('dlpMask')) return;
    var mask = document.createElement('div');
    mask.id = 'dlpMask';
    mask.className = 'dlp-mask';
    mask.innerHTML =
      '<div class="dlp-box" role="dialog" aria-label="插入资源下载卡片">'
      + '<div class="dlp-head"><b>📥 插入资源下载卡片</b>'
      + '<button type="button" class="dlp-x" id="dlpX" aria-label="关闭">✕</button></div>'
      + '<input type="text" id="dlpQ" class="dlp-q" placeholder="搜索资源名称 / 输入 ID…">'
      + '<div class="dlp-list" id="dlpList"></div>'
      + '<div class="dlp-foot">点选资源即插入 <code>@[download](资源ID)</code>。'
      + '读者在正文里就能直接兑换或下载：已兑换显示「立即下载」，未登录显示登录入口，兑换成功会自动回到这篇文章。</div>'
      + '</div>';
    document.body.appendChild(mask);

    var listEl = mask.querySelector('#dlpList');
    var qEl    = mask.querySelector('#dlpQ');

    function dlEsc(s) {
      return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
    function render() {
      var q = (qEl.value || '').trim().toLowerCase();
      if (!DL_GOODS.length) {
        listEl.innerHTML = '<p class="dlp-empty">积分商城还没有上架资源。<br>'
          + '先到 <a href="points.php" target="_blank">积分商城</a> 添加资源（填好下载地址与积分售价），回来就能插入正文了～</p>';
        return;
      }
      var items = DL_GOODS.filter(function (g) {
        return !q || String(g.title).toLowerCase().indexOf(q) !== -1 || String(g.id) === q;
      });
      if (!items.length) { listEl.innerHTML = '<p class="dlp-empty">没有匹配的资源</p>'; return; }
      listEl.innerHTML = items.map(function (g) {
        return '<button type="button" class="dlp-item" data-id="' + g.id + '">'
          + '<span class="dlp-ico">📦</span>'
          + '<span class="dlp-main"><b>' + dlEsc(g.title) + '</b>'
          + '<em>#' + g.id + ' · ' + (g.price > 0 ? g.price + ' ' + DL_UNIT : '免费') + ' · 📥 ' + g.dl + '</em></span>'
          + '<span class="dlp-add">插入</span></button>';
      }).join('');
    }
    function close() { if (mask.parentNode) mask.parentNode.removeChild(mask); }

    mask.addEventListener('click', function (ev) {
      if (ev.target === mask) { close(); return; }
      var item = ev.target.closest ? ev.target.closest('.dlp-item') : null;
      if (item) {
        insertBlock('@[download](' + item.getAttribute('data-id') + ')');
        close();
        updatePreview();
      }
    });
    mask.querySelector('#dlpX').addEventListener('click', close);
    qEl.addEventListener('input', render);
    document.addEventListener('keydown', function onEsc(ev) {
      if (ev.key === 'Escape') { close(); document.removeEventListener('keydown', onEsc); }
    });

    render();
    qEl.focus();
  }

  /* 2.1.7：标题框下方的胶囊快捷按钮 */
  var edTa = document.getElementById('edText');
  function wrapLock(type) {
    var tag = type === 'comment' ? 'comment' : 'login';
    if (!edTa) return;
    var s = edTa.selectionStart, epos = edTa.selectionEnd;
    var sel = edTa.value.slice(s, epos).replace(/^\n+|\n+$/g, '');
    var body = sel !== '' ? sel : (tag === 'comment' ? '评论后才能看到的内容…' : '登录后才能看到的内容…');
    var ins = '\n@[' + tag + ']\n' + body + '\n@[/' + tag + ']\n';
    edTa.setRangeText(ins, s, epos, 'end');
    edTa.focus();
    updatePreview();
  }
  var pillAttach = document.getElementById('pillAttach');
  if (pillAttach) pillAttach.addEventListener('click', function () {
    if (window.__moeMediaOpen) window.__moeMediaOpen('insert');
  });
  var pillDl = document.getElementById('pillDl');
  if (pillDl) pillDl.addEventListener('click', openDlPicker);
  [].forEach.call(document.querySelectorAll('.ed-pill[data-lock]'), function (b) {
    b.addEventListener('click', function () { wrapLock(b.getAttribute('data-lock')); });
  });

  toolbar.addEventListener('click', function (ev) {
    var btn = ev.target.closest('button[data-wk]');
    if (!btn) return;
    var fn = actions[btn.getAttribute('data-wk')];
    if (fn) fn();
    updatePreview();
  });

  /* ============================================================
     2.0.4 · 资源媒体库
     ------------------------------------------------------------
     上传 / 搜索 / 类型筛选 / 分页 / 插入文章 / 设为封面 / 删除
     与编辑器同处一个作用域，直接复用 insertBlock / updatePreview 等
     ============================================================ */
  var mlMask    = document.getElementById('mlMask'),
      mlGrid    = document.getElementById('mlGrid'),
      mlQ       = document.getElementById('mlQ'),
      mlStatus  = document.getElementById('mlStatus'),
      mlCount   = document.getElementById('mlCount'),
      mlMore    = document.getElementById('mlMore'),
      mlFile    = document.getElementById('mlFile'),
      mlFilters = document.getElementById('mlFilters');
  if (mlMask && mlGrid) {
    var mlMode = 'insert', mlKind = 'all', mlPage = 1, mlBusy = false,
        mlQTimer = null, mlCaret = { s: 0, e: 0 };

    function mlesc(v) {
      return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;')
        .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    }
    function mlSay(msg, bad) {
      mlStatus.textContent = msg || '';
      mlStatus.className = 'ml-status' + (msg ? ' show' : '') + (bad ? ' bad' : '');
    }
    function mlRemember() { mlCaret.s = text.selectionStart; mlCaret.e = text.selectionEnd; }
    text.addEventListener('keyup', mlRemember);
    text.addEventListener('mouseup', mlRemember);
    text.addEventListener('blur', mlRemember);

    function mlPost(data, cb) {
      var fd = new FormData();
      fd.append('_token', CSRF);
      Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
      fetch('media.php', { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) {
          // 2.2.6：响应可能不是 JSON（如 403 文本 / 空白），先读文本再解析，把真实原因显示出来
          return r.text().then(function (t) {
            try { return JSON.parse(t); }
            catch (e) {
              throw new Error(t ? '接口返回异常：' + t.slice(0, 120)
                : '接口无响应（HTTP ' + r.status + ' · 登录可能已过期或被服务器安全规则拦截，请刷新页面重试）');
            }
          });
        })
        .then(cb)
        .catch(function (e) { cb({ ok: 0, msg: '请求失败：' + e.message }); });
    }
    function mlFind(node, test) {
      while (node && node !== mlGrid && node !== document) {
        if (test(node)) return node;
        node = node.parentNode;
      }
      return null;
    }

    /* 生成 Markdown：图片 / 视频 / 音频 / 普通附件各用对应语法 */
    function mlMd(it) {
      var label = it.name.replace(/\.[^.]+$/, '');
      if (it.kind === 'image') return '![' + label + '](' + it.url + ')';
      if (it.kind === 'video') return '@[video](' + it.url + ')';
      if (it.kind === 'audio') return '[🎵 ' + it.name + '](' + it.url + ')';
      return '[📎 ' + it.name + '](' + it.url + ')';
    }
    function mlInsertInto(md) {
      var s = Math.min(mlCaret.s, text.value.length), e = Math.min(mlCaret.e, text.value.length);
      try { text.setSelectionRange(s, e); } catch (err) {}
      insertBlock(md);
      updatePreview();
      armAutoSave();
    }
    function mlSetCover(it) {
      if (it.kind !== 'image') { mlSay('只有图片可以设为封面哦', true); return; }
      var ci = document.getElementById('coverInput'), cp = document.getElementById('coverPrev');
      if (ci) ci.value = it.url;
      if (cp) cp.innerHTML = '<img src="' + mlesc(it.url) + '" alt="">';
      refreshSeo();
      armAutoSave();
      mlSay('✅ 已将「' + it.name + '」设为封面');
      mlCloseWin();
    }

    function mlCard(it) {
      var card = document.createElement('div');
      card.className = 'ml-card';
      var thumb;
      if (it.kind === 'image') {
        thumb = '<img src="' + mlesc(it.url) + '" alt="' + mlesc(it.name) + '" loading="lazy">';
      } else {
        var ico = it.kind === 'video' ? '🎬' : (it.kind === 'audio' ? '🎵' : '📎');
        thumb = '<span class="ml-ph">' + ico + '<small>' + mlesc(it.ext) + '</small></span>';
      }
      card.innerHTML =
        '<div class="ml-thumb">' + thumb + '</div>' +
        '<div class="ml-name" title="' + mlesc(it.name) + '">' + mlesc(it.name) + '</div>' +
        '<div class="ml-meta">' + mlesc(it.size) + ' · ' + mlesc(it.time) +
          (it.used ? ' · 引用×' + it.used : '') + '</div>' +
        '<div class="ml-acts">' +
          '<button type="button" data-do="insert">' + (mlMode === 'cover' ? '🖼 用作封面' : '➕ 插入文章') + '</button>' +
          (it.kind === 'image' && mlMode !== 'cover' ? '<button type="button" data-do="cover">🖼 设为封面</button>' : '') +
          '<button type="button" data-do="del" title="删除">🗑</button>' +
        '</div>';
      card._item = it;
      return card;
    }

    function mlLoad(reset) {
      if (mlBusy) return;
      if (reset) { mlPage = 1; mlGrid.innerHTML = ''; }
      mlBusy = true;
      mlSay('正在读取资源…');
      mlPost({ act: 'list', q: mlQ.value.trim(), kind: mlKind, page: mlPage }, function (d) {
        mlBusy = false;
        if (!d.ok) { mlSay('❌ ' + (d.msg || '读取失败'), true); return; }
        mlCount.textContent = '共 ' + d.total + ' 个文件' + (mlMode === 'cover' ? ' · 点图片可直接设为封面' : '');
        (d.items || []).forEach(function (it) { mlGrid.appendChild(mlCard(it)); });
        mlMore.style.display = d.has_more ? '' : 'none';
        if (!mlGrid.querySelector('.ml-card')) {
          mlGrid.innerHTML = '<div class="ml-empty">📭 还没有找到资源<br>' +
            '<small>点左上角「上传图片/文件」上传，或换个关键词试试</small></div>';
        }
        mlSay('');
      });
    }

    function mlDelete(card, it) {
      if (!confirm('确定删除「' + it.name + '」吗？该操作不可恢复！')) return;
      function run(force) {
        var data = { act: 'delete', rel: it.rel || '' };
        if (it.rel64) data.rel64 = it.rel64;   /* 原始路径字节 base64，兼容历史 GBK 文件名 */
        if (force) data.force = 1;
        mlPost(data, function (r) {
          if (r.ok) {
            if (card.parentNode) card.parentNode.removeChild(card);
            var n = parseInt((mlCount.textContent.match(/\d+/) || [0])[0], 10);
            if (n > 0) mlCount.textContent = '共 ' + (n - 1) + ' 个文件';
            mlSay('🗑 已删除 ' + it.name);
          } else if (r.in_use) {
            if (confirm(r.msg)) run(true);
          } else {
            mlSay('❌ ' + (r.msg || '删除失败'), true);
          }
        });
      }
      run(false);
    }

    mlGrid.addEventListener('click', function (ev) {
      var card = mlFind(ev.target, function (n) {
        return n.className && String(n.className).indexOf('ml-card') >= 0;
      });
      if (!card || !card._item) return;
      var it = card._item;
      var btn = mlFind(ev.target, function (n) { return n.getAttribute && n.getAttribute('data-do'); });
      if (!btn) {
        if (mlMode === 'cover' && it.kind === 'image') mlSetCover(it);
        return;
      }
      var act = btn.getAttribute('data-do');
      if (act === 'insert') {
        if (mlMode === 'cover') { mlSetCover(it); return; }
        mlInsertInto(mlMd(it));
        mlSay('✅ 已插入：' + it.name);
        mlCloseWin();
      } else if (act === 'cover') {
        mlSetCover(it);
      } else if (act === 'del') {
        mlDelete(card, it);
      }
    });

    function mlCloseWin() {
      mlMask.hidden = true;
      document.body.classList.remove('ml-open');
      try { text.focus(); text.setSelectionRange(mlCaret.s, mlCaret.e); } catch (e) {}
    }
    function mlOpenWin(mode) {
      mlRemember();
      mlMode = mode || 'insert';
      mlKind = mlMode === 'cover' ? 'image' : 'all';
      Array.prototype.forEach.call(mlFilters.querySelectorAll('.ml-chip'), function (c) {
        c.className = c.getAttribute('data-kind') === mlKind ? 'ml-chip cur' : 'ml-chip';
      });
      mlMask.hidden = false;
      document.body.classList.add('ml-open');
      mlLoad(true);
    }
    window.__moeMediaOpen = mlOpenWin;

    document.getElementById('mlClose').addEventListener('click', mlCloseWin);
    mlMask.addEventListener('click', function (ev) { if (ev.target === mlMask) mlCloseWin(); });
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' && !mlMask.hidden) mlCloseWin();
    });
    mlFilters.addEventListener('click', function (ev) {
      var chip = mlFind(ev.target, function (n) {
        return n.className && String(n.className).indexOf('ml-chip') >= 0;
      });
      if (!chip || !chip.parentNode) return;
      mlKind = chip.getAttribute('data-kind') || 'all';
      Array.prototype.forEach.call(mlFilters.querySelectorAll('.ml-chip'), function (c) {
        c.className = c === chip ? 'ml-chip cur' : 'ml-chip';
      });
      mlLoad(true);
    });
    mlQ.addEventListener('input', function () {
      clearTimeout(mlQTimer);
      mlQTimer = setTimeout(function () { mlLoad(true); }, 300);
    });
    document.getElementById('mlSearch').addEventListener('click', function () {
      clearTimeout(mlQTimer); mlLoad(true);
    });
    mlMore.addEventListener('click', function () { mlPage++; mlLoad(false); });

    var ab = document.getElementById('attachBtn');
    if (ab) ab.addEventListener('click', function () { mlOpenWin('insert'); });
    var coverLibBtn = document.getElementById('coverLibBtn');
    if (coverLibBtn) coverLibBtn.addEventListener('click', function () { mlOpenWin('cover'); });

    /* 上传：统一走 scope=attach，图片 / 视频 / 音频 / 文档 / 压缩包都能传 */
    mlFile.addEventListener('change', function () {
      var files = Array.prototype.slice.call(this.files || []);
      this.value = '';
      if (!files.length) return;
      var done = 0, fail = 0, lastErr = '';
      function step(i) {
        if (i >= files.length) {
          mlSay(fail
            ? ('⚠️ 上传完成：成功 ' + done + ' 个，失败 ' + fail + ' 个' + (lastErr ? '（' + lastErr + '）' : ''))
            : ('✅ 已上传 ' + done + ' 个文件'), !!fail);
          mlLoad(true);
          return;
        }
        mlSay('⬆ 上传中（' + (i + 1) + '/' + files.length + '）：' + files[i].name, false);
        var fd = new FormData();
        fd.append('file', files[i]);
        fd.append('scope', 'attach');
        fd.append('_token', CSRF);
        fetch('upload.php', { method: 'POST', body: fd, credentials: 'same-origin' })
          .then(function (r) {
            // 2.2.6：非 JSON 响应（如超过 post_max_size 后 $_POST 被清空导致 403）也给出可读提示
            return r.text().then(function (t) {
              var d; try { d = JSON.parse(t); } catch (e) { d = { ok: 0, msg: t ? t.slice(0, 120) : '上传接口无响应（文件可能超出服务器大小限制）' }; }
              return d;
            });
          })
          .then(function (d) {
            if (d.ok) done++;
            else { fail++; lastErr = d.msg || '不支持该文件'; }
            step(i + 1);
          })
          .catch(function () { fail++; lastErr = '网络异常'; step(i + 1); });
      }
      step(0);
    });
  }
  /* ---------- 快捷键 ---------- */
  text.addEventListener('keydown', function (ev) {
    var mod = ev.ctrlKey || ev.metaKey;
    if (ev.key === 'Tab') {
      ev.preventDefault();
      setRange('    ', text.selectionStart, text.selectionEnd);
      updatePreview();
      return;
    }
    if (!mod) return;
    var k = ev.key.toLowerCase();
    if (k === 'b') { ev.preventDefault(); actions.bold(); updatePreview(); }
    else if (k === 'i') { ev.preventDefault(); actions.italic(); updatePreview(); }
    else if (k === 'k') { ev.preventDefault(); actions.link(); updatePreview(); }
    else if (k === 's') {
      ev.preventDefault();
      doSubmit();
    }
  });

  /* ---------- 字数 / 本地暂存（仅浏览器兜底，不写数据库） ---------- */
  var saveTimer = null;
  function onChange() {
    updateStat();
    updatePreview();
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveLocal, 1200);
    savedEl.textContent = '';
  }
  function saveLocal() {
    try {
      localStorage.setItem(DRAFT_KEY, JSON.stringify({
        title: document.getElementById('titleInput').value,
        content: text.value,
        ts: Date.now()
      }));
    } catch (e) {}
  }
  text.addEventListener('input', onChange);

  // 若有本地暂存且比库里内容新，提示恢复；比库里旧（已经发布/保存过）则直接清掉
  try {
    var saved = localStorage.getItem(DRAFT_KEY);
    if (saved) {
      var d = JSON.parse(saved);
      if (SAVED_TS > 0 && d.ts && d.ts <= SAVED_TS * 1000) {
        localStorage.removeItem(DRAFT_KEY);   // 内容早已入库（如发布成功后残留），不再打扰
      } else if (d.content && d.content !== text.value) {
        var bar = document.createElement('div');
        bar.className = 'ed-restore';
        bar.innerHTML = '发现 ' + new Date(d.ts).toLocaleString() + ' 浏览器本地暂存的内容 ' +
          '<button type="button" class="btn sm" id="edRestore">恢复</button>' +
          '<button type="button" class="btn ghost sm" id="edDrop">丢弃</button>';
        document.getElementById('edHint').parentNode.insertBefore(bar, document.getElementById('edHint'));
        bar.querySelector('#edRestore').onclick = function () {
          text.value = d.content;
          if (d.title) document.getElementById('titleInput').value = d.title;
          bar.remove();
          onChange();
        };
        bar.querySelector('#edDrop').onclick = function () {
          localStorage.removeItem(DRAFT_KEY);
          bar.remove();
        };
      }
    }
  } catch (e) {}

  /* ---------- 链接预览 ---------- */
  var urlPrev   = document.getElementById('urlPreview'),
      titleInput = document.getElementById('titleInput'),
      slugInput  = document.getElementById('slugInput');

  var catSel = document.querySelector('select[name="category_id"]');

  /* 1.9.7：页面别名留空时按标题预览真实链接，不再显示 page.html */
  function pageSlugGuess() {
    var s = (slugInput && slugInput.value || '').trim();
    if (s) return s;
    var t = (titleInput && titleInput.value || '').trim();
    if (!t) return '';
    t = t.replace(/\s+/g, '-').replace(/[\/\\?%#&='"<>|*:;]+/g, '-')
         .replace(/-{2,}/g, '-').replace(/^-+|-+$/g, '');
    if (!t || /^\d+$/.test(t)) t = '页面-' + t;
    return t.replace(/-+$/g, '');   // 与后端 moe_page_slug_clean 的 trim('-_') 保持一致
  }
  function makeUrl() {
    if (IS_PAGE) {
      var slug = pageSlugGuess();
      return slug ? BASE + encodeURIComponent(slug) + '.html' : BASE + '（填写标题后自动生成链接）';
    }
    if (STYLE === 'cat_num') {
      var cid = catSel ? String(catSel.value) : String(CUR_CAT);
      var dir = CATS[cid] || 'uncategorized';
      var num = (cid === String(CUR_CAT) && CUR_NUM > 0) ? CUR_NUM : (NEXT[cid] || 1);
      return BASE + dir + '/' + num + '.html';
    }
    return BASE + (PID > 0 ? PID : 1) + '.html';
  }
  function refreshSeo() {
    if (urlPrev) urlPrev.textContent = makeUrl();
  }
  [titleInput, slugInput, catSel].forEach(function (el) {
    if (el) el.addEventListener('input', refreshSeo);
    if (el && el.tagName === 'SELECT') el.addEventListener('change', refreshSeo);
  });

  /* ---------- 封面 ---------- */
  var input = document.getElementById('coverInput'), file = document.getElementById('coverFile'),
      prev = document.getElementById('coverPrev'), msg = document.getElementById('upMsg');
  input.addEventListener('input', function () {
    prev.innerHTML = this.value ? '<img src="' + this.value + '">' : '🌸';
  });
  file.addEventListener('change', function () {
    if (!this.files[0]) return;
    var fd = new FormData(), xhr = new XMLHttpRequest();
    fd.append('file', this.files[0]);
    fd.append('_token', CSRF);
    msg.textContent = '上传中…';
    msg.style.color = '#9a8fae';
    xhr.open('POST', 'upload.php');
    xhr.onload = function () {
      try {
        var d = JSON.parse(xhr.responseText);
        if (d.ok) { input.value = d.url; prev.innerHTML = '<img src="' + d.url + '">'; msg.textContent = '✅ 上传成功'; msg.style.color = '#3fb984'; refreshSeo(); }
        else { msg.textContent = '❌ ' + d.msg; msg.style.color = '#e0566b'; }
      } catch (e) { msg.textContent = '❌ 上传失败'; msg.style.color = '#e0566b'; }
    };
    xhr.send(fd);
  });

  /* ---------- 自动生成标签（1.8.3） ---------- */
  var tagsInput = document.getElementById('tagsInput');
  var autoTagBtn = document.getElementById('autoTagBtn');
  var tagHint = document.getElementById('tagHint');
  if (autoTagBtn && tagsInput) {
    autoTagBtn.addEventListener('click', function () {
      var t = titleInput ? titleInput.value.trim() : '';
      if (!t && !text.value.trim()) { if (tagHint) tagHint.textContent = '请先写点标题或正文，才有内容可提取关键词哦'; return; }
      autoTagBtn.disabled = true;
      autoTagBtn.textContent = '生成中…';
      var fd = new FormData();
      fd.append('title', t);
      fd.append('content', text.value);
      fd.append('_token', CSRF);
      fetch('autotag.php', { method: 'POST', body: fd })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          autoTagBtn.disabled = false;
          autoTagBtn.textContent = '✨ 自动生成';
          if (d.ok && d.tags && d.tags.length) {
            tagsInput.value = d.tags.join(',');
            if (tagHint) tagHint.textContent = '✅ 已生成 ' + d.tags.length + ' 个标签，可手动增删后再保存';
            armAutoSave();
          } else {
            if (tagHint) tagHint.textContent = '⚠️ ' + (d.msg || '没能提取出关键词，请手动填写');
          }
        })
        .catch(function () {
          autoTagBtn.disabled = false;
          autoTagBtn.textContent = '✨ 自动生成';
          if (tagHint) tagHint.textContent = '⚠️ 请求失败，请重试';
        });
    });
  }

  /* ---------- 自动保存草稿（仅未发布内容 · 空闲 5 分钟触发） ---------- */
  var AUTO_DRAFT = <?php echo $autoDraft ? json_encode(array('id' => (int)$autoDraft['id'], 'title' => (string)$autoDraft['title'], 'content' => (string)$autoDraft['content']), JSON_UNESCAPED_UNICODE) : 'null'; ?>;
  var IS_PUBLISHED = <?php echo ($post && $post['status'] === 'published') ? 'true' : 'false'; ?>;
  var IDLE_MS = 5 * 60 * 1000;  // 5 分钟无操作才自动保存
  var autoTimer = null, autoBusy = false, submitting = false, lastSig = '';
  var postIdEl = document.getElementById('postId');
  var excerptEl = document.getElementById('excerptInput');
  var coverEl   = document.getElementById('coverInput');

  function autoPayload() {
    var fd = new FormData();
    fd.append('_token', CSRF);
    fd.append('act', 'autosave');
    fd.append('type', IS_PAGE ? 'page' : 'post');
    fd.append('id', postIdEl ? (postIdEl.value || '0') : '0');
    fd.append('title', titleInput ? titleInput.value : '');
    fd.append('content', text.value);
    fd.append('slug', slugInput ? slugInput.value : '');
    fd.append('excerpt', excerptEl ? excerptEl.value : '');
    fd.append('cover', coverEl ? coverEl.value : '');
    fd.append('category_id', catSel ? catSel.value : '0');
    fd.append('tags', document.getElementById('tagsInput') ? document.getElementById('tagsInput').value : '');
    return fd;
  }
  function autoSave() {
    if (IS_PUBLISHED || autoBusy || submitting) return;
    var t = titleInput ? titleInput.value : '';
    if (!text.value.trim() && !t.trim()) return;
    // 内容没变就不用重复写库
    var sig = t + '|' + text.value + '|' + (excerptEl ? excerptEl.value : '') + '|' + (coverEl ? coverEl.value : '');
    if (sig === lastSig) return;
    autoBusy = true;
    fetch('autosave.php', { method: 'POST', body: autoPayload() })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        autoBusy = false;
        if (!d.ok) {
          savedEl.textContent = d.msg && d.msg.indexOf('已发布') >= 0 ? '' : ('⚠️ ' + (d.msg || '自动保存失败'));
          return;
        }
        lastSig = sig;
        if (postIdEl && (!postIdEl.value || postIdEl.value === '0') && d.id) {
          postIdEl.value = d.id;
          try {
            if (history.replaceState) history.replaceState(null, '', 'post-edit.php?id=' + d.id + (IS_PAGE ? '&type=page' : ''));
          } catch (e) {}
        }
        try { localStorage.removeItem(DRAFT_KEY); } catch (e) {}
        savedEl.textContent = '📝 草稿已自动保存 ' + (d.saved_at || '');
      })
      .catch(function () { autoBusy = false; savedEl.textContent = '⚠️ 自动保存失败（网络异常）'; });
  }
  function armAutoSave() {
    if (IS_PUBLISHED || submitting) return;
    clearTimeout(autoTimer);
    autoTimer = setTimeout(autoSave, IDLE_MS);
  }
  [text, titleInput, slugInput, excerptEl, coverEl].forEach(function (el) {
    if (!el) return;
    el.addEventListener('input', armAutoSave);
    el.addEventListener('change', armAutoSave);
  });
  /* 严格 5 分钟规则：只有空闲满 5 分钟才自动保存。
     切换标签页 / 关闭页面不再立即保存草稿（旧版会在这里秒存，导致草稿越攒越多） */

  // 正式提交（发布 / 保存）时立刻停掉自动保存，并清掉本地暂存，避免下次打开误提示
  var postForm = document.getElementById('postForm');
  function clearLocal() { try { localStorage.removeItem(DRAFT_KEY); } catch (e) {} }
  function doSubmit() {
    submitting = true;
    clearTimeout(autoTimer);
    clearLocal();
    postForm.submit();
  }
  if (postForm) postForm.addEventListener('submit', function () { submitting = true; clearTimeout(autoTimer); clearLocal(); });

  if (AUTO_DRAFT) {
    var adBar = document.getElementById('autoDraftBar');
    var adUse = document.getElementById('autoDraftUse');
    var adDrop = document.getElementById('autoDraftDrop');
    if (adUse) adUse.addEventListener('click', function () {
      text.value = AUTO_DRAFT.content || '';
      if (titleInput && AUTO_DRAFT.title) titleInput.value = AUTO_DRAFT.title;
      // 接续自动草稿槽位：后续自动保存原地更新这一篇，不会另存副本
      if (postIdEl && AUTO_DRAFT.id) {
        postIdEl.value = AUTO_DRAFT.id;
        try { if (history.replaceState) history.replaceState(null, '', 'post-edit.php?id=' + AUTO_DRAFT.id + (IS_PAGE ? '&type=page' : '')); } catch (e) {}
      }
      if (adBar) adBar.style.display = 'none';
      onChange();
      armAutoSave();
      updatePreview();
    });
    if (adDrop) adDrop.addEventListener('click', function () {
      if (adBar) adBar.style.display = 'none';
      var fd = new FormData();
      fd.append('_token', CSRF);
      fd.append('act', 'discard');
      fd.append('id', AUTO_DRAFT.id);
      fetch('autosave.php', { method: 'POST', body: fd }).catch(function () {});
    });
  }

  /* ---------- 初始化 ---------- */
  refreshSeo();
  updateStat();
})();
</script>

<?php include 'includes/footer.php'; ?>
