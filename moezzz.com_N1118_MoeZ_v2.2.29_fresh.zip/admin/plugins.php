<?php
/**
 * 后台 · 插件管理（2.0.2）
 * 上传 zip 插件包 / 卡片式展示 / 启用停用 / 删除 / 开发说明
 * 仅站长可访问（moe_admin_guard 白名单 + 本页二次校验）
 */
require __DIR__ . '/bootstrap.php';
$active     = 'plugins';
$page_title = '插件管理';

if (!function_exists('moe_is_owner') || !moe_is_owner()) {
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    echo '<div style="max-width:480px;margin:12vh auto;padding:28px;font:15px/1.8 system-ui,\'PingFang SC\',sans-serif;background:#fff;border-radius:18px;text-align:center;color:#4a4060">'
       . '<div style="font-size:38px">🔒</div><h2>插件管理仅站长可用</h2>'
       . '<p style="color:#8e83a5">插件会在站点上运行 PHP 代码，因此需要站长权限。</p>'
       . '<p style="margin-top:18px"><a href="index.php" style="color:#8f7bff">← 返回仪表盘</a></p></div>';
    exit;
}

/* ---------- 操作 ---------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = (string)($_POST['act'] ?? '');
    $id  = (string)($_POST['id'] ?? '');

    if ($act === 'upload') {
        $f = $_FILES['zipfile'] ?? null;
        if (!$f || ($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            flash('请先选择要上传的 .zip 插件包', 'bad');
        } elseif ($f['error'] !== UPLOAD_ERR_OK) {
            flash('上传失败（错误码 ' . (int)$f['error'] . '），请检查 PHP 上传限制', 'bad');
        } elseif (strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION)) !== 'zip') {
            flash('只接受 .zip 格式的插件包', 'bad');
        } elseif ($f['size'] > 20 * 1024 * 1024) {
            flash('插件包不能超过 20MB', 'bad');
        } else {
            $err = '';
            $newId = moe_plugin_install_zip($f['tmp_name'], (string)$f['name'], $err);
            if ($newId) {
                flash('插件「' . $newId . '」安装成功，确认无误后再点「启用」 🧩');
                if (function_exists('moe_content_changed')) moe_content_changed();
            } else {
                flash('安装失败：' . $err, 'bad');
            }
        }
    } elseif (in_array($act, array('enable', 'disable', 'delete'), true)) {
        if (!moe_plugin_id_valid($id)) {
            flash('插件 ID 不合法', 'bad');
        } else {
            $on = moe_plugins_enabled();
            if ($act === 'delete') {
                $on = array_values(array_diff($on, array($id)));
                moe_plugins_set_enabled($on);
                $ok = moe_plugin_remove_dir(moe_plugins_dir() . '/' . $id);
                flash($ok ? '插件「' . $id . '」已删除' : '删除失败，请检查目录权限', $ok ? 'ok' : 'bad');
            } elseif ($act === 'enable') {
                $meta = moe_plugin_meta($id);
                if (!$meta || $meta['entry'] === '') {
                    flash('插件缺少入口文件，无法启用', 'bad');
                } else {
                    $on[] = $id;
                    moe_plugins_set_enabled($on);
                    flash('插件「' . $meta['name'] . '」已启用 ✨');
                }
            } else {
                moe_plugins_set_enabled(array_values(array_diff($on, array($id))));
                flash('插件「' . $id . '」已停用');
            }
            if (function_exists('moe_content_changed')) moe_content_changed();
        }
    }
    redirect('plugins.php');
}

$list    = moe_plugins_scan();
$enabled = moe_plugins_enabled();
$zipOk   = class_exists('ZipArchive');
$dirOk   = function_exists('moe_plugins_prepare_dir') ? moe_plugins_prepare_dir() : false;
$errors  = function_exists('moe_plugin_last_errors') ? moe_plugin_last_errors() : array();
// 2.2.23：与官方版本清单比对（授权检测结果缓存，只读不联网），卡片标「可更新 / 已是最新」
$remote = function_exists('moe_auth_remote_versions')
    ? moe_auth_remote_versions()
    : array('themes' => array(), 'plugins' => array());

include 'includes/header.php';
?>

<div class="set-tabs" id="plugTabs" role="tablist" aria-label="插件管理">
  <button type="button" class="set-tab cur" id="tab-plug-list" data-pane="plug-list" role="tab" aria-selected="true" aria-controls="plug-list">📦 已安装插件 <span style="opacity:.75"><?php echo count($list); ?></span></button>
  <button type="button" class="set-tab" id="tab-plug-upload" data-pane="plug-upload" role="tab" aria-selected="false" aria-controls="plug-upload">📤 上传插件</button>
  <button type="button" class="set-tab" id="tab-plug-dev" data-pane="plug-dev" role="tab" aria-selected="false" aria-controls="plug-dev">📖 开发说明</button>
</div>

<!-- ============ 已安装插件 ============ -->
<div class="card set-pane cur" id="plug-list" role="tabpanel" aria-labelledby="tab-plug-list">
  <h2 class="card-title">已安装插件</h2>
  <p class="hint" style="margin:-6px 0 16px">
    共 <b><?php echo count($list); ?></b> 个插件，其中 <b><?php echo count($enabled); ?></b> 个已启用。
    上传后默认<b>停用</b>，确认来源可靠再启用；启用中的插件代码会在前台 / 后台真实运行。
  </p>

  <?php if (!empty($errors)): ?>
    <div class="plug-err" style="margin-bottom:14px">
      ⚠️ 本次请求中插件执行报错（已跳过，不影响站点）：<br><?php echo e(implode('；', array_slice($errors, 0, 5))); ?>
    </div>
  <?php endif; ?>

  <?php if (empty($list)): ?>
    <div style="text-align:center;padding:36px 12px;color:var(--muted)">
      <div style="font-size:40px">🧩</div>
      <p style="margin-top:8px">还没有安装任何插件</p>
      <p class="hint">可以切换到「📤 上传插件」安装第一个，或先看看「📖 开发说明」了解插件包格式。</p>
    </div>
  <?php else: ?>
    <div class="plug-grid">
      <?php foreach ($list as $p):
          // 2.2.23：官方版本比对
          $rv     = isset($remote['plugins'][$p['id']]) ? (string)$remote['plugins'][$p['id']] : '';
          $hasNew = $rv !== '' && version_compare($rv, (string)$p['version'], '>');
      ?>
        <div class="plug <?php echo $p['enabled'] ? '' : 'off'; ?>">
          <div class="plug-top">
            <div class="plug-ico"><?php echo e(mb_substr((string)$p['icon'], 0, 2, 'UTF-8')); ?></div>
            <div class="plug-tt">
              <div class="plug-name"><?php echo e($p['name']); ?></div>
              <div class="plug-meta">v<?php echo e($p['version']); ?> · <?php echo e($p['author']); ?> · <?php echo e($p['id']); ?></div>
            </div>
            <?php if ($hasNew): ?><span class="plug-tag" style="background:#fff3e0;color:#c77800" title="官方已发布新版本">⬆ 新版 v<?php echo e($rv); ?></span>
            <?php elseif ($rv !== ''): ?><span class="plug-tag" style="background:#e8f7ee;color:#2e9e5b" title="已与官方版本同步">✓ 最新</span>
            <?php endif; ?>
            <span class="plug-tag <?php echo $p['enabled'] ? '' : 'off'; ?>"><?php echo $p['enabled'] ? '已启用' : '已停用'; ?></span>
          </div>
          <div class="plug-desc"><?php echo e($p['description'] !== '' ? $p['description'] : '（插件未提供说明）'); ?></div>
          <div class="plug-meta">
            入口 <code><?php echo e($p['entry'] !== '' ? $p['entry'] : '缺失'); ?></code> ·
            <?php echo (int)$p['files']; ?> 个文件 · <?php echo number_format($p['size'] / 1024, 1); ?> KB
            <?php if (!$p['has_json']): ?> · <span style="color:var(--warn)">无 plugin.json（读头部注释）</span><?php endif; ?>
          </div>
          <?php if (!empty($p['hooks'])): ?>
            <div class="plug-meta">挂载点：<?php echo e(implode(' / ', array_slice((array)$p['hooks'], 0, 6))); ?></div>
          <?php endif; ?>
          <?php if ($p['error'] !== ''): ?><div class="plug-err">⚠️ <?php echo e($p['error']); ?></div><?php endif; ?>
          <div class="plug-foot">
            <?php if (function_exists('moe_auth_check')):
              if ($hasNew): ?>
              <!-- 2.2.23：官方有新版 → 高亮「更新到 vX」 -->
              <form data-upd method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="auth_update_plugin">
                <input type="hidden" name="slug" value="<?php echo e($p['id']); ?>">
                <input type="hidden" name="mode" value="zip">
                <button class="btn sm" type="submit" style="background:var(--grad);color:#fff;border:0"
                        title="官方最新版 v<?php echo e($rv); ?>，点击在线更新">⬆ 更新到 v<?php echo e($rv); ?></button>
              </form>
              <?php elseif ($rv === ''): ?>
              <!-- 官方清单里没有该插件（未授权 / 未收录）→ 保留手动尝试入口 -->
              <form data-upd method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="auth_update_plugin">
                <input type="hidden" name="slug" value="<?php echo e($p['id']); ?>">
                <input type="hidden" name="mode" value="zip">
                <button class="btn ghost sm" type="submit" title="尝试从官方更新源获取该插件的最新版">⬆ 检查更新</button>
              </form>
              <?php endif; /* rv!=='' 且无新版：不显示更新按钮（已是最新） */ ?>
            <?php endif; ?>
            <?php if ($p['enabled']): ?>
              <form method="post"><?php echo csrf_field(); ?><input type="hidden" name="act" value="disable"><input type="hidden" name="id" value="<?php echo e($p['id']); ?>">
                <button class="btn ghost sm" type="submit">⏸ 停用</button></form>
            <?php else: ?>
              <form method="post"><?php echo csrf_field(); ?><input type="hidden" name="act" value="enable"><input type="hidden" name="id" value="<?php echo e($p['id']); ?>">
                <button class="btn sm" type="submit">▶️ 启用</button></form>
            <?php endif; ?>
            <form method="post" onsubmit="return confirm('确定删除插件「<?php echo e($p['name']); ?>」？插件目录会被整个移除，此操作不可恢复。');">
              <?php echo csrf_field(); ?><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?php echo e($p['id']); ?>">
              <button class="btn ghost sm" type="submit" style="color:var(--bad)">🗑 删除</button>
            </form>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<!-- ============ 上传插件 ============ -->
<div class="card set-pane" id="plug-upload" role="tabpanel" aria-labelledby="tab-plug-upload">
  <h2 class="card-title">上传插件包</h2>
  <p class="hint" style="margin:-6px 0 16px">
    选择 <b>.zip</b> 插件包上传，程序会读取 <code>plugin.json</code>（或 PHP 头部注释）展示插件信息。
    安装后<b>默认停用</b>，请在「已安装插件」里手动启用。
  </p>

  <?php if (!$zipOk || !$dirOk): ?>
    <div class="plug-err" style="margin-bottom:14px">
      <?php if (!$zipOk): ?>⚠️ 当前 PHP 未开启 <b>zip 扩展</b>，无法解压插件包。请在宝塔面板 → 软件商店 → PHP 设置 → 安装「zip」扩展后重启 PHP。<br><?php endif; ?>
      <?php if (!$dirOk): ?>⚠️ 插件目录不可写：<code><?php echo e(moe_plugins_dir()); ?></code>，请将站点根目录权限设为可写（推荐 755，属主为 PHP 运行用户）。<?php endif; ?>
    </div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="upload">
    <div class="field">
      <label>插件压缩包（.zip，≤ 20MB）</label>
      <input type="file" name="zipfile" accept=".zip,application/zip" required>
    </div>
    <p class="hint" style="margin:0 0 14px">
      安全限制：包内不允许 <code>..</code> 越界路径、绝对路径、可执行文件；仅放行 php / json / css / js / 图片 / 字体 / 文本，
      最多 200 个文件、解压后合计 20MB。同名插件会被覆盖（旧目录先删除）。
    </p>
    <div class="form-foot" style="border-top:1px dashed var(--line);padding-top:16px;margin-top:6px">
      <button class="btn" type="submit" <?php echo (!$zipOk || !$dirOk) ? 'disabled' : ''; ?>>📤 上传并安装</button>
    </div>
  </form>
</div>

<!-- ============ 开发说明 ============ -->
<div class="card set-pane" id="plug-dev" role="tabpanel" aria-labelledby="tab-plug-dev">
  <h2 class="card-title">插件开发说明</h2>
  <div class="sub-h plain" style="margin-bottom:8px">目录结构</div>
  <pre class="plug-code">content/plugins/hello-moe/
├── plugin.json      插件信息（推荐）
└── plugin.php       入口文件，注册钩子</pre>

  <div class="sub-h plain" style="margin-bottom:8px">plugin.json</div>
  <pre class="plug-code">{
  "id":          "hello-moe",
  "name":        "示例插件",
  "version":     "1.0.0",
  "author":      "萌Z",
  "description": "在页面底部显示一行小字",
  "icon":        "🌸",
  "entry":       "plugin.php",
  "hooks":       ["front_footer"]
}</pre>
  <p class="hint" style="margin:8px 0 0">不写 plugin.json 也可以：在入口 PHP 头部用 <code>Plugin Name: / Version: / Author: / Description:</code> 注释，程序会自动解析。</p>

  <div class="sub-h plain" style="margin-bottom:8px">plugin.php</div>
  <pre class="plug-code">&lt;?php
moe_plugin_register('front_footer', function () {
    return '&lt;p style="text-align:center"&gt;🌸 来自示例插件&lt;/p&gt;';
});

// 后台菜单追加一项（过滤器型钩子）
moe_plugin_register('admin_menu', function ($menu) {
    $menu['hello'] = array('🌸', '示例', 'index.php');
    return $menu;
});</pre>

  <div class="sub-h plain" style="margin-bottom:8px">可用钩子</div>
  <div class="sys-grid" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">
    <div class="sys-item"><div class="k">前台 · 输出型</div><div class="v">front_head <small>注入 &lt;/head&gt; 前</small></div></div>
    <div class="sys-item"><div class="k">前台 · 输出型</div><div class="v">front_footer <small>注入 &lt;/body&gt; 前</small></div></div>
    <div class="sys-item"><div class="k">后台 · 过滤器</div><div class="v">admin_menu <small>接收并返回菜单数组</small></div></div>
    <div class="sys-item"><div class="k">后台 · 输出型</div><div class="v">admin_dashboard <small>仪表盘末尾追加卡片</small></div></div>
    <div class="sys-item"><div class="k">后台 · 输出型</div><div class="v">admin_footer <small>后台页脚前注入</small></div></div>
  </div>
  <p class="hint" style="margin-top:12px">
    输出型钩子可以 <code>return</code> 字符串，也可以直接 <code>echo</code>；过滤器型钩子必须 <code>return</code> 处理后的值。
    插件报错会被单独捕获并记录，不会让整站白屏。启用插件后前台页面缓存会自动关闭，保证插件内容实时生效。
  </p>
</div>

<script>
(function () {
  'use strict';
  var box = document.getElementById('plugTabs');
  if (!box) return;
  function show(id) {
    if (!document.getElementById(id)) id = 'plug-list';
    Array.prototype.forEach.call(box.querySelectorAll('.set-tab'), function (t) {
      var on = t.dataset.pane === id;
      t.className = on ? 'set-tab cur' : 'set-tab';
      t.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    Array.prototype.forEach.call(document.querySelectorAll('.set-pane'), function (p) {
      p.className = (p.id === id ? 'card set-pane cur' : 'card set-pane');
    });
  }
  box.addEventListener('click', function (ev) {
    var t = ev.target;
    while (t && t !== box && !(t.dataset && t.dataset.pane)) t = t.parentNode;
    if (t && t !== box && t.dataset && t.dataset.pane) show(t.dataset.pane);
  });
})();
</script>

<script>
/* 2.2.5：在线更新 / 删除 —— fetch 提交到 update-check.php，弹窗显示结果后刷新
   2.2.16：与模板管理一致——按钮显示已用时、结果弹窗点确定后再刷新、HTTP 状态检查 */
(function () {
  Array.prototype.forEach.call(document.querySelectorAll('form[data-upd]'), function (f) {
    f.addEventListener('submit', function (ev) {
      ev.preventDefault();
      if (f.dataset.confirm && !window.confirm(f.dataset.confirm)) return;
      var btn = f.querySelector('button');
      var orig = btn ? btn.textContent : '';
      if (btn) { btn.disabled = true; btn.textContent = '⏳ 处理中…'; }
      var fd = new FormData(f);
      fd.set('confirm', '1');
      var t0 = Date.now();
      var timer = setInterval(function () {
        if (!btn) return;
        var s = Math.round((Date.now() - t0) / 1000);
        btn.textContent = '⏳ 处理中 ' + s + 's（解析+下载约 1~2 分钟，请勿关闭）';
      }, 1000);
      fetch('update-check.php', { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) {
          if (!r.ok) throw new Error('服务器返回 HTTP ' + r.status + '（网关超时会报 502/504，可稍后重试）');
          return r.text();
        })
        .then(function (t) {
          clearInterval(timer);
          var m = null;
          try { m = JSON.parse(t); } catch (e) { /* 非 JSON（HTML 错误页） */ }
          var msg = m ? ((m.ok ? '✅ ' : '❌ ') + (m.msg || m.error || '操作完成')) : t.slice(0, 400);
          window.alert(msg, function () { window.location.reload(); });
        })
        .catch(function (e) {
          clearInterval(timer);
          window.alert('❌ 请求失败：' + e + '\n\n常见原因：蓝奏云解析 / 大文件下载耗时较长被服务器网关掐断（502/504）。可再试一次；多次失败建议改用官方站直链 zip 或「上传更新包」。', function () {
            if (btn) { btn.disabled = false; btn.textContent = orig; }
          });
        });
    });
  });
})();
</script>

<?php include 'includes/footer.php'; ?>
