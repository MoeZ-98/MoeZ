<?php
/**
 * 后台 · 自动生成标签（AJAX 端点）
 * 2.2.13：AI 配置就绪时优先用大模型生成标签（更懂语义、更贴合内容）；
 *         未配置 AI / 超配额 / 调用失败时，静默回退原纯 PHP 关键词提取，编辑器体验不变。
 */
require __DIR__ . '/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

$token = isset($_POST['_token']) ? (string)$_POST['_token'] : '';
if ($token === '' || empty($_SESSION['moe_csrf']) || !hash_equals((string)$_SESSION['moe_csrf'], $token)) {
    json_exit(false, '令牌校验失败，请刷新页面重试');
}

if (!function_exists('moe_auto_tags')) {
    json_exit(false, '关键词模块未加载，请确认程序文件完整');
}

$title   = trim((string)($_POST['title'] ?? ''));
$content = (string)($_POST['content'] ?? '');
$existing = trim((string)($_POST['tags'] ?? ''));

/** 已手动填写的标签保留在前，避免被生成结果覆盖丢失 */
$mergeExisting = function (array $tags) use ($existing) {
    foreach (post_tags(array('tags' => $existing)) as $t) {
        if (!in_array($t, $tags, true)) array_unshift($tags, $t);
    }
    return array_values(array_slice($tags, 0, 8));
};

$tags = array();
$msg = '';

/* ---------- 1) AI 生成（配置就绪才尝试） ---------- */
if (function_exists('moe_ai_ready') && moe_ai_ready()) {
    $plain = trim(strip_tags($content));
    if (function_exists('mb_substr')) $plain = mb_substr($plain, 0, 3000, 'UTF-8');
    else $plain = substr($plain, 0, 6000);

    $prompt = "你是博客文章的标签助手。根据标题和正文，提炼 4~6 个最能代表内容主题的简短标签：\n"
        . "- 每个标签 2~8 个字，可以是关键词、技术名词或内容主题\n"
        . "- 不要重复、不要互相包含、不要无意义的泛词（如「分享」「文章」）\n"
        . "- 只输出一个 JSON 数组，形如 [\"标签1\",\"标签2\"]，不要任何解释\n\n"
        . "标题：" . $title . "\n正文：" . $plain;

    /* 标签生成不占用看板娘对话配额太多：占 1 条配额，低温 + 限输出，避免长思考 */
    if (function_exists('moe_ai_quota_take')) moe_ai_quota_take(1);
    $r = moe_ai_chat(array(
        array('role' => 'system', 'content' => '你是一个中文博客标签生成器，只输出 JSON 数组。'),
        array('role' => 'user', 'content' => $prompt),
    ), array('temp' => 0.3, 'max_tokens' => 200, 'timeout' => 20));

    if (!empty($r['ok'])) {
        $txt = (string)$r['text'];
        /* 容错：剥掉可能的 ```json 围栏和前后杂文字，取第一个 [ ... ] 段 */
        if (preg_match('/\[.*\]/s', $txt, $m)) {
            $arr = json_decode($m[0], true);
            if (is_array($arr)) {
                foreach ($arr as $t) {
                    $t = trim((string)$t);
                    if ($t === '' || function_exists('mb_strlen') && mb_strlen($t, 'UTF-8') > 12) continue;
                    if (!in_array($t, $tags, true)) $tags[] = $t;
                    if (count($tags) >= 6) break;
                }
            }
        }
        if ($tags) {
            $msg = 'AI 已生成 ' . count($mergeExisting($tags)) . ' 个标签 ✨';
        }
    }
}

/* ---------- 2) 回退：纯 PHP 关键词提取（未配 AI / AI 失败时） ---------- */
if (!$tags) {
    $tags = moe_auto_tags($title, $content, 6);
}

$tags = $mergeExisting($tags);
if (empty($tags)) {
    json_exit(false, '没能从标题和正文里提取出关键词，试试手动填写');
}
if ($msg === '') $msg = '已生成 ' . count($tags) . ' 个标签';
json_exit(true, $msg, array('tags' => $tags));
