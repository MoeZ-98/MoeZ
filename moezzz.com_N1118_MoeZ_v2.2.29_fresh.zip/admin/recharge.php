<?php
/**
 * 2.2.4：金币充值已并入「积分商城」页（points.php?tab=recharge），
 * 本文件仅做兼容跳转，不再独立渲染。
 */
require __DIR__ . '/bootstrap.php';
redirect('points.php?tab=recharge');
