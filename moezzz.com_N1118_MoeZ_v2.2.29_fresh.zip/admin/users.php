<?php
/**
 * 后台 · 用户管理（2.0.0，仅站长）
 * 新增账号 / 改角色 / 启停 / 重置密码 / 删除。
 * 安全约束：不能停用或删除自己、不能删掉最后一个站长、删除用户时其文章转给当前站长。
 */
require __DIR__ . '/bootstrap.php';
$active = 'users';
$page_title = '用户管理';

$me = current_user();
if (!$me) redirect('login.php');
if (!moe_is_owner()) { flash('只有站长可以管理用户', 'bad'); redirect('index.php'); }

$t = moe_table('users');

/** 仍然有效的站长数量 */
function moe_active_admin_count()
{
    try {
        return (int)one('SELECT COUNT(*) FROM ' . moe_table('users') . " WHERE role = 'admin' AND status = 'active'");
    } catch (Throwable $e) { return 1; }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = (string)($_POST['act'] ?? '');
    $id  = (int)($_POST['id'] ?? 0);
    $self = (int)$me['id'];

    if ($act === 'add') {
        $name  = trim((string)($_POST['username'] ?? ''));
        $pass  = (string)($_POST['password'] ?? '');
        $mail  = trim((string)($_POST['email'] ?? ''));
        $nick  = trim((string)($_POST['nickname'] ?? ''));
        $role  = (string)($_POST['role'] ?? 'member');
        if (!in_array($role, array('member', 'author', 'admin'), true)) $role = 'member';
        if (!preg_match('/^[\x{4e00}-\x{9fa5}A-Za-z0-9_]{2,32}$/u', $name)) {
            flash('用户名需 2~32 位，支持中文、字母、数字、下划线', 'bad');
        } elseif (strlen($pass) < 6) {
            flash('密码至少 6 位', 'bad');
        } elseif ($mail !== '' && !filter_var($mail, FILTER_VALIDATE_EMAIL)) {
            flash('邮箱格式不正确', 'bad');
        } elseif (row('SELECT id FROM ' . $t . ' WHERE username = ?', array($name))) {
            flash('用户名「' . $name . '」已被占用', 'bad');
        } elseif ($mail !== '' && row('SELECT id FROM ' . $t . ' WHERE email = ?', array($mail))) {
            flash('该邮箱已被其他账号使用', 'bad');
        } else {
            q('INSERT INTO ' . $t . ' (username,password,email,nickname,role,status,created_at) VALUES (?,?,?,?,?,?,NOW())',
                array($name, password_hash($pass, PASSWORD_DEFAULT), $mail,
                      $nick !== '' ? $nick : $name, $role, 'active'));
            flash('账号「' . $name . '」已创建 ✅');
        }
    } elseif ($act === 'role') {
        $role = (string)($_POST['role'] ?? 'member');
        if (!in_array($role, array('member', 'author', 'admin'), true)) $role = 'member';
        $target = moe_user_by($id);
        if (!$target) {
            flash('用户不存在', 'bad');
        } elseif ($id === $self && $role !== 'admin') {
            flash('不能降低自己的站长权限', 'bad');
        } elseif ($target['role'] === 'admin' && $role !== 'admin' && moe_active_admin_count() <= 1) {
            flash('至少要保留一位站长', 'bad');
        } else {
            q('UPDATE ' . $t . ' SET role = ? WHERE id = ?', array($role, $id));
            flash('角色已更新为「' . moe_user_role_label($role) . '」');
        }
    } elseif ($act === 'status') {
        $target = moe_user_by($id);
        if ($id === $self) {
            flash('不能停用自己的账号', 'bad');
        } elseif ($target) {
            $new = (string)$target['status'] === 'active' ? 'disabled' : 'active';
            if ($new === 'disabled' && $target['role'] === 'admin' && moe_active_admin_count() <= 1) {
                flash('至少要保留一位有效站长', 'bad');
            } else {
                q('UPDATE ' . $t . ' SET status = ? WHERE id = ?', array($new, $id));
                flash($new === 'active' ? '账号已启用' : '账号已停用');
            }
        }
    } elseif ($act === 'reset') {
        $target = moe_user_by($id);
        if ($target) {
            $newPass = substr(bin2hex(random_bytes(5)), 0, 10);
            q('UPDATE ' . $t . ' SET password = ? WHERE id = ?',
                array(password_hash($newPass, PASSWORD_DEFAULT), $id));
            flash('「' . $target['username'] . '」的新密码：' . $newPass . '（请立即复制，仅显示这一次）', 'warn');
        }
    } elseif ($act === 'delete') {
        $target = moe_user_by($id);
        if ($id === $self) {
            flash('不能删除自己的账号', 'bad');
        } elseif ($target) {
            if ($target['role'] === 'admin' && (string)$target['status'] === 'active' && moe_active_admin_count() <= 1) {
                flash('至少要保留一位站长', 'bad');
            } else {
                try { q('UPDATE ' . moe_table('posts') . ' SET user_id = ? WHERE user_id = ?', array($self, $id)); }
                catch (Throwable $e) { /* 忽略 */ }
                try { q('UPDATE ' . moe_table('comments') . ' SET user_id = 0 WHERE user_id = ?', array($id)); }
                catch (Throwable $e) { /* 老表无 user_id 字段时忽略 */ }
                q('DELETE FROM ' . $t . ' WHERE id = ?', array($id));
                flash('用户已删除，其文章已转给你');
            }
        }
    }
    if (function_exists('moe_content_changed')) moe_content_changed();
    redirect('users.php');
}

$users = rows('SELECT * FROM ' . $t . ' ORDER BY id ASC LIMIT 200');
$counts = array();
try {
    foreach (rows('SELECT user_id, COUNT(*) AS n FROM ' . moe_table('posts') . " WHERE type = 'post' GROUP BY user_id") as $r) {
        $counts[(int)$r['user_id']] = (int)$r['n'];
    }
} catch (Throwable $e) { /* 忽略 */ }

include 'includes/header.php';
?>

<style>
  .usr-name { display:flex; align-items:center; gap:9px; min-width:150px; }
  .usr-name img { width:34px; height:34px; border-radius:50%; object-fit:cover; flex:none; }
  .usr-name b { font-size:13.5px; font-weight:600; }
  .usr-name small { display:block; color:var(--muted); font-size:11.5px; }
  .usr-role { display:flex; gap:6px; align-items:center; }
  .usr-role select { padding:6px 9px; border:1.5px solid #e8e2f0; border-radius:8px; font-size:12.5px; background:#fff; }
  .usr-add { display:grid; grid-template-columns:repeat(auto-fit,minmax(170px,1fr)); gap:0 14px; }
  @media (max-width:700px) {
    .usr-role { flex-wrap:wrap; }
    .usr-role select { flex:1; min-width:110px; }
    .usr-add { grid-template-columns:1fr; }
  }
</style>

<div class="card">
  <div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:14px">
    <h2 class="card-title" style="margin:0">全部用户（<?php echo count($users); ?>）</h2>
    <span style="flex:1"></span>
    <a class="btn ghost sm" href="<?php echo e(base_url() . 'user'); ?>" target="_blank">🏠 前台用户中心 ↗</a>
  </div>
  <p class="hint" style="margin:-4px 0 14px">
    <b>站长</b>：全部权限 · <b>作者</b>：可进后台写文章与管理内容 · <b>会员</b>：仅前台评论与个人资料。
    会员登录后无法进入后台；前台注册开关在「站点设置 → 功能设置」。
  </p>

  <div class="table-wrap">
    <table class="tbl">
      <thead><tr><th>用户</th><th>邮箱</th><th>角色</th><th>状态</th><th>文章</th><th>注册时间</th><th>操作</th></tr></thead>
      <tbody>
      <?php foreach ($users as $u): ?>
        <tr>
          <td class="t-title">
            <div class="usr-name">
              <img src="<?php echo e(moe_user_avatar($u)); ?>" alt="">
              <div><b><?php echo e(moe_user_display($u)); ?></b><small>@<?php echo e($u['username']); ?><?php echo (int)$u['id'] === (int)$me['id'] ? ' · 我' : ''; ?></small></div>
            </div>
          </td>
          <td style="font-size:12.5px;word-break:break-all"><?php echo e($u['email'] !== '' ? $u['email'] : '—'); ?></td>
          <td>
            <form method="post" class="usr-role">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="act" value="role">
              <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
              <select name="role">
                <?php foreach (array('member' => '会员', 'author' => '作者', 'admin' => '站长') as $rk => $rv): ?>
                  <option value="<?php echo $rk; ?>" <?php echo moe_user_role($u) === $rk ? 'selected' : ''; ?>><?php echo $rv; ?></option>
                <?php endforeach; ?>
              </select>
              <button class="btn ghost sm" type="submit">保存</button>
            </form>
          </td>
          <td>
            <form method="post" style="display:inline">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="act" value="status">
              <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
              <button class="pill <?php echo (string)$u['status'] === 'active' ? 'ok' : 'warn'; ?>" type="submit"
                      style="border:0;cursor:pointer" title="点击切换启用状态"><?php echo (string)$u['status'] === 'active' ? '正常' : '已停用'; ?></button>
            </form>
          </td>
          <td><span class="pill violet"><?php echo (int)($counts[(int)$u['id']] ?? 0); ?></span></td>
          <td style="color:var(--muted);font-size:12.5px"><?php echo e(date('Y-m-d', strtotime((string)$u['created_at']))); ?></td>
          <td>
            <div class="acts">
              <a class="btn ghost sm" href="<?php echo e(moe_user_url($u)); ?>" target="_blank">主页</a>
              <form method="post" onsubmit="return confirm('重置「<?php echo e($u['username']); ?>」的密码？新密码会显示一次。')">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="reset">
                <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
                <button class="btn ghost sm" type="submit">重置密码</button>
              </form>
              <form method="post" onsubmit="return confirm('删除用户「<?php echo e($u['username']); ?>」？其文章会转给你，评论保留。')">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="act" value="delete">
                <input type="hidden" name="id" value="<?php echo (int)$u['id']; ?>">
                <button class="btn danger sm" type="submit">删除</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<div class="card">
  <h2 class="card-title">＋ 新增账号</h2>
  <p class="hint" style="margin:-6px 0 16px">手动创建作者 / 会员账号，不必走前台注册。新建账号默认「正常」状态。</p>
  <form method="post">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="act" value="add">
    <div class="usr-add">
      <div class="field"><label>用户名 *</label><input type="text" name="username" required placeholder="2~32 位，中文/字母/数字/下划线"></div>
      <div class="field"><label>密码 *（至少 6 位）</label><input type="password" name="password" required autocomplete="new-password"></div>
      <div class="field"><label>昵称</label><input type="text" name="nickname" placeholder="留空用用户名"></div>
      <div class="field"><label>邮箱</label><input type="email" name="email" placeholder="选填"></div>
      <div class="field"><label>角色</label>
        <select name="role">
          <option value="member">会员（仅前台）</option>
          <option value="author">作者（可进后台发文）</option>
          <option value="admin">站长（全部权限）</option>
        </select>
      </div>
    </div>
    <div class="form-foot" style="border-top:1px dashed var(--line);padding-top:16px;margin-top:6px">
      <button class="btn" type="submit">＋ 创建账号</button>
    </div>
  </form>
</div>

<?php include 'includes/footer.php'; ?>
