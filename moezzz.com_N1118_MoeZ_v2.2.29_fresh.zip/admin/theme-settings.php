<?php
/**
 * 后台 · 模板设置（卡片网格版）
 *
 * 用法：替换程序根目录下的 admin/theme-settings.php（建议先备份原文件）。
 * 与程序原版保持一致的部分：
 *   - 仍从当前模板 templates/{dir}/info.php 读取 settings 声明；
 *   - 提交字段名仍是 opt_{key}（bool 未勾选存 0、勾选存 1），保存键 themeopt_{模板}_{key}；
 *   - 仍使用 csrf_field() / csrf_verify() 与 flash() / redirect()。
 * 变化只在呈现层：
 *   - 按设置项的 group 字段分组，未声明 group 的归入「其他设置」；
 *   - 每项渲染成一张卡片，响应式网格排列，长文本卡片自动占满整行；
 *   - 顶部提供分组快捷跳转，底部保存栏吸底。
 */
require __DIR__ . '/bootstrap.php';
$active = 'themeopts';
$page_title = '模板设置';

$curTheme = theme();
$tset = theme_settings($curTheme);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    foreach (theme_settings($curTheme) as $row) {
        $k = 'themeopt_' . $curTheme . '_' . $row['key'];
        if ($row['type'] === 'bool') {
            setting_set($k, isset($_POST['opt_' . $row['key']]) ? '1' : '0');
        } else {
            setting_set($k, trim((string)($_POST['opt_' . $row['key']] ?? '')));
        }
    }
    flash('模板设置已保存 🎨');
    redirect('theme-settings.php');
}

/* 按 group 分组，保留 info.php 中的声明顺序 */
$groups = array();
foreach ($tset as $row) {
    $g = isset($row['group']) ? trim((string)$row['group']) : '';
    if ($g === '') $g = '其他设置';
    $groups[$g][] = $row;
}

/* 分组顺序：按下面顺序排列，未列出的分组按 info.php 声明顺序接在后面 */
$groupOrder = array('品牌与外观', '首页设置', '导航与用户', '侧栏与资料卡', '文章、评论与页面', '积分与商城', '友链与检测', '页脚与站点数据', '版娘与语音');
$sorted = array();
foreach ($groupOrder as $g) {
    if (isset($groups[$g])) { $sorted[$g] = $groups[$g]; unset($groups[$g]); }
}
$groups = $sorted + $groups;

$groupDesc = array(
    '品牌与外观'       => '站点标识、主色调与头图',
    '首页设置'         => '首屏大图、精选大卡 / 索引区 / 文章卡片三个独立区块',
    '导航与用户'       => '顶部菜单、用户入口与浮标开关',
    '侧栏与资料卡'     => '侧栏模块显隐、资料卡文案与社交入口',
    '文章、评论与页面' => '列表展示、评论功能、统计页与关于页',
    '积分与商城'       => '商城 / 下载中心页面别名与商城说明（积分规则在「积分商城」管理）',
    '友链与检测'       => '友链页文案、评论与自动检测/失联展示',
    '页脚与站点数据'   => '页脚格言、备案、友链磁贴、公告与建站日期',
    '版娘与语音'       => '由「萌Z 版娘」插件提供，7 套主题通用：显示、立绘、男女声与调试',
    '其他设置'         => '模板未指定 group 的设置项',
);

$groupIcon = array(
    '品牌与外观'       => '🎨',
    '首页设置'         => '🏠',
    '导航与用户'       => '🧭',
    '侧栏与资料卡'     => '📐',
    '文章、评论与页面' => '📝',
    '积分与商城'       => '🛒',
    '友链与检测'       => '🔗',
    '页脚与站点数据'   => '📄',
    '其他设置'         => '⚙️',
    '版娘与语音'       => '🎙',
);

$typeLabel = array('text' => '文本', 'color' => '色彩', 'bool' => '开关', 'select' => '下拉', 'textarea' => '长文本');

include 'includes/header.php';
?>

<style>
/* 模板设置 · 卡片网格 */
.fo-set-lead{
  display:flex; gap:14px; align-items:center; flex-wrap:wrap;
  background:linear-gradient(135deg,#f3f0ff,#eef9ff);
}
.fo-set-lead .fo-set-face{ font-size:30px; }
.fo-set-lead h2{ font-size:15.5px; }
.fo-set-lead h2 b{
  background:var(--grad); -webkit-background-clip:text; background-clip:text; color:transparent;
}
.fo-set-lead p{ font-size:12.5px; color:var(--muted); }
.fo-set-lead .spacer{ flex:1; }

/* 设置搜索框 */
.fo-set-search{ display:flex; align-items:center; gap:10px; margin:0 0 12px; }
.fo-set-search input{
  flex:1; min-width:0; padding:10px 14px; border:1.5px solid #e8e2f0; border-radius:12px;
  font-size:13px; color:var(--text); background:#faf8ff; outline:none; transition:.2s; font-family:inherit;
}
.fo-set-search input:focus{ border-color:var(--violet); background:#fff; box-shadow:0 0 0 3px rgba(161,140,209,.15); }
.fo-set-q-count{ flex:none; font-size:12px; color:var(--muted); }
.fo-set-card.is-hit{ border-color:#c9b8ee; box-shadow:0 0 0 2px rgba(161,140,209,.18); }
.fo-set-group{ margin:0 0 22px; }
.fo-set-group-head{ display:flex; align-items:center; gap:10px; margin:0 0 12px; flex-wrap:wrap; }
.fo-set-group-head h3{
  font-size:14.5px; display:flex; align-items:center; gap:8px; color:#4b3f5e;
}
.fo-set-group-head h3::before{
  content:""; width:4px; height:15px; border-radius:4px; background:var(--grad); display:block;
}
.fo-set-group-head span{ font-size:11.5px; color:var(--muted); }
.fo-set-group-head p{ font-size:11.5px; color:var(--muted); margin-left:auto; }

.fo-set-grid{
  display:grid; grid-template-columns:repeat(auto-fill, minmax(268px, 1fr));
  gap:14px; align-items:start;
}
.fo-set-card{
  background:#fff; border:1px solid #eee9f7; border-radius:14px;
  padding:14px 15px 13px; box-shadow:0 6px 18px rgba(146,120,200,.07);
  display:flex; flex-direction:column; gap:9px;
  transition:transform .2s ease, box-shadow .2s ease, border-color .2s ease;
}
.fo-set-card:hover{
  transform:translateY(-2px); border-color:#e3dbf3; box-shadow:0 12px 26px rgba(146,120,200,.14);
}
.fo-set-card.is-wide{ grid-column:1 / -1; }
.fo-set-card-head{ display:flex; align-items:flex-start; gap:8px; }
.fo-set-name{ font-size:13px; font-weight:600; color:#4b3f5e; line-height:1.55; flex:1; min-width:0; }
.fo-set-type{
  flex:none; font-size:10.5px; color:#a18cd1; background:#f6f2ff;
  border-radius:999px; padding:1px 8px; line-height:18px;
}
.fo-set-card .fo-set-control{ display:flex; flex-direction:column; gap:8px; }
.fo-set-card input[type=text],
.fo-set-card select,
.fo-set-card textarea{
  width:100%; padding:9px 11px; border:1.5px solid #e8e2f0; border-radius:10px;
  font-size:13px; color:var(--text); background:#fff; outline:none; transition:.2s;
  font-family:inherit;
}
.fo-set-card input[type=text]:focus,
.fo-set-card select:focus,
.fo-set-card textarea:focus{ border-color:var(--violet); box-shadow:0 0 0 3px rgba(161,140,209,.15); }
.fo-set-card textarea{ resize:vertical; line-height:1.7; }
.fo-set-color{ display:flex; gap:8px; align-items:center; }
.fo-set-color input[type=color]{
  flex:none; width:44px; height:38px; padding:2px; border:1.5px solid #e8e2f0;
  border-radius:10px; background:#fff; cursor:pointer;
}
.fo-set-hint{ margin:0; font-size:11.5px; line-height:1.65; color:var(--muted); }

/* 开关卡片 */
.fo-set-switch{ display:flex; align-items:center; gap:10px; cursor:pointer; user-select:none; }
.fo-set-switch input{ position:absolute; opacity:0; width:0; height:0; }
.fo-set-switch i{
  position:relative; flex:none; width:42px; height:23px; border-radius:999px;
  background:#e6e0f2; transition:background .2s; display:block;
}
.fo-set-switch i::after{
  content:""; position:absolute; top:3px; left:3px; width:17px; height:17px; border-radius:50%;
  background:#fff; box-shadow:0 2px 6px rgba(75,63,94,.22); transition:transform .2s;
}
.fo-set-switch input:checked + i{ background:var(--grad); }
.fo-set-switch input:checked + i::after{ transform:translateX(19px); }
.fo-set-switch input:focus-visible + i{ box-shadow:0 0 0 3px rgba(161,140,209,.25); }
.fo-set-switch span{ font-size:12.5px; color:var(--muted); }
.fo-set-switch input:checked ~ span{ color:var(--ok); font-weight:600; }

.fo-set-save{
  position:sticky; bottom:0; z-index:6; margin-top:4px;
  display:flex; align-items:center; gap:14px; flex-wrap:wrap;
  padding:14px 18px; border-radius:14px; background:rgba(255,255,255,.9);
  border:1px solid var(--line); box-shadow:0 -6px 22px rgba(146,120,200,.12);
  backdrop-filter:blur(10px);
}
.fo-set-save .hint{ margin:0; }
@media (max-width:720px){
  .fo-set-grid{ grid-template-columns:1fr; }
  .fo-set-save{ position:static; }
}
</style>

<div class="card fo-set-lead">
  <span class="fo-set-face">🖌</span>
  <div>
    <h2>正在配置模板：<b><?php echo e($curTheme); ?></b></h2>
    <p>设置项由模板的 <code>info.php</code> 声明，按分组排成卡片；各模板独立保存，改完记得前台预览效果 ↗</p>
  </div>
  <div class="spacer"></div>
  <?php if (is_file(__DIR__ . '/points.php')): ?><a class="btn ghost sm" href="points.php">🛒 积分商城管理</a><?php elseif (is_file(__DIR__ . '/theme-shop.php')): ?><a class="btn ghost sm" href="theme-shop.php">🛒 积分商城管理</a><?php endif; ?>
  <a class="btn ghost sm" href="themes.php">🎨 返回模板管理</a>
  <a class="btn ghost sm" href="<?php echo e(base_url()); ?>" target="_blank">前台预览 ↗</a>
</div>

<?php if (empty($tset)): ?>
<div class="card">
  <h2 class="card-title">无可配置项</h2>
  <p class="hint" style="margin:0">当前模板「<?php echo e($curTheme); ?>」没有声明任何设置项。模板作者可在
    <code>templates/<?php echo e($curTheme); ?>/info.php</code> 的 <code>settings</code> 数组中声明
    text / color / bool / select / textarea 类型设置项，并可用 <code>group</code> 指定卡片所在分组。</p>
</div>
<?php else: ?>
<form method="post">
  <?php echo csrf_field(); ?>
  <input type="hidden" name="act" value="saveopts">

  <div class="fo-set-search">
    <input type="search" id="fo-set-q" placeholder="🔍 搜索设置项，如：签到 / 友链 / 大卡…" autocomplete="off">
    <span class="fo-set-q-count" id="fo-set-q-count" hidden></span>
  </div>

  <!-- 选项卡栏（与站点设置同款交互） -->
  <div class="set-tabs" id="setTabs" role="tablist" aria-label="模板设置">
    <?php $gi = 0; foreach ($groups as $gname => $rows): $gi++; ?>
      <button type="button" class="set-tab<?php echo $gi === 1 ? ' cur' : ''; ?>" id="tab-pane-<?php echo $gi; ?>" data-pane="pane-<?php echo $gi; ?>" role="tab" aria-selected="<?php echo $gi === 1 ? 'true' : 'false'; ?>" aria-controls="pane-<?php echo $gi; ?>"><?php echo isset($groupIcon[$gname]) ? $groupIcon[$gname] . ' ' : ''; ?><?php echo e($gname); ?></button>
    <?php endforeach; ?>
  </div>

  <?php $gi = 0; foreach ($groups as $gname => $rows): $gi++; ?>
  <div class="card set-pane<?php echo $gi === 1 ? ' cur' : ''; ?>" id="pane-<?php echo $gi; ?>" role="tabpanel" data-name="<?php echo e($gname); ?>">
      <div class="fo-set-group-head" style="margin-bottom:14px">
        <h3><?php echo isset($groupIcon[$gname]) ? $groupIcon[$gname] : ''; ?> <?php echo e($gname); ?></h3>
        <span><?php echo count($rows); ?> 项</span>
        <?php if (isset($groupDesc[$gname])): ?><p><?php echo e($groupDesc[$gname]); ?></p><?php endif; ?>
      </div>
      <div class="fo-set-grid">
        <?php foreach ($rows as $row): ?>
          <?php
            $key = $row['key'];
            $curVal = setting('themeopt_' . $curTheme . '_' . $key, $row['default']);
            $isWide = in_array($row['type'], array('textarea'), true);
          ?>
          <div class="fo-set-card<?php echo $isWide ? ' is-wide' : ''; ?>" data-name="<?php echo e($row['label'] . ' ' . (string)$row['hint'] . ' ' . $key); ?>">
            <div class="fo-set-card-head">
              <span class="fo-set-name"><?php echo e($row['label']); ?></span>
              <span class="fo-set-type"><?php echo e(isset($typeLabel[$row['type']]) ? $typeLabel[$row['type']] : $row['type']); ?></span>
            </div>

            <div class="fo-set-control">
              <?php if ($row['type'] === 'bool'): ?>
                <label class="fo-set-switch">
                  <input type="checkbox" name="opt_<?php echo e($key); ?>" <?php echo $curVal === '1' ? 'checked' : ''; ?>>
                  <i></i>
                  <span><?php echo $curVal === '1' ? '已开启' : '已关闭'; ?></span>
                </label>
              <?php elseif ($row['type'] === 'color'): ?>
                <div class="fo-set-color">
                  <input type="color" value="<?php echo e(preg_match('/^#[0-9a-fA-F]{6}$/', $curVal) ? $curVal : $row['default']); ?>"
                         id="cp_<?php echo e($key); ?>">
                  <input type="text" name="opt_<?php echo e($key); ?>" value="<?php echo e($curVal); ?>"
                         id="tx_<?php echo e($key); ?>" placeholder="#35b8ab">
                </div>
              <?php elseif ($row['type'] === 'select'): ?>
                <select name="opt_<?php echo e($key); ?>">
                  <?php foreach ((array)$row['options'] as $ov => $ol): ?>
                    <option value="<?php echo e($ov); ?>" <?php echo (string)$curVal === (string)$ov ? 'selected' : ''; ?>><?php echo e($ol); ?></option>
                  <?php endforeach; ?>
                </select>
              <?php elseif ($row['type'] === 'textarea'): ?>
                <textarea name="opt_<?php echo e($key); ?>" rows="3"><?php echo e($curVal); ?></textarea>
              <?php else: ?>
                <input type="text" name="opt_<?php echo e($key); ?>" value="<?php echo e($curVal); ?>">
              <?php endif; ?>
            </div>

            <?php if ($row['hint']): ?><p class="fo-set-hint"><?php echo e($row['hint']); ?></p><?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
  </div>
  <?php endforeach; ?>

  <div class="fo-set-save">
    <button class="btn" type="submit">💾 保存模板设置</button>
    <span class="hint">保存后前台立即生效（样式 / 开关类设置刷新页面即可看到）</span>
  </div>
</form>
<?php endif; ?>

<script>
/* 取色器与文本框联动 */
document.querySelectorAll('input[type=color][id^=cp_]').forEach(function (c) {
  var tx = document.getElementById('tx_' + c.id.slice(3));
  if (tx) c.addEventListener('input', function () { tx.value = this.value; });
});
/* 开关文字随勾选状态切换 */
document.querySelectorAll('.fo-set-switch input[type=checkbox]').forEach(function (box) {
  var txt = box.parentNode.querySelector('span');
  if (!txt) return;
  box.addEventListener('change', function () {
    txt.textContent = this.checked ? '已开启' : '已关闭';
  });
});
/* 选项卡切换（与站点设置同款，记住上次停留的页签） */
(function () {
  var tabBox = document.getElementById('setTabs');
  var panes = document.querySelectorAll('.set-pane');
  var activeId = null;

  function showPane(id) {
    activeId = id;
    var ts = tabBox ? tabBox.querySelectorAll('.set-tab') : [];
    Array.prototype.forEach.call(ts, function (t) {
      var on = t.dataset.pane === id;
      t.className = on ? 'set-tab cur' : 'set-tab';
      t.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    Array.prototype.forEach.call(panes, function (p) {
      p.className = p.id === id ? 'card set-pane cur' : 'card set-pane';
    });
    try { localStorage.setItem('moe_foset_tab', id); } catch (e) {}
  }
  if (tabBox) {
    tabBox.addEventListener('click', function (ev) {
      var t = ev.target;
      while (t && t !== tabBox && !(t.dataset && t.dataset.pane)) t = t.parentNode;
      if (t && t !== tabBox && t.dataset && t.dataset.pane) showPane(t.dataset.pane);
    });
    (function () {
      var last = null;
      try { last = localStorage.getItem('moe_foset_tab'); } catch (e) {}
      if (last && document.getElementById(last)) showPane(last);
      else if (panes[0]) activeId = panes[0].id;
    })();
  }
  /* 搜索时展开全部页签、清空后回到当前页签 */
  window.foSetSearchHook = function (kw) {
    if (!panes.length) return;
    if (kw !== '') {
      Array.prototype.forEach.call(panes, function (p) { p.className = 'card set-pane cur'; });
    } else {
      showPane(activeId || panes[0].id);
    }
  };
})();
/* 分组跳转（已改为选项卡，保留占位避免旧引用报错） */
/* 设置项搜索：输入即过滤，命中的卡片高亮、空分组隐藏 */
(function () {
  var q = document.getElementById('fo-set-q');
  if (!q) return;
  var countEl = document.getElementById('fo-set-q-count');
  var cards = Array.prototype.slice.call(document.querySelectorAll('.fo-set-card'));
  var timer = null;
  q.addEventListener('input', function () {
    clearTimeout(timer);
    timer = setTimeout(function () {
      var kw = q.value.trim().toLowerCase();
      var hits = 0;
      cards.forEach(function (card) {
        var ok = kw === '' || (card.getAttribute('data-name') || '').toLowerCase().indexOf(kw) !== -1;
        card.style.display = ok ? '' : 'none';
        card.classList.toggle('is-hit', ok && kw !== '');
        if (ok) hits++;
      });
      if (typeof window.foSetSearchHook === 'function') window.foSetSearchHook(kw);
      if (kw !== '') {
        document.querySelectorAll('.set-pane').forEach(function (p) {
          var visible = p.querySelectorAll('.fo-set-card:not([style*="none"])').length;
          p.style.display = visible ? '' : 'none';
        });
      } else {
        document.querySelectorAll('.set-pane').forEach(function (p) { p.style.display = ''; });
      }
      if (countEl) {
        countEl.hidden = kw === '';
        countEl.textContent = kw === '' ? '' : '命中 ' + hits + ' 项';
      }
    }, 120);
  });
})();
</script>

<?php include 'includes/footer.php'; ?>