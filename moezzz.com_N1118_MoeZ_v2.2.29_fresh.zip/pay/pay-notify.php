<?php
/**
 * MoeZ · 第三方支付回调端点（2.2.1）
 * ------------------------------------------------------------
 * 网关地址（后台「金币充值 → 第三方接口」配置的 recharge_api_url）完成收款后，
 * 服务端回调本端点自动为用户加金币：
 *   POST / GET：order_no, uid, money(支付金额), sign
 *   sign = HMAC-SHA256(订单号|金额|用户ID, recharge_secret) 前 32 位大写
 * 幂等：同一订单重复回调只入账一次；响应 success（大网关约定）或 JSON。
 */
define('MOE_PAY_NOTIFY', true);
require dirname(__DIR__) . '/init.php';

header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');

if (!function_exists('moe_rc_notify')) {
    http_response_code(500);
    echo 'fail: recharge module missing';
    exit;
}

$orderNo = (string)($_REQUEST['order_no'] ?? ($_REQUEST['out_trade_no'] ?? ''));
$money   = (string)($_REQUEST['money'] ?? ($_REQUEST['price'] ?? ($_REQUEST['amount'] ?? '')));
$uid     = (int)($_REQUEST['uid'] ?? ($_REQUEST['user_id'] ?? 0));
$sign    = (string)($_REQUEST['sign'] ?? '');

if ($money === '' && isset($_REQUEST['amount'])) $money = (string)$_REQUEST['amount'];

$r = moe_rc_notify($orderNo, (float)$money, $uid, $sign);
if (!empty($r['ok'])) {
    echo 'success';
} else {
    http_response_code(400);
    echo 'fail: ' . (string)($r['msg'] ?? 'unknown');
}
