<?php
/**
 * MoeZ · 充值订单状态查询端点（2.2.3）
 * ------------------------------------------------------------
 * 供用户中心「支付状态实时跟踪」轮询使用：
 * 用户扫码 / 网关支付后，页面每 4 秒查一次自己的订单状态，
 * 站长后台确认到账（或网关回调 pay-notify.php 入账）后，
 * 用户页面自动收到通知并刷新，无需手动刷新或返回。
 *
 * 安全：必须登录（session），只返回当前登录用户自己的订单，
 * 不接受外部传入的 uid —— 无法枚举他人订单。
 */
require dirname(__DIR__) . '/init.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if (!function_exists('moe_rc_orders_load')) {
    echo json_encode(array('ok' => 0, 'msg' => '充值模块未加载'));
    exit;
}

$uid = isset($_SESSION['moe_uid']) ? (int)$_SESSION['moe_uid'] : 0;
if ($uid <= 0) {
    http_response_code(401);
    echo json_encode(array('ok' => 0, 'msg' => '请先登录'));
    exit;
}

// 最近 10 条订单（含状态、金额、金币、时间；驳回时附原因）
$mine = array();
foreach (moe_rc_user_orders($uid, 10) as $o) {
    $mine[] = array(
        'no'      => (string)($o['no'] ?? ''),
        'amount'  => (string)($o['amount'] ?? ''),
        'coins'   => (string)($o['coins'] ?? ''),
        'status'  => (string)($o['status'] ?? ''),
        'time'    => (string)($o['time'] ?? ''),
        'done_at' => (string)($o['done_at'] ?? ''),
        'note'    => (string)($o['done_note'] ?? ''),
    );
}

echo json_encode(array('ok' => 1, 'uid' => $uid, 'orders' => $mine), JSON_UNESCAPED_UNICODE);
exit;
