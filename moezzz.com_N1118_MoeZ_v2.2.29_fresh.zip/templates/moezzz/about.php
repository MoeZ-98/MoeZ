<?php
/**
 * moezzz 模板 · 关于（/about）
 * 可用变量：$site $nav_cats（无额外变量）
 * 站点资料取自 $site（含 stats，来自 site_stats()）；可结合 site()/setting() 读取其它设置项。
 */
$page_title = '关于';
$cur_p = 'about';
$card_class = 'card--wide';
include partial_path('header.php');

$ava   = !empty($site['avatar']) ? media_url($site['avatar']) : '';
$stats = (isset($site['stats']) && is_array($site['stats'])) ? $site['stats'] : array();
$sp    = isset($stats['posts']) ? (int)$stats['posts'] : 0;
$sc    = isset($stats['comments']) ? (int)$stats['comments'] : 0;
$sv    = isset($stats['views']) ? (int)$stats['views'] : 0;
$site_desc = isset($site['desc']) ? (string)$site['desc'] : '';
$site_sub  = isset($site['sub']) ? (string)$site['sub'] : '';
$site_sign = isset($site['signature']) ? (string)$site['signature'] : '';
$desc  = $site_desc !== '' ? $site_desc : '这里记录代码、生活与一些小小的好奇。';
$sign  = $site_sign !== '' ? $site_sign : ($site_sub !== '' ? $site_sub : '记录想法与日常的小角落');
?>

      <header class="article-head">
        <h1>关于 · About</h1>
        <div class="article-meta">
          <span><?php echo e($site['name']); ?></span>
          <?php if (!empty($site['sub'])): ?><span><?php echo e($site['sub']); ?></span><?php endif; ?>
          <span>Moe Home v<?php echo e(isset($moe_ver) ? $moe_ver : (defined('MOE_VERSION') ? MOE_VERSION : '1.1.0')); ?></span>
        </div>
      </header>

      <section class="zz-about-head">
        <?php if ($ava): ?>
          <img decoding="async" class="zz-about-ava" src="<?php echo e($ava); ?>" alt="<?php echo e($site['name']); ?>" referrerpolicy="no-referrer">
        <?php else: ?>
          <span class="zz-about-ava"><?php echo e(initial($site['name'])); ?></span>
        <?php endif; ?>
        <div>
          <h2 class="zz-about-name"><?php echo e($site['name']); ?></h2>
          <p class="zz-about-sig"><?php echo e($sign); ?></p>
        </div>
      </section>

      <div class="md-body">
        <p><?php echo e($desc); ?></p>
        <p>目前共有 <b><?php echo $sp; ?></b> 篇文章、<b><?php echo $sc; ?></b> 条评论，累计被浏览 <b><?php echo $sv; ?></b> 次。</p>
        <p>想聊聊的话，可以从下面的入口找到我。</p>
      </div>

      <section class="zz-about-stats">
        <div class="zz-about-stat"><b><?php echo $sp; ?></b><span>文章</span></div>
        <div class="zz-about-stat"><b><?php echo $sc; ?></b><span>评论</span></div>
        <div class="zz-about-stat"><b><?php echo $sv; ?></b><span>浏览</span></div>
      </section>

      <nav class="zz-about-links" aria-label="联系方式">
        <?php if (!empty($site['github'])): ?><a class="zz-about-btn" href="<?php echo e($site['github']); ?>" target="_blank" rel="noopener nofollow">GitHub</a><?php endif; ?>
        <?php if (!empty($site['bilibili'])): ?><a class="zz-about-btn" href="<?php echo e($site['bilibili']); ?>" target="_blank" rel="noopener nofollow">哔哩哔哩</a><?php endif; ?>
        <?php if (!empty($site['weibo'])): ?><a class="zz-about-btn" href="<?php echo e($site['weibo']); ?>" target="_blank" rel="noopener nofollow">微博</a><?php endif; ?>
        <?php if (!empty($site['twitter'])): ?><a class="zz-about-btn" href="<?php echo e($site['twitter']); ?>" target="_blank" rel="noopener nofollow">X / Twitter</a><?php endif; ?>
        <?php if (!empty($site['mail'])): ?><a class="zz-about-btn" href="mailto:<?php echo e($site['mail']); ?>">写信给我</a><?php endif; ?>
        <?php if (!empty($site['rss'])): ?><a class="zz-about-btn" href="<?php echo e(rss_url()); ?>">RSS 订阅</a><?php endif; ?>
        <?php foreach ((array)$site['socials'] as $soc): ?>
          <?php if (!empty($soc['url'])): ?>
            <a class="zz-about-btn" href="<?php echo e($soc['url']); ?>" target="_blank" rel="noopener nofollow"><?php echo e(!empty($soc['name']) ? $soc['name'] : '链接'); ?></a>
          <?php endif; ?>
        <?php endforeach; ?>
      </nav>

      <nav class="zz-about-nav" aria-label="站内入口">
        <a href="<?php echo e(home_url()); ?>">首页</a>
        <a href="<?php echo e(base_url() . 'archives'); ?>">归档</a>
        <a href="<?php echo e(base_url() . 'blog/article'); ?>">写作</a>
        <a href="<?php echo e(base_url() . 'life'); ?>">点滴</a>
        <a href="<?php echo e(base_url() . 'link'); ?>">友链</a>
      </nav>

<?php include partial_path('footer.php'); ?>
