<?php
/**
 * moezzz 模板 · 分类列表
 * 可用变量：$cat $posts $pager $total $site $nav_cats
 */
$page_title = '分类：' . $cat['name'];
$cur_p = 'category';
$card_class = 'card--wide';
include partial_path('header.php');
?>

      <header class="article-head">
        <h1><?php echo e($cat['name']); ?></h1>
        <div class="article-meta">
          <span>共 <b><?php echo (int)$total; ?></b> 篇</span>
          <?php if (!empty($cat['description'])): ?><span><?php echo e($cat['description']); ?></span><?php endif; ?>
        </div>
      </header>

      <div class="chips" style="justify-content:flex-start;margin:0 0 20px">
        <a class="chip" href="<?php echo e(home_url()); ?>"><span class="dot"></span>全部</a>
        <?php foreach ($nav_cats as $c): ?>
          <a class="chip" href="<?php echo e(cat_url($c)); ?>"
             style="<?php echo $c['id'] == $cat['id'] ? 'border-color:rgba(45,212,191,.7);color:#eaf6ff' : ''; ?>">
            <span class="dot <?php echo $c['id'] == $cat['id'] ? 'lime' : ''; ?>"></span><?php echo e($c['name']); ?>
          </a>
        <?php endforeach; ?>
      </div>

      <?php if (empty($posts)): ?>
        <div class="empty-box">
          <span class="big">🍂</span>
          <p>这个分类下还没有文章～</p>
          <a class="cta" href="<?php echo e(home_url()); ?>">回到首页</a>
        </div>
      <?php else: ?>
        <div class="posts-grid">
          <?php foreach ($posts as $p): ?>
            <article class="post <?php echo post_cover($p) ? 'has-cover' : ''; ?>">
              <?php if (post_cover($p)): ?>
                <a class="post-cover" href="<?php echo e(post_url($p)); ?>">
                  <img decoding="async" src="<?php echo e(media_url(post_cover($p))); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy">
                </a>
              <?php endif; ?>
              <h3 class="post-title"><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
              <p class="post-excerpt"><?php echo e(post_excerpt($p)); ?></p>
              <div class="post-meta">
                <span class="pm-d"><?php echo e(format_time($p['created_at'], 'Y-m-d')); ?></span>
                <span class="pm-v"><?php echo isset($p['views']) ? (int)$p['views'] : 0; ?> 阅</span>
                <span class="pm-v"><?php echo function_exists('one') ? (int)one('SELECT COUNT(*) FROM ' . moe_table('comments') . " WHERE post_id=? AND status='approved'", array($p['id'])) : 0; ?> 评</span>
              </div>
            </article>
          <?php endforeach; ?>
        </div>
        <?php echo $pager; ?>
      <?php endif; ?>

<?php include partial_path('footer.php'); ?>
