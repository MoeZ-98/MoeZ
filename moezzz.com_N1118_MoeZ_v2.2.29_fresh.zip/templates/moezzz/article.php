<?php
/**
 * moezzz 模板 · 全部文章（/blog/article）
 * 可用变量：$posts $pager $total $page $cats（含 count）$sel_cat
 */
$page_title = '写作 · 全部文章';
$cur_p = 'article';
$card_class = 'card--wide';
include partial_path('header.php');

$sel = isset($sel_cat) && $sel_cat !== '' ? (int)$sel_cat : 0;
?>

      <header class="article-head">
        <h1>写作 · 全部文章</h1>
        <div class="article-meta">
          <span>共 <b><?php echo (int)$total; ?></b> 篇</span>
          <?php if (isset($page) && (int)$page > 1): ?><span>第 <?php echo (int)$page; ?> 页</span><?php endif; ?>
          <span><a href="<?php echo e(base_url() . 'archives'); ?>" style="color:inherit;border-bottom:1px solid rgba(255,255,255,.25);text-decoration:none">归档视图 →</a></span>
        </div>
      </header>

      <div class="chips" style="justify-content:flex-start;margin:0 0 20px">
        <a class="chip" href="<?php echo e(base_url() . 'blog/article'); ?>"
           style="<?php echo $sel === 0 ? 'border-color:rgba(45,212,191,.7);color:#eaf6ff' : ''; ?>">
          <span class="dot <?php echo $sel === 0 ? 'lime' : ''; ?>"></span>全部
        </a>
        <?php foreach ((array)(isset($cats) ? $cats : array()) as $c): ?>
          <?php $is_cur = $sel > 0 && isset($c['id']) && (int)$c['id'] === $sel; ?>
          <a class="chip" href="<?php echo e(cat_url($c)); ?>"
             style="<?php echo $is_cur ? 'border-color:rgba(45,212,191,.7);color:#eaf6ff' : ''; ?>">
            <span class="dot <?php echo $is_cur ? 'lime' : ''; ?>"></span><?php echo e(isset($c['name']) ? $c['name'] : ''); ?><?php if (isset($c['count'])): ?><small style="color:var(--muted);margin-left:2px"><?php echo (int)$c['count']; ?></small><?php endif; ?>
          </a>
        <?php endforeach; ?>
      </div>

      <?php if (empty($posts)): ?>
        <div class="empty-box">
          <span class="big">📝</span>
          <p>还没有文章，登录后台写下第一篇吧～</p>
          <a class="cta" href="<?php echo e(base_url() . 'admin/'); ?>">前往后台</a>
        </div>
      <?php else: ?>
        <div class="posts-grid">
          <?php foreach ($posts as $p): ?>
            <article class="post <?php echo post_cover($p) ? 'has-cover' : ''; ?>">
              <?php if (post_cover($p)): ?>
                <a class="post-cover" href="<?php echo e(post_url($p)); ?>">
                  <img decoding="async" src="<?php echo e(media_url(post_cover($p))); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy">
                </a>
              <?php endif; ?>
              <h3 class="post-title"><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
              <p class="post-excerpt"><?php echo e(post_excerpt($p)); ?></p>
              <div class="post-meta">
                <?php if (!empty($p['cat_name'])): ?><span class="tag"><?php echo e($p['cat_name']); ?></span><?php endif; ?>
                <?php if (!empty($p['is_top'])): ?><span class="tag" style="color:#ffd28a">置顶</span><?php endif; ?>
                <span class="pm-d"><?php echo isset($p['created_at']) ? e(format_time($p['created_at'], 'Y-m-d')) : ''; ?></span>
                <span class="pm-v"><?php echo isset($p['views']) ? (int)$p['views'] : 0; ?> 阅</span>
                <span class="pm-v">约 <?php echo e(reading_time($p)); ?> 分钟</span>
              </div>
            </article>
          <?php endforeach; ?>
        </div>
        <?php echo $pager; ?>
      <?php endif; ?>

<?php include partial_path('footer.php'); ?>
