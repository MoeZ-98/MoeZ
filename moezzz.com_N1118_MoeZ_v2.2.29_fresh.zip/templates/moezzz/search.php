<?php
/**
 * moezzz 模板 · 搜索结果
 * 可用变量：$posts $kw $pager $total $site $nav_cats
 */
$page_title = '搜索：' . $kw;
$cur_p = 'search';
$card_class = 'card--wide';
include partial_path('header.php');
?>

      <header class="article-head">
        <h1>搜索 · <?php echo e($kw); ?></h1>
        <div class="article-meta">
          <span>找到 <b><?php echo (int)$total; ?></b> 条结果</span>
          <span><a href="<?php echo e(home_url()); ?>" style="color:inherit;border-bottom:1px solid rgba(255,255,255,.25);text-decoration:none">返回首页</a></span>
        </div>
      </header>

      <?php if (empty($posts)): ?>
        <div class="empty-box">
          <span class="big">🫧</span>
          <p>没有找到「<?php echo e($kw); ?>」相关的内容，换个关键词试试？</p>
          <a class="cta" href="<?php echo e(home_url()); ?>">回到首页</a>
        </div>
      <?php else: ?>
        <div class="posts-grid">
          <?php foreach ($posts as $p): ?>
            <article class="post <?php echo post_cover($p) ? 'has-cover' : ''; ?>">
              <?php if (post_cover($p)): ?>
                <a class="post-cover" href="<?php echo e(post_url($p)); ?>">
                  <img decoding="async" src="<?php echo e(media_url(post_cover($p))); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy">
                </a>
              <?php endif; ?>
              <h3 class="post-title"><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
              <p class="post-excerpt"><?php echo e(post_excerpt($p)); ?></p>
              <div class="post-meta">
                <span class="pm-d"><?php echo e(format_time($p['created_at'], 'Y-m-d')); ?></span>
                <span class="pm-v"><?php echo isset($p['views']) ? (int)$p['views'] : 0; ?> 阅</span>
              </div>
            </article>
          <?php endforeach; ?>
        </div>
        <?php echo $pager; ?>
      <?php endif; ?>

<?php include partial_path('footer.php'); ?>
