<?php
/**
 * moezzz 模板 · 友链申请弹窗（footer.php 与 link.php 共用）
 * 依赖：$site；提交接口为 base_url() . 'link.php'
 * 说明：申请按钮 #flApplyBtn 在各自模板里，弹窗结构只出现一次，避免 ID 冲突。
 */
$mine_name = isset($site['name']) ? (string)$site['name'] : '';
$mine_url  = base_url();
$mine_desc = !empty($site['desc']) ? (string)$site['desc'] : (!empty($site['signature']) ? (string)$site['signature'] : '');
$mine_ava  = !empty($site['avatar']) ? media_url($site['avatar']) : '';
?>
<div class="fl-modal" id="flModal" hidden>
  <div class="fl-modal-mask" data-fl-close></div>

  <div class="fl-modal-panel" role="dialog" aria-modal="true" aria-labelledby="flModalTitle">
    <button type="button" class="fl-modal-x" id="flModalClose" aria-label="关闭">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
    </button>

    <h3 class="fl-modal-title" id="flModalTitle">申请友链</h3>
    <p class="fl-modal-sub">先把本站加进你的友链，再提交下面的表单；通过后会出现在友链列表里。</p>

    <section class="fl-mine" aria-label="本站信息">
      <p class="fl-mine-title">本站信息 · 加到你的友链里</p>
      <div class="fl-mine-head">
        <?php if ($mine_ava !== ''): ?>
          <img class="fl-mine-ava" src="<?php echo e($mine_ava); ?>" alt="<?php echo e($mine_name); ?>" decoding="async" referrerpolicy="no-referrer">
        <?php else: ?>
          <span class="fl-mine-ava"><?php echo e(initial($mine_name)); ?></span>
        <?php endif; ?>
        <div class="fl-mine-id">
          <b><?php echo e($mine_name); ?></b>
          <?php if ($mine_desc !== ''): ?><span><?php echo e($mine_desc); ?></span><?php endif; ?>
        </div>
      </div>

      <div class="fl-mine-row">
        <span class="fl-mine-k">名称</span>
        <code id="flMineName"><?php echo e($mine_name); ?></code>
        <button type="button" class="fl-copy" data-copy="flMineName">复制</button>
      </div>
      <div class="fl-mine-row">
        <span class="fl-mine-k">地址</span>
        <code id="flMineUrl"><?php echo e($mine_url); ?></code>
        <button type="button" class="fl-copy" data-copy="flMineUrl">复制</button>
      </div>
      <?php if ($mine_desc !== ''): ?>
      <div class="fl-mine-row">
        <span class="fl-mine-k">描述</span>
        <code id="flMineDesc"><?php echo e($mine_desc); ?></code>
        <button type="button" class="fl-copy" data-copy="flMineDesc">复制</button>
      </div>
      <?php endif; ?>
    </section>

    <form class="fl-form" id="flForm">
      <?php echo csrf_field(); ?>
      <div class="fl-form-row">
        <input type="text" name="url" placeholder="你的站点地址 *（如 https://example.com）" required>
      </div>
      <div class="fl-form-row">
        <input type="text" name="name" placeholder="站点名称（留空自动获取站点标题）">
        <input type="text" name="contact" placeholder="联系方式（选填，审核结果通知用）">
      </div>
      <div class="fl-form-foot">
        <span class="fl-form-hint">提交后会自动访问你的站点检测回链：已加自动通过展示，未加转人工审核</span>
        <button type="submit" class="fl-form-btn">提交申请</button>
      </div>
      <p class="fl-form-msg" id="flMsg" role="status" aria-live="polite"></p>
    </form>
  </div>
</div>