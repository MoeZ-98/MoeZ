<?php
/**
 * moezzz 模板 · 点滴时间线（/life）
 * 可用变量：$groups（'YYYY-MM' => 文章行数组，行内额外含 comment_count）、$total、$life_cat
 */
$page_title = '点滴';
$cur_p = 'life';
$card_class = 'card--wide';
include partial_path('header.php');

$life_name = isset($life_cat['name']) ? (string)$life_cat['name'] : '点滴';
?>

      <header class="article-head">
        <h1>点滴 · <?php echo e($life_name); ?></h1>
        <div class="article-meta">
          <span>共 <b><?php echo (int)$total; ?></b> 条</span>
          <span>日常的碎片，按月收拢</span>
          <?php if (isset($life_cat['id'])): ?>
            <span><a href="<?php echo e(cat_url($life_cat)); ?>" style="color:inherit;border-bottom:1px solid rgba(255,255,255,.25);text-decoration:none">查看分类 →</a></span>
          <?php endif; ?>
        </div>
      </header>

      <?php if (empty($groups)): ?>
        <div class="empty-box">
          <span class="big">🪷</span>
          <p>还没有点滴记录，去「<?php echo e($life_name); ?>」分类写点什么吧～</p>
          <a class="cta" href="<?php echo e(home_url()); ?>">回到首页</a>
        </div>
      <?php else: ?>
        <div class="zz-life">
          <?php foreach ($groups as $month => $items): ?>
            <?php $items = (array)$items; ?>
            <section class="zz-life-group">
              <h2 class="zz-life-month">
                <span class="zz-life-m"><?php echo e($month); ?></span>
                <span class="zz-life-c"><?php echo count($items); ?> 条</span>
              </h2>
              <div class="zz-life-list">
                <?php foreach ($items as $p): ?>
                  <article class="zz-life-item">
                    <span class="zz-life-dot" aria-hidden="true"></span>
                    <time class="zz-life-time"><?php echo isset($p['created_at']) ? e(format_time($p['created_at'], 'm-d H:i')) : ''; ?></time>
                    <div class="zz-life-body">
                      <a class="zz-life-title" href="<?php echo e(post_url($p)); ?>"><?php echo e(isset($p['title']) ? $p['title'] : ''); ?></a>
                      <p class="zz-life-text"><?php echo e(post_excerpt($p, 120)); ?></p>
                      <span class="zz-life-meta">
                        <?php echo isset($p['comment_count']) ? (int)$p['comment_count'] : 0; ?> 条评论
                        <?php if (!empty($p['views'])): ?> · <?php echo (int)$p['views']; ?> 阅读<?php endif; ?>
                        · 约 <?php echo e(reading_time($p)); ?> 分钟
                      </span>
                    </div>
                  </article>
                <?php endforeach; ?>
              </div>
            </section>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

<?php include partial_path('footer.php'); ?>
