<?php header('Content-Type: text/html; charset=utf-8'); ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex">
<title>站点维护中 · <?php echo e(setting('site_name', 'Moe Home')); ?></title>
<style>
  :root{--ink:#eaf6ff;--muted:#8fa8c8;--violet:#2dd4bf;--cyan:#60c8f8;--pink:#f4a6ff}
  *{box-sizing:border-box}
  body{
    margin:0; min-height:100vh; display:flex; align-items:center; justify-content:center;
    padding:24px; text-align:center; overflow:hidden;
    background:#060a10; color:var(--ink);
    font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
  }
  .scene{position:fixed;inset:0;filter:blur(72px);opacity:.85;pointer-events:none;overflow:hidden}
  .blob{position:absolute;border-radius:50%;mix-blend-mode:screen}
  .b1{width:60vmax;height:60vmax;top:-20vmax;left:-16vmax;background:radial-gradient(circle,var(--violet) 0%,transparent 62%);animation:d1 26s ease-in-out infinite}
  .b2{width:52vmax;height:52vmax;bottom:-20vmax;right:-14vmax;background:radial-gradient(circle,var(--cyan) 0%,transparent 62%);animation:d2 32s ease-in-out infinite}
  .b3{width:38vmax;height:38vmax;top:34%;left:54%;background:radial-gradient(circle,var(--pink) 0%,transparent 62%);animation:d3 24s ease-in-out infinite}
  @keyframes d1{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(5vmax,4vmax) scale(1.1)}}
  @keyframes d2{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(-5vmax,-3vmax) scale(1.08)}}
  @keyframes d3{0%,100%{transform:translate(0,0) scale(1)}50%{transform:translate(-6vmax,5vmax) scale(1.14)}}

  .box{
    position:relative; z-index:2; max-width:440px; padding:44px 32px;
    border-radius:28px; text-align:center;
    background:rgba(6,10,16,.20);
    border:1px solid rgba(255,255,255,.16);
    -webkit-backdrop-filter:blur(26px) saturate(150%); backdrop-filter:blur(26px) saturate(150%);
    box-shadow:0 40px 90px -28px rgba(0,0,0,.75);
  }
  .ring{
    width:96px;height:96px;margin:0 auto 22px;border-radius:50%;
    display:grid;place-items:center;font-size:38px;
    background:
      radial-gradient(circle at 30% 25%,rgba(45,212,191,.55),transparent 55%),
      radial-gradient(circle at 75% 80%,rgba(96,200,248,.4),transparent 55%),
      linear-gradient(135deg,#23203f,#0f1022);
    border:1px solid rgba(255,255,255,.2);
    animation:float 3s ease-in-out infinite;
  }
  @keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
  h1{
    margin:0 0 10px; font-size:21px; letter-spacing:.1em;
    font-family:"Songti SC","Noto Serif SC",Georgia,serif; font-weight:600;
    background:linear-gradient(118deg,#fff,#d3c9ff 45%,#8fd8ff 80%);
    -webkit-background-clip:text; background-clip:text; color:transparent;
  }
  p{margin:0;color:var(--muted);font-size:13.5px;line-height:1.9}
  .dot{display:inline-block;width:6px;height:6px;border-radius:50%;background:var(--violet);
       box-shadow:0 0 9px var(--violet);margin-right:7px;vertical-align:middle}
</style>
</head>
<body>
  <div class="scene" aria-hidden="true">
    <div class="blob b1"></div><div class="blob b2"></div><div class="blob b3"></div>
  </div>
  <div class="box">
    <div class="ring">🛠️</div>
    <h1>小站正在维护中</h1>
    <p><span class="dot"></span><?php echo e(setting('site_name', 'Moe Home')); ?> 稍后就回来，马上就好啦～</p>
  </div>
</body>
</html>
