<?php
/**
 * moezzz 模板 · 公共头部
 * 可用变量：$site $nav_cats；可选：$cur_p、$card_class、$kw
 *
 * 结构：极光背景层 → .stage > .card（顶部导航 + 各页内容）
 * 卡片由 footer.php 闭合。
 */
$cur = isset($cur_p) ? $cur_p : 'index';
$card_class = isset($card_class) ? $card_class : '';
$pretty = is_pretty_url();
$favicon = !empty($site['avatar']) ? media_url($site['avatar']) : theme_url('assets/favicon.svg');
$moe_ver = defined('MOE_VERSION') ? MOE_VERSION : '1.1.0';
/* 样式表带上文件修改时间，改过 CSS 立刻失效旧缓存，不用手动清理 */
$moe_css_v = $moe_ver . '.' . (int)@filemtime(__DIR__ . '/assets/style.css');

/* ---------- 模板设置（后台「模板管理 → 模板设置」） ---------- */
$opt_accent = theme_opt('accent', '#cbbfff');
if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $opt_accent)) $opt_accent = '#cbbfff';
$opt_aurora = theme_opt('aurora', '1') === '1';
$opt_width  = (int)theme_opt('card_width', '860');
if (!in_array($opt_width, array(860, 980, 1100), true)) $opt_width = 860;
$opt_note   = theme_opt('post_note', '');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php echo seo_head(); ?>
<meta name="theme-color" content="#060a10">
<link rel="icon" href="<?php echo e($favicon); ?>">
<link rel="alternate" type="application/rss+xml" title="<?php echo e($site['name']); ?>" href="<?php echo e(rss_url()); ?>">
<link rel="stylesheet" href="<?php echo e(theme_url('assets/style.css')); ?>?v=<?php echo e($moe_css_v); ?>">
<style>
:root{--accent:<?php echo e($opt_accent); ?>;}
<?php if ($opt_width !== 860): ?>.card--wide{width:min(100%,<?php echo $opt_width; ?>px);}
<?php endif; ?>
</style>
</head>
<body<?php echo $opt_aurora ? '' : ' class="no-aurora"'; ?>>

<!-- 背景：极光光斑（图片缺失/离线时的兜底层） -->
<div class="scene" aria-hidden="true">
  <div class="blob b1"></div>
  <div class="blob b2"></div>
  <div class="blob b3"></div>
  <div class="blob b4"></div>
</div>
<div class="grid-overlay" aria-hidden="true"></div>
<div class="noise" aria-hidden="true"></div>
<div class="glow-wrap" aria-hidden="true"><div class="glow" id="glow"></div></div>

<div class="stage">
  <main class="card <?php echo $card_class; ?>">

    <div class="card-top">
      <nav class="card-nav" aria-label="站内导航">
        <!-- 分类多时只让这层滚动，搜索按钮固定在外侧，不会被挤出可视区 -->
        <div class="nav-scroll">
          <a class="nav-btn <?php echo $cur === 'index' ? 'cur' : ''; ?>" href="<?php echo e(home_url()); ?>">首页</a>
          <?php foreach ($nav_cats as $c): ?>
            <a class="nav-btn <?php echo (isset($cat) && $cat['id'] == $c['id']) ? 'cur' : ''; ?>"
               href="<?php echo e(cat_url($c)); ?>"><?php echo e($c['name']); ?></a>
          <?php endforeach; ?>
        </div>
        <button type="button" class="nav-btn nav-ico" id="navSearch" title="搜索" aria-label="搜索">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true">
            <circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/>
          </svg>
        </button>
      </nav>
      <div class="card-user">
        <a class="nav-btn nav-me" href="<?php echo e(base_url() . 'admin/'); ?>" title="进入后台">后台</a>
      </div>
    </div>

    <form class="search-bar" id="searchBar" method="get"
          action="<?php echo e(base_url() . 'index.php'); ?>"
          data-pretty="<?php echo $pretty ? '1' : '0'; ?>"
          data-base="<?php echo e(base_url()); ?>" hidden>
      <input type="hidden" name="p" value="search">
      <input type="search" name="q" id="searchInput" placeholder="搜索文章、想法或随手记…"
             value="<?php echo isset($kw) ? e($kw) : ''; ?>" autocomplete="off">
      <button type="submit" class="search-go" aria-label="开始搜索">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true">
          <path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>
        </svg>
      </button>
    </form>
