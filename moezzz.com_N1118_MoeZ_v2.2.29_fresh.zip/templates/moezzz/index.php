<?php
/**
 * moezzz 模板 · 首页（名片 + 文章浮层）
 * 可用变量：$posts $pager $page $total $site $nav_cats
 */
$page_title = $site['name'];
$cur_p = 'index';
$card_class = 'card--index';
include partial_path('header.php');

$ava = !empty($site['avatar']) ? media_url($site['avatar']) : '';
$site_sign = isset($site['signature']) ? (string)$site['signature'] : '';
$site_desc = isset($site['desc']) ? (string)$site['desc'] : '';
$bio = $site_sign !== '' ? $site_sign : ($site_desc !== '' ? $site_desc : '这里是我的小角落，记录想法与日常。');
$stats = (isset($site['stats']) && is_array($site['stats'])) ? $site['stats'] : array();
?>

      <!-- 头像：光环 / 双环 / 轨道光点 -->
      <div class="avatar" title="点我试试">
        <span class="abg"></span>
        <span class="halo"></span>
        <span class="ring"></span>
        <span class="ring rev"></span>
        <span class="orbit"><i></i><i></i><i></i></span>
        <div class="face">
          <span class="init"><?php echo e(initial($site['name'])); ?></span>
          <?php if ($ava): ?>
            <img class="qq show" src="<?php echo e($ava); ?>" alt="<?php echo e($site['name']); ?>" referrerpolicy="no-referrer" decoding="async">
          <?php endif; ?>
          <span class="hi"></span>
          <span class="scan"></span>
        </div>
      </div>

      <h1 class="name"><?php echo e($site['name']); ?></h1>
      <p class="role"><span id="typed"></span><span class="caret" aria-hidden="true"></span></p>
      <p class="bio"><?php echo e($bio); ?></p>

      <div class="chips">
        <?php foreach ($nav_cats as $i => $c): ?>
          <a class="chip" href="<?php echo e(cat_url($c)); ?>">
            <span class="dot <?php echo array('', 'pink', 'lime')[$i % 3]; ?>"></span><?php echo e($c['name']); ?>
          </a>
        <?php endforeach; ?>
        <?php if (empty($nav_cats)): ?>
          <span class="chip"><span class="dot"></span><?php echo isset($stats['posts']) ? (int)$stats['posts'] : 0; ?> 篇文章</span>
          <span class="chip"><span class="dot pink"></span><?php echo isset($stats['comments']) ? (int)$stats['comments'] : 0; ?> 条留言</span>
          <span class="chip"><span class="dot lime"></span><?php echo isset($stats['views']) ? (int)$stats['views'] : 0; ?> 次浏览</span>
        <?php endif; ?>
      </div>

      <nav class="socials" aria-label="联系方式">
        <?php foreach ($site['socials'] as $soc): ?>
        <?php $socImg = function_exists('social_icon_url') ? social_icon_url($soc['icon']) : ''; ?>
        <a style="--c:#e6edf5" href="<?php echo e($soc['url']); ?>" target="_blank" rel="noopener nofollow" aria-label="<?php echo e($soc['name']); ?>" title="<?php echo e($soc['name']); ?>">
          <?php if ($socImg !== ''): ?>
            <img decoding="async" src="<?php echo e($socImg); ?>" alt="<?php echo e($soc['name']); ?>" style="width:20px;height:20px;object-fit:contain">
          <?php else: ?>
            <span style="font-size:20px;line-height:1"><?php echo e($soc['icon'] !== '' ? $soc['icon'] : '🔗'); ?></span>
          <?php endif; ?>
        </a>
        <?php endforeach; ?>
        <?php if (!empty($site['rss'])): ?>
        <a style="--c:#ffd28a" href="<?php echo e(rss_url()); ?>" aria-label="RSS" title="RSS 订阅">
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="6.2" cy="17.8" r="2.3"/><path d="M3.9 10.1v3c4 0 7.2 3.2 7.2 7.1h3c0-5.6-4.5-10.1-10.2-10.1zM3.9 3.9v3c7.4 0 13.3 6 13.3 13.3h3c0-9-7.3-16.3-16.3-16.3z"/></svg>
        </a>
        <?php endif; ?>
      </nav>

      <button type="button" class="cta" id="openGallery" aria-controls="gallery">
        浏览文章
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></svg>
      </button>

      <!-- ============ 文章浮层 ============ -->
      <div class="gallery" id="gallery" aria-hidden="true" role="dialog" aria-label="文章列表">
        <div class="gallery-panel">
          <div class="gallery-head" id="galleryHead">
            <div>
              <h2 class="works-title">文 章</h2>
              <p class="works-sub">Latest Posts · 共 <?php echo (int)$total; ?> 篇</p>
            </div>
            <button type="button" class="gallery-close" id="closeGallery" aria-label="关闭">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>
            </button>
          </div>

          <?php if (empty($posts)): ?>
            <div class="empty-box">
              <span class="big">🌱</span>
              <p>还没有文章哦，登录后台写下第一篇吧～</p>
              <a class="cta" href="<?php echo e(base_url() . 'admin/'); ?>">前往后台</a>
            </div>
          <?php else: ?>
            <div class="posts-grid">
              <?php foreach ($posts as $p): ?>
                <article class="post <?php echo post_cover($p) ? 'has-cover' : ''; ?>">
                  <?php if (post_cover($p)): ?>
                    <a class="post-cover" href="<?php echo e(post_url($p)); ?>">
                      <img src="<?php echo e(media_url(post_cover($p))); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy" decoding="async">
                    </a>
                  <?php endif; ?>
                  <h3 class="post-title">
                    <a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a>
                  </h3>
                  <p class="post-excerpt"><?php echo e(post_excerpt($p)); ?></p>
                  <div class="post-meta">
                    <?php if (!empty($p['cat_name'])): ?><span class="tag"><?php echo e($p['cat_name']); ?></span><?php endif; ?>
                    <?php if (!empty($p['is_top'])): ?><span class="tag" style="color:#ffd28a">置顶</span><?php endif; ?>
                    <span class="pm-d"><?php echo e(format_time($p['created_at'], 'Y-m-d')); ?></span>
                    <span class="pm-v"><?php echo isset($p['views']) ? (int)$p['views'] : 0; ?> 阅</span>
                  </div>
                </article>
              <?php endforeach; ?>
            </div>
            <?php echo $pager; ?>
          <?php endif; ?>
        </div>
      </div>

<?php include partial_path('footer.php'); ?>

<script>
(function () {
  /* ---- 打字机：站点签名 ---- */
  var text = <?php echo json_encode($site_sign !== '' ? $site_sign : (isset($site['sub']) && $site['sub'] !== '' ? $site['sub'] : '保持热爱，奔赴山海'), JSON_UNESCAPED_UNICODE); ?>;
  var el = document.getElementById('typed'), i = 0, adding = true;
  if (el) {
    (function tick() {
      if (adding) {
        i++;
        el.textContent = text.slice(0, i);
        if (i >= text.length) { adding = false; return setTimeout(tick, 2400); }
        return setTimeout(tick, 130);
      }
      i--;
      el.textContent = text.slice(0, i);
      if (i <= 0) { adding = true; return setTimeout(tick, 420); }
      setTimeout(tick, 38);
    })();
  }

  /* ---- 文章浮层开合 ---- */
  var gal = document.getElementById('gallery');
  var openBtn = document.getElementById('openGallery');
  var closeBtn = document.getElementById('closeGallery');
  var head = document.getElementById('galleryHead');

  /* .card 带 backdrop-filter 与 3D 变换，会成为 fixed 元素的包含块，
     把浮层移到 body 下才能铺满整个视口 */
  if (gal && gal.parentNode !== document.body) document.body.appendChild(gal);

  function openGallery() {
    if (!gal) return;
    gal.classList.add('open');
    gal.setAttribute('aria-hidden', 'false');
    document.documentElement.classList.add('modal-open');
    history.replaceState(null, '', '#posts');
  }
  function closeGallery() {
    if (!gal) return;
    gal.classList.remove('open');
    gal.setAttribute('aria-hidden', 'true');
    document.documentElement.classList.remove('modal-open');
    history.replaceState(null, '', location.pathname + location.search);
  }
  if (openBtn) openBtn.addEventListener('click', openGallery);
  if (closeBtn) closeBtn.addEventListener('click', closeGallery);
  if (gal) {
    gal.addEventListener('click', function (e) { if (e.target === gal) closeGallery(); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && gal.classList.contains('open')) closeGallery();
    });
    /* 第二页起 / 带 #posts 直达时自动展开 */
    var fromPage = <?php echo (int)$page; ?> > 1;
    if (location.hash === '#posts' || fromPage) openGallery();

    /* 标题吸顶阴影 */
    gal.addEventListener('scroll', function () {
      if (gal.scrollTop > 24) head.classList.add('scrolled'); else head.classList.remove('scrolled');
    }, { passive: true });
  }
})();
</script>
