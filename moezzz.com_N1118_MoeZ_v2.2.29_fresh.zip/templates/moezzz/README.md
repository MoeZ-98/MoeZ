# moezzz · 目录与路径依赖

> 本主题在 **2.2.30 工程化改造**里随站点目录整理做了统一路径适配。
> **外观、布局、配色、页面结构与业务功能一律未改**，只把「写死目录」的写法收敛到统一适配层。

## 依赖的站点路径

| 路径 | 用途 | 状态 |
|---|---|---|
| `templates/moezzz/assets/` | 主题自带样式 / 脚本 / 字体 / 图标 | 原位保留，一律经 `theme_url()` 引用 |
| `favicon.ico`（站点根） | 图标最终兜底 | 原位保留 |
| `uploads/{image,video,audio,file}/YYYYMM/` | 正文图、封面、后台自定义图片 | 由 `includes/upload.php` 写入，经 `media_url()` 引用；文件名不再带时间戳，规则见 `docs/附件命名说明.md` |
| `includes/theme-assets.php` | 主题资源路径适配层 | 新增，由 `init.php` 自动加载 |

## 已归档、不要再引用的旧路径

- `favicon.png`、`docs.html` → `content/archive/legacy-assets/`；
- `tests/` 自测脚本与截图 → `content/archive/dev-tests/`；
- `templates/*.zip` 历史主题安装包 → `content/archive/theme-packages/`；
- `docs/` 下乱码命名的 md → 已合并为 `docs/更新说明-2.0.3-*.md` / `docs/更新说明-2.0.4-*.md`。

> 归档区不参与运行、不进在线更新包、Web 不可访问，**不要**把主题里的路径指过去。
> 全站目录职责见 `docs/目录导航.md`。

## 本主题本次的适配点

- 图标变量 `$favicon` 改走 `moe_theme_icon()`，保留「站点头像 → 主题 favicon.svg」优先级；
- 补齐 `apple-touch-icon`。

## 以后目录再变，改哪里

1. 站内资源一律用 `theme_url()` / `media_url()`，不要在模板里写 `templates/xxx/`、`/uploads/xxx` 之类的绝对路径；
2. 图标统一走 `moe_theme_icon()` + `moe_icon_links()`；跨主题资源走 `moe_theme_asset()`；
   附件地址判断走 `moe_is_media_path()`；
3. 需要调整目录时，只改 `includes/theme-assets.php`（必要时同步 `includes/upload.php` 与部署配置），
   **7 套主题不用逐个翻代码**；
4. 主题侧所有适配调用都带 `function_exists()` 保护：万一在线更新只覆盖了半个包，
   会自动退回原来的写法，不会白屏。

## 🎙 版娘与语音（独立插件）

本主题的看板娘由 `content/plugins/moez-companion/` 插件提供，不再依赖任何单套主题的
CSS / JS。插件**首次部署自动启用**，通过 `front_head` / `front_footer` 钩子注入，
7 套主题通用；停用插件本主题的其它外观不受影响。

- 配置入口：后台 →「模板管理 → 模板设置 → 版娘与语音」，本主题 `info.php` 已声明该分组；
- 站点级默认：后台 →「站点设置 → 🎙 语音调试」，保存的值优先级高于主题设置；
- 男声 / 女声切换与调试：聊天窗头部 `♀ / ♂` 按钮、底部「🎙 语音调试」浮层，
  也可在 URL 加 `?voice_debug=1` 直接展开调试台；
- fomalhaut 主题另保留一份自带挂载块作为兼容回退，插件启用时自动让出，不会同页出现两套。

