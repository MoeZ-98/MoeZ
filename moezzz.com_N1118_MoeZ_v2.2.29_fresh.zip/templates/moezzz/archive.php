<?php
/**
 * moezzz 模板 · 归档时间线（/archives）
 * 可用变量：$groups（年份 => 文章行数组，行含 id,title,slug,type,category_id,url_num,content,created_at）、$total
 * 页面结构：$cur_p → header.php（打开 .stage > .card）→ 内容 → footer.php（闭合）
 */
$page_title = '归档';
$cur_p = 'archive';
$card_class = 'card--wide';
include partial_path('header.php');

$years      = array_keys((array)$groups);
$year_count = count($years);
?>

      <header class="article-head">
        <h1>归档 · Archive</h1>
        <div class="article-meta">
          <span>共 <b><?php echo (int)$total; ?></b> 篇</span>
          <span><?php echo (int)$year_count; ?> 个年份</span>
          <span><a href="<?php echo e(base_url() . 'blog/article'); ?>" style="color:inherit;border-bottom:1px solid rgba(255,255,255,.25);text-decoration:none">写作列表 →</a></span>
        </div>
      </header>

      <?php if (empty($years)): ?>
        <div class="empty-box">
          <span class="big">🗂</span>
          <p>还没有可以归档的文章，先去后台写一篇吧～</p>
          <a class="cta" href="<?php echo e(home_url()); ?>">回到首页</a>
        </div>
      <?php else: ?>
        <div class="chips zz-arc-tabs">
          <button type="button" class="chip zz-arc-tab is-on" data-year="all"><span class="dot"></span>全部</button>
          <?php foreach ($years as $y): ?>
            <button type="button" class="chip zz-arc-tab" data-year="<?php echo e($y); ?>">
              <span class="dot lime"></span><?php echo e($y); ?>
            </button>
          <?php endforeach; ?>
        </div>

        <?php foreach ($groups as $y => $items): ?>
          <?php $items = (array)$items; ?>
          <section class="zz-arc-group" data-year="<?php echo e($y); ?>">
            <h2 class="zz-arc-year">
              <span class="zz-arc-y"><?php echo e($y); ?></span>
              <span class="zz-arc-c"><?php echo count($items); ?> 篇</span>
              <span class="zz-arc-line" aria-hidden="true"></span>
            </h2>
            <div class="zz-arc-list">
              <?php foreach ($items as $p): ?>
                <a class="zz-arc-item" href="<?php echo e(post_url($p)); ?>">
                  <span class="zz-arc-date"><?php echo isset($p['created_at']) ? e(format_time($p['created_at'], 'm-d')) : ''; ?></span>
                  <span class="zz-arc-title"><?php echo e(isset($p['title']) ? $p['title'] : ''); ?></span>
                  <span class="zz-arc-read">约 <?php echo e(reading_time($p)); ?> 分钟</span>
                </a>
              <?php endforeach; ?>
            </div>
          </section>
        <?php endforeach; ?>
      <?php endif; ?>

      <script>
      (function () {
        var tabs = document.querySelectorAll('.zz-arc-tab');
        var boxes = document.querySelectorAll('.zz-arc-group');
        if (!tabs.length) return;
        tabs.forEach(function (t) {
          t.addEventListener('click', function () {
            var y = t.getAttribute('data-year');
            tabs.forEach(function (x) { x.classList.remove('is-on'); });
            t.classList.add('is-on');
            boxes.forEach(function (g) {
              g.style.display = (y === 'all' || g.getAttribute('data-year') === y) ? '' : 'none';
            });
          });
        });
      })();
      </script>

<?php include partial_path('footer.php'); ?>
