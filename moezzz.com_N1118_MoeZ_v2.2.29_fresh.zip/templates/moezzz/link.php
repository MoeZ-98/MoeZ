<?php
/**
 * moezzz 模板 · 友情链接（/link）
 * 可用变量：$links（links 表行：id,name,url,logo,description,contact,status,sort,created_at）$site $nav_cats
 * 说明：本页自带友链展示与申请入口，故设 $hide_links = true 隐藏 footer 里的通用友链块，避免重复；
 *       申请表单沿用 .fl-form / #flForm / #flMsg / #flApplyBtn，直接复用 footer.php 的提交交互脚本。
 */
$page_title = '友情链接';
$cur_p = 'link';
$card_class = 'card--wide';
$hide_links = true;
include partial_path('header.php');

$ava = !empty($site['avatar']) ? media_url($site['avatar']) : '';
?>

      <header class="article-head">
        <h1>友情链接 · Friends</h1>
        <div class="article-meta">
          <span>共 <b><?php echo count((array)$links); ?></b> 位朋友</span>
          <span>互相点亮，一起发光</span>
        </div>
      </header>

      <section class="zz-link-me">
        <?php if ($ava): ?>
          <img decoding="async" class="zz-link-me-ava" src="<?php echo e($ava); ?>" alt="<?php echo e($site['name']); ?>" referrerpolicy="no-referrer">
        <?php else: ?>
          <span class="zz-link-me-ava"><?php echo e(initial($site['name'])); ?></span>
        <?php endif; ?>
        <div class="zz-link-me-body">
          <b><?php echo e($site['name']); ?></b>
          <?php if (!empty($site['sub'])): ?><span><?php echo e($site['sub']); ?></span><?php endif; ?>
          <code><?php echo e(base_url()); ?></code>
        </div>
      </section>

      <?php if (empty($links)): ?>
        <div class="empty-box">
          <span class="big">🤝</span>
          <p>还没有友链，来交个朋友吧～</p>
        </div>
      <?php else: ?>
        <div class="fl-grid">
          <?php foreach ($links as $l): ?>
            <?php
              $lname = isset($l['name']) ? (string)$l['name'] : '';
              $lurl  = isset($l['url']) ? (string)$l['url'] : '';
              $ico   = function_exists('link_icon') ? link_icon($l) : '';
              $ld    = function_exists('link_desc') ? link_desc($l) : '';
              $sub   = $ld !== '' ? $ld : (parse_url($lurl, PHP_URL_HOST) ?: $lurl);
            ?>
            <a class="fl-card" href="<?php echo e($lurl); ?>" target="_blank" rel="noopener nofollow" title="<?php echo e($lname); ?>">
              <span class="fl-ico" style="overflow:hidden">
                <?php if ($ico !== ''): ?>
                  <img decoding="async" src="<?php echo e($ico); ?>" alt="<?php echo e(initial($lname)); ?>" loading="lazy"
                       style="width:100%;height:100%;object-fit:cover;display:block"
                       onerror="this.parentNode.textContent=this.alt">
                <?php else: ?>
                  <?php echo e(initial($lname)); ?>
                <?php endif; ?>
              </span>
              <span class="fl-name">
                <?php echo e($lname); ?>
                <small><?php echo e($sub); ?></small>
              </span>
            </a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>

      <section class="zz-link-apply">
        <div class="fl-head">
          <h3 class="fl-title">申请友链</h3>
          <button type="button" class="fl-apply" id="flApplyBtn">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
            填写申请
          </button>
        </div>
<p class="fl-empty">点击「填写申请」可查看本站信息并提交：请先在贵站添加本站链接，提交后会自动检测，已添加自动通过展示，未添加则转人工审核。</p>

        <?php include partial_path('link-apply.php'); ?>
      </section>

<?php include partial_path('footer.php'); ?>
