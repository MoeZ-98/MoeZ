<?php
/**
 * moezzz 模板 · 文章详情
 * 可用变量：$post $cat $prev $next $comments $site $nav_cats
 */
$page_title = $post['title'];
$cur_p = 'post';
$card_class = 'card--wide';
include partial_path('header.php');
?>

      <article>
        <header class="article-head">
          <?php if ($cat): ?>
            <a class="cat" href="<?php echo e(cat_url($cat)); ?>"><?php echo e($cat['name']); ?></a>
          <?php endif; ?>
          <h1><?php echo e($post['title']); ?></h1>
          <div class="article-meta">
            <span><?php echo e(format_time($post['created_at'], 'Y-m-d')); ?></span>
            <?php if (!empty($post['updated_at']) && substr($post['updated_at'], 0, 10) !== substr($post['created_at'], 0, 10)): ?>
              <span>更新于 <?php echo e(format_time($post['updated_at'], 'Y-m-d')); ?></span>
            <?php endif; ?>
            <span><?php echo isset($post['views']) ? (int)$post['views'] : 0; ?> 次阅读</span>
            <span>约 <?php echo reading_time($post); ?> 分钟</span>
            <?php if (!empty($site['author'])): ?><span><?php echo e($site['author']); ?></span><?php endif; ?>
          </div>
        </header>

        <?php if (!empty($opt_note)): ?><p class="article-note"><?php echo e($opt_note); ?></p><?php endif; ?>

        <?php
        /* 正文大图默认同步解码，会拖慢首屏；统一补上异步解码属性 */
        $moe_body = render_content(isset($post['content']) ? $post['content'] : '', isset($post['content_format']) ? $post['content_format'] : 'html');
        $moe_body = preg_replace('/<img(?![^>]*\bdecoding\s*=)/i', '<img decoding="async"', $moe_body);
        ?>
        <div class="md-body">
          <?php echo $moe_body; ?>
        </div>

        <?php echo function_exists('post_tags_html') ? post_tags_html($post) : ''; ?>

        <?php if ($post['slug']): ?>
        <div class="article-link">
          <span>本文链接</span>
          <code><?php echo e(post_url($post)); ?></code>
        </div>
        <?php endif; ?>
      </article>

      <?php if ($prev || $next): ?>
      <nav class="post-nav">
        <?php if ($prev): ?>
          <a href="<?php echo e(post_url($prev)); ?>">
            <span class="lab">← 上一篇</span><?php echo e($prev['title']); ?>
          </a>
        <?php else: ?><span></span><?php endif; ?>
        <?php if ($next): ?>
          <a class="next" href="<?php echo e(post_url($next)); ?>">
            <span class="lab">下一篇 →</span><?php echo e($next['title']); ?>
          </a>
        <?php endif; ?>
      </nav>
      <?php endif; ?>

      <section class="comments">
        <?php $comments = isset($comments) ? (array)$comments : array(); ?>
        <h2>评论 · <?php echo count($comments); ?></h2>

        <?php if (!empty($comments)): ?>
          <div class="comment-list">
            <?php foreach ($comments as $c): ?>
              <div class="comment-item">
                <div class="face"><?php echo e(initial($c['author'])); ?></div>
                <div class="c-body">
                  <div class="c-head">
                    <b><?php echo e($c['author']); ?></b>
                    <time><?php echo e(nice_time($c['created_at'])); ?></time>
                    <?php
                    $cloc = function_exists('moe_comment_loc') ? moe_comment_loc($c) : (isset($c['location']) ? trim($c['location']) : '');
                    $cua  = function_exists('moe_ua_info') && isset($c['ua']) ? moe_ua_info($c['ua']) : '';
                    ?>
                    <?php if ($cloc !== ''): ?><span class="c-badge"><?php echo e($cloc); ?></span><?php endif; ?>
                    <?php if ($cua !== ''): ?><span class="c-badge c-badge-soft"><?php echo e($cua); ?></span><?php endif; ?>
                  </div>
                  <div class="c-text"><?php echo nl2br(e($c['content'])); ?></div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <?php if (setting('comment_enabled', '1') === '1'): ?>
          <form class="comment-form" id="cform" method="post" action="<?php echo e(base_url() . 'comment.php'); ?>">
            <input type="hidden" name="post_id" value="<?php echo (int)$post['id']; ?>">
            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
            <h3>说点什么</h3>
            <?php $__cdf = function_exists('moe_comment_defaults') ? moe_comment_defaults() : array('author' => '', 'email' => '', 'admin' => false); ?>
            <div class="row">
              <input type="text" name="author" placeholder="昵称 *" maxlength="30" required value="<?php echo e($__cdf['author']); ?>">
              <input type="email" name="email" placeholder="邮箱（选填，不会公开）" value="<?php echo e($__cdf['email']); ?>">
            </div>
            <?php if (!empty($__cdf['admin'])): ?><p class="hint" style="font-size:12px;color:#9a8fae;margin:-4px 0 8px">👋 站长已登录，已自动填入你的信息</p><?php endif; ?>
            <textarea name="content" placeholder="想说的话都可以写在这里…" maxlength="1000" required></textarea>
            <div style="margin-top:14px;text-align:right">
              <button class="cta" type="submit" id="csubmit">
                发送评论
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m22 2-7 20-4-9-9-4Z"/><path d="M22 2 11 13"/></svg>
              </button>
            </div>
            <p id="cmsg" style="font-size:12.5px;margin:10px 0 0;display:none"></p>
          </form>
          <script>
          document.getElementById('cform').addEventListener('submit', function (e) {
            e.preventDefault();
            var btn = document.getElementById('csubmit'), msg = document.getElementById('cmsg');
            btn.disabled = true; btn.style.opacity = '.6';
            fetch(this.action, { method: 'POST', body: new FormData(this) })
              .then(function (r) { return r.json(); })
              .then(function (d) {
                msg.style.display = 'block';
                msg.style.color = d.ok ? '#7ef0a6' : '#f4a6ff';
                msg.textContent = d.msg;
                if (d.ok) { setTimeout(function () { location.reload(); }, 900); }
                else { btn.disabled = false; btn.style.opacity = '1'; }
              })
              .catch(function () {
                msg.style.display = 'block'; msg.style.color = '#f4a6ff';
                msg.textContent = '网络开小差了，请稍后重试';
                btn.disabled = false; btn.style.opacity = '1';
              });
          });
          </script>
        <?php else: ?>
          <div class="empty-box" style="padding:28px"><p style="margin:0">评论区暂时关闭啦～</p></div>
        <?php endif; ?>
      </section>

<?php include partial_path('footer.php'); ?>
