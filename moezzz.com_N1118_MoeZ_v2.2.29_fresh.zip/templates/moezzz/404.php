<?php
/** moezzz 模板 · 404 */
$page_title = '404 Not Found';
$cur_p = '404';
include partial_path('header.php');
?>

      <div class="empty-box" style="border-style:solid;border-color:rgba(255,255,255,.10);padding:56px 20px">
        <span class="big" style="font-size:52px">🎀</span>
        <div style="font-family:var(--font-serif);font-size:clamp(26px,7vw,40px);letter-spacing:.1em;
                    background:linear-gradient(118deg,#fff,#d3c9ff 45%,#8fd8ff 80%);
                    -webkit-background-clip:text;background-clip:text;color:transparent;margin-bottom:10px">
          404
        </div>
        <p>页面去二次元了 · 你要找的内容不存在，或已被删除</p>
        <a class="cta" href="<?php echo e(home_url()); ?>">
          回到首页
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"/><path d="m13 6 6 6-6 6"/></svg>
        </a>
      </div>

<?php include partial_path('footer.php'); ?>
