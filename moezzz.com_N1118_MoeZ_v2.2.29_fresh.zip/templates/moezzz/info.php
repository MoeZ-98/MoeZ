<?php
/** 模板信息 —— 后台「模板管理」读取 */
return array(
    'name'    => '萌站 Zz · 极光名片',
    'version' => '1.3.0',
    'author'  => 'Moe Home',
    'desc'    => '深色极光背景 · 玻璃拟态名片 · 头像光环动画 · 青紫渐变 · 全屏文章浮层',
    /* 模板设置：后台「模板管理 → 模板设置」可视化调整 */
    'settings' => array(
        array(
            'key'     => 'accent',
            'label'   => '主色调',
            'type'    => 'color',
            'default' => '#cbbfff',
            'hint'    => '按钮、链接高亮与头像光环的渐变主色，另一端固定为青色 #7cf0ff',
        ),
        array(
            'key'     => 'aurora',
            'label'   => '极光背景光斑',
            'type'    => 'bool',
            'default' => '1',
            'hint'    => '关闭后背景更纯净，低配设备性能更好',
        ),
        array(
            'key'     => 'show_friends',
            'label'   => '前台展示友情链接',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'card_width',
            'label'   => '文章页卡片宽度',
            'type'    => 'select',
            'default' => '860',
            'options' => array('860' => '标准 860px', '980' => '加宽 980px', '1100' => '超宽 1100px'),
        ),
        array(
            'key'     => 'post_note',
            'label'   => '文章页顶部小字',
            'type'    => 'text',
            'default' => '',
            'hint'    => '留空不显示，如：转载请注明出处',
        ),
    ),
);
