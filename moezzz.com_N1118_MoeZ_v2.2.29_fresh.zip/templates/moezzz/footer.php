<?php
/**
 * moezzz 模板 · 公共底部
 * 闭合 .card / .stage，输出友链、页脚与交互脚本
 */
try {
    $links = rows('SELECT * FROM ' . moe_table('links') . ' ORDER BY sort, id');
} catch (Throwable $e) {
    $links = array();
}
$links = array_values(array_filter((array)$links, function ($l) {
    return !isset($l['status']) || $l['status'] === 'approved';
}));
$show_fl = function_exists('theme_opt') && theme_opt('show_friends', '1') === '1';
?>

<?php if ($show_fl && !(isset($hide_links) && $hide_links)): ?>
<section class="fl" aria-label="友情链接">
  <div class="fl-head">
    <h3 class="fl-title">友情链接 · Friends</h3>
    <button type="button" class="fl-apply" id="flApplyBtn">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
        申请友链
      </button>
  </div>

  <?php if (!empty($links)): ?>
  <div class="fl-grid">
    <?php foreach ($links as $l): ?>
      <?php
        $ico = function_exists('link_icon') ? link_icon($l) : '';
        $ld  = function_exists('link_desc') ? link_desc($l) : '';
        $sub = $ld !== '' ? $ld : (parse_url($l['url'], PHP_URL_HOST) ?: $l['url']);
      ?>
      <a class="fl-card" href="<?php echo e($l['url']); ?>" target="_blank" rel="noopener nofollow" title="<?php echo e($l['name']); ?>">
        <span class="fl-ico" style="overflow:hidden">
          <?php if ($ico !== ''): ?>
            <img decoding="async" src="<?php echo e($ico); ?>" alt="<?php echo e(initial($l['name'])); ?>" loading="lazy"
                 style="width:100%;height:100%;object-fit:cover;display:block"
                 onerror="this.parentNode.textContent=this.alt">
          <?php else: ?>
            <?php echo e(initial($l['name'])); ?>
          <?php endif; ?>
        </span>
        <span class="fl-name">
          <?php echo e($l['name']); ?>
          <small style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo e($sub); ?></small>
        </span>
      </a>
    <?php endforeach; ?>
  </div>
  <?php else: ?>
  <p class="fl-empty">还没有友链，来交个朋友吧～</p>
  <?php endif; ?>

<!-- 申请友链：点击按钮弹出窗口，内含本站信息与申请表 -->
  <?php include partial_path('link-apply.php'); ?>
</section>
<?php endif; ?>

    <footer class="foot">
      <p class="cr"><?php echo !empty($site['footer']) ? e($site['footer']) : '© ' . date('Y') . ' · ' . e($site['name']); ?></p>
      <p class="beian">
        <?php if (!empty($site['rss'])): ?><a href="<?php echo e(rss_url()); ?>">RSS</a><?php endif; ?>
        <a href="<?php echo e(base_url() . 'sitemap.xml'); ?>">Sitemap</a>
        <span class="dot-sep">·</span>
        <span>Moe Home v<?php echo e(isset($moe_ver) ? $moe_ver : (defined('MOE_VERSION') ? MOE_VERSION : '1.1.0')); ?></span>
      </p>
    </footer>

  </main>
</div>

<button type="button" class="back-top" id="backTop" aria-label="返回顶部">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M12 19V5"/><path d="m5 12 7-7 7 7"/>
  </svg>
  顶部
</button>

<script>
(function () {
  /* ---- 光标光晕跟随 ---- */
  var glow = document.getElementById('glow');
  if (glow && window.matchMedia('(hover:hover)').matches) {
    var tx = 50, ty = 50, cx = 50, cy = 50, raf = 0;
    document.addEventListener('mousemove', function (e) {
      tx = (e.clientX / window.innerWidth) * 100;
      ty = (e.clientY / window.innerHeight) * 100;
      glow.style.opacity = '1';
      if (!raf) raf = requestAnimationFrame(loop);
    }, { passive: true });
    function loop() {
      cx += (tx - cx) * 0.12;
      cy += (ty - cy) * 0.12;
      glow.style.setProperty('--gx', cx + '%');
      glow.style.setProperty('--gy', cy + '%');
      if (Math.abs(tx - cx) > 0.2 || Math.abs(ty - cy) > 0.2) {
        raf = requestAnimationFrame(loop);
      } else { raf = 0; }
    }
  }

  /* ---- 返回顶部 ---- */
  var bt = document.getElementById('backTop');
  if (bt) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 320) bt.classList.add('show'); else bt.classList.remove('show');
    }, { passive: true });
    bt.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
  }

  /* ---- 搜索栏展开 / 收起 ---- */
  var navSearch = document.getElementById('navSearch');
  var bar = document.getElementById('searchBar');
  if (navSearch && bar) {
    navSearch.addEventListener('click', function () {
      var open = !bar.hasAttribute('hidden');
      if (open) { bar.setAttribute('hidden', ''); return; }
      bar.removeAttribute('hidden');
      var inp = document.getElementById('searchInput');
      if (inp) { setTimeout(function () { inp.focus(); }, 60); }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !bar.hasAttribute('hidden')) bar.setAttribute('hidden', '');
    });
  }

  /* ---- 伪静态搜索：/search/关键词 ---- */
  if (bar && bar.getAttribute('data-pretty') === '1') {
    bar.addEventListener('submit', function (ev) {
      var q = bar.querySelector('input[name=q]');
      if (!q || !q.value.trim()) { ev.preventDefault(); return; }
      ev.preventDefault();
      location.href = bar.getAttribute('data-base') + 'search/' + encodeURIComponent(q.value.trim());
    });
  }

  /* ---- 头像鼠标高光 ---- */
  document.querySelectorAll('.avatar').forEach(function (av) {
    av.addEventListener('mousemove', function (e) {
      var r = av.getBoundingClientRect();
      var hx = ((e.clientX - r.left) / r.width) * 100;
      var hy = ((e.clientY - r.top) / r.height) * 100;
      var hi = av.querySelector('.hi');
      if (hi) { hi.style.setProperty('--hx', hx + '%'); hi.style.setProperty('--hy', hy + '%'); }
    });
  });
  /* ---- 友链申请弹窗 ---- */
  var applyBtn = document.getElementById('flApplyBtn');
  var flForm = document.getElementById('flForm');
  var flMsg = document.getElementById('flMsg');
  var flModal = document.getElementById('flModal');
  if (applyBtn && flForm && flModal) {
    /* 卡片带 backdrop-filter，会成为 fixed 子元素的包含块；弹窗必须挂到 body 上才能真正铺满视口 */
    if (flModal.parentNode !== document.body) document.body.appendChild(flModal);
    var lastFocus = null;
    function openFlModal() {
      lastFocus = document.activeElement;
      flModal.hidden = false;
      document.documentElement.classList.add('modal-open');
      var first = flForm.querySelector('input[name=url]');
      if (first) first.focus();
    }
    function closeFlModal() {
      flModal.hidden = true;
      document.documentElement.classList.remove('modal-open');
      if (lastFocus && lastFocus.focus) lastFocus.focus();
    }
    applyBtn.addEventListener('click', openFlModal);
    var flClose = document.getElementById('flModalClose');
    if (flClose) flClose.addEventListener('click', closeFlModal);
    var flMask = flModal.querySelector('.fl-modal-mask');
    if (flMask) flMask.addEventListener('click', closeFlModal);
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !flModal.hidden) closeFlModal();
    });

    /* 本站信息一键复制 */
    function copyText(txt, done) {
      function legacy() {
        var ta = document.createElement('textarea');
        ta.value = txt; ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0';
        document.body.appendChild(ta); ta.select();
        try { document.execCommand('copy'); } catch (err) {}
        document.body.removeChild(ta); done();
      }
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(txt).then(done, legacy);
      } else { legacy(); }
    }
    flModal.querySelectorAll('.fl-copy').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var target = document.getElementById(btn.getAttribute('data-copy'));
        if (!target) return;
        copyText((target.textContent || '').trim(), function () {
          btn.textContent = '已复制';
          btn.classList.add('done');
          setTimeout(function () { btn.textContent = '复制'; btn.classList.remove('done'); }, 1600);
        });
      });
    });
    flForm.addEventListener('submit', function (ev) {
      ev.preventDefault();
      var btn = flForm.querySelector('.fl-form-btn');
      btn.disabled = true; btn.textContent = '检测中…（访问对方站点）';
      flMsg.textContent = ''; flMsg.className = 'fl-form-msg';
      fetch('<?php echo e(base_url() . 'link.php'); ?>', { method: 'POST', body: new FormData(flForm) })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          flMsg.textContent = d.msg;
          flMsg.className = 'fl-form-msg' + (d.ok ? ' ok' : ' bad');
          btn.disabled = false; btn.textContent = '提交申请';
          if (d.ok) setTimeout(function () { location.reload(); }, 1600);
        })
        .catch(function () {
          flMsg.textContent = '网络开小差了，请稍后重试';
          flMsg.className = 'fl-form-msg bad';
          btn.disabled = false; btn.textContent = '提交申请';
        });
    });
  }
})();
</script>
</body>
</html>
