<?php
/**
 * moezzz 模板 · 独立页面
 * 可用变量：$page $site $nav_cats
 */
$page_title = $page['title'];
$cur_p = 'page';
$card_class = 'card--wide';
$hide_links = false;
include partial_path('header.php');
?>

      <article>
        <header class="article-head">
          <h1><?php echo e($page['title']); ?></h1>
          <div class="article-meta">
            <span>更新于 <?php echo e(format_time($page['updated_at'], 'Y-m-d')); ?></span>
          </div>
        </header>

        <?php
        $moe_body = render_content(isset($page['content']) ? $page['content'] : '', isset($page['content_format']) ? $page['content_format'] : 'html');
        $moe_body = preg_replace('/<img(?![^>]*\bdecoding\s*=)/i', '<img decoding="async"', $moe_body);
        ?>
        <div class="md-body">
          <?php echo $moe_body; ?>
        </div>
      </article>

<?php include partial_path('footer.php'); ?>
