<?php
/**
 * 冰屿模板 · 用户登录 / 注册 / 个人中心
 * 可用变量：$act (login|register|profile) $me (当前用户|null) $err $okmsg；公共变量 $site
 */
$cur_p = 'user';
$hero_mode = 'none';
include partial_path('header.php');

$actTitle = $act === 'profile' ? '👤 个人中心' : ($act === 'register' ? '🎉 注册账号' : '🔐 登录');
?>

      <div class="user-page">
        <div class="u-card">
          <h2 class="u-title"><?php echo $actTitle; ?></h2>

          <?php if ($err): ?><p class="u-msg bad">⚠️ <?php echo e($err); ?></p><?php endif; ?>
          <?php if ($okmsg): ?><p class="u-msg good">✅ <?php echo e($okmsg); ?></p><?php endif; ?>

          <?php if ($act === 'login'): ?>
          <form method="post" action="<?php echo e(base_url() . 'user/login'); ?>" class="u-form">
            <?php echo csrf_field(); ?>
            <label>用户名</label>
            <input type="text" name="username" required autofocus placeholder="请输入用户名">
            <label>密码</label>
            <input type="password" name="password" required placeholder="请输入密码">
            <button class="u-btn" type="submit">登录 ✨</button>
          </form>
          <p class="u-tip">还没有账号？<a href="<?php echo e(base_url() . 'user/register'); ?>">去注册 →</a></p>

          <?php elseif ($act === 'register'): ?>
          <form method="post" action="<?php echo e(base_url() . 'user/register'); ?>" class="u-form">
            <?php echo csrf_field(); ?>
            <label>用户名 <i>（2-32 位字母 / 数字 / 下划线 / 中文）</i></label>
            <input type="text" name="username" required autofocus placeholder="给自己起个名字吧">
            <label>邮箱 <i>（选填，仅站长可见）</i></label>
            <input type="email" name="email" placeholder="you@example.com">
            <label>密码 <i>（至少 6 位）</i></label>
            <input type="password" name="password" required placeholder="设置密码">
            <label>确认密码</label>
            <input type="password" name="password2" required placeholder="再输一遍">
            <button class="u-btn" type="submit">注册并登录 🎉</button>
          </form>
          <p class="u-tip">已有账号？<a href="<?php echo e(base_url() . 'user/login'); ?>">去登录 →</a></p>

          <?php else: /* profile */ ?>
          <div class="u-me">
            <?php
            $meAva = !empty($me['avatar']) ? $me['avatar'] : ($site['avatar'] ? media_url($site['avatar']) : '');
            $meName = $me['nickname'] !== '' ? $me['nickname'] : $me['username'];
            $meRole = isset($me['role']) && $me['role'] === 'admin';
            if ($meAva): ?>
              <img src="<?php echo e($meAva); ?>" alt="" referrerpolicy="no-referrer">
            <?php else: ?>
              <span class="face"><?php echo e(initial($meName)); ?></span>
            <?php endif; ?>
            <div>
              <b><?php echo e($meName); ?></b>
              <span class="role"><?php echo $meRole ? '👑 站长' : '🙂 注册用户'; ?> · 加入于 <?php echo e(format_time($me['created_at'], 'Y-m-d')); ?></span>
            </div>
          </div>
          <form method="post" action="<?php echo e(base_url() . 'user/profile'); ?>" class="u-form">
            <?php echo csrf_field(); ?>
            <label>昵称</label>
            <input type="text" name="nickname" maxlength="32" value="<?php echo e($me['nickname']); ?>" placeholder="展示用的昵称">
            <label>邮箱 <i>（用于匹配你发出的评论）</i></label>
            <input type="email" name="email" value="<?php echo e($me['email']); ?>" placeholder="you@example.com">
            <label>头像图片地址 <i>（选填，https://…）</i></label>
            <input type="text" name="avatar" value="<?php echo e($me['avatar']); ?>" placeholder="https://example.com/avatar.png">
            <label>原密码 <i>（修改密码时填写）</i></label>
            <input type="password" name="oldpass" placeholder="不修改就留空">
            <label>新密码</label>
            <input type="password" name="newpass" placeholder="至少 6 位，不修改就留空">
            <button class="u-btn" type="submit">保存资料 💾</button>
          </form>
          <div class="u-acts">
            <?php if ($meRole): ?>
              <a href="<?php echo e(base_url() . 'admin/'); ?>">⚙️ 管理后台</a>
            <?php endif; ?>
            <a href="<?php echo e(base_url() . 'archives'); ?>">📚 文章归档</a>
            <a href="<?php echo e(base_url() . 'user/logout'); ?>">🚪 退出登录</a>
          </div>
          <?php endif; ?>
        </div>
      </div>

<?php include partial_path('footer.php'); ?>
