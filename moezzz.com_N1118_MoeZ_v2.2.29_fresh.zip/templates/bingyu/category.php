<?php
/**
 * 冰屿模板 · 分类列表
 * 可用变量：$cat $posts $pager $total $site $nav_cats
 */
$page_title = '分类：' . $cat['name'];
$cur_p = 'category';
$hero_mode = 'banner';
$hero_title = '🏷 ' . $cat['name'];
$hero_meta = array(
    array('ico' => '🗂', 'text' => '共 ' . (int)$total . ' 篇文章'),
);
if ($cat['description']) $hero_meta[] = array('ico' => '📝', 'text' => $cat['description']);
include partial_path('header.php');
?>

      <main class="by-main" style="width:100%">
        <?php if (empty($posts)): ?>
          <div class="empty-box">
            <span class="big">🍂</span>
            <p>这个分类下还没有文章～</p>
            <a class="btn-go" href="<?php echo e(home_url()); ?>">回到首页</a>
          </div>
        <?php else: ?>
          <div class="cards">
            <?php foreach ($posts as $p): ?>
            <article class="card-p">
              <?php if (post_cover($p)): ?>
                <a class="cover" href="<?php echo e(post_url($p)); ?>">
                  <img src="<?php echo e(media_url(post_cover($p))); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy" referrerpolicy="no-referrer">
                </a>
              <?php endif; ?>
              <div class="pad">
                <div class="byline">
                  <span class="dot-ava"><?php echo e(initial($site['author'] ?: $site['name'])); ?></span>
                  <span><?php echo e($site['author'] ?: $site['name']); ?></span>
                  <span>·</span>
                  <time><?php echo e(format_time($p['created_at'], 'Y-m-d H:i')); ?></time>
                  <?php if (!empty($p['is_top'])): ?><span style="color:var(--accent)">置顶</span><?php endif; ?>
                </div>
                <h3><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
                <p class="excerpt"><?php echo e(post_excerpt($p, 70)); ?></p>
                <div class="foot">
                  <span>👀 <?php echo (int)$p['views']; ?></span>
                  <?php $cN = function_exists('post_comment_count') ? (int)post_comment_count($p['id']) : 0; ?>
                  <span>💬 <?php echo $cN; ?></span>
                  <span class="sp"></span>
                  <a class="chip-tag" href="<?php echo e(cat_url($cat)); ?>"><?php echo e($cat['name']); ?></a>
                </div>
              </div>
            </article>
            <?php endforeach; ?>
          </div>
          <?php echo $pager; ?>
        <?php endif; ?>
      </main>

<?php include partial_path('footer.php'); ?>
