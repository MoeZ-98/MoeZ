<?php
/**
 * 冰屿模板 · 写作列表（/blog/article）
 * 可用变量：$posts $pager $total $page $cats $sel_cat $site $nav_cats
 */
$page_title = '写作';
$cur_p = 'article';
$hero_mode = 'banner';
$hero_title = '✍️ 全部写作';
$hero_meta = array(
    array('ico' => '🗂', 'text' => '共 ' . (int)$total . ' 篇文章'),
);
if ((int)$page > 1) $hero_meta[] = array('ico' => '📄', 'text' => '第 ' . (int)$page . ' 页');
include partial_path('header.php');
?>

      <main class="by-main" style="width:100%">
        <?php if (!empty($cats)): ?>
          <nav class="by-chips" aria-label="按分类筛选">
            <a class="by-chip<?php echo empty($sel_cat) ? ' cur' : ''; ?>"
               href="<?php echo e(base_url() . 'blog/article'); ?>">全部 <small><?php echo (int)$total; ?></small></a>
            <?php foreach ((array)$cats as $c): ?>
              <a class="by-chip<?php echo ((int)$sel_cat === (int)$c['id']) ? ' cur' : ''; ?>"
                 href="<?php echo e(base_url() . 'blog/article?cat=' . (int)$c['id']); ?>"><?php echo e($c['name']); ?><?php if (isset($c['count'])): ?> <small><?php echo (int)$c['count']; ?></small><?php endif; ?></a>
            <?php endforeach; ?>
          </nav>
        <?php endif; ?>

        <?php if (empty($posts)): ?>
          <div class="empty-box">
            <span class="big">🌱</span>
            <p>这里还没有文章哦，换个分类或去后台写下第一篇吧～</p>
            <a class="btn-go" href="<?php echo e(home_url()); ?>">回到首页</a>
          </div>
        <?php else: ?>
          <div class="cards">
            <?php foreach ($posts as $p): ?>
            <article class="card-p">
              <?php if (post_cover($p)): ?>
                <a class="cover" href="<?php echo e(post_url($p)); ?>">
                  <img src="<?php echo e(media_url(post_cover($p))); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy" referrerpolicy="no-referrer">
                </a>
              <?php endif; ?>
              <div class="pad">
                <div class="byline">
                  <span class="dot-ava"><?php echo e(initial($site['author'] ?: $site['name'])); ?></span>
                  <span><?php echo e($site['author'] ?: $site['name']); ?></span>
                  <span>·</span>
                  <time><?php echo e(format_time($p['created_at'], 'Y-m-d H:i')); ?></time>
                  <?php if (!empty($p['is_top'])): ?><span style="color:var(--accent)">置顶</span><?php endif; ?>
                </div>
                <h3><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
                <p class="excerpt"><?php echo e(post_excerpt($p, 70)); ?></p>
                <div class="foot">
                  <span>👀 <?php echo (int)$p['views']; ?></span>
                  <?php $cN = function_exists('post_comment_count') ? (int)post_comment_count($p['id']) : 0; ?>
                  <span>💬 <?php echo $cN; ?></span>
                  <span class="sp"></span>
                  <?php if (!empty($p['cat_name'])): ?>
                    <a class="chip-tag" href="<?php echo e(cat_url(array('id' => isset($p['category_id']) ? (int)$p['category_id'] : 0, 'slug' => isset($p['cat_slug']) ? $p['cat_slug'] : '', 'name' => $p['cat_name']))); ?>"><?php echo e($p['cat_name']); ?></a>
                  <?php endif; ?>
                </div>
              </div>
            </article>
            <?php endforeach; ?>
          </div>
          <?php echo $pager; ?>
        <?php endif; ?>
      </main>

<?php include partial_path('footer.php'); ?>