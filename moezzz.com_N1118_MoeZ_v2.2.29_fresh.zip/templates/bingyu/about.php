<?php
/**
 * 冰屿模板 · 关于页（/about）
 * 可用变量：$site $nav_cats；内容来自模板设置「关于页内容」
 */
$page_title = '关于本站';
$cur_p = 'about';
$hero_mode = 'banner';
$hero_title = '👤 关于本站';
$hero_meta = array(array('ico' => '🌸', 'text' => $site['name']));
include partial_path('header.php');

$about_md = trim(theme_opt('about_md', ''));
?>
      <article class="article-wrap">
        <?php if ($about_md !== ''): ?>
          <div class="md-body">
            <?php echo render_content($about_md, 'markdown'); ?>
          </div>
        <?php else: ?>
          <div class="md-body">
            <h2><?php echo e($site['name']); ?></h2>
            <p><?php echo e($site['desc'] !== '' ? $site['desc'] : ($site['signature'] !== '' ? $site['signature'] : '这里是我的小角落，记录想法与日常。')); ?></p>
            <ul>
              <li>📝 已发布 <b><?php echo (int)$site['stats']['posts']; ?></b> 篇文章</li>
              <li>💬 收到 <b><?php echo (int)$site['stats']['comments']; ?></b> 条评论</li>
              <li>👀 累计 <b><?php echo (int)$site['stats']['views']; ?></b> 次浏览</li>
            </ul>
            <blockquote>在后台「模板管理 → 模板设置 → 关于页内容」填写 Markdown，即可自定义本页。</blockquote>
          </div>
        <?php endif; ?>
        <div class="post-foot">
          <span>感谢每一位到访的小伙伴 ✨</span>
        </div>
      </article>

<?php include partial_path('footer.php'); ?>
