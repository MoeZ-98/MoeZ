<?php
/**
 * 冰屿模板 · 公共底部
 * 闭合 .by-wrap，输出海浪页脚、用户中心面板、悬浮球与交互脚本
 * 可用变量：$site $nav_cats $pretty；header.php 中已定义 $opt_sakura / $opt_fnote / $typed_text
 */

/* ---------- 推荐友链（用户中心面板无需，此处仅保留页脚统计） ---------- */
$s_stats = $site['stats'];
?>
</div><!-- /.by-wrap -->

<footer class="by-foot">
  <svg class="wave-top" viewBox="0 0 1440 60" preserveAspectRatio="none" aria-hidden="true">
    <path fill="#2d3f68" d="M0,30 C180,58 360,6 540,20 C720,34 900,56 1080,40 C1260,24 1380,36 1440,44 L1440,60 L0,60 Z"/>
    <path fill="#4f6ba6" opacity=".55" d="M0,44 C240,60 480,22 720,34 C960,46 1200,58 1440,38 L1440,60 L0,60 Z"/>
  </svg>
  <div class="stones" aria-hidden="true">
    <span>🐸</span><span>🐯</span><span>🐶</span><span>🐕</span><span>🐰</span>
    <span>🐼</span><span>🐨</span><span>🐮</span><span>🐱</span>
  </div>
  <?php if ($opt_fnote !== ''): ?><p class="note"><?php echo e($opt_fnote); ?></p><?php endif; ?>
  <p class="cr"><?php echo $site['footer'] ? e($site['footer']) : '© ' . date('Y') . ' ' . e($site['name']) . '. All rights reserved.'; ?></p>
  <p class="beian">
    <?php if ($site['rss']): ?><a href="<?php echo e(rss_url()); ?>">RSS 订阅</a><?php endif; ?>
    <a href="<?php echo e(base_url() . 'sitemap.xml'); ?>">Sitemap</a>
    <span>·</span>
    <span>由 MoeZ v<?php echo MOE_VERSION; ?> 强力驱动</span>
  </p>
</footer>

<!-- 用户中心面板 -->
<div class="by-user-panel" id="userPanel" style="display:none">
  <div class="up-head">
    <?php
    $navAva = $site['avatar'] ? media_url($site['avatar']) : '';
    if ($navAva): ?>
      <img src="<?php echo e($navAva); ?>" alt="头像" referrerpolicy="no-referrer">
    <?php else: ?>
      <span class="face"><?php echo e(initial($site['name'])); ?></span>
    <?php endif; ?>
    <div style="min-width:0">
      <b><?php echo e($site['name']); ?></b>
      <span class="role">👑 站长 · MoeZ</span>
    </div>
  </div>
  <div class="up-nums">
    <a href="<?php echo e(base_url() . 'archives'); ?>"><b><?php echo (int)$s_stats['posts']; ?></b><span>文章</span></a>
    <a href="<?php echo e(base_url() . 'link'); ?>"><b><?php echo (int)$s_stats['comments']; ?></b><span>评论</span></a>
    <a href="javascript:;"><b><?php echo (int)$s_stats['views']; ?></b><span>浏览</span></a>
  </div>
  <div class="up-links">
    <a href="<?php echo e(base_url() . 'admin/post-edit.php'); ?>">📝 写文章</a>
    <a href="<?php echo e(base_url() . 'admin/comments.php'); ?>">💬 评论管理</a>
    <a href="<?php echo e(base_url() . 'admin/'); ?>">⚙️ 管理后台</a>
    <a href="<?php echo e(base_url() . 'archives'); ?>">📚 文章归档</a>
    <a href="<?php echo e(base_url() . 'link'); ?>">🤝 友链申请</a>
    <?php if ($site['rss']): ?><a href="<?php echo e(rss_url()); ?>">🌈 RSS 订阅</a><?php endif; ?>
  </div>
</div>

<!-- 右侧悬浮球 -->
<div class="by-fab">
  <button type="button" id="fabSakura" class="<?php echo $opt_sakura ? '' : 'off'; ?>" title="樱花特效开关" aria-label="樱花特效开关">🌸</button>
  <button type="button" id="backTop" title="回到顶部" aria-label="回到顶部">🚀</button>
</div>

<script>
(function () {
  /* ---- 导航滚动态：过 Hero 后变白底 ---- */
  var nav = document.getElementById('byNav');
  function navState() {
    if (!nav) return;
    if (window.scrollY > 60) nav.classList.add('solid'); else nav.classList.remove('solid');
  }
  navState();
  window.addEventListener('scroll', navState, { passive: true });

  /* ---- 移动端菜单 ---- */
  var burger = document.getElementById('byBurger');
  var menu = document.getElementById('byMenu');
  if (burger && menu) {
    burger.addEventListener('click', function () { menu.classList.toggle('open'); });
  }

  /* ---- Hero 打字机特效（循环：打完停 2.4s → 删完停 0.4s → 重打） ---- */
  var typed = document.getElementById('byTyped');
  if (typed) {
    var text = typed.textContent;
    typed.textContent = '';
    var i = 0, adding = true;
    (function tick() {
      if (adding) {
        i++;
        typed.textContent = text.slice(0, i);
        if (i >= text.length) { adding = false; return setTimeout(tick, 2400); }
        return setTimeout(tick, 130);
      }
      i--;
      typed.textContent = text.slice(0, i);
      if (i <= 0) { adding = true; return setTimeout(tick, 420); }
      setTimeout(tick, 38);
    })();
  }

  /* ---- 返回顶部 ---- */
  var bt = document.getElementById('backTop');
  window.addEventListener('scroll', function () {
    if (window.scrollY > 360) bt.classList.add('show'); else bt.classList.remove('show');
  }, { passive: true });
  bt.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });

  /* ---- 用户中心面板开合（右上角头像触发） ---- */
  var fabUser = document.getElementById('navAva') || document.getElementById('fabUser');
  var panel = document.getElementById('userPanel');
  if (fabUser && panel) {
    fabUser.addEventListener('click', function (e) {
      e.stopPropagation();
      var open = panel.style.display !== 'block';
      panel.style.display = open ? 'block' : 'none';
      panel.classList.toggle('open', open);
    });
    document.addEventListener('click', function (e) {
      if (panel.style.display === 'block' && !panel.contains(e.target)) {
        panel.style.display = 'none';
        panel.classList.remove('open');
      }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        panel.style.display = 'none';
        panel.classList.remove('open');
      }
    });
  }

  /* ---- 樱花飘落（可开关） ---- */
  var glyphs = ['❀', '❁', '✿', '🌸'];
  var sakOn = <?php echo $opt_sakura ? 'true' : 'false'; ?>;
  var fabSakura = document.getElementById('fabSakura');
  function spawnPetal() {
    if (!sakOn) return;
    var p = document.createElement('span');
    p.className = 'petal';
    p.textContent = glyphs[Math.floor(Math.random() * glyphs.length)];
    p.style.left = Math.random() * 100 + 'vw';
    p.style.fontSize = (10 + Math.random() * 12) + 'px';
    p.style.opacity = (.4 + Math.random() * .5).toFixed(2);
    var dur = 9 + Math.random() * 10;
    p.style.animationDuration = dur + 's';
    p.style.animationDelay = (-Math.random() * dur).toFixed(1) + 's';
    document.body.appendChild(p);
    p.addEventListener('animationiteration', function () {
      if (!sakOn) { p.remove(); return; }
      p.style.left = Math.random() * 100 + 'vw';
    });
  }
  if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    var n = window.innerWidth < 760 ? 8 : 14;
    for (var i = 0; i < n; i++) spawnPetal();
    setInterval(spawnPetal, 1800);
  }
  if (fabSakura) {
    fabSakura.addEventListener('click', function () {
      sakOn = !sakOn;
      fabSakura.classList.toggle('off', !sakOn);
      if (!sakOn) {
        document.querySelectorAll('.petal').forEach(function (p) { p.remove(); });
      }
    });
  }

  /* ---- 页脚运行天数实时计时（页脚含 id=byRun 时启用） ---- */
  var runEl = document.getElementById('byRun');
  if (runEl) {
    var born = runEl.getAttribute('data-born') || '';
    if (/^\d{4}-\d{2}-\d{2}$/.test(born)) {
      var mileEl = document.getElementById('byMile');
      function pad(x) { return (x < 10 ? '0' : '') + x; }
      function tickRun() {
        var diff = Math.max(0, Date.now() - new Date(born + 'T00:00:00+08:00').getTime());
        var d = Math.floor(diff / 86400000);
        var h = Math.floor(diff % 86400000 / 3600000);
        var m = Math.floor(diff % 3600000 / 60000);
        var s = Math.floor(diff % 60000 / 1000);
        runEl.innerHTML = '本站已运行了 <b>' + d + '</b> 天 <b>' + pad(h) + '</b> 时 <b>' + pad(m) + '</b> 分 <b>' + pad(s) + '</b> 秒 ❤';
        if (mileEl) {
          mileEl.textContent = '🌍 本站已伴随地球自转 ' + d.toLocaleString('en-US') + ' 圈，走过赤道约 ' + (d * 40075).toLocaleString('en-US') + ' 千米 ✨';
        }
      }
      tickRun();
      setInterval(tickRun, 1000);
    }
  }
})();
</script>
</body>
</html>
