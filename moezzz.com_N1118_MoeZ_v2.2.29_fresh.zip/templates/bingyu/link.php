<?php
/**
 * 冰屿模板 · 友情链接页
 * 可用变量：$links $site $nav_cats
 */
$page_title = '友情链接';
$cur_p = 'links';
$hero_mode = 'banner';
$hero_title = '🔗 友情链接';
$hero_meta = array(array('ico' => '🌐', 'text' => '共收录 ' . count($links) . ' 个站点'));
include partial_path('header.php');
?>

      <main class="by-main" style="width:100%">
        <?php if (empty($links)): ?>
          <div class="empty-box">
            <span class="big">🤝</span>
            <p>还没有友链，来交个朋友吧～</p>
          </div>
        <?php else: ?>
          <div class="cards" style="column-count:3">
            <?php foreach ($links as $l): ?>
              <?php
                $ico = function_exists('link_icon') ? link_icon($l) : '';
                $ld  = function_exists('link_desc') ? link_desc($l) : '';
                $sub = $ld !== '' ? $ld : (parse_url($l['url'], PHP_URL_HOST) ?: $l['url']);
              ?>
              <a class="card-p" style="display:block" href="<?php echo e($l['url']); ?>" target="_blank" rel="noopener nofollow" title="<?php echo e($l['name']); ?>">
                <div class="pad">
                  <div style="display:flex;align-items:center;gap:10px">
                    <span class="dot-ava" style="width:34px;height:34px;font-size:14px;border-radius:12px;overflow:hidden">
                      <?php if ($ico !== ''): ?>
                        <img src="<?php echo e($ico); ?>" alt="<?php echo e(initial($l['name'])); ?>" loading="lazy"
                             style="width:100%;height:100%;object-fit:cover;display:block"
                             onerror="this.parentNode.textContent=this.alt">
                      <?php else: ?>
                        <?php echo e(initial($l['name'])); ?>
                      <?php endif; ?>
                    </span>
                    <span style="min-width:0">
                      <b style="display:block;font-size:14.5px"><?php echo e($l['name']); ?></b>
                      <small style="color:var(--muted);font-size:11.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:block"><?php echo e($sub); ?></small>
                    </span>
                  </div>
                </div>
              </a>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <div class="empty-box" style="padding:26px;margin-top:18px">
          <p style="margin:0;font-size:13px">想交换友链？在下方填写你的站点地址，提交后会自动检测回链 👇</p>
          <form class="cmt-form" id="flForm" style="width:100%;margin-top:14px;text-align:left"
                method="post" action="<?php echo e(base_url() . 'link.php'); ?>">
            <?php echo csrf_field(); ?>
            <div class="row">
              <input type="url" name="url" placeholder="你的站点地址 *（如 https://example.com）" required>
            </div>
            <div class="row">
              <input type="text" name="name" placeholder="站点名称（留空自动获取）">
              <input type="text" name="contact" placeholder="联系方式（选填）">
            </div>
            <button class="send" type="submit" id="flSubmit">提交申请</button>
            <p id="flMsg" style="font-size:12.5px;margin:12px 0 0;display:none"></p>
          </form>
        </div>
      </main>

      <script>
      document.getElementById('flForm').addEventListener('submit', function (e) {
        e.preventDefault();
        var btn = document.getElementById('flSubmit'), msg = document.getElementById('flMsg');
        btn.disabled = true; btn.style.opacity = '.6'; btn.textContent = '检测中…';
        msg.style.display = 'block'; msg.style.color = '#8b93a7'; msg.textContent = '正在访问你的站点检测回链…';
        fetch(this.action, { method: 'POST', body: new FormData(this) })
          .then(function (r) { return r.json(); })
          .then(function (d) {
            msg.style.color = d.ok ? '#3fb984' : '#e0566b';
            msg.textContent = d.msg;
            if (d.ok) { setTimeout(function () { location.reload(); }, 1600); }
            else { btn.disabled = false; btn.style.opacity = '1'; btn.textContent = '提交申请'; }
          })
          .catch(function () {
            msg.style.color = '#e0566b'; msg.textContent = '网络开小差了，请稍后重试';
            btn.disabled = false; btn.style.opacity = '1'; btn.textContent = '提交申请';
          });
      });
      </script>

<?php include partial_path('footer.php'); ?>
