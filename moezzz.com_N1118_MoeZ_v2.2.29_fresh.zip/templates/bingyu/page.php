<?php
/**
 * 冰屿模板 · 独立页面
 * 可用变量：$page $site $nav_cats
 */
$page_title = $page['title'];
$cur_p = 'page';
$hero_mode = 'banner';
$hero_title = $page['title'];
$hero_meta = array(array('ico' => '📅', 'text' => '更新于 ' . format_time($page['updated_at'], 'Y-m-d')));
include partial_path('header.php');
?>

      <article class="article-wrap">
        <div class="md-body">
          <?php echo render_content($page['content'], isset($page['content_format']) ? $page['content_format'] : 'html'); ?>
        </div>
        <div class="post-foot">
          <span><?php echo e($site['name']); ?> · <?php echo e(format_time($page['updated_at'], 'Y-m-d')); ?></span>
        </div>
      </article>

<?php include partial_path('footer.php'); ?>
