<?php
/**
 * 冰屿模板 · 404
 * 可用变量：$site $nav_cats
 */
$page_title = '页面不存在 404';
$cur_p = '404';
$hero_mode = 'none';
include partial_path('header.php');
?>

      <main class="by-main" style="width:100%">
        <div class="empty-box" style="padding:70px 20px;margin-top:20px">
          <span class="big" style="font-size:54px">❄</span>
          <div style="font-size:clamp(30px,7vw,44px);font-weight:800;letter-spacing:.1em;margin-bottom:8px;
                      background:linear-gradient(120deg,var(--accent),var(--accent2));
                      -webkit-background-clip:text;background-clip:text;color:transparent">404</div>
          <p>页面飘去雪国了 · 你要找的内容不存在或已被移除</p>
          <a class="btn-go" href="<?php echo e(home_url()); ?>">回到首页</a>
        </div>
      </main>

<?php include partial_path('footer.php'); ?>
