<?php
/**
 * 冰屿模板 · 公共头部
 * 可用变量：$site $nav_cats；页面可预设：
 *   $hero_mode  'full' 首页全屏封面 | 'banner' 内页小横幅 | 'none' 无横幅
 *   $hero_title / $hero_sub / $hero_meta(array)  横幅标题、副标题、元信息胶囊
 */
$cur = isset($cur_p) ? $cur_p : 'index';
$hero_mode = isset($hero_mode) ? $hero_mode : 'banner';
$pretty = is_pretty_url();
/* 目录适配：原有优先级不变，仅补「主题图标文件缺失 → 站点根 favicon.ico」兜底 */
$moe_icon_ready = function_exists('moe_theme_icon') && function_exists('moe_icon_links');
$moe_icon_raw   = $site['avatar'] ? media_url($site['avatar']) : '';
$favicon = $moe_icon_ready ? moe_theme_icon($moe_icon_raw, 'assets/favicon.svg')
                           : ($moe_icon_raw !== '' ? $moe_icon_raw : theme_url('assets/favicon.svg'));

/* ---------- 模板设置（后台「模板管理 → 模板设置」） ---------- */
$opt_accent = theme_opt('accent', '#3f9dff');
if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $opt_accent)) $opt_accent = '#3f9dff';
$opt_hero_img = trim(theme_opt('hero_image', ''));
if ($opt_hero_img !== '' && !preg_match('#^(https?://|/)#', $opt_hero_img)) {
    $opt_hero_img = media_url($opt_hero_img);
}
$opt_hero_sub = theme_opt('hero_sub', '');
$opt_sakura   = theme_opt('sakura', '1') === '1';
$opt_side     = theme_opt('show_sidebar', '1') === '1';
$opt_cover    = (int)theme_opt('cover_height', '160');
if (!in_array($opt_cover, array(140, 160, 190, 220), true)) $opt_cover = 160;
$opt_fnote    = theme_opt('footer_note', '');
/* 首页封面高度 */
$opt_hero_h = theme_opt('hero_height', '92vh');
if (!in_array($opt_hero_h, array('100vh', '92vh', '80vh', '70vh', '560px'), true)) $opt_hero_h = '92vh';
/* 内页横幅（分类/文章/归档等） */
$opt_show_banner = theme_opt('show_banner', '1') === '1';
$opt_banner_h = (int)theme_opt('banner_height', '280');
if (!in_array($opt_banner_h, array(220, 280, 360), true)) $opt_banner_h = 280;
$opt_banner_img = trim(theme_opt('banner_image', ''));
if ($opt_banner_img !== '' && !preg_match('#^(https?://|/)#', $opt_banner_img)) {
    $opt_banner_img = media_url($opt_banner_img);
}
if ($opt_banner_img === '') $opt_banner_img = $opt_hero_img;
/* Hero 打字机文案 */
$typed_text = $opt_hero_sub !== '' ? $opt_hero_sub : ($site['sub'] !== '' ? $site['sub'] : $site['desc']);

/* 菜单图标：按序号给导航项配小图标 */
$icons = array('🏠', '📚', '🏠', '💖', '🎵', '📦', '🗒', '🖼', '🧰', '✏️', '💬', '🌸');
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php echo seo_head(); ?>
<meta name="theme-color" content="#3f9dff">
<?php echo function_exists('moe_icon_links') ? moe_icon_links($favicon) : '<link rel="icon" href="' . e($favicon) . '">' . "\n"; ?>
<link rel="alternate" type="application/rss+xml" title="<?php echo e($site['name']); ?>" href="<?php echo e(rss_url()); ?>">
<?php $css_v = MOE_VERSION . '.' . (int)@filemtime(theme_path('assets/style.css')); ?>
<link rel="stylesheet" href="<?php echo e(theme_url('assets/style.css')); ?>?v=<?php echo e($css_v); ?>">
<style>:root{--accent:<?php echo e($opt_accent); ?>;--cover-h:<?php echo $opt_cover; ?>px;--hero-h:<?php echo e($opt_hero_h); ?>;--banner-h:<?php echo $opt_banner_h; ?>px;}</style>
</head>
<body class="<?php echo ($hero_mode === 'none' || ($hero_mode === 'banner' && !$opt_show_banner)) ? 'no-hero' : ''; ?>">

<!-- 吸顶导航 -->
<nav class="by-nav" id="byNav">
  <a class="by-brand" href="<?php echo e(home_url()); ?>">
    <span class="mark">❄</span><?php echo e($site['name']); ?>
  </a>
  <button type="button" class="by-burger" id="byBurger" aria-label="展开菜单">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
  </button>
  <div class="by-menu" id="byMenu">
    <a class="<?php echo $cur === 'index' ? 'cur' : ''; ?>" href="<?php echo e(home_url()); ?>">🏠 首页</a>
    <?php $i = 1; foreach ($nav_cats as $c): ?>
      <a class="<?php echo (isset($cat) && $cat['id'] == $c['id']) ? 'cur' : ''; ?>"
         href="<?php echo e(cat_url($c)); ?>"><?php echo $icons[$i % count($icons)]; ?> <?php echo e($c['name']); ?></a>
    <?php $i++; endforeach; ?>
    <a class="<?php echo $cur === 'archive' ? 'cur' : ''; ?>" href="<?php echo e(base_url() . 'archives'); ?>">📚 归档</a>
    <a class="<?php echo $cur === 'links' ? 'cur' : ''; ?>" href="<?php echo e(base_url() . 'link'); ?>">🔗 友链</a>
    <a href="<?php echo e(base_url() . 'admin/'); ?>">⚙️ 后台</a>
  </div>
  <?php
  $navAva = $site['avatar'] ? media_url($site['avatar']) : '';
  if ($navAva): ?>
    <button type="button" class="ava-btn" id="navAva" title="用户中心" aria-label="用户中心">
      <img class="ava" src="<?php echo e($navAva); ?>" alt="头像" referrerpolicy="no-referrer">
    </button>
  <?php else: ?>
    <button type="button" class="ava-btn" id="navAva" title="用户中心" aria-label="用户中心">
      <span class="ava"><?php echo e(initial($site['name'])); ?></span>
    </button>
  <?php endif; ?>
</nav>

<?php if ($hero_mode === 'full'): ?>
<!-- 全屏封面 -->
<header class="by-hero">
  <?php if ($opt_hero_img !== ''): ?>
    <img class="bg" src="<?php echo e($opt_hero_img); ?>" alt="" referrerpolicy="no-referrer">
  <?php endif; ?>
  <div class="inner">
    <h1><?php echo e($site['name']); ?></h1>
    <p class="sub"><span id="byTyped"><?php echo e($typed_text); ?></span><span class="tcur" aria-hidden="true"></span></p>
  </div>
  <a class="down" href="#main" aria-label="向下滚动">
    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>
  </a>
  <svg class="wave" viewBox="0 0 1440 70" preserveAspectRatio="none" aria-hidden="true">
    <path fill="#f6f7fb" d="M0,42 C240,72 480,10 720,26 C960,42 1200,66 1440,34 L1440,70 L0,70 Z"/>
  </svg>
</header>
<?php elseif ($hero_mode === 'banner' && $opt_show_banner): ?>
<!-- 内页横幅 -->
<header class="by-banner">
  <?php if ($opt_banner_img !== ''): ?>
    <img class="bg" src="<?php echo e($opt_banner_img); ?>" alt="" referrerpolicy="no-referrer">
  <?php endif; ?>
  <div class="inner">
    <h1><?php echo e(isset($hero_title) ? $hero_title : $page_title); ?></h1>
    <?php if (!empty($hero_meta)): ?>
      <div class="meta">
        <?php foreach ($hero_meta as $m): ?>
          <?php if (!empty($m['url'])): ?>
            <a href="<?php echo e($m['url']); ?>"><?php echo $m['ico'] . ' ' . e($m['text']); ?></a>
          <?php else: ?>
            <span><?php echo $m['ico'] . ' ' . e($m['text']); ?></span>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</header>
<?php endif; ?>

<div class="by-wrap" id="main">
