<?php
/**
 * 冰屿模板 · 归档时间线
 * 可用变量：$groups（按年份分组）$total $site $nav_cats
 */
$page_title = '归档';
$cur_p = 'archive';
$hero_mode = 'banner';
$hero_title = '📚 文章归档';
$hero_meta = array(array('ico' => '🗂', 'text' => '共 ' . (int)$total . ' 篇文章'));
include partial_path('header.php');

/* 年份筛选 tab（仿归档页胶囊样式） */
$years = array_keys((array)$groups);
?>

      <main class="by-main" style="width:100%">
        <?php if (empty($years)): ?>
          <div class="empty-box">
            <span class="big">📚</span>
            <p>还没有文章可以归档哦～</p>
            <a class="btn-go" href="<?php echo e(home_url()); ?>">回到首页</a>
          </div>
        <?php else: ?>
          <div class="tag-cloud" style="justify-content:center;margin-bottom:22px" id="yearTabs">
            <a class="year-tab cur" href="javascript:;" data-year="all">全部 <small><?php echo (int)$total; ?></small></a>
            <?php foreach ($years as $y): ?>
              <a class="year-tab" href="javascript:;" data-year="<?php echo e($y); ?>"><?php echo e($y); ?> <small><?php echo count($groups[$y]); ?></small></a>
            <?php endforeach; ?>
          </div>

          <?php foreach ($groups as $y => $items): ?>
          <section class="archive-year" data-year="<?php echo e($y); ?>">
            <h2 style="font-size:18px;margin:6px 0 14px;display:flex;align-items:center;gap:8px">
              <span style="font-size:14px;color:var(--muted)">📅</span><?php echo e($y); ?>
              <small style="font-size:12px;color:var(--muted);font-weight:400"><?php echo count($items); ?> 篇</small>
            </h2>
            <div style="background:var(--card);border-radius:var(--radius);box-shadow:var(--shadow);border:1px solid rgba(237,240,246,.8);padding:6px 20px">
              <?php foreach ($items as $it): ?>
                <div style="display:flex;gap:12px;align-items:baseline;padding:10px 0;border-bottom:1px dashed var(--line)">
                  <time style="color:var(--muted);font-size:12.5px;flex-shrink:0"><?php echo e(format_time($it['created_at'], 'm-d')); ?></time>
                  <a style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:14px"
                     href="<?php echo e(post_url($it)); ?>"><?php echo e($it['title']); ?></a>
                  <span style="color:var(--muted);font-size:12px;flex-shrink:0">👀 <?php echo isset($it['views']) ? (int)$it['views'] : 0; ?></span>
                </div>
              <?php endforeach; ?>
            </div>
          </section>
          <?php endforeach; ?>
        <?php endif; ?>
      </main>

      <script>
      (function () {
        var tabs = document.querySelectorAll('.year-tab');
        var secs = document.querySelectorAll('.archive-year');
        tabs.forEach(function (t) {
          t.addEventListener('click', function () {
            var y = t.getAttribute('data-year');
            tabs.forEach(function (x) { x.classList.remove('cur'); });
            t.classList.add('cur');
            secs.forEach(function (s) {
              s.style.display = (y === 'all' || s.getAttribute('data-year') === y) ? '' : 'none';
            });
          });
        });
      })();
      </script>

<?php include partial_path('footer.php'); ?>
