<?php
/**
 * 冰屿模板 · 首页（全屏封面 + 侧栏 + 卡片瀑布流）
 * 可用变量：$posts $pager $page $total $site $nav_cats
 */
$page_title = $site['name'];
$cur_p = 'index';
$hero_mode = 'full';
include partial_path('header.php');

/* ---------- 侧栏数据 ---------- */
$hot = rows('SELECT id, slug, title, cover, views, created_at FROM ' . moe_table('posts')
    . " WHERE type='post' AND status='published' ORDER BY views DESC, id DESC LIMIT 6");
$s_cmts = rows('SELECT c.author, c.content, c.created_at, p.title FROM ' . moe_table('comments') . ' c
    LEFT JOIN ' . moe_table('posts') . ' p ON p.id = c.post_id
    WHERE c.status = \'approved\' ORDER BY c.id DESC LIMIT 5');
$s_cats = rows('SELECT c.*, (SELECT COUNT(*) FROM ' . moe_table('posts')
    . " p WHERE p.category_id = c.id AND p.type='post' AND p.status='published') AS n FROM "
    . moe_table('categories') . ' c ORDER BY n DESC LIMIT 10');
$s_stats = $site['stats'];
$opt_side = theme_opt('show_sidebar', '1') === '1';

/* ---------- 名片/欢迎语/一言设置 ---------- */
$opt_sidebg = trim(theme_opt('side_bg', ''));
if ($opt_sidebg !== '' && !preg_match('#^(https?://|/)#', $opt_sidebg)) $opt_sidebg = media_url($opt_sidebg);
$opt_welcome = theme_opt('side_welcome', '');
$opt_quote = trim(theme_opt('side_quote', ''));
if ($opt_quote !== '' && strpos($opt_quote, '|') !== false) {
    list($q_text, $q_from) = array_map('trim', explode('|', $opt_quote, 2));
} else {
    /* 今日一言：经典名言按日期轮换 */
    $quotes = array(
        array('不积跬步，无以至千里。', '《荀子·劝学》'),
        array('千里之行，始于足下。', '《道德经》'),
        array('学而不思则罔，思而不学则殆。', '《论语》'),
        array('山重水复疑无路，柳岸花明又一村。', '《游山西村》'),
        array('长风破浪会有时，直挂云帆济沧海。', '《行路难》'),
        array('会当凌绝顶，一览众山小。', '《望岳》'),
        array('纸上得来终觉浅，绝知此事要躬行。', '《冬夜读书示子聿》'),
        array('海内存知己，天涯若比邻。', '《送杜少府之任蜀州》'),
        array('路漫漫其修远兮，吾将上下而求索。', '《离骚》'),
        array('少壮不努力，老大徒伤悲。', '《长歌行》'),
    );
    $q = $quotes[(int)date('z') % count($quotes)];
    $q_text = $q[0]; $q_from = $q[1];
}
$side_ava = $site['avatar'] ? media_url($site['avatar']) : '';
$side_name = $site['author'] !== '' ? $site['author'] : $site['name'];
$side_sig = $site['signature'] !== '' ? $site['signature'] : ($site['desc'] !== '' ? $site['desc'] : '记录生活，分享美好。');
?>

<div class="by-layout <?php echo $opt_side ? '' : 'no-side'; ?>">
  <?php if ($opt_side): ?>
  <!-- ======= 左侧栏 ======= -->
  <aside class="by-side">
    <div class="s-card s-me">
      <div class="top">
        <?php if ($opt_sidebg !== ''): ?>
          <img class="bg" src="<?php echo e($opt_sidebg); ?>" alt="" referrerpolicy="no-referrer">
        <?php endif; ?>
        <span class="ava-holder">
          <?php if ($side_ava): ?>
            <img src="<?php echo e($side_ava); ?>" alt="<?php echo e($side_name); ?>" referrerpolicy="no-referrer">
          <?php else: ?>
            <span class="init"><?php echo e(initial($side_name)); ?></span>
          <?php endif; ?>
        </span>
      </div>
      <div class="body">
        <h3><?php echo e($side_name); ?></h3>
        <p class="desc"><?php echo e($side_sig); ?></p>
        <div class="s-socials">
          <?php foreach ($site['socials'] as $soc): ?>
          <?php $socImg = function_exists('social_icon_url') ? social_icon_url($soc['icon']) : ''; ?>
          <a href="<?php echo e($soc['url']); ?>" target="_blank" rel="noopener nofollow" title="<?php echo e($soc['name']); ?>" aria-label="<?php echo e($soc['name']); ?>">
            <?php if ($socImg !== ''): ?>
              <img src="<?php echo e($socImg); ?>" alt="<?php echo e($soc['name']); ?>" style="width:18px;height:18px;object-fit:contain">
            <?php else: ?>
              <span style="font-size:18px;line-height:1"><?php echo e($soc['icon'] !== '' ? $soc['icon'] : '🔗'); ?></span>
            <?php endif; ?>
          </a>
          <?php endforeach; ?>
          <?php if ($site['rss']): ?>
          <a href="<?php echo e(rss_url()); ?>" title="RSS 订阅" aria-label="RSS 订阅">
            <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="6.2" cy="17.8" r="2.3"/><path d="M3.9 10.1v3c4 0 7.2 3.2 7.2 7.1h3c0-5.6-4.5-10.1-10.2-10.1zM3.9 3.9v3c7.4 0 13.3 6 13.3 13.3h3c0-9-7.3-16.3-16.3-16.3z"/></svg>
          </a>
          <?php endif; ?>
        </div>
        <div class="s-nums2">
          <div class="n2"><b><?php echo number_format((int)$s_stats['posts']); ?></b><span>📝 文章总数</span></div>
          <div class="n2"><b><?php echo number_format((int)$s_stats['views']); ?></b><span>👀 总浏览量</span></div>
        </div>
      </div>
    </div>

    <!-- 欢迎来访者 -->
    <div class="s-card s-welcome">
      <h3 class="s-t">📢 欢迎来访者</h3>
      <p class="w-text"><?php echo e($opt_welcome); ?></p>
      <div class="w-btns">
        <a class="w-btn" href="<?php echo e(base_url() . 'about'); ?>">了解更多</a>
        <?php if ($site['github']): ?>
          <a class="w-btn" href="<?php echo e($site['github']); ?>" target="_blank" rel="noopener nofollow">开源地址</a>
        <?php elseif ($site['rss']): ?>
          <a class="w-btn" href="<?php echo e(rss_url()); ?>">订阅本站</a>
        <?php endif; ?>
      </div>
    </div>

    <!-- 今日一言 -->
    <div class="s-card s-quote">
      <h3 class="s-t">💬 今日一言</h3>
      <p class="q-text"><?php echo e($q_text); ?></p>
      <p class="q-from">—— <?php echo e($q_from); ?></p>
    </div>

    <div class="s-card">
      <form class="s-search" method="get" action="<?php echo e(base_url() . 'index.php'); ?>"
            data-pretty="<?php echo $pretty ? '1' : '0'; ?>" data-base="<?php echo e(base_url()); ?>">
        <input type="hidden" name="p" value="search">
        <input type="search" name="q" placeholder="输入关键词搜索" value="<?php echo isset($kw) ? e($kw) : ''; ?>" required>
        <button type="submit" aria-label="搜索">🔍</button>
      </form>
    </div>

    <?php if (!empty($hot)): ?>
    <div class="s-card">
      <h3 class="s-t">🔥 热门文章</h3>
      <ul class="hot-list">
        <?php foreach ($hot as $i => $h): ?>
        <li>
          <span class="rank"><?php echo $i + 1; ?></span>
          <span class="t"><a href="<?php echo e(post_url($h)); ?>"><?php echo e($h['title']); ?></a></span>
          <?php if (post_cover($h)): ?>
            <img class="thumb" src="<?php echo e(media_url(post_cover($h))); ?>" alt="" loading="lazy" referrerpolicy="no-referrer">
          <?php endif; ?>
        </li>
        <?php endforeach; ?>
      </ul>
    </div>
    <?php endif; ?>

    <?php if (!empty($s_cats)): ?>
    <div class="s-card">
      <h3 class="s-t">🏷 标签聚合</h3>
      <div class="tag-cloud">
        <?php foreach ($s_cats as $c): ?>
          <a href="<?php echo e(cat_url($c)); ?>"><?php echo e($c['name']); ?><small><?php echo (int)$c['n']; ?></small></a>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($s_cmts)): ?>
    <div class="s-card">
      <h3 class="s-t">💬 最新留言</h3>
      <ul class="s-cmts">
        <?php foreach ($s_cmts as $c): ?>
        <li>
          <b><?php echo e($c['author']); ?></b>
          <p title="<?php echo e($c['title']); ?>"><?php echo e(excerpt_text($c['content'], 26)); ?></p>
        </li>
        <?php endforeach; ?>
      </ul>
    </div>
    <?php endif; ?>
  </aside>
  <?php endif; ?>

  <!-- ======= 文章卡片瀑布流 ======= -->
  <main class="by-main">
    <?php if (empty($posts)): ?>
      <div class="empty-box">
        <span class="big">🌱</span>
        <p>还没有文章哦，登录后台写下第一篇吧～</p>
        <a class="btn-go" href="<?php echo e(base_url() . 'admin/'); ?>">前往后台</a>
      </div>
    <?php else: ?>
      <div class="cards">
        <?php foreach ($posts as $p): ?>
        <article class="card-p">
          <?php if (post_cover($p)): ?>
            <a class="cover" href="<?php echo e(post_url($p)); ?>">
              <img src="<?php echo e(media_url(post_cover($p))); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy" referrerpolicy="no-referrer">
            </a>
          <?php endif; ?>
          <div class="pad">
            <div class="byline">
              <span class="dot-ava"><?php echo e(initial($site['author'] ?: $site['name'])); ?></span>
              <span><?php echo e($site['author'] ?: $site['name']); ?></span>
              <span>·</span>
              <time><?php echo e(format_time($p['created_at'], 'Y-m-d H:i')); ?></time>
              <?php if (!empty($p['is_top'])): ?><span style="color:var(--accent)">置顶</span><?php endif; ?>
            </div>
            <h3><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
            <p class="excerpt"><?php echo e(post_excerpt($p, 70)); ?></p>
            <div class="foot">
              <span>👀 <?php echo (int)$p['views']; ?></span>
              <?php
              $cN = function_exists('post_comment_count') ? (int)post_comment_count($p['id']) : 0;
              ?>
              <span>💬 <?php echo $cN; ?></span>
              <span class="sp"></span>
              <?php if (!empty($p['cat_name'])): ?>
                <a class="chip-tag" href="<?php echo e(cat_url(array('id' => $p['cat_id'], 'slug' => $p['cat_slug'], 'name' => $p['cat_name']))); ?>"><?php echo e($p['cat_name']); ?></a>
              <?php endif; ?>
            </div>
          </div>
        </article>
        <?php endforeach; ?>
      </div>
      <?php echo $pager; ?>
    <?php endif; ?>
  </main>
</div>

<?php include partial_path('footer.php'); ?>
