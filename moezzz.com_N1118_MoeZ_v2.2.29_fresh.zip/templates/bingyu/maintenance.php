<?php
/**
 * 冰屿模板 · 维护模式
 * 可用变量：$site $nav_cats
 */
$page_title = '站点维护中';
$cur_p = 'maintenance';
$hero_mode = 'none';
include partial_path('header.php');
?>

      <main class="by-main" style="width:100%">
        <div class="empty-box" style="padding:70px 20px;margin-top:20px">
          <span class="big" style="font-size:54px">🛠</span>
          <div style="font-size:22px;font-weight:800;margin-bottom:8px"><?php echo e($site['name']); ?> 正在装修中…</div>
          <p>站点暂时进入维护模式，马上回来，请稍后再来看看～</p>
        </div>
      </main>

<?php include partial_path('footer.php'); ?>
