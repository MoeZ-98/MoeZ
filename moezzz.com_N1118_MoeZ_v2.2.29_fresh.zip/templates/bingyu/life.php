<?php
/**
 * 冰屿模板 · 点滴时间线（/life）
 * 可用变量：$groups（'YYYY-MM' => 文章行数组，行内额外含 comment_count）$total $life_cat $site $nav_cats
 */
$page_title = '点滴';
$cur_p = 'life';
$hero_mode = 'banner';
$hero_title = '🌙 点滴';
$hero_meta = array(
    array('ico' => '🗂', 'text' => '共 ' . (int)$total . ' 条记录'),
);
if (!empty($life_cat['name'])) {
    $hero_meta[] = array('ico' => '🏷', 'text' => $life_cat['name'], 'url' => cat_url($life_cat));
}
include partial_path('header.php');
?>

      <main class="by-main" style="width:100%">
        <?php if (empty($groups)): ?>
          <div class="empty-box">
            <span class="big">🍃</span>
            <p>还没有点滴记录哦，随手记下生活的碎片吧～</p>
            <a class="btn-go" href="<?php echo e(home_url()); ?>">回到首页</a>
          </div>
        <?php else: ?>
          <div class="by-life">
            <?php foreach ($groups as $month => $items): ?>
            <section class="by-life-group">
              <h2 class="by-life-month"><?php echo e($month); ?><small><?php echo count((array)$items); ?> 条</small></h2>
              <ul class="by-life-list">
                <?php foreach ((array)$items as $it): ?>
                <li>
                  <time class="by-life-time"><?php echo e(format_time($it['created_at'], 'm-d H:i')); ?></time>
                  <div class="by-life-body">
                    <a class="by-life-title" href="<?php echo e(post_url($it)); ?>"><?php echo e($it['title']); ?></a>
                    <?php if (trim(post_excerpt($it, 120)) !== ''): ?>
                      <p class="by-life-text"><?php echo e(post_excerpt($it, 120)); ?></p>
                    <?php endif; ?>
                    <span class="by-life-meta">💬 <?php echo isset($it['comment_count']) ? (int)$it['comment_count'] : 0; ?> 条评论 · 👀 <?php echo isset($it['views']) ? (int)$it['views'] : 0; ?> 次浏览</span>
                  </div>
                </li>
                <?php endforeach; ?>
              </ul>
            </section>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </main>

<?php include partial_path('footer.php'); ?>