<?php
/**
 * 冰屿模板 · 文章详情
 * 可用变量：$post $cat $prev $next $comments $site $nav_cats
 */
$page_title = $post['title'];
$cur_p = 'post';
$hero_mode = 'banner';
$hero_title = $post['title'];
$hero_meta = array(
    array('ico' => '👤', 'text' => $site['author'] ?: $site['name']),
    array('ico' => '👀', 'text' => (int)$post['views'] . ' 次浏览'),
    array('ico' => '📅', 'text' => format_time($post['created_at'], 'Y-m-d H:i')),
);
if ($cat) $hero_meta[] = array('ico' => '🏷', 'text' => $cat['name'], 'url' => cat_url($cat));
include partial_path('header.php');
?>

      <article class="article-wrap">
        <?php if (trim(post_excerpt($post, 160)) !== ''): ?>
        <!-- 导读摘要 -->
        <div class="ai-box">
          <span class="lab">🤖 AI 文章导读</span>
          <p style="margin:0"><?php echo e(post_excerpt($post, 160)); ?></p>
        </div>
        <?php endif; ?>

        <div class="md-body">
          <?php echo render_content($post['content'], isset($post['content_format']) ? $post['content_format'] : 'html'); ?>
        </div>

        <?php echo function_exists('post_tags_html') ? post_tags_html($post) : ''; ?>

        <div class="post-foot">
          <?php if ($cat): ?>
            <a class="chip-tag" href="<?php echo e(cat_url($cat)); ?>"><?php echo e($cat['name']); ?></a>
          <?php endif; ?>
          <?php if (!empty($post['updated_at']) && substr($post['updated_at'], 0, 10) !== substr($post['created_at'], 0, 10)): ?>
            <span>最后更新：<?php echo e(format_time($post['updated_at'], 'Y-m-d')); ?></span>
          <?php endif; ?>
          <span>阅读 <?php echo (int)$post['views']; ?> 次 · 约 <?php echo reading_time($post); ?> 分钟</span>
        </div>
      </article>

      <?php if ($prev || $next): ?>
      <nav class="post-nav">
        <?php if ($prev): ?>
          <a href="<?php echo e(post_url($prev)); ?>"><span class="lab">← 上一篇</span><?php echo e($prev['title']); ?></a>
        <?php else: ?><span></span><?php endif; ?>
        <?php if ($next): ?>
          <a class="next" href="<?php echo e(post_url($next)); ?>"><span class="lab">下一篇 →</span><?php echo e($next['title']); ?></a>
        <?php endif; ?>
      </nav>
      <?php endif; ?>

      <!-- 订阅按钮 -->
      <div class="sub-row">
        <a class="sub-btn p1" href="<?php echo e(base_url() . 'archives'); ?>">📚 查看归档</a>
        <?php if ($site['rss']): ?><a class="sub-btn p2" href="<?php echo e(rss_url()); ?>" target="_blank">🎈 RSS 订阅</a><?php endif; ?>
      </div>

      <section class="comments">
        <h2>💬 文章评论 <small style="color:var(--muted);font-weight:400"><?php echo count($comments); ?> 条</small></h2>

        <?php if (!empty($comments)): ?>
          <div class="cmt-list">
            <?php foreach ($comments as $c): ?>
              <div class="cmt-item">
                <div class="face"><?php echo e(initial($c['author'])); ?></div>
                <div style="min-width:0;flex:1">
                  <div class="head">
                    <b><?php echo e($c['author']); ?></b>
                    <time><?php echo e(nice_time($c['created_at'])); ?></time>
                    <?php
                    $cloc = function_exists('moe_comment_loc') ? moe_comment_loc($c) : (isset($c['location']) ? trim($c['location']) : '');
                    $cua  = function_exists('moe_ua_info') && isset($c['ua']) ? moe_ua_info($c['ua']) : '';
                    ?>
                    <?php if ($cloc !== ''): ?><span class="c-badge"><?php echo e($cloc); ?></span><?php endif; ?>
                    <?php if ($cua !== ''): ?><span class="c-badge"><?php echo e($cua); ?></span><?php endif; ?>
                  </div>
                  <div class="text"><?php echo nl2br(e($c['content'])); ?></div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <?php if (setting('comment_enabled', '1') === '1'): ?>
          <form class="cmt-form" id="cform" method="post" action="<?php echo e(base_url() . 'comment.php'); ?>">
            <input type="hidden" name="post_id" value="<?php echo (int)$post['id']; ?>">
            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
            <h3>✏️ 说点什么吧～</h3>
            <?php $__cdf = function_exists('moe_comment_defaults') ? moe_comment_defaults() : array('author' => '', 'email' => '', 'admin' => false); ?>
            <div class="row">
              <input type="text" name="author" placeholder="你的昵称 *" maxlength="30" required value="<?php echo e($__cdf['author']); ?>">
              <input type="email" name="email" placeholder="邮箱（选填，不会公开）" value="<?php echo e($__cdf['email']); ?>">
            </div>
            <?php if (!empty($__cdf['admin'])): ?><p style="font-size:12px;color:#9a8fae;margin:-4px 0 8px">👋 站长已登录，已自动填入你的信息</p><?php endif; ?>
            <textarea name="content" placeholder="留下你想说的话…" maxlength="1000" required></textarea>
            <button class="send" type="submit" id="csubmit">发射评论 🚀</button>
            <p id="cmsg" style="font-size:12.5px;margin:12px 0 0;display:none"></p>
          </form>
          <script>
          document.getElementById('cform').addEventListener('submit', function (e) {
            e.preventDefault();
            var btn = document.getElementById('csubmit'), msg = document.getElementById('cmsg');
            btn.disabled = true; btn.style.opacity = '.6';
            fetch(this.action, { method: 'POST', body: new FormData(this) })
              .then(function (r) { return r.json(); })
              .then(function (d) {
                msg.style.display = 'block';
                msg.style.color = d.ok ? '#3fb984' : '#e0566b';
                msg.textContent = d.msg;
                if (d.ok) { setTimeout(function () { location.reload(); }, 900); }
                else { btn.disabled = false; btn.style.opacity = '1'; }
              })
              .catch(function () {
                msg.style.display = 'block'; msg.style.color = '#e0566b';
                msg.textContent = '网络开小差了，请稍后重试';
                btn.disabled = false; btn.style.opacity = '1';
              });
          });
          </script>
        <?php else: ?>
          <div class="empty-box" style="padding:30px"><p style="margin:0">评论区暂时关闭啦～</p></div>
        <?php endif; ?>
      </section>

<?php include partial_path('footer.php'); ?>
