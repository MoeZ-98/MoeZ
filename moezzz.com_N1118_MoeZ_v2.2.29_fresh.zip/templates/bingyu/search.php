<?php
/**
 * 冰屿模板 · 搜索结果
 * 可用变量：$posts $kw $pager $total $site $nav_cats
 */
$page_title = '搜索：' . $kw;
$cur_p = 'search';
$hero_mode = 'banner';
$hero_title = '🔍 搜索「' . $kw . '」';
$hero_meta = array(array('ico' => '🗂', 'text' => '找到 ' . (int)$total . ' 篇相关文章'));
include partial_path('header.php');
?>

      <main class="by-main" style="width:100%">
        <?php if (empty($posts)): ?>
          <div class="empty-box">
            <span class="big">🔭</span>
            <p><?php echo $kw !== '' ? '没有找到与「' . e($kw) . '」相关的文章，换个关键词试试？' : '输入关键词开始搜索吧～'; ?></p>
            <a class="btn-go" href="<?php echo e(home_url()); ?>">回到首页</a>
          </div>
        <?php else: ?>
          <div class="cards">
            <?php foreach ($posts as $p): ?>
            <article class="card-p">
              <?php if (post_cover($p)): ?>
                <a class="cover" href="<?php echo e(post_url($p)); ?>">
                  <img src="<?php echo e(media_url(post_cover($p))); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy" referrerpolicy="no-referrer">
                </a>
              <?php endif; ?>
              <div class="pad">
                <div class="byline">
                  <span class="dot-ava"><?php echo e(initial($site['author'] ?: $site['name'])); ?></span>
                  <span><?php echo e($site['author'] ?: $site['name']); ?></span>
                  <span>·</span>
                  <time><?php echo e(format_time($p['created_at'], 'Y-m-d H:i')); ?></time>
                </div>
                <h3><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
                <p class="excerpt"><?php echo e(post_excerpt($p, 70)); ?></p>
                <div class="foot">
                  <span>👀 <?php echo (int)$p['views']; ?></span>
                  <span class="sp"></span>
                  <span class="chip-tag">搜索结果</span>
                </div>
              </div>
            </article>
            <?php endforeach; ?>
          </div>
          <?php echo $pager; ?>
        <?php endif; ?>
      </main>

<?php include partial_path('footer.php'); ?>
