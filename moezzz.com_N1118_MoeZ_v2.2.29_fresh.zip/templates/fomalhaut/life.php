<?php
/**
 * 星辉 · Fomalhaut 模板 · 点滴（/life，按月分组的时间线）
 * 可用变量：$groups $total $life_cat $site
 */
$cur_p = 'life';
include partial_path('header.php');

$fo_hero_img = trim(fo_opt('hero_bg', ''));
$fo_hero_img = $fo_hero_img !== '' ? media_url(fo_opt('hero_bg', '')) : theme_url('assets/hero.svg');
?>
<section class="fo-hero fo-hero--small" style="background-image:linear-gradient(180deg,rgba(14,32,52,.28),rgba(14,32,52,.52)),url('<?php echo e($fo_hero_img); ?>')">
  <div class="fo-hero-center">
    <h1 class="fo-hero-title fo-hero-title--sm">点滴</h1>
    <p class="fo-hero-sub">共 <?php echo (int)$total; ?> 条 · 日常的碎片</p>
  </div>
</section>

<div class="fo-wrap fo-wrap--single">
  <div class="fo-panel">
    <div class="fo-panel-head">
      <h2 class="fo-panel-title"><?php echo e($life_cat['name']); ?> <span>- <?php echo (int)$total; ?></span></h2>
      <a class="fo-panel-sub" href="<?php echo e(cat_url($life_cat)); ?>">查看分类 →</a>
    </div>

    <div class="fo-life">
      <?php foreach ((array)$groups as $month => $items): ?>
        <div class="fo-life-group">
          <div class="fo-life-month"><?php echo e($month); ?></div>
          <div class="fo-life-items">
            <?php foreach ($items as $it): ?>
              <a class="fo-life-item" href="<?php echo e(post_url($it)); ?>">
                <span class="fo-life-dot"></span>
                <span class="fo-life-date"><?php echo e(format_time($it['created_at'], 'm-d')); ?></span>
                <span class="fo-life-title"><?php echo e($it['title']); ?></span>
                <span class="fo-life-ex"><?php echo e(post_excerpt($it, 60)); ?></span>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
      <?php if (empty($groups)): ?><p class="fo-empty">还没有点滴记录</p><?php endif; ?>
    </div>
  </div>
</div>

<?php include partial_path('footer.php'); ?>