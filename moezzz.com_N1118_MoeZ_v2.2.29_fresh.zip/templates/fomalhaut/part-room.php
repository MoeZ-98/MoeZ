<?php
/**
 * 星辉 · Fomalhaut 模板 · 公共聊天室（2.1.31）
 *
 * 由 companion.php 引入：
 *   - AJAX：companion.php 在输出任何 HTML 之前调用 fo_room_ajax()（弹 JSON 后 exit）
 *   - 页面：fo_room_page() 负责 /companion?room=1 的正文
 *
 * 设计取舍：
 *   - 不新增程序文件、不改核心：消息表在首次发言/拉取时自动 CREATE TABLE IF NOT EXISTS
 *   - 违禁词命中直接拒发，不入库；大小写、全角半角、中间加点/空格都能识别
 *   - 同一 IP 4 秒内只能发一条，防刷屏；每页只拉最近 60 条，之后按 id 增量拉
 *   - 2.1.31：她的回话改由服务端生成并入库（AI 优先，不通就用她自己的口吻），
 *     不再让浏览器代问 chat.php 再带签名回传。原因是这台主机的 XHR POST 全被挡掉
 *     （原生表单能进库、轮询靠 GET 才通），那条二次往返从来没成功过 —— 表现就是「她毫无反应」。
 *     空房间的招呼也改到服务端渲染时入库，零 JS 也能看到她在。
 *   - 2.1.30：陪聊令牌改为「种子 + HMAC」自带校验（不再绑 IP，CDN 下也能通过）；别人发言、
 *     轮询到新消息、进空房间都会触发她；chat.php 不通时用本地口吻兜底，不再静默。
 *   - 2.1.29：版娘也会在这个房间里说话（room_bot_on）：她的话由发言者浏览器向 chat.php 要，
 *     带 hash_hmac 签名回传入库，别人刷新也能看到；12 秒冷却，签名密钥在主题目录 .roomkey
 *   - 2.1.28：发送改为 urlencoded XHR + 解析容错 + 原生表单兜底。
 *     有些主机对 multipart/POST 会返回 HTML（重定向、防火墙页、warning），
 *     前端拿不到 JSON 就只能报「网络不太好」；现在会退回普通表单提交，消息照样落库。
 */

if (!function_exists('fo_room_table')) {
    function fo_room_table()
    {
        return moe_table('room_msgs');
    }
}

/** 表是否已经存在（用一次 SELECT 探测，不依赖 DDL 执行结果） */
if (!function_exists('fo_room_exists')) {
    function fo_room_exists()
    {
        try {
            /* rows() 对空表返回空数组、对缺表抛异常/返回 false，比 row() 更能分辨 */
            $r = rows('SELECT id FROM ' . fo_room_table() . ' LIMIT 1');
            return is_array($r);
        } catch (Throwable $e) {
            return false;
        }
    }
}

/** 建表（幂等，一次请求只试一次；q() 走预处理时 DDL 可能失败，这里补 PDO 直连兜底） */
if (!function_exists('fo_room_ensure')) {
    function fo_room_ensure()
    {
        static $state = null;
        if ($state !== null) return $state;
        $state = false;
        if (fo_room_exists()) { $state = true; return $state; }

        $ddl = 'CREATE TABLE IF NOT EXISTS ' . fo_room_table() . ' ('
            . 'id INT UNSIGNED NOT NULL AUTO_INCREMENT,'
            . 'uid INT UNSIGNED NOT NULL DEFAULT 0,'
            . 'name VARCHAR(40) NOT NULL DEFAULT "",'
            . 'content VARCHAR(500) NOT NULL DEFAULT "",'
            . 'ip VARCHAR(45) NOT NULL DEFAULT "",'
            . 'created_at DATETIME NOT NULL,'
            . 'PRIMARY KEY (id), KEY idx_room_time (created_at)'
            . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';

        if (function_exists('q')) {
            try { q($ddl); } catch (Throwable $e) {}
        }
        if (fo_room_exists()) { $state = true; return $state; }

        /* 兜底：有些封装对 DDL 用预处理语句会报 1295，这里直接拿 PDO 执行 */
        foreach (array('db', 'pdo', 'moe_db', 'dbh') as $fn) {
            if (!function_exists($fn)) continue;
            try {
                $pdo = $fn();
                if (is_object($pdo) && method_exists($pdo, 'exec')) $pdo->exec($ddl);
            } catch (Throwable $e) {}
            if (fo_room_exists()) { $state = true; return $state; }
        }
        return $state;
    }
}

/** 长度与截断：宿主没装 mbstring 时退回 strlen / substr，不至于白屏 */
if (!function_exists('fo_room_len')) {
    function fo_room_len($s)
    {
        return function_exists('mb_strlen') ? mb_strlen((string)$s, 'UTF-8') : strlen((string)$s);
    }
}
if (!function_exists('fo_room_cut')) {
    function fo_room_cut($s, $n)
    {
        $s = (string)$s;
        return function_exists('mb_substr') ? mb_substr($s, 0, (int)$n, 'UTF-8') : substr($s, 0, (int)$n);
    }
}

/**
 * 违禁词表：后台设置优先，留空用内置基础词库 */
if (!function_exists('fo_room_badwords')) {
    function fo_room_badwords()
    {
        $raw = trim((string)fo_opt('room_badwords', ''));
        $list = array();
        if ($raw !== '') {
            foreach (preg_split('/\r\n|\r|\n/', $raw) as $line) {
                $line = trim($line);
                if ($line !== '') $list[] = $line;
            }
        }
        if (empty($list)) {
            $list = array('傻逼', '傻b', '煞笔', '操你', '草泥马', '妈的', 'fuck', 'shit', '赌博', '博彩', '私服', '外挂',
                '代刷', '加微信', '加qq', '二维码', '代开发票', '办证', '枪支', '冰毒', '色情', '约炮', '裸聊',
                '贷款', '刷单', '日结兼职', '开奖', '发票', '网赚', '菠菜');
        }
        return $list;
    }
}

/** 命中就返回那个词，未命中返回空串 */
if (!function_exists('fo_room_filter')) {
    function fo_room_filter($text)
    {
        $t = (string)$text;
        $squeeze = function ($s) {
            /* 去掉空白、零宽字符与常见分隔符，防止「傻 逼」「傻.逼」「傻-逼」绕过 */
            $s = (string)$s;
            /* 全角英数先转半角：ＦＵＣＫ 这类换字体写法也要能抓（不依赖 mbstring） */
            if (function_exists('mb_convert_kana')) {
                $s = mb_convert_kana($s, 'as', 'UTF-8');
            } else {
                static $fwMap = null;
                if ($fwMap === null) {
                    $fwMap = array();
                    for ($i = 0; $i < 95; $i++) {         /* U+FF01..U+FF5E → U+0021..U+007E */
                        $cp = 0xFF01 + $i;
                        $fwMap[chr(0xE0 | ($cp >> 12)) . chr(0x80 | (($cp >> 6) & 0x3F)) . chr(0x80 | ($cp & 0x3F))] = chr(0x21 + $i);
                    }
                }
                $s = strtr($s, $fwMap);
            }
            $s = preg_replace('/[\s\x{200B}\x{200C}\x{200D}\x{FEFF}\x{3000}]+/u', '', $s);
            $s = preg_replace('/[\.\,\-\_\*\|\/\\\\\'"·•。，、！？!?~`＠@]+/u', '', (string)$s);
            return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
        };
        $flat = $squeeze($t);
        foreach (fo_room_badwords() as $w) {
            $w = $squeeze($w);
            if ($w === '') continue;
            $pos = function_exists('mb_strpos') ? mb_strpos($flat, $w, 0, 'UTF-8') : strpos($flat, $w);
            if ($pos !== false) return $w;
        }
        return '';
    }
}

/** 当前访客身份：登录取昵称，未登录用本地记住的名字 */
if (!function_exists('fo_room_me')) {
    function fo_room_me()
    {
        $uid = 0;
        $name = '';
        if (function_exists('current_user')) {
            $u = current_user();
            if (is_array($u) && !empty($u['id'])) {
                $uid = (int)$u['id'];
                $nick = trim((string)(isset($u['nickname']) ? $u['nickname'] : ''));
                $name = $nick !== '' ? $nick : (string)(isset($u['username']) ? $u['username'] : '');
            }
        }
        return array('uid' => $uid, 'name' => $name);
    }
}

/* ---------- 版娘在聊天室里说话（2.1.31） ----------
   2.1.29 / 2.1.30 的做法是「浏览器先问 chat.php，拿到话再带签名回传入库」。
   这条路对主机环境太敏感：XHR 的 POST 被 WAF / CDN 挡掉（这台主机就是这样，
   原生表单能进库、轮询能走 GET，偏偏 XHR POST 全被吞）、chat.php 返回非 JSON、
   令牌对不上，任何一环断掉，屏幕上就是「她毫无反应」。
   2.1.31 把「决定她说什么 + 入库」整体搬到服务端：真人发言落库后，由 PHP 在同一次
   请求里直接生成她的话并入库，不再依赖浏览器的二次往返。
   首选仍是站内 AI（服务端带着访客 cookie 直接调 chat.php），AI 不通时用她自己的
   口吻兜底 —— 宁可朴素，也不能一片安静。 */
if (!function_exists('fo_room_bot_name')) {
    function fo_room_bot_name()
    {
        $n = trim((string)fo_opt('room_bot_name', ''));
        if ($n === '') $n = trim((string)fo_opt('mascot_name', ''));
        return $n !== '' ? $n : '糖糖';
    }
}

/* 她自己的口吻（服务端）：AI 不通时用这些，按话题挑，不是随机复读 */
if (!function_exists('fo_room_lines')) {
    function fo_room_lines()
    {
        return array(
            'greet'  => array('有人来啦，我先给你倒杯水 ✦', '欢迎来坐坐～随便说点什么我都接得住', '嘿，我在呢，想聊什么都行'),
            'hi'     => array('在的在的，欢迎来串门 ✦', '嗨～今天想聊点什么', '来啦来啦，坐这边'),
            'ask'    => array('这个嘛…让我想两秒', '唔，我猜是看心情吧', '我也还在学这个，你教教我', '我倾向另一个答案，你先说说你的'),
            'laugh'  => array('笑死，你这句话我得记下来', '哈哈哈你怎么这么会', '被你逗到了 ✦'),
            'sad'    => array('辛苦啦，先歇一会儿', '抱一下，慢慢来', '这种时候别硬撑，我在。'),
            'praise' => array('被你这么说，我有点飘了', '嘿嘿，听你这么说我很开心', '谢谢你呀，今天心情加分 ✦'),
            'design' => array('那套配色我也喜欢，冷色里带一点暖', '眼力真好，这张挑得不容易', '夜色的图最耐看，一直看也不腻'),
            'post'   => array('那篇我翻了两遍，越看越有点意思', '写到那里的地方我也停了一下', '下次想看你写点更随意的'),
            'tech'   => array('折腾这些最有成就感了', '这个坑我也踩过，慢慢来', '搞定了记得跟我说一声 ✦'),
            'food'   => array('说到这个我就饿了', '配一杯热的更好', '半夜看到这个太犯规了'),
            'night'  => array('这个点还醒着的人，我们是一伙的', '夜里安静，正好说话', '别熬太晚呀'),
            'other'  => array('嗯嗯，我在听', '这个话题我也感兴趣', '说下去说下去', '原来你也在意这个呀', '我记住这句了')
        );
    }
}
if (!function_exists('fo_room_pick')) {
    function fo_room_pick($arr, $not = '')
    {
        $arr = array_values((array)$arr);
        if (!$arr) return '';
        $n = count($arr);
        for ($i = 0; $i < 6; $i++) {
            $v = $arr[mt_rand(0, $n - 1)];
            if ($not === '' || $v !== $not) return $v;
        }
        return $arr[0];
    }
}

/* 她自己的口吻生成：先认话题，再决定用哪一组；偶尔回引对方的话，像真的在听 */
if (!function_exists('fo_room_persona')) {
    function fo_room_persona($text, $greet = false, $lastBot = '')
    {
        $L = fo_room_lines();
        if ($greet) return fo_room_pick($L['greet'], $lastBot);

        $t = trim((string)$text);
        $line = '';

        if ($t === '') return fo_room_pick($L['other'], $lastBot);

        if (preg_match('/^(在吗|在不在|你好|您好|hi|hello|嗨|哈喽|早上好|晚上好|早安|晚安|早啊)/iu', $t)) {
            $line = fo_room_pick($L['hi'], $lastBot);
        } elseif (preg_match('/(哈哈{2,}|嘿嘿|笑死|233|hhh)/iu', $t)) {
            $line = fo_room_pick($L['laugh'], $lastBot);
        } elseif (preg_match('/(难受|累了|好累|不开心|难过|emo|想哭|烦死|崩溃|委屈|孤独|失眠)/iu', $t)) {
            $line = fo_room_pick($L['sad'], $lastBot);
        } elseif (preg_match('/(壁纸|配图|封面|配色|排版|设计|字体|插画)/u', $t)) {
            $line = fo_room_pick($L['design'], $lastBot);
        } elseif (preg_match('/(好看|喜欢|可爱|厉害|牛|太棒|谢谢|辛苦|爱了|绝了|牛啊)/u', $t)) {
            $line = fo_room_pick($L['praise'], $lastBot);
        } elseif (preg_match('/(文章|这篇|博客|更新|读到|看完了|写)/u', $t)) {
            $line = fo_room_pick($L['post'], $lastBot);
        } elseif (preg_match('/(代码|php|服务器|主机|部署|程序|bug|主题|插件|cdn)/iu', $t)) {
            $line = fo_room_pick($L['tech'], $lastBot);
        } elseif (preg_match('/(吃|饿|咖啡|奶茶|宵夜|饭)/u', $t)) {
            $line = fo_room_pick($L['food'], $lastBot);
        } elseif (preg_match('/(凌晨|半夜|熬夜|睡不着|睡了|晚安)/u', $t)) {
            $line = fo_room_pick($L['night'], $lastBot);
        } elseif (preg_match('/[?？]|吗|呢|怎么|为什么|什么|哪里|哪儿|谁|多少|如何|能不能|可不可以/u', $t)) {
            $line = fo_room_pick($L['ask'], $lastBot);
        } else {
            $line = fo_room_pick($L['other'], $lastBot);
        }

        /* 有 35% 的机会把对方的话回引一下，像真的听见了（太长的不引） */
        $len = fo_room_len($t);
        if ($len >= 2 && $len <= 22 && mt_rand(1, 100) <= 35) {
            $echo = fo_room_cut($t, 12);
            $line = '「' . $echo . '」——' . $line;
        }
        return $line;
    }
}

/* 服务端问站内 AI：带访客自己的 cookie 直连 chat.php（浏览器那条路被主机 WAF 挡了） */
if (!function_exists('fo_room_ai_reply')) {
    function fo_room_ai_reply($text)
    {
        $text = trim((string)$text);
        if ($text === '') return '';
        if (!function_exists('curl_init') || !function_exists('base_url')) return '';

        $ask = '你正在站内的公共聊天室里和访客闲聊。有人刚说：' . $text
            . '。你顺着这句接一句，20 字以内，像真人随口搭话：不要反问、不要解释、不要括号、不要表情包、不要自我介绍。';

        $headers = array(
            'X-Requested-With: XMLHttpRequest',
            'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
        );
        if (function_exists('csrf_token')) {
            $t = (string)csrf_token();
            if ($t !== '') $headers[] = 'X-CSRF-Token: ' . $t;
        }
        $cookie = array();
        foreach ((array)$_COOKIE as $k => $v) $cookie[] = $k . '=' . urlencode((string)$v);

        $raw = '';
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, base_url() . 'chat.php');
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array(
                'q'     => $ask,
                'title' => '公共聊天室',
                'url'   => base_url() . 'companion?room=1',
                'cid'   => 'fo-room',
            )));
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 6);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($ch, CURLOPT_MAXREDIRS, 2);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_USERAGENT, 'Fomalhaut-Room/2.1.31');
            if ($cookie) curl_setopt($ch, CURLOPT_COOKIE, implode('; ', $cookie));
            $raw = (string)curl_exec($ch);
            curl_close($ch);
        } catch (Throwable $e) {
            return '';
        }
        if ($raw === '') return '';

        /* 各版本返回形态不一样，挨个认 */
        $t = '';
        $raw = preg_replace('/^\xEF\xBB\xBF/', '', $raw);
        $j = json_decode($raw, true);
        if (is_array($j)) {
            foreach (array('text', 'reply', 'answer', 'content', 'say', 'message', 'msg') as $k) {
                if (isset($j[$k]) && is_string($j[$k]) && trim($j[$k]) !== '') { $t = trim($j[$k]); break; }
            }
            if ($t === '' && isset($j['data']) && is_array($j['data'])) {
                foreach (array('text', 'reply', 'answer', 'content') as $k) {
                    if (isset($j['data'][$k]) && is_string($j['data'][$k]) && trim($j['data'][$k]) !== '') { $t = trim($j['data'][$k]); break; }
                }
            }
            if ($t === '' && isset($j['choices'][0])) {
                $c = $j['choices'][0];
                if (isset($c['message']['content']) && is_string($c['message']['content'])) $t = trim($c['message']['content']);
                elseif (isset($c['content']) && is_string($c['content'])) $t = trim($c['content']);
            }
        }
        if ($t === '' && strpos($raw, '{') === false && strlen($raw) <= 300) {
            $t = trim(preg_replace('/\s+/u', ' ', strip_tags($raw)));
        }
        if ($t === '') return '';

        /* 网关页、错误页、客套开场都不能当她的话 */
        if (preg_match('/^(4\d\d|5\d\d)\b|bad gateway|not found|forbidden|fatal error|parse error|nginx|apache|exception/i', $t)) return '';
        if (preg_match('/(作为.{0,6}(助手|AI|模型)|我可以帮你|有什么可以帮|想了解更多|更多关于|关于页|欢迎关注|抱歉)/u', $t)) return '';
        if (strpos($t, '<') !== false) return '';

        $t = trim(preg_replace('/\s+/u', ' ', $t));
        $bname = fo_room_bot_name();
        $t = preg_replace('/^[「【\[]?' . preg_quote($bname, '/') . '[」】\]]?\s*[:：]\s*/u', '', $t);
        $t = trim((string)$t, "「」『』\"' ");
        if (fo_room_len($t) > 60) $t = fo_room_cut($t, 60);
        return trim((string)$t);
    }
}

/* 她的话入库：签名早已不需要（生成在服务端），这里只管清洗、限长、违禁词、冷却 */
if (!function_exists('fo_room_bot_store')) {
    function fo_room_bot_store($text, $greet = false)
    {
        $bname = fo_room_bot_name();
        $text = strip_tags((string)$text);
        $text = trim(preg_replace('/\s+/u', ' ', $text));
        $text = preg_replace('/^[「【\[]?' . preg_quote($bname, '/') . '[」】\]]?\s*[:：]\s*/u', '', $text);
        $text = trim((string)$text, "「」『』\"' ");
        if ($text === '') return array('ok' => false, 'msg' => 'empty');
        if (fo_room_len($text) > 160) $text = fo_room_cut($text, 160);
        if (fo_room_filter($text) !== '') return array('ok' => false, 'msg' => 'filtered');

        if (!$greet) {
            try {
                $last = row('SELECT UNIX_TIMESTAMP(created_at) AS ts FROM ' . fo_room_table()
                    . " WHERE ip = 'bot' ORDER BY id DESC LIMIT 1");
                if ($last && (time() - (int)$last['ts']) < 6) return array('ok' => true, 'skip' => 'cool');
            } catch (Throwable $e) {
            }
        }

        $botIp = $greet ? 'bot-greet' : 'bot';
        $bid = 0;
        try {
            q('INSERT INTO ' . fo_room_table() . ' (uid, name, content, ip, created_at) VALUES (?,?,?,?,?)',
                array(0, $bname, $text, $botIp, date('Y-m-d H:i:s')));
            if (function_exists('last_insert_id')) $bid = (int)last_insert_id();
        } catch (Throwable $e) {
            return array('ok' => false, 'msg' => 'db');
        }
        if (!$bid) {
            try {
                $r = row('SELECT id FROM ' . fo_room_table() . " WHERE ip = '" . $botIp . "' ORDER BY id DESC LIMIT 1");
                $bid = $r ? (int)$r['id'] : 0;
            } catch (Throwable $e) {
            }
        }
        return array('ok' => true, 'item' => array(
            'id' => $bid, 'uid' => 0, 'name' => $bname, 'text' => $text, 'ts' => time(), 'mine' => false, 'bot' => true,
        ));
    }
}

/* 决定她说什么：AI 优先，不通就用她自己的口吻；结果里带 why 方便排查 */
if (!function_exists('fo_room_reply')) {
    function fo_room_reply($text, $greet = false, $fast = false)
    {
        if (!fo_on('room_bot_on', '1')) return array('ok' => false, 'msg' => 'off');
        $line = '';
        $why = 'persona';
        $lastBot = '';
        try {
            $lb = row('SELECT content FROM ' . fo_room_table() . " WHERE ip = 'bot' ORDER BY id DESC LIMIT 1");
            if (is_array($lb) && isset($lb['content'])) $lastBot = (string)$lb['content'];
        } catch (Throwable $e) {
        }
        if (!$greet && !$fast) {
            $line = fo_room_ai_reply($text);
            if ($line !== '') $why = 'ai';
        }
        if ($line === '') $line = fo_room_persona($text, $greet, $lastBot);
        $r = fo_room_bot_store($line, $greet);
        $r['why'] = $why;
        return $r;
    }
}

/* 空房间：她先打个招呼，别让人进来对着白板（服务端直接入库，不依赖 JS） */
if (!function_exists('fo_room_greet_if_empty')) {
    function fo_room_greet_if_empty()
    {
        if (!fo_on('room_bot_on', '1')) return;
        try {
            $c = row('SELECT COUNT(*) AS c FROM ' . fo_room_table());
        } catch (Throwable $e) {
            return;
        }
        if (!$c || !isset($c['c']) || (int)$c['c'] > 0) return;
        fo_room_reply('', true);
    }
}

/**
 * 发言入库：AJAX 与原生表单共用，返回 array(ok, msg, item)
 * 顺序：清洗 → 长度 → 违禁词 → 防刷屏 → 入库
 */
if (!function_exists('fo_room_store')) {
    function fo_room_store($text, $me, $ip, $nameIn)
    {
        $text = strip_tags((string)$text);
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]+/u', '', $text);
        $text = trim(preg_replace('/\s+/u', ' ', (string)$text));
        if ($text === '') return array('ok' => false, 'msg' => '说点什么吧');
        if (fo_room_len($text) > 240) $text = fo_room_cut($text, 240);

        $hit = fo_room_filter($text);
        if ($hit !== '') return array('ok' => false, 'msg' => '这句话里有不合规的词，换种说法吧～');

        /* 防刷屏：同 IP 4 秒一条 */
        try {
            $last = row('SELECT UNIX_TIMESTAMP(created_at) AS ts FROM ' . fo_room_table()
                . " WHERE ip = '" . addslashes($ip) . "' ORDER BY id DESC LIMIT 1");
            if ($last && (time() - (int)$last['ts']) < 4) {
                return array('ok' => false, 'msg' => '慢一点，喝口水再发～');
            }
        } catch (Throwable $e) {
        }

        $name = trim((string)$me['name']);
        if ($name === '') $name = trim(strip_tags((string)$nameIn));
        if ($name === '') $name = '路过的旅行者';
        $name = fo_room_cut(preg_replace('/\s+/u', ' ', $name), 20);

        $id = 0;
        try {
            q('INSERT INTO ' . fo_room_table() . ' (uid, name, content, ip, created_at) VALUES (?,?,?,?,?)',
                array((int)$me['uid'], $name, $text, $ip, date('Y-m-d H:i:s')));
            if (function_exists('last_insert_id')) $id = (int)last_insert_id();
        } catch (Throwable $e) {
            return array('ok' => false, 'msg' => '发送失败，稍后再试');
        }
        if (!$id) {
            try {
                $r = row('SELECT id FROM ' . fo_room_table() . " WHERE ip = '" . addslashes($ip) . "' ORDER BY id DESC LIMIT 1");
                $id = $r ? (int)$r['id'] : 0;
            } catch (Throwable $e) {
            }
        }
        return array(
            'ok'   => true,
            'msg'  => '发出去了',
            'item' => array('id' => $id, 'uid' => (int)$me['uid'], 'name' => $name, 'text' => $text, 'ts' => time(), 'mine' => true),
        );
    }
}

/** AJAX：pull / send。必须在输出 HTML 前调用 */
if (!function_exists('fo_room_ajax')) {
    function fo_room_ajax()
    {
        while (ob_get_level() > 0) { ob_end_clean(); }
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        header('X-Robots-Tag: noindex');

        $src = $_POST;
        if (isset($_GET['fo_room_action'])) $src = array_merge($_GET, $_POST);
        $act = isset($src['fo_room_action']) ? (string)$src['fo_room_action'] : '';

        $reply = function ($arr) {
            $out = json_encode($arr, JSON_UNESCAPED_UNICODE);
            if ($out === false) $out = '{"ok":false,"msg":"编码失败"}';
            echo $out;
            exit;
        };

        if (!fo_room_ensure()) $reply(array('ok' => false, 'msg' => '聊天室暂时不可用（消息表创建失败），请检查数据库建表权限'));

        $me = fo_room_me();
        $ip = isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '';

        if ($act === 'pull') {
            $after = max(0, (int)(isset($src['after']) ? $src['after'] : 0));
            $list = array();
            try {
                if ($after > 0) {
                    $list = rows('SELECT id, uid, name, content, ip, UNIX_TIMESTAMP(created_at) AS ts FROM ' . fo_room_table()
                        . ' WHERE id > ' . $after . ' ORDER BY id ASC LIMIT 80');
                } else {
                    $list = rows('SELECT id, uid, name, content, ip, UNIX_TIMESTAMP(created_at) AS ts FROM ' . fo_room_table()
                        . ' ORDER BY id DESC LIMIT 60');
                    $list = array_reverse((array)$list);
                }
            } catch (Throwable $e) {
                $reply(array('ok' => false, 'msg' => '读取失败'));
            }
            $out = array();
            foreach ((array)$list as $r) {
                $out[] = array(
                    'id'   => (int)$r['id'],
                    'uid'  => (int)$r['uid'],
                    'name' => (string)$r['name'],
                    'text' => (string)$r['content'],
                    'ts'   => (int)$r['ts'],
                    'mine' => ($me['uid'] > 0 && (int)$r['uid'] === $me['uid']),
                    'bot'  => (isset($r['ip']) && strpos((string)$r['ip'], 'bot') === 0),
                );
            }
            $reply(array('ok' => true, 'list' => $out, 'me' => $me));
        }

        if ($act === 'send') {
            $text = isset($src['text']) ? (string)$src['text'] : (isset($src['fo_room_text']) ? (string)$src['fo_room_text'] : '');
            $nameIn = isset($src['name']) ? (string)$src['name'] : (isset($src['fo_room_name']) ? (string)$src['fo_room_name'] : '');
            $r = fo_room_store($text, $me, $ip, $nameIn);
            if (empty($r['ok'])) $reply(array('ok' => false, 'msg' => $r['msg']));
            /* 先把我这句回给页面，她的话由紧随其后的 reply 请求生成（不让我这边等 AI） */
            $reply(array('ok' => true, 'item' => $r['item'], 'bot_on' => fo_on('room_bot_on', '1') ? 1 : 0));
        }

        if ($act === 'reply') {
            /* 她说不说、说什么，全在服务端决定（2.1.31）。
               条件只有一个：房间里最新一条是真人刚说的话。这样既不会被反复调用刷屏，
               也不依赖浏览器去 chat.php 绕一圈 —— 那条路在这台主机上根本走不通。 */
            $after = max(0, (int)(isset($src['after']) ? $src['after'] : 0));
            $text = isset($src['text']) ? (string)$src['text'] : '';
            $newest = null;
            try {
                $newest = row('SELECT id, name, content, ip, UNIX_TIMESTAMP(created_at) AS ts FROM ' . fo_room_table()
                    . ' ORDER BY id DESC LIMIT 1');
            } catch (Throwable $e) {
            }
            if (!$newest) $reply(array('ok' => false, 'msg' => 'empty-room'));
            if (strpos((string)$newest['ip'], 'bot') === 0) $reply(array('ok' => true, 'skip' => 'last-is-bot'));
            if ((time() - (int)$newest['ts']) > 180) $reply(array('ok' => true, 'skip' => 'stale'));
            if ($text === '') $text = (string)$newest['content'];
            $r = fo_room_reply($text);
            if (empty($r['ok'])) $reply(array('ok' => false, 'msg' => isset($r['msg']) ? $r['msg'] : 'fail'));
            if (!empty($r['skip'])) $reply(array('ok' => true, 'skip' => $r['skip']));
            $reply(array('ok' => true, 'item' => $r['item'], 'why' => isset($r['why']) ? $r['why'] : ''));
        }

        $reply(array('ok' => false, 'msg' => '未知操作'));
    }
}

/** 聊天室正文（已由 companion.php 输出 header） */
if (!function_exists('fo_room_page')) {
    function fo_room_page()
    {
        $me = fo_room_me();
        $on = fo_on('room_on', '1');
        $self = base_url() . 'companion?room=1';
        $ip = isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '';

        /* 原生表单兜底：不带 JS 也能发言（AJAX 拿到非 JSON 响应时前端会自动走这条路） */
        $notice = array('type' => '', 'text' => '');
        if ($on && isset($_SERVER['REQUEST_METHOD']) && strtoupper((string)$_SERVER['REQUEST_METHOD']) === 'POST'
            && isset($_POST['fo_room_native'])) {
            if (!fo_room_ensure()) {
                $notice = array('type' => 'warn', 'text' => '聊天室初始化失败：消息表没建成');
            } else {
                $nativeText = isset($_POST['fo_room_text']) ? (string)$_POST['fo_room_text'] : '';
                $r = fo_room_store($nativeText, $me, $ip, isset($_POST['fo_room_name']) ? (string)$_POST['fo_room_name'] : '');
                $notice = array('type' => empty($r['ok']) ? 'warn' : 'ok', 'text' => empty($r['ok']) ? $r['msg'] : '发出去了 ✦');
                if (!empty($r['ok'])) {
                    /* AJAX 的 POST 被主机挡掉时，走的就是这条路。整页都在刷新了，
                       索性把她的回话也在这里生成入库，刷新完就能看到，不用等 JS。 */
                    try {
                        fo_room_reply($nativeText, false, true);
                    } catch (Throwable $e) {
                    }
                }
            }
        }
        $csrf = function_exists('csrf_token') ? csrf_token() : '';
        /* 版娘进聊天室：开关 / 名字。她的话现在是服务端生成的，页面不需要签名与 chat 地址 */
        $bot_on = fo_on('room_bot_on', '1');
        $bot_name = fo_room_bot_name();
        if ($on && $bot_on && function_exists('fo_room_greet_if_empty')) {
            try {
                fo_room_greet_if_empty();
            } catch (Throwable $e) {
            }
        }
        ?>
<div class="fo-wrap fo-wrap--single fo-wrap--nohero">
  <div class="fo-fr-panel fo-room">
    <header class="fo-fr-head">
      <div class="fo-fr-title-row">
        <span class="fo-fr-ico" aria-hidden="true">✧</span>
        <h1>公共聊天室</h1>
      </div>
      <p class="fo-fr-desc">大家随便聊，聊文章、聊壁纸、聊今天心情都行。广告、辱骂和违法内容会被直接拦下来。</p>
      <div class="fo-room-tabs">
        <a class="fo-room-tab" href="<?php echo e(base_url() . 'companion'); ?>">小屋</a>
        <a class="fo-room-tab is-on" href="<?php echo e($self); ?>" aria-current="page">聊天室</a>
      </div>
    </header>

    <?php if (!$on): ?>
      <p class="fo-empty">聊天室暂时关闭了，去小屋看看吧。</p>
    <?php elseif (!fo_room_ensure()): ?>
      <p class="fo-empty">聊天室初始化失败：消息表没建成，检查一下数据库账号有没有建表权限。</p>
    <?php else: ?>
    <div class="fo-room-box" id="fo-room" data-api="<?php echo e($self); ?>"
         data-bot="<?php echo $bot_on ? '1' : '0'; ?>"
         data-bot-name="<?php echo e($bot_name); ?>">
      <div class="fo-room-msgs" id="fo-room-msgs" role="log" aria-live="polite"></div>
      <form class="fo-room-form" id="fo-room-form" method="post" action="<?php echo e($self); ?>" autocomplete="off">
        <input type="hidden" name="fo_room_native" id="fo-room-nf" value="0">
        <input type="hidden" name="fo_csrf" value="<?php echo e($csrf); ?>">
        <?php if ($me['uid'] === 0): ?>
          <input type="text" class="fo-room-name" id="fo-room-name" name="fo_room_name" maxlength="20" placeholder="昵称" aria-label="昵称">
        <?php else: ?>
          <span class="fo-room-name fo-room-name--me" title="已登录，用站内昵称发言"><?php echo e($me['name']); ?></span>
        <?php endif; ?>
        <input type="text" class="fo-room-input" id="fo-room-input" name="fo_room_text" maxlength="240" placeholder="说点什么…（Enter 发送）" aria-label="发言内容">
        <button type="submit" class="fo-room-send">发送</button>
      </form>
      <p class="fo-room-tip<?php echo $notice['type'] === 'warn' ? ' is-warn' : ($notice['type'] === 'ok' ? ' is-ok' : ''); ?>" id="fo-room-tip"><?php
        echo $notice['text'] !== '' ? e($notice['text']) : '提倡友善交流；违禁词会被拦下，不会出现在这里。';
      ?></p>
    </div>
    <script>
    (function () {
      var box = document.getElementById('fo-room');
      if (!box) return;
      var listEl = document.getElementById('fo-room-msgs');
      var form = document.getElementById('fo-room-form');
      var input = document.getElementById('fo-room-input');
      var nameEl = document.getElementById('fo-room-name');
      var tip = document.getElementById('fo-room-tip');
      var nf = document.getElementById('fo-room-nf');
      var api = box.getAttribute('data-api');
      var last = 0, busy = false, timer = null, meUid = 0, netFails = 0;
      /* 这台主机会把 XHR 的 POST 吞掉（返回 502 页面）。一旦发现，之后所有请求直接走 GET，
         省掉每次「先失败的 POST」那一个来回。 */
      var postBlocked = false;
      /* 版娘进聊天室 */
      var botOn = box.getAttribute('data-bot') === '1';
      var botName = box.getAttribute('data-bot-name') || '糖糖';

      /* 昵称记在本地，下次来还是自己 */
      try {
        if (nameEl && nameEl.tagName === 'INPUT') {
          var savedName = localStorage.getItem('fo_room_name') || '';
          if (savedName) nameEl.value = savedName;
          nameEl.addEventListener('change', function () { localStorage.setItem('fo_room_name', nameEl.value.trim()); });
        }
      } catch (e) {}

      function ago(ts) {
        var d = Math.floor(Date.now() / 1000) - ts;
        if (d < 60) return '刚刚';
        if (d < 3600) return Math.floor(d / 60) + ' 分钟前';
        if (d < 86400) return Math.floor(d / 3600) + ' 小时前';
        return Math.floor(d / 86400) + ' 天前';
      }
      function hue(uid, name) {
        var s = String(name || ''), h = 0;
        for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) % 360;
        return h;
      }
      function nearBottom() { return listEl.scrollHeight - listEl.scrollTop - listEl.clientHeight < 60; }
      function scrollEnd(force) { if (force || nearBottom()) listEl.scrollTop = listEl.scrollHeight; }

      /* 服务器有时会先吐一段 HTML（重定向、warning、防火墙页），
         这里剥到第一个 { 到最后一个 }，能解析就解析，不能就算了 */
      function parseJSON(t) {
        if (!t) return null;
        t = String(t).replace(/^\uFEFF/, '').trim();
        var i = t.indexOf('{'), j = t.lastIndexOf('}');
        if (i < 0 || j <= i) return null;
        try { return JSON.parse(t.slice(i, j + 1)); } catch (e) { return null; }
      }
      function post(fields, ok, fail, useGet) {
        if (postBlocked) useGet = true;
        var pairs = [];
        for (var k in fields) { if (Object.prototype.hasOwnProperty.call(fields, k)) pairs.push(encodeURIComponent(k) + '=' + encodeURIComponent(fields[k])); }
        var body = pairs.join('&');
        var xhr = new XMLHttpRequest();
        var url = api;
        var method = 'POST';
        if (useGet) { method = 'GET'; url = api + (api.indexOf('?') < 0 ? '?' : '&') + body; body = null; }
        try { xhr.open(method, url, true); } catch (e) { fail('open'); return; }
        if (!useGet) xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        xhr.timeout = 15000;
        xhr.onload = function () {
          var d = parseJSON(xhr.responseText);
          if (d) { ok(d, xhr.responseText); return; }
          fail(xhr.status === 0 ? 'net' : 'body', xhr.responseText);
        };
        xhr.onerror = xhr.ontimeout = function () { fail('net', ''); };
        xhr.send(body);
      }

      function bubble(m) {
        var row = document.createElement('div');
        row.className = 'fo-room-msg' + (m.mine ? ' is-me' : '') + (m.bot ? ' is-bot' : '');
        row.setAttribute('data-id', m.id);
        var meta = document.createElement('div');
        meta.className = 'fo-room-meta';
        var nm = document.createElement('b');
        nm.textContent = m.name || '路过的旅行者';
        nm.style.color = 'hsl(' + hue(m.uid, m.name) + ',45%,48%)';
        var tm = document.createElement('span');
        tm.textContent = ago(m.ts);
        meta.appendChild(nm); meta.appendChild(tm);
        var body = document.createElement('div');
        body.className = 'fo-room-text';
        body.textContent = m.text;
        row.appendChild(meta);
        row.appendChild(body);
        return row;
      }
      function append(items) {
        var stick = nearBottom();
        items.forEach(function (m) {
          if (m.id && listEl.querySelector('[data-id="' + m.id + '"]')) return;
          listEl.appendChild(bubble(m));
          if (m.id > last) last = m.id;
        });
        scrollEnd(stick);
      }
      function notice(text, kind) {
        if (!tip) return;
        tip.textContent = text;
        tip.classList.remove('is-warn', 'is-ok');
        tip.classList.add(kind === 'ok' ? 'is-ok' : 'is-warn');
        if (kind === 'ok') setTimeout(function () {
          if (tip && tip.classList.contains('is-ok')) {
            tip.classList.remove('is-ok');
            tip.textContent = '提倡友善交流；违禁词会被拦下，不会出现在这里。';
          }
        }, 2200);
      }
      function render(rows, first) {
        if (first) { listEl.innerHTML = ''; last = 0; }
        if (rows && rows.length) { append(rows); return; }
        if (first) {
          var ph = document.createElement('p');
          ph.className = 'fo-room-empty';
          ph.textContent = '还没有人说话，来当第一个吧 ✦';
          listEl.appendChild(ph);
        }
      }
      function pull(first, viaGet) {
        post({ fo_room_action: 'pull', after: first ? 0 : last }, function (d) {
          netFails = 0;
          if (!d || !d.ok) { if (first) notice((d && d.msg) || '聊天室暂时连不上'); return; }
          if (d.me) meUid = d.me.uid || 0;
          var newest = (d.list && d.list.length) ? d.list[d.list.length - 1] : null;
          render(d.list, first);
          if (first) {
            scrollEnd(true);
            /* 刚提交完就被刷新回来的（原生表单那条路）：她想接就接一句 */
            if (newest && !newest.bot && (Math.floor(Date.now() / 1000) - newest.ts) < 60) {
              askReply(newest.id, newest.text);
            } else if (newest) {
              replied = Math.max(replied, newest.id || 0);
            }
          } else if (newest && !newest.bot) {
            /* 别人说话，她也接一句（服务端会判断要不要真开口） */
            askReply(newest.id, newest.text);
          }
        }, function (how, raw) {
          /* POST 不通时改用 GET 再试一次（部分主机只放行 GET），并记住这个结论 */
          if (!viaGet) { postBlocked = true; setTimeout(function () { pull(first, true); }, 400); return; }
          netFails++;
          if (first) {
            var m = '聊天室暂时连不上，稍后会自动重试';
            if (raw && /Fatal error|Parse error|Warning/i.test(raw)) m = '服务器返回了错误页，稍后会自动重试';
            notice(m);
          }
        }, viaGet);
      }
      function nativeSend() {
        if (!form || !nf) return;
        nf.value = '1';
        form.submit();          /* 走普通 POST，页面刷新后消息已经落库 */
      }
      function sent(d, text) {
        busy = false;
        if (!d || !d.ok) { notice((d && d.msg) || '发送失败'); return; }
        var ph = listEl.querySelector('.fo-room-empty');
        if (ph) ph.remove();
        append([d.item]);
        scrollEnd(true);
        if (input) input.value = '';
        /* 我话音刚落，就去问她要不要接一句（服务端决定说什么） */
        askReply(d.item && d.item.id, text);
      }
      function send() {
        var text = (input && input.value || '').trim();
        if (!text || busy) return;
        busy = true;
        var fields = { fo_room_action: 'send', text: text };
        if (nameEl && nameEl.tagName === 'INPUT') fields.name = nameEl.value.trim();
        post(fields, function (d) { sent(d, text); }, function (how, raw) {
          if (how === 'body' && raw && /不合规|慢一点|说点什么/.test(raw)) { busy = false; notice('发送失败'); return; }
          /* POST 被主机挡掉时（XHR 的 POST 常被 WAF 吞掉）先改走 GET，还不行才退回原生表单 */
          postBlocked = true;
          post(fields, function (d) { sent(d, text); }, function () { busy = false; nativeSend(); }, true);
        }, false);
      }
      /* ---- 版娘在聊天室里说话（2.1.31）----
         她的回话由服务端生成并入库，页面只负责问一句「她要不要接」（action=reply）。
         2.1.29 / 2.1.30 是让浏览器代问 chat.php、再带签名回传，中间任何一环被主机挡掉
         就一声不吭；现在这条链只剩一个请求，POST 不通自动改 GET。 */
      var typingEl = null, botBusy = false, botCool = 0, replied = 0;

      /* 「正在输入」三点：她说之前先亮一下，别让人以为卡住了 */
      function typingOn() {
        if (typingEl || !botOn) return;
        var row = document.createElement('div');
        row.className = 'fo-room-msg is-bot fo-room-typing';
        var meta = document.createElement('div');
        meta.className = 'fo-room-meta';
        var b = document.createElement('b');
        b.textContent = botName;
        var sp = document.createElement('span');
        sp.textContent = '正在输入';
        meta.appendChild(b); meta.appendChild(sp);
        var bd = document.createElement('div');
        bd.className = 'fo-room-text';
        bd.innerHTML = '<i></i><i></i><i></i>';
        row.appendChild(meta); row.appendChild(bd);
        listEl.appendChild(row);
        typingEl = row;
        scrollEnd(true);
      }
      function typingOff() {
        if (typingEl && typingEl.parentNode) typingEl.parentNode.removeChild(typingEl);
        typingEl = null;
      }

      function askReply(id, text) {
        if (!botOn || !id) return;
        if (id <= replied) return;
        if (botBusy) return;
        var now = Date.now();
        if (now - botCool < 6000) return;      /* 6 秒内只问一次，别刷屏也别烧 token */
        botBusy = true;
        botCool = now;
        replied = id;
        var fields = { fo_room_action: 'reply', after: id, text: String(text || '').slice(0, 240) };
        var tp = setTimeout(typingOn, 320);
        function done(d) {
          clearTimeout(tp); typingOff(); botBusy = false;
          if (d && d.ok && d.item) {
            var ph = listEl.querySelector('.fo-room-empty');
            if (ph) ph.remove();
            append([d.item]);
            scrollEnd(true);
            if (d.item.id > replied) replied = d.item.id;
            try { console.info('[聊天室] 她接了一句（' + (d.why === 'ai' ? 'AI' : '她自己的口吻') + '）'); } catch (e) {}
          } else if (d && d.skip) {
            try { console.info('[聊天室] 她这次没说：' + d.skip); } catch (e) {}
          }
        }
        function bad(how) {
          clearTimeout(tp); typingOff(); botBusy = false;
          try { console.info('[聊天室] 她这次没接上：' + how); } catch (e) {}
        }
        post(fields, done, function (how) {
          /* POST 发不出去（这台主机就是这样）→ 改用 GET 再问一次，并记住 */
          postBlocked = true;
          post(fields, done, bad, true);
        }, false);
      }

      if (form) form.addEventListener('submit', function (e) { e.preventDefault(); send(); });
      pull(true);
      timer = setInterval(function () {
        if (document.hidden || busy || netFails > 3) return;
        pull(false);
      }, 4000);
      document.addEventListener('visibilitychange', function () { if (!document.hidden) { netFails = 0; pull(false); } });
      window.addEventListener('pagehide', function () { if (timer) clearInterval(timer); });
    })();
    </script>
    <?php endif; ?>
  </div>
</div>
        <?php
    }
}
