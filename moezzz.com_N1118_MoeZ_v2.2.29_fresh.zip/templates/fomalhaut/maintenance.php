<?php
/**
 * 星辉 · Fomalhaut 模板 · 站点维护页（独立渲染，不依赖公共变量）
 */
header('Content-Type: text/html; charset=utf-8');
$fo_name = function_exists('setting') ? setting('site_name', 'Moe Home') : 'Moe Home';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>站点维护中 · <?php echo e($fo_name); ?></title>
<style>
html,body{margin:0;height:100%}
body{display:flex;align-items:center;justify-content:center;text-align:center;color:#2b3a4a;
  font-family:"PingFang SC","Microsoft YaHei",system-ui,sans-serif;
  background:radial-gradient(900px 500px at 20% 10%,#dff3f1 0%,transparent 60%),
             radial-gradient(700px 500px at 85% 20%,#e2ecfb 0%,transparent 55%),
             linear-gradient(160deg,#eef4f8,#e7f0f4 55%,#f3f7fa)}
.box{padding:44px}
.star{font-size:56px;color:#35b8ab;display:block;animation:float 3s ease-in-out infinite}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
h1{font-size:26px;margin:16px 0 10px;letter-spacing:1px}
p{color:#7d8fa1;font-size:14px;margin:0}
</style>
</head>
<body>
<div class="box">
  <span class="star">✦</span>
  <h1>小站正在维护中…</h1>
  <p><?php echo e($fo_name); ?> 稍后回来，星星正在重新排列～</p>
</div>
</body>
</html>