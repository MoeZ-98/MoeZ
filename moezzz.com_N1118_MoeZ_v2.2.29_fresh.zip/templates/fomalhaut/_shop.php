<?php
/**
 * 星辉 · Fomalhaut · 积分 / 签到 / 商城 / 下载 —— 兼容层（2.1.0 起）
 * ------------------------------------------------------------------
 * 2.1.0 把这些功能搬进了程序核心（includes/points.php），因为前台 /user
 * 由核心的 includes/user.php 渲染，模板里的用户中心页面永远拿不到路由。
 *
 * 主题里原有的 shop.php / downloads.php / user.php / _signin.php /
 * _points.php / _download.php 仍按老函数名调用，本文件把 fo_* 一次性
 * 代理到核心的 moe_pt_*，于是：
 *   · 只有一份数据（moe_pt_* 表），不会出现主题与用户中心各记一套积分；
 *   · 老页面 / 老书签 / 老链接继续可用；
 *   · 换模板、换主题都不影响数据。
 *
 * 极简原则：这里只做转发，不写任何业务逻辑，避免两处规则不一致。
 */

if (!defined('FO_SHOP_LOADED')) define('FO_SHOP_LOADED', true);

if (!function_exists('fo_opt') && is_file(__DIR__ . '/_lib.php')) {
    require_once __DIR__ . '/_lib.php';
}

/** 老表名 → 核心表名 */
function fo_shop_table($name)
{
    $map = array(
        'points'     => 'pt_points',
        'points_log' => 'pt_log',
        'signin'     => 'pt_sign',
        'sign'       => 'pt_sign',
        'goods'      => 'pt_goods',
        'orders'     => 'pt_orders',
        'downloads'  => 'pt_downloads',
    );
    $t = isset($map[$name]) ? $map[$name] : 'pt_' . $name;
    return moe_table($t);
}

/** 数据表是否就绪（核心自动建表） */
function fo_shop_ready()
{
    return function_exists('moe_pt_ready') ? moe_pt_ready() : false;
}

function fo_shop_uid()
{
    return function_exists('moe_pt_uid') ? moe_pt_uid() : 0;
}

function fo_points_name()
{
    // 主题设置里的名称优先（站长在模板设置里改过就继续沿用），否则用核心设置
    $n = trim((string)fo_opt('points_name', ''));
    if ($n !== '') return $n;
    return function_exists('moe_pt_name') ? moe_pt_name() : '积分';
}

function fo_points_row($uid)
{
    return moe_pt_row($uid);
}

function fo_points_balance($uid)
{
    return function_exists('moe_pt_balance') ? moe_pt_balance($uid) : 0;
}

/** 兼容老签名：fo_points_add($uid, $amount, $type, $note) */
function fo_points_add($uid, $amount, $type = 'admin', $note = '')
{
    return moe_pt_add($uid, $amount, $type, $note);
}

function fo_signin_status($uid)
{
    return moe_pt_sign_status($uid);
}

function fo_signin_do($uid)
{
    return moe_pt_sign_do($uid);
}

function fo_goods_list($onlyOn = true)
{
    return moe_pt_goods($onlyOn);
}

function fo_goods_get($id)
{
    return moe_pt_good($id);
}

function fo_user_orders($uid)
{
    return moe_pt_orders($uid);
}

function fo_has_bought($uid, $gid)
{
    return moe_pt_has_bought($uid, $gid);
}

function fo_order_buy($uid, $gid)
{
    return moe_pt_buy($uid, $gid);
}

/** 老接口只返回地址字符串，未兑换返回 null */
function fo_download_url($uid, $gid)
{
    $t = moe_pt_download_target($uid, $gid);
    if (!$t) return null;
    return $t['type'] === 'remote' ? (string)$t['url'] : (string)$t['url'];
}

function fo_download_record($uid, $gid)
{
    return moe_pt_download_record($uid, $gid);
}

function fo_points_logs($uid, $limit = 10)
{
    return moe_pt_logs($uid, $limit);
}

function fo_comment_points_left($uid)
{
    return function_exists('moe_pt_comment_left') ? moe_pt_comment_left($uid) : 0;
}

/**
 * 评论得分：老调用会传「评论 #123」这样的备注，
 * 这里解析出评论 id，交给核心做去重与每日上限判断。
 */
function fo_comment_points_grant($uid, $note = '发表评论')
{
    $cid = 0;
    if (preg_match('/#\s*(\d+)/', (string)$note, $m)) $cid = (int)$m[1];
    return moe_pt_comment_grant($uid, $cid);
}

function fo_goods_save($data, $id = 0)
{
    return moe_pt_goods_save($data, $id);
}

function fo_goods_delete($id)
{
    return moe_pt_goods_delete($id);
}
