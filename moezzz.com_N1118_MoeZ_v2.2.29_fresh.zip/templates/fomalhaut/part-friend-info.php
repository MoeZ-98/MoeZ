<?php
/**
 * 星辉 · Fomalhaut 模板 · 友链信息 + 申请说明（全站非首页复用组件）
 *
 * 三块内容：
 *   1) 友链信息卡：站点名称 / 描述 / 链接 / 头像链接 / 主页截图，每项可一键复制
 *   2) 申请友链：三步说明 + 可复制的留言模板
 *   3) 注意事项：每行一条，支持「标题：内容」自动加粗标题
 *
 * 可用变量：$site
 * 后台设置：friend_shot（主页截图）、friend_rules（注意事项）、friend_apply_note（申请提示）
 */
$GLOBALS['fo_friend_info_done'] = true;

$fo_fi_name = trim((string)$site['name']);
$fo_fi_desc = trim((string)$site['desc']);
if ($fo_fi_desc === '') $fo_fi_desc = trim((string)$site['signature']);
if ($fo_fi_desc === '') $fo_fi_desc = trim((string)$site['sub']);
$fo_fi_url = base_url();
$fo_fi_avatar = !empty($site['avatar']) ? media_url($site['avatar']) : theme_url('assets/avatar.svg');
$fo_fi_shot = trim(fo_opt('friend_shot', ''));
if ($fo_fi_shot !== '') $fo_fi_shot = media_url($fo_fi_shot);
if ($fo_fi_shot === '') $fo_fi_shot = theme_url('assets/hero.svg');

$fo_fi_note = trim(fo_opt('friend_apply_note', ''));
if ($fo_fi_note === '') $fo_fi_note = '可按下方模板留言，也可以使用您自己的格式。站长看到后会尽快回复，是否添加由站长决定。';

$fo_fi_rules = array();
foreach (preg_split('/\r\n|\r|\n/', (string)fo_opt('friend_rules', '')) as $line) {
    $line = trim($line);
    if ($line !== '') $fo_fi_rules[] = $line;
}
if (empty($fo_fi_rules)) {
    $fo_fi_rules = array(
        '互换原则：请先将本站添加到您的友链页面，确认后会添加您的友链',
        '链接维护：友链网站长期无法访问或内容违规，将会被移除',
        '内容要求：内容积极向上，不含有任何色情/反动/暴力等违法违规内容',
        '站点要求：支持 HTTPS，以原创内容为主，能够正常访问且有持续更新',
    );
}

$fo_fi_apply = trim(fo_opt('link_apply', ''));

$fo_fi_tpl = "备注：\n站点名称：\n站点描述：\n站点链接：\n头像链接：";

/* 复制按钮图标 */
$fo_fi_copy_icon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2.4"></rect><path d="M15 5.6A2.6 2.6 0 0 0 12.4 3H6.6A2.6 2.6 0 0 0 4 5.6v5.8A2.6 2.6 0 0 0 6.6 14"></path></svg>';
?>
<section class="fo-fi-wrap" id="fo-fri-apply">
  <div class="fo-fi-grid">

    <article class="fo-fi-card fo-fi-info">
      <header class="fo-fi-head">
        <span class="fo-fi-ava">
          <img src="<?php echo e($fo_fi_avatar); ?>" alt="<?php echo e($fo_fi_name); ?>" loading="lazy">
          <i aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.8 10 18l9-10"></path></svg></i>
        </span>
        <div class="fo-fi-head-text">
          <h2><?php echo e($fo_fi_name); ?></h2>
          <p><?php echo e($fo_fi_desc); ?></p>
        </div>
      </header>

      <div class="fo-fi-fields">
        <?php
        $fo_fi_rows = array(
            array('label' => '站点名称', 'value' => $fo_fi_name),
            array('label' => '站点描述', 'value' => $fo_fi_desc),
            array('label' => '站点链接', 'value' => $fo_fi_url),
            array('label' => '头像链接', 'value' => $fo_fi_avatar),
        );
        foreach ($fo_fi_rows as $fo_fi_row):
        ?>
        <div class="fo-fi-field">
          <div class="fo-fi-field-main">
            <span><?php echo e($fo_fi_row['label']); ?></span>
            <b><?php echo e($fo_fi_row['value']); ?></b>
          </div>
          <button type="button" class="fo-fi-copy" data-copy="<?php echo e($fo_fi_row['value']); ?>" aria-label="复制<?php echo e($fo_fi_row['label']); ?>" title="复制">
            <?php echo $fo_fi_copy_icon; ?>
          </button>
        </div>
        <?php endforeach; ?>
      </div>
    </article>

    <article class="fo-fi-card fo-fi-apply">
      <h2 class="fo-fi-title">
        <span class="fo-fi-tag" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="12" height="17" rx="2.4"></rect><path d="M9 3.5h6v3H9z"></path><path d="M9 11h6M9 15h4"></path></svg></span>
        申请友链
      </h2>

      <?php if ($fo_fi_apply !== ''): ?>
        <div class="fo-fi-prose"><?php echo render_content($fo_fi_apply, 'markdown'); ?></div>
      <?php endif; ?>

      <ol class="fo-fi-steps">
        <li>
          <i aria-hidden="true">1</i>
          <div class="fo-fi-step">
            <h3>添加本站友链</h3>
            <p>请先在您的网站友链页面添加本站信息，可直接复制左侧各字段</p>
            <p class="fo-fi-hl"><?php echo e($fo_fi_note); ?></p>
          </div>
        </li>
        <li>
          <i aria-hidden="true">2</i>
          <div class="fo-fi-step">
            <h3>在评论区留言</h3>
            <p>请复制下方申请模板，修改后在评论区发送</p>
            <div class="fo-fi-tpl">
              <pre id="fo-fi-tpl-text"><?php echo e($fo_fi_tpl); ?></pre>
              <button type="button" class="fo-fi-copy fo-fi-copy--tpl" data-copy-target="fo-fi-tpl-text" aria-label="复制申请模板" title="复制模板">
                <?php echo $fo_fi_copy_icon; ?>
              </button>
            </div>
          </div>
        </li>
        <li>
          <i aria-hidden="true">3</i>
          <div class="fo-fi-step">
            <h3>等待审核</h3>
            <p>确认信息无误后会尽快添加您的友链</p>
          </div>
        </li>
      </ol>
    </article>
  </div>

  <article class="fo-fi-card fo-fi-rules">
    <h2 class="fo-fi-rules-title">
      <span aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"></circle><path d="M12 10.6v6"></path><path d="M12 7.4h.01"></path></svg></span>
      注意事项
    </h2>
    <ul class="fo-fi-rule-list">
      <?php foreach ($fo_fi_rules as $fo_rule): ?>
        <?php
        $fo_rule_html = e($fo_rule);
        if (preg_match('/^([^：:]{1,12})[：:]\s*(.+)$/u', $fo_rule, $m)) {
            $fo_rule_html = '<b>' . e($m[1]) . '：</b>' . e($m[2]);
        }
        ?>
        <li><?php echo $fo_rule_html; ?></li>
      <?php endforeach; ?>
    </ul>
  </article>

  <p class="fo-fi-toast" id="fo-fi-toast" hidden>已复制到剪贴板</p>
</section>

<script>
(function () {
  var wrap = document.getElementById('fo-fri-apply');
  if (!wrap) return;
  var toast = document.getElementById('fo-fi-toast');
  var timer = 0;

  function showToast() {
    if (!toast) return;
    toast.hidden = false;
    toast.classList.add('is-on');
    clearTimeout(timer);
    timer = setTimeout(function () {
      toast.classList.remove('is-on');
      setTimeout(function () { toast.hidden = true; }, 220);
    }, 1600);
  }

  function legacyCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    return ok;
  }

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return legacyCopy(text); });
    }
    return Promise.resolve(legacyCopy(text));
  }

  wrap.addEventListener('click', function (ev) {
    var btn = ev.target.closest ? ev.target.closest('.fo-fi-copy') : null;
    if (!btn) return;
    var text = btn.getAttribute('data-copy');
    if (text === null) {
      var id = btn.getAttribute('data-copy-target');
      var node = id ? document.getElementById(id) : null;
      text = node ? node.textContent : '';
    }
    if (!text) return;
    copyText(text).then(function (ok) {
      if (ok) {
        btn.classList.add('is-done');
        setTimeout(function () { btn.classList.remove('is-done'); }, 1200);
        showToast();
      }
    });
  });
})();
</script>