<?php
/**
 * 星辉 · Fomalhaut · 下载跳转
 * 校验登录与兑换记录后记录一次下载并跳转到外链地址
 */
require dirname(dirname(__DIR__)) . '/init.php';
require __DIR__ . '/_shop.php';

$uid = fo_shop_uid();
if ($uid <= 0) {
    redirect(base_url() . 'user/login');
}

$gid = isset($_GET['g']) ? (int)$_GET['g'] : 0;
$url = fo_download_url($uid, $gid);
if ($url === null) {
    http_response_code(403);
    exit('还没有兑换这个资源，或资源不存在。');
}

fo_download_record($uid, $gid);

header('Location: ' . $url, true, 302);
exit;