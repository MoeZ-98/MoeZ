<?php
/**
 * 星辉 · Fomalhaut 模板 · 公共评论区（文章页 / 友链页共用）
 *
 * 调用前可指定：
 *   $fo_cmt_target   评论目标 ID（文章页为文章 id；友链页为友链留言板绑定 ID，可为 0）
 *   $fo_cmt_comments 已审核评论数组
 *   $fo_cmt_action   提交地址（文章页 comment.php；友链页主题内 _comment.php）
 *   $fo_cmt_title    标题，默认「评论」
 *   $fo_cmt_lead     标题下的一句引导语，默认空
 *   $fo_cmt_anchor   区块锚点 id，默认 comment
 */
$fo_cmt_target   = isset($fo_cmt_target) ? (int)$fo_cmt_target : (isset($post['id']) ? (int)$post['id'] : 0);
$fo_cmt_comments = isset($fo_cmt_comments) ? (array)$fo_cmt_comments : (isset($comments) ? (array)$comments : array());
$fo_cmt_action   = isset($fo_cmt_action) && $fo_cmt_action !== '' ? $fo_cmt_action : base_url() . 'comment.php';
$fo_cmt_title    = isset($fo_cmt_title) && $fo_cmt_title !== '' ? $fo_cmt_title : '评论';
$fo_cmt_lead     = isset($fo_cmt_lead) ? (string)$fo_cmt_lead : '';
$fo_cmt_anchor   = isset($fo_cmt_anchor) && $fo_cmt_anchor !== '' ? $fo_cmt_anchor : 'comment';

$fo_cdf = function_exists('fo_comment_defaults') ? fo_comment_defaults() : array('author' => '', 'email' => '', 'admin' => false, 'user' => false);
/* 评论得分提示（2.1.0）：积分为核心模块，发评论时由 comment.php 直接发放，
   这里只负责显示「可得多少 / 今天还剩几次」，不再走前端二次领分接口。 */
$fo_cmt_points = null;
if (!empty($fo_cdf['user']) && function_exists('moe_pt_comment_left') && moe_pt_on()) {
    $fo_cmt_pts = max(0, (int)moe_pt_opt('comment', '2'));
    $fo_cmt_left = moe_pt_comment_left((int)($fo_cdf['uid'] ?? 0));
    if ($fo_cmt_pts > 0 && $fo_cmt_left > 0) {
        $fo_cmt_points = array('points' => $fo_cmt_pts, 'left' => $fo_cmt_left, 'unit' => moe_pt_name());
    }
}
$fo_cmt_emoji = fo_on('comment_emoji', '1');
$fo_cmt_hitokoto = fo_on('comment_hitokoto', '1');
$fo_cmt_img = fo_on('comment_img_upload', '1');
?>
    <?php /* 2.1.0：积分由 comment.php 直接发放，前端不再二次领取（避免重复加分） */ ?>
    <section class="fo-comments" id="<?php echo e($fo_cmt_anchor); ?>"
           data-avatar="<?php echo e(fo_avatar_default()); ?>"
           data-hitokoto="<?php echo $fo_cmt_hitokoto ? '1' : '0'; ?>"
           data-img="<?php echo $fo_cmt_img ? '1' : '0'; ?>"
           data-upload="<?php echo e(base_url() . 'comment_upload.php'); ?>">
      <h2 class="fo-comments-title"><?php echo e($fo_cmt_title); ?> <span><?php echo count($fo_cmt_comments); ?></span></h2>
      <?php if ($fo_cmt_lead !== ''): ?><p class="fo-comments-lead"><?php echo e($fo_cmt_lead); ?></p><?php endif; ?>

      <form class="fo-comment-form" method="post" action="<?php echo e($fo_cmt_action); ?>" id="fo-comment-form">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="post_id" value="<?php echo (int)$fo_cmt_target; ?>">
        <?php if (!empty($fo_cdf['admin'])): ?>
        <div class="fo-comment-identity">
          <span class="fo-comment-identity-badge">✦</span>
          <b><?php echo e($fo_cdf['author'] !== '' ? $fo_cdf['author'] : '站长'); ?></b>
          <span>已登录，将以站长身份发布，无需填写昵称邮箱</span>
        </div>
        <input type="hidden" name="author" value="<?php echo e($fo_cdf['author']); ?>">
        <input type="hidden" name="email" value="<?php echo e($fo_cdf['email']); ?>">
        <?php elseif (!empty($fo_cdf['user'])): ?>
        <div class="fo-comment-identity">
          <span class="fo-comment-identity-badge">👤</span>
          <b><?php echo e($fo_cdf['author']); ?></b>
          <span>已登录会员，无需填写昵称邮箱 · <a href="<?php echo e(base_url() . 'user/profile'); ?>">修改资料</a></span>
        </div>
        <input type="hidden" name="author" value="<?php echo e($fo_cdf['author']); ?>">
        <input type="hidden" name="email" value="<?php echo e($fo_cdf['email']); ?>">
        <?php else: ?>
        <div class="fo-comment-row">
          <input type="text" name="author" placeholder="昵称 *" required maxlength="30">
          <input type="email" name="email" placeholder="邮箱（选填，不会公开）" maxlength="100">
        </div>
        <?php endif; ?>

        <div class="fo-comment-toolbar">
          <?php if ($fo_cmt_emoji): ?>
          <div class="fo-emoji-bar" id="fo-emoji-bar">
            <?php foreach (array('😊','😂','🥰','😍','😘','👍','🙏','🎉','✨','🔥','💦','😖','😭','😳','🤔','😅','🖕','🈚','❤️','💔','🌸','🌟','🐱','🐕','🍺','🍰','👋','💪','🤝','👏') as $fo_emo): ?>
              <button type="button" class="fo-emoji-btn" data-emo="<?php echo e($fo_emo); ?>"><?php echo e($fo_emo); ?></button>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
          <div class="fo-comment-tools">
            <?php if ($fo_cmt_emoji): ?><button type="button" class="fo-tool-btn" id="fo-emoji-toggle" title="表情">😊 表情</button><?php endif; ?>
            <?php if ($fo_cmt_img): ?>
            <button type="button" class="fo-tool-btn" id="fo-img-btn" title="上传图片">🖼 图片</button>
            <input type="file" id="fo-img-input" accept="image/jpeg,image/png,image/gif,image/webp" hidden>
            <span class="fo-tool-status" id="fo-img-status"></span>
            <?php endif; ?>
          </div>
        </div>

        <textarea name="content" rows="4" placeholder="写下你的评论…<?php if ($fo_cmt_img): ?>可上传图片，支持粘贴 [img]图片地址[/img]<?php endif; ?>" maxlength="2000"></textarea>
        <input type="hidden" name="parent_id" value="0" id="fo-reply-parent">
        <?php if ($fo_cmt_img): ?><div class="fo-comment-previews" id="fo-img-previews"></div><?php endif; ?>
        <?php if ($fo_cmt_points): ?>
        <p class="fo-comment-points">✦ 本次评论可得 <b>+<?php echo (int)$fo_cmt_points['points']; ?></b> <?php echo e($fo_cmt_points['unit']); ?>，今天还剩 <?php echo (int)$fo_cmt_points['left']; ?> 次得分机会</p>
        <?php endif; ?>
        <div class="fo-comment-foot">
          <span>发布后将显示 IP 归属地与设备信息</span>
          <button class="fo-btn" type="submit">发布评论</button>
        </div>
        <p class="fo-comment-msg" id="fo-comment-msg" hidden></p>
      </form>

      <?php if (empty($fo_cmt_comments)): ?>
        <p class="fo-empty">还没有评论，来说点什么吧～</p>
      <?php else: ?>
      <?php
      /* 嵌套楼层式评论：回复缩进挂在父评论下 */
      $fo_children = array();
      foreach ($fo_cmt_comments as $cm) {
          $fo_children[(int)($cm['parent_id'] ?? 0)][] = $cm;
      }
      $fo_admin_mail = strtolower(trim((string)$site['mail']));
      /* 站长评论头像：优先用后台设置的站点头像（资料卡同款）；未配置时用默认头像 */
      $fo_admin_avatar = !empty($site['avatar']) ? media_url($site['avatar']) : '';
      /* 会员头像映射（1.6.0）：评论邮箱与用户中心会员邮箱一致时，显示该会员的头像与身份 */
      $fo_user_map = array();
      try {
          foreach ((array)rows('SELECT email, avatar, nickname, username, role FROM ' . moe_table('users') . " WHERE email <> ''") as $fu) {
              $fu_mail = strtolower(trim((string)$fu['email']));
              if ($fu_mail !== '') $fo_user_map[$fu_mail] = $fu;
          }
      } catch (Throwable $e) {
          $fo_user_map = array();
      }
      $fo_render_cm = function ($cm, $depth, $parent_author) use (&$fo_render_cm, $fo_children, $fo_admin_mail, $fo_admin_avatar, $fo_user_map) {
          $fo_cm_id = (int)$cm['id'];
          $fo_cm_mail = strtolower(trim((string)($cm['email'] ?? '')));
          $fo_um = isset($fo_user_map[$fo_cm_mail]) ? $fo_user_map[$fo_cm_mail] : null;
          $fo_is_admin = ($fo_cm_mail !== '' && $fo_admin_mail !== '' && $fo_cm_mail === $fo_admin_mail)
              || (!empty($fo_um) && $fo_um['role'] === 'admin');
          $fo_cm_avatar = '';
          if ($fo_is_admin && $fo_admin_avatar !== '') {
              $fo_cm_avatar = $fo_admin_avatar;
          } elseif (!empty($fo_um) && !empty($fo_um['avatar'])) {
              $fo_cm_avatar = (string)$fo_um['avatar'];
          } else {
              $fo_cm_avatar = fo_avatar((string)$cm['author'], (string)($cm['email'] ?? ''));
          }
          ?>
      <article class="fo-comment<?php echo $depth > 0 ? ' fo-comment--child' : ''; ?>" id="fo-cm-<?php echo $fo_cm_id; ?>">
        <img class="fo-comment-avatar" src="<?php echo $fo_cm_avatar !== '' ? e($fo_cm_avatar) : fo_avatar_default(); ?>" alt="<?php echo e($cm['author']); ?>" width="40" height="40" loading="lazy" decoding="async"
             onerror="<?php if ($fo_is_admin && $fo_admin_avatar !== ''): ?>this.onerror=null;this.src=foDefaultAvatar;<?php else: ?>if(!this.dataset.f){this.dataset.f='1';this.src='https://weavatar.com/avatar/<?php echo $fo_cm_mail !== '' ? md5($fo_cm_mail) : 'default'; ?>?d=retro&s=96';}else{this.onerror=null;this.src=foDefaultAvatar;}<?php endif; ?>">
        <div class="fo-comment-main">
          <div class="fo-comment-head">
            <b><?php echo e($cm['author']); ?></b>
            <?php if ($fo_is_admin): ?><span class="fo-comment-badge">站长</span>
            <?php elseif (!empty($fo_um)): ?><span class="fo-comment-badge fo-comment-badge--user">会员</span><?php endif; ?>
          </div>
          <div class="fo-comment-text">
            <?php if ($depth > 0 && $parent_author !== ''): ?><span class="fo-comment-replytag">回复了: <?php echo e($parent_author); ?></span><?php endif; ?>
            <?php echo fo_comment_html($cm['content']); ?>
          </div>
          <div class="fo-comment-meta">
            <time><?php echo e(nice_time($cm['created_at'])); ?></time>
            <?php
            /* 2.1.2：IP 归属地 + 设备信息改为三枚圆角小徽标（地址 / 系统 / 浏览器），数据来自评论表 location + ua */
            $fo_ua = function_exists('moe_ua_parts') ? moe_ua_parts((string)($cm['ua'] ?? '')) : array('os' => '', 'browser' => '');
            if (!empty($cm['location'])): ?>
            <span class="fo-cmt-tag" title="IP 归属地"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-7-5.1-7-11a7 7 0 0 1 14 0c0 5.9-7 11-7 11Z"/><circle cx="12" cy="10" r="2.6"/></svg><?php echo e($cm['location']); ?></span>
            <?php endif;
            if ($fo_ua['os'] !== ''): ?>
            <span class="fo-cmt-tag" title="操作系统"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/></svg><?php echo e($fo_ua['os']); ?></span>
            <?php endif;
            if ($fo_ua['browser'] !== ''): ?>
            <span class="fo-cmt-tag" title="浏览器"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3a14.5 14.5 0 0 1 0 18 14.5 14.5 0 0 1 0-18Z"/></svg><?php echo e($fo_ua['browser']); ?></span>
            <?php endif;
            /* 2.1.2：自己的评论显示「编辑」入口（后台「站点设置」可关闭），跳到用户中心改 */
            $fo_mine = !empty($fo_cdf['user']) && (
                (int)($cm['user_id'] ?? 0) === (int)($fo_cdf['uid'] ?? 0)
                || ((int)($cm['user_id'] ?? 0) === 0 && $fo_cm_mail !== '' && $fo_cm_mail === strtolower(trim((string)($fo_cdf['email'] ?? ''))))
            );
            if ($fo_mine && function_exists('setting') && setting('comment_edit', '1') === '1'): ?>
            <a class="fo-cmt-edit" href="<?php echo e(base_url() . 'user?a=comments&edit=' . $fo_cm_id . '#uc-cm-' . $fo_cm_id); ?>">✏️ 编辑</a>
            <?php endif; ?>
            <button type="button" class="fo-reply-btn" data-id="<?php echo $fo_cm_id; ?>">回复</button>
          </div>
          <?php if (!empty($fo_children[$fo_cm_id])): ?>
          <div class="fo-comment-children">
            <?php foreach ($fo_children[$fo_cm_id] as $fo_cm_child) { $fo_render_cm($fo_cm_child, $depth + 1, (string)$cm['author']); } ?>
          </div>
          <?php endif; ?>
        </div>
      </article>
      <?php }; ?>
      <div class="fo-comment-list">
        <?php foreach (($fo_children[0] ?? array()) as $fo_cm_root) { $fo_render_cm($fo_cm_root, 0, ''); } ?>
      </div>
      <?php endif; ?>
    </section>

