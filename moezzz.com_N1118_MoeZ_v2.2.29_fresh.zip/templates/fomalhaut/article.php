<?php
/**
 * 星辉 · Fomalhaut 模板 · 文章列表（/blog/article）
 * 可用变量：$posts $pager $total $page $cats $sel_cat $site
 */
$cur_p = 'article';
include partial_path('header.php');

$fo_hero_img = trim(fo_opt('hero_bg', ''));
$fo_hero_img = $fo_hero_img !== '' ? media_url($fo_hero_img) : theme_url('assets/hero.svg');
?>
<section class="fo-hero fo-hero--small" style="background-image:linear-gradient(180deg,rgba(14,32,52,.28),rgba(14,32,52,.52)),url('<?php echo e($fo_hero_img); ?>')">
  <div class="fo-hero-center">
    <h1 class="fo-hero-title fo-hero-title--sm">文章</h1>
    <p class="fo-hero-sub">共 <?php echo (int)$total; ?> 篇，慢慢读</p>
  </div>
</section>

<div class="fo-wrap fo-wrap--single">
  <div class="fo-panel">
    <?php if (!empty($cats)): ?>
    <div class="fo-yearchips fo-yearchips--cats">
      <a class="fo-yearchip is-active" href="<?php echo e(base_url() . 'blog/article'); ?>">全部</a>
      <?php foreach ((array)$cats as $c): ?>
        <a class="fo-yearchip" href="<?php echo e(cat_url($c)); ?>"><?php echo e($c['name']); ?><em><?php echo (int)$c['count']; ?></em></a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="fo-grid fo-grid--wide">
      <?php foreach ((array)$posts as $p): ?>
        <?php $cov = fo_cover($p); ?>
        <article class="fo-card">
          <a class="fo-card-cover" href="<?php echo e(post_url($p)); ?>" style="background:<?php echo e($cov['style']); ?>">
            <?php echo fo_cover_img_tag($cov['url']); ?>
            <?php if (!empty($p['is_top'])): ?><span class="fo-flag fo-flag--top">置顶</span><?php endif; ?>
            <?php if (!empty($p['cat_name'])): ?><span class="fo-flag fo-flag--cat"><?php echo e($p['cat_name']); ?></span><?php endif; ?>
          </a>
          <div class="fo-card-body">
            <h3 class="fo-card-title"><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
            <div class="fo-meta">
              <span class="fo-meta-end"><?php echo e(fo_ago($p['created_at'])); ?></span>
              <span><?php echo (int)$p['views']; ?> 浏览</span>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>

    <?php if (empty($posts)): ?><p class="fo-empty">这个分类下还没有文章</p><?php endif; ?>
    <?php echo $pager; ?>
  </div>
</div>

<?php include partial_path('footer.php'); ?>