<?php
/**
 * 星辉 · Fomalhaut · 签到端点
 * POST + CSRF，登录用户每天一次，返回 JSON（含积分与连签）
 */
require dirname(dirname(__DIR__)) . '/init.php';
require __DIR__ . '/_shop.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_exit(false, '非法请求');

csrf_verify();

$uid = fo_shop_uid();
if ($uid <= 0) json_exit(false, '请先登录后再签到');

$res = fo_signin_do($uid);
json_exit((bool)$res['ok'], (string)$res['msg'], array(
    'points'  => (int)$res['points'],
    'streak'  => (int)$res['streak'],
    'balance' => (int)$res['balance'],
));