<?php
/**
 * 星辉 · Fomalhaut · 弹窗登录 / 注册端点（2.1.25）
 * 配合 header.php 里的登录弹窗，全部走 AJAX + JSON：
 *   GET              ：返回最新 CSRF Token（缓存页里的旧 Token 可能已失效）、
 *                      是否开放注册、是否开启登录图形验证码
 *   GET  ?act=captcha：生成算术验证码（复用核心 moe_uc_captcha 的会话键，注册用）
 *   POST act=login   ：会员登录（复用核心 moe_user_login，支持用户名 / 邮箱；
 *                      后台开了「登录图形验证码」时一并校验；支持记住登录 14 天）
 *   POST act=register：会员注册（复用核心 moe_user_register，成功后自动登录）
 */
require dirname(dirname(__DIR__)) . '/init.php';

$act = isset($_REQUEST['act']) ? (string)$_REQUEST['act'] : '';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    if ($act === 'captcha') {
        json_exit(true, '', array('cap' => moe_uc_captcha()));
    }
    json_exit(true, '', array(
        'token'    => csrf_token(),
        'register' => setting('user_register', '0') === '1',
        'capimg'   => setting('login_captcha', '0') === '1',
    ));
}

if ($act === 'login') {
    csrf_verify();
    // 图形验证码（后台「邮箱与登录 → 登录验证码」开启时；与后台登录同一套 Session 键）
    if (setting('login_captcha', '0') === '1') {
        $inp = strtoupper(trim((string)($_POST['captcha'] ?? '')));
        $ses = isset($_SESSION['moe_captcha']) ? strtoupper((string)$_SESSION['moe_captcha']) : '';
        unset($_SESSION['moe_captcha']);          // 一次性，防重放
        if ($ses === '' || $inp === '' || !hash_equals($ses, $inp)) {
            json_exit(false, '图形验证码不正确或已过期，点图片可刷新', array('recapimg' => 1));
        }
    }
    $r = moe_user_login($_POST['username'] ?? '', $_POST['password'] ?? '', true);
    if ($r[0] && !empty($_POST['remember'])) {
        // 记住登录状态：会话 id 已在登录时重建，这里把 Cookie 延长到 14 天（与后台登录一致）
        $p = session_get_cookie_params();
        @setcookie(session_name(), session_id(), time() + 86400 * 14, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    json_exit((bool)$r[0], (string)$r[1]);
}

if ($act === 'register') {
    csrf_verify();
    $r = moe_user_register($_POST);
    if ($r[0]) {
        // 注册成功自动登录，弹窗关闭后即为登录态
        moe_user_login($_POST['username'] ?? '', (string)($_POST['password'] ?? ''), true);
        json_exit(true, '注册成功，欢迎加入～', array('reload' => 1));
    }
    json_exit(false, (string)$r[1], array('recap' => 1));
}

json_exit(false, '未知操作');
