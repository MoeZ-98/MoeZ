<?php
/**
 * 星辉 · Fomalhaut 模板 · 看板娘小屋（/companion，2.1.23）
 * 展示看板娘的使用情况：陪聊次数、AI token 输入/输出、花费统计
 * 可用变量：$cp_stats（total/today/cost_total/cost_today/price_in/price_out） $cp_name
 *
 * 2.1.27：/companion?room=1 是公共聊天室（part-room.php）。
 *   AJAX 请求必须在输出 HTML 之前处理，所以先挂上 part-room 再 include header。
 */
include_once partial_path('part-room.php');

if ((isset($_POST['fo_room_action']) || isset($_GET['fo_room_action'])) && function_exists('fo_room_ajax')) {
    fo_room_ajax();          /* 弹 JSON 后 exit，不会走到模板 HTML（GET 走同一入口，POST 被主机拦时前端可退回 GET） */
}

$fo_room_mode = isset($_GET['room']) && (string)$_GET['room'] !== '0' && (string)$_GET['room'] !== '';

$cur_p = 'companion';
include partial_path('header.php');

if ($fo_room_mode) {
    fo_room_page();
    include partial_path('footer.php');
    return;
}

$fmt = function ($n) { return number_format((float)$n); };
$fmtc = function ($n) { return number_format((float)$n, ($n > 0 && $n < 1) ? 4 : 2); };
$cp_ai_on = function_exists('moe_ai_cfg') ? moe_ai_cfg() : array('on' => false, 'model' => '');
$fo_room_on = fo_on('room_on', '1');
?>
<div class="fo-wrap fo-wrap--single fo-wrap--nohero">
  <div class="fo-fr-panel">

    <header class="fo-fr-head">
      <div class="fo-fr-title-row">
        <span class="fo-fr-ico" aria-hidden="true">✦</span>
        <h1><?php echo e($cp_name); ?>的小屋</h1>
      </div>
      <p class="fo-fr-desc">这里记录着「<?php echo e($cp_name); ?>」陪大家聊天的痕迹～她一直在认真营业哦。</p>
      <div class="fo-room-tabs">
        <a class="fo-room-tab is-on" href="<?php echo e(base_url() . 'companion'); ?>" aria-current="page">小屋</a>
        <?php if ($fo_room_on): ?><a class="fo-room-tab fo-room-tab--go" href="<?php echo e(base_url() . 'companion?room=1'); ?>">聊天室 →</a><?php endif; ?>
      </div>
    </header>

    <div class="fo-cpstat-hero">
      <img class="fo-cpstat-ava" src="<?php echo e(theme_url('assets/companion.png')); ?>" alt="<?php echo e($cp_name); ?>" loading="lazy" decoding="async">
      <div class="fo-cpstat-herotext">
        <strong><?php echo e($cp_name); ?></strong>
        <span><?php if (!empty($cp_ai_on['on'])): ?>AI 在线 ·<?php echo e($cp_ai_on['model']); ?><?php else: ?>站内小助手模式<?php endif; ?></span>
      </div>
    </div>

    <h2 class="fo-cpstat-h2">累计陪伴</h2>
    <div class="fo-cpstat-grid">
      <div class="fo-cpstat-card">
        <em><?php echo $fmt($cp_stats['total']['req']); ?></em>
        <span>对话次数</span>
      </div>
      <div class="fo-cpstat-card">
        <em><?php echo $fmt($cp_stats['total']['in']); ?></em>
        <span>输入 tokens</span>
      </div>
      <div class="fo-cpstat-card">
        <em><?php echo $fmt($cp_stats['total']['out']); ?></em>
        <span>输出 tokens</span>
      </div>
      <div class="fo-cpstat-card is-cost">
        <em>¥<?php echo $fmtc($cp_stats['cost_total']); ?></em>
        <span>累计花费</span>
      </div>
    </div>

    <h2 class="fo-cpstat-h2">今天</h2>
    <div class="fo-cpstat-grid">
      <div class="fo-cpstat-card">
        <em><?php echo $fmt($cp_stats['today']['req']); ?></em>
        <span>今日对话</span>
      </div>
      <div class="fo-cpstat-card">
        <em><?php echo $fmt($cp_stats['today']['in']); ?></em>
        <span>输入 tokens</span>
      </div>
      <div class="fo-cpstat-card">
        <em><?php echo $fmt($cp_stats['today']['out']); ?></em>
        <span>输出 tokens</span>
      </div>
      <div class="fo-cpstat-card is-cost">
        <em>¥<?php echo $fmtc($cp_stats['cost_today']); ?></em>
        <span>今日花费</span>
      </div>
    </div>

    <p class="fo-cpstat-note">tokens 是 AI 思考与回答的字数计量：她每次听懂你的话要「读」（输入），回答要「写」（输出）。
      花费按后台单价估算（输入 ¥<?php echo e($fmtc($cp_stats['price_in'])); ?> / 百万 tokens，输出 ¥<?php echo e($fmtc($cp_stats['price_out'])); ?> / 百万 tokens），仅供站长参考。</p>

  </div>
</div>
<?php include partial_path('footer.php'); ?>
