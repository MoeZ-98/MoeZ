<?php
/**
 * 星辉 · Fomalhaut 模板 · 404
 */
$cur_p = '404';
$page_title = '404 Not Found';
include partial_path('header.php');
$fo_hero_img = theme_url('assets/hero.svg');
?>
<section class="fo-hero fo-hero--small" style="background-image:linear-gradient(180deg,rgba(14,32,52,.32),rgba(14,32,52,.58)),url('<?php echo e($fo_hero_img); ?>')">
  <div class="fo-hero-center">
    <h1 class="fo-hero-title fo-hero-title--sm">404</h1>
    <p class="fo-hero-sub">这颗星星好像不在这片星图里</p>
  </div>
</section>

<div class="fo-wrap fo-wrap--single">
  <div class="fo-panel fo-404">
    <div class="fo-404-face">✦</div>
    <h2>页面去二次元了</h2>
    <p>你要找的内容不存在、已被删除，或者根本就是别的次元的链接～</p>
    <div class="fo-404-actions">
      <a class="fo-btn" href="<?php echo e(home_url()); ?>">回到首页</a>
      <a class="fo-btn fo-btn--ghost" href="<?php echo e(base_url() . 'archives'); ?>">看看归档</a>
    </div>
  </div>
</div>

<?php include partial_path('footer.php'); ?>