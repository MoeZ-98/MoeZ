<?php
/**
 * 星辉 · Fomalhaut 模板 · 公共函数库
 * 只在模板内部使用，全部函数带 fo_ 前缀，避免与程序核心冲突。
 */

/** 主题资源版本号：升级主题后用于刷新 style.css / app.js 缓存 */
if (!defined('FO_ASSET_VER')) define('FO_ASSET_VER', '2.1.31');

/** 读取模板设置（带兜底默认值） */
if (!function_exists('fo_opt')) {
    function fo_opt($key, $default = '')
    {
        return theme_opt($key, $default);
    }
}

/** 十六进制颜色转 rgba（透明度 0-100） */
if (!function_exists('fo_rgba')) {
    function fo_rgba($hex, $alpha)
    {
        $hex = ltrim(trim((string)$hex), '#');
        if (strlen($hex) === 3) $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        if (strlen($hex) !== 6 || !ctype_xdigit($hex)) return '';
        $a = max(0, min(100, (int)$alpha)) / 100;
        return 'rgba(' . hexdec(substr($hex, 0, 2)) . ',' . hexdec(substr($hex, 2, 2)) . ',' . hexdec(substr($hex, 4, 2)) . ',' . $a . ')';
    }
}

/** 布尔开关：'1' 视为开启 */
if (!function_exists('fo_on')) {
    function fo_on($key, $default = '1')
    {
        return theme_opt($key, $default) === '1';
    }
}

/** 侧栏是否可用：总开关 + 六个模块至少一个开启 */
if (!function_exists('fo_side_enabled')) {
    function fo_side_enabled()
    {
        return fo_on('show_sidebar', '1') && (fo_on('show_profile', '1') || fo_on('show_calendar', '1')
            || fo_on('show_rank', '1')
            || fo_on('show_yearbar', '1') || fo_on('show_announce', '1') || fo_on('show_sitestats', '1'));
    }
}

/** 评论内容渲染：转义后把 [img]图片地址[/img] 转为图片标签 */
if (!function_exists('fo_comment_html')) {
    function fo_comment_html($content)
    {
        $html = nl2br(e((string)$content));
        $html = preg_replace_callback('/\[img\]\s*(https?:\/\/[^\s\[\]<>"\']+)\s*\[\/img\]/iu', function ($m) {
            return '<img class="fo-comment-img" src="' . e($m[1]) . '" alt="评论图片" loading="lazy">';
        }, $html);
        return $html;
    }
}

/** 字符长度 / 截取：mbstring 未安装时退回 UTF-8 正则，避免模板报错 */
if (!function_exists('fo_strlen')) {
    function fo_strlen($s)
    {
        $s = (string)$s;
        if (function_exists('mb_strlen')) return mb_strlen($s, 'UTF-8');
        return preg_match_all('/./us', $s, $m) ? count($m[0]) : strlen($s);
    }
}
if (!function_exists('fo_substr')) {
    function fo_substr($s, $start, $len = null)
    {
        $s = (string)$s;
        if (function_exists('mb_substr')) return $len === null ? mb_substr($s, $start, null, 'UTF-8') : mb_substr($s, $start, $len, 'UTF-8');
        preg_match_all('/./us', $s, $m);
        $chars = isset($m[0]) ? $m[0] : array();
        $slice = $len === null ? array_slice($chars, $start) : array_slice($chars, $start, $len);
        return implode('', $slice);
    }
}

/** 文章标签：取「SEO 关键词」字段，中英文逗号 / 空格分隔 */
if (!function_exists('fo_tags')) {
    function fo_tags($post, $limit = 6)
    {
        $raw = isset($post['seo_keywords']) ? (string)$post['seo_keywords'] : '';
        if ($raw === '' && isset($post['keywords'])) $raw = (string)$post['keywords'];
        $parts = preg_split('/[,，、\s]+/u', $raw);
        $out = array();
        foreach ((array)$parts as $p) {
            $p = trim($p);
            if ($p === '' || fo_strlen($p) > 12) continue;
            if (!in_array($p, $out, true)) $out[] = $p;
            if (count($out) >= $limit) break;
        }
        return $out;
    }
}

/** 封面占位渐变（无封面图时使用，按文章 id 稳定取色） */
if (!function_exists('fo_gradient')) {
    function fo_gradient($seed = 0)
    {
        $list = array(
            'linear-gradient(135deg,#bfd9f2 0%,#e8f1fb 45%,#cfe6d8 100%)',
            'linear-gradient(135deg,#f6d5c3 0%,#fdeee2 48%,#cfe0ef 100%)',
            'linear-gradient(135deg,#c9d7f0 0%,#e6ecf9 45%,#f3d9e7 100%)',
            'linear-gradient(135deg,#cce4dd 0%,#eaf6f2 45%,#d6e3f2 100%)',
            'linear-gradient(135deg,#e9dcc4 0%,#f7f1e4 45%,#cfe2ea 100%)',
            'linear-gradient(135deg,#d5cbe8 0%,#f0ebfa 45%,#f6dfe3 100%)',
        );
        $i = abs((int)$seed) % count($list);
        return $list[$i];
    }
}

/**
 * 文章封面：返回 array('url' => 图片地址, 'style' => 渐变兜底)
 * 2.1.14：无论有无图片都返回渐变——有图时渐变作为 img 未加载完的占位，避免白块闪烁
 */
if (!function_exists('fo_cover')) {
    function fo_cover($post)
    {
        $cover = function_exists('post_cover') ? post_cover($post) : (isset($post['cover']) ? $post['cover'] : '');
        $grad = fo_gradient(isset($post['id']) ? $post['id'] : 0);
        return array('url' => $cover !== '' ? media_url($cover) : '', 'style' => $grad);
    }
}

/**
 * 封面图标签（2.1.14 加载优化）
 * 列表卡片默认原生懒加载：视口外封面不再随首屏一起下载；首屏大卡传 $eager=true 高优先级加载。
 */
if (!function_exists('fo_cover_img_tag')) {
    function fo_cover_img_tag($url, $eager = false)
    {
        if ((string)$url === '') return '';
        return '<img class="fo-cover-img" src="' . e($url) . '" alt="" '
            . ($eager ? 'fetchpriority="high"' : 'loading="lazy"') . ' decoding="async"'
            . ' onerror="this.remove()">';
    }
}

/** 「x 天前 / 刚刚」短格式，用于卡片元信息 */
if (!function_exists('fo_ago')) {
    function fo_ago($dt)
    {
        $ts = is_numeric($dt) ? (int)$dt : strtotime((string)$dt);
        if (!$ts) return '';
        $d = time() - $ts;
        if ($d < 0) return '刚刚';
        if ($d < 3600) return max(1, (int)floor($d / 60)) . ' 分钟前';
        if ($d < 86400) return (int)floor($d / 3600) . ' 小时前';
        return (int)floor($d / 86400) . ' 天前';
    }
}

/** 页面数据（按别名查 type=page），不存在返回 null */
if (!function_exists('fo_page')) {
    function fo_page($slug)
    {
        $slug = trim((string)$slug);
        if ($slug === '') return null;
        static $cache = array();
        if (array_key_exists($slug, $cache)) return $cache[$slug];
        try {
            $pg = row('SELECT * FROM ' . moe_table('posts') . " WHERE type='page' AND slug = ? AND status='published' LIMIT 1", array($slug));
            return $cache[$slug] = ($pg ? $pg : null);
        } catch (Throwable $e) {
            return $cache[$slug] = null;
        }
    }
}

/** 统计页地址：优先按页面别名生成，页面不存在返回 '' */
if (!function_exists('fo_stats_url')) {
    function fo_stats_url()
    {
        $slug = trim(fo_opt('stats_slug', 'stats'));
        $pg = fo_page($slug);
        return $pg ? page_url($pg) : '';
    }
}

/** 下一个固定公历节日（用于侧栏倒计时） */
if (!function_exists('fo_next_festival')) {
    function fo_next_festival()
    {
        $list = array(
            array('元旦', 1, 1), array('情人节', 2, 14), array('劳动节', 5, 1),
            array('儿童节', 6, 1), array('国庆节', 10, 1), array('平安夜', 12, 24),
            array('圣诞节', 12, 25),
        );
        $today = strtotime(date('Y-m-d'));
        $best = null;
        foreach ($list as $f) {
            $ts = strtotime(date('Y') . '-' . sprintf('%02d-%02d', $f[1], $f[2]));
            if ($ts < $today) $ts = strtotime((date('Y') + 1) . '-' . sprintf('%02d-%02d', $f[1], $f[2]));
            $days = (int)round(($ts - $today) / 86400);
            if ($best === null || $days < $best['days']) {
                $best = array('name' => $f[0], 'days' => $days, 'date' => date('m-d', $ts));
            }
        }
        return $best;
    }
}

/** 当月日历数据（周一为一周之始） */
if (!function_exists('fo_calendar')) {
    function fo_calendar()
    {
        $y = (int)date('Y');
        $m = (int)date('n');
        $first = strtotime(date('Y-m-01'));
        $days = (int)date('t', $first);
        $offset = ((int)date('N', $first)) - 1; // 周一=0
        $today = (int)date('j');
        $cells = array();
        for ($i = 0; $i < $offset; $i++) $cells[] = 0;
        for ($d = 1; $d <= $days; $d++) $cells[] = $d;
        while (count($cells) % 7 !== 0) $cells[] = 0;
        return array(
            'year' => $y, 'month' => $m, 'today' => $today,
            'week' => (int)date('W'), 'cells' => $cells,
            'weekdays' => array('一', '二', '三', '四', '五', '六', '日'),
        );
    }
}

/** 年度产出（近 5 年每年文章数） */
if (!function_exists('fo_year_bars')) {
    function fo_year_bars($years = 4)
    {
        $out = array();
        try {
            $rows = rows('SELECT YEAR(created_at) AS y, COUNT(*) AS c FROM ' . moe_table('posts')
                . " WHERE type='post' AND status='published' GROUP BY YEAR(created_at)");
            $map = array();
            foreach ((array)$rows as $r) $map[(int)$r['y']] = (int)$r['c'];
            $cur = (int)date('Y');
            for ($i = $years - 1; $i >= 0; $i--) {
                $y = $cur - $i;
                $out[] = array('year' => $y, 'count' => isset($map[$y]) ? $map[$y] : 0);
            }
        } catch (Throwable $e) {
            $out = array();
        }
        return $out;
    }
}

/** 站点侧栏数据（一次查询聚合，失败时返回 0） */
if (!function_exists('fo_site_data')) {
    function fo_site_data()
    {
        $d = array('posts' => 0, 'comments' => 0, 'views' => 0, 'cats' => 0, 'last_update' => '', 'month_posts' => 0);
        try {
            $d['posts']    = (int)one('SELECT COUNT(*) FROM ' . moe_table('posts') . " WHERE type='post' AND status='published'");
            $d['comments'] = (int)one('SELECT COUNT(*) FROM ' . moe_table('comments') . " WHERE status='approved'");
            $d['views']    = (int)one('SELECT COALESCE(SUM(views),0) FROM ' . moe_table('posts') . " WHERE type='post' AND status='published'");
            $d['cats']     = (int)one('SELECT COUNT(*) FROM ' . moe_table('categories'));
            $d['last_update'] = (string)one('SELECT MAX(updated_at) FROM ' . moe_table('posts') . " WHERE type='post' AND status='published'");
            $d['month_posts'] = (int)one('SELECT COUNT(*) FROM ' . moe_table('posts') . " WHERE type='post' AND status='published' AND DATE_FORMAT(created_at,'%Y-%m') = ?", array(date('Y-m')));
        } catch (Throwable $e) {
            // 数据不可用时保持零值，页面仍可渲染
        }
        return $d;
    }
}

/** 距离建站日期的运行时长 */
if (!function_exists('fo_uptime')) {
    function fo_uptime()
    {
        $from = trim(fo_opt('run_from', ''));
        if ($from === '') {
            try { $from = (string)one('SELECT MIN(created_at) FROM ' . moe_table('posts') . " WHERE type='post' AND status='published'"); } catch (Throwable $e) { $from = ''; }
        }
        $ts = $from !== '' ? strtotime($from) : 0;
        if (!$ts || $ts > time()) return array('days' => 0, 'text' => '');
        $diff = time() - $ts;
        $days = (int)floor($diff / 86400);
        $hours = (int)floor(($diff % 86400) / 3600);
        $mins = (int)floor(($diff % 3600) / 60);
        $secs = (int)($diff % 60);
        return array(
            'days' => $days,
            'text' => $days . ' 天 ' . sprintf('%02d 小时 %02d 分 %02d 秒', $hours, $mins, $secs),
            'ts'   => $ts,
        );
    }
}

/** 评论区头像：无邮箱时用首字占位 */
if (!function_exists('fo_avatar')) {
    function fo_avatar($name, $email = '')
    {
        $email = trim((string)$email);
        if ($email !== '' && function_exists('md5')) {
            /* QQ 号邮箱：直接用 QQ 头像，国内访问稳定 */
            if (preg_match('/^(\d{4,12})@qq\.com$/i', $email, $m)) {
                return 'https://q1.qlogo.cn/g?b=qq&nk=' . $m[1] . '&s=100';
            }
            /* Cravatar 国内源（gravatar 镜像）：d=404 让无头像的邮箱返回 404，
               触发模板 img onerror 回退到首字母彩色占位，而不是灰色 mystery-man */
            return 'https://cravatar.cn/avatar/' . md5(strtolower($email)) . '?d=404&s=96';
        }
        return '';
    }
}

/** 默认头像：灰色人像（所有源都失败时的兜底，data URI 免请求） */
if (!function_exists('fo_avatar_default')) {
    function fo_avatar_default()
    {
        return "data:image/svg+xml;utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 96 96'%3E%3Crect width='96' height='96' fill='%23e6eef3'/%3E%3Ccircle cx='48' cy='37' r='17' fill='%23b9cbd6'/%3E%3Cpath d='M14 96c0-20 15-31 34-31s34 11 34 31z' fill='%23b9cbd6'/%3E%3C/svg%3E";
    }
}

/**
 * 评论表单的默认身份（登录用户自动带入昵称与邮箱）
 * 程序核心没有这个函数，模板自己补齐；同时兼容核心以后补上同名函数的情况。
 * @return array author email admin(bool) user(bool) uid(int)
 */
if (!function_exists('fo_comment_defaults')) {
    function fo_comment_defaults()
    {
        $out = array('author' => '', 'email' => '', 'admin' => false, 'user' => false, 'uid' => 0);
        // 程序 2.0.0 起统一用 current_user()；moe_current_user() 是旧名，已不存在
        if (!function_exists('current_user')) return $out;
        $u = current_user();
        if (!$u) return $out;

        $author = trim((string)($u['nickname'] ?? ''));
        if ($author === '') $author = trim((string)($u['username'] ?? ''));
        $out['author'] = $author;
        $out['email']  = trim((string)($u['email'] ?? ''));
        $out['uid']    = (int)($u['id'] ?? 0);
        $out['user']   = $out['uid'] > 0;
        $out['admin']  = $out['user'] && (($u['role'] ?? '') === 'admin');
        return $out;
    }
}

/**
 * 侧栏签到排行榜（2.1.1）
 * 数据全部来自程序核心 includes/points.php，模板只负责展示，
 * 因此换主题 / 关掉积分功能都不会报错。
 */
if (!function_exists('fo_rank_widget')) {
    function fo_rank_widget()
    {
        if (!function_exists('moe_pt_rank_board')) return '';
        $period = fo_opt('rank_period', 'week');
        $limit  = (int)fo_opt('rank_limit', '5');
        if ($limit < 3) $limit = 3;
        if ($limit > 12) $limit = 12;

        $board = moe_pt_rank_board($period, $limit);
        $rows  = isset($board['rows']) ? $board['rows'] : array();
        $label = function_exists('moe_pt_rank_label') ? moe_pt_rank_label($period) : '本周';
        $unit  = function_exists('moe_pt_name') ? moe_pt_name() : '积分';
        $all   = base_url() . 'user?a=points&rk=' . rawurlencode($period) . '#rank';

        /* 登录用户才显示自己的名次（登录用户不走进页面缓存，不会串号） */
        $me = null;
        if (function_exists('current_user') && function_exists('moe_pt_rank_me')) {
            $u = current_user();
            if ($u) $me = moe_pt_rank_me((int)$u['id'], $period);
        }

        $h = '<section class="fo-widget fo-rank">'
           . '<div class="fo-widget-head"><span>🏆 签到榜<em>' . e($label) . '</em></span>'
           . '<a class="fo-widget-more" href="' . e($all) . '">全部 ›</a></div>';

        if (!$rows) {
            $h .= '<p class="fo-rank-empty">' . e($label) . '还没有人签到，来做第一个吧～</p>';
        } else {
            $h .= '<div class="fo-rank-list">';
            foreach ($rows as $i => $r) {
                $no = $i + 1;
                $h .= '<a class="fo-rank-row" href="' . e($r['url'] !== '' ? $r['url'] : $all) . '" title="' . e($r['name']) . '">'
                    . '<span class="fo-rank-no n' . $no . '">' . $no . '</span>'
                    . '<img class="fo-rank-ava" src="' . e($r['avatar']) . '" alt="" width="26" height="26" loading="lazy" decoding="async">'
                    . '<span class="fo-rank-info"><b>' . e($r['name']) . '</b>'
                    . '<span>' . ((int)$r['streak'] > 0 ? '连签 ' . (int)$r['streak'] . ' 天' : '今日未签') . '</span></span>'
                    . '<span class="fo-rank-val">' . (int)$r['days'] . '<i>天</i></span>'
                    . '</a>';
            }
            $h .= '</div>';
        }

        $h .= '<div class="fo-rank-foot"><span>今日 <b>' . (int)$board['today'] . '</b> 人已签';
        if ((int)$board['signers'] > 0) $h .= ' · 共 <b>' . (int)$board['signers'] . '</b> 人</span>';
        else $h .= '</span>';
        if ($me && (int)$me['rank'] > 0) {
            $h .= '<a href="' . e($all) . '">我的排名 <b>#' . (int)$me['rank'] . '</b></a>';
        } elseif ($me) {
            $h .= '<a href="' . e($all) . '">去签到上榜 ›</a>';
        } else {
            $h .= '<a href="' . e(base_url() . 'user') . '">登录查看我的排名</a>';
        }
        $h .= '</div></section>';
        return $h;
    }
}

/** 数字缩写：33900 → 3.4w */
if (!function_exists('fo_num')) {
    function fo_num($n)
    {
        $n = (int)$n;
        if ($n >= 10000) return round($n / 10000, 1) . 'w';
        if ($n >= 1000) return round($n / 1000, 1) . 'k';
        return (string)$n;
    }
}

/**
 * 文章评论数批量查询（2.1.25）
 * 首页「左右图文 / 图文列表」两种列表样式要显示评论数，逐篇 count 会变成 N+1 次查询，
 * 这里按本页文章 ID 一次 GROUP BY 取回，返回 [文章ID => 评论数]；任何异常都退化为 0，不影响页面渲染。
 */
if (!function_exists('fo_comment_counts')) {
    function fo_comment_counts($posts)
    {
        static $cache = array();
        $ids = array();
        foreach ((array)$posts as $p) {
            $id = isset($p['id']) ? (int)$p['id'] : 0;
            if ($id > 0 && !array_key_exists($id, $cache)) $ids[$id] = $id;
        }
        if ($ids) {
            try {
                $rs = rows('SELECT post_id, COUNT(*) AS cnt FROM ' . moe_table('comments')
                    . " WHERE status='approved' AND post_id IN (" . implode(',', $ids) . ') GROUP BY post_id');
                foreach ((array)$rs as $r) $cache[(int)$r['post_id']] = (int)$r['cnt'];
            } catch (Throwable $e) {
                /* 统计失败不影响列表 */
            }
            foreach ($ids as $id) {
                if (!array_key_exists($id, $cache)) $cache[$id] = 0;
            }
        }
        return $cache;
    }
}

/** 友链显示域名：https://a.b/c → a.b */
if (!function_exists('fo_link_host')) {
    function fo_link_host($url)
    {
        $host = (string)parse_url((string)$url, PHP_URL_HOST);
        if ($host === '') $host = preg_replace('#^(https?://)?(www\.)?#i', '', (string)$url);
        return rtrim(preg_replace('#/.*$#', '', $host), '/');
    }
}

/** 友链简介映射：模板设置 friend_intro 每行「域名或站名|一句话简介」 */
if (!function_exists('fo_friend_intro_map')) {
    function fo_friend_intro_map()
    {
        static $map = null;
        if ($map !== null) return $map;
        $map = array();
        foreach (preg_split('/\r\n|\r|\n/', (string)fo_opt('friend_intro', '')) as $line) {
            $line = trim($line);
            if ($line === '' || strpos($line, '|') === false) continue;
            $p = array_map('trim', explode('|', $line, 2));
            if ($p[0] === '') continue;
            $map[strtolower($p[0])] = $p[1];
            $map[strtolower(preg_replace('#^(https?://)?(www\.)?#i', '', $p[0]))] = $p[1];
        }
        return $map;
    }
}

/** 友链页评论目标：模板设置 friend_comment_id > slug 命中 link/links/friends 的独立页面 > 0（虚拟留言板） */
if (!function_exists('fo_friend_comment_target')) {
    function fo_friend_comment_target()
    {
        $id = (int)fo_opt('friend_comment_id', '0');
        if ($id > 0) return $id;
        try {
            $hit = row('SELECT id FROM ' . moe_table('posts') . " WHERE type='page' AND slug IN ('link','links','friends','friend') ORDER BY id ASC LIMIT 1");
            if ($hit && !empty($hit['id'])) return (int)$hit['id'];
        } catch (Throwable $e) {
            // 查询失败时退回虚拟 ID
        }
        return 0;
    }
}
/** 友链申请：从评论内容里解析站点字段（支持中英文冒号、前后空格） */
if (!function_exists('fo_friend_parse')) {
    function fo_friend_parse($content)
    {
        $text = str_replace(array('：', '﹕', '∶'), ':', (string)$content);
        $get = function ($label) use ($text) {
            if (preg_match('/(?:^|\n)\s*' . $label . '\s*:\s*(.+)/u', $text, $m)) {
                $v = trim($m[1]);
                $v = preg_replace('/\s+/u', ' ', $v);
                if ($v !== '' && $v !== '您的' . $label) return $v;
            }
            return '';
        };

        $name = $get('站点名称');
        $desc = $get('站点描述');
        $url  = $get('站点链接');
        $logo = $get('头像链接');

        if ($url === '' || !preg_match('#^https?://#i', $url)) {
            /* 没写「站点链接」时，退而取正文里第一个不是本站的 http(s) 地址 */
            $hosts = function_exists('moe_site_hosts') ? moe_site_hosts() : array();
            if (preg_match_all('#https?://[^\s，,。；;）)】]+#iu', $text, $ms)) {
                foreach ($ms[0] as $u) {
                    $h = strtolower((string)parse_url($u, PHP_URL_HOST));
                    if ($h !== '' && !in_array($h, $hosts, true) && strpos($u, ':') !== false) { $url = $u; break; }
                }
            }
        }
        if ($url === '' || !preg_match('#^https?://#i', $url)) return null;

        return array(
            'name' => $name !== '' ? $name : '',
            'desc' => $desc,
            'url'  => $url,
            'logo' => $logo !== '' && preg_match('#^https?://#i', $logo) ? $logo : '',
        );
    }
}

/** 自动检测前的地址防护：只放行公网 http/https，挡掉本机与内网地址 */
if (!function_exists('fo_friend_url_safe')) {
    function fo_friend_url_safe($url)
    {
        $u = trim((string)$url);
        if ($u === '' || !preg_match('#^https?://#i', $u)) return false;
        $parts = parse_url($u);
        if (!$parts || empty($parts['host'])) return false;

        $host = strtolower($parts['host']);
        if ($host === 'localhost' || substr($host, -6) === '.local' || substr($host, -9) === '.internal') return false;
        if (isset($parts['port']) && !in_array((int)$parts['port'], array(80, 443), true)) return false;

        if (filter_var($host, FILTER_VALIDATE_IP)) {
            if (!filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return false;
        } elseif (strpos($host, '.') === false) {
            return false;
        }
        return true;
    }
}

/** 抓取对方页面（优先复用程序自带的 moe_http_get） */
if (!function_exists('fo_friend_fetch')) {
    function fo_friend_fetch($url, $timeout = 6)
    {
        if (function_exists('moe_http_get')) return (string)moe_http_get($url, $timeout);
        if (!function_exists('curl_init')) {
            /* 没有 curl 时退回 file_get_contents（与程序 linkcheck.php 的策略一致） */
            $ctx = stream_context_create(array(
                'http' => array('timeout' => $timeout, 'max_redirects' => 3, 'ignore_errors' => true,
                    'header' => "User-Agent: Mozilla/5.0 (compatible; Fomalhaut friend apply)
"),
                'ssl'  => array('verify_peer' => false, 'verify_peer_name' => false),
            ));
            return (string)@file_get_contents($url, false, $ctx);
        }
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 3,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; Fomalhaut friend apply)',
        ));
        $body = curl_exec($ch);
        curl_close($ch);
        return is_string($body) ? $body : '';
    }
}

/** 抓取 URL：返回 http 状态码与正文（curl 优先，缺失时退回 file_get_contents） */
if (!function_exists('fo_http_probe')) {
    function fo_http_probe($url, $timeout = 4)
    {
        $url = trim((string)$url);
        if ($url === '' || !preg_match('#^https?://#i', $url)) return array('code' => 0, 'body' => '');

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, array(
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS      => 3,
                CURLOPT_TIMEOUT        => $timeout,
                CURLOPT_CONNECTTIMEOUT => $timeout,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_SSL_VERIFYHOST => 0,
                CURLOPT_ENCODING       => '',
                CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; Fomalhaut link check)',
            ));
            $body = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            return array('code' => $code, 'body' => is_string($body) ? $body : '');
        }

        $ctx = stream_context_create(array(
            'http' => array('timeout' => $timeout, 'max_redirects' => 3, 'ignore_errors' => true,
                'header' => "User-Agent: Mozilla/5.0 (compatible; Fomalhaut link check)\r\n"),
            'ssl'  => array('verify_peer' => false, 'verify_peer_name' => false),
        ));
        $body = @file_get_contents($url, false, $ctx);
        $code = 0;
        if (!empty($http_response_header[0]) && preg_match('#\s(\d{3})\s#', $http_response_header[0], $m)) {
            $code = (int)$m[1];
        }
        return array('code' => $code, 'body' => is_string($body) ? $body : '');
    }
}

/** 申请站点候选页：提交链接、站点根、常见友链内页（最多 6 个） */
if (!function_exists('fo_friend_candidate_pages')) {
    function fo_friend_candidate_pages($url)
    {
        $url = trim((string)$url);
        $parts = parse_url($url);
        if (!$parts || empty($parts['host'])) return array();
        $scheme = isset($parts['scheme']) ? $parts['scheme'] : 'https';
        $origin = $scheme . '://' . $parts['host'] . (isset($parts['port']) ? ':' . $parts['port'] : '');

        $paths = array('/links', '/link', '/links.html', '/friend', '/friends', '/friendlinks', '/links/', '/about');
        $list = array($url, $origin . '/');
        foreach ($paths as $p) {
            $list[] = $origin . $p;
        }

        $out = array();
        foreach ($list as $u) {
            $u = (substr($u, -1) === '/' && strlen($u) > strlen($origin) + 1) ? rtrim($u, '/') : $u;
            $u = ($u === $origin . '/') ? $u : rtrim($u, '/');
            if (!in_array($u, $out, true)) $out[] = $u;
        }
        return array_slice($out, 0, 6);
    }
}

/** 判断页面是否存在指向本站的链接 */
if (!function_exists('fo_html_has_backlink')) {
    function fo_html_has_backlink($html, $hosts)
    {
        $html = (string)$html;
        if ($html === '' || empty($hosts)) return false;
        if (preg_match_all('#<a\b[^>]*href\s*=\s*(["\'])([^"\']+)\1#is', $html, $ms)) {
            foreach ($ms[2] as $href) {
                $h = strtolower((string)parse_url(trim($href), PHP_URL_HOST));
                $h = preg_replace('/^www\./', '', $h);
                if ($h !== '' && in_array($h, $hosts, true)) return true;
            }
        }
        foreach ($hosts as $h) {
            if ($h !== '' && stripos($html, $h) !== false) return true;
        }
        return false;
    }
}

/** 提交时的站点自检：首页 + 常见友链内页都看，返回是否可访问、是否含回链、命中页 */
if (!function_exists('fo_friend_backlink_check')) {
    function fo_friend_backlink_check($url, $needBacklink = true)
    {
        $hosts = function_exists('moe_site_hosts')
            ? array_map(function ($h) { return preg_replace('/^www\./', '', strtolower($h)); }, moe_site_hosts())
            : array();
        $pages = fo_friend_candidate_pages($url);
        if (empty($pages)) return array('ok' => false, 'alive' => false, 'title' => '', 'reason' => '站点地址无效', 'hit' => '');

        $alive = false;
        $title = '';
        $hit = '';

        foreach ($pages as $i => $page) {
            if (!fo_friend_url_safe($page)) continue;
            $res = fo_http_probe($page, 4);
            $code = (int)$res['code'];
            $body = (string)$res['body'];
            $pageOk = ($code === 0 ? trim($body) !== '' : ($code < 400 && trim($body) !== ''));
            if (!$pageOk) continue;

            $alive = true;
            if ($title === '' && preg_match('#<title[^>]*>(.*?)</title>#is', $body, $m)) {
                $title = trim(html_entity_decode(strip_tags($m[1]), ENT_QUOTES, 'UTF-8'));
                if (function_exists('mb_substr') && mb_strlen($title) > 60) $title = mb_substr($title, 0, 60);
            }
            if ($needBacklink) {
                if (fo_html_has_backlink($body, $hosts)) { $hit = $page; break; }
                if ($i >= 3) break;   /* 前 4 个页面没命中就收工，避免提交久等 */
            } else {
                $hit = $page;
                break;
            }
        }

        if (!$alive) {
            return array('ok' => false, 'alive' => false, 'title' => '', 'reason' => '无法访问对方站点（超时或拒绝连接）', 'hit' => '');
        }
        if (!$needBacklink) {
            return array('ok' => true, 'alive' => true, 'title' => $title, 'reason' => '站点可正常访问', 'hit' => $hit);
        }
        if ($hit !== '') {
            return array('ok' => true, 'alive' => true, 'title' => $title, 'reason' => '已在 ' . $hit . ' 检测到本站链接', 'hit' => $hit);
        }
        return array('ok' => false, 'alive' => true, 'title' => $title, 'reason' => '首页与常见友链内页均未检测到本站链接', 'hit' => '');
    }
}

/** 每日友链存活检测：一天最多跑一次，逐条写回检测结果与时间 */
if (!function_exists('fo_links_daily_check')) {
    function fo_links_daily_check($force = false)
    {
        if (!fo_on('link_auto_check', '1')) {
            return array('ok' => true, 'skipped' => 'disabled');
        }
        $last = (int)setting('themeopt_fomalhaut_linkcheck_at', '0');
        if (!$force && $last > 0 && (time() - $last) < 86400) {
            return array('ok' => true, 'skipped' => 'interval');
        }

        $limit = (int)fo_opt('link_check_limit', '5');
        $limit = max(1, min(10, $limit));

        try {
            $rows = rows('SELECT id, name, url, check_result FROM ' . moe_table('links')
                . " WHERE status='approved' AND url <> '' ORDER BY (last_check IS NULL) DESC, last_check ASC, id ASC LIMIT " . $limit);
        } catch (Throwable $e) {
            return array('ok' => false, 'skipped' => 'query');
        }

        $alive = 0;
        $dead = 0;
        foreach ((array)$rows as $r) {
            if (!fo_friend_url_safe($r['url'])) continue;
            $res = fo_http_probe($r['url'], 4);
            $code = (int)$res['code'];
            $body = (string)$res['body'];
            $ok = ($code === 0 ? trim($body) !== '' : ($code < 400 && trim($body) !== ''));

            try {
                if ($ok) {
                    $alive++;
                    if (stripos((string)$r['check_result'], '失联') === 0) {
                        q('UPDATE ' . moe_table('links') . ' SET check_result = ?, last_check = NOW() WHERE id = ?', array('已恢复（自动检测 ' . date('Y-m-d') . '）', $r['id']));
                    } else {
                        q('UPDATE ' . moe_table('links') . ' SET last_check = NOW() WHERE id = ?', array($r['id']));
                    }
                } else {
                    $dead++;
                    q('UPDATE ' . moe_table('links') . ' SET check_result = ?, last_check = NOW() WHERE id = ?', array('失联：无法访问（自动检测 ' . date('Y-m-d') . '）', $r['id']));
                }
            } catch (Throwable $e) {
                /* 单条写入失败不影响其它友链 */
            }
        }

        try {
            setting_set('themeopt_fomalhaut_linkcheck_at', (string)time());
        } catch (Throwable $e) {
            /* 设置写入失败时下次会再跑一次 */
        }

        return array('ok' => true, 'checked' => count((array)$rows), 'alive' => $alive, 'dead' => $dead);
    }
}

/** 友链是否被判为失联（按 check_result 前缀判断，与后台检测写回的格式一致） */
if (!function_exists('fo_link_is_dead')) {
    function fo_link_is_dead($link)
    {
        return isset($link['check_result']) && stripos((string)$link['check_result'], '失联') === 0;
    }
}

/**
 * 友链申请自动检测审批
 * 从评论解析站点信息 → 检测可访问与回链 → 达标直接写入友链，不达标存为待审核
 * @return array array('status' => 'added|pending|skip', 'msg' => string, 'name' => string)
 */
if (!function_exists('fo_friend_auto_apply')) {
    function fo_friend_auto_apply($content)
    {
        if (!fo_on('friend_auto_apply', '1')) return array('status' => 'skip', 'msg' => '', 'name' => '');

        $info = fo_friend_parse($content);
        if (!$info) return array('status' => 'skip', 'msg' => '', 'name' => '');

        if (!fo_friend_url_safe($info['url'])) {
            return array('status' => 'pending', 'msg' => '站点链接不是可访问的公网地址，已转人工审核', 'name' => $info['name']);
        }

        $host = preg_replace('/^www\./', '', strtolower((string)parse_url($info['url'], PHP_URL_HOST)));
        try {
            foreach ((array)rows('SELECT id, name, url FROM ' . moe_table('links')) as $l) {
                $h = preg_replace('/^www\./', '', strtolower((string)parse_url((string)$l['url'], PHP_URL_HOST)));
                if ($h !== '' && $h === $host) {
                    return array('status' => 'skip', 'msg' => '该站点已在友链中：' . $l['name'], 'name' => $info['name']);
                }
            }
        } catch (Throwable $e) {
            // 查询失败不阻断后续检测
        }

        $needBacklink = fo_on('friend_auto_need_backlink', '1');
        /* 首页 + 常见友链内页都检测，命中任一处含本站链接即通过 */
        $check = fo_friend_backlink_check($info['url'], $needBacklink);
        $ok = !empty($check['ok']);
        $title = (string)$check['title'];
        $reason = (string)$check['reason'];

        $name = $info['name'] !== '' ? $info['name'] : ($title !== '' ? $title : $host);
        $status = $ok ? 'approved' : 'pending';
        $check_note = $ok ? ('自动检测通过：' . $reason) : ('自动检测未通过：' . $reason);

        try {
            q('INSERT INTO ' . moe_table('links') . ' (name, url, logo, contact, status, check_result, last_check, sort, created_at) VALUES (?,?,?,?,?,?,NOW(),0,NOW())',
                array($name, $info['url'], $info['logo'], '', $status, $check_note));
        } catch (Throwable $e) {
            return array('status' => 'pending', 'msg' => '检测通过但写入友链失败，请人工处理', 'name' => $name);
        }

        return array(
            'status' => $ok ? 'added' : 'pending',
            'msg'    => $ok ? ('自动检测通过，已加入友链：' . $name) : ('自动检测未通过（' . $reason . '），已转人工审核'),
            'name'   => $name,
        );
    }
}

/** 卡片链接：独立页面走 page_url，文章走 post_url */
if (!function_exists('fo_item_url')) {
    function fo_item_url($item)
    {
        return (isset($item['type']) && $item['type'] === 'page') ? page_url($item) : post_url($item);
    }
}

/**
 * 解析模板设置里的自定义精选目标，支持三种写法：
 *   1) 纯数字 ID：12            → 文章 id=12
 *   2) 分类别名+编号：tech/12    → 分类别名 tech 下编号 12（也可写 tech/12.html）
 *   3) 独立页面别名：about.html  → 独立页面 slug=about（也兼容 page/about.html）
 * 解析不到返回 null，调用方回退到默认精选逻辑
 */
if (!function_exists('fo_custom_featured')) {
    function fo_custom_featured($raw)
    {
        $raw = trim((string)$raw);
        if ($raw === '') return null;

        $raw = preg_replace('#^https?://[^/]+/#i', '', $raw);   // 允许直接粘贴整条链接
        $raw = preg_replace('/[?#].*$/', '', $raw);
        $raw = trim($raw, '/');

        $select = 'SELECT p.*, c.name AS cat_name, c.slug AS cat_slug FROM ' . moe_table('posts') . ' p'
            . ' LEFT JOIN ' . moe_table('categories') . ' c ON c.id = p.category_id';

        try {
            /* 独立页面：page/别名.html 或 裸 别名.html */
            if (preg_match('#^(?:page/)?([^/]+?)\.html$#i', $raw, $m)) {
                $pg = row('SELECT * FROM ' . moe_table('posts') . " WHERE type='page' AND slug = ? LIMIT 1", array($m[1]));
                if ($pg) return $pg;
                $po = row($select . " WHERE p.type='post' AND p.status='published' AND p.slug = ? LIMIT 1", array($m[1]));
                if ($po) return $po;
            }
            /* 分类别名 + 编号（编号按分类独立，也兼容写文章 ID） */
            if (preg_match('#^([^/]+)/(\d+)(?:\.html)?$#', $raw, $m)) {
                $num = (int)$m[2];
                $po = row($select . " WHERE p.type='post' AND p.status='published' AND c.slug = ? AND (p.url_num = ? OR p.id = ?) LIMIT 1",
                    array($m[1], $num, $num));
                if ($po) return $po;
            }
            /* 纯数字 ID 或 编号.html */
            if (preg_match('#^(\d+)(?:\.html)?$#', $raw, $m)) {
                $num = (int)$m[1];
                $po = row($select . " WHERE p.type='post' AND p.status='published' AND p.id = ? LIMIT 1", array($num));
                if ($po) return $po;
                $po = row($select . " WHERE p.type='post' AND p.status='published' AND p.url_num = ? LIMIT 1", array($num));
                if ($po) return $po;
            }
        } catch (Throwable $e) {
            return null;
        }
        return null;
    }
}

/**
 * 2.1.4：首页精选大卡文章 ID（核心首页查询用它把大卡文章从列表中整体排除，
 *        从而保证任何模式下每页卡片数严格 = 后台「每页文章数」且不漏文章）。
 * 结果在本次请求内缓存（static）：核心排除的与模板大卡展示的必须是同一篇，
 * 随机模式下两次独立抽取会不一致，这里必须只抽一次。
 */
if (!function_exists('fo_home_featured_id')) {
    function fo_home_featured_id()
    {
        /* 按模式缓存：同一次请求内同一模式只抽一次（随机模式核心与模板必须同篇） */
        static $pick = array();
        $modeKey = fo_on('show_featured', '1') ? fo_opt('featured_mode', 'latest') : 'off';
        if (isset($pick[$modeKey])) return $pick[$modeKey];
        $id = 0;
        try {
            if ($modeKey !== 'off') {
                $pq = 'SELECT p.id FROM ' . moe_table('posts') . " p WHERE p.type='post' AND p.status='published'";
                if ($modeKey === 'custom') {
                    $target = trim(fo_opt('featured_custom_id', ''));
                    if ($target !== '') {
                        $fp = fo_custom_featured($target);
                        $id = $fp ? (int)$fp['id'] : 0;
                    }
                } elseif ($modeKey === 'hot') {
                    $r = row($pq . ' ORDER BY p.views DESC, p.id DESC LIMIT 1');
                    $id = $r ? (int)$r['id'] : 0;
                } elseif ($modeKey === 'random') {
                    $pool = rows($pq . ' ORDER BY p.created_at DESC, p.id DESC LIMIT 200');
                    if (!empty($pool)) $id = (int)$pool[array_rand($pool)]['id'];
                } else {
                    $r = row($pq . ' ORDER BY p.is_top DESC, p.created_at DESC, p.id DESC LIMIT 1');
                    $id = $r ? (int)$r['id'] : 0;
                }
            }
        } catch (Throwable $e) {
            $id = 0;
        }
        return $pick[$modeKey] = $id;
    }
}
