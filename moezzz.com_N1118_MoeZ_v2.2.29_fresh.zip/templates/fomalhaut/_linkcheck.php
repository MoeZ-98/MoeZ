<?php
/**
 * 星辉 · Fomalhaut · 友链每日检测端点
 *
 * 由友链页在前端空闲时触发（每天最多真正执行一次，节流记在设置里），
 * 逐条请求已审核友链，写回 check_result / last_check，失联的会在友链页单独展示。
 */
require dirname(dirname(__DIR__)) . '/init.php';
require __DIR__ . '/_lib.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_exit(false, '非法请求');
}

csrf_verify();

$res = fo_links_daily_check();

json_exit(true, 'ok', is_array($res) ? $res : array());