<?php
/**
 * 星辉 · Fomalhaut 模板 · 搜索结果
 * 可用变量：$posts $kw $pager $total $site
 */
$cur_p = 'article';
include partial_path('header.php');

$fo_hero_img = trim(fo_opt('hero_bg', ''));
$fo_hero_img = $fo_hero_img !== '' ? media_url($fo_hero_img) : theme_url('assets/hero.svg');
?>
<section class="fo-hero fo-hero--small" style="background-image:linear-gradient(180deg,rgba(14,32,52,.28),rgba(14,32,52,.52)),url('<?php echo e($fo_hero_img); ?>')">
  <div class="fo-hero-center">
    <h1 class="fo-hero-title fo-hero-title--sm">搜索</h1>
    <p class="fo-hero-sub"><?php echo $kw !== '' ? '「' . e($kw) . '」的结果 · ' . (int)$total . ' 篇' : '输入关键词，在站内找找看'; ?></p>
  </div>
</section>

<div class="fo-wrap fo-wrap--single">
  <div class="fo-panel">
    <form class="fo-search" method="get" action="<?php echo e(base_url() . 'index.php'); ?>"
          data-pretty="<?php echo is_pretty_url() ? '1' : '0'; ?>" data-base="<?php echo e(base_url()); ?>">
      <input type="hidden" name="p" value="search">
      <input class="fo-search-input" type="text" name="q" value="<?php echo e($kw); ?>" placeholder="想要搜点儿什么?" autocomplete="off">
      <button class="fo-btn" type="submit">搜索</button>
    </form>

    <?php if (!empty($posts)): ?>
    <div class="fo-search-list">
      <?php foreach ((array)$posts as $p): ?>
        <a class="fo-search-item" href="<?php echo e(post_url($p)); ?>">
          <div class="fo-search-item-body">
            <h3><?php echo e($p['title']); ?></h3>
            <p><?php echo e(post_excerpt($p, 110)); ?></p>
          </div>
          <div class="fo-search-item-meta">
            <span><?php echo e(format_time($p['created_at'], 'Y-m-d')); ?></span>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
    <?php echo $pager; ?>
    <?php else: ?>
      <p class="fo-empty"><?php echo $kw !== '' ? '没有找到相关文章，换个关键词试试' : '还没有输入关键词'; ?></p>
    <?php endif; ?>
  </div>
</div>


<?php include partial_path('footer.php'); ?>