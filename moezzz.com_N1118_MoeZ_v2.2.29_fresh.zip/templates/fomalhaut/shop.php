<?php
/**
 * 星辉 · Fomalhaut 模板 · 积分商城视图
 * 由 page.php 在页面别名等于 shop_slug 时引入（header 已输出）
 * 可用变量：$page $site
 */
require_once __DIR__ . '/_shop.php';

$fo_shop_uid = fo_shop_uid();
$fo_shop_ready = fo_shop_ready();
$fo_shop_msg = '';
$fo_shop_ok = null;

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && !empty($_POST['fo_buy'])) {
    csrf_verify();
    $fo_buy = fo_order_buy($fo_shop_uid, (int)$_POST['fo_buy']);
    $fo_shop_ok = (bool)$fo_buy['ok'];
    $fo_shop_msg = (string)$fo_buy['msg'];
}

$fo_goods = $fo_shop_ready ? fo_goods_list(true) : array();
$fo_orders = $fo_shop_uid > 0 ? fo_user_orders($fo_shop_uid) : array();
$fo_balance = $fo_shop_uid > 0 ? fo_points_balance($fo_shop_uid) : 0;
$fo_points_unit = fo_points_name();

$fo_shop_intro = trim(fo_opt('shop_intro', ''));
if ($fo_shop_intro === '') {
    $fo_shop_intro = '用积分兑换站内的下载资源：登录后每天签到、发表评论都能攒积分，兑换成功后到「下载中心」获取下载地址。';
}
$fo_hero_img = trim(fo_opt('hero_bg', ''));
$fo_hero_img = $fo_hero_img !== '' ? media_url($fo_hero_img) : theme_url('assets/hero.svg');
$fo_downloads_url = '';
$fo_dl_slug = trim(fo_opt('downloads_slug', 'downloads'));
if ($fo_dl_slug !== '') $fo_downloads_url = base_url() . 'page/' . rawurlencode($fo_dl_slug) . '.html';
?>
<section class="fo-hero fo-hero--small" style="background-image:linear-gradient(180deg,rgba(14,32,52,.28),rgba(14,32,52,.52)),url('<?php echo e($fo_hero_img); ?>')">
  <div class="fo-hero-center">
    <h1 class="fo-hero-title fo-hero-title--sm">积分商城</h1>
    <p class="fo-hero-sub">攒 <?php echo e($fo_points_unit); ?>，换资源</p>
  </div>
</section>

<div class="fo-wrap fo-wrap--single fo-wrap--nohero">
  <div class="fo-panel">
    <div class="fo-shop-head">
      <div class="fo-shop-head-main">
        <h2 class="fo-shop-title">可兑换资源 <span><?php echo count($fo_goods); ?></span></h2>
        <div class="fo-prose fo-shop-intro"><?php echo render_content($fo_shop_intro, 'markdown'); ?></div>
      </div>
      <div class="fo-shop-wallet">
        <?php if ($fo_shop_uid > 0): ?>
          <span class="fo-shop-wallet-label">我的<?php echo e($fo_points_unit); ?></span>
          <b><?php echo (int)$fo_balance; ?></b>
          <a class="fo-btn fo-btn--ghost fo-shop-wallet-link" href="<?php echo e(base_url() . 'user?a=points'); ?>">签到赚积分</a>
          <?php if ($fo_downloads_url !== ''): ?><a class="fo-btn fo-btn--ghost fo-shop-wallet-link" href="<?php echo e($fo_downloads_url); ?>">下载中心</a><?php endif; ?>
        <?php else: ?>
          <span class="fo-shop-wallet-label">登录后可签到攒 <?php echo e($fo_points_unit); ?></span>
          <a class="fo-btn fo-shop-login" href="<?php echo e(base_url() . 'user'); ?>">去登录</a>
        <?php endif; ?>
      </div>
    </div>

    <?php if (!$fo_shop_ready): ?>
      <p class="fo-empty">积分数据表还没建好，请确认数据库账号有建表权限后刷新一次。</p>
    <?php elseif ($fo_shop_msg !== ''): ?>
      <p class="fo-shop-msg <?php echo $fo_shop_ok ? 'is-ok' : 'is-err'; ?>"><?php echo e($fo_shop_msg); ?></p>
    <?php endif; ?>

    <?php if (!empty($fo_goods)): ?>
    <div class="fo-shop-grid">
      <?php foreach ($fo_goods as $g): ?>
        <?php
          $gid = (int)$g['id'];
          $price = (int)$g['price'];
          $bought = isset($fo_orders[$gid]);
        ?>
        <article class="fo-shop-card">
          <div class="fo-shop-cover"<?php if (!empty($g['cover'])): ?> style="background-image:url('<?php echo e(media_url($g['cover'])); ?>')"<?php else: ?> style="background:<?php echo e(fo_gradient($gid)); ?>"<?php endif; ?>>
            <?php if ($bought): ?><span class="fo-shop-badge is-owned">已兑换</span><?php endif; ?>
          </div>
          <div class="fo-shop-body">
            <h3 class="fo-shop-card-title"><?php echo e($g['title']); ?></h3>
            <?php if (!empty($g['summary'])): ?><p class="fo-shop-card-desc"><?php echo e($g['summary']); ?></p><?php endif; ?>
            <div class="fo-shop-meta">
              <span class="fo-shop-price"><?php echo $price > 0 ? ((int)$price . ' ' . e($fo_points_unit)) : '免费'; ?></span>
              <span class="fo-shop-dl"><?php echo (int)$g['downloads']; ?> 次下载</span>
            </div>
            <div class="fo-shop-actions">
              <?php if ($bought): ?>
                <a class="fo-btn fo-shop-btn" href="<?php echo e(theme_url('_download.php')); ?>?g=<?php echo $gid; ?>">下载</a>
              <?php elseif ($fo_shop_uid <= 0): ?>
                <a class="fo-btn fo-btn--ghost fo-shop-btn" href="<?php echo e(base_url() . 'user'); ?>">登录后兑换</a>
              <?php else: ?>
                <form method="post" class="fo-shop-form">
                  <?php echo csrf_field(); ?>
                  <button class="fo-btn fo-shop-btn" type="submit" name="fo_buy" value="<?php echo $gid; ?>">兑换</button>
                </form>
              <?php endif; ?>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
      <p class="fo-empty">还没有上架资源，去后台「商城管理」添加吧。</p>
    <?php endif; ?>
  </div>
</div>