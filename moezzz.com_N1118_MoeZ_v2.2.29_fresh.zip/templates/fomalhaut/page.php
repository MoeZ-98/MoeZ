<?php
/**
 * 星辉 · Fomalhaut 模板 · 独立页面
 * 别名等于模板设置 stats_slug 的页面会渲染成「文章统计」，
 * 其余页面按普通文章样式输出 Markdown / HTML 正文。
 * 可用变量：$page $site $nav_cats
 */
require_once __DIR__ . '/_lib.php';

$fo_slug = isset($page['slug']) ? (string)$page['slug'] : '';
$fo_stats_slug = trim(fo_opt('stats_slug', 'stats'));
$fo_is_stats = ($fo_stats_slug !== '' && $fo_slug === $fo_stats_slug);

if ($fo_is_stats) {
    $cur_p = 'stats';
    include partial_path('header.php');
    include partial_path('stats.php');
    include partial_path('footer.php');
    return;
}

/* 积分商城与下载中心：同样用「页面别名」承载 */
$fo_shop_slug = trim(fo_opt('shop_slug', 'shop'));
$fo_dl_slug = trim(fo_opt('downloads_slug', 'downloads'));

if ($fo_shop_slug !== '' && $fo_slug === $fo_shop_slug) {
    $cur_p = 'shop';
    $page_title = trim((string)$page['title']) !== '' ? $page['title'] : '积分商城';
    include partial_path('header.php');
    include partial_path('shop.php');
    include partial_path('footer.php');
    return;
}

if ($fo_dl_slug !== '' && $fo_slug === $fo_dl_slug) {
    $cur_p = 'downloads';
    $page_title = trim((string)$page['title']) !== '' ? $page['title'] : '下载中心';
    include partial_path('header.php');
    include partial_path('downloads.php');
    include partial_path('footer.php');
    return;
}

$cur_p = 'page';
$page_title = $page['title'];
include partial_path('header.php');

$fo_hero_img = trim(fo_opt('hero_bg', ''));
$fo_hero_img = $fo_hero_img !== '' ? media_url($fo_hero_img) : theme_url('assets/hero.svg');
?>
<section class="fo-hero fo-hero--small" style="background-image:linear-gradient(180deg,rgba(14,32,52,.28),rgba(14,32,52,.52)),url('<?php echo e($fo_hero_img); ?>')">
  <div class="fo-hero-center">
    <h1 class="fo-hero-title fo-hero-title--sm"><?php echo e($page['title']); ?></h1>
    <p class="fo-hero-sub">更新于 <?php echo e(format_time($page['updated_at'], 'Y-m-d')); ?></p>
  </div>
</section>

<div class="fo-wrap fo-wrap--single">
  <div class="fo-panel fo-panel--article">
    <div class="fo-prose">
      <?php echo render_content($page['content'], isset($page['content_format']) ? $page['content_format'] : 'html'); ?>
    </div>
  </div>
</div>

<?php include partial_path('footer.php'); ?>