<?php
/**
 * 星辉 · Fomalhaut 模板 · 友情链接（/link）
 * 版式参照「大卡片 + 头像横滚 + 搜索 / 状态筛选 + 友链卡片网格 + 申请说明 + 评论」的友链页
 * 可用变量：$links $site
 */
$cur_p = 'link';
include partial_path('header.php');

/* 失联友链单独归类：正常友链进卡片网格，失联的放到页面下方单独区块 */
$fo_friends = array();
$fo_dead_links = array();
foreach ((array)$links as $fo_l) {
    if (function_exists('fo_link_is_dead') && fo_link_is_dead($fo_l)) {
        $fo_dead_links[] = $fo_l;
    } else {
        $fo_friends[] = $fo_l;
    }
}
$fo_intro_map = fo_friend_intro_map();

$fo_desc = trim(fo_opt('link_desc', ''));
if ($fo_desc === '') $fo_desc = '这里是我的朋友们，欢迎互相访问交流';


/* 友链卡片状态：根据后台「检查结果」归类，用于筛选与徽章 */
$fo_state_of = function ($l) {
    $r = strtolower(trim((string)($l['check_result'] ?? '')));
    if ($r === '') return array('key' => 'unknown', 'text' => '待检测', 'cls' => 'is-unknown');
    if (preg_match('/失败|超时|错误|无法|fail|timeout|error|refused|404|50[0-9]/', $r)) return array('key' => 'down', 'text' => '异常', 'cls' => 'is-down');
    if (preg_match('/正常|成功|200|ok|可访问/', $r)) return array('key' => 'ok', 'text' => '可访问', 'cls' => 'is-ok');
    return array('key' => 'unknown', 'text' => fo_substr($r, 0, 12), 'cls' => 'is-unknown');
};

/* 友链页评论：与程序评论表共用，绑定 ID 见 _lib.php 的 fo_friend_comment_target() */
$fo_cmt_on = fo_on('friend_comment', '1');
$fo_cmt_target = $fo_cmt_on ? fo_friend_comment_target() : 0;
$fo_cmt_comments = array();
if ($fo_cmt_on) {
    try {
        $fo_cmt_comments = rows('SELECT * FROM ' . moe_table('comments') . " WHERE post_id = ? AND status='approved' ORDER BY id DESC", array($fo_cmt_target));
    } catch (Throwable $e) {
        $fo_cmt_comments = array();
    }
}

/* 友链信息卡 / 申请友链 / 注意事项：内置在友链页，不依赖独立文件 */
$fo_fi_name = trim((string)$site['name']);
$fo_fi_desc = trim((string)$site['desc']);
if ($fo_fi_desc === '') $fo_fi_desc = trim((string)$site['signature']);
if ($fo_fi_desc === '') $fo_fi_desc = trim((string)$site['sub']);
$fo_fi_url = base_url();
$fo_fi_avatar = !empty($site['avatar']) ? media_url($site['avatar']) : theme_url('assets/avatar.svg');
/* 主页截图用模板头图（对应设置已移除） */
$fo_fi_shot = theme_url('assets/hero.svg');

$fo_fi_note = '可按下方模板留言，也可以使用您自己的格式。站长看到后会尽快回复，是否添加由站长决定。';

$fo_fi_rules = array(
    '互换原则：请先将本站添加到您的友链页面，确认后会添加您的友链',
    '链接维护：友链网站长期无法访问或内容违规，将会被移除',
    '内容要求：内容积极向上，不含有任何色情/反动/暴力等违法违规内容',
    '站点要求：支持 HTTPS，以原创内容为主，能够正常访问且有持续更新',
);

$fo_fi_apply = trim(fo_opt('link_apply', ''));

$fo_fi_tpl = "\n站点名称：\n站点描述：\n站点链接：\n头像链接：";

/* 复制按钮图标 */
$fo_fi_copy_icon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2.4"></rect><path d="M15 5.6A2.6 2.6 0 0 0 12.4 3H6.6A2.6 2.6 0 0 0 4 5.6v5.8A2.6 2.6 0 0 0 6.6 14"></path></svg>';
?>
<div class="fo-wrap fo-wrap--single fo-wrap--nohero">
  <div class="fo-fr-panel">

    <header class="fo-fr-head">
      <div class="fo-fr-title-row">
        <span class="fo-fr-ico" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="9" cy="8" r="3.2"></circle><path d="M3.2 20c0-3.2 2.6-5.4 5.8-5.4s5.8 2.2 5.8 5.4"></path>
            <circle cx="17" cy="9.4" r="2.4"></circle><path d="M17.6 14.4c3 0 5 1.9 5 4.6"></path>
          </svg>
        </span>
        <h1 class="fo-fr-title">友情链接</h1>
        <span class="fo-fr-count"><?php echo count($fo_friends); ?> 个</span>
      </div>
      <p class="fo-fr-sub"><?php echo e($fo_desc); ?></p>

      <div class="fo-fr-actions">
        <a class="fo-fr-chip fo-fr-chip--main" href="#fo-fri-apply">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 20l4-1 10-10a2.1 2.1 0 0 0-3-3L5 16l-1 4z"></path></svg>
          申请友链
        </a>
        <?php if (trim(fo_opt('link_apply', '')) !== ''): ?>
        <a class="fo-fr-chip" href="#fo-fri-apply">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5.5A1.5 1.5 0 0 1 5.5 4H10l2 2h6.5A1.5 1.5 0 0 1 20 7.5v11A1.5 1.5 0 0 1 18.5 20h-13A1.5 1.5 0 0 1 4 18.5z"></path></svg>
          友链规范
        </a>
        <?php endif; ?>
        <?php if (count($fo_friends) > 1): ?>
        <button class="fo-fr-chip" type="button" id="fo-fr-random">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"></path></svg>
          随机漫游
        </button>
        <?php endif; ?>
      </div>
    </header>

    <?php if (count($fo_friends) > 3): ?>
    <div class="fo-fr-marquee" aria-hidden="true">
      <div class="fo-fr-marquee-track">
        <?php for ($fo_round = 0; $fo_round < 2; $fo_round++): ?>
          <?php foreach ($fo_friends as $l): ?>
            <?php $fo_ava = !empty($l['logo']) ? media_url($l['logo']) : ''; ?>
            <span class="fo-fr-ava-sm" data-name="<?php echo e($l['name']); ?>">
              <b><?php echo e(initial($l['name'])); ?></b>
              <?php if ($fo_ava !== ''): ?>
                <img src="<?php echo e($fo_ava); ?>" alt="" width="38" height="38" loading="lazy" decoding="async" style="display:none" onload="this.style.display='block'" onerror="this.remove()">
              <?php endif; ?>
            </span>
          <?php endforeach; ?>
        <?php endfor; ?>
      </div>
    </div>
    <?php endif; ?>

    <div class="fo-fr-tools">
      <label class="fo-fr-search">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="11" cy="11" r="6.5"></circle><path d="M16 16l4 4"></path></svg>
        <input type="search" id="fo-fr-search" placeholder="搜索友链…" autocomplete="off">
      </label>
      <div class="fo-fr-filters" id="fo-fr-filters">
        <button type="button" class="fo-fr-filter is-active" data-state="all">全部</button>
        <button type="button" class="fo-fr-filter" data-state="ok">可访问</button>
        <button type="button" class="fo-fr-filter" data-state="down">异常</button>
        <button type="button" class="fo-fr-filter" data-state="unknown">待检测</button>
      </div>
    </div>

    <div class="fo-fr-grid" id="fo-fr-grid">
      <?php foreach ($fo_friends as $l): ?>
        <?php
          $fo_host = fo_link_host($l['url']);
          $fo_intro = '';
          foreach (array(strtolower($fo_host), strtolower((string)$l['name']), strtolower((string)preg_replace('#^https?://#i', '', (string)$l['url']))) as $fo_key) {
              if ($fo_key !== '' && isset($fo_intro_map[$fo_key])) { $fo_intro = $fo_intro_map[$fo_key]; break; }
          }
          $fo_state = $fo_state_of($l);
          $fo_logo = !empty($l['logo']) ? media_url($l['logo']) : '';
        ?>
        <a class="fo-fr-card" href="<?php echo e($l['url']); ?>" target="_blank" rel="noopener nofollow"
           data-name="<?php echo e($l['name']); ?>" data-host="<?php echo e($fo_host); ?>" data-state="<?php echo e($fo_state['key']); ?>">
          <span class="fo-fr-card-glow" aria-hidden="true"></span>
          <span class="fo-fr-ava">
            <?php if ($fo_logo !== ''): ?>
              <img src="<?php echo e($fo_logo); ?>" alt="<?php echo e($l['name']); ?>" width="60" height="60" loading="lazy" decoding="async"
                   onerror="this.style.display='none';this.parentNode.classList.add('is-ph')">
              <b class="fo-fr-ph"><?php echo e(initial($l['name'])); ?></b>
            <?php else: ?>
              <b class="fo-fr-ph is-on"><?php echo e(initial($l['name'])); ?></b>
            <?php endif; ?>
          </span>
          <span class="fo-fr-body">
            <span class="fo-fr-card-head">
              <b class="fo-fr-name"><?php echo e($l['name']); ?></b>
              <em class="fo-fr-state <?php echo e($fo_state['cls']); ?>"><i></i><?php echo e($fo_state['text']); ?></em>
            </span>
            <span class="fo-fr-desc"><?php echo e($fo_intro !== '' ? $fo_intro : $fo_host); ?></span>
            <span class="fo-fr-tags">
              <?php if (!empty($l['created_at'])): ?><span class="fo-fr-tag">收录 <?php echo e(date('m-d', strtotime((string)$l['created_at']))); ?></span><?php endif; ?>
              <?php if (!empty($l['last_check'])): ?><span class="fo-fr-tag is-time">检测于 <?php echo e(date('m-d', strtotime((string)$l['last_check']))); ?></span><?php endif; ?>
            </span>
          </span>
          <span class="fo-fr-go" aria-hidden="true">↗</span>
        </a>
      <?php endforeach; ?>
    </div>

    <p class="fo-fr-empty" id="fo-fr-empty" hidden>没有匹配的友链，换个关键词试试～</p>
    <?php if (empty($fo_friends)): ?><p class="fo-empty">还没有友链，去后台「友情链接」添加吧</p><?php endif; ?>

<?php if (fo_on('show_dead_links', '1') && !empty($fo_dead_links)): ?>
<section class="fo-fr-dead">
  <details>
    <summary><span class="fo-fr-dead-title">失联友链</span><em><?php echo count($fo_dead_links); ?></em><i>这些站点当前无法访问，已自动标记，恢复后会自动回到上方列表</i></summary>
    <ul class="fo-fr-dead-list">
      <?php foreach ($fo_dead_links as $fo_dl): ?>
        <?php $fo_dl_host = fo_link_host($fo_dl['url']); ?>
        <li>
          <a href="<?php echo e($fo_dl['url']); ?>" target="_blank" rel="noopener nofollow"><?php echo e($fo_dl['name']); ?></a>
          <span class="fo-fr-dead-host"><?php echo e($fo_dl_host); ?></span>
          <?php if (!empty($fo_dl['last_check'])): ?><span class="fo-fr-dead-time">检测于 <?php echo e(date('m-d H:i', strtotime((string)$fo_dl['last_check']))); ?></span><?php endif; ?>
        </li>
      <?php endforeach; ?>
    </ul>
  </details>
</section>
<?php endif; ?>

<section class="fo-fi-wrap" id="fo-fri-apply">
  <div class="fo-fi-grid">

    <article class="fo-fi-card fo-fi-info">
      <header class="fo-fi-head">
        <span class="fo-fi-ava">
          <img src="<?php echo e($fo_fi_avatar); ?>" alt="<?php echo e($fo_fi_name); ?>" loading="lazy">
          <i aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.8 10 18l9-10"></path></svg></i>
        </span>
        <div class="fo-fi-head-text">
          <h2><?php echo e($fo_fi_name); ?></h2>
          <p><?php echo e($fo_fi_desc); ?></p>
        </div>
      </header>

      <div class="fo-fi-fields">
        <?php
        $fo_fi_rows = array(
            array('label' => '站点名称', 'value' => $fo_fi_name),
            array('label' => '站点描述', 'value' => $fo_fi_desc),
            array('label' => '站点链接', 'value' => $fo_fi_url),
            array('label' => '头像链接', 'value' => $fo_fi_avatar),
        );
        foreach ($fo_fi_rows as $fo_fi_row):
        ?>
        <div class="fo-fi-field">
          <div class="fo-fi-field-main">
            <span><?php echo e($fo_fi_row['label']); ?></span>
            <b><?php echo e($fo_fi_row['value']); ?></b>
          </div>
          <button type="button" class="fo-fi-copy" data-copy="<?php echo e($fo_fi_row['value']); ?>" aria-label="复制<?php echo e($fo_fi_row['label']); ?>" title="复制">
            <?php echo $fo_fi_copy_icon; ?>
          </button>
        </div>
        <?php endforeach; ?>
      </div>
    </article>

    <article class="fo-fi-card fo-fi-apply">
      <h2 class="fo-fi-title">
        <span class="fo-fi-tag" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="4" width="12" height="17" rx="2.4"></rect><path d="M9 3.5h6v3H9z"></path><path d="M9 11h6M9 15h4"></path></svg></span>
        申请友链
      </h2>

      <?php if ($fo_fi_apply !== ''): ?>
        <div class="fo-fi-prose"><?php echo render_content($fo_fi_apply, 'markdown'); ?></div>
      <?php endif; ?>

      <ol class="fo-fi-steps">
        <li>
          <i aria-hidden="true">1</i>
          <div class="fo-fi-step">
            <h3>添加本站友链</h3>
            <p>请先在您的网站友链页面添加本站信息，可直接复制左侧各字段</p>
            <p class="fo-fi-hl"><?php echo e($fo_fi_note); ?></p>
          </div>
        </li>
        <li>
          <i aria-hidden="true">2</i>
          <div class="fo-fi-step">
            <h3>在评论区留言</h3>
            <p>请复制下方申请模板，修改后在评论区发送</p>
            <div class="fo-fi-tpl">
              <pre id="fo-fi-tpl-text"><?php echo e($fo_fi_tpl); ?></pre>
              <button type="button" class="fo-fi-copy fo-fi-copy--tpl" data-copy-target="fo-fi-tpl-text" aria-label="复制申请模板" title="复制模板">
                <?php echo $fo_fi_copy_icon; ?>
              </button>
            </div>
          </div>
        </li>
        <li>
          <i aria-hidden="true">3</i>
          <div class="fo-fi-step">
            <h3>等待审核</h3>
            <p>确认信息无误后会尽快添加您的友链</p>
          </div>
        </li>
      </ol>
    </article>
  </div>

  <article class="fo-fi-card fo-fi-rules">
    <h2 class="fo-fi-rules-title">
      <span aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"></circle><path d="M12 10.6v6"></path><path d="M12 7.4h.01"></path></svg></span>
      注意事项
    </h2>
    <ul class="fo-fi-rule-list">
      <?php foreach ($fo_fi_rules as $fo_rule): ?>
        <?php
        $fo_rule_html = e($fo_rule);
        if (preg_match('/^([^：:]{1,12})[：:]\s*(.+)$/u', $fo_rule, $m)) {
            $fo_rule_html = '<b>' . e($m[1]) . '：</b>' . e($m[2]);
        }
        ?>
        <li><?php echo $fo_rule_html; ?></li>
      <?php endforeach; ?>
    </ul>
  </article>

  <p class="fo-fi-toast" id="fo-fi-toast" hidden>已复制到剪贴板</p>
</section>

    <?php if (fo_on('link_auto_check', '1')): ?>
      <span id="fo-fr-linkcheck" data-url="<?php echo e(theme_url('_linkcheck.php')); ?>" data-token="<?php echo e(function_exists('csrf_token') ? csrf_token() : ''); ?>" hidden></span>
    <?php endif; ?>

    <?php if ($fo_cmt_on): ?>
      <?php
      $fo_cmt_action = theme_url('_comment.php');
      $fo_cmt_title = '评论';
      $fo_cmt_lead = '分享你的想法，与大家交流讨论；想交换友链也可以直接在这里留言。';
      $fo_cmt_anchor = 'fo-fr-comment';
      include partial_path('part-comments.php');
      ?>
    <?php endif; ?>

  </div>
</div>




<?php include partial_path('footer.php'); ?>
