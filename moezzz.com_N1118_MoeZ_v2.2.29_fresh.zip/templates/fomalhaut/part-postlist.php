<?php
/**
 * 星辉 · Fomalhaut 模板 · 首页文章列表片段（2.1.26）
 *
 * 调用方（index.php）先设置两个变量：
 *   $fo_posts   文章行数组（核心首页查询结果，已在本页排除精选大卡）
 *   $fo_layout  显示样式：
 *               grid 卡片网格（封面 + 标题 + 摘要）
 *               side 左右图文（大图与文字左右交错，杂志感）
 *               list 图文列表（大图统一在左，一行一篇，节奏规整）
 *
 * 后两种共用一套行式结构，只有「是否交错」不同；三种样式共用同一份数据、
 * 同一套封面与元信息逻辑，以后再加样式只要在这里补一个分支 + style.css 补一段类。
 */
$fo_posts  = (isset($fo_posts) && is_array($fo_posts)) ? $fo_posts : array();
$fo_layout = isset($fo_layout) ? (string)$fo_layout : 'grid';
if (!in_array($fo_layout, array('grid', 'side', 'list'), true)) $fo_layout = 'grid';
if (empty($fo_posts)) return;

/* 评论数：行式布局要展示，卡片网格不需要，避免默认样式多跑一次查询 */
$fo_cc = $fo_layout === 'grid' ? array() : fo_comment_counts($fo_posts);
$fo_row_i = 0;
?>
<?php if ($fo_layout === 'side' || $fo_layout === 'list'): ?>
<div class="fo-rowlist fo-rowlist--<?php echo $fo_layout; ?>">
  <?php foreach ($fo_posts as $p): ?>
    <?php
    $fo_row_i++;
    $cov  = fo_cover($p);
    $pid  = isset($p['id']) ? (int)$p['id'] : 0;
    /* 左右图文：偶数行把封面换到右边，形成「左-右-左-右」交错；图文列表始终图在左 */
    $rev  = ($fo_layout === 'side' && $fo_row_i % 2 === 0);
    $tags = function_exists('post_tags') ? post_tags($p) : fo_tags($p, 2);
    $tags = array_slice((array)$tags, 0, 2);
    $mins = ($fo_layout === 'side' && function_exists('reading_time')) ? (int)reading_time($p) : 0;
    ?>
    <article class="fo-row<?php echo $rev ? ' fo-row--rev' : ''; ?>">
      <a class="fo-row-cover" href="<?php echo e(post_url($p)); ?>" style="background:<?php echo e($cov['style']); ?>">
        <?php echo fo_cover_img_tag($cov['url']); ?>
        <?php if (!empty($p['is_top'])): ?><span class="fo-flag fo-flag--top">置顶</span><?php endif; ?>
      </a>
      <div class="fo-row-body">
        <div class="fo-row-top">
          <?php if (!empty($p['cat_name'])): ?><span class="fo-chip-mini"><?php echo e($p['cat_name']); ?></span><?php endif; ?>
          <span class="fo-row-date"><?php echo e(fo_ago($p['created_at'])); ?></span>
          <?php if ($mins > 0): ?>
          <span class="fo-row-read"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7.5v5l3 1.8"/></svg>约 <?php echo $mins; ?> 分钟</span>
          <?php endif; ?>
          <?php if (!empty($tags)): ?>
          <span class="fo-row-tags">
            <?php foreach ($tags as $t): ?><a href="<?php echo e(function_exists('post_tag_url') ? post_tag_url($t) : '#'); ?>">#<?php echo e($t); ?></a><?php endforeach; ?>
          </span>
          <?php endif; ?>
        </div>
        <h3 class="fo-row-title"><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
        <p class="fo-row-desc"><?php echo e(post_excerpt($p, 120)); ?></p>
        <div class="fo-meta">
          <span><svg viewBox="0 0 24 24"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/></svg><?php echo e(fo_num(isset($p['views']) ? $p['views'] : 0)); ?> 阅读</span>
          <span><svg viewBox="0 0 24 24"><path d="M21 11.5a8 8 0 0 1-8 8H8l-5 3 1.4-4.7A8 8 0 1 1 21 11.5Z"/></svg><?php echo (int)(isset($fo_cc[$pid]) ? $fo_cc[$pid] : 0); ?> 评论</span>
        </div>
      </div>
    </article>
  <?php endforeach; ?>
</div>
<?php else: ?>
<div class="fo-grid">
  <?php foreach ($fo_posts as $p): ?>
    <?php $cov = fo_cover($p); ?>
    <article class="fo-card">
      <a class="fo-card-cover" href="<?php echo e(post_url($p)); ?>" style="background:<?php echo e($cov['style']); ?>">
        <?php echo fo_cover_img_tag($cov['url']); ?>
        <?php if (!empty($p['is_top'])): ?><span class="fo-flag fo-flag--top">置顶</span><?php endif; ?>
        <?php if (!empty($p['cat_name'])): ?><span class="fo-flag fo-flag--cat"><?php echo e($p['cat_name']); ?></span><?php endif; ?>
        <span class="fo-card-shade"></span>
      </a>
      <div class="fo-card-body">
        <h3 class="fo-card-title"><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
        <p class="fo-card-desc"><?php echo e(post_excerpt($p, 78)); ?></p>
        <div class="fo-meta">
          <?php if (!empty($p['cat_name'])): ?><span><svg viewBox="0 0 24 24"><path d="M4 5h16v14H4z"/><path d="M4 9h16"/></svg><?php echo e($p['cat_name']); ?></span><?php endif; ?>
          <span class="fo-meta-end"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><?php echo e(fo_ago($p['created_at'])); ?></span>
        </div>
      </div>
    </article>
  <?php endforeach; ?>
</div>
<?php endif; ?>
