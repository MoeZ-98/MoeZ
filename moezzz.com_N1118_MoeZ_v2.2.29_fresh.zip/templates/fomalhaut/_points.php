<?php
/**
 * 星辉 · Fomalhaut · 评论得分端点
 *
 * 程序的 comment.php 发出评论后，前端再调用这里领积分。
 * 为避免「不发评论也刷分」，这里会核对：最近 3 分钟内确实有一条
 * 由当前登录用户（昵称或邮箱匹配）发表的评论，且同一条评论只发一次。
 */
require dirname(dirname(__DIR__)) . '/init.php';
require __DIR__ . '/_shop.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_exit(false, '非法请求');

csrf_verify();

$uid = fo_shop_uid();
if ($uid <= 0) json_exit(false, '请先登录');

$action = isset($_POST['action']) ? (string)$_POST['action'] : 'comment';
if ($action !== 'comment') json_exit(false, '未知操作');

$user = null;
try {
    $user = row('SELECT id, username, nickname, email FROM ' . moe_table('users') . ' WHERE id = ? LIMIT 1', array($uid));
} catch (Throwable $e) {
    $user = null;
}
if (!$user) json_exit(false, '用户不存在');

$nickname = trim((string)($user['nickname'] ?? ''));
$email = trim((string)($user['email'] ?? ''));
$since = date('Y-m-d H:i:s', time() - 180);

$comment = null;
try {
    $sql = 'SELECT id, author, email, created_at FROM ' . moe_table('comments')
        . ' WHERE created_at >= ? AND (author = ? OR (email <> \'\' AND email = ?)) ORDER BY id DESC LIMIT 1';
    $comment = row($sql, array($since, $nickname !== '' ? $nickname : $user['username'], $email));
} catch (Throwable $e) {
    $comment = null;
}

if (!$comment) json_exit(false, '没找到刚发表的评论，积分未发放');

/* 同一条评论只发一次 */
$note = '评论 #' . (int)$comment['id'];
try {
    $exist = row('SELECT id FROM ' . fo_shop_table('points_log') . ' WHERE user_id = ? AND note = ? LIMIT 1', array($uid, $note));
    if ($exist) json_exit(false, '这条评论的积分已经领过了');
} catch (Throwable $e) {
    // 查询失败时继续，交给下面的每日上限兜底
}

$grant = fo_comment_points_grant($uid, $note);
json_exit((bool)$grant['ok'], (string)$grant['msg'], array(
    'balance' => (int)($grant['balance'] ?? fo_points_balance($uid)),
));