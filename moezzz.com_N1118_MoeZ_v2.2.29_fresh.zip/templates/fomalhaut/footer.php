<?php
/**
 * 星辉 · Fomalhaut 模板 · 公共底部
 * 结构：三栏（格言 / 站内导航 / 推荐友链）+ 版权与运行信息
 */
$fo_motto = trim(fo_opt('motto', ''));
if ($fo_motto === '') $fo_motto = '再看一看那个光点，它就在这里。这里就是家园，这就是我们——你所爱的每一个人，你认识的每一个人，你听说过的每一个人，曾经有过的每一个人，都在它上面度过他们的一生。';
$fo_icp = trim(fo_opt('icp', ''));
$fo_uptime = fo_uptime();
$fo_stats_url = fo_stats_url();
/* 推荐友链数量（模板设置，0 表示不显示该栏） */
$fo_friend_count = max(0, min(24, (int)fo_opt('friend_count', '3')));

/* 友链只查一次：随机打乱后取前 N 条做磁贴，随机按钮用同一批链接做池子
   2.1.2 修复：数量完全按模板设置的「推荐友链数量」来（0 = 不显示），且改为随机展示，
   每次页面缓存刷新后都会换一批，不再永远按后台排序取前几条 */
$fo_links = array();
$fo_quote_pool = array();
try {
    $fo_link_rows = rows('SELECT name, url, logo FROM ' . moe_table('links') . " WHERE status='approved' AND url <> '' AND (check_result IS NULL OR check_result NOT LIKE '失联%')");
    $fo_link_rows = (array)$fo_link_rows;
    shuffle($fo_link_rows);
    foreach ($fo_link_rows as $fo_l) {
        $u = trim((string)$fo_l['url']);
        if ($u === '' || !preg_match('#^https?://#i', $u)) continue;
        $fo_quote_pool[] = $u;
        if (count($fo_links) < $fo_friend_count) $fo_links[] = $fo_l;
    }
} catch (Throwable $e) {
    $fo_links = array();
    $fo_quote_pool = array();
}

/* 「点击开启星辰之旅」：点击时随机打开一条已审核友链，没有友链时退回友链页 */
$fo_quote_url = !empty($fo_quote_pool) ? $fo_quote_pool[array_rand($fo_quote_pool)] : base_url() . 'link';
/* 广告位：开关 + 数量 + 文字 + 链接（模板设置） */
$fo_ad_on = fo_on('show_ad_slot', '1');
$fo_ad_count = max(0, min(4, (int)fo_opt('ad_count', '1')));
$fo_ad_text = trim(fo_opt('ad_text', ''));
if ($fo_ad_text === '') $fo_ad_text = '广告位<br>招租';
$fo_ad_url = trim(fo_opt('ad_url', ''));
if ($fo_ad_url === '') $fo_ad_url = base_url() . 'link';
?>
</main>

<footer class="fo-footer">
  <div class="fo-footer-in">
    <div class="fo-footer-col fo-footer-col--quote">
      <div class="fo-footer-head">关于本站<span class="fo-footer-ic">✦</span></div>
      <p class="fo-quote"><?php echo e($fo_motto); ?></p>
      <a class="fo-quote-btn" id="fo-quote-btn" href="<?php echo e($fo_quote_url); ?>"<?php if (!empty($fo_quote_pool)): ?> data-friends="<?php echo e(implode('|', $fo_quote_pool)); ?>"<?php endif; ?> target="_blank" rel="noopener nofollow">点击开启星辰之旅</a>
    </div>

    <div class="fo-footer-col">
      <div class="fo-footer-head">猜你想看<span class="fo-footer-ic">✦</span></div>
      <ul class="fo-footer-links">
        <li><a href="<?php echo e(base_url() . 'archives'); ?>">文章归档</a></li>
        <li><a href="<?php echo e(base_url() . 'blog/article'); ?>">全部文章</a></li>
        <li><a href="<?php echo e(base_url() . 'link'); ?>">友情链接</a></li>
        <li><a href="<?php echo e(base_url() . 'about'); ?>">关于作者</a></li>
        <?php if ($fo_stats_url !== ''): ?><li><a href="<?php echo e($fo_stats_url); ?>">网站统计</a></li><?php endif; ?>
        <li><a href="<?php echo e(search_url('')); ?>">站内搜索</a></li>
      </ul>
    </div>

    <?php if ($fo_friend_count > 0 || ($fo_ad_on && $fo_ad_count > 0)): ?>
    <div class="fo-footer-col">
      <div class="fo-footer-head">推荐友链<span class="fo-footer-ic">✦</span></div>
      <div class="fo-footer-friends">
        <?php if ($fo_friend_count > 0): ?>
        <?php if (!empty($fo_links)): ?>
          <?php foreach ($fo_links as $l): ?>
            <a class="fo-friend" href="<?php echo e($l['url']); ?>" target="_blank" rel="noopener" title="<?php echo e($l['name']); ?>">
              <?php if (!empty($l['logo'])): ?>
                <img src="<?php echo e(media_url($l['logo'])); ?>" alt="<?php echo e($l['name']); ?>" width="56" height="56" loading="lazy" decoding="async">
              <?php else: ?>
                <span class="fo-friend-ph"><?php echo e(initial($l['name'])); ?></span>
              <?php endif; ?>
            </a>
          <?php endforeach; ?>
        <?php else: ?>
          <?php for ($i = 2; $i <= max(2, $fo_friend_count); $i++): ?>
            <span class="fo-friend fo-friend--slot"><span class="fo-friend-ph">✦</span></span>
          <?php endfor; ?>
        <?php endif; ?>
        <?php endif; ?>
        <?php if ($fo_ad_on && $fo_ad_count > 0): ?>
          <?php for ($i = 0; $i < $fo_ad_count; $i++): ?>
            <a class="fo-ad" href="<?php echo e($fo_ad_url); ?>"><?php echo $fo_ad_text; ?></a>
          <?php endfor; ?>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>
  </div>

  <div class="fo-footer-bottom">
    <div class="fo-copy">
      <span>© <?php echo date('Y'); ?> <?php echo e($site['footer'] !== '' ? $site['footer'] : $site['name']); ?> 版权所有.</span>
      <a href="https://beian.miit.gov.cn/" target="_blank" rel="noopener"><?php echo e($fo_icp !== '' ? $fo_icp : '萌ICP备 00000000 号'); ?></a>
    </div>
    <?php if ($fo_uptime['text'] !== ''): ?>
    <div class="fo-uptime">本站已运行 <b id="fo-uptime-b" data-start="<?php echo (int)$fo_uptime['ts']; ?>"><?php echo e($fo_uptime['text']); ?></b></div>
    <?php endif; ?>
    <div class="fo-badges">
      <span class="fo-badge fo-badge--dark"><a href="<?php echo e(rss_url()); ?>" target="_blank" rel="noopener">RSS</a></span>
      <span class="fo-badge fo-badge--teal"><a href="<?php echo e(base_url() . 'sitemap.xml'); ?>" target="_blank" rel="noopener">sitemap</a></span>
      <span class="fo-badge">Moe Home v<?php echo e(isset($site['version']) ? $site['version'] : ''); ?></span>
      <span class="fo-badge fo-badge--grad">Theme Fomalhaut</span>
      <span class="fo-badge fo-badge--dark">CDN</span>
    </div>
  </div>
</footer>

<?php /* 全站浮动回到顶部：所有页面通用（首页桌面端已有右侧浮动条，脚本会自动隐藏本按钮） */ ?>
<button class="fo-totop" type="button" id="fo-totop" aria-label="回到顶部" title="回到顶部">
  <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V6"/><path d="m6 12 6-6 6 6"/></svg>
</button>

<?php /* 2.1.16 看板娘（立体仿真人）：position:fixed 固定在视口角落，页面怎么滚她都不动；可点击打开站内聊天 */
$fo_cp_on = fo_on('show_mascot', '1');
$fo_cp_scope = fo_opt('mascot_scope', 'all');
if ($fo_cp_on && $fo_cp_scope === 'home' && (!isset($cur_p) || $cur_p !== 'index')) $fo_cp_on = false;
if ($fo_cp_on):
$fo_cp_src = trim(fo_opt('mascot_img', ''));
$fo_cp_src = $fo_cp_src !== '' ? media_url($fo_cp_src) : theme_url('assets/companion.png');
$fo_cp_h = (int)trim((string)fo_opt('mascot_height', ''));
$fo_cp_name = trim(fo_opt('mascot_name', ''));
if ($fo_cp_name === '') $fo_cp_name = '小星';
$fo_cp_greet = trim(fo_opt('mascot_greet', ''));
if ($fo_cp_greet === '') $fo_cp_greet = '在的呀～我是' . (isset($site['name']) ? $site['name'] : '小站') . '的看板娘' . $fo_cp_name . '，可以问我「最新文章」「热门推荐」，也可以直接丢关键词让我帮你找文章。';
$fo_cp_hint = trim(fo_opt('mascot_hint', ''));
if ($fo_cp_hint === '') $fo_cp_hint = '点我聊天 ✦';

/* 2.1.17 温柔御姐语音 / 2.1.24 病娇：浏览器内置语音合成，无需任何外部服务 */
$fo_cp_voice  = fo_on('voice_on', '1') ? '1' : '0';
$fo_cp_vauto  = fo_on('voice_autoplay', '1') ? '1' : '0';
$fo_cp_vstyle = fo_opt('voice_style', 'gentle');
if (!in_array($fo_cp_vstyle, array('gentle', 'sweet', 'natural', 'yandere'), true)) $fo_cp_vstyle = 'gentle';
$fo_cp_vrate  = trim((string)fo_opt('voice_rate', ''));
$fo_cp_vpitch = trim((string)fo_opt('voice_pitch', ''));
$fo_cp_psize  = fo_opt('cp_panel_size', 'compact');
if (!in_array($fo_cp_psize, array('compact', 'standard'), true)) $fo_cp_psize = 'compact';
$fo_cp_vlabels = array('gentle' => '温柔御姐', 'sweet' => '清甜少女', 'natural' => '系统原声', 'yandere' => '病娇');
$fo_cp_vshorts = array('gentle' => '御姐', 'sweet' => '少女', 'natural' => '原声', 'yandere' => '病娇');
$fo_cp_vlabel  = $fo_cp_vlabels[$fo_cp_vstyle];
$fo_cp_vshort  = $fo_cp_vshorts[$fo_cp_vstyle];
?>
<div class="fo-companion<?php echo fo_opt('mascot_side', 'left') === 'right' ? ' fo-companion--right' : ''; ?><?php echo $fo_cp_vstyle === 'yandere' ? ' is-yandere' : ''; ?>" id="fo-companion"<?php echo $fo_cp_h > 80 ? ' style="--fo-cp-h:' . $fo_cp_h . 'px;"' : ''; ?>
     data-api="<?php echo e(base_url() . 'chat.php'); ?>"
     data-token="<?php echo e(function_exists('csrf_token') ? csrf_token() : ''); ?>"
     data-name="<?php echo e($fo_cp_name); ?>"
     data-greet="<?php echo e($fo_cp_greet); ?>"
     data-panel-size="<?php echo e($fo_cp_psize); ?>"
     data-voice="<?php echo e($fo_cp_voice); ?>"
     data-voice-auto="<?php echo e($fo_cp_vauto); ?>"
     data-voice-style="<?php echo e($fo_cp_vstyle); ?>"
     data-voice-rate="<?php echo e($fo_cp_vrate); ?>"
     data-voice-pitch="<?php echo e($fo_cp_vpitch); ?>">
  <div class="fo-cp-panel">
    <div class="fo-cp-head">
      <span class="fo-cp-dot"></span>
      <span class="fo-cp-head-name"><?php echo e($fo_cp_name); ?></span>
      <span class="fo-cp-head-status">在线 · 站内小助手</span>
      <button type="button" class="fo-cp-reset" aria-label="重新开始对话" title="重新开始对话">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1"/><path d="M3 4.2v5h5"/></svg>
      </button>
      <button type="button" class="fo-cp-style" aria-label="切换语音音色" title="切换语音音色（当前：<?php echo e($fo_cp_vlabel); ?>）" aria-pressed="false">
        <span class="fo-cp-style-ico">♪</span><span class="fo-cp-style-name"><?php echo e($fo_cp_vshort); ?></span>
      </button>
      <button type="button" class="fo-cp-voice is-on" aria-label="关闭语音" title="<?php echo e($fo_cp_vlabel); ?>语音：开">
        <span class="fo-cp-vw"><i></i><i></i><i></i></span>
        <svg class="fo-cp-vico" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/></svg>
        <svg class="fo-cp-voff" viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="m17 9 4 6"/><path d="m21 9-4 6"/></svg>
      </button>
      <button type="button" class="fo-cp-close" aria-label="收起对话">&times;</button>
    </div>
    <div class="fo-cp-msgs" id="fo-cp-msgs"></div>
    <div class="fo-cp-chips" id="fo-cp-chips"></div>
    <form class="fo-cp-form" id="fo-cp-form">
      <input type="text" class="fo-cp-input" id="fo-cp-input" maxlength="200" placeholder="和 <?php echo e($fo_cp_name); ?> 说点什么…" autocomplete="off">
      <button type="submit" class="fo-cp-send" aria-label="发送">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4Z"/></svg>
      </button>
    </form>
  </div>
  <div class="fo-cp-figure" role="button" tabindex="0" aria-label="打开聊天">
    <img src="<?php echo e($fo_cp_src); ?>" alt="<?php echo e($fo_cp_name); ?>" draggable="false" decoding="async">
  </div>
  <?php /* 2.1.30 手机端：立绘默认收起成一个小按钮，点一下她才出来（不再一直挡着正文） */ ?>
  <button type="button" class="fo-cp-mini" aria-label="叫出<?php echo e($fo_cp_name); ?>" title="叫出<?php echo e($fo_cp_name); ?>">
    <img src="<?php echo e($fo_cp_src); ?>" alt="" aria-hidden="true" draggable="false" decoding="async">
    <i aria-hidden="true">✦</i>
  </button>
  <div class="fo-cp-hint"><?php echo e($fo_cp_hint); ?></div>
</div>
<?php endif; ?>

</body>
</html>