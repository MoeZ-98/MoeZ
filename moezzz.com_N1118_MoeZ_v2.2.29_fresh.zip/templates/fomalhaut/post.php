<?php
/**
 * 星辉 · Fomalhaut 模板 · 文章详情
 * 可用变量：$post $cat $prev $next $comments $site
 */
$cur_p = 'article';
$page_title = $post['title'];
include partial_path('header.php');

$fo_cov = fo_cover($post);
$fo_tags = post_tags($post);
if (empty($fo_tags)) $fo_tags = fo_tags($post, 8);
$fo_hero_img = $fo_cov['url'] !== '' ? $fo_cov['url'] : (trim(fo_opt('hero_bg', '')) !== '' ? media_url(fo_opt('hero_bg', '')) : theme_url('assets/hero.svg'));
$fo_side_on = fo_side_enabled();

/* 2.1.7：告诉「评论可见」语法当前是哪篇文章 */
$GLOBALS['moe_render_post_id'] = (int)$post['id'];

/* 评论表单：站长已登录时免填昵称邮箱 */
$fo_cdf = function_exists('moe_comment_defaults') ? moe_comment_defaults() : array('author' => '', 'email' => '', 'admin' => false);
$fo_cdf['author'] = (string)$fo_cdf['author'];
$fo_cdf['email'] = (string)$fo_cdf['email'];

/* 评论扩展功能开关 */
$fo_cmt_emoji = fo_on('comment_emoji', '1');
$fo_cmt_hitokoto = fo_on('comment_hitokoto', '1');
$fo_cmt_img = fo_on('comment_img_upload', '1');

/* 版权声明文字 */
$fo_copy_text = trim(fo_opt('post_copyright_text', ''));
if ($fo_copy_text === '') $fo_copy_text = '本篇文章采用 CC BY-NC-SA 4.0 许可协议，转载时请注明原作者与本文链接。';

/* ---------- 2.1.6 左侧悬浮磁吸目录：从正文 H2 / H3 自动生成 ---------- */
$fo_body = render_content($post['content'], isset($post['content_format']) ? $post['content_format'] : 'html');
$fo_toc_items = array();
if (fo_on('show_toc', '1')) {
    $fo_seq = 0;
    $fo_body = preg_replace_callback('/<h([23])([^>]*)>(.*?)<\/h\1>/s', function ($m) use (&$fo_toc_items, &$fo_seq) {
        $txt = trim(html_entity_decode(strip_tags($m[3]), ENT_QUOTES, 'UTF-8'));
        if ($txt === '') return $m[0];
        $attrs = $m[2];
        if (preg_match('/\bid\s*=\s*["\']([^"\']+)["\']/i', $attrs, $im)) {
            $id = $im[1];
        } else {
            $fo_seq++;
            $id = 'fo-sec-' . $fo_seq;
            $attrs .= ' id="' . $id . '"';
        }
        $fo_toc_items[] = array('lv' => (int)$m[1], 'id' => $id, 'text' => $txt);
        return '<h' . $m[1] . $attrs . '>' . $m[3] . '</h' . $m[1] . '>';
    }, $fo_body);
}
$fo_toc_html = '';
if (count($fo_toc_items) >= 2) {
    $fo_toc_html = '<nav class="fo-toc" id="fo-toc" aria-label="文章目录">'
        . '<div class="fo-toc-head"><span>目录</span><em>' . count($fo_toc_items) . ' 节</em></div>'
        . '<div class="fo-toc-prog"><i id="fo-toc-prog"></i></div>'
        . '<ol class="fo-toc-list">';
    foreach ($fo_toc_items as $it) {
        $fo_toc_html .= '<li class="fo-toc-lv' . (int)$it['lv'] . '"><a href="#' . e($it['id']) . '">'
            . e($it['text']) . '</a></li>';
    }
    $fo_toc_html .= '</ol></nav>';
}
?>
<section class="fo-hero fo-hero--small fo-hero--post" style="background-image:linear-gradient(180deg,rgba(14,32,52,.42),rgba(14,32,52,.66)),url('<?php echo e($fo_hero_img); ?>')">
  <div class="fo-hero-center">
    <h1 class="fo-hero-title fo-hero-title--sm fo-hero-title--wrap"><?php echo e($post['title']); ?></h1>
    <p class="fo-hero-sub"><?php echo e($post['cat_name'] ?? ($cat ? $cat['name'] : '未分类')); ?> · <?php echo e(format_time($post['created_at'], 'Y-m-d')); ?></p>
  </div>
</section>

<div class="fo-wrap<?php echo $fo_side_on ? '' : ' fo-wrap--noside'; ?><?php echo $fo_toc_html !== '' ? ' fo-wrap--toc' : ''; ?>">
  <?php echo $fo_toc_html; ?>
  <div class="fo-content">
  <article class="fo-panel fo-panel--article">
    <div class="fo-article-meta">
      <?php if ($cat): ?><a class="fo-chip-mini" href="<?php echo e(cat_url($cat)); ?>"><?php echo e($cat['name']); ?></a><?php endif; ?>
      <span><?php echo e(format_time($post['created_at'], 'Y-m-d')); ?></span>
      <span><?php echo e(reading_time($post)); ?> 分钟阅读</span>
      <span><?php echo (int)$post['views']; ?> 次浏览</span>
      <span><?php echo count($comments); ?> 条评论</span>
    </div>

    <?php /* 2.1.27：AI 摘要。放在元信息下面、正文上面 —— 进文章先看到「这篇讲什么」，
              由站内 AI 读正文后生成；请求失败 / 未配置 AI 时整块自动隐藏，不留空白 */ ?>
    <?php if (fo_on('post_ai_summary', '1')): ?>
    <div class="fo-aisum" id="fo-aisum"
         data-api="<?php echo e(base_url() . 'chat.php'); ?>"
         data-csrf="<?php echo e(function_exists('csrf_token') ? csrf_token() : ''); ?>"
         data-title="<?php echo e($post['title']); ?>"
         data-key="<?php echo (int)$post['id']; ?>">
      <div class="fo-aisum-head">
        <span class="fo-aisum-ico" aria-hidden="true">✦</span>
        <b>AI 摘要</b>
        <em>读完正文自动生成，仅供参考</em>
        <button type="button" class="fo-aisum-again" id="fo-aisum-again" hidden>换一版</button>
      </div>
      <div class="fo-aisum-body" id="fo-aisum-body">
        <span class="fo-aisum-skel" aria-label="正在总结"><i></i><i></i><i></i></span>
      </div>
    </div>
    <?php endif; ?>

    <div class="fo-prose" id="fo-article-body">
      <?php echo $fo_body; ?>
    </div>

    <?php if (fo_on('post_show_tags', '1') && !empty($fo_tags)): ?>
    <div class="fo-article-tags">
      <span class="fo-article-tags-label">标签</span>
      <?php foreach ($fo_tags as $t): ?><a class="fo-tag" href="<?php echo e(post_tag_url($t)); ?>">#<?php echo e($t); ?></a><?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (fo_on('post_show_copyright', '1')): ?>
    <?php
    /* 2.1.27 版权修正：作者优先取文章作者（此前永远显示站点名）；
       链接带域名、可点击、可一键复制；版权文字里的 CC 协议自动变成可点链接 */
    $fo_author = '';
    foreach (array('author_name', 'author', 'nickname', 'username') as $fo_ak) {
        if (!empty($post[$fo_ak]) && is_string($post[$fo_ak])) { $fo_author = trim($post[$fo_ak]); break; }
    }
    if ($fo_author === '') $fo_author = (string)$site['name'];
    $fo_plink = (string)post_url($post);
    $fo_copy_html = e($fo_copy_text);
    $fo_copy_html = preg_replace(
        '/CC\s*BY(-NC)?(-SA)?(\s*[0-9.]+)?/i',
        '<a class="fo-copyright-cc" href="https://creativecommons.org/licenses/by-nc-sa/4.0/deed.zh" target="_blank" rel="noopener nofollow">$0</a>',
        $fo_copy_html
    );
    ?>
    <div class="fo-copyright">
      <div class="fo-copyright-head">
        <span class="fo-copyright-badge">©</span>
        <b>本文作者：<?php echo e($fo_author); ?></b>
        <span class="fo-copyright-title" title="<?php echo e($post['title']); ?>">《<?php echo e($post['title']); ?>》</span>
        <a class="fo-copyright-link" href="<?php echo e($fo_plink); ?>" rel="bookmark" title="<?php echo e($fo_plink); ?>"><?php echo e(preg_replace('#^https?://#i', '', $fo_plink)); ?></a>
        <button type="button" class="fo-copyright-copy" data-url="<?php echo e($fo_plink); ?>" title="复制本文链接">复制</button>
      </div>
      <p class="fo-copyright-text"><?php echo $fo_copy_html; ?></p>
    </div>
    <?php endif; ?>

    <nav class="fo-prevnext">
      <?php if ($prev): ?>
        <a class="fo-prevnext-item" href="<?php echo e(post_url($prev)); ?>"><span>上一篇</span><b><?php echo e($prev['title']); ?></b></a>
      <?php else: ?><span class="fo-prevnext-item is-empty"><span>上一篇</span><b>已经是最早的文章</b></span><?php endif; ?>
      <?php if ($next): ?>
        <a class="fo-prevnext-item fo-prevnext-item--next" href="<?php echo e(post_url($next)); ?>"><span>下一篇</span><b><?php echo e($next['title']); ?></b></a>
      <?php else: ?><span class="fo-prevnext-item fo-prevnext-item--next is-empty"><span>下一篇</span><b>已经是最新的文章</b></span><?php endif; ?>
    </nav>

    <?php /* 2.1.2：文章点赞（再点一次可取消；Cookie 防重复，不依赖登录） */ ?>
    <div class="fo-likebar">
      <button type="button" class="fo-like-btn" id="fo-like-btn"
              data-pid="<?php echo (int)$post['id']; ?>"
              data-url="<?php echo e(base_url() . 'like.php'); ?>"
              data-likes="<?php echo (int)($post['likes'] ?? 0); ?>"
              aria-pressed="false" title="喜欢就点个赞吧">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.3 4.9 13a4.6 4.6 0 1 1 6.5-6.5l.6.6.6-.6A4.6 4.6 0 1 1 19.1 13Z"/></svg>
        <b class="fo-like-num"><?php echo (int)($post['likes'] ?? 0); ?></b>
        <span>喜欢这篇文章</span>
      </button>
    </div>

      <?php
      /* 评论区：公共组件，文章页与友链页共用 */
      $fo_cmt_target   = (int)$post['id'];
      $fo_cmt_comments = (array)$comments;
      $fo_cmt_action   = base_url() . 'comment.php';
      $fo_cmt_title    = '评论';
      $fo_cmt_lead     = '';
      $fo_cmt_anchor   = 'comment';
      include partial_path('part-comments.php');
      ?>
  </article>
  </div>

  <?php if ($fo_side_on): include partial_path('side.php'); endif; ?>
</div>


<?php include partial_path('footer.php'); ?>
