<?php
/**
 * 星辉 · Fomalhaut 模板 · 关于页（/about）
 * 内容来自模板设置 about_md（Markdown），留空时展示站点介绍与资料卡
 * 可用变量：$site $nav_cats
 */
$cur_p = 'about';
include partial_path('header.php');

$fo_hero_img = trim(fo_opt('hero_bg', ''));
$fo_hero_img = $fo_hero_img !== '' ? media_url($fo_hero_img) : theme_url('assets/hero.svg');
$fo_about = trim(fo_opt('about_md', ''));
$fo_avatar = !empty($site['avatar']) ? media_url($site['avatar']) : theme_url('assets/avatar.svg');
$fo_data = fo_site_data();
?>
<section class="fo-hero fo-hero--small" style="background-image:linear-gradient(180deg,rgba(14,32,52,.28),rgba(14,32,52,.52)),url('<?php echo e($fo_hero_img); ?>')">
  <div class="fo-hero-center">
    <h1 class="fo-hero-title fo-hero-title--sm">关于</h1>
    <p class="fo-hero-sub"><?php echo e($site['desc'] !== '' ? $site['desc'] : '关于 ' . $site['name']); ?></p>
  </div>
</section>

<div class="fo-wrap fo-wrap--about">
  <div class="fo-panel fo-panel--article">
    <div class="fo-about-head">
      <img class="fo-about-avatar" src="<?php echo e($fo_avatar); ?>" alt="<?php echo e($site['name']); ?>" width="64" height="64" loading="lazy" decoding="async">
      <div>
        <h2 class="fo-about-name"><?php echo e($site['name']); ?></h2>
        <p class="fo-about-sig"><?php echo e($site['signature'] !== '' ? $site['signature'] : ($site['sub'] !== '' ? $site['sub'] : '')); ?></p>
      </div>
    </div>

    <div class="fo-prose">
      <?php if ($fo_about !== ''): ?>
        <?php echo render_content($fo_about, 'markdown'); ?>
      <?php else: ?>
        <?php
        $fo_about_name = trim((string)$site['author']);
        if ($fo_about_name === '') $fo_about_name = $site['name'];
        $fo_about_tag = rtrim(trim((string)$site['signature']), "。.！! ");
        $fo_about_desc = rtrim(trim((string)$site['desc']), "。.！! ");
        if ($fo_about_desc === '') $fo_about_desc = '这里记录代码、主题折腾与一些小小的好奇';
        ?>
        <h2>关于本站</h2>
        <p><?php echo e($site['name']); ?> 是一个用 Moe Home 搭起来的个人主页与博客。<?php echo e($fo_about_desc); ?>。</p>
        <p>站点里大致是三块内容：一是折腾程序与主题的记录，包括模板改造、CSS 与 PHP 的小技巧；二是日常碎碎念和随手收藏；三是偶尔写点长一点的文章，把想清楚和还没想清楚的事都摊开讲讲。这里不追热点，更新也说不上勤快，但每篇都是自己敲出来的。</p>
        <p>目前站内共有 <b><?php echo (int)$fo_data['posts']; ?></b> 篇文章、<b><?php echo (int)$fo_data['comments']; ?></b> 条评论，累计被浏览 <b><?php echo (int)$fo_data['views']; ?></b> 次。侧栏能看到文章、标签与分类的数量，页脚的运行天数比任何自我介绍都诚实。</p>

        <h2>关于我</h2>
        <p>你好，我是 <b><?php echo e($fo_about_name); ?></b><?php if ($fo_about_tag !== ''): ?>——<?php echo e($fo_about_tag); ?><?php endif; ?>。</p>
        <p>喜欢把界面调到自己顺眼为止，看到好看的主题会忍不住拆开看看它是怎么写的；写代码的时间不算多，改样式的耐心倒是很足。平时会待在评论区里，交换友链、指出错别字、顺手提个建议都欢迎。</p>
        <ul>
          <li>昵称：<?php echo e($fo_about_name); ?></li>
          <li>坐标：<em class="fo-about-todo">待补充</em></li>
          <li>正在做的事：<em class="fo-about-todo">待补充</em></li>
          <li>可以聊：主题改造、博客折腾、二次元与日常</li>
        </ul>
        <p>想说的话可以直接评论，或者从下面的入口找到我。</p>
      <?php endif; ?>
    </div>

    <div class="fo-about-links">
      <?php if (!empty($site['github'])): ?><a class="fo-btn fo-btn--ghost" href="<?php echo e($site['github']); ?>" target="_blank" rel="noopener">Github</a><?php endif; ?>
      <?php if (!empty($site['mail'])): ?><a class="fo-btn fo-btn--ghost" href="mailto:<?php echo e($site['mail']); ?>">邮件</a><?php endif; ?>
      <?php if (!empty($site['bilibili'])): ?><a class="fo-btn fo-btn--ghost" href="<?php echo e($site['bilibili']); ?>" target="_blank" rel="noopener">哔哩哔哩</a><?php endif; ?>
      <a class="fo-btn fo-btn--ghost" href="<?php echo e(rss_url()); ?>" target="_blank" rel="noopener">RSS</a>
    </div>
  </div>
</div>

<?php include partial_path('footer.php'); ?>