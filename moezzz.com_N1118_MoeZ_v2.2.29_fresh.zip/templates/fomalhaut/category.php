<?php
/**
 * 星辉 · Fomalhaut 模板 · 分类页
 * 可用变量：$cat $posts $pager $total $page $site
 */
$cur_p = 'article';
include partial_path('header.php');

$fo_hero_img = trim(fo_opt('hero_bg', ''));
$fo_hero_img = $fo_hero_img !== '' ? media_url($fo_hero_img) : theme_url('assets/hero.svg');
$fo_desc = !empty($cat['description']) ? $cat['description'] : '「' . $cat['name'] . '」分类下共 ' . (int)$total . ' 篇文章';

/* 全部分类（带文章数）：与文章列表页同一排筛选胶囊，当前分类高亮 */
$fo_cats = array();
try {
    $fo_cats = rows('SELECT c.*, (SELECT COUNT(*) FROM ' . moe_table('posts') . " p WHERE p.category_id = c.id AND p.type='post' AND p.status='published') AS count FROM " . moe_table('categories') . ' c ORDER BY c.sort, c.id');
} catch (Throwable $e) {
    $fo_cats = array();
}
?>
<section class="fo-hero fo-hero--small" style="background-image:linear-gradient(180deg,rgba(14,32,52,.28),rgba(14,32,52,.52)),url('<?php echo e($fo_hero_img); ?>')">
  <div class="fo-hero-center">
    <h1 class="fo-hero-title fo-hero-title--sm"><?php echo e($cat['name']); ?></h1>
    <p class="fo-hero-sub"><?php echo e($fo_desc); ?></p>
  </div>
</section>

<div class="fo-wrap fo-wrap--single">
  <div class="fo-panel">
    <?php if (!empty($fo_cats)): ?>
    <div class="fo-yearchips fo-yearchips--cats">
      <a class="fo-yearchip" href="<?php echo e(base_url() . 'blog/article'); ?>">全部</a>
      <?php foreach ((array)$fo_cats as $fo_c): ?>
        <a class="fo-yearchip <?php echo (int)$fo_c['id'] === (int)$cat['id'] ? 'is-active' : ''; ?>" href="<?php echo e(cat_url($fo_c)); ?>"><?php echo e($fo_c['name']); ?><em><?php echo (int)$fo_c['count']; ?></em></a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div class="fo-panel-head">
      <h2 class="fo-panel-title"><?php echo e($cat['name']); ?> <span>- <?php echo (int)$total; ?></span></h2>
      <a class="fo-panel-sub" href="<?php echo e(base_url() . 'blog/article'); ?>">查看全部文章 →</a>
    </div>

    <div class="fo-grid fo-grid--wide">
      <?php foreach ((array)$posts as $p): ?>
        <?php $cov = fo_cover($p); ?>
        <article class="fo-card">
          <a class="fo-card-cover" href="<?php echo e(post_url($p)); ?>" style="background:<?php echo e($cov['style']); ?>">
            <?php echo fo_cover_img_tag($cov['url']); ?>
            <?php if (!empty($p['is_top'])): ?><span class="fo-flag fo-flag--top">置顶</span><?php endif; ?>
            <span class="fo-flag fo-flag--cat"><?php echo e($cat['name']); ?></span>
          </a>
          <div class="fo-card-body">
            <h3 class="fo-card-title"><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
            <div class="fo-meta">
              <span>发布于 <?php echo e(fo_ago($p['created_at'])); ?></span>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>

    <?php if (empty($posts)): ?><p class="fo-empty">这个分类下还没有文章</p><?php endif; ?>
    <?php echo $pager; ?>
  </div>
</div>

<?php include partial_path('footer.php'); ?>