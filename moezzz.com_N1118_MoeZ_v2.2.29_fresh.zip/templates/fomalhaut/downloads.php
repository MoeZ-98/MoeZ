<?php
/**
 * 星辉 · Fomalhaut 模板 · 下载中心视图
 * 由 page.php 在页面别名等于 downloads_slug 时引入（header 已输出）
 * 可用变量：$page $site
 */
require_once __DIR__ . '/_shop.php';

$fo_dl_uid = fo_shop_uid();
$fo_dl_ready = fo_shop_ready();
$fo_dl_orders = $fo_dl_uid > 0 ? fo_user_orders($fo_dl_uid) : array();
$fo_dl_balance = $fo_dl_uid > 0 ? fo_points_balance($fo_dl_uid) : 0;
$fo_dl_unit = fo_points_name();
$fo_dl_all = $fo_dl_ready ? fo_goods_list(true) : array();

$fo_shop_slug = trim(fo_opt('shop_slug', 'shop'));
$fo_shop_url = $fo_shop_slug !== '' ? base_url() . 'page/' . rawurlencode($fo_shop_slug) . '.html' : '';
$fo_hero_img = trim(fo_opt('hero_bg', ''));
$fo_hero_img = $fo_hero_img !== '' ? media_url($fo_hero_img) : theme_url('assets/hero.svg');
?>
<section class="fo-hero fo-hero--small" style="background-image:linear-gradient(180deg,rgba(14,32,52,.28),rgba(14,32,52,.52)),url('<?php echo e($fo_hero_img); ?>')">
  <div class="fo-hero-center">
    <h1 class="fo-hero-title fo-hero-title--sm">下载中心</h1>
    <p class="fo-hero-sub">已兑换的资源都在这儿</p>
  </div>
</section>

<div class="fo-wrap fo-wrap--single fo-wrap--nohero">
  <div class="fo-panel">
    <div class="fo-shop-head">
      <div class="fo-shop-head-main">
        <h2 class="fo-shop-title">我的下载 <span><?php echo count($fo_dl_orders); ?></span></h2>
        <p class="fo-shop-intro">兑换成功后在这里获取下载地址；同一资源只需兑换一次，下载次数不限。</p>
      </div>
      <div class="fo-shop-wallet">
        <?php if ($fo_dl_uid > 0): ?>
          <span class="fo-shop-wallet-label">我的<?php echo e($fo_dl_unit); ?></span>
          <b><?php echo (int)$fo_dl_balance; ?></b>
          <?php if ($fo_shop_url !== ''): ?><a class="fo-btn fo-btn--ghost fo-shop-wallet-link" href="<?php echo e($fo_shop_url); ?>">去商城</a><?php endif; ?>
        <?php else: ?>
          <span class="fo-shop-wallet-label">登录后查看已兑换资源</span>
          <a class="fo-btn fo-shop-login" href="<?php echo e(base_url() . 'user'); ?>">去登录</a>
        <?php endif; ?>
      </div>
    </div>

    <?php if (!$fo_dl_ready): ?>
      <p class="fo-empty">积分数据表还没建好，请确认数据库账号有建表权限后刷新一次。</p>
    <?php elseif ($fo_dl_uid <= 0): ?>
      <p class="fo-empty">登录后即可看到自己兑换过的资源。</p>
    <?php elseif (empty($fo_dl_orders)): ?>
      <p class="fo-empty">还没有兑换过资源<?php if ($fo_shop_url !== ''): ?>，<a href="<?php echo e($fo_shop_url); ?>">去商城看看</a><?php endif; ?>。</p>
    <?php else: ?>
      <ul class="fo-dl-list">
        <?php foreach ($fo_dl_orders as $gid => $o): ?>
          <li class="fo-dl-item">
            <div class="fo-dl-main">
              <b><?php echo e($o['title'] !== null && $o['title'] !== '' ? $o['title'] : '资源已删除'); ?></b>
              <span class="fo-dl-meta">兑换于 <?php echo e(format_time($o['created_at'], 'Y-m-d H:i')); ?> · 花费 <?php echo (int)$o['price']; ?> <?php echo e($fo_dl_unit); ?></span>
            </div>
            <?php if (!empty($o['download_url'])): ?>
              <a class="fo-btn fo-shop-btn" href="<?php echo e(theme_url('_download.php')); ?>?g=<?php echo (int)$gid; ?>">下载</a>
            <?php else: ?>
              <span class="fo-dl-off">资源暂不可用</span>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <?php if (!empty($fo_dl_all)): ?>
      <h2 class="fo-shop-title fo-shop-title--sub">全部资源</h2>
      <ul class="fo-dl-all">
        <?php foreach ($fo_dl_all as $g): ?>
          <?php $owned = isset($fo_dl_orders[(int)$g['id']]); ?>
          <li>
            <span class="fo-dl-all-title"><?php echo e($g['title']); ?></span>
            <span class="fo-dl-all-price"><?php echo $owned ? '已拥有' : ((int)$g['price'] . ' ' . e($fo_dl_unit)); ?></span>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
</div>