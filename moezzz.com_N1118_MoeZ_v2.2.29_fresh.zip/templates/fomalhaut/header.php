<?php
/**
 * 星辉 · Fomalhaut 模板 · 公共头部
 * 结构：吸顶半透明胶囊导航（站标 / 居中菜单 / 工具图标）
 * 可用变量：$site $nav_cats；可选 $cur_p $page_title
 */
require_once __DIR__ . '/_lib.php';

$cur = isset($cur_p) ? $cur_p : 'index';
$fo_accent = trim(fo_opt('accent', '#35b8ab'));
if (!preg_match('/^#[0-9a-fA-F]{6}$/', $fo_accent)) $fo_accent = '#35b8ab';
$fo_logo = trim(fo_opt('logo', ''));
$fo_logo_url = $fo_logo !== '' ? media_url($fo_logo) : '';
$fo_logo_mode = fo_opt('logo_mode', 'text') === 'image' ? 'image' : 'text';
$fo_site_icon = trim(fo_opt('site_icon', ''));
if ($fo_site_icon !== '') {
    $fo_favicon = media_url($fo_site_icon);
} elseif (!empty($site['avatar'])) {
    $fo_favicon = media_url($site['avatar']);
} else {
    $fo_favicon = theme_url('assets/favicon.svg');
}
$fo_stats_url = fo_stats_url();
$fo_search_url = search_url('');

/* 2.1.8：首页 Hero 越过导航栏 —— 导航透明叠加在背景前，滚动后恢复实底 */
$fo_hero_under = ($cur === 'index' && fo_on('show_hero', '1'));

/* 用户中心（1.6.0）：登录后导航显示头像，未登录显示登录入口
   2.1.0：程序统一用 current_user()（moe_front_user 是旧名，已不存在），
          入口指向核心 /user，登录后直接进用户中心主页（含签到、积分、下载）。 */
$fo_user_on = fo_on('show_user_center', '1');
$fo_me = function_exists('current_user') ? current_user() : null;
$fo_user_url = base_url() . 'user';
$fo_me_name = $fo_me ? (trim((string)$fo_me['nickname']) !== '' ? $fo_me['nickname'] : $fo_me['username']) : '';
$fo_me_ava = ($fo_me && !empty($fo_me['avatar'])) ? (string)$fo_me['avatar'] : '';
$fo_shop_on = function_exists('moe_pt_shop_on') ? moe_pt_shop_on() : false;

/* 模板设置：自定义导航菜单（每行一个「名称|链接」，按行顺序显示，可控制前后） */
$fo_menu = array();
$fo_menu_custom = false;
foreach (preg_split('/\r\n|\r|\n/', fo_opt('nav_menu', '')) as $line) {
    $line = trim($line);
    if ($line === '') continue;
    $p = array_map('trim', explode('|', $line));
    if (($p[0] ?? '') === '') continue;
    $fo_menu[] = array('title' => $p[0], 'url' => ($p[1] ?? '') !== '' ? $p[1] : home_url(), 'key' => 'custom');
    $fo_menu_custom = true;
}

/* 未自定义时使用模板默认菜单（2.1.27 起与站点实际导航对齐：首页/归档/文章/积分商城/友链/版娘/关于）
   「统计」等模板里存在但默认不收的入口，站长在「自定义导航菜单」里加一行即可 */
if (empty($fo_menu)) {
    $fo_menu = array(
        array('title' => '首页', 'url' => home_url(), 'key' => 'index'),
        array('title' => '归档', 'url' => base_url() . 'archives', 'key' => 'archive'),
        array('title' => '文章', 'url' => base_url() . 'blog/article', 'key' => 'article'),
    );
    // 2.1.0：积分商城入口（后台开启商城且上架了资源时才出现）
    if ($fo_shop_on) {
        $fo_menu[] = array('title' => '积分商城', 'url' => base_url() . 'shop', 'key' => 'shop');
    }
    // 2.1.23：友链与看板娘小屋
    $fo_menu[] = array('title' => '友链', 'url' => base_url() . 'links', 'key' => 'link');
    $fo_menu[] = array('title' => '版娘', 'url' => base_url() . 'companion', 'key' => 'companion');
    $fo_menu[] = array('title' => '关于', 'url' => base_url() . 'about', 'key' => 'about');
}

/* 模板设置：导航栏追加分类链接（自定义菜单时不再追加，避免重复） */
if (fo_on('nav_show_cats', '0') && !$fo_menu_custom) {
    try {
        $fo_nav_cats = rows('SELECT * FROM ' . moe_table('categories') . ' ORDER BY sort, id LIMIT 8');
        foreach ((array)$fo_nav_cats as $c) {
            $fo_menu[] = array('title' => $c['name'], 'url' => cat_url($c), 'key' => 'cat-' . (int)$c['id']);
        }
    } catch (Throwable $e) {
        // 分类不可用时不追加
    }
}

$fo_icon = function ($name) {
    $icons = array(
        'search' => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m16.5 16.5 4 4"/></svg>',
        'rss'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM5 11a8 8 0 0 1 8 8"/><path d="M5 5a14 14 0 0 1 14 14"/></svg>',
        'top'    => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V6"/><path d="m6 12 6-6 6 6"/></svg>',
        'star'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6l2.7 6.1 6.6.6-5 4.4 1.5 6.5-5.8-3.4-5.8 3.4 1.5-6.5-5-4.4 6.6-.6z"/></svg>',
        'user'   => '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/></svg>',
    );
    return isset($icons[$name]) ? $icons[$name] : '';
};
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php echo seo_head(); ?>
<meta name="theme-color" content="<?php echo e($fo_accent); ?>">
<link rel="icon" href="<?php echo e($fo_favicon); ?>">
<link rel="apple-touch-icon" href="<?php echo e($fo_favicon); ?>">
<link rel="alternate" type="application/rss+xml" title="<?php echo e($site['name']); ?>" href="<?php echo e(rss_url()); ?>">
<link rel="stylesheet" href="<?php echo e(theme_url('assets/style.css')); ?>?v=<?php echo defined('FO_ASSET_VER') ? FO_ASSET_VER : MOE_VERSION; ?>">
<?php
/* 2.1.14 加载优化：首页 Hero 背景图是首屏最大元素（LCP），提前发起请求，
   不必等 CSS/HTML 解析到该节点才开始下载；视频背景不 preload（会抢带宽） */
$fo_pl_bg = ($cur === 'index' && fo_on('show_hero', '1')) ? trim(fo_opt('hero_bg', '')) : '';
if ($fo_pl_bg !== '' && !preg_match('/\.(mp4|webm|ogv|mov|m4v)(\?|#|$)/i', $fo_pl_bg)) {
    echo '<link rel="preload" as="image" href="' . e(media_url($fo_pl_bg)) . '" fetchpriority="high">' . "\n";
}
?>
<script defer src="<?php echo e(theme_url('assets/app.js')); ?>?v=<?php echo defined('FO_ASSET_VER') ? FO_ASSET_VER : MOE_VERSION; ?>"></script>
<style>
:root{
  --fo-accent: <?php echo e($fo_accent); ?>;
  --fo-accent-soft: color-mix(in srgb, <?php echo e($fo_accent); ?> 14%, #ffffff);
  --fo-accent-line: color-mix(in srgb, <?php echo e($fo_accent); ?> 34%, #ffffff);
}
<?php if (fo_on('hero_typing', '0')): ?>
.fo-typing::after{ content:'|'; margin-left:3px; font-weight:400; animation:foBlink 1s steps(1) infinite; }
@keyframes foBlink{ 50%{ opacity:0 } }
<?php endif; ?>
<?php if (fo_opt('mobile_columns', '1') === '2'): ?>
@media (max-width: 720px){
  .fo-grid{ grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px; }
  .fo-card-title{ font-size: 15px; }
  .fo-meta{ font-size: 12px; gap: 8px; }
}
<?php endif; ?>
</style>
</head>
<body class="fo-body<?php echo !empty($fo_hero_under) ? ' fo-hero-under' : ''; ?>">

<header class="fo-header" id="fo-header">
  <div class="fo-header-in">
    <a class="fo-brand" href="<?php echo e(home_url()); ?>">
      <?php if ($fo_logo_mode === 'image'): ?>
        <?php if ($fo_logo_url !== ''): ?>
          <img class="fo-brand-img" src="<?php echo e($fo_logo_url); ?>" alt="<?php echo e($site['name']); ?>" decoding="async">
        <?php else: ?>
          <span class="fo-brand-star"><?php echo $fo_icon('star'); ?></span>
        <?php endif; ?>
      <?php else: ?>
        <span class="fo-brand-star"><?php echo $fo_icon('star'); ?></span>
        <span class="fo-brand-name"><?php echo e($site['name']); ?></span>
      <?php endif; ?>
    </a>

    <nav class="fo-nav" aria-label="站内导航">
      <?php foreach ($fo_menu as $m): ?>
        <a class="fo-nav-link <?php echo $m['key'] === $cur ? 'is-active' : ''; ?>" href="<?php echo e($m['url']); ?>"><?php echo e($m['title']); ?></a>
      <?php endforeach; ?>
      <div class="fo-side-drawer" id="fo-side-drawer"></div>
    </nav>

    <div class="fo-tools">
      <?php if ($fo_user_on): ?>
      <?php
      /* 导航用户入口（2.1.25）：未登录点击弹出登录/注册弹窗，登录后显示头像并可进入个人中心 */
      $fo_nav_ava = $fo_me_ava !== '' ? media_url($fo_me_ava) : theme_url('assets/avatar.svg');
      ?>
      <?php if ($fo_me): ?>
      <a class="fo-tool fo-tool--user fo-tool--avatar is-in" href="<?php echo e($fo_user_url); ?>" title="个人中心 · <?php echo e($fo_me_name); ?>" aria-label="用户中心">
        <img class="fo-tool-ava" src="<?php echo e($fo_nav_ava); ?>" alt="<?php echo e($fo_me_name); ?>" width="28" height="28" decoding="async" referrerpolicy="no-referrer">
      </a>
      <?php else: ?>
      <button class="fo-tool fo-tool--user fo-tool--avatar" type="button" id="fo-auth-open" title="登录 / 用户中心" aria-label="登录 / 用户中心" aria-haspopup="dialog">
        <img class="fo-tool-ava" src="<?php echo e(theme_url('assets/avatar.svg')); ?>" alt="未登录" width="28" height="28" decoding="async">
      </button>
      <?php endif; ?>
      <?php endif; ?>
      <a class="fo-tool" href="<?php echo e($fo_search_url); ?>" aria-label="搜索"><?php echo $fo_icon('search'); ?></a>
      <a class="fo-tool fo-tool--rss" href="<?php echo e(rss_url()); ?>" target="_blank" rel="noopener" aria-label="RSS"><?php echo $fo_icon('rss'); ?></a>
      <button class="fo-tool" type="button" id="fo-to-top" aria-label="回到顶部"><?php echo $fo_icon('top'); ?></button>
    </div>

    <button class="fo-nav-toggle" type="button" id="fo-nav-toggle" aria-label="展开菜单" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
  </div>
</header>

<?php if ($fo_user_on && !$fo_me): ?>
<?php
/* 2.1.25：弹窗登录 / 注册（未登录时导航头像点击弹出），双栏样式：左侧大图 + 右侧表单。
   Token 与验证码都从 _auth.php 现取，页面缓存里的旧 Token 不影响登录。
   左侧图片：模板设置「登录弹窗左侧图片」，留空回退首页 Hero 背景图，再留空显示星海渐变。 */
$fo_reg_on = setting('user_register', '0') === '1';
$fo_cap_on = setting('login_captcha', '0') === '1';
$fo_auth_bg = trim(fo_opt('auth_bg', ''));
if ($fo_auth_bg === '' || preg_match('/\.(mp4|webm|ogv|mov|m4v)(\?|#|$)/i', $fo_auth_bg)) {
    $__maybe = trim(fo_opt('hero_bg', ''));
    $fo_auth_bg = ($__maybe !== '' && !preg_match('/\.(mp4|webm|ogv|mov|m4v)(\?|#|$)/i', $__maybe)) ? $__maybe : '';
}
unset($__maybe);
?>
<div class="fo-auth" id="fo-auth" hidden>
  <div class="fo-auth-mask" data-fo-auth-close></div>
  <div class="fo-auth-box" role="dialog" aria-modal="true" aria-label="登录 / 注册">
    <div class="fo-auth-pic"<?php echo $fo_auth_bg !== '' ? ' style="background-image:url(' . e(media_url($fo_auth_bg)) . ');"' : ''; ?>>
      <?php if ($fo_auth_bg === ''): ?><span class="fo-auth-pic-star">✦</span><?php endif; ?>
    </div>

    <div class="fo-auth-dialog">
      <button class="fo-auth-x" type="button" data-fo-auth-close aria-label="关闭">✕</button>
      <h3 class="fo-auth-title" id="fo-auth-title">账户登录</h3>
      <p class="fo-auth-sub" id="fo-auth-sub">欢迎回来，登录后即可参与评论与互动</p>

      <form class="fo-auth-form is-on" data-form="login" novalidate>
        <label class="fo-auth-field"><span>👤</span><input type="text" name="username" placeholder="用户名 / 邮箱" autocomplete="username" required></label>
        <label class="fo-auth-field"><span>🔒</span><input type="password" name="password" placeholder="密码" autocomplete="current-password" required></label>
        <?php if ($fo_cap_on): ?>
        <div class="fo-auth-field fo-auth-field--cap">
          <label class="fo-auth-field-in"><span>🛡</span><input type="text" name="captcha" maxlength="4" placeholder="图形验证码" style="text-transform:uppercase" required></label>
          <img class="fo-auth-capimg" id="fo-auth-capimg" src="<?php echo e(base_url() . 'admin/captcha.php?t=' . time()); ?>" alt="验证码" title="看不清？点我刷新">
        </div>
        <?php endif; ?>
        <label class="fo-auth-remember"><input type="checkbox" name="remember" value="1"> 记住登录状态</label>
        <button class="fo-auth-btn" type="submit">登 录</button>
        <p class="fo-auth-msg" hidden></p>
        <?php if ($fo_reg_on): ?><p class="fo-auth-swap">没有账号？<a href="javascript:;" data-tab-go="register">注册新账号</a></p><?php endif; ?>
      </form>

      <?php if ($fo_reg_on): ?>
      <form class="fo-auth-form" data-form="register" hidden novalidate>
        <label class="fo-auth-field"><span>👤</span><input type="text" name="username" maxlength="32" placeholder="用户名（2-32 位）" autocomplete="username" required></label>
        <label class="fo-auth-field"><span>✉️</span><input type="email" name="email" maxlength="100" placeholder="邮箱（选填）" autocomplete="email"></label>
        <label class="fo-auth-field"><span>🔒</span><input type="password" name="password" placeholder="密码（至少 6 位）" autocomplete="new-password" required></label>
        <label class="fo-auth-field"><span>🔒</span><input type="password" name="password2" placeholder="确认密码" autocomplete="new-password" required></label>
        <label class="fo-auth-field"><span>🧮</span><input type="text" name="captcha" inputmode="numeric" placeholder="验算结果" required><b class="fo-auth-cap" id="fo-auth-cap">…</b></label>
        <button class="fo-auth-btn" type="submit">注册并登录</button>
        <p class="fo-auth-msg" hidden></p>
        <p class="fo-auth-swap">已有账号？<a href="javascript:;" data-tab-go="login">去登录</a></p>
      </form>
      <?php endif; ?>
    </div>
  </div>
</div>
<style>
.fo-auth{ position:fixed; inset:0; z-index:9990; display:flex; align-items:center; justify-content:center; padding:20px; }
.fo-auth[hidden]{ display:none; }
.fo-auth-mask{ position:absolute; inset:0; background:rgba(16,28,38,.55); backdrop-filter:blur(6px); }
.fo-auth-box{ position:relative; display:flex; width:min(780px,100%); max-height:92vh; background:#fff; border-radius:16px; box-shadow:0 30px 80px rgba(10,30,48,.4); overflow:hidden; animation:foAuthIn .22s ease; }
@keyframes foAuthIn{ from{ opacity:0; transform:translateY(14px) scale(.97); } to{ opacity:1; transform:none; } }
.fo-auth-pic{ flex:0 0 46%; min-height:500px; position:relative; background:#243043 center/cover no-repeat; }
.fo-auth-pic-star{ position:absolute; inset:0; display:grid; place-items:center; font-size:64px; color:rgba(255,255,255,.35); }
.fo-auth-dialog{ flex:1; min-width:0; padding:34px 34px 22px; overflow:auto; }
.fo-auth-x{ position:absolute; top:12px; right:12px; width:30px; height:30px; border:0; border-radius:50%; background:#f1f5f8; color:#7d90a0; font-size:13px; line-height:1; cursor:pointer; z-index:2; }
.fo-auth-x:hover{ background:#e6edf2; color:#42576a; }
.fo-auth-title{ font-size:22px; font-weight:700; color:#23384c; letter-spacing:.5px; }
.fo-auth-sub{ font-size:13px; color:#93a4b3; margin:8px 0 22px; }
.fo-auth-form{ display:none; }
.fo-auth-form.is-on{ display:block; }
.fo-auth-field{ display:flex; align-items:center; gap:9px; background:#eef3fb; border:1.5px solid transparent; border-radius:10px; padding:0 12px; margin-bottom:14px; transition:border-color .18s, background .18s; }
.fo-auth-field:focus-within{ background:#fff; border-color:var(--fo-accent); }
.fo-auth-field span{ font-size:14px; opacity:.6; flex:none; }
.fo-auth-field input{ flex:1; min-width:0; border:0; outline:0; background:transparent; padding:12px 0; font-size:14px; color:#24455c; font-family:inherit; }
.fo-auth-field--cap{ justify-content:space-between; gap:10px; }
.fo-auth-field-in{ display:flex; align-items:center; gap:9px; flex:1; min-width:0; }
.fo-auth-capimg{ height:40px; border-radius:8px; cursor:pointer; flex:none; display:block; }
.fo-auth-cap{ flex:none; font-size:13px; color:var(--fo-accent); font-weight:700; white-space:nowrap; user-select:none; }
.fo-auth-remember{ display:flex; align-items:center; gap:7px; font-size:13px; color:#7d90a0; margin:-2px 0 16px; cursor:pointer; user-select:none; }
.fo-auth-remember input{ width:15px; height:15px; accent-color:var(--fo-accent); cursor:pointer; }
.fo-auth-btn{ display:block; width:100%; border:0; cursor:pointer; padding:13px; border-radius:10px; font-size:15px; font-weight:700; letter-spacing:4px; color:#fff; font-family:inherit; background:#3a4a5e; transition:background .18s, transform .15s; }
.fo-auth-btn:hover{ background:#2f3d4e; transform:translateY(-1px); }
.fo-auth-msg{ font-size:13px; border-radius:10px; padding:9px 12px; margin:12px 0 0; line-height:1.6; }
.fo-auth-msg.is-err{ background:#fdeef1; color:#d8556e; }
.fo-auth-msg.is-ok{ background:#e9f7f1; color:#2e9e6b; }
.fo-auth-swap{ font-size:13px; color:#8fa1b0; text-align:center; margin:14px 0 0; }
.fo-auth-swap a{ color:var(--fo-accent); text-decoration:none; font-weight:600; }
@media (max-width:760px){
  .fo-auth{ padding:14px; }
  .fo-auth-pic{ display:none; }
  .fo-auth-box{ width:min(400px,100%); }
  .fo-auth-dialog{ padding:26px 22px 16px; }
}
</style>
<script>
(function(){
  var root = document.getElementById('fo-auth');
  var openBtn = document.getElementById('fo-auth-open');
  if (!root || !openBtn) return;
  var AUTH = <?php echo json_encode(theme_url('_auth.php')); ?>;
  var token = '';
  var capLoaded = false;
  var busy = false;
  var TITLES = {
    login:    ['账户登录', '欢迎回来，登录后即可参与评论与互动'],
    register: ['注册账号', '加入之后即可评论、签到与攒积分']
  };

  function q(s, p){ return (p || root).querySelector(s); }
  function qa(s, p){ return Array.prototype.slice.call((p || root).querySelectorAll(s)); }
  function msg(form, text, cls){
    var m = q('.fo-auth-msg', form);
    if (!m) return;
    if (!text){ m.hidden = true; m.textContent = ''; return; }
    m.hidden = false; m.textContent = text;
    m.className = 'fo-auth-msg ' + (cls || 'is-err');
  }
  function refreshCapImg(){
    var ci = q('#fo-auth-capimg');
    if (ci) ci.src = <?php echo json_encode(base_url() . 'admin/captcha.php?t='); ?> + Date.now();
  }
  function switchTab(name){
    qa('.fo-auth-form').forEach(function(f){
      var on = f.getAttribute('data-form') === name;
      f.classList.toggle('is-on', on);
      if (on) f.removeAttribute('hidden'); else f.setAttribute('hidden', '');
    });
    var t = TITLES[name] || TITLES.login;
    var tt = q('#fo-auth-title'); if (tt) tt.textContent = t[0];
    var ts = q('#fo-auth-sub'); if (ts) ts.textContent = t[1];
    if (name === 'register') loadCap();
    var first = q('.fo-auth-form.is-on input[name=username]');
    if (first) setTimeout(function(){ first.focus(); }, 60);
  }
  function refresh(){
    fetch(AUTH, { credentials: 'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(d){
        if (d && d.token) token = d.token;
        if (d && d.register && !q('[data-form=register]')) location.reload();
      })
      .catch(function(){});
  }
  function loadCap(){
    if (capLoaded) return;
    var capEl = q('#fo-auth-cap');
    if (!capEl) return;
    fetch(AUTH + '?act=captcha', { credentials: 'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(d){
        if (d && d.ok){ capEl.textContent = d.cap; capLoaded = true; }
      })
      .catch(function(){ capEl.textContent = '加载失败'; });
  }
  function post(form, act){
    if (busy) return;
    busy = true;
    var btn = q('.fo-auth-btn', form);
    var old = btn ? btn.textContent : '';
    if (btn) btn.textContent = '请稍候…';
    msg(form, '');
    var fd = new FormData(form);
    fd.append('act', act);
    fd.append('_token', token);
    fetch(AUTH, { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(d){
        busy = false;
        if (btn) btn.textContent = old;
        if (d && d.ok){
          msg(form, d.msg || '成功，正在刷新…', 'is-ok');
          setTimeout(function(){ location.reload(); }, 600);
        } else {
          msg(form, (d && d.msg) || '操作失败，请稍后再试', 'is-err');
          if (d && d.recap){ capLoaded = false; loadCap(); form.reset(); }
          if (q('#fo-auth-capimg')) refreshCapImg();   // 登录失败刷新图形验证码
          refresh();
        }
      })
      .catch(function(){
        busy = false;
        if (btn) btn.textContent = old;
        msg(form, '网络异常，请稍后再试', 'is-err');
        if (q('#fo-auth-capimg')) refreshCapImg();
        refresh();
      });
  }
  function open(){
    root.removeAttribute('hidden');
    document.body.style.overflow = 'hidden';
    refresh();
    var first = q('.fo-auth-form.is-on input[name=username]');
    if (first) setTimeout(function(){ first.focus(); }, 60);
  }
  function close(){
    root.setAttribute('hidden', '');
    document.body.style.overflow = '';
  }
  openBtn.addEventListener('click', open);
  qa('[data-fo-auth-close]').forEach(function(el){ el.addEventListener('click', close); });
  document.addEventListener('keydown', function(ev){ if (ev.key === 'Escape' && !root.hasAttribute('hidden')) close(); });
  qa('[data-tab-go]').forEach(function(a){
    a.addEventListener('click', function(ev){ ev.preventDefault(); switchTab(a.getAttribute('data-tab-go')); });
  });
  var ci = q('#fo-auth-capimg');
  if (ci) ci.addEventListener('click', refreshCapImg);
  var loginForm = q('[data-form=login]');
  var regForm = q('[data-form=register]');
  if (loginForm) loginForm.addEventListener('submit', function(ev){ ev.preventDefault(); post(loginForm, 'login'); });
  if (regForm) regForm.addEventListener('submit', function(ev){ ev.preventDefault(); post(regForm, 'register'); });
})();
</script>
<?php endif; ?>

<main class="fo-main">