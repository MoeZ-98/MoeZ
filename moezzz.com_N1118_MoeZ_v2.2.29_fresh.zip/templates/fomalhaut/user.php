<?php
/**
 * 星辉 · Fomalhaut 模板 · 用户中心
 * 可用变量：$act (login|register|profile) $me (当前用户|null) $err $okmsg；公共变量 $site
 * 路由（程序 1.8.13+）：/user/login /user/register /user/profile /user/logout
 */
$err = isset($err) ? (string)$err : '';
$okmsg = isset($okmsg) ? (string)$okmsg : '';
$cur_p = 'user';
$page_title = $act === 'profile' ? '个人中心' : ($act === 'register' ? '注册账号' : '登录');
include partial_path('header.php');

$fo_u_title = $page_title;
$fo_u_me_name = $me ? ($me['nickname'] !== '' ? $me['nickname'] : $me['username']) : '';
$fo_u_me_ava = ($me && !empty($me['avatar'])) ? (string)$me['avatar'] : '';
$fo_u_is_admin = $me && isset($me['role']) && $me['role'] === 'admin';

/* 积分 / 签到数据（个人中心才需要） */
$fo_u_points = null;
if ($act === 'profile' && $me) {
    require_once __DIR__ . '/_shop.php';
    $fo_u_uid = (int)$me['id'];
    $fo_u_points = array(
        'balance' => fo_points_balance($fo_u_uid),
        'sign'    => fo_signin_status($fo_u_uid),
        'logs'    => fo_points_logs($fo_u_uid, 8),
        'orders'  => fo_user_orders($fo_u_uid),
        'unit'    => fo_points_name(),
        'left'    => fo_comment_points_left($fo_u_uid),
        'cp_on'   => ((int)fo_opt('comment_points', '2') > 0),
        'ready'   => fo_shop_ready(),
    );
    $fo_u_shop_slug = trim(fo_opt('shop_slug', 'shop'));
    $fo_u_dl_slug = trim(fo_opt('downloads_slug', 'downloads'));
    $fo_u_shop_url = $fo_u_shop_slug !== '' ? base_url() . 'page/' . rawurlencode($fo_u_shop_slug) . '.html' : '';
    $fo_u_dl_url = $fo_u_dl_slug !== '' ? base_url() . 'page/' . rawurlencode($fo_u_dl_slug) . '.html' : '';
}
?>
<div class="fo-wrap fo-wrap--user">
  <div class="fo-content fo-content--user">
    <article class="fo-panel fo-user-panel">
      <div class="fo-user-head">
        <span class="fo-user-star">✦</span>
        <h1 class="fo-user-title"><?php echo e($fo_u_title); ?></h1>
        <p class="fo-user-sub"><?php echo $act === 'profile' ? '管理你的资料与密码' : '登录后评论免填昵称邮箱'; ?></p>
      </div>

      <?php if ($err !== ''): ?><p class="fo-user-msg is-err">⚠️ <?php echo e($err); ?></p><?php endif; ?>
      <?php if ($okmsg !== ''): ?><p class="fo-user-msg is-ok">✅ <?php echo e($okmsg); ?></p><?php endif; ?>

      <?php if ($act === 'login'): ?>
      <form method="post" action="<?php echo e(base_url() . 'user/login'); ?>" class="fo-user-form">
        <?php echo csrf_field(); ?>
        <label class="fo-user-label">用户名</label>
        <input class="fo-user-input" type="text" name="username" required autofocus maxlength="32" placeholder="请输入用户名" autocomplete="username">
        <label class="fo-user-label">密码</label>
        <input class="fo-user-input" type="password" name="password" required placeholder="请输入密码" autocomplete="current-password">
        <button class="fo-btn fo-btn--wide fo-user-btn" type="submit">登 录 ✦</button>
      </form>
      <p class="fo-user-tip">还没有账号？<a href="<?php echo e(base_url() . 'user/register'); ?>">去注册 →</a></p>

      <?php elseif ($act === 'register'): ?>
      <form method="post" action="<?php echo e(base_url() . 'user/register'); ?>" class="fo-user-form">
        <?php echo csrf_field(); ?>
        <label class="fo-user-label">用户名 <i>（2-32 位中文 / 字母 / 数字 / 下划线）</i></label>
        <input class="fo-user-input" type="text" name="username" required autofocus maxlength="32" placeholder="给自己起个名字吧" autocomplete="username">
        <label class="fo-user-label">邮箱 <i>（选填，仅站长可见）</i></label>
        <input class="fo-user-input" type="email" name="email" maxlength="100" placeholder="you@example.com">
        <label class="fo-user-label">密码 <i>（至少 6 位）</i></label>
        <input class="fo-user-input" type="password" name="password" required placeholder="设置密码" autocomplete="new-password">
        <label class="fo-user-label">确认密码</label>
        <input class="fo-user-input" type="password" name="password2" required placeholder="再输一遍" autocomplete="new-password">
        <button class="fo-btn fo-btn--wide fo-user-btn" type="submit">注册并登录 ✦</button>
      </form>
      <p class="fo-user-tip">已有账号？<a href="<?php echo e(base_url() . 'user/login'); ?>">去登录 →</a></p>

      <?php else: /* profile */ ?>
      <div class="fo-user-me">
        <?php if ($fo_u_me_ava !== ''): ?>
          <img class="fo-user-me-ava" src="<?php echo e($fo_u_me_ava); ?>" alt="" referrerpolicy="no-referrer">
        <?php else: ?>
          <span class="fo-user-me-face"><?php echo e(initial($fo_u_me_name)); ?></span>
        <?php endif; ?>
        <div class="fo-user-me-info">
          <b><?php echo e($fo_u_me_name); ?></b>
          <span><?php echo $fo_u_is_admin ? '👑 站长' : '🙂 会员'; ?> · 加入于 <?php echo e(format_time($me['created_at'], 'Y-m-d')); ?></span>
        </div>
      </div>
      <form method="post" action="<?php echo e(base_url() . 'user/profile'); ?>" class="fo-user-form">
        <?php echo csrf_field(); ?>
        <label class="fo-user-label">昵称 <i>（评论时展示的名字）</i></label>
        <input class="fo-user-input" type="text" name="nickname" maxlength="32" value="<?php echo e($me['nickname']); ?>" placeholder="展示用的昵称">
        <label class="fo-user-label">邮箱 <i>（用于匹配你发出的评论头像）</i></label>
        <input class="fo-user-input" type="email" name="email" maxlength="100" value="<?php echo e($me['email']); ?>" placeholder="you@example.com">
        <label class="fo-user-label">头像图片地址 <i>（选填，https://…）</i></label>
        <input class="fo-user-input" type="text" name="avatar" maxlength="255" value="<?php echo e($me['avatar']); ?>" placeholder="https://example.com/avatar.png">
        <label class="fo-user-label">原密码 <i>（修改密码时填写）</i></label>
        <input class="fo-user-input" type="password" name="oldpass" placeholder="不修改就留空" autocomplete="current-password">
        <label class="fo-user-label">新密码</label>
        <input class="fo-user-input" type="password" name="newpass" placeholder="至少 6 位，不修改就留空" autocomplete="new-password">
        <button class="fo-btn fo-btn--wide fo-user-btn" type="submit">保存资料 ✦</button>
      </form>
      <?php if ($fo_u_points): ?>
      <div class="fo-points-card">
        <div class="fo-points-top">
          <div>
            <span class="fo-points-label">我的<?php echo e($fo_u_points['unit']); ?></span>
            <b class="fo-points-balance"><?php echo (int)$fo_u_points['balance']; ?></b>
          </div>
          <div class="fo-points-sign">
            <?php if ($fo_u_points['sign']['signed']): ?>
              <span class="fo-points-signed">今日已签到 · 连签 <?php echo (int)$fo_u_points['sign']['streak']; ?> 天</span>
            <?php else: ?>
              <button type="button" class="fo-btn fo-points-btn" id="fo-signin-btn"
                      data-url="<?php echo e(theme_url('_signin.php')); ?>"
                      data-token="<?php echo e(csrf_token()); ?>">签到领 <?php echo max(0, (int)fo_opt('sign_points', '5')); ?> <?php echo e($fo_u_points['unit']); ?></button>
              <span class="fo-points-signed" id="fo-signin-msg" hidden></span>
            <?php endif; ?>
          </div>
        </div>
        <p class="fo-points-tip">
          <?php if (!$fo_u_points['ready']): ?>积分数据表未就绪，请检查数据库建表权限。
          <?php else: ?>
            每天签到有基础积分，连签还有额外加成；<?php if ($fo_u_points['cp_on']): ?>发表评论也能攒 <?php echo e($fo_u_points['unit']); ?>（今天还剩 <?php echo (int)$fo_u_points['left']; ?> 次得分机会）。<?php else: ?>评论得分当前已关闭，积分主要来自签到与管理员调整。<?php endif; ?>
          <?php endif; ?>
        </p>
        <div class="fo-points-links">
          <?php if ($fo_u_shop_url !== ''): ?><a class="fo-btn fo-btn--ghost" href="<?php echo e($fo_u_shop_url); ?>">🛒 积分商城</a><?php endif; ?>
          <?php if ($fo_u_dl_url !== ''): ?><a class="fo-btn fo-btn--ghost" href="<?php echo e($fo_u_dl_url); ?>">📥 下载中心（<?php echo count($fo_u_points['orders']); ?>）</a><?php endif; ?>
        </div>
        <?php if (!empty($fo_u_points['logs'])): ?>
          <ul class="fo-points-log">
            <?php foreach ($fo_u_points['logs'] as $fo_lg): ?>
              <li>
                <span class="fo-points-log-note"><?php echo e($fo_lg['note'] !== '' ? $fo_lg['note'] : $fo_lg['type']); ?></span>
                <b class="<?php echo (int)$fo_lg['amount'] >= 0 ? 'is-plus' : 'is-minus'; ?>"><?php echo (int)$fo_lg['amount'] > 0 ? '+' : ''; ?><?php echo (int)$fo_lg['amount']; ?></b>
                <i><?php echo e(format_time($fo_lg['created_at'], 'm-d H:i')); ?></i>
              </li>
            <?php endforeach; ?>
          </ul>
        <?php endif; ?>
      </div>
      <?php endif; ?>

      <div class="fo-user-acts">
        <?php if ($fo_u_is_admin): ?>
          <a class="fo-user-act" href="<?php echo e(base_url() . 'admin/'); ?>">⚙️ 管理后台</a>
        <?php endif; ?>
        <a class="fo-user-act" href="<?php echo e(base_url() . 'archives'); ?>">📚 文章归档</a>
        <a class="fo-user-act fo-user-act--out" href="<?php echo e(base_url() . 'user/logout'); ?>">🚪 退出登录</a>
      </div>
      <?php endif; ?>
    </article>
  </div>
</div>

<?php include partial_path('footer.php'); ?>
