<?php
/**
 * 星辉 · Fomalhaut 模板 · 首页
 * Hero 星空问候区 + 精选文章 + 分类索引 + 卡片瀑布 + 右侧信息栏
 * 可用变量：$posts $pager $page $total $site $nav_cats
 */
$cur_p = 'index';
include partial_path('header.php');

$fo_hero   = fo_on('show_hero', '1');
$fo_hero_bg = trim(fo_opt('hero_bg', ''));
$fo_hero_img = $fo_hero_bg !== '' ? media_url($fo_hero_bg) : theme_url('assets/hero.svg');
$fo_sub    = trim(fo_opt('hero_subtitle', ''));
if ($fo_sub === '') $fo_sub = 'Welcome to ' . $site['name'];
$fo_hero_title = trim(fo_opt('hero_title', ''));
if ($fo_hero_title === '') $fo_hero_title = $site['name'];

/* 2.1.13：精选大卡 + 索引区在所有分页都显示（此前只在第 1 页出现）。
   大卡文章已由核心从每页列表查询中整体排除（标准「每页 N 篇」分页），
   因此翻页后重复渲染大卡不会吞掉本页任何文章；索引区为独立查询，同样安全。 */
$fo_page_no = max(1, (int)$page);

/* ===== 2.1.4 首页三大区块各自独立、互不挤占（修复部分文章不显示） =====
   ① 精选大卡：开关 + 模式。大卡文章 ID 由 fo_home_featured_id() 统一决定
      （核心首页查询已把这篇文章从列表中整体排除），因此大卡与网格零重叠、
      每页卡片数严格 = 后台「每页文章数」、不漏文章。
   ② 索引区：模式 + 数量（catbox_count），单独查询
   ③ 文章卡片网格：核心已按后台「每页文章数」排除大卡文章后查询，直接使用 */
$fo_list = !empty($posts) ? array_values($posts) : array();
$fo_featured = null;
if (fo_on('show_featured', '1')) {
    $fo_feat_id = function_exists('fo_home_featured_id') ? (int)fo_home_featured_id() : 0;
    if ($fo_feat_id > 0) {
        try {
            $fo_featured = row('SELECT p.*, c.name AS cat_name FROM ' . moe_table('posts') . ' p LEFT JOIN ' . moe_table('categories') . " c ON c.id = p.category_id WHERE p.id = " . $fo_feat_id);
        } catch (Throwable $e) {
            $fo_featured = null;
        }
    }
}
/* 安全兜底：若核心文件未同步更新（列表仍含大卡文章），去重避免一篇文章出现两次 */
if ($fo_featured) {
    foreach ($fo_list as $fo_k => $fo_p) {
        if ((int)$fo_p['id'] === (int)$fo_featured['id']) { unset($fo_list[$fo_k]); }
    }
    $fo_list = array_values($fo_list);
}
$fo_typing = fo_on('hero_typing', '0');

/* 2.1.10：Hero 高度 PC / 手机端分别自定义（CSS 变量注入，留空用默认响应式高度） */
$fo_hero_h = trim((string)fo_opt('hero_height', ''));
$fo_hero_hm = trim((string)fo_opt('hero_height_mobile', ''));
$fo_hero_style = '';
if ($fo_hero_h !== '' && (int)$fo_hero_h > 120) $fo_hero_style .= '--fo-hero-h:' . (int)$fo_hero_h . 'px;';
if ($fo_hero_hm !== '' && (int)$fo_hero_hm > 120) $fo_hero_style .= '--fo-hero-h-m:' . (int)$fo_hero_hm . 'px;';

/* 2.1.8：Hero 支持视频背景（mp4/webm/mov 等），GIF 当图片直接可用 */
$fo_hero_is_video = $fo_hero_bg !== '' && preg_match('/\.(mp4|webm|ogv|mov|m4v)(\?|#|$)/i', $fo_hero_bg);

/* 首页标题/简介底色块 */
$fo_tb_opacity = (int)fo_opt('hero_text_bg_opacity', '0');
$fo_tb_rgba = $fo_tb_opacity > 0 ? fo_rgba(fo_opt('hero_text_bg', '#0b2534'), $fo_tb_opacity) : '';

/* 分类及文章数 */
$fo_cats = array();
try {
    $fo_cats = rows('SELECT c.*, (SELECT COUNT(*) FROM ' . moe_table('posts') . " p WHERE p.category_id = c.id AND p.type='post' AND p.status='published') AS cnt"
        . ' FROM ' . moe_table('categories') . ' c ORDER BY c.sort, c.id');
} catch (Throwable $e) {
    $fo_cats = array();
}

/* 侧栏开关汇总：side.php 部件内部同样会校验，全部关闭时正文占满版心 */
$fo_side_on = fo_side_enabled();
$fo_wrap_class = 'fo-wrap';
if (!$fo_side_on) $fo_wrap_class .= ' fo-wrap--noside';
if (!$fo_hero) $fo_wrap_class .= ' fo-wrap--nohero';
?>
<?php if ($fo_hero): ?>
<?php if ($fo_hero_is_video): ?>
<section class="fo-hero fo-hero--video"<?php echo $fo_hero_style !== '' ? ' style="' . e($fo_hero_style) . '"' : ''; ?>>
  <video class="fo-hero-video" src="<?php echo e($fo_hero_img); ?>" autoplay muted loop playsinline preload="auto"></video>
<?php else: ?>
<section class="fo-hero" style="background-image:linear-gradient(180deg,rgba(14,32,52,.18),rgba(14,32,52,.42)),url('<?php echo e($fo_hero_img); ?>');<?php echo e($fo_hero_style); ?>">
<?php endif; ?>
  <div class="fo-hero-center<?php echo $fo_tb_rgba !== '' ? ' has-bg' : ''; ?>"<?php if ($fo_tb_rgba !== ''): ?> style="background:<?php echo e($fo_tb_rgba); ?>"<?php endif; ?>>
    <h1 class="fo-hero-title"><?php echo e($fo_hero_title); ?><span class="fo-hero-star">✦</span></h1>
    <p class="fo-hero-sub<?php echo $fo_typing ? ' fo-typing' : ''; ?>"<?php if ($fo_typing): ?> data-text="<?php echo e($fo_sub); ?>"<?php endif; ?>><?php echo e($fo_sub); ?></p>
  </div>
  <a class="fo-hero-scroll" href="#fo-start" aria-label="向下浏览"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg></a>
</section>
<?php endif; ?>

<?php if ($fo_typing): ?>
<?php endif; ?>

<div class="fo-rail" aria-label="快捷操作">
  <button type="button" class="fo-rail-btn" onclick="window.scrollTo({top:0,behavior:'smooth'})" title="回到顶部">
    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V6"/><path d="m6 12 6-6 6 6"/></svg>
  </button>
  <a class="fo-rail-btn" href="<?php echo e(search_url('')); ?>" title="搜索">
    <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m16.5 16.5 4 4"/></svg>
  </a>
  <a class="fo-rail-btn" href="<?php echo e(rss_url()); ?>" target="_blank" rel="noopener" title="订阅">
    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM5 11a8 8 0 0 1 8 8"/><path d="M5 5a14 14 0 0 1 14 14"/></svg>
  </a>
  <button type="button" class="fo-rail-btn" onclick="window.scrollTo({top:document.body.scrollHeight,behavior:'smooth'})" title="到底部">
    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v13"/><path d="m6 12 6 6 6-6"/></svg>
  </button>
</div>

<div class="<?php echo $fo_wrap_class; ?>" id="fo-start">
  <div class="fo-content">

    <?php /* 2.1.27：Hero 与精选大卡之间的栏头 —— 首屏到内容之间原本空一块，太空 */ ?>
    <?php if ($fo_featured || !empty($fo_list)): ?>
    <div class="fo-sechead">
      <h2 class="fo-sechead-t"><i>✦</i>最新更新<em>共 <?php echo (int)$total; ?> 篇</em></h2>
      <a class="fo-sechead-more" href="<?php echo e(base_url() . 'blog/article'); ?>">全部文章<i>›</i></a>
    </div>
    <?php endif; ?>

    <?php if ($fo_featured): ?>
    <?php $fc = fo_cover($fo_featured); ?>
    <article class="fo-featured">
      <a class="fo-featured-cover" href="<?php echo e(fo_item_url($fo_featured)); ?>" style="background:<?php echo e($fc['style']); ?>">
        <?php echo fo_cover_img_tag($fc['url'], true); ?>
        <span class="fo-featured-glow"></span>
      </a>
      <div class="fo-featured-body">
        <span class="fo-featured-date"><?php echo e(format_time($fo_featured['created_at'], 'Y-m-d')); ?></span>
        <h2 class="fo-featured-title"><a href="<?php echo e(fo_item_url($fo_featured)); ?>"><?php echo e($fo_featured['title']); ?></a></h2>
        <p class="fo-featured-desc"><?php echo e(post_excerpt($fo_featured, 90)); ?></p>
        <div class="fo-featured-foot">
          <?php if (!empty($fo_featured['cat_name'])): ?><span class="fo-chip-mini"><?php echo e($fo_featured['cat_name']); ?></span><?php endif; ?>
          <span class="fo-dot-line"><i></i><i></i><i></i></span>
        </div>
      </div>
      <div class="fo-featured-dots" aria-hidden="true"><span></span><span></span><span></span></div>
    </article>
    <?php endif; ?>

    <?php
    /* 分类索引区：模板设置可选「分类索引 / 随机文章 / 热门文章」+ 独立数量设置
       2.1.13 起所有分页均渲染；随机/热门为独立查询，与文章列表分页互不影响 */
    $fo_catbox_mode = fo_opt('catbox_mode', 'cats');
    $fo_catbox_n = max(2, min(10, (int)fo_opt('catbox_count', '6')));
    $fo_catbox_items = array();
    if ($fo_catbox_mode === 'random' || $fo_catbox_mode === 'hot') {
        /* 2.1.27：索引区改显示文章封面缩略图，查询带上 cover；老库没有 cover 时自动退回降级列 */
        foreach (array('id, title, views, cover', 'id, title, views') as $fo_cb_cols) {
            try {
                if ($fo_catbox_mode === 'random') {
                    /* 随机：取最近 100 篇在 PHP 里洗牌抽取（不依赖数据库 RAND()） */
                    $fo_cb_pool = rows('SELECT ' . $fo_cb_cols . ' FROM ' . moe_table('posts') . " WHERE type='post' AND status='published' ORDER BY created_at DESC, id DESC LIMIT 100");
                    if (!empty($fo_cb_pool)) {
                        shuffle($fo_cb_pool);
                        $fo_catbox_items = array_slice($fo_cb_pool, 0, $fo_catbox_n);
                    }
                } else {
                    $fo_catbox_items = rows('SELECT ' . $fo_cb_cols . ' FROM ' . moe_table('posts') . " WHERE type='post' AND status='published' ORDER BY views DESC, id DESC LIMIT $fo_catbox_n");
                }
                break;
            } catch (Throwable $e) { $fo_catbox_items = array(); }
        }
    }
    ?>
    <?php if ($fo_catbox_mode === 'cats' && !empty($fo_cats)): ?>
    <section class="fo-catbox">
      <div class="fo-catgrid">
        <?php foreach (array_slice($fo_cats, 0, $fo_catbox_n) as $c): ?>
          <a class="fo-catitem" href="<?php echo e(cat_url($c)); ?>">
            <span class="fo-catitem-ic"><?php echo e(fo_substr($c['name'], 0, 1)); ?></span>
            <span class="fo-catitem-name"><?php echo e($c['name']); ?><em>(<?php echo (int)$c['cnt']; ?>)</em></span>
            <span class="fo-catitem-arrow">›</span>
          </a>
        <?php endforeach; ?>
      </div>
      <?php if (count($fo_cats) > $fo_catbox_n): ?>
        <a class="fo-catmore" href="<?php echo e(base_url() . 'blog/article'); ?>">查看更多...</a>
      <?php endif; ?>
    </section>
    <?php elseif (!empty($fo_catbox_items)): ?>
    <section class="fo-catbox">
      <div class="fo-catgrid">
        <?php foreach ($fo_catbox_items as $fp): ?>
          <?php $fo_cb_cov = fo_cover($fp); ?>
          <a class="fo-catitem" href="<?php echo e(post_url($fp)); ?>" title="<?php echo e($fp['title']); ?>">
            <span class="fo-catitem-ic<?php echo $fo_cb_cov['url'] !== '' ? ' fo-catitem-ic--img' : ''; ?>"<?php if ($fo_cb_cov['url'] === '') echo ' style="background:' . e($fo_cb_cov['style']) . '"'; ?>><?php if ($fo_cb_cov['url'] !== ''): ?><img src="<?php echo e($fo_cb_cov['url']); ?>" alt="" loading="lazy" decoding="async" onerror="this.parentNode.classList.remove('fo-catitem-ic--img');this.remove()"><?php else: ?><?php echo e(fo_substr($fp['title'], 0, 1)); ?><?php endif; ?></span>
            <span class="fo-catitem-name fo-catitem-name--post"><?php echo e($fp['title']); ?><em>(<?php echo (int)$fp['views']; ?> 浏览)</em></span>
            <span class="fo-catitem-arrow">›</span>
          </a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <?php if ($fo_page_no > 1): ?>
    <p class="fo-listnote">第 <?php echo $fo_page_no; ?> 页 · 本页 <b><?php echo count($fo_list); ?></b> 篇 · 全站共 <b><?php echo (int)$total; ?></b> 篇</p>
    <?php endif; ?>

    <?php
    /* 2.1.25：文章列表三种样式，后台「首页设置 → 首页文章显示样式」切换
       grid 卡片网格（默认）/ side 左右图文 / list 图文列表。
       三种样式的 DOM 全部收在 part-postlist.php，样式差异只在 style.css，页面逻辑无需分叉 */
    $fo_layout = fo_opt('list_layout', 'grid');
    $fo_posts  = $fo_list;
    include partial_path('part-postlist.php');
    ?>

    <?php if (empty($fo_list) && empty($fo_featured)): ?>
      <p class="fo-empty">还没有文章，先去后台写一篇吧～</p>
    <?php endif; ?>

    <?php /* 分页防线：本页文章没显示完（总数 > 本页实际取到的篇数）才显示分页。
              无论程序取「每页 N 篇」还是「每页 N+1 篇（含精选大卡）」，这里都按实际判断，
              不会出现有文章却看不到分页的情况 */ ?>
    <?php if ($page > 1 || (int)$total > count((array)$posts)) echo $pager; ?>
  </div>

  <?php if ($fo_side_on): include partial_path('side.php'); endif; ?>
</div>

<?php include partial_path('footer.php'); ?>