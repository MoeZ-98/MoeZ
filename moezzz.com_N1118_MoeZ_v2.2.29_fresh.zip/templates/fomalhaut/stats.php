<?php
/**
 * 星辉 · Fomalhaut 模板 · 文章统计（由「页面」承载，别名见模板设置 stats_slug）
 * 内容：发布趋势折线 / Top10 标签 / 全部标签 / 分类占比
 * 可用变量：$page $site
 */
$fo_hero_img = trim(fo_opt('hero_bg', ''));
$fo_hero_img = $fo_hero_img !== '' ? media_url($fo_hero_img) : theme_url('assets/hero.svg');

/* ---------- 数据 ---------- */
$fo_months = array();
$fo_month_counts = array();
for ($i = 11; $i >= 0; $i--) {
    $key = date('Y-m', strtotime(date('Y-m-01') . ' -' . $i . ' month'));
    $fo_months[] = $key;
    $fo_month_counts[$key] = 0;
}
try {
    $fo_rows = rows('SELECT DATE_FORMAT(created_at, "%Y-%m") AS m, COUNT(*) AS c FROM ' . moe_table('posts')
        . " WHERE type='post' AND status='published' AND created_at >= ? GROUP BY m", array(date('Y-m-01', strtotime(date('Y-m-01') . ' -11 month'))));
    foreach ((array)$fo_rows as $r) {
        if (isset($fo_month_counts[$r['m']])) $fo_month_counts[$r['m']] = (int)$r['c'];
    }
} catch (Throwable $e) {
    // 数据不可用时图表为空
}

$fo_month_series = array();
foreach ($fo_months as $m) $fo_month_series[] = $fo_month_counts[$m];
$fo_month_max = max(1, max($fo_month_series));

/* 标签统计（按文章 SEO 关键词聚合） */
$fo_tag_counts = array();
$fo_posts_total = 0;
try {
    $fo_kw_rows = rows('SELECT seo_keywords FROM ' . moe_table('posts') . " WHERE type='post' AND status='published'");
    $fo_posts_total = count($fo_kw_rows);
    foreach ((array)$fo_kw_rows as $r) {
        foreach (preg_split('/[,，、\s]+/u', (string)$r['seo_keywords']) as $t) {
            $t = trim($t);
            if ($t === '') continue;
            if (!isset($fo_tag_counts[$t])) $fo_tag_counts[$t] = 0;
            $fo_tag_counts[$t]++;
        }
    }
    arsort($fo_tag_counts);
} catch (Throwable $e) {
    $fo_tag_counts = array();
}

$fo_top_tags = array_slice($fo_tag_counts, 0, 10, true);
$fo_tag_max = !empty($fo_top_tags) ? max($fo_top_tags) : 1;
$fo_tag_total = count($fo_tag_counts);

/* 分类统计 */
$fo_cats = array();
$fo_cat_total = 0;
try {
    $fo_cats = rows('SELECT c.name, c.slug, (SELECT COUNT(*) FROM ' . moe_table('posts') . " p WHERE p.category_id = c.id AND p.type='post' AND p.status='published') AS cnt"
        . ' FROM ' . moe_table('categories') . ' c ORDER BY cnt DESC, c.sort, c.id');
    foreach ((array)$fo_cats as $c) $fo_cat_total += (int)$c['cnt'];
} catch (Throwable $e) {
    $fo_cats = array();
}

$fo_palette = array('#37b6ab', '#7cc7c0', '#a8d9d2', '#4f9fc4', '#8bc7e0', '#c3e2ef', '#f0b47a', '#f7d2ac', '#b9a7d8', '#dcd2f0', '#9dd0a8', '#cfe8d5');

/* 折线图坐标 */
$fo_w = 760; $fo_h = 220; $fo_pad = 34;
$fo_step = count($fo_month_series) > 1 ? ($fo_w - $fo_pad * 2) / (count($fo_month_series) - 1) : 0;
$fo_points = array();
foreach ($fo_month_series as $i => $v) {
    $x = $fo_pad + $i * $fo_step;
    $y = $fo_h - $fo_pad - ($v / $fo_month_max) * ($fo_h - $fo_pad * 1.6);
    $fo_points[] = array(round($x, 1), round($y, 1), (int)$v, $fo_months[$i]);
}
$fo_line = '';
foreach ($fo_points as $i => $pt) $fo_line .= ($i === 0 ? 'M' : 'L') . $pt[0] . ',' . $pt[1] . ' ';
$fo_area = $fo_line . 'L' . $fo_points[count($fo_points) - 1][0] . ',' . ($fo_h - $fo_pad) . ' L' . $fo_points[0][0] . ',' . ($fo_h - $fo_pad) . ' Z';

/* 环形图参数 */
$fo_circ = 2 * 3.1415926 * 68;
$fo_offset = 0;
?>
<section class="fo-hero fo-hero--small" style="background-image:linear-gradient(180deg,rgba(14,32,52,.28),rgba(14,32,52,.52)),url('<?php echo e($fo_hero_img); ?>')">
  <div class="fo-hero-center">
    <h1 class="fo-hero-title fo-hero-title--sm">文章统计</h1>
    <p class="fo-hero-sub">用数据看看这个小小的宇宙</p>
  </div>
</section>

<div class="fo-wrap fo-wrap--single">
  <div class="fo-panel">
    <div class="fo-panel-head">
      <h2 class="fo-panel-title">文章发布统计</h2>
      <span class="fo-panel-sub">近 12 个月 · 共 <?php echo (int)$fo_posts_total; ?> 篇文章</span>
    </div>

    <div class="fo-chart">
      <svg viewBox="0 0 <?php echo $fo_w; ?> <?php echo $fo_h; ?>" class="fo-chart-svg" role="img" aria-label="近 12 个月文章发布趋势">
        <defs>
          <linearGradient id="foArea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="var(--fo-accent)" stop-opacity=".28"/>
            <stop offset="100%" stop-color="var(--fo-accent)" stop-opacity="0"/>
          </linearGradient>
        </defs>
        <?php for ($g = 0; $g <= 4; $g++): $gy = $fo_pad + ($fo_h - $fo_pad * 2) * $g / 4; ?>
          <line x1="<?php echo $fo_pad; ?>" y1="<?php echo round($gy, 1); ?>" x2="<?php echo $fo_w - $fo_pad; ?>" y2="<?php echo round($gy, 1); ?>" stroke="#e8eef4" stroke-width="1"/>
          <text x="8" y="<?php echo round($gy + 4, 1); ?>" class="fo-chart-tick"><?php echo round($fo_month_max * (1 - $g / 4), 0); ?></text>
        <?php endfor; ?>
        <path d="<?php echo e($fo_area); ?>" fill="url(#foArea)"/>
        <path d="<?php echo e($fo_line); ?>" fill="none" stroke="var(--fo-accent)" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"/>
        <?php foreach ($fo_points as $pt): ?>
          <circle cx="<?php echo $pt[0]; ?>" cy="<?php echo $pt[1]; ?>" r="3.2" fill="#fff" stroke="var(--fo-accent)" stroke-width="2"/>
        <?php endforeach; ?>
        <?php foreach ($fo_points as $i => $pt): ?>
          <?php if ($i % 2 === 0 || $i === count($fo_points) - 1): ?>
            <text x="<?php echo $pt[0]; ?>" y="<?php echo $fo_h - 10; ?>" text-anchor="middle" class="fo-chart-tick"><?php echo e(substr($pt[3], 2)); ?></text>
          <?php endif; ?>
        <?php endforeach; ?>
      </svg>
    </div>

    <div class="fo-panel-head fo-panel-head--tight">
      <h2 class="fo-panel-title">Top 10 标签统计图</h2>
      <span class="fo-panel-sub">文章数最多的 10 个标签</span>
    </div>

    <div class="fo-tagbars">
      <?php if (!empty($fo_top_tags)): ?>
        <?php $ti = 0; foreach ($fo_top_tags as $name => $cnt): $h = max(10, round($cnt / $fo_tag_max * 130)); ?>
          <div class="fo-tagbar">
            <span class="fo-tagbar-num"><?php echo (int)$cnt; ?></span>
            <span class="fo-tagbar-stick" style="height:<?php echo $h; ?>px;background:<?php echo e($fo_palette[$ti % count($fo_palette)]); ?>">
              <b class="fo-tagbar-val"><?php echo (int)$cnt; ?></b>
            </span>
            <span class="fo-tagbar-label"><?php echo e($name); ?></span>
          </div>
        <?php $ti++; endforeach; ?>
      <?php else: ?>
        <p class="fo-empty">还没有标签数据：给文章填写「SEO 关键词」即可自动统计</p>
      <?php endif; ?>
    </div>

    <div class="fo-panel-head fo-panel-head--tight">
      <h2 class="fo-panel-title">全部标签</h2>
      <span class="fo-panel-sub">共 <?php echo (int)$fo_tag_total; ?> 个</span>
    </div>
    <div class="fo-tagcloud">
      <?php foreach ($fo_tag_counts as $name => $cnt): ?>
        <span class="fo-tagcloud-item"><?php echo e($name); ?><em><?php echo (int)$cnt; ?></em></span>
      <?php endforeach; ?>
      <?php if (empty($fo_tag_counts)): ?><p class="fo-empty">暂无标签</p><?php endif; ?>
    </div>

    <div class="fo-panel-head fo-panel-head--tight">
      <h2 class="fo-panel-title">文章分类统计</h2>
      <span class="fo-panel-sub">分类文章占比</span>
    </div>

    <div class="fo-donut-wrap">
      <div class="fo-donut">
        <svg viewBox="0 0 180 180" role="img" aria-label="分类占比环形图">
          <circle cx="90" cy="90" r="68" fill="none" stroke="#eef3f7" stroke-width="20"/>
          <?php $oi = 0; foreach ((array)$fo_cats as $c): ?>
            <?php
              $cnt = (int)$c['cnt'];
              if ($cnt <= 0 || $fo_cat_total <= 0) continue;
              $len = $fo_circ * $cnt / $fo_cat_total;
              $dash = round($len, 2) . ' ' . round($fo_circ - $len, 2);
              $color = $fo_palette[$oi % count($fo_palette)];
            ?>
            <circle cx="90" cy="90" r="68" fill="none" stroke="<?php echo e($color); ?>" stroke-width="20"
                    stroke-dasharray="<?php echo $dash; ?>" stroke-dashoffset="<?php echo round(-$fo_offset, 2); ?>"
                    transform="rotate(-90 90 90)" stroke-linecap="butt"/>
            <?php $fo_offset += $len; $oi++; ?>
          <?php endforeach; ?>
        </svg>
        <div class="fo-donut-center">
          <b><?php echo (int)$fo_cat_total; ?></b>
          <span>篇文章</span>
        </div>
      </div>
      <ul class="fo-legend">
        <?php $li = 0; foreach ((array)$fo_cats as $c): if ((int)$c['cnt'] <= 0) continue; ?>
          <li><i style="background:<?php echo e($fo_palette[$li % count($fo_palette)]); ?>"></i><span><?php echo e($c['name']); ?></span><b><?php echo (int)$c['cnt']; ?></b></li>
        <?php $li++; endforeach; ?>
        <?php if (empty($fo_cats)): ?><li class="fo-empty">暂无分类</li><?php endif; ?>
      </ul>
    </div>

    <div class="fo-panel-head fo-panel-head--tight">
      <h2 class="fo-panel-title">全部条目</h2>
      <span class="fo-panel-sub">分类文章数</span>
    </div>
    <div class="fo-tagcloud">
      <?php foreach ((array)$fo_cats as $c): ?>
        <a class="fo-tagcloud-item" href="<?php echo e(cat_url($c)); ?>"><?php echo e($c['name']); ?><em><?php echo (int)$c['cnt']; ?></em></a>
      <?php endforeach; ?>
    </div>
  </div>
</div>