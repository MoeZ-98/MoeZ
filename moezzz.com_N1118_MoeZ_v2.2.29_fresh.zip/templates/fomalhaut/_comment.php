<?php
/**
 * 星辉 · Fomalhaut · 友链页留言提交端点
 *
 * 友链页不是文章，程序自带的 comment.php 只接受 type='post' 的文章，
 * 所以这里提供一个主题内的轻量端点：复用程序初始化、CSRF 与评论表，
 * 只允许写入「友链页留言板」绑定的那个目标 ID（模板设置 friend_comment_id，
 * 未填时自动取 slug 为 link/links/friends 的独立页面，仍没有则为 0）。
 *
 * 安全约束：
 *   - 只接受 POST + CSRF 校验；
 *   - 目标 ID 由服务端决定，前端传来的 post_id 仅用于比对，不接受任意文章；
 *   - 昵称 ≤30 字、内容 ≤1000 字、邮箱格式校验；
 *   - 同一会话 60 秒内只能发一条。
 */
require dirname(dirname(__DIR__)) . '/init.php';
require __DIR__ . '/_lib.php';

/* 积分数据层：友链留言同样可以拿评论积分（与文章评论共用上限） */
require __DIR__ . '/_shop.php';

/* 程序自带的回链检测（缺失时自动降级为只检测可访问性） */
if (!function_exists('moe_check_backlink') && is_file(dirname(dirname(__DIR__)) . '/includes/linkcheck.php')) {
    require_once dirname(dirname(__DIR__)) . '/includes/linkcheck.php';
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_exit(false, '非法请求');
}

csrf_verify();

if (setting('comment_enabled', '1') !== '1') {
    json_exit(false, '本站未开放评论');
}

$target  = fo_friend_comment_target();
$post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;
if ($post_id !== $target) {
    json_exit(false, '留言板参数已过期，请刷新页面后重试');
}

$author  = trim((string)($_POST['author'] ?? ''));
$email   = trim((string)($_POST['email'] ?? ''));
$content = trim((string)($_POST['content'] ?? ''));

/* 登录用户强制使用账号昵称与邮箱：评论积分按账号发放，前端传值不可信 */
$fo_me = function_exists('fo_comment_defaults') ? fo_comment_defaults() : array('user' => false);
if (!empty($fo_me['user'])) {
    if (($fo_me['author'] ?? '') !== '') $author = (string)$fo_me['author'];
    $email = (string)($fo_me['email'] ?? '');
}

if ($author === '' || $content === '') {
    json_exit(false, '昵称和留言内容不能为空');
}
if (mb_strlen($author) > 30) {
    json_exit(false, '昵称太长啦');
}
if (mb_strlen($content) > 1000) {
    json_exit(false, '留言内容最多 1000 字');
}
if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_exit(false, '邮箱格式不正确');
}

if (!empty($_SESSION['moe_last_friend_comment']) && time() - (int)$_SESSION['moe_last_friend_comment'] < 60) {
    json_exit(false, '留言太快啦，喝口水休息一下~');
}

$ip  = $_SERVER['REMOTE_ADDR'] ?? '';
$ua  = isset($_SERVER['HTTP_USER_AGENT']) ? mb_substr((string)$_SERVER['HTTP_USER_AGENT'], 0, 255, 'UTF-8') : '';
$loc = function_exists('moe_ip_location') ? moe_ip_location($ip) : '';

q('INSERT INTO ' . moe_table('comments') . ' (post_id,author,email,content,status,ip,ua,location,created_at) VALUES (?,?,?,?,?,?,?,?,NOW())',
    array($target, $author, $email, $content, 'approved', $ip, $ua, $loc));
/* 先记下评论 id：后面自动审批会写入友链表，last_id() 会被覆盖 */
$fo_cid = function_exists('last_id') ? (int)last_id() : 0;

/* 友链申请自动检测审批：识别评论里的站点信息、检测可访问与回链，达标直接加友链 */
$fo_auto = array('status' => 'skip', 'msg' => '', 'name' => '');
try {
    $fo_auto = fo_friend_auto_apply($content);
} catch (Throwable $e) {
    $fo_auto = array('status' => 'pending', 'msg' => '自动检测异常，已转人工审核', 'name' => '');
}

if (($fo_auto['status'] === 'added' || $fo_auto['status'] === 'pending') && $fo_cid > 0) {
    $fo_note = $fo_auto['status'] === 'added'
        ? "\n\n【系统】自动检测通过，友链已添加：" . $fo_auto['name']
        : "\n\n【系统】" . $fo_auto['msg'];
    try {
        q('UPDATE ' . moe_table('comments') . ' SET content = ? WHERE id = ?', array($content . $fo_note, $fo_cid));
    } catch (Throwable $e) {
        // 追加系统说明失败不影响留言本身
    }
}

/* 登录用户留言也记评论积分；同一条评论由 note 去重，前端再领也不会重复 */
if ($fo_cid > 0 && fo_shop_uid() > 0 && function_exists('fo_comment_points_grant')) {
    try {
        fo_comment_points_grant(fo_shop_uid(), '评论 #' . $fo_cid);
    } catch (Throwable $e) {
        // 积分发放失败不影响留言
    }
}

$_SESSION['moe_last_friend_comment'] = time();

$fo_tip = '留言成功，正在刷新…';
if ($fo_auto['status'] === 'added') $fo_tip = '留言成功，已自动检测通过并添加友链，正在刷新…';
elseif ($fo_auto['status'] === 'pending') $fo_tip = '留言成功，自动检测未通过，已转人工审核，正在刷新…';

json_exit(true, $fo_tip);