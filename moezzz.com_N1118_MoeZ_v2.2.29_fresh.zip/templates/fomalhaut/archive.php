<?php
/**
 * 星辉 · Fomalhaut 模板 · 归档页（/archives）
 * 文章总览 + 年度分布 + 年份筛选 + 年度卡片
 * 可用变量：$site $nav_cats
 */
$cur_p = 'archive';
include partial_path('header.php');

$fo_hero_img = trim(fo_opt('hero_bg', ''));
$fo_hero_img = $fo_hero_img !== '' ? media_url($fo_hero_img) : theme_url('assets/hero.svg');

$fo_items = array();
try {
    $fo_items = rows('SELECT p.id, p.title, p.slug, p.excerpt, p.content, p.cover, p.created_at, p.updated_at, p.category_id, p.url_num, p.views, p.seo_keywords, c.name AS cat_name'
        . ' FROM ' . moe_table('posts') . ' p LEFT JOIN ' . moe_table('categories') . ' c ON c.id = p.category_id'
        . " WHERE p.type='post' AND p.status='published' ORDER BY p.created_at DESC, p.id DESC");
} catch (Throwable $e) {
    $fo_items = array();
}

$fo_groups = array();
foreach ((array)$fo_items as $it) {
    $fo_groups[substr((string)$it['created_at'], 0, 4)][] = $it;
}
krsort($fo_groups);
$fo_total = count($fo_items);
$fo_max_year = 0;
foreach ($fo_groups as $items) $fo_max_year = max($fo_max_year, count($items));
?>
<section class="fo-hero fo-hero--small" style="background-image:linear-gradient(180deg,rgba(14,32,52,.28),rgba(14,32,52,.52)),url('<?php echo e($fo_hero_img); ?>')">
  <div class="fo-hero-center">
    <h1 class="fo-hero-title fo-hero-title--sm">归档</h1>
    <p class="fo-hero-sub">把散落在时间里的文字收进来</p>
  </div>
</section>

<div class="fo-wrap fo-wrap--single">
  <div class="fo-panel">
    <div class="fo-panel-head">
      <h2 class="fo-panel-title">文章总览 <span>- <?php echo (int)$fo_total; ?></span></h2>
      <span class="fo-panel-sub">共 <?php echo count($fo_groups); ?> 个年份</span>
    </div>

    <div class="fo-yeardist">
      <div class="fo-yeardist-head">
        <span>年度分布</span>
        <span class="fo-muted">共 <?php echo (int)$fo_total; ?> 篇 · 逐年统计</span>
      </div>
      <div class="fo-yeardist-bars">
        <?php foreach ($fo_groups as $y => $items): ?>
          <div class="fo-yeardist-item">
            <span class="fo-yeardist-num"><?php echo count($items); ?></span>
            <span class="fo-yeardist-bar" style="height:<?php echo $fo_max_year > 0 ? max(8, round(count($items) / $fo_max_year * 78)) : 8; ?>px"></span>
            <span class="fo-yeardist-year"><?php echo e($y); ?></span>
          </div>
        <?php endforeach; ?>
        <?php if (empty($fo_groups)): ?><p class="fo-empty">暂无文章</p><?php endif; ?>
      </div>
    </div>

    <div class="fo-yearchips">
      <button type="button" class="fo-yearchip is-active" data-year="all">全部</button>
      <?php foreach ($fo_groups as $y => $items): ?>
        <button type="button" class="fo-yearchip" data-year="<?php echo e($y); ?>"><?php echo e($y); ?></button>
      <?php endforeach; ?>
    </div>

    <?php foreach ($fo_groups as $y => $items): ?>
    <section class="fo-yeargroup" data-year="<?php echo e($y); ?>">
      <div class="fo-yeargroup-head">
        <h3><?php echo e($y); ?> <em><?php echo count($items); ?> 篇</em></h3>
        <span class="fo-yeargroup-line"></span>
      </div>
      <div class="fo-archive-grid">
        <?php foreach ($items as $p): ?>
          <?php $cov = fo_cover($p); ?>
          <a class="fo-arch-card" href="<?php echo e(post_url($p)); ?>">
            <div class="fo-arch-cover" style="background:<?php echo e($cov['style']); ?>">
              <?php echo fo_cover_img_tag($cov['url']); ?>
              <span class="fo-arch-shade"></span>
            </div>
            <div class="fo-arch-body">
              <p class="fo-arch-excerpt"><?php echo e(post_excerpt($p, 52)); ?></p>
              <div class="fo-arch-meta">
                <span class="fo-arch-date"><?php echo e(format_time($p['created_at'], 'Y-m-d')); ?></span>
              </div>
              <h4 class="fo-arch-title"><?php echo e($p['title']); ?></h4>
            </div>
          </a>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endforeach; ?>

    <?php if (empty($fo_groups)): ?><p class="fo-empty">还没有文章，先去后台写一篇吧～</p><?php endif; ?>
  </div>
</div>


<?php include partial_path('footer.php'); ?>