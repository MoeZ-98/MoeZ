<?php
/**
 * 星辉 · Fomalhaut 模板 · 右侧信息栏（首页 / 文章页共用部件）
 * 各模块独立开关；全部关闭或总开关关闭时本部件不输出任何内容
 * 可用变量：$site
 */
if (!fo_side_enabled()) return;

/* ---- 以下为侧栏自身所需数据，页面无需提前准备 ---- */
$fo_data = fo_site_data();

/* 标签总数（按 SEO 关键词去重） */
$fo_tag_total = 0;
try {
    $fo_kw_rows = rows('SELECT seo_keywords FROM ' . moe_table('posts') . " WHERE type='post' AND status='published' AND seo_keywords <> ''");
    $fo_set = array();
    foreach ((array)$fo_kw_rows as $r) {
        foreach (preg_split('/[,，、\s]+/u', (string)$r['seo_keywords']) as $t) {
            $t = trim($t);
            if ($t !== '') $fo_set[$t] = 1;
        }
    }
    $fo_tag_total = count($fo_set);
} catch (Throwable $e) {
    $fo_tag_total = 0;
}

$fo_cal = fo_calendar();
$fo_fest = fo_next_festival();
$fo_uptime = fo_uptime();
$fo_year_bars = fo_year_bars(4);
$fo_weekday = array(1 => '周一', 2 => '周二', 3 => '周三', 4 => '周四', 5 => '周五', 6 => '周六', 7 => '周日');
$fo_weekday_cn = $fo_weekday[(int)date('N')];

$fo_notice = trim(fo_opt('notice', ''));
$fo_me_sig = trim(fo_opt('me_sig', ''));
if ($fo_me_sig === '') $fo_me_sig = $site['signature'] !== '' ? $site['signature'] : ($site['sub'] !== '' ? $site['sub'] : 'FUTURE IS NOW');
$fo_avatar = !empty($site['avatar']) ? media_url($site['avatar']) : theme_url('assets/avatar.svg');

/* 个人资料卡：名字用后台「个人资料 → 昵称/作者名」（site_author），头像用后台头像 */
$fo_profile_name = trim((string)$site['author']);
if ($fo_profile_name === '') {
    /* 兜底：账号昵称 → 用户名 → 站点名 */
    try {
        $fo_me = row('SELECT nickname, username FROM ' . moe_table('users') . ' ORDER BY id ASC LIMIT 1');
    } catch (Throwable $e) {
        $fo_me = null;
    }
    $fo_profile_name = $fo_me ? (trim((string)$fo_me['nickname']) !== '' ? $fo_me['nickname'] : $fo_me['username']) : '';
}
if ($fo_profile_name === '') $fo_profile_name = $site['name'];
$fo_profile_avatar = $fo_avatar;
$fo_github = trim(fo_opt('github', '')) !== '' ? trim(fo_opt('github', '')) : (string)$site['github'];
$fo_email  = trim(fo_opt('email', '')) !== '' ? trim(fo_opt('email', '')) : (string)$site['mail'];

$fo_day_of_year = (int)date('z') + 1;
$fo_days_in_year = date('L') ? 366 : 365;
$fo_year_percent = round($fo_day_of_year / $fo_days_in_year * 100, 2);
$fo_days_to_newyear = $fo_days_in_year - $fo_day_of_year;

/* 2.1.5：社交图标自动获取后台「用户中心 → 社交与展示」配置 */
$fo_social_list = function_exists('moe_social_list') ? moe_social_list() : array();
/* RSS 入口：默认显示（老站行为不变），后台取消勾选「前台展示 RSS 订阅入口」（存 0）后隐藏 */
$fo_show_rss = function_exists('setting') ? setting('social_rss', '1') !== '0' : true;

/* 资料卡横幅背景图 */
$fo_profile_bg = trim(fo_opt('profile_bg', ''));
$fo_profile_style = $fo_profile_bg !== ''
    ? "background-image:linear-gradient(180deg,rgba(255,255,255,.10),rgba(255,255,255,0)),url('" . e(media_url($fo_profile_bg)) . "');background-size:cover;background-position:center;"
    : '';
?>
<aside class="fo-side" id="fo-side">
  <?php if (fo_on('show_profile', '1')): ?>
  <section class="fo-widget fo-profile">
    <div class="fo-profile-cover<?php echo $fo_profile_style !== '' ? ' has-img' : ''; ?>"<?php if ($fo_profile_style !== ''): ?> style="<?php echo e($fo_profile_style); ?>"<?php endif; ?>>
      <span class="fo-profile-orbit"></span>
      <span class="fo-profile-orbit fo-profile-orbit--2"></span>
    </div>
    <div class="fo-profile-main">
      <img class="fo-profile-avatar" src="<?php echo e($fo_profile_avatar); ?>" alt="<?php echo e($fo_profile_name); ?>" width="68" height="68" loading="lazy" decoding="async">
      <div class="fo-profile-name"><?php echo e($fo_profile_name); ?><span class="fo-profile-badge">✦</span></div>
      <div class="fo-profile-sig"><?php echo e($fo_me_sig); ?></div>
      <?php $fo_ribbon = trim(fo_opt('me_ribbon', '如果觉得累了，摆烂一下也没关系。')); if ($fo_ribbon !== ''): ?>
      <div class="fo-ribbon"><?php echo e($fo_ribbon); ?></div>
      <?php endif; ?>
      <div class="fo-profile-stats">
        <div><b><?php echo (int)$fo_data['posts']; ?></b><span>文章</span></div>
        <div><b><?php echo (int)$fo_tag_total; ?></b><span>标签</span></div>
        <div><b><?php echo (int)$fo_data['cats']; ?></b><span>分类</span></div>
      </div>
      <?php if ($fo_github !== ''): ?>
      <a class="fo-btn fo-btn--wide" href="<?php echo e($fo_github); ?>" target="_blank" rel="noopener">Github主页 <span>↗</span></a>
      <?php endif; ?>
      <div class="fo-socials">
        <?php if (!empty($fo_social_list)): ?>
        <?php foreach ($fo_social_list as $fo_soc):
            $fo_soc_url = (string)$fo_soc['url'];
            if (preg_match('#^\s*(javascript|data|vbscript|file)\s*:#i', $fo_soc_url)) $fo_soc_url = '#';
            $fo_soc_name = (string)$fo_soc['name'];
            $fo_soc_img = function_exists('moe_social_icon') ? moe_social_icon((string)$fo_soc['icon'], $fo_soc_name) : '';
            $fo_soc_ico = $fo_soc_img !== ''
                ? '<img src="' . e($fo_soc_img) . '" alt="" width="15" height="15" loading="lazy" decoding="async">'
                : '<span class="fo-soc-emoji">' . e(trim((string)$fo_soc['icon']) !== '' ? $fo_soc['icon'] : '🔗') . '</span>';
            $is_mail = strpos($fo_soc_url, 'mailto:') === 0; ?>
        <a href="<?php echo e($fo_soc_url); ?>"<?php echo $is_mail ? '' : ' target="_blank" rel="noopener"'; ?> title="<?php echo e($fo_soc_name !== '' ? $fo_soc_name : '链接'); ?>"><?php echo $fo_soc_ico; ?></a>
        <?php endforeach; ?>
        <?php if ($fo_show_rss): ?>
        <a href="<?php echo e(rss_url()); ?>" target="_blank" rel="noopener" title="RSS"><svg viewBox="0 0 24 24"><path d="M5 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM5 11a8 8 0 0 1 8 8"/><path d="M5 5a14 14 0 0 1 14 14"/></svg></a>
        <?php endif; ?>
        <?php else: ?>
        <?php if ($fo_email !== ''): ?><a href="mailto:<?php echo e($fo_email); ?>" title="邮件"><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></svg></a><?php endif; ?>
        <?php if (!empty($site['github'])): ?><a href="<?php echo e($site['github']); ?>" target="_blank" rel="noopener" title="Github"><svg viewBox="0 0 24 24"><path d="M9 19c-4 1.5-4-2-6-2m12 5v-3.5c0-1 .1-1.4-.5-2 2.8-.3 5.5-1.4 5.5-6a4.6 4.6 0 0 0-1.3-3.2 4.2 4.2 0 0 0-.1-3.2s-1-.3-3.5 1.3a12 12 0 0 0-6.2 0C6.4 3.6 5.4 3.9 5.4 3.9a4.2 4.2 0 0 0-.1 3.2A4.6 4.6 0 0 0 4 10.3c0 4.5 2.7 5.6 5.5 6-.6.6-.6 1.2-.5 2V21"/></svg></a><?php endif; ?>
        <?php if (!empty($site['bilibili'])): ?><a href="<?php echo e($site['bilibili']); ?>" target="_blank" rel="noopener" title="哔哩哔哩"><svg viewBox="0 0 24 24"><rect x="4" y="7" width="16" height="12" rx="3"/><path d="m8 4 3 3M16 4l-3 3"/></svg></a><?php endif; ?>
        <?php if (!empty($site['weibo'])): ?><a href="<?php echo e($site['weibo']); ?>" target="_blank" rel="noopener" title="微博"><svg viewBox="0 0 24 24"><circle cx="10" cy="14" r="6"/><path d="M17 5a4 4 0 0 1 4 4"/><path d="M16 8a1.6 1.6 0 0 1 2 1.4"/></svg></a><?php endif; ?>
        <?php if ($fo_show_rss): ?>
        <a href="<?php echo e(rss_url()); ?>" target="_blank" rel="noopener" title="RSS"><svg viewBox="0 0 24 24"><path d="M5 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM5 11a8 8 0 0 1 8 8"/><path d="M5 5a14 14 0 0 1 14 14"/></svg></a>
        <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <?php if (fo_on('show_calendar', '1')): ?>
  <section class="fo-widget fo-calendar">
    <div class="fo-widget-head">
      <span>第<?php echo (int)$fo_cal['week']; ?>周 <em><?php echo e($fo_weekday_cn); ?></em></span>
      <span class="fo-calendar-month"><?php echo (int)$fo_cal['month']; ?>月</span>
    </div>
    <div class="fo-calendar-main">
      <div class="fo-calendar-big"><?php echo sprintf('%02d', $fo_cal['today']); ?></div>
      <div class="fo-calendar-grid">
        <?php foreach ($fo_cal['weekdays'] as $w): ?><span class="fo-calendar-wd"><?php echo e($w); ?></span><?php endforeach; ?>
        <?php foreach ($fo_cal['cells'] as $c): ?>
          <span class="fo-calendar-day <?php echo $c === $fo_cal['today'] ? 'is-today' : ($c === 0 ? 'is-empty' : ''); ?>"><?php echo $c === 0 ? '' : $c; ?></span>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="fo-calendar-foot">
      <span class="fo-calendar-fest"><?php echo (int)$fo_fest['days']; ?>天后是<b><?php echo e($fo_fest['name']); ?></b></span>
      <span class="fo-calendar-date"><?php echo e($fo_fest['date']); ?> <?php echo e(date('H:i')); ?></span>
    </div>
  </section>
  <?php endif; ?>

  <?php if (fo_on('show_rank', '1')): ?>
    <?php echo fo_rank_widget(); ?>
  <?php endif; ?>

  <?php if (fo_on('show_announce', '1')): ?>
  <?php
  /* 2.1.11：欢迎卡紧随排行榜之后（线路列表已删除） */
  $fo_ann_title = trim(fo_opt('announce_title', ''));
  if ($fo_ann_title === '') $fo_ann_title = '欢迎来访者';
  $fo_ann_btns = array();
  foreach (preg_split('/\r\n|\r|\n/', fo_opt('announce_btns', '')) as $fo_ab_line) {
      $fo_ab_line = trim($fo_ab_line);
      if ($fo_ab_line === '') continue;
      $fo_ab = array_map('trim', explode('|', $fo_ab_line));
      if (($fo_ab[0] ?? '') === '') continue;
      $fo_ann_btns[] = array('name' => $fo_ab[0], 'url' => ($fo_ab[1] ?? '') !== '' ? $fo_ab[1] : home_url());
      if (count($fo_ann_btns) >= 3) break;
  }
  ?>
  <section class="fo-widget fo-announce">
    <div class="fo-ann-card">
      <div class="fo-ann-head"><i></i><span>📢 <?php echo e($fo_ann_title); ?></span></div>
      <?php if ($fo_notice !== ''): ?><p class="fo-ann-body"><?php echo e($fo_notice); ?></p><?php endif; ?>
      <?php if (!empty($fo_ann_btns)): ?>
      <div class="fo-ann-btns">
        <?php foreach ($fo_ann_btns as $fo_ab): ?>
        <a class="fo-ann-btn" href="<?php echo e($fo_ab['url']); ?>"<?php echo preg_match('#^https?://#i', $fo_ab['url']) ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo e($fo_ab['name']); ?></a>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
      <span class="fo-ann-bubble"></span>
    </div>
  </section>
  <?php endif; ?>

  <?php if (fo_on('show_yearbar', '1')): ?>
  <section class="fo-widget fo-yearbar">
    <div class="fo-yearbar-top">
      <div>
        <span class="fo-yearbar-label">距离元旦</span>
        <div class="fo-yearbar-num"><?php echo (int)$fo_days_to_newyear; ?><small>天</small></div>
      </div>
      <div class="fo-yearbar-right">
        <div><span>本岁</span><b><?php echo number_format($fo_year_percent, 2); ?>%</b></div>
        <div><span>已完成</span><b><?php echo (int)$fo_day_of_year; ?> 天</b></div>
      </div>
    </div>
    <div class="fo-yearbar-track"><i style="width:<?php echo max(2, min(100, $fo_year_percent)); ?>%"></i></div>
    <div class="fo-yearbar-foot">
      <span><?php echo date('Y'); ?> 年</span>
      <span>新岁 <?php echo (int)$fo_days_to_newyear; ?> 天后开启</span>
    </div>
  </section>
  <?php endif; ?>

  <?php if (fo_on('show_sitestats', '1')): ?>
  <section class="fo-widget fo-sitestats">
    <div class="fo-widget-head"><span>小站资讯</span><span class="fo-widget-more">✦</span></div>
    <div class="fo-sitestats-grid">
      <div><b><?php echo e(fo_num($fo_data['views'])); ?></b><span>浏览量</span></div>
      <div><b><?php echo e(fo_num($fo_data['comments'])); ?></b><span>评论数</span></div>
      <div><b><?php echo e(fo_num($fo_data['posts'])); ?></b><span>文章</span></div>
    </div>
    <p class="fo-sitestats-line">已运行 <b><?php echo (int)$fo_uptime['days']; ?></b> 天 · 本月更新 <b><?php echo (int)$fo_data['month_posts']; ?></b> 篇</p>
    <div class="fo-yearbars">
      <?php $fo_max_y = 0; foreach ($fo_year_bars as $b) { $fo_max_y = max($fo_max_y, $b['count']); } ?>
      <?php foreach ($fo_year_bars as $b): ?>
        <div class="fo-yearbar-item">
          <span class="fo-yearbar-c"><?php echo (int)$b['count']; ?></span>
          <span class="fo-yearbar-stick" style="height:<?php echo $fo_max_y > 0 ? max(6, round($b['count'] / $fo_max_y * 54)) : 6; ?>px"></span>
          <span class="fo-yearbar-y"><?php echo (int)$b['year']; ?></span>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="fo-sitestats-foot">
      <div><b><?php echo (int)$fo_data['month_posts']; ?></b><span>本月文章</span></div>
      <div><b><?php echo e(fo_num($fo_data['views'])); ?></b><span>总浏览量</span></div>
    </div>
  </section>
  <?php endif; ?>
</aside>
