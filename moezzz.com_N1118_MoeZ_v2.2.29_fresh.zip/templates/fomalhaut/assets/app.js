/*!
 * 星辉 · Fomalhaut —— 前台脚本集合
 * 页面内联脚本合并到这里，浏览器可缓存；各段按元素是否存在自动跳过。
 */

/* 页脚：菜单抽屉、回顶、隐藏重复浮标、随机友链 */
(function () {
  var t = document.getElementById('fo-to-top');
  if (t) t.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });

  /* 运行时长：每秒实时更新（服务端给出建站时间戳，避免时钟偏差） */
  var up = document.getElementById('fo-uptime-b');
  if (up) {
    var start = parseInt(up.getAttribute('data-start') || '0', 10);
    if (start > 0) {
      var render = function () {
        var d = Math.floor(Date.now() / 1000) - start;
        if (d < 0) d = 0;
        var days = Math.floor(d / 86400);
        var hours = Math.floor((d % 86400) / 3600);
        var mins = Math.floor((d % 3600) / 60);
        var secs = d % 60;
        up.textContent = days + ' 天 ' + (hours < 10 ? '0' : '') + hours + ' 小时 ' + (mins < 10 ? '0' : '') + mins + ' 分 ' + (secs < 10 ? '0' : '') + secs + ' 秒';
      };
      render();
      setInterval(render, 1000);
    }
  }

  /* 浮动回顶：首页桌面端已有右侧浮动条时隐藏，其余页面（栏目/文章/归档等）均显示 */
  var fab = document.getElementById('fo-totop');
  if (fab) {
    var rail = document.querySelector('.fo-rail');
    var wideMq = window.matchMedia('(min-width: 901px)');
    var syncFab = function () {
      if (rail && wideMq.matches) { fab.classList.remove('is-on'); fab.hidden = true; return; }
      fab.hidden = false;
      if (window.pageYOffset > 300) fab.classList.add('is-on');
      else fab.classList.remove('is-on');
    };
    fab.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
    window.addEventListener('scroll', syncFab, { passive: true });
    if (wideMq.addEventListener) wideMq.addEventListener('change', syncFab);
    else if (wideMq.addListener) wideMq.addListener(syncFab);
    syncFab();
  }

  var nav = document.getElementById('fo-nav-toggle');
  var head = document.getElementById('fo-header');
  if (nav && head) {
    nav.addEventListener('click', function () {
      var open = head.classList.toggle('is-open');
      nav.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    /* 手机端：点击菜单项后收起抽屉 */
    head.addEventListener('click', function (ev) {
      var link = ev.target.closest ? ev.target.closest('.fo-nav-link') : null;
      if (link && head.classList.contains('is-open')) {
        head.classList.remove('is-open');
        nav.setAttribute('aria-expanded', 'false');
      }
    });
  }
  /* 页脚「点击开启星辰之旅」：点一次随机开一条友链 */
  var quoteBtn = document.getElementById('fo-quote-btn');
  if (quoteBtn) {
    quoteBtn.addEventListener('click', function (ev) {
      var raw = this.getAttribute('data-friends') || '';
      if (!raw) return;
      var pool = raw.split('|').filter(function (u) { return /^https?:\/\//i.test(u); });
      if (pool.length < 2) return;
      ev.preventDefault();
      var pick = pool[Math.floor(Math.random() * pool.length)];
      window.open(pick, '_blank', 'noopener,noreferrer');
    });
  }

  /* 手机端侧栏：≤900px 时移入汉堡菜单抽屉，桌面端还原到原位 */
  var side = document.getElementById('fo-side');
  var drawer = document.getElementById('fo-side-drawer');
  if (side && drawer) {
    var sideHome = side.parentNode;
    var sideNext = side.nextSibling;
    var sideMq = window.matchMedia('(max-width: 900px)');
    var placeSide = function () {
      if (sideMq.matches) {
        if (side.parentNode !== drawer) drawer.appendChild(side);
      } else if (side.parentNode !== sideHome) {
        sideHome.insertBefore(side, sideNext);
      }
    };
    placeSide();
    if (sideMq.addEventListener) sideMq.addEventListener('change', placeSide);
    else if (sideMq.addListener) sideMq.addListener(placeSide);
  }
})();

/* 评论：表情、一言、图片上传、提交 */
(function () {
  var wrap = document.querySelector('.fo-comments');
  var f = document.getElementById('fo-comment-form');
  if (!wrap || !f) return;
  window.foDefaultAvatar = wrap.getAttribute('data-avatar') || '';
  var msg = document.getElementById('fo-comment-msg');
  var ta = f.querySelector('textarea[name=content]');

  /* 光标处插入文本 */
  function insertText(text) {
    if (!ta) return;
    var s = ta.selectionStart || 0, epos = ta.selectionEnd || 0;
    ta.value = ta.value.slice(0, s) + text + ta.value.slice(epos);
    ta.selectionStart = ta.selectionEnd = s + text.length;
    ta.focus();
  }

  /* 表情：点工具条展开/收起，点表情插入光标处 */
  var emoToggle = document.getElementById('fo-emoji-toggle');
  var emoBar = document.getElementById('fo-emoji-bar');
  if (emoToggle && emoBar) {
    emoToggle.addEventListener('click', function () { emoBar.classList.toggle('is-open'); });
    emoBar.addEventListener('click', function (ev) {
      var btn = ev.target.closest('.fo-emoji-btn');
      if (!btn) return;
      insertText(btn.getAttribute('data-emo') || '');
      emoBar.classList.remove('is-open');
    });
  }

  /* 一言：滚动到评论框附近才请求，省掉首屏的外部请求；不想打字可直接发布这句话 */
  var hkText = '';
  if (wrap.getAttribute('data-hitokoto') === '1') {
    var local = ['风起于青萍之末，浪成于微澜之间。', '星星发亮是为了让每一个人有一天都能找到属于自己的星星。', '把普通的事做好，就是不普通。', '慢慢来，比较快。', '心中有丘壑，眉目作山河。'];
    var applyHk = function (quote, from) {
      hkText = quote;
      ta.placeholder = '「 ' + quote + ' 」—— ' + (from || '一言') + '\n（不想打字？直接点「发布评论」就发这句话）';
    };
    var loadHk = function () {
      if (navigator.connection && navigator.connection.saveData) {
        applyHk(local[Math.floor(Math.random() * local.length)], '一言');
        return;
      }
      fetch('https://v1.hitokoto.cn/?encode=json&c=d&c=i&c=k', { cache: 'no-store' })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          var q = d.hitokoto || local[Math.floor(Math.random() * local.length)];
          applyHk(q, d.from);
        })
        .catch(function () {
          var q = local[Math.floor(Math.random() * local.length)];
          applyHk(q, '一言');
        });
    };
    if ('IntersectionObserver' in window) {
      var hkObserver = new IntersectionObserver(function (entries) {
        for (var i = 0; i < entries.length; i++) {
          if (entries[i].isIntersecting) { hkObserver.disconnect(); loadHk(); return; }
        }
      }, { rootMargin: '240px 0px' });
      hkObserver.observe(f);
    } else {
      loadHk();
    }
  } else if (ta) {
    ta.placeholder = '写下你的评论…' + (wrap.getAttribute('data-img') === '1' ? '可上传图片，支持粘贴 [img]图片地址[/img]' : '');
  }

  /* 评论图片上传 */
  var imgBtn = document.getElementById('fo-img-btn');
  var imgInput = document.getElementById('fo-img-input');
  var imgStatus = document.getElementById('fo-img-status');
  var previews = document.getElementById('fo-img-previews');
  function markPreview(input) {
    if (!previews) return;
    var tag = document.createElement('span');
    tag.className = 'fo-img-thumb';
    tag.textContent = input;
    previews.appendChild(tag);
  }
  if (imgBtn && imgInput) {
    imgBtn.addEventListener('click', function () { imgInput.click(); });
    imgInput.addEventListener('change', function () {
      var file = imgInput.files && imgInput.files[0];
      if (!file) return;
      if (file.size > 5 * 1024 * 1024) { if (imgStatus) imgStatus.textContent = '图片不能超过 5MB'; imgInput.value = ''; return; }
      if (imgStatus) imgStatus.textContent = '上传中…';
      var fd = new FormData();
      fd.append('file', file);
      var csrfInput = f.querySelector('input[name=_token]');
      if (csrfInput) fd.append('_token', csrfInput.value);
      fetch(wrap.getAttribute('data-upload'), { method: 'POST', body: fd, credentials: 'same-origin' })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          if (d.ok) {
            insertText((ta.value && ta.value !== '' && ta.value.slice(-1) !== '\n' ? '\n' : '') + '[img]' + d.url + '[/img]');
            markPreview(d.url.split('/').pop());
            if (imgStatus) imgStatus.textContent = '插入成功';
          } else {
            if (imgStatus) imgStatus.textContent = d.msg || '上传失败';
          }
        })
        .catch(function () { if (imgStatus) imgStatus.textContent = '网络异常，上传失败'; })
        .finally(function () { imgInput.value = ''; setTimeout(function () { if (imgStatus) imgStatus.textContent = ''; }, 2500); });
    });
  }

  /* 回复：点某条评论的「回复」后提交时带上 parent_id；再点同一条的「回复」取消 */
  var replyParent = document.getElementById('fo-reply-parent');
  if (replyParent) document.addEventListener('click', function (ev) {
    var btn = ev.target.closest ? ev.target.closest('.fo-reply-btn') : null;
    if (!btn) return;
    var id = btn.getAttribute('data-id') || '0';
    if (replyParent.value === id) {
      replyParent.value = '0';
    } else {
      replyParent.value = id;
      if (ta) ta.focus();
    }
  });

  /* 提交：内容为空时自动用一言发布，仍为空则提示 */
  f.addEventListener('submit', function (ev) {
    ev.preventDefault();
    if (ta && ta.value.trim() === '') {
      if (hkText !== '') ta.value = hkText;
      else {
        msg.hidden = false; msg.className = 'fo-comment-msg is-err'; msg.textContent = '评论内容不能为空';
        return;
      }
    }
    var btn = f.querySelector('button[type=submit]');
    btn.disabled = true;
    fetch(f.action, { method: 'POST', body: new FormData(f), credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        msg.hidden = false;
        msg.textContent = d.msg || (d.ok ? '发布成功' : '发布失败');
        msg.className = 'fo-comment-msg ' + (d.ok ? 'is-ok' : 'is-err');
        if (d.ok) {
          f.reset();
          var pm = document.getElementById('fo-points-endpoint');
          if (pm) {
            var pb = new URLSearchParams();
            pb.set('_token', pm.getAttribute('data-token') || '');
            pb.set('action', 'comment');
            fetch(pm.getAttribute('data-url'), { method: 'POST', body: pb, credentials: 'same-origin' })
              .then(function (r) { return r.json(); })
              .then(function (pd) {
                if (pd && pd.ok && pd.msg) {
                  msg.textContent = (d.msg || '发布成功') + ' · ' + pd.msg;
                }
              })
              .catch(function () {});
          }
          setTimeout(function () { location.reload(); }, 1300);
        }
      })
      .catch(function () {
        msg.hidden = false; msg.className = 'fo-comment-msg is-err'; msg.textContent = '网络异常，请稍后再试';
      })
      .finally(function () { btn.disabled = false; });
  });
})();

/* 友链页：复制字段与模板、提示条 */
(function () {
  var grid = document.getElementById('fo-fr-grid');
  if (!grid) return;
  var cards = Array.prototype.slice.call(grid.querySelectorAll('.fo-fr-card'));
  var search = document.getElementById('fo-fr-search');
  var filters = document.getElementById('fo-fr-filters');
  var empty = document.getElementById('fo-fr-empty');
  var state = 'all';
  var kw = '';

  function apply() {
    var shown = 0;
    cards.forEach(function (c) {
      var name = (c.getAttribute('data-name') || '').toLowerCase();
      var host = (c.getAttribute('data-host') || '').toLowerCase();
      var st = c.getAttribute('data-state') || 'unknown';
      var okKw = kw === '' || name.indexOf(kw) > -1 || host.indexOf(kw) > -1;
      var okSt = state === 'all' || st === state;
      var show = okKw && okSt;
      c.hidden = !show;
      if (show) shown++;
    });
    if (empty) empty.hidden = shown !== 0;
  }

  if (search) search.addEventListener('input', function () {
    kw = this.value.trim().toLowerCase();
    apply();
  });

  if (filters) filters.addEventListener('click', function (ev) {
    var btn = ev.target.closest ? ev.target.closest('.fo-fr-filter') : null;
    if (!btn) return;
    state = btn.getAttribute('data-state') || 'all';
    filters.querySelectorAll('.fo-fr-filter').forEach(function (b) { b.classList.toggle('is-active', b === btn); });
    apply();
  });

  var random = document.getElementById('fo-fr-random');
  if (random) random.addEventListener('click', function () {
    if (!cards.length) return;
    var pick = cards[Math.floor(Math.random() * cards.length)];
    window.open(pick.href, '_blank', 'noopener');
  });
})();

/* 友链页：搜索、状态筛选、随机漫游 */
(function () {
  var wrap = document.getElementById('fo-fri-apply');
  if (!wrap) return;
  var toast = document.getElementById('fo-fi-toast');
  var timer = 0;

  function showToast(text) {
    if (!toast) return;
    if (text) toast.textContent = text;
    toast.hidden = false;
    toast.classList.add('is-on');
    clearTimeout(timer);
    timer = setTimeout(function () {
      toast.classList.remove('is-on');
      setTimeout(function () { toast.hidden = true; }, 220);
    }, 1600);
  }

  function legacyCopy(text) {
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    var ok = false;
    try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
    document.body.removeChild(ta);
    return ok;
  }

  function copyText(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text).then(function () { return true; }, function () { return legacyCopy(text); });
    }
    return Promise.resolve(legacyCopy(text));
  }

  wrap.addEventListener('click', function (ev) {
    var btn = ev.target.closest ? ev.target.closest('.fo-fi-copy') : null;
    if (!btn) return;
    var text = btn.getAttribute('data-copy');
    if (text === null) {
      var id = btn.getAttribute('data-copy-target');
      var node = id ? document.getElementById(id) : null;
      text = node ? node.textContent : '';
    }
    if (!text) return;
    copyText(text).then(function (ok) {
      if (ok) {
        btn.classList.add('is-done');
        setTimeout(function () { btn.classList.remove('is-done'); }, 1200);
        showToast('已复制到剪贴板');
      } else {
        showToast('复制失败，请手动选中复制');
      }
    });
  });
})();

/* 用户中心：签到领积分 */
(function () {
  var btn = document.getElementById('fo-signin-btn');
  if (!btn) return;
  btn.addEventListener('click', function () {
    if (btn.disabled) return;
    btn.disabled = true;
    var msg = document.getElementById('fo-signin-msg');
    var body = new URLSearchParams();
    body.set('_token', btn.getAttribute('data-token') || '');
    fetch(btn.getAttribute('data-url'), { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (msg) {
          msg.hidden = false;
          msg.textContent = d.msg || (d.ok ? '签到成功' : '签到失败');
          msg.className = 'fo-points-signed ' + (d.ok ? 'is-ok' : 'is-err');
        }
        if (d.ok) {
          setTimeout(function () { location.reload(); }, 900);
        } else {
          btn.disabled = false;
        }
      })
      .catch(function () {
        if (msg) { msg.hidden = false; msg.textContent = '网络异常，请稍后再试'; msg.className = 'fo-points-signed is-err'; }
        btn.disabled = false;
      });
  });
})();

/* 友链页：空闲时触发每日失联检测（服务端一天最多跑一次） */
(function () {
  var mark = document.getElementById('fo-fr-linkcheck');
  if (!mark) return;
  var token = mark.getAttribute('data-token') || '';
  if (!token) {
    var tokenInput = document.querySelector('.fo-comment-form input[name="_token"]');
    token = tokenInput ? tokenInput.value : '';
  }
  if (!token || !mark.getAttribute('data-url')) return;
  var run = function () {
    var body = new URLSearchParams();
    body.set('_token', token);
    fetch(mark.getAttribute('data-url'), { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (d && d.dead > 0 && !sessionStorage.getItem('fo-dead-reloaded')) {
          sessionStorage.setItem('fo-dead-reloaded', '1');
          location.reload();
        }
      })
      .catch(function () {});
  };
  if ('requestIdleCallback' in window) {
    requestIdleCallback(run, { timeout: 4000 });
  } else {
    setTimeout(run, 1500);
  }
})();

/* 首页：副标题打字机 */
(function () {
  var el = document.querySelector('.fo-hero-sub.fo-typing');
  if (!el) return;
  var txt = el.getAttribute('data-text') || el.textContent || '';
  el.textContent = '';
  var i = 0, del = false;
  function step() {
    el.textContent = txt.slice(0, i);
    if (!del) {
      if (i < txt.length) { i++; setTimeout(step, 130); }
      else { del = true; setTimeout(step, 2000); }          /* 打完停 2 秒 */
    } else {
      if (i > 0) { i--; setTimeout(step, 60); }             /* 快速删除 */
      else { del = false; setTimeout(step, 600); }          /* 删完停 0.6 秒再打 */
    }
  }
  step();
})();

/* 归档：年份筛选 */
(function () {
  var chips = document.querySelectorAll('.fo-yearchip');
  var groups = document.querySelectorAll('.fo-yeargroup');
  chips.forEach(function (c) {
    c.addEventListener('click', function () {
      chips.forEach(function (x) { x.classList.remove('is-active'); });
      c.classList.add('is-active');
      var y = c.getAttribute('data-year');
      groups.forEach(function (g) {
        g.style.display = (y === 'all' || g.getAttribute('data-year') === y) ? '' : 'none';
      });
    });
  });
})();

/* 搜索：美化 URL 提交 */
(function () {
  var f = document.querySelector('.fo-search');
  if (f && f.getAttribute('data-pretty') === '1') {
    f.addEventListener('submit', function (ev) {
      var q = f.querySelector('input[name=q]');
      if (q && q.value.trim()) {
        ev.preventDefault();
        location.href = f.getAttribute('data-base') + 'search/' + encodeURIComponent(q.value.trim());
      }
    });
  }
})();

/* 文章点赞（2.1.2）：like.php 切换式点赞，Cookie 防重复；游客也能点 */
(function () {
  var btn = document.getElementById('fo-like-btn');
  if (!btn) return;
  var pid = btn.getAttribute('data-pid');
  var num = btn.querySelector('.fo-like-num');
  var count = parseInt(btn.getAttribute('data-likes'), 10) || 0;
  var liked = document.cookie.indexOf('moe_like_' + pid + '=1') !== -1;

  function paint() {
    btn.classList.toggle('is-liked', liked);
    btn.setAttribute('aria-pressed', liked ? 'true' : 'false');
    if (num) num.textContent = String(count);
  }
  paint();

  btn.addEventListener('click', function () {
    if (btn.classList.contains('is-busy')) return;
    btn.classList.add('is-busy');
    var tok = document.querySelector('.fo-comment-form input[name="_token"]');
    var body = new URLSearchParams();
    body.set('pid', pid);
    body.set('_token', tok ? tok.value : '');
    fetch(btn.getAttribute('data-url'), { method: 'POST', body: body, credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        btn.classList.remove('is-busy');
        if (!j || !j.ok) return;
        count = parseInt(j.likes, 10) || 0;
        liked = !!j.liked;
        paint();
        btn.classList.add('is-pop');
        setTimeout(function () { btn.classList.remove('is-pop'); }, 450);
      })
      .catch(function () { btn.classList.remove('is-busy'); });
  });
})();

/* ============ 2.1.6 文章左侧目录：滚动高亮 + 阅读进度 + 平滑跳转 ============ */
(function () {
  var toc = document.getElementById('fo-toc');
  if (!toc) return;
  var body = document.getElementById('fo-article-body');
  var list = toc.querySelector('.fo-toc-list');
  var links = [].slice.call(toc.querySelectorAll('.fo-toc-list a'));
  if (!body || !list || !links.length) return;

  var heads = links.map(function (a) {
    var id = a.getAttribute('href') || '';
    return id.charAt(0) === '#' ? document.getElementById(decodeURIComponent(id.slice(1))) : null;
  });
  var prog = document.getElementById('fo-toc-prog');
  var ticking = false;
  var wrap = body.closest('.fo-wrap');
  var artTop = 0;

  /* 2.1.9：左侧空间够（不压正文）且滚动过正文顶部（不压 Hero）时才显示目录 */
  function measure() {
    artTop = body.getBoundingClientRect().top + window.pageYOffset;
    var avail = wrap ? (window.innerWidth - wrap.getBoundingClientRect().width) / 2 : 0;
    toc.classList.toggle('is-fit', avail >= 200 && window.innerWidth >= 1560);
  }

  function sync() {
    ticking = false;
    toc.classList.toggle('is-show', window.innerWidth >= 1560 && window.pageYOffset + 110 >= artTop);
    var offset = 120, cur = 0, i;
    for (i = 0; i < heads.length; i++) {
      if (heads[i] && heads[i].getBoundingClientRect().top <= offset) cur = i;
    }
    // 读完到底：高亮最后一节
    if (window.innerHeight + window.pageYOffset >= document.body.scrollHeight - 6) cur = heads.length - 1;

    for (i = 0; i < links.length; i++) {
      links[i].parentNode.classList.toggle('is-on', i === cur);
    }

    if (prog) {
      var r = body.getBoundingClientRect();
      var total = r.height - window.innerHeight + offset;
      var done = total > 40 ? (offset - r.top) / total : 1;
      done = Math.max(0, Math.min(1, done));
      prog.style.width = (done * 100).toFixed(1) + '%';
    }

    var on = links[cur] ? links[cur].parentNode : null;
    if (on) {
      var lb = list.getBoundingClientRect(), ib = on.getBoundingClientRect();
      if (ib.top < lb.top || ib.bottom > lb.bottom) list.scrollTop += (ib.top - lb.top) - 8;
    }
  }

  function onScroll() {
    if (!ticking) { ticking = true; requestAnimationFrame(sync); }
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  window.addEventListener('resize', function () { measure(); onScroll(); });

  links.forEach(function (a) {
    a.addEventListener('click', function (ev) {
      var href = a.getAttribute('href') || '';
      if (href.charAt(0) !== '#') return;
      var el = document.getElementById(decodeURIComponent(href.slice(1)));
      if (!el) return;
      ev.preventDefault();
      var top = el.getBoundingClientRect().top + window.pageYOffset - 84;
      var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
      window.scrollTo({ top: top, behavior: reduce ? 'auto' : 'smooth' });
      if (history.replaceState) history.replaceState(null, '', href);
    });
  });

  measure();
  sync();
})();

/* ============ 2.1.8 Hero 越过导航栏：滚动后导航变实底 ============ */
(function () {
  var head = document.getElementById('fo-header');
  if (!head || !document.body.classList.contains('fo-hero-under')) return;
  function sync() { head.classList.toggle('is-solid', window.pageYOffset > 40); }
  window.addEventListener('scroll', sync, { passive: true });
  sync();
})();

/* ============ 2.1.14 文章图片灯箱 ============
   正文内图片点击后全屏预览：支持左右切换、键盘 ←/→/Esc、点击遮罩关闭、触摸滑动。 */
(function () {
  var prose = document.getElementById('fo-article-body') || document.querySelector('.fo-prose');
  if (!prose) return;
  var imgs = Array.prototype.slice.call(prose.querySelectorAll('img')).filter(function (img) {
    if (img.closest('[data-no-lightbox]')) return false;
    if (img.getAttribute('data-no-zoom') !== null) return false;
    return img.getAttribute('src');
  });
  if (!imgs.length) return;

  var box = null, pic = null, cap = null, cur = 0, lastFocus = null, lockedY = 0;

  function build() {
    box = document.createElement('div');
    box.className = 'fo-lightbox';
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-modal', 'true');
    box.setAttribute('aria-label', '图片预览');
    box.innerHTML =
      '<button type="button" class="fo-lb-btn fo-lb-close" aria-label="关闭（Esc）">&#215;</button>' +
      '<button type="button" class="fo-lb-btn fo-lb-prev" aria-label="上一张">&#8249;</button>' +
      '<button type="button" class="fo-lb-btn fo-lb-next" aria-label="下一张">&#8250;</button>' +
      '<figure class="fo-lb-figure"><img class="fo-lb-img" alt="">' +
      '<figcaption class="fo-lb-cap"></figcaption></figure>';
    document.body.appendChild(box);
    pic = box.querySelector('.fo-lb-img');
    cap = box.querySelector('.fo-lb-cap');

    box.querySelector('.fo-lb-close').addEventListener('click', close);
    box.querySelector('.fo-lb-prev').addEventListener('click', function (e) { e.stopPropagation(); step(-1); });
    box.querySelector('.fo-lb-next').addEventListener('click', function (e) { e.stopPropagation(); step(1); });
    box.addEventListener('click', function (e) {
      if (e.target === box || e.target.classList.contains('fo-lb-figure')) close();
    });
    pic.addEventListener('load', function () { box.classList.add('is-ready'); });

    /* 触摸滑动切换 */
    var sx = 0, sy = 0;
    box.addEventListener('touchstart', function (e) {
      if (!e.touches.length) return;
      sx = e.touches[0].clientX; sy = e.touches[0].clientY;
    }, { passive: true });
    box.addEventListener('touchend', function (e) {
      if (!e.changedTouches.length) return;
      var dx = e.changedTouches[0].clientX - sx;
      var dy = e.changedTouches[0].clientY - sy;
      if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy)) step(dx < 0 ? 1 : -1);
      else if (dy > 80) close();
    }, { passive: true });

    document.addEventListener('keydown', onKey);
  }

  function paint() {
    var img = imgs[cur];
    box.classList.remove('is-ready');
    pic.src = img.getAttribute('src');
    pic.alt = img.getAttribute('alt') || '';
    var text = (img.getAttribute('alt') || '').trim();
    cap.textContent = text;
    cap.style.display = text ? '' : 'none';
    box.classList.toggle('is-single', imgs.length < 2);
    if (pic.complete) box.classList.add('is-ready');
  }

  function step(dir) {
    cur = (cur + dir + imgs.length) % imgs.length;
    paint();
  }

  function open(i) {
    if (!box) build();
    cur = i;
    lastFocus = document.activeElement;
    lockedY = window.pageYOffset;
    paint();
    box.classList.add('is-open');
    document.body.classList.add('fo-lb-lock');
    document.body.style.top = (-lockedY) + 'px';
    var btn = box.querySelector('.fo-lb-close');
    if (btn) btn.focus({ preventScroll: true });
  }

  function close() {
    if (!box) return;
    box.classList.remove('is-open', 'is-ready');
    document.body.classList.remove('fo-lb-lock');
    document.body.style.top = '';
    window.scrollTo(0, lockedY);
    if (lastFocus && lastFocus.focus) lastFocus.focus({ preventScroll: true });
  }

  function onKey(e) {
    if (!box || !box.classList.contains('is-open')) return;
    if (e.key === 'Escape') { e.preventDefault(); close(); }
    else if (e.key === 'ArrowLeft' && imgs.length > 1) { e.preventDefault(); step(-1); }
    else if (e.key === 'ArrowRight' && imgs.length > 1) { e.preventDefault(); step(1); }
  }

  imgs.forEach(function (img, i) {
    img.classList.add('fo-zoomable');
    if (!img.getAttribute('loading')) img.setAttribute('loading', 'lazy');
    if (!img.getAttribute('decoding')) img.setAttribute('decoding', 'async');
    img.addEventListener('click', function (e) {
      e.preventDefault();
      open(i);
    });
  });

  /* 图片在正文里常被 <a> 包住：阻止链接跳转，直接开灯箱 */
  imgs.forEach(function (img) {
    var a = img.closest('a');
    if (a) a.addEventListener('click', function (e) { e.preventDefault(); });
  });
})();

/* ============ 2.1.16 看板娘聊天 ============ */
(function () {
  var root = document.getElementById('fo-companion');
  if (!root) return;
  var figure = root.querySelector('.fo-cp-figure');
  var panel = root.querySelector('.fo-cp-panel');
  var msgs = root.querySelector('.fo-cp-msgs');
  var chipsBox = root.querySelector('.fo-cp-chips');
  var form = root.querySelector('.fo-cp-form');
  var input = root.querySelector('.fo-cp-input');
  var closeBtn = root.querySelector('.fo-cp-close');
  var resetBtn = root.querySelector('.fo-cp-reset');
  if (!figure || !panel || !msgs) return;

  var api = root.getAttribute('data-api') || 'chat.php';
  var token = root.getAttribute('data-token') || '';
  var greet = root.getAttribute('data-greet') || '在的呀～有什么想聊的、想找的，都可以问我。';
  var DEFAULT_CHIPS = [['最新文章', '最新文章'], ['热门推荐', '热门推荐'], ['站点分类', '站点分类'], ['关于小站', '关于小站']];

  /* 2.1.27 她会读你正在看的这一页：把标题、分类、正文摘一段一起带给 AI，
     再配两条「这一页」相关的快捷话题，问「这篇讲了什么」时她真的答得上来 */
  function pageContext() {
    try {
      var body = document.querySelector('.fo-prose') || document.querySelector('.fo-catitem') || document.body;
      if (!body) return '';
      var txt = (body.innerText || body.textContent || '').replace(/\s+/g, ' ').trim();
      if (txt.length > 1600) txt = txt.slice(0, 1600);
      var cat = document.querySelector('.fo-article-meta .fo-chip-mini');
      var sub = document.querySelector('.fo-hero-sub');
      var head = (document.title || '').trim();
      if (cat) head += '｜分类：' + cat.textContent.trim();
      if (sub) head += '｜' + sub.textContent.trim();
      return head + '｜' + txt;
    } catch (e) { return ''; }
  }
  function pageChips() {
    var list = [];
    if (document.querySelector('.fo-prose')) {
      list.push(['这篇讲了什么', '帮我用三句话总结这篇《' + (document.title || '').replace(/\s*[-–|].*$/, '') + '》的要点']);
      list.push(['和我聊聊这页', '随便聊聊我现在看的这一页，说说你的想法']);
    }
    return list.concat(DEFAULT_CHIPS);
  }
  var busy = false, greeted = false;

  /* 2.1.27 触屏适配：手机上「自动聚焦输入框」会把视口顶到聊天窗并弹出键盘，
     看起来就是「她一思考完就跳到聊天框」，很打断阅读。触屏下不再自动聚焦，
     是否输入交给访客自己点。 */
  var isTouch = (function () {
    try {
      return window.matchMedia('(hover: none) and (pointer: coarse)').matches || ('ontouchstart' in window);
    } catch (e) { return false; }
  })();
  function focusInput() {
    if (!input || isTouch) return;
    try { input.focus({ preventScroll: true }); } catch (e) { try { input.focus(); } catch (e2) {} }
  }

  /* 长期记忆的钥匙：访客本地稳定 id（清浏览器数据才会换新） */
  var cid = '';
  try {
    cid = localStorage.getItem('moe_cp_cid');
    if (!cid) {
      cid = 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
      localStorage.setItem('moe_cp_cid', cid);
    }
  } catch (er) {}

  /* 聊天记录本地留档：刷新页面、下次再来都能接着聊（最多 30 条） */
  var HIST_KEY = 'moe_cp_hist';
  function histLoad() {
    try { var h = JSON.parse(localStorage.getItem(HIST_KEY) || '[]'); return h && h.length ? h : []; } catch (er) { return []; }
  }
  function histSave(who, t) {
    try {
      var h = histLoad();
      h.push([who, t]);
      if (h.length > 30) h = h.slice(-30);
      localStorage.setItem(HIST_KEY, JSON.stringify(h));
    } catch (er) {}
  }
  function histClear() { try { localStorage.removeItem(HIST_KEY); } catch (er) {} }

  /* ---- 2.1.24 语音：串行队列 + 手势解锁 + 保活 + 病娇音色 ----
     无声根因：Chrome 会静默拦截无手势的 speak()、吞掉一次性塞入的多段队列、
     约 15 秒截断长朗读，cancel() 后立刻重播也会被吞。以下逐条对症处理。 */
  var synth = window.speechSynthesis || null;
  var voiceBtn = root.querySelector('.fo-cp-voice');
  var styleBtn = root.querySelector('.fo-cp-style');
  var statusEl = root.querySelector('.fo-cp-head-status');
  var STYLE_KEYS = ['gentle', 'sweet', 'natural', 'yandere'];
  var STYLE_LABEL = { gentle: '温柔御姐', sweet: '清甜少女', natural: '系统原声', yandere: '病娇' };
  var STYLE_SHORT = { gentle: '御姐', sweet: '少女', natural: '原声', yandere: '病娇' };
  var STYLE_STATUS = {
    gentle: '在线 · 站内小助手', sweet: '在线 · 今天也元气满满',
    natural: '在线 · 系统原声', yandere: '在线 · 只准看着我哦…'
  };
  var voiceBox = {
    on: root.getAttribute('data-voice') !== '0',
    auto: root.getAttribute('data-voice-auto') !== '0',
    style: root.getAttribute('data-voice-style') || 'gentle',
    rate: parseFloat(root.getAttribute('data-voice-rate')) || 0,
    pitch: parseFloat(root.getAttribute('data-voice-pitch')) || 0
  };
  if (STYLE_KEYS.indexOf(voiceBox.style) < 0) voiceBox.style = 'gentle';
  /* 四种预置音色：御姐＝放慢半拍压低；少女＝略快抬高；natural＝原声；病娇＝偏高、忽快忽慢 */
  var V_STYLE = {
    gentle:  { rate: 0.90, pitch: 0.80 },
    sweet:   { rate: 1.02, pitch: 1.16 },
    natural: { rate: 1.00, pitch: 1.00 },
    yandere: { rate: 1.06, pitch: 1.22 }
  };
  /* 系统里的中文女声优先级：晓晓(Edge Natural 最像真人) > 晓伊 > 瑶瑶 > 慧慧 > 婷婷 > 美佳 */
  var V_RANK = ['xiaoxiao', '晓晓', 'xiaoyi', '晓伊', 'yaoyao', '瑶瑶', 'meijia', '美佳', 'huihui', '慧慧', 'tingting', '婷婷', 'hanhan', '涵涵'];
  var voice = null, voiceReady = false, speaking = false, lastSpoken = '', pendingSay = '';
  var voiceTries = 0;   /* 手机端首次取不到语音列表时的重试计数 */
  var voiceQueue = [], voiceIdx = 0, voiceToken = 0;
  var keepAliveTimer = null, startTimer = null, blockedNotified = false, userGestured = false;

  function pickVoice() {
    if (!synth) return;
    var list = [];
    try { list = synth.getVoices() || []; } catch (e) { list = []; }
    if (!list.length) {
      /* 手机端（尤其 Android Chrome / 微信）首屏常常是空列表，要等 voiceschanged 或轮询 */
      if (voiceTries++ < 8) setTimeout(pickVoice, 350);
      return;
    }
    voiceTries = 0;
    voiceReady = true;
    var zh = list.filter(function (v) { return /^(zh|cmn|yue)/i.test(v.lang || '') || /中文|普通話|普通话|Chinese/i.test(v.name || ''); });
    if (!zh.length) zh = list;
    var best = null, bestScore = -1;
    zh.forEach(function (v) {
      var n = String(v.name || '').toLowerCase(), s = 0;
      for (var i = 0; i < V_RANK.length; i++) {
        if (n.indexOf(V_RANK[i]) >= 0) { s = 100 - i * 6; break; }
      }
      if (/natural|online|neural/.test(n)) s += 12;      /* 神经语音更接近真人 */
      if (/female|女/.test(n)) s += 6;
      if (/男|male|yunxi|yunjian|kangkang/.test(n) && s < 60) s -= 20;
      if (!s && /zh/i.test(v.lang || '')) s = 1;
      if (s > bestScore) { bestScore = s; best = v; }
    });
    voice = best || zh[0] || null;
  }

  function voiceSupported() { return !!synth && typeof window.SpeechSynthesisUtterance === 'function'; }
  function styleLabel() { return STYLE_LABEL[voiceBox.style] || STYLE_LABEL.gentle; }

  function setSpeaking(on) {
    speaking = on;
    root.classList.toggle('is-speaking', on);
    if (voiceBtn) {
      voiceBtn.setAttribute('aria-label', on ? '停止朗读' : (voiceBox.on ? '关闭语音' : '开启语音'));
      voiceBtn.setAttribute('title', on ? '正在说话 · 点击停止' : (styleLabel() + '语音：' + (voiceBox.on ? '开' : '关')));
    }
  }

  /* 朗读前清洗：去掉链接、emoji、装饰符号，把省略号与破折号换成停顿 */
  function cleanText(t) {
    if (!t) return '';
    var s = String(t);
    s = s.replace(/https?:\/\/\S+/g, '');
    s = s.replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{2B00}-\u{2BFF}\u{FE0F}\u{200D}]/gu, '');
    s = s.replace(/[「」『』《》【】]/g, '');
    s = s.replace(/[·•✦★☆♪♥]/g, '');
    s = s.replace(/…+|\.{3,}/g, '，');
    s = s.replace(/[—–]{1,}|--/g, '，');
    s = s.replace(/\s+/g, ' ');
    return s.trim();
  }

  /* 长文本按句切分，每段不超过约 40 字 */
  function splitText(t) {
    var raw = t.match(/[^。！？!?；;\n]+[。！？!?；;\n]*/g) || [t];
    var out = [];
    raw.forEach(function (seg) {
      seg = seg.trim();
      if (!seg) return;
      if (seg.length <= 42) { out.push(seg); return; }
      var sub = seg.match(/[^，,、]+[，,、]*/g) || [seg];
      var buf = '';
      sub.forEach(function (p) {
        if ((buf + p).length > 42 && buf) { out.push(buf); buf = p; }
        else buf += p;
      });
      if (buf) out.push(buf);
    });
    return out.filter(function (s) { return s.replace(/[\s，,。！？!?；;]/g, '').length > 0; });
  }

  /* 病娇台词润色：只加语气、不改事实；检索结果 / 带数字的资讯保持原样 */
  function yanderize(t) {
    var s = String(t || '');
    if (/https?|\d{4}年|第\s*\d|\d+\s*(篇|条|个)|分类|搜索|链接|结果|地址/i.test(s)) return s;
    var tails = [
      '……只准看着我哦，呐？',
      '……嘿嘿，我一直都在这里等你呢。',
      '……不许去看别的网站哦？',
      '……你不会突然不见的，对吧？',
      '……嗯，这样就好，我们一直在一起。'
    ];
    var h = 0;
    for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    s = s.replace('。', '……').replace(/！/g, '…！').replace(/？/g, '…？');
    return s + tails[h % tails.length];
  }

  /* 病娇情绪曲线：逐段交替快慢高低，尾段放慢压低，像忽然贴近耳边低语 */
  function emotionCurve(i, total, st) {
    if (voiceBox.style !== 'yandere') return { rate: st.rate, pitch: st.pitch };
    var swing = [0, 0.14, -0.10, 0.18, -0.06][i % 5];
    var last = (i === total - 1);
    return {
      rate: Math.min(2, Math.max(0.5, st.rate + swing + (last ? -0.16 : 0))),
      pitch: Math.min(2, Math.max(0.3, st.pitch + swing * 1.4 + (last ? -0.28 : 0)))
    };
  }

  function keepAliveStop() {
    if (keepAliveTimer) { clearInterval(keepAliveTimer); keepAliveTimer = null; }
  }
  /* Chrome 约 15 秒会把长朗读截断；定时 pause/resume 让队列保持激活 */
  function keepAlive() {
    keepAliveStop();
    /* 手机端禁用 pause/resume 保活：iOS 会因此整段静音，Android 也会被系统打断 */
    if (isTouch) return;
    keepAliveTimer = setInterval(function () {
      if (!speaking || !synth) { keepAliveStop(); return; }
      try { synth.pause(); synth.resume(); } catch (er) {}
    }, 8000);
  }

  function stopSpeak() {
    voiceToken++;                 /* 作废在途 onstart/onend，避免 cancel 后旧队列复活 */
    voiceQueue = []; voiceIdx = 0;
    if (startTimer) { clearTimeout(startTimer); startTimer = null; }
    keepAliveStop();
    if (synth) { try { synth.cancel(); } catch (er) {} }
    setSpeaking(false);
  }

  /* 静默失败必须可见：告诉访客是浏览器拦了，以及怎么解锁 */
  function voiceBlocked(reason) {
    root.setAttribute('data-voice-blocked', reason === 'error' ? '2' : '1');
    if (!msgs) return;
    var tip = document.createElement('div');
    tip.className = 'fo-cp-msg is-bot is-sys';
    var line = document.createElement('div');
    line.className = 'fo-cp-bubble';
    line.textContent = reason === 'mobile'
      ? '这台手机的浏览器没让我出声…可能是没装中文语音包，或在微信/B站这类内置浏览器里打开了。用系统浏览器打开本站，声音就正常了 ✦'
      : (reason === 'error'
        ? '语音好像没念出来…检查一下系统音量或中文语音包，再点这句话旁的小喇叭试试 ✦'
        : '浏览器把自动朗读挡住啦～点一下页面任意处，再点这句话旁边的小喇叭就能听到我 ✦');
    tip.appendChild(line);
    msgs.appendChild(tip);
    scrollEnd();
  }

  /* 逐段串行：一次只喂一句，onend 后再喂下一句，Chrome 不再吞队列
     2.1.28 手机端两段式重试：先按选中的中文音色念，2.4 秒还没出声就换系统默认发音重念一遍
     （很多安卓机/微信内置浏览器只认默认引擎，指定 voice 反而静默失败），两轮都没声才算失败 */
  function speakNext() {
    if (!voiceBox.on || !voiceSupported() || voiceIdx >= voiceQueue.length) {
      setSpeaking(false); keepAliveStop(); return;
    }
    var token = voiceToken;
    var item = voiceQueue[voiceIdx];
    var stage = 0;
    var started = false;

    function clearTimer() { if (startTimer) { clearTimeout(startTimer); startTimer = null; } }

    function attempt() {
      if (token !== voiceToken || !voiceBox.on) return;
      var useVoice = stage === 0 ? voice : null;
      var u = new SpeechSynthesisUtterance(item.text);
      if (useVoice) { try { u.voice = useVoice; } catch (er) {} u.lang = useVoice.lang || 'zh-CN'; }
      else u.lang = 'zh-CN';
      u.rate = item.rate; u.pitch = item.pitch; u.volume = 1;

      u.onstart = function () {
        if (token !== voiceToken) return;
        started = true;
        setSpeaking(true);
        clearTimer();
      };
      u.onend = function () {
        if (token !== voiceToken) return;
        clearTimer();
        voiceIdx++;
        setTimeout(function () { if (token === voiceToken) speakNext(); }, 45);
      };
      u.onerror = function (ev) {
        if (token !== voiceToken) return;
        clearTimer();
        var err = ev && ev.error ? ev.error : '';
        if (err === 'interrupted' || err === 'canceled') return;
        /* not-allowed = 自动播放策略拦截；这类错误不会触发 onstart，必须显式提示访客怎么解锁 */
        if (err === 'not-allowed') {
          setSpeaking(false); keepAliveStop();
          voiceQueue = []; voiceIdx = 0;
          if (!blockedNotified) { blockedNotified = true; voiceBlocked('autoplay'); }
          return;
        }
        /* 音色不认（synthesis-failed / audio-busy 等）：换默认发音再试一次 */
        if (stage === 0) {
          stage = 1;
          setTimeout(attempt, isTouch ? 320 : 180);
          return;
        }
        setSpeaking(false); keepAliveStop();
        voiceQueue = []; voiceIdx = 0;
        if (!blockedNotified) { blockedNotified = true; voiceBlocked('error'); }
      };

      try { if (synth.paused) synth.resume(); synth.speak(u); } catch (er) { setSpeaking(false); return; }

      clearTimer();
      startTimer = setTimeout(function () {
        if (token !== voiceToken || started) return;
        /* 一轮没出声：换默认发音再来 */
        if (stage === 0 && voice) {
          stage = 1;
          try { synth.cancel(); } catch (er) {}
          setTimeout(attempt, isTouch ? 320 : 180);
          return;
        }
        /* 两轮都没声：手机端不 cancel（慢机首句合成可能 4-6 秒，cancel 就彻底没声），只记录并按需提示 */
        root.setAttribute('data-voice-blocked', '2');
        stopSpeak();
        if (!blockedNotified) { blockedNotified = true; voiceBlocked(isTouch ? 'mobile' : 'timeout'); }
      }, isTouch ? 2400 : 1700);
    }

    attempt();
  }

  function speak(text, force) {
    if (!voiceSupported() || !voiceBox.on || (!voiceBox.auto && !force)) return;
    /* 手机端还没发生过任何触摸手势：先记下来，等第一次点击（解锁语音引擎）后再念 */
    if (isTouch && !userGestured && !force) { pendingSay = text; return; }
    var t = cleanText(text);
    if (!t) return;
    if (!voice) pickVoice();
    lastSpoken = text;
    if (voiceBox.style === 'yandere') t = yanderize(t);
    var st = V_STYLE[voiceBox.style] || V_STYLE.gentle;
    var baseRate = voiceBox.rate > 0 ? voiceBox.rate : st.rate;
    var basePitch = voiceBox.pitch > 0 ? voiceBox.pitch : st.pitch;
    var parts = splitText(t);
    if (!parts.length) return;
    var wasBusy = false;
    try { wasBusy = !!(synth.speaking || synth.pending); } catch (er) {}
    stopSpeak();                  /* 先停上一段：stopSpeak 会清空 voiceQueue，顺序不能颠倒 */
    voiceQueue = parts.map(function (p, i) {
      var emo = emotionCurve(i, parts.length, { rate: baseRate, pitch: basePitch });
      return { text: p, rate: emo.rate, pitch: emo.pitch };
    });
    voiceIdx = 0;
    var token = voiceToken;
    var launch = function () {
      if (token !== voiceToken || !voiceBox.on) return;
      if (!voice) pickVoice();
      keepAlive();
      speakNext();
    };
    /* cancel() 之后立刻 speak() 在安卓 Chrome / iOS 上常被静默丢弃，必须留间隔；
       之前只在「上一段还在念」时才等 180ms，空闲重播就直接被吞了 —— 这正是手机没声的主因 */
    setTimeout(launch, wasBusy ? 240 : (isTouch ? 280 : 130));
  }

  /* 首次用户手势预热语音引擎：Chrome/Edge 会静默拦截无手势的首次 speak()
     2.1.28 不再在 50ms 后 cancel 预热句 —— iOS 上 cancel 紧跟 speak 会把引擎卡死，
     之后整页再也发不出声（手机端「完全没语音」的另一个主因）。预热句用最短文本，自己就结束了 */
  function unlockVoice() {
    if (userGestured) return;
    userGestured = true;
    if (!voiceSupported()) return;          /* 浏览器压根没有语音合成：只记手势，别抛错 */
    try {
      synth.resume();
      var warm = new SpeechSynthesisUtterance('。');
      warm.lang = 'zh-CN'; warm.volume = 0; warm.rate = 2;
      synth.speak(warm);
      if (pendingSay) {
        var pd = pendingSay;
        pendingSay = '';
        /* 留够时间让预热句走完，再念真正的内容 */
        setTimeout(function () { speak(pd, true); }, 420);
      }
    } catch (er) {}
  }
  ['pointerdown', 'touchstart', 'keydown'].forEach(function (ev) {
    document.addEventListener(ev, unlockVoice, { once: true, passive: true, capture: true });
  });

  /* 浏览器不支持语音合成（部分微信/QQ 内置浏览器、老安卓机）：按钮置灰并说明原因，
     别再让访客对着按钮点了没反应 */
  if (!voiceSupported() && voiceBtn) {
    voiceBtn.classList.add('is-na');
    voiceBtn.setAttribute('title', '当前浏览器不支持朗读');
    voiceBtn.setAttribute('aria-disabled', 'true');
    voiceBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (blockedNotified) return;
      blockedNotified = true;
      voiceBlocked('mobile');
    });
  }

  function syncVoiceBtn() {
    if (!voiceBtn) return;
    voiceBtn.classList.toggle('is-on', voiceBox.on);
    voiceBtn.classList.toggle('is-off', !voiceBox.on);
    voiceBtn.setAttribute('title', styleLabel() + '语音：' + (voiceBox.on ? '开' : '关'));
    voiceBtn.setAttribute('aria-label', voiceBox.on ? '关闭语音' : '开启语音');
    voiceBtn.setAttribute('aria-pressed', voiceBox.on ? 'true' : 'false');
  }

  function applyStyle(s, save) {
    if (STYLE_KEYS.indexOf(s) < 0) s = 'gentle';
    voiceBox.style = s;
    blockedNotified = false;
    root.setAttribute('data-voice-style', s);
    root.classList.toggle('is-yandere', s === 'yandere');
    if (styleBtn) {
      var nm = styleBtn.querySelector('.fo-cp-style-name');
      if (nm) nm.textContent = STYLE_SHORT[s];
      styleBtn.setAttribute('title', '切换语音音色（当前：' + STYLE_LABEL[s] + '）');
      styleBtn.setAttribute('aria-label', '切换语音音色，当前' + STYLE_LABEL[s]);
      styleBtn.classList.toggle('is-y', s === 'yandere');
    }
    if (statusEl) { statusEl.textContent = STYLE_STATUS[s]; statusEl.setAttribute('title', STYLE_STATUS[s]); }
    syncVoiceBtn();
    if (save) { try { localStorage.setItem('moe_cp_vstyle', s); } catch (er) {} }
  }

  if (voiceSupported()) {
    pickVoice();
    try { synth.addEventListener('voiceschanged', pickVoice); } catch (er) { synth.onvoiceschanged = pickVoice; }
    /* 关掉页面前停止朗读，避免后台还在念 */
    window.addEventListener('pagehide', stopSpeak);
  } else {
    voiceBox.on = false;
    if (voiceBtn) voiceBtn.hidden = true;
    if (styleBtn) styleBtn.hidden = true;
  }
  /* 站点设置里关掉了语音：彻底隐藏小喇叭与音色按钮，不响应点击 */
  if (root.getAttribute('data-voice') === '0') {
    voiceBox.on = false;
    if (voiceBtn) voiceBtn.hidden = true;
    if (styleBtn) styleBtn.hidden = true;
  }
  /* 访客上次选的音色优先于后台默认值 */
  try {
    var sv = localStorage.getItem('moe_cp_vstyle');
    if (sv && STYLE_KEYS.indexOf(sv) >= 0) voiceBox.style = sv;
  } catch (er) {}
  applyStyle(voiceBox.style, false);
  syncVoiceBtn();

  if (styleBtn) {
    styleBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      var next = STYLE_KEYS[(STYLE_KEYS.indexOf(voiceBox.style) + 1) % STYLE_KEYS.length];
      applyStyle(next, true);
      /* 换音色当场念一句，既验证出声又让访客立刻听出差别 */
      speak(lastSpoken || greet, true);
    });
  }
  if (voiceBtn) {
    voiceBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (speaking) { stopSpeak(); return; }
      voiceBox.on = !voiceBox.on;
      try { localStorage.setItem('moe_cp_voice', voiceBox.on ? '1' : '0'); } catch (er) {}
      syncVoiceBtn();
      if (voiceBox.on) speak(lastSpoken || greet, true);
    });
    /* 记住上次的开关选择（站点设置未强制关闭时） */
    try {
      var saved = localStorage.getItem('moe_cp_voice');
      if (saved === '0' && root.getAttribute('data-voice') === '1') { voiceBox.on = false; syncVoiceBtn(); }
    } catch (er) {}
  }
  function scrollEnd() { msgs.scrollTop = msgs.scrollHeight; }

  /* 表情联动：她说到带（动作）或颜文字的话，立绘跟着跳一下 */
  function emote() {
    if (!figure) return;
    figure.classList.remove('is-emote');
    void figure.offsetWidth;
    figure.classList.add('is-emote');
    setTimeout(function () { figure.classList.remove('is-emote'); }, 1600);
  }
  var EMOTE_RE = /[（(][^（）()]{1,12}[）)]|[✧≧ᴗω☆♪ヽﾉε▼]/;

  function addMsg(text, who, links, opts) {    var div = document.createElement('div');
    div.className = 'fo-cp-msg ' + (who === 'me' ? 'is-me' : 'is-bot');
    if (who !== 'me') {
      var ava = document.createElement('span');
      ava.className = 'fo-cp-ava';
      ava.textContent = '✦';
      div.appendChild(ava);
    }
    var body = document.createElement('div');
    body.className = 'fo-cp-bubble';

    function appendLinks() {
      if (!links || !links.length) return;
      var box = document.createElement('div');
      box.className = 'fo-cp-links';
      links.forEach(function (l) {
        if (!l || !l.u) return;
        var a = document.createElement('a');
        a.href = l.u;
        a.textContent = l.t || l.u;
        a.rel = 'noopener';
        box.appendChild(a);
      });
      if (box.firstChild) body.appendChild(box);
    }

    /* 动作按钮：她可以带你去某个页面、回顶部——你点了才执行 */
    function appendActions() {
      var acts = opts && opts.actions;
      if (!acts || !acts.length) return;
      var box = document.createElement('div');
      box.className = 'fo-cp-acts';
      acts.slice(0, 2).forEach(function (a) {
        if (!a || !a.t) return;
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'fo-cp-act';
        b.textContent = '🪄 ' + (a.label || '执行');
        b.addEventListener('click', function (e) {
          e.stopPropagation();
          if (a.t === 'top') {
            window.scrollTo({ top: 0, behavior: 'smooth' });
          } else if (a.t === 'bottom') {
            window.scrollTo({ top: document.documentElement.scrollHeight, behavior: 'smooth' });
          } else if (a.u) {
            location.href = a.u;
          }
        });
        box.appendChild(b);
      });
      if (box.firstChild) body.appendChild(box);
    }

    div.appendChild(body);
    msgs.appendChild(div);
    /* 来源标签：让她知道这句是站内答的、AI 想出来的，还是刚从网上查的（放气泡里、链接后面） */
    var srcEl = null;
    if (who !== 'me' && opts && opts.src && opts.src !== 'local') {
      srcEl = document.createElement('span');
      srcEl.className = 'fo-cp-src is-' + opts.src;
      srcEl.textContent = opts.src === 'web' ? '🌐 联网查的' : '✦ AI 想的';
    }
    /* 每条回复旁挂一个「重听」小喇叭，悬停/移动端常显 */
    if (who !== 'me' && text) {
      var say = document.createElement('button');
      say.type = 'button';
      say.className = 'fo-cp-say';
      say.title = '重听这句话';
      say.setAttribute('aria-label', '重听这句话');
      say.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 9v6h4l5 4V5L8 9H4Z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/><path d="M18.8 6a8 8 0 0 1 0 12" opacity=".55"/></svg>';
      say.addEventListener('click', function (e) { e.stopPropagation(); speak(text, true); });
      div.appendChild(say);
    }
    var finish = function () {
      appendLinks();
      appendActions();
      if (srcEl) body.appendChild(srcEl);
      scrollEnd();
      if (who !== 'me' && text) {
        if (!(opts && opts.nosave)) histSave(who, text);
        if (EMOTE_RE.test(text)) emote();
        if (!(opts && opts.quiet)) speak(text);
      } else if (who === 'me' && text && !(opts && opts.nosave)) {
        histSave(who, text);
      }
    };
    if (who === 'bot' && opts && opts.typer && text && text.length > 14) {
      typeText(body, text, finish);
    } else {
      if (text) body.appendChild(document.createTextNode(text));
      finish();
    }
    scrollEnd();
  }

  /* 打字机：模型回复通常一秒来一大段，逐字放出来更像在说话 */
  function typeText(el, text, done) {
    var i = 0;
    var step = Math.max(1, Math.ceil(text.length / 80));
    var timer = setInterval(function () {
      i += step;
      if (i >= text.length) {
        clearInterval(timer);
        el.textContent = text;
        scrollEnd();
        if (done) done();
        return;
      }
      el.textContent = text.slice(0, i);
      scrollEnd();
    }, 20);
  }

  function setChips(list) {
    if (!chipsBox) return;
    chipsBox.innerHTML = '';
    (list && list.length ? list : DEFAULT_CHIPS).forEach(function (c) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'fo-cp-chip';
      b.textContent = c[0];
      b.addEventListener('click', function () { send(c[1] || c[0]); });
      chipsBox.appendChild(b);
    });
  }

  /* 打字气泡：label 可随等待时间变化（想 → 翻资料 → 还在努力） */
  function typing(on, label) {
    var t = msgs.querySelector('.fo-cp-typing');
    if (on) {
      if (t) {
        var lb = t.querySelector('.fo-cp-think');
        if (lb && label) lb.textContent = label;
        return;
      }
      t = document.createElement('div');
      t.className = 'fo-cp-msg is-bot fo-cp-typing';
      t.innerHTML = '<span class="fo-cp-ava">✦</span><div class="fo-cp-bubble"><i></i><i></i><i></i></div>'
        + (label ? '<em class="fo-cp-think">' + label + '</em>' : '');
      msgs.appendChild(t);
      scrollEnd();
    } else if (t) {
      t.remove();
    }
  }

  /* 等待文案：大模型一般 2～10 秒，给点反馈免得像卡住 */
  var waitTimers = [];
  function startWait() {
    clearWait();
    waitTimers.push(setTimeout(function () { typing(true, '正在翻资料…'); }, 2600));
    waitTimers.push(setTimeout(function () { typing(true, '还在想，稍等一下…'); }, 11000));
  }
  function clearWait() {
    waitTimers.forEach(function (t) { clearTimeout(t); });
    waitTimers = [];
  }

  function send(q) {
    q = (q || '').trim();
    if (!q || busy) return;
    busy = true;
    stopSpeak(); /* 用户开口时，她先停下来听 */
    addMsg(q, 'me');
    setChips([]);
    typing(true, '正在想…');
    startWait();
    var fd = new FormData();
    fd.append('q', q);
    fd.append('title', document.title || '');
    fd.append('url', location.href || '');
    /* 页面上下文：服务端认哪个字段就用哪个，多余的字段会被忽略，不影响原有问答 */
    var ctx = pageContext();
    if (ctx) { fd.append('ctx', ctx); fd.append('page_text', ctx); }
    if (cid) fd.append('cid', cid);
    var headers = {};
    if (token) headers['X-CSRF-Token'] = token;
    fetch(api, { method: 'POST', body: fd, credentials: 'same-origin', headers: headers })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        clearWait();
        typing(false);
        if (d && d.ok) {
          addMsg(d.text || '…', 'bot', d.links, { src: d.src, typer: true, actions: d.actions });
          setChips(d.chips);
        } else {
          addMsg((d && d.msg) || '唔…线路好像飘走了，稍后再试试。', 'bot');
          setChips(pageChips());
        }
        busy = false;
        focusInput();
      })
      .catch(function () {
        clearWait();
        typing(false);
        addMsg('网络好像不太稳定，稍后再和我聊聊吧。', 'bot');
        setChips(pageChips());
        busy = false;
      });
  }

  function open() {
    root.classList.add('is-open', 'is-hint-off');
    if (!greeted) {
      greeted = true;
      var old = histLoad();
      if (old.length) {
        /* 上次的聊天还在：安静地回放，让她「记得」你们聊过什么 */
        old.forEach(function (m) { addMsg(m[1], m[0], null, { quiet: true, nosave: true }); });
        setChips(pageChips());
      } else {
        addMsg(greet, 'bot');
        setChips(pageChips());
      }
    }
    setTimeout(focusInput, 260);
  }
  function toggle() {
    if (root.classList.contains('is-open')) { root.classList.remove('is-open'); stopSpeak(); }
    else open();
  }

  figure.addEventListener('click', toggle);
  figure.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
  });
  /* 2.1.30 手机端的小按钮：点一下她才从角落里出来并打开聊天窗 */
  var miniBtn = root.querySelector('.fo-cp-mini');
  if (miniBtn) {
    miniBtn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      open();
    });
  }
  if (closeBtn) closeBtn.addEventListener('click', function () { root.classList.remove('is-open'); stopSpeak(); });

  /* 重新开始：清空界面 + 清掉服务端记忆，然后重新打招呼 */
  if (resetBtn) {
    resetBtn.addEventListener('click', function (e) {
      e.stopPropagation();
      stopSpeak();
      clearWait();
      msgs.innerHTML = '';
      histClear();
      greeted = false;
      var fd = new FormData();
      fd.append('reset', '1');
      if (cid) fd.append('cid', cid);
      var headers = {};
      if (token) headers['X-CSRF-Token'] = token;
      fetch(api, { method: 'POST', body: fd, credentials: 'same-origin', headers: headers }).catch(function () {});
      setTimeout(function () {
        greeted = true;
        addMsg(greet, 'bot');
        setChips(pageChips());
        focusInput();
      }, 120);
    });
  }
  if (form) form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (!input) return;
    send(input.value);
    input.value = '';
  });
  /* Esc 关闭聊天窗（灯箱关闭优先级更高，仅在灯箱未开时生效） */
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && root.classList.contains('is-open') && !document.querySelector('.fo-lightbox.is-open')) {
      root.classList.remove('is-open');
    }
  });

  /* 主动互动：文章页读到接近底部时，她会冒出来提议带你回顶部（每个会话只提醒一次） */
  (function () {
    if (!document.querySelector('.fo-prose')) return; /* 只在文章页 */
    var fired = false;
    try { if (sessionStorage.getItem('moe_cp_read')) return; } catch (e) { return; }
    window.addEventListener('scroll', function () {
      if (fired) return;
      var max = document.documentElement.scrollHeight - window.innerHeight;
      if (max <= 200 || window.scrollY / max < 0.85) return;
      fired = true;
      try { sessionStorage.setItem('moe_cp_read', '1'); } catch (e) {}
      if (root.classList.contains('is-open')) return;
      var tip = document.createElement('div');
      tip.className = 'fo-cp-tip';
      tip.setAttribute('role', 'status');
      tip.innerHTML = '看完啦？我可以<span class="fo-cp-tip-btn" role="button" tabindex="0">带你回顶部</span>';
      var btn = tip.querySelector('.fo-cp-tip-btn');
      var go = function () { tip.remove(); window.scrollTo({ top: 0, behavior: 'smooth' }); };
      btn.addEventListener('click', function (e) { e.stopPropagation(); go(); });
      btn.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
      root.appendChild(tip);
      setTimeout(function () { if (tip.parentNode) tip.remove(); }, 15000);
    }, { passive: true });
  })();
})();

/* ============ 2.1.27 文章页 AI 摘要 ============ */
(function () {
  var box = document.getElementById('fo-aisum');
  if (!box) return;
  var bodyEl = document.getElementById('fo-aisum-body');
  var againBtn = document.getElementById('fo-aisum-again');
  var api = box.getAttribute('data-api') || 'chat.php';
  var csrf = box.getAttribute('data-csrf') || '';
  var key = 'fo_aisum_' + location.pathname + '_' + (box.getAttribute('data-key') || '0');
  var article = document.getElementById('fo-article-body');
  var busy = false, done = false;

  function text() {
    if (!article) return '';
    var t = (article.innerText || article.textContent || '').replace(/\s+/g, ' ').trim();
    return t.length > 1400 ? t.slice(0, 1400) : t;
  }
  function cacheGet() {
    try { return sessionStorage.getItem(key) || ''; } catch (e) { return ''; }
  }
  function cacheSet(v) {
    try { sessionStorage.setItem(key, v); } catch (e) {}
  }
  function render(t) {
    bodyEl.textContent = t;
    box.classList.add('is-ready');
    box.classList.remove('is-fail');
    if (againBtn) againBtn.hidden = false;
  }
  function fail() {
    /* 拿不到像样的摘要时不要再糊一段闲聊，直接说清楚，并留「换一版」让访客重试 */
    busy = false;
    bodyEl.textContent = '这篇的摘要暂时没生成出来，点右上角「换一版」再试一次。';
    box.classList.add('is-ready', 'is-fail');
    if (againBtn) againBtn.hidden = false;
  }
  function pick(regen) {
    var src = text();
    if (!src) { fail(); return; }
    if (busy) return;
    busy = true;
    box.classList.remove('is-off', 'is-fail');
    bodyEl.innerHTML = '<span class="fo-aisum-skel"><i></i><i></i><i></i></span>';
    var title = box.getAttribute('data-title') || document.title || '';
    var body = src.length > 900 ? src.slice(0, 900) : src;

    /* 摘要的本质是「把标题 + 正文交给模型，让它压缩成要点」。
       chat.php 是聊天接口，提示词里出现「站内 / 关于 / 了解」这类词容易被当成闲聊意图，
       所以这里用最朴素的说法；正文前 900 字放进 q，其余通过 page_text / ctx 交代。 */
    function ask(strict) {
      if (strict) {
        return '只输出两三句要点，用句号结尾；不要称呼、不要寒暄、不要出现「你」「我」「AI」。\n'
          + '《' + title + '》\n' + body;
      }
      return '这篇文章主要讲了什么？用两三句话概括要点：\n《' + title + '》\n' + body;
    }

    /* 一看就是寒暄 / 站内闲聊的回复，不算摘要 */
    function looksCanned(t) {
      var s = String(t || '').replace(/\s+/g, '');
      if (s.length < 12) return true;
      if (/想了解更多|关于页|了解更多|欢迎关注|加我|建议你|去逛逛|站内搜索|我是.{0,6}助手/.test(s)) return true;
      if (!/[。！？]/.test(s) && s.length < 40) return true;
      return false;
    }

    function strip(t) {
      return String(t || '').replace(/^【?AI\s*摘要】?[：:]\s*/i, '').trim();
    }

    function finish(t) {
      busy = false;
      cacheSet(t);
      render(t);
      done = true;
    }

    function request(strict, back) {
      var fd = new FormData();
      fd.append('q', ask(strict));
      fd.append('title', title);
      fd.append('url', location.href || '');
      fd.append('mode', 'summary');
      fd.append('task', 'summary');
      fd.append('page_text', src);          /* 服务端认这个字段时，正文可以给全 */
      fd.append('ctx', src);
      fd.append('cid', 'aisum-' + (box.getAttribute('data-key') || '0') + (regen ? '-r' + Date.now() : ''));
      var headers = {};
      if (csrf) headers['X-CSRF-Token'] = csrf;
      var ctrl = null, timer = null;
      try {
        if (window.AbortController) {
          ctrl = new AbortController();
          timer = setTimeout(function () { try { ctrl.abort(); } catch (e) {} }, 25000);
        }
      } catch (e) {}
      fetch(api, { method: 'POST', body: fd, credentials: 'same-origin', headers: headers, signal: ctrl ? ctrl.signal : undefined })
        .then(function (r) { return r.json(); })
        .then(function (d) {
          if (timer) clearTimeout(timer);
          back(d && d.ok ? String(d.text || '') : '');
        })
        .catch(function () { if (timer) clearTimeout(timer); back(''); });
    }

    request(false, function (raw) {
      var t = strip(raw);
      if (t && !looksCanned(t)) { finish(t); return; }
      /* 第一次拿回来的不像摘要：换更硬的说法再要一遍 */
      request(true, function (raw2) {
        var t2 = strip(raw2);
        if (t2 && !looksCanned(t2)) { finish(t2); return; }
        fail();
      });
    });
  }

  var cached = cacheGet();
  if (cached) { render(cached); done = true; }

  /* 滚到摘要再请求：一次阅读不看完就走的访客不消耗 token */
  if (!done) {
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (es) {
        es.forEach(function (en) {
          if (en.isIntersecting && !done) { io.disconnect(); pick(false); }
        });
      }, { rootMargin: '140px' });
      io.observe(box);
    } else {
      pick(false);
    }
  }
  if (againBtn) againBtn.addEventListener('click', function () { try { sessionStorage.removeItem(key); } catch (e) {} pick(true); });
})();

/* ============ 2.1.27 版权区「复制链接」 ============ */
(function () {
  document.addEventListener('click', function (e) {
    var btn = e.target.closest ? e.target.closest('.fo-copyright-copy') : null;
    if (!btn) return;
    e.preventDefault();
    var url = btn.getAttribute('data-url') || location.href;
    var ok = function () {
      var old = btn.textContent;
      btn.textContent = '已复制';
      btn.classList.add('is-done');
      setTimeout(function () { btn.textContent = old; btn.classList.remove('is-done'); }, 1600);
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(url).then(ok, function () { ok(); });
    } else {
      var ta = document.createElement('textarea');
      ta.value = url;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); } catch (er) {}
      document.body.removeChild(ta);
      ok();
    }
  });
})();
