<?php
/**
 * 二次元 · Nijigen 模板 · 首页
 * 可用变量：$posts（含 cat_name/cat_slug/cat_id）、$pager、$page、$total、$site、$nav_cats
 * 结构：横幅 hero → 最新文章（第 1 页首条精选大卡 + 图文列表 / 卡片网格）→ 分页
 */
if (!defined('NG_ASSET_VER')) require_once theme_path('_lib.php');
$ng_landing = ng_opt('landing', 'off');
if ($ng_landing === 'on' && (int)$page === 1 && !isset($_GET['enter'])) {
    /* 封面式首页：首次访问先看个人资料页；站内「首页」链接与封面按钮均带 ?enter=1 直达列表 */
    include theme_path('landing.php');
    return;
}

$page_title = $site['name'];
$cur_p = 'index';
include partial_path('header.php');

$ng_layout   = ng_opt('layout', 'list');
$ng_hero     = ng_opt('hero_mode', 'full');
$ng_title    = trim(ng_opt('hero_title', '')) !== '' ? ng_opt('hero_title', '') : $site['name'];
$ng_sub      = trim(ng_opt('hero_sub', '')) !== '' ? ng_opt('hero_sub', '') : $site['sub'];
$ng_sign     = $site['signature'] ? $site['signature'] : '欢迎来到我的小站～ (๑>ᴗ<๑)';
$ng_hbg      = trim((string)ng_opt('hero_bg_img', ''));
/* 背景图遮罩：默认 none（纯图，不再叠主题色），可选中性压暗 / 主题色 */
$ng_hveil    = ng_opt('hero_veil', 'none');
if (!in_array($ng_hveil, array('none', 'light', 'mid', 'strong', 'tint'), true)) $ng_hveil = 'none';
$ng_posts    = (array) $posts;
$ng_feat     = null;   // 精选大卡（仅第 1 页且列表模式）
if ($page == 1 && $ng_layout === 'list' && count($ng_posts) > 0) {
    $ng_feat = array_shift($ng_posts);
}
?>

<?php if ($ng_hero !== 'off'): ?>
<header class="ng-hero<?php echo $ng_hero === 'mini' ? ' is-mini' : ''; ?><?php echo $ng_hbg !== '' ? ' has-bg ng-veil-' . e($ng_hveil) : ''; ?>"
        <?php if ($ng_hbg !== ''): ?>style="--hero-bg:url('<?php echo e(media_url($ng_hbg)); ?>')"<?php endif; ?>>
  <span class="ng-deco d1">🌸</span><span class="ng-deco d2">✦</span>
  <span class="ng-deco d3">☁️</span><span class="ng-deco d4">🌟</span>
  <div class="avatar-ring"><img src="<?php echo e(media_url($site['avatar'])); ?>" alt="<?php echo e($site['name']); ?> 的头像"></div>
  <h1><?php echo e($ng_title); ?></h1>
  <?php if ($ng_sub): ?><p class="sub"><?php echo e($ng_sub); ?></p><?php endif; ?>
  <div class="ng-typing"><span id="ngTyping" data-text="<?php echo e($ng_sign); ?>"></span><span class="cursor"></span></div>

  <?php if (ng_on('show_socials', '1')): ?>
  <div class="socials">
    <?php foreach ($site['socials'] as $soc): ?>
      <?php $socImg = function_exists('social_icon_url') ? social_icon_url($soc['icon']) : ''; ?>
      <a href="<?php echo e($soc['url']); ?>" target="_blank" rel="noopener" title="<?php echo e($soc['name']); ?>">
        <?php if ($socImg !== ''): ?><img src="<?php echo e($socImg); ?>" alt="<?php echo e($soc['name']); ?>" onerror="this.remove()"><?php else: ?><?php echo e($soc['icon'] !== '' ? $soc['icon'] : '🔗'); ?><?php endif; ?>
      </a>
    <?php endforeach; ?>
    <?php if ($site['rss']): ?><a href="<?php echo e(rss_url()); ?>" title="RSS 订阅">📡</a><?php endif; ?>
  </div>
  <?php endif; ?>

  <?php if (ng_on('show_stats', '1')): ?>
  <div class="ng-stat-bar">
    <span class="ng-stat"><b><?php echo (int)$site['stats']['posts']; ?></b><span>文章</span></span>
    <span class="ng-stat"><b><?php echo (int)$site['stats']['comments']; ?></b><span>评论</span></span>
    <span class="ng-stat"><b><?php echo e(ng_num($site['stats']['views'])); ?></b><span>浏览</span></span>
  </div>
  <?php endif; ?>
</header>
<?php endif; ?>

<?php $ng_side = ng_side_on(); ?>
<?php if ($ng_side): ?><div class="ng-layout"><div class="ng-main"><?php endif; ?>

<section>
  <div class="ng-sec-title">
    <h2><i>🌸</i>最新文章</h2>
    <span class="ng-more">共 <?php echo (int)$total; ?> 篇</span>
  </div>

  <?php if (empty($posts)): ?>
    <div class="ng-empty">
      <span class="big">🌱</span>
      <h2>还没有文章哦～</h2>
      <p>登录后台写下第一篇，和大家见面吧！</p>
      <a class="ng-btn" href="<?php echo e(base_url() . 'admin/'); ?>">前往后台 ✍️</a>
    </div>
  <?php else: ?>

    <?php if ($ng_feat): $ng_fcover = ng_cover($ng_feat); ?>
    <a class="ng-feat" href="<?php echo e(post_url($ng_feat)); ?>" style="background:<?php echo e($ng_fcover['style']); ?>">
      <?php echo ng_cover_img($ng_fcover['url'], true); ?>
      <?php if ($ng_fcover['url'] === ''): ?><span class="ng-cover-ph" aria-hidden="true"></span><?php endif; ?>
      <span class="ng-feat-veil"></span>
      <div class="ng-feat-body">
        <span class="ng-feat-tag">✧ 最新一篇<?php echo !empty($ng_feat['is_top']) ? ' · 置顶' : ''; ?></span>
        <h3><?php echo e($ng_feat['title']); ?></h3>
        <p class="ng-meta">
          <?php if (!empty($ng_feat['cat_name'])): ?><span><?php echo e($ng_feat['cat_name']); ?></span><?php endif; ?>
          <time><?php echo e(nice_time($ng_feat['created_at'])); ?></time>
          <span>⏱ 约 <?php echo reading_time($ng_feat); ?> 分钟</span>
          <?php if (isset($ng_feat['views'])): ?><span>👀 <?php echo e(ng_num($ng_feat['views'])); ?> 阅读</span><?php endif; ?>
        </p>
      </div>
    </a>
    <?php endif; ?>

    <?php
      $ng_show_reading = ng_on('show_reading', '1');
      include theme_path('_list.php');
    ?>

    <?php echo $pager; ?>
  <?php endif; ?>
</section>

<?php if ($ng_side): ?></div><?php include theme_path('_sidebar.php'); ?></div><?php endif; ?>

<?php include partial_path('footer.php'); ?>
