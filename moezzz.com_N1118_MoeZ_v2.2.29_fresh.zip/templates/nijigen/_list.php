<?php
/**
 * Nijigen 模板 · 图文列表片段（供首页尾段 / 分类 / 搜索 / 写作页复用）
 * 调用方先设置：
 *   $ng_posts         文章行数组
 *   $ng_layout        'list'（左图右文行式）| 'alt'（左右交替）| 'grid'（双列卡片网格）
 *   $ng_show_reading  是否显示阅读时长（bool，可省略，默认显示）
 */
$ng_layout = isset($ng_layout) ? $ng_layout : 'list';
$ng_show_reading = !isset($ng_show_reading) || $ng_show_reading;

if (empty($ng_posts)) return;

$ng_is_grid = ($ng_layout === 'grid');
$ng_is_alt  = ($ng_layout === 'alt');
?>
<div class="<?php echo $ng_is_grid ? 'ng-grid' : ($ng_is_alt ? 'ng-list is-alt' : 'ng-list'); ?>">
  <?php foreach ($ng_posts as $ng_i => $ng_p):
    $ng_cover = ng_cover($ng_p);
    $ng_url   = post_url($ng_p);
    $ng_title = isset($ng_p['title']) ? $ng_p['title'] : '（无标题）';
    $ng_tags  = ng_tags($ng_p);
    $ng_rev   = $ng_is_alt && ((int)$ng_i % 2 === 1);
    $ng_pid   = isset($ng_p['id']) ? (int)$ng_p['id'] : 0;
    $ng_date  = isset($ng_p['created_at']) ? (string)$ng_p['created_at'] : '';
    /* 分类字段在不同路由里给的名字不一样（cat_id / category_id），逐项兜底，避免 PHP 8 的 Undefined array key 警告污染页面 */
    $ng_cname = isset($ng_p['cat_name']) ? (string)$ng_p['cat_name'] : '';
    $ng_cat   = array(
        'id'   => isset($ng_p['cat_id']) ? (int)$ng_p['cat_id'] : (isset($ng_p['category_id']) ? (int)$ng_p['category_id'] : 0),
        'name' => $ng_cname,
        'slug' => isset($ng_p['cat_slug']) ? (string)$ng_p['cat_slug'] : '',
    );
  ?>
  <?php if ($ng_is_grid): ?>
  <article class="ng-card" style="--row-grad:<?php echo e($ng_cover['style']); ?>">
    <a class="ng-card-cover" href="<?php echo e($ng_url); ?>">
      <?php echo ng_cover_img($ng_cover['url']); ?>
      <?php if ($ng_cover['url'] === ''): ?><span class="ng-cover-ph" aria-hidden="true"></span><?php endif; ?>
      <?php if (!empty($ng_p['is_top'])): ?><span class="ng-pin">置顶</span><?php endif; ?>
    </a>
    <div class="ng-card-body">
      <div class="ng-meta">
        <?php if ($ng_cname !== ''): ?>
          <a class="ng-chip" href="<?php echo e(cat_url($ng_cat)); ?>"><?php echo e($ng_cname); ?></a>
        <?php endif; ?>
        <?php if ($ng_date !== ''): ?><time datetime="<?php echo e($ng_date); ?>"><?php echo e(nice_time($ng_date)); ?></time><?php endif; ?>
      </div>
      <h3><a href="<?php echo e($ng_url); ?>"><?php echo e($ng_title); ?></a></h3>
      <p class="excerpt"><?php echo e(post_excerpt($ng_p, 64)); ?></p>
      <div class="ng-meta">
        <?php if ($ng_tags): ?><span><?php foreach ($ng_tags as $ng_t): ?>#<?php echo e($ng_t); ?> <?php endforeach; ?></span><?php endif; ?>
        <?php if (isset($ng_p['views'])): ?><span>👀 <?php echo e(ng_num($ng_p['views'])); ?></span><?php endif; ?>
      </div>
    </div>
  </article>
  <?php else: ?>
  <article class="ng-row<?php echo $ng_rev ? ' is-rev' : ''; ?>" style="--row-grad:<?php echo e($ng_cover['style']); ?>">
    <a class="ng-row-cover" href="<?php echo e($ng_url); ?>">
      <?php echo ng_cover_img($ng_cover['url']); ?>
      <?php if ($ng_cover['url'] === ''): ?><span class="ng-cover-ph" aria-hidden="true"></span><?php endif; ?>
      <?php if (!empty($ng_p['is_top'])): ?><span class="ng-pin">置顶</span><?php endif; ?>
    </a>
    <div class="ng-row-body">
      <div class="ng-meta">
        <?php if ($ng_cname !== ''): ?>
          <a class="ng-chip" href="<?php echo e(cat_url($ng_cat)); ?>"><?php echo e($ng_cname); ?></a>
        <?php endif; ?>
        <?php if ($ng_date !== ''): ?><time datetime="<?php echo e($ng_date); ?>"><?php echo e(nice_time($ng_date)); ?></time><?php endif; ?>
        <?php if ($ng_show_reading && !empty($ng_p['content'])): ?><span class="ng-rt">⏱ 约 <?php echo reading_time($ng_p); ?> 分钟</span><?php endif; ?>
        <?php foreach (array_slice($ng_tags, 0, 2) as $ng_t): ?><span class="ng-tag">#<?php echo e($ng_t); ?></span><?php endforeach; ?>
      </div>
      <h3><a href="<?php echo e($ng_url); ?>"><?php echo e($ng_title); ?></a></h3>
      <p class="excerpt"><?php echo e(post_excerpt($ng_p, 96)); ?></p>
      <div class="ng-meta">
        <?php if (isset($ng_p['views'])): ?><span>👀 <?php echo e(ng_num($ng_p['views'])); ?> 阅读</span><?php endif; ?>
        <span>💬 <?php echo $ng_pid > 0 ? ng_comments($ng_pid) : 0; ?> 评论</span>
      </div>
    </div>
  </article>
  <?php endif; ?>
  <?php endforeach; ?>
</div>
