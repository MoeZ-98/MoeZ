<?php
/**
 * Nijigen 模板 · 分类文章列表
 * 可用变量：$cat $posts $pager $total $site $nav_cats
 */
$page_title = '分类：' . $cat['name'];
$cur_p = 'category';
include partial_path('header.php');
?>

<?php $ng_side = ng_side_on(); ?>
<?php if ($ng_side): ?><div class="ng-layout"><div class="ng-main"><?php endif; ?>

<header class="ng-page-head">
  <h1>🌸 <?php echo e($cat['name']); ?></h1>
  <p><?php echo $cat['description'] ? e($cat['description']) : '这个分类下共 ' . (int)$total . ' 篇文章'; ?></p>
</header>

<?php if (count($nav_cats) > 1): ?>
<div class="ng-chips">
  <?php foreach ($nav_cats as $c): ?>
    <a class="<?php echo $c['id'] == $cat['id'] ? 'cur' : ''; ?>" href="<?php echo e(cat_url($c)); ?>"><?php echo e($c['name']); ?></a>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if (empty($posts)): ?>
  <div class="ng-empty">
    <span class="big">🍂</span>
    <h2>这里还没有文章～</h2>
    <p>去别的分类逛逛，或者回到首页看看吧！</p>
    <a class="ng-btn" href="<?php echo e(u()); ?>">回到首页 🏠</a>
  </div>
<?php else: ?>
  <?php
    $ng_posts = $posts;
    $ng_layout = ng_opt('layout', 'list');
    $ng_show_reading = ng_on('show_reading', '1');
    include theme_path('_list.php');
  ?>
  <?php echo $pager; ?>
<?php endif; ?>

<?php if ($ng_side): ?></div><?php include theme_path('_sidebar.php'); ?></div><?php endif; ?>

<?php include partial_path('footer.php'); ?>
