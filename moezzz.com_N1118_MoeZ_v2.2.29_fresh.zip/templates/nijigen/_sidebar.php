<?php
/**
 * Nijigen 模板 · 侧边栏公共片段（首页 / 分类 / 搜索 / 写作页复用）
 * 调用方负责外层 .ng-layout 双栏容器；本文件自身也校验开关，关闭时直接 return。
 * 可用变量：$site $nav_cats，分类页另有 $cat
 */
if (!defined('NG_ASSET_VER')) require_once theme_path('_lib.php');
if (!ng_side_on()) return;

$ng_hot      = ng_on('side_hot', '1')      ? ng_side_hot(6)      : array();
$ng_side_cs  = ng_on('side_cats', '1')     ? ng_side_cats(10, isset($nav_cats) ? $nav_cats : array()) : array();
$ng_cmts     = ng_on('side_comments', '1') ? ng_side_comments(5) : array();
$ng_cloud    = ng_on('side_tags', '1')     ? ng_side_tags(14)    : array();
$ng_side_ls  = ng_on('side_links', '1')    ? ng_side_links(5)    : array();
$ng_notice   = trim((string)ng_opt('sidebar_notice', ''));
?>
<aside class="ng-side">
  <div class="ng-side-sticky">

    <?php if (ng_on('side_profile', '1')): ?>
    <div class="ng-side-card ng-profile">
      <img class="ng-profile-avatar" src="<?php echo e(media_url($site['avatar'])); ?>" alt="<?php echo e($site['name']); ?>">
      <b class="ng-profile-name"><?php echo e($site['name']); ?></b>
      <?php if ($site['signature'] || $site['sub']): ?>
        <p class="ng-profile-sign"><?php echo e($site['signature'] ? $site['signature'] : $site['sub']); ?></p>
      <?php endif; ?>
      <div class="ng-profile-stats">
        <span><b><?php echo (int)$site['stats']['posts']; ?></b><i>文章</i></span>
        <span><b><?php echo (int)$site['stats']['comments']; ?></b><i>评论</i></span>
        <span><b><?php echo e(ng_num($site['stats']['views'])); ?></b><i>浏览</i></span>
      </div>
      <?php if ($site['rss']): ?><a class="ng-profile-rss" href="<?php echo e(rss_url()); ?>">📡 RSS 订阅</a><?php endif; ?>
    </div>
    <?php endif; ?>

    <?php if ($ng_notice !== '' && ng_on('side_notice', '1')): ?>
    <div class="ng-side-card">
      <h3><i>📢</i>公告</h3>
      <p class="ng-notice"><?php echo nl2br(e($ng_notice)); ?></p>
    </div>
    <?php endif; ?>

    <?php if (ng_on('side_search', '1')): ?>
    <div class="ng-side-card ng-card-search">
      <h3><i>🔍</i>搜搜看</h3>
      <form class="ng-search ng-side-search" action="<?php echo e(base_url() . 'index.php'); ?>" method="get"
            data-pretty="<?php echo is_pretty_url() ? '1' : '0'; ?>" data-base="<?php echo e(base_url()); ?>">
        <input type="hidden" name="p" value="search">
        <input type="text" name="q" placeholder="想找点什么呢～" value="<?php echo isset($kw) ? e($kw) : ''; ?>">
        <button type="submit" aria-label="搜索">✧</button>
      </form>
    </div>
    <?php endif; ?>

    <?php if ($ng_hot): ?>
    <div class="ng-side-card">
      <h3><i>🔥</i>热门文章</h3>
      <ol class="ng-side-hot">
        <?php $ng_hi = 0; foreach ($ng_hot as $ng_h): ?>
          <?php
            $ng_hurl = '';
            if (function_exists('post_url')) {
                try { $ng_hurl = post_url($ng_h); } catch (Throwable $e) { $ng_hurl = ''; }
            }
            if ($ng_hurl === '') continue;
            $ng_hi++;
          ?>
        <li>
          <a href="<?php echo e($ng_hurl); ?>">
            <span class="rank"><?php echo $ng_hi; ?></span>
            <span class="t"><?php echo e(isset($ng_h['title']) ? $ng_h['title'] : '（无标题）'); ?></span>
            <?php if (isset($ng_h['views'])): ?><span class="v">👀<?php echo e(ng_num($ng_h['views'])); ?></span><?php endif; ?>
          </a>
        </li>
        <?php endforeach; ?>
      </ol>
    </div>
    <?php endif; ?>

    <?php if ($ng_side_cs): ?>
    <div class="ng-side-card">
      <h3><i>🌸</i>分类目录</h3>
      <ul class="ng-side-cats">
        <?php foreach ($ng_side_cs as $c): ?>
        <li>
          <a href="<?php echo e(cat_url($c)); ?>" class="<?php echo (isset($cat) && isset($c['id']) && $cat['id'] == $c['id']) ? 'cur' : ''; ?>">
            <span><?php echo e($c['name']); ?></span>
            <?php if (isset($c['n']) && $c['n'] !== null): ?><span class="n"><?php echo (int)$c['n']; ?> 篇</span><?php endif; ?>
          </a>
        </li>
        <?php endforeach; ?>
      </ul>
    </div>
    <?php endif; ?>

    <?php if ($ng_cmts): ?>
    <div class="ng-side-card">
      <h3><i>💬</i>最新评论</h3>
      <ul class="ng-side-cmts">
        <?php foreach ($ng_cmts as $c): $ng_cu = ng_cmt_user($c); ?>
        <li>
          <span class="ng-av" style="--av-h:<?php echo (int)$ng_cu['hue']; ?>">
            <span class="ng-av-l"><?php echo e($ng_cu['letter']); ?></span>
            <?php if ($ng_cu['avatar'] !== ''): ?>
              <img src="<?php echo e($ng_cu['avatar']); ?>" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()">
            <?php endif; ?>
          </span>
          <span class="b">
            <b><?php echo e($ng_cu['name']); ?></b>
            <p><?php echo e(ng_substr((string)(isset($c['content']) ? $c['content'] : ''), 0, 60)); ?></p>
          </span>
        </li>
        <?php endforeach; ?>
      </ul>
    </div>
    <?php endif; ?>

    <?php if ($ng_cloud): ?>
    <div class="ng-side-card">
      <h3><i>🏷️</i>标签云</h3>
      <div class="ng-side-tags">
        <?php foreach ($ng_cloud as $t => $n): ?><span>#<?php echo e($t); ?></span><?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <?php if ($ng_side_ls): ?>
    <div class="ng-side-card">
      <h3><i>🔗</i>友情链接</h3>
      <div class="ng-side-links">
        <?php foreach ($ng_side_ls as $l): ?>
        <a href="<?php echo e($l['url']); ?>" target="_blank" rel="noopener nofollow" title="<?php echo e($l['name']); ?>">
          <span class="face"><?php echo e(initial($l['name'])); ?></span>
          <span><?php echo e($l['name']); ?></span>
        </a>
        <?php endforeach; ?>
        <a class="all" href="<?php echo e(base_url() . 'link'); ?>">全部友链 →</a>
      </div>
    </div>
    <?php endif; ?>

  </div>
</aside>
