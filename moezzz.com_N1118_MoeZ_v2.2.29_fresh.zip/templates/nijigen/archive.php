<?php
/**
 * Nijigen 模板 · 归档时间线（路由 /archives）
 * 可用变量：$groups（年份字符串 => 文章行数组） $total $site $nav_cats
 */
$page_title = '归档';
$cur_p = 'archive';
include partial_path('header.php');
?>

<?php $ng_side = ng_side_on(); ?>
<?php if ($ng_side): ?><div class="ng-layout"><div class="ng-main"><?php endif; ?>

<header class="ng-page-head">
  <h1>🗂 归档</h1>
  <p>共 <?php echo (int)$total; ?> 篇文章 · <?php echo count((array)$groups); ?> 个年份，按时间倒序排列</p>
</header>

<?php if (empty($groups)): ?>
  <div class="ng-empty">
    <span class="big">🌱</span>
    <h2>还没有可以归档的文章</h2>
    <p>先去后台写一篇吧～</p>
    <a class="ng-btn" href="<?php echo e(u()); ?>">回到首页</a>
  </div>
<?php else: ?>
  <?php if (count((array)$groups) > 1): ?>
    <div class="ng-chips">
      <?php foreach ($groups as $year => $year_items): ?>
        <a href="#y<?php echo e($year); ?>"><?php echo e($year); ?> <span>· <?php echo count((array)$year_items); ?></span></a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <?php foreach ($groups as $year => $items): ?>
    <section class="ng-tl-group" id="y<?php echo e($year); ?>">
      <div class="ng-tl-head">
        <h2><?php echo e($year); ?></h2>
        <span class="ng-tl-count"><?php echo count((array)$items); ?> 篇</span>
      </div>
      <ul class="ng-tl-list">
        <?php foreach ((array)$items as $p): ?>
          <li class="ng-tl-item">
            <span class="ng-tl-date"><?php echo e(isset($p['created_at']) ? format_time($p['created_at'], 'm-d') : ''); ?></span>
            <a class="ng-tl-title" href="<?php echo e(!empty($p['id']) ? post_url($p) : '#'); ?>"><?php echo e(isset($p['title']) && $p['title'] !== '' ? $p['title'] : '（无标题）'); ?></a>
            <?php if (!empty($p['content'])): ?><span class="ng-tl-extra">⏱ 约 <?php echo reading_time($p); ?> 分钟</span><?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    </section>
  <?php endforeach; ?>
<?php endif; ?>

<?php if ($ng_side): ?></div><?php include theme_path('_sidebar.php'); ?></div><?php endif; ?>

<?php include partial_path('footer.php'); ?>
