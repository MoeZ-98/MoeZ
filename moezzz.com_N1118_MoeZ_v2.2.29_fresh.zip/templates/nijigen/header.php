<?php
/**
 * 二次元 · Nijigen 模板 · 公共头部
 * 在模板文件内通过 include partial_path('header.php') 引入
 */
/** @var array $site  @var array $nav_cats */
if (!defined('NG_ASSET_VER')) require_once theme_path('_lib.php');
$cur    = isset($cur_p) ? $cur_p : 'index';
$pretty = is_pretty_url();
$ng_dark = ng_opt('default_mode', 'auto');
$ng_accent = ng_opt('accent', 'sakura');
if (!in_array($ng_accent, array('sakura', 'sora', 'minto', 'hoshimi'), true)) $ng_accent = 'sakura';
/* 封面式首页开启时，站内「首页」入口带 ?enter=1，直达真正的列表页 */
$ng_is_landing = ($cur === 'landing');
$ng_home = ng_opt('landing', 'off') === 'on' && !$ng_is_landing ? ng_enter_url() : home_url();

/* 当前登录用户（前台用户中心体系） */
$ng_u = function_exists('current_user') ? current_user() : null;
$ng_u_name  = $ng_u ? (function_exists('moe_user_display') ? moe_user_display($ng_u) : $ng_u['username']) : '';
$ng_u_face  = $ng_u ? (function_exists('moe_user_avatar') ? moe_user_avatar($ng_u) : '') : '';
$ng_u_uc    = base_url() . 'user';
$ng_u_role  = $ng_u && function_exists('moe_user_role_label') ? moe_user_role_label(moe_user_role($ng_u)) : '';
$ng_reg_on  = setting('user_register', '0') === '1';
$ng_cap     = (!$ng_u && $ng_reg_on && function_exists('moe_uc_captcha')) ? moe_uc_captcha() : '';
$ng_token   = csrf_token();

/* 导航栏站点图标：支持 emoji / 图片地址，留空则用站点头像 */
$ng_nico = trim((string)ng_opt('nav_icon', ''));
/* 目录适配：附件/外链判断交给统一层，兼容 uploads/image/YYYYMM/ 分月目录 */
$ng_nico_is_img = function_exists('moe_is_media_path')
    ? moe_is_media_path($ng_nico)
    : ($ng_nico !== '' && (bool)preg_match('#^(https?:)?//|^/|^media/|^uploads/#i', $ng_nico));
$ng_navUser = ng_on('nav_user', '1');
$ng_navSearch = ng_on('nav_search', '1');
/* 自定义 Logo：图片地址 + 点击链接；都留空时保持默认「站点头像 / emoji + 站名 → 首页」 */
$ng_logo_img  = trim((string)ng_opt('logo_img', ''));
$ng_logo_url  = trim((string)ng_opt('logo_url', ''));
$ng_logo_hide = ng_on('logo_hide_name', '0');
$ng_logo_href = $ng_home;
if ($ng_logo_url !== '') {
    /* 只接受 http(s) / 协议相对 / 绝对路径，站内相对路径自动补 base_url，杜绝伪协议 */
    if (preg_match('#^(https?://|//|/)#i', $ng_logo_url)) $ng_logo_href = $ng_logo_url;
    else $ng_logo_href = base_url() . ltrim($ng_logo_url, '/');
}
/* 窄屏侧栏：默认堆在正文下方，可选「搬进抽屉」 */
$ng_side_in_dw = ng_on('drawer_side', '0');
/* 访客前台配色切换：4 套预设，选择记在 localStorage */
$ng_visitor_pal = ng_on('visitor_palette', '0');
$ng_pal_items = array(
    array('id' => 'sakura',  'name' => '樱花粉紫', 'dot' => '#ff8fb7'),
    array('id' => 'sora',    'name' => '晴空蓝紫', 'dot' => '#6fb7ff'),
    array('id' => 'minto',   'name' => '薄荷绿粉', 'dot' => '#63d8b2'),
    array('id' => 'hoshimi', 'name' => '星芒橙金', 'dot' => '#ffb36b'),
);

/* 抽屉里的导航磁贴 */
$ng_dw_items = array();
$ng_dw_items[] = array('url' => $ng_home, 'icon' => '🏠', 'name' => '首页', 'cur' => $cur === 'index');
foreach ((array)$nav_cats as $c) {
    $ng_dw_items[] = array(
        'url'  => cat_url($c),
        'icon' => '🌸',
        'name' => $c['name'],
        'cur'  => (isset($cat) && isset($c['id']) && $cat['id'] == $c['id']),
    );
}
$ng_dw_items[] = array('url' => base_url() . 'blog/article', 'icon' => '📝', 'name' => '写作', 'cur' => $cur === 'article');
$ng_dw_items[] = array('url' => base_url() . 'archives',    'icon' => '🗃', 'name' => '归档', 'cur' => $cur === 'archive');
$ng_dw_items[] = array('url' => base_url() . 'link',         'icon' => '🔗', 'name' => '友链', 'cur' => $cur === 'link');
$ng_dw_items[] = array('url' => base_url() . 'about',        'icon' => '🍀', 'name' => '关于', 'cur' => $cur === 'about');
if ($site['rss']) $ng_dw_items[] = array('url' => rss_url(), 'icon' => '📡', 'name' => 'RSS', 'cur' => false);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo seo_head(); ?>
<meta name="theme-color" content="<?php echo e(ng_theme_color()); ?>">
<?php
/* 目录适配：nijigen 历来只用主题自带图标；文件缺失时回退根 favicon.ico */
$moe_icon_ready = function_exists('moe_theme_icon') && function_exists('moe_icon_links');
$moe_icon_raw   = '';
$moe_favicon = $moe_icon_ready ? moe_theme_icon($moe_icon_raw, 'assets/avatar.svg')
                              : ($moe_icon_raw !== '' ? $moe_icon_raw : theme_url('assets/avatar.svg'));
echo $moe_icon_ready ? moe_icon_links($moe_favicon)
                     : '<link rel="icon" href="' . e($moe_favicon) . '">' . "\n";
?>
<link rel="alternate" type="application/rss+xml" title="<?php echo e($site['name']); ?>" href="<?php echo e(rss_url()); ?>">
<link rel="stylesheet" href="<?php echo e(theme_url('assets/style.css')); ?>?v=<?php echo NG_ASSET_VER; ?>">
<?php
/* 自定义配色：ng_palette_css() 已做白名单校验与标签过滤，直接作为 CSS 输出 */
$ng_pal_css = ng_palette_css();
if ($ng_pal_css !== ''): ?>
<style id="ngPaletteCss"><?php echo $ng_pal_css; ?></style>
<?php endif; ?>
<script>
/* 明暗模式：在样式应用前定好 data-theme，避免暗色用户看到白屏闪烁；手动选择优先于默认模式 */
(function () {
  var mode = <?php echo json_encode($ng_dark); ?>;
  var theme = mode === 'auto'
    ? (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
    : mode;
  try {
    var saved = localStorage.getItem('ng-theme');
    if (saved === 'light' || saved === 'dark') theme = saved;
  } catch (e) { /* 隐私模式等场景忽略 */ }
  document.documentElement.setAttribute('data-theme', theme);
})();
</script>
</head>
<body class="ng-accent-<?php echo e($ng_accent); ?><?php echo $ng_is_landing ? ' ng-landing-on' : ''; ?><?php echo $ng_side_in_dw ? ' ng-side-in-drawer' : ''; ?>" data-dark="<?php echo e($ng_dark); ?>" data-drawer-side="<?php echo $ng_side_in_dw ? '1' : '0'; ?>" data-nav-more="<?php echo ng_on('nav_more', '1') ? '1' : '0'; ?>">
<?php if ($ng_visitor_pal): ?>
<script>/* 访客上次选的配色：在内容绘制前同步套用，避免闪一下默认色 */
(function(){try{var a=localStorage.getItem('ng-accent');if(/^(sakura|sora|minto|hoshimi)$/.test(a)){document.body.className=document.body.className.replace(/\bng-accent-[a-z]+/,'ng-accent-'+a);}}catch(e){}})();
</script>
<?php endif; ?>
<?php if (ng_on('sakura', '1')): ?><canvas id="ngPetals" aria-hidden="true"></canvas><?php endif; ?>

<nav class="ng-nav" id="ngNav">
  <div class="ng-nav-inner">
    <a class="ng-logo" href="<?php echo e($ng_logo_href); ?>" title="<?php echo e($site['name']); ?>">
      <?php if ($ng_logo_img !== ''): ?>
        <img class="ng-logo-custom" src="<?php echo e(media_url($ng_logo_img)); ?>" alt="<?php echo e($site['name']); ?>"
             onerror="this.style.display='none'">
      <?php elseif ($ng_nico_is_img): ?>
        <img class="ng-logo-ico" src="<?php echo e(media_url($ng_nico)); ?>" alt=""
             onerror="this.style.display='none'">
      <?php elseif ($ng_nico !== ''): ?>
        <span class="ng-logo-emoji"><?php echo e($ng_nico); ?></span>
      <?php else: ?>
        <img src="<?php echo e(media_url($site['avatar'])); ?>" alt="" onerror="this.style.display='none'">
      <?php endif; ?>
      <span<?php echo $ng_logo_hide ? ' hidden' : ''; ?>><?php echo e($site['name']); ?></span>
    </a>
    <div class="ng-links" id="ngLinks">
      <a href="<?php echo e($ng_home); ?>" class="<?php echo $cur === 'index' ? 'cur' : ''; ?>"><i>🏠</i>首页</a>
      <?php foreach ($nav_cats as $c): ?>
        <a href="<?php echo e(cat_url($c)); ?>" class="<?php echo (isset($cat) && $cat['id'] == $c['id']) ? 'cur' : ''; ?>"><i>🌸</i><?php echo e($c['name']); ?></a>
      <?php endforeach; ?>
      <a href="<?php echo e(base_url() . 'blog/article'); ?>" class="<?php echo $cur === 'article' ? 'cur' : ''; ?>"><i>📝</i>写作</a>
      <a href="<?php echo e(base_url() . 'link'); ?>" class="<?php echo $cur === 'link' ? 'cur' : ''; ?>"><i>🔗</i>友链</a>
      <?php if ($site['rss']): ?><a href="<?php echo e(rss_url()); ?>" title="RSS 订阅"><i>📡</i>RSS</a><?php endif; ?>
    </div>
    <div class="ng-nav-right">
      <!-- 导航项放不下时，app.js 会把末尾若干项移进这里，避免最后一项被裁掉半截 -->
      <div class="ng-more" id="ngMore" hidden>
        <button class="ng-more-btn" id="ngMoreBtn" type="button" aria-label="更多导航"
                aria-expanded="false" aria-controls="ngMorePop">更多 ▾</button>
        <div class="ng-more-pop" id="ngMorePop" hidden></div>
      </div>
      <?php if (ng_on('mode_toggle', '1')): ?>
      <button class="ng-theme-btn" id="ngThemeBtn" type="button" aria-label="切换明暗模式" title="切换明暗模式">🌙</button>
      <?php endif; ?>
      <?php if ($ng_visitor_pal): ?>
      <div class="ng-palette" id="ngPaletteBox">
        <button class="ng-theme-btn" id="ngPaletteBtn" type="button" aria-label="切换站点配色"
                aria-expanded="false" aria-controls="ngPalettePop" title="切换站点配色">🎨</button>
        <div class="ng-palette-pop" id="ngPalettePop" hidden>
          <b>站点配色</b>
          <div class="ng-palette-row">
            <?php foreach ($ng_pal_items as $it): ?>
            <button type="button" class="ng-palette-item" data-accent-set="<?php echo e($it['id']); ?>" title="<?php echo e($it['name']); ?>">
              <i style="--dot:<?php echo e($it['dot']); ?>"></i><span><?php echo e($it['name']); ?></span>
            </button>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <?php endif; ?>
      <?php if ($ng_navSearch): ?>
      <form class="ng-search" action="<?php echo e(base_url() . 'index.php'); ?>" method="get"
            data-pretty="<?php echo $pretty ? '1' : '0'; ?>" data-base="<?php echo e(base_url()); ?>">
        <input type="hidden" name="p" value="search">
        <input type="text" name="q" placeholder="搜搜看…✧" value="<?php echo isset($kw) ? e($kw) : ''; ?>">
      </form>
      <?php endif; ?>
      <?php if ($ng_navUser): ?>
        <?php if ($ng_u): ?>
          <a class="ng-user-chip" href="<?php echo e($ng_u_uc); ?>" title="<?php echo e($ng_u_name); ?> · 用户中心">
            <img src="<?php echo e($ng_u_face); ?>" alt="" onerror="this.remove()">
            <span><?php echo e($ng_u_name); ?></span>
          </a>
        <?php else: ?>
          <button class="ng-auth-btn" type="button" data-auth-open="login">登录</button>
        <?php endif; ?>
      <?php endif; ?>
      <button class="ng-burger" id="ngBurger" type="button" aria-label="菜单" aria-expanded="false" aria-controls="ngDrawer">☰</button>
    </div>
  </div>
</nav>

<!-- 移动端抽屉：个人资料 + 导航网格 + 账号操作 -->
<div class="ng-drawer" id="ngDrawer" aria-hidden="true">
  <div class="ng-drawer-veil" data-dw-close></div>
  <div class="ng-drawer-panel" role="dialog" aria-label="站点菜单">
    <button class="ng-dw-x" type="button" data-dw-close aria-label="关闭菜单">✕</button>
    <div class="ng-dw-profile">
      <img class="face" src="<?php echo e($ng_u ? $ng_u_face : media_url($site['avatar'])); ?>" alt=""
           onerror="this.style.display='none'">
      <div class="meta">
        <b><?php echo e($ng_u ? $ng_u_name : $site['name']); ?></b>
        <span>
          <?php if ($ng_u): ?>
            <?php echo e($ng_u_role); ?> · 已登录
          <?php else: ?>
            <?php echo e($site['signature'] ? $site['signature'] : ($site['sub'] ? $site['sub'] : '欢迎来串门～')); ?>
          <?php endif; ?>
        </span>
      </div>
      <!-- 侧栏不再搬进抽屉后，个人资料数据仍在这里保留一份（不占额外卡片） -->
      <div class="ng-dw-stats">
        <span><b><?php echo (int)$site['stats']['posts']; ?></b><i>文章</i></span>
        <span><b><?php echo (int)$site['stats']['comments']; ?></b><i>评论</i></span>
        <span><b><?php echo e(ng_num($site['stats']['views'])); ?></b><i>浏览</i></span>
      </div>
      <?php if ($ng_u): ?>
        <a class="ng-dw-act" href="<?php echo e($ng_u_uc); ?>">用户中心</a>
      <?php else: ?>
        <button class="ng-dw-act" type="button" data-auth-open="login">登录 / 注册</button>
      <?php endif; ?>
    </div>

    <form class="ng-search ng-dw-search" action="<?php echo e(base_url() . 'index.php'); ?>" method="get"
          data-pretty="<?php echo $pretty ? '1' : '0'; ?>" data-base="<?php echo e(base_url()); ?>">
      <input type="hidden" name="p" value="search">
      <input type="text" name="q" placeholder="搜搜看…✧">
    </form>

    <div class="ng-dw-grid">
      <?php foreach ($ng_dw_items as $it): ?>
        <a class="ng-dw-tile<?php echo $it['cur'] ? ' cur' : ''; ?>" href="<?php echo e($it['url']); ?>">
          <i><?php echo e($it['icon']); ?></i><span><?php echo e($it['name']); ?></span>
        </a>
      <?php endforeach; ?>
    </div>

    <!-- 侧栏模块挂载点：手机端由 app.js 把 .ng-side-sticky 整块搬进来 -->
    <div class="ng-dw-side" id="ngDrawerSide" hidden>
      <div class="ng-dw-side-head"><span>更多内容</span></div>
      <div class="ng-dw-side-body" id="ngDrawerSideBody"></div>
    </div>

    <?php if ($ng_visitor_pal): ?>
    <div class="ng-dw-palette">
      <span>站点配色</span>
      <div class="ng-palette-row">
        <?php foreach ($ng_pal_items as $it): ?>
        <button type="button" class="ng-palette-item" data-accent-set="<?php echo e($it['id']); ?>" title="<?php echo e($it['name']); ?>">
          <i style="--dot:<?php echo e($it['dot']); ?>"></i><span><?php echo e($it['name']); ?></span>
        </button>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <div class="ng-dw-foot">
      <?php if (ng_on('mode_toggle', '1')): ?>
        <button class="ng-dw-mini" type="button" data-theme-toggle>🌓 切换明暗</button>
      <?php endif; ?>
      <?php if ($ng_u): ?>
        <form method="post" action="<?php echo e($ng_u_uc); ?>" class="ng-dw-logout">
          <input type="hidden" name="_token" value="<?php echo e($ng_token); ?>">
          <input type="hidden" name="act" value="logout">
          <button class="ng-dw-mini" type="submit">🚪 退出登录</button>
        </form>
      <?php else: ?>
        <a class="ng-dw-mini" href="<?php echo e(base_url() . 'admin/login.php'); ?>" rel="nofollow">🛠 后台登录</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php if (!$ng_u): ?>
<!-- 前台登录 / 注册弹窗（提交到用户中心，失败时原地提示） -->
<div class="ng-modal" id="ngAuth" aria-hidden="true" data-auth-url="<?php echo e($ng_u_uc); ?>"
     data-cap-url="<?php echo e($ng_u_uc . '?a=register'); ?>">
  <div class="ng-modal-veil" data-auth-close></div>
  <div class="ng-modal-card" role="dialog" aria-modal="true" aria-label="登录或注册">
    <button class="ng-modal-x" type="button" data-auth-close aria-label="关闭">✕</button>
    <div class="ng-auth-brand">
      <img src="<?php echo e(media_url($site['avatar'])); ?>" alt="" onerror="this.style.display='none'">
      <div>
        <b><?php echo e($site['name']); ?></b>
        <small><?php echo e($site['signature'] ? $site['signature'] : '登录后评论会自动带上你的昵称和头像 ✧'); ?></small>
      </div>
    </div>

    <div class="ng-auth-tabs<?php echo $ng_reg_on ? '' : ' no-reg'; ?>">
      <button type="button" class="cur" data-auth-tab="login">登录</button>
      <?php if ($ng_reg_on): ?><button type="button" data-auth-tab="register">注册</button><?php endif; ?>
    </div>

    <form class="ng-auth-form" data-auth-act="login" method="post" action="<?php echo e($ng_u_uc); ?>">
      <input type="hidden" name="_token" value="<?php echo e($ng_token); ?>">
      <input type="hidden" name="act" value="login">
      <label class="ng-field">
        <span>用户名 / 邮箱</span>
        <input type="text" name="username" required autocomplete="username" placeholder="请输入用户名或邮箱">
      </label>
      <label class="ng-field">
        <span>密码</span>
        <input type="password" name="password" required autocomplete="current-password" placeholder="请输入密码">
      </label>
      <button class="ng-btn ng-auth-submit" type="submit">登 录</button>
      <p class="ng-auth-tip">
        <?php if ($ng_reg_on): ?>还没有账号？<a href="#" data-auth-tab="register">立即注册 →</a><?php else: ?>本站暂未开放注册<?php endif; ?>
      </p>
    </form>

    <?php if ($ng_reg_on): ?>
    <form class="ng-auth-form" data-auth-act="register" method="post" action="<?php echo e($ng_u_uc); ?>" hidden>
      <input type="hidden" name="_token" value="<?php echo e($ng_token); ?>">
      <input type="hidden" name="act" value="register">
      <div class="ng-field-row">
        <label class="ng-field">
          <span>用户名 *</span>
          <input type="text" name="username" required maxlength="32" placeholder="2~32 位，中文/字母/数字">
        </label>
        <label class="ng-field">
          <span>昵称</span>
          <input type="text" name="nickname" maxlength="30" placeholder="留空用用户名">
        </label>
      </div>
      <label class="ng-field">
        <span>邮箱（选填）</span>
        <input type="email" name="email" placeholder="用于找回账号与通知">
      </label>
      <div class="ng-field-row">
        <label class="ng-field">
          <span>密码 *</span>
          <input type="password" name="password" required minlength="6" autocomplete="new-password" placeholder="至少 6 位">
        </label>
        <label class="ng-field">
          <span>确认密码 *</span>
          <input type="password" name="password2" required minlength="6" autocomplete="new-password" placeholder="再输一次">
        </label>
      </div>
      <label class="ng-field">
        <span>验算：<b><?php echo e($ng_cap); ?></b></span>
        <input type="text" name="captcha" required inputmode="numeric" placeholder="请输入计算结果">
      </label>
      <button class="ng-btn ng-auth-submit" type="submit">注 册</button>
      <p class="ng-auth-tip">已有账号？<a href="#" data-auth-tab="login">去登录 →</a></p>
    </form>
    <?php endif; ?>

    <p class="ng-auth-msg" role="status" aria-live="polite"></p>
  </div>
</div>
<?php endif; ?>

<?php if ($ng_is_landing): ?><main class="ng-landing-main"><?php else: ?><main class="ng-container"><?php endif; ?>