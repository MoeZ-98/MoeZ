<?php
/**
 * Nijigen 模板 · 文章详情页
 * 可用变量：$post $cat $prev $next $comments $site $nav_cats
 */
$page_title = $post['title'];
$cur_p = 'post';
include partial_path('header.php');
$ng_cdf = ng_comment_defaults();

/* 底部版权卡片文案 */
$ng_copy_txt = trim((string)ng_opt('post_copy_text', ''));
if ($ng_copy_txt === '') $ng_copy_txt = '本文为原创内容，转载请保留原文链接并注明出处。';
$ng_author = !empty($site['author']) ? $site['author'] : $site['name'];
?>

<?php $ng_side = ng_side_on(); ?>
<?php if ($ng_side): ?><div class="ng-layout"><div class="ng-main"><?php endif; ?>

<div class="ng-article-wrap">
  <article class="ng-article">
    <header class="ng-article-header">
      <?php if ($cat): ?>
        <a class="ng-chip" href="<?php echo e(cat_url($cat)); ?>"><?php echo e($cat['name']); ?></a>
      <?php endif; ?>
      <h1><?php echo e($post['title']); ?></h1>
      <div class="meta">
        <span>📅 <?php echo e(format_time($post['created_at'], 'Y-m-d')); ?></span>
        <?php if (!empty($post['updated_at']) && substr($post['updated_at'], 0, 10) !== substr($post['created_at'], 0, 10)): ?>
          <span>🔄 更新于 <?php echo e(format_time($post['updated_at'], 'Y-m-d')); ?></span>
        <?php endif; ?>
        <span>👀 <?php echo (int)$post['views']; ?> 次阅读</span>
        <span>⏱ 约 <?php echo reading_time($post); ?> 分钟</span>
        <?php if ($site['author']): ?><span>✍️ <?php echo e($site['author']); ?></span><?php endif; ?>
      </div>
    </header>

    <div class="md-body">
      <?php echo render_content($post['content'], isset($post['content_format']) ? $post['content_format'] : 'html'); ?>
    </div>

    <?php $ng_tags = ng_tags($post, 8); if ($ng_tags): ?>
    <div class="article-tags">
      <?php foreach ($ng_tags as $ng_t): ?>
        <span class="ng-tag">#<?php echo e($ng_t); ?></span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (ng_on('post_copy', '1')): ?>
    <div class="ng-copyright">
      <div class="ng-copy-head">
        <span class="ng-copy-ico">©</span>
        <b>版权声明</b>
        <span class="ng-copy-tag">原创内容</span>
      </div>
      <dl class="ng-copy-list">
        <dt>文章</dt><dd><?php echo e($post['title']); ?></dd>
        <dt>作者</dt><dd><?php echo e($ng_author); ?></dd>
        <?php if ($post['slug']): ?><dt>链接</dt><dd><code class="ng-copy-url"><?php echo e(post_url($post)); ?></code></dd><?php endif; ?>
        <dt>声明</dt><dd><?php echo e($ng_copy_txt); ?></dd>
      </dl>
    </div>
    <?php endif; ?>
  </article>

  <?php if ($prev || $next): ?>
  <nav class="ng-post-nav">
    <?php if ($prev): $ng_pc = ng_cover($prev); ?>
      <a class="pn-card pn-prev" href="<?php echo e(post_url($prev)); ?>" style="--pn-grad:<?php echo e($ng_pc['style']); ?>">
        <?php if ($ng_pc['url'] !== ''): ?><span class="pn-bg" style="background-image:url('<?php echo e($ng_pc['url']); ?>')" aria-hidden="true"></span><?php endif; ?>
        <span class="pn-lab">← 上一篇</span>
        <span class="pn-title"><?php echo e($prev['title']); ?></span>
      </a>
    <?php endif; ?>
    <?php if ($next): $ng_nc = ng_cover($next); ?>
      <a class="pn-card pn-next" href="<?php echo e(post_url($next)); ?>" style="--pn-grad:<?php echo e($ng_nc['style']); ?>">
        <?php if ($ng_nc['url'] !== ''): ?><span class="pn-bg" style="background-image:url('<?php echo e($ng_nc['url']); ?>')" aria-hidden="true"></span><?php endif; ?>
        <span class="pn-lab">下一篇 →</span>
        <span class="pn-title"><?php echo e($next['title']); ?></span>
      </a>
    <?php endif; ?>
  </nav>
  <?php endif; ?>

  <?php include theme_path('_post_cats.php'); ?>

  <section class="ng-comments">
    <h2>💬 评论（<?php echo count($comments); ?>）</h2>

    <?php if (setting('comment_enabled', '1') === '1'): ?>
      <form class="ng-form ng-cm-form" id="cform" method="post" action="<?php echo e(base_url() . 'comment.php'); ?>">
        <input type="hidden" name="post_id" value="<?php echo (int)$post['id']; ?>">
        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
        <h3>✏️ 发表评论</h3>
        <div class="ng-cm-reply-tip" id="creplyTip" hidden>
          <span>正在回复 <b id="creplyName"></b></span>
          <button type="button" id="creplyCancel" aria-label="取消回复">✕</button>
        </div>
        <div class="row">
          <input type="text" name="author" placeholder="昵称 *" maxlength="30" required value="<?php echo e($ng_cdf['author']); ?>">
          <input type="email" name="email" placeholder="邮箱（选填，不会公开）" value="<?php echo e($ng_cdf['email']); ?>">
        </div>
        <?php if (!empty($ng_cdf['admin'])): ?><p class="hint">👋 站长已登录，已自动填入你的信息</p><?php endif; ?>
        <textarea name="content" placeholder="说点什么吧～（支持 1000 字以内）" maxlength="1000" required></textarea>
        <div style="margin-top:14px;text-align:right">
          <button class="ng-btn" type="submit" id="csubmit">🚀 发射评论</button>
        </div>
        <p id="cmsg" style="font-size:13px;margin-top:10px;display:none"></p>
      </form>
      <script>
      (function () {
        var f = document.getElementById('cform');
        if (!f) return;
        f.addEventListener('submit', function (e) {
          e.preventDefault();
          var btn = document.getElementById('csubmit'), msg = document.getElementById('cmsg');
          btn.disabled = true; btn.textContent = '发射中…';
          fetch(f.action, { method: 'POST', body: new FormData(f) })
            .then(function (r) { return r.json(); })
            .then(function (d) {
              msg.style.display = 'block';
              msg.style.color = d.ok ? '#3fb984' : '#e0566b';
              msg.textContent = d.msg;
              if (d.ok) setTimeout(function () { location.reload(); }, 900);
              else { btn.disabled = false; btn.textContent = '🚀 发射评论'; }
            })
            .catch(function () {
              msg.style.display = 'block'; msg.style.color = '#e0566b';
              msg.textContent = '网络开小差了，请重试';
              btn.disabled = false; btn.textContent = '🚀 发射评论';
            });
        });
      })();
      </script>
    <?php else: ?>
      <div class="ng-empty" style="padding:30px"><p>评论区暂时关闭啦～</p></div>
    <?php endif; ?>

    <!-- 已发布评论：放在评论框下方，带边框卡片 -->
    <div class="ng-cm-list">
      <div class="ng-cm-list-head">
        <b>全部评论</b>
        <span><?php echo count($comments); ?> 条</span>
      </div>
      <?php if (!empty($comments)): ?>
        <?php foreach ($comments as $c): $ng_cu = ng_cmt_user($c); ?>
          <div class="ng-comment-item">
            <span class="ng-av" style="--av-h:<?php echo (int)$ng_cu['hue']; ?>">
              <span class="ng-av-l"><?php echo e($ng_cu['letter']); ?></span>
              <?php if ($ng_cu['avatar'] !== ''): ?>
                <img src="<?php echo e($ng_cu['avatar']); ?>" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.remove()">
              <?php endif; ?>
            </span>
            <div class="c-body">
              <div class="c-head">
                <b><?php echo e($ng_cu['name']); ?></b>
                <?php if ($ng_cu['admin']): ?><span class="ng-c-badge is-admin">站长</span><?php endif; ?>
                <time><?php echo e(nice_time($c['created_at'])); ?></time>
                <?php
                $ng_cloc = function_exists('moe_comment_loc') ? moe_comment_loc($c) : (isset($c['location']) ? trim((string)$c['location']) : '');
                $ng_cua  = function_exists('moe_ua_info') && isset($c['ua']) ? moe_ua_info($c['ua']) : '';
                ?>
                <?php if ($ng_cloc !== ''): ?><span class="ng-c-badge"><?php echo e($ng_cloc); ?></span><?php endif; ?>
                <?php if ($ng_cua !== ''): ?><span class="ng-c-badge ng-c-badge-soft"><?php echo e($ng_cua); ?></span><?php endif; ?>
              </div>
              <div class="c-text"><?php
                $ng_ctext = isset($c['content']) ? (string)$c['content'] : '';
                $ng_ctext = e($ng_ctext);
                // 开头的 @昵称 高亮显示（回复功能会把被回复者写在正文最前）
                $ng_ctext = preg_replace('/^@([^\s<>：:，,]{1,24}) ?/u', '<span class="ng-at">@$1</span> ', $ng_ctext, 1);
                echo nl2br($ng_ctext);
              ?></div>
              <?php if (setting('comment_enabled', '1') === '1'): ?>
              <div class="c-foot">
                <button class="ng-cm-reply" type="button" data-reply="<?php echo e($ng_cu['name']); ?>">↩ 回复</button>
              </div>
              <?php endif; ?>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p class="ng-cm-empty">还没有评论，来抢沙发吧～</p>
      <?php endif; ?>
    </div>
  </section>
</div>

<?php if ($ng_side): ?></div><?php include theme_path('_sidebar.php'); ?></div><?php endif; ?>

<?php include partial_path('footer.php'); ?>
