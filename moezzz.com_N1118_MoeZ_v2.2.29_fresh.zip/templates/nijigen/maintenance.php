<?php
/** Nijigen 模板 · 维护模式页 */
$site_name = function_exists('setting') ? setting('site_name', 'MoeZ') : 'MoeZ';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>站点维护中 · <?php echo e($site_name); ?></title>
<meta name="robots" content="noindex">
<style>
body { margin:0; min-height:100vh; display:flex; align-items:center; justify-content:center;
  font-family:"PingFang SC","Microsoft YaHei",sans-serif; text-align:center; color:#43324d;
  background:linear-gradient(135deg,#fdf4f9,#f2effc); }
.box { max-width:420px; padding:40px 30px; }
.big { font-size:56px; display:block; margin-bottom:12px; }
h1 { font-size:22px; margin:0 0 10px; }
p { color:#9a8aa6; margin:0 0 24px; font-size:14px; }
a { display:inline-block; padding:10px 26px; border-radius:999px; color:#fff; text-decoration:none;
  background:linear-gradient(135deg,#ff8fb7,#a78bfa); font-size:14px; font-weight:600; }
</style>
</head>
<body>
<div class="box">
  <span class="big">🛠️(๑•́ ₃ •̀๑)</span>
  <h1>站点正在维护中…</h1>
  <p>正在给小站换新装，马上回来～</p>
  <a href="javascript:location.reload()">刷新看看</a>
</div>
</body>
</html>
