<?php
/**
 * 二次元 · Nijigen 模板 · 公共底部
 * 结构：友链区块（可选）→ 页脚（附加内容 / 版权 / 备案（可选）/ credit）
 * 1.7.0：页脚回到最初的简洁版本（社交胶囊 / 建站运行 / 云服务说明已移除）
 */
$ng_links = array();
try {
    foreach (rows('SELECT * FROM ' . moe_table('links') . ' ORDER BY sort, id') as $l) {
        if (!isset($l['status']) || $l['status'] === 'approved') $ng_links[] = $l;
    }
} catch (Throwable $e) { /* 表未就绪时静默跳过 */ }

/* 备案信息：完全可选，两项都留空时页脚与初始版本一模一样 */
$ng_icp    = trim((string)ng_opt('footer_icp', ''));
$ng_police = trim((string)ng_opt('footer_police', ''));
$ng_police_code = preg_match('/(\d{6,})/', $ng_police, $m) ? $m[1] : '';
$ng_police_url  = $ng_police_code !== ''
    ? 'https://beian.mps.gov.cn/#/query/webSearch?code=' . $ng_police_code
    : 'https://beian.mps.gov.cn/';
?>
</main>

<?php if (!(isset($cur_p) && $cur_p === 'landing')): ?>
<?php if (!empty($ng_links) && ng_on('show_links', '1') && !(isset($hide_links) && $hide_links)): ?>
<section class="ng-container ng-links-sec">
  <div class="ng-sec-title">
    <h2><i>🔗</i>友情链接</h2>
    <a class="ng-more" href="<?php echo e(base_url() . 'link'); ?>">全部友链 →</a>
  </div>
  <div class="ng-links-grid">
    <?php foreach ($ng_links as $l): ?>
      <?php
        $ico = function_exists('link_icon') ? link_icon($l) : '';
        $ld  = function_exists('link_desc') ? link_desc($l) : '';
        $sub = $ld !== '' ? $ld : ('🔗 ' . (parse_url($l['url'], PHP_URL_HOST) ?: $l['url']));
      ?>
      <a class="ng-link-card" href="<?php echo e($l['url']); ?>" target="_blank" rel="noopener nofollow" title="<?php echo e($l['name']); ?>">
        <span class="face">
          <?php if ($ico !== ''): ?>
            <img src="<?php echo e($ico); ?>" alt="<?php echo e(initial($l['name'])); ?>" loading="lazy"
                 onerror="this.parentNode.textContent=this.alt">
          <?php else: ?>
            <?php echo e(initial($l['name'])); ?>
          <?php endif; ?>
        </span>
        <span class="info">
          <b><?php echo e($l['name']); ?></b>
          <span><?php echo e($sub); ?></span>
        </span>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<footer class="ng-footer">
  <div class="ng-container">
    <?php if (trim((string)ng_opt('footer_extra', '')) !== ''): ?>
      <div class="ng-footer-extra"><?php echo ng_opt('footer_extra', ''); ?></div>
    <?php endif; ?>
    <p><?php echo $site['footer'] ? e($site['footer']) : '© ' . date('Y') . ' ' . e($site['name']); ?></p>
    <?php if ($ng_icp !== '' || $ng_police !== ''): ?>
    <p class="ng-footer-legal">
      <?php if ($ng_icp !== ''): ?><a href="https://beian.miit.gov.cn/" target="_blank" rel="noopener nofollow"><?php echo e($ng_icp); ?></a><?php endif; ?>
      <?php if ($ng_police !== ''): ?><a href="<?php echo e($ng_police_url); ?>" target="_blank" rel="noopener nofollow"><?php echo e($ng_police); ?></a><?php endif; ?>
    </p>
    <?php endif; ?>
    <p class="ng-footer-sub">✧ Made with <span class="heart">♥</span> · MoeZ v<?php echo MOE_VERSION; ?> ✧</p>
  </div>
</footer>
<?php endif; ?>

<button class="ng-backtop" id="ngBackTop" title="返回顶部" aria-label="返回顶部">🚀</button>

<script src="<?php echo e(theme_url('assets/app.js')); ?>?v=<?php echo NG_ASSET_VER; ?>" defer></script>
</body>
</html>
