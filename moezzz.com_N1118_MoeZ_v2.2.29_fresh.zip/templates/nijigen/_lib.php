<?php
/**
 * 二次元 · Nijigen 模板 · 公共函数库
 * 只在模板内部使用，全部函数带 ng_ 前缀，避免与程序核心冲突。
 */

/** 主题资源版本号：升级主题后用于刷新 style.css / app.js 缓存 */
if (!defined('NG_ASSET_VER')) define('NG_ASSET_VER', '1.9.1');

/** 读取模板设置（带兜底默认值） */
if (!function_exists('ng_opt')) {
    function ng_opt($key, $default = '')
    {
        return theme_opt($key, $default);
    }
}

/** 布尔开关：'1' 视为开启 */
if (!function_exists('ng_on')) {
    function ng_on($key, $default = '1')
    {
        return theme_opt($key, $default) === '1';
    }
}

/**
 * 前端配色：把「模板设置 → 前端配色」里的自定义颜色编译成一小段 CSS 变量覆盖。
 * - 只接受 #RGB / #RRGGBB / #RRGGBBAA，等于推荐色或留空 = 跟随预设，不输出；
 * - 亮色 / 暗色分开输出，自定义亮色不会破坏暗黑模式；
 * - 自定义 CSS 独立生效，输出前去掉尖括号与 @import / javascript url，避免注入。
 */
if (!function_exists('ng_palette_css')) {
    function ng_palette_css()
    {
        $read = function ($map) {
            $out = array();
            foreach ($map as $key => $def) {
                $v = strtolower(trim((string)ng_opt($key, '')));
                if ($v === '' || $v === $def[1]) continue;      // 未改 = 跟随预设
                if (!preg_match('/^#[0-9a-f]{3}(?:[0-9a-f]{3})?(?:[0-9a-f]{2})?$/', $v)) continue;
                $out[$def[0]] = $v;
            }
            return $out;
        };
        $decl = function ($vars) {
            $s = '';
            foreach ($vars as $k => $v) $s .= $k . ':' . $v . ';';
            return $s;
        };

        $css = '';
        if (ng_on('palette_on', '0')) {
            $both = $read(array(
                'palette_a1'       => array('--ng-a1', '#ff8fb7'),
                'palette_a2'       => array('--ng-a2', '#a78bfa'),
                'palette_a3'       => array('--ng-a3', '#7cc7ff'),
                'palette_hero_ink' => array('--ng-hero-ink', '#ffffff'),
            ));
            $light = $read(array(
                'palette_link'  => array('--link', '#e0568c'),
                'palette_ink'   => array('--ink', '#43324d'),
                'palette_muted' => array('--muted', '#9a8aa6'),
                'palette_bg'    => array('--bg', '#fdf4f9'),
                'palette_bg2'   => array('--bg2', '#f2effc'),
                'palette_card'  => array('--card-solid', '#ffffff'),
            ));
            $dark = $read(array(
                'palette_dark_bg'   => array('--bg', '#17121f'),
                'palette_dark_card' => array('--card-solid', '#2b213a'),
                'palette_dark_ink'  => array('--ink', '#ece5f3'),
                'palette_dark_link' => array('--link', '#ff9fbe'),
            ));

            /* 三主色任一被改：连带重算渐变、光晕、描边、阴影与横幅浅色渐变 */
            if (isset($both['--ng-a1']) || isset($both['--ng-a2']) || isset($both['--ng-a3'])) {
                $both['--ng-grad']     = 'linear-gradient(135deg, var(--ng-a1), var(--ng-a2) 55%, var(--ng-a3))';
                $both['--ng-hero-a1']  = 'color-mix(in srgb, var(--ng-a1) 45%, #fff)';
                $both['--ng-hero-a2']  = 'color-mix(in srgb, var(--ng-a2) 42%, #fff)';
                $both['--ng-hero-a3']  = 'color-mix(in srgb, var(--ng-a3) 45%, #fff)';
                $both['--ng-glow1']    = 'color-mix(in srgb, var(--ng-a1) 32%, transparent)';
                $both['--ng-glow2']    = 'color-mix(in srgb, var(--ng-a2) 28%, transparent)';
                $both['--line']        = 'color-mix(in srgb, var(--ng-a1) 16%, transparent)';
                $both['--shadow']      = '0 10px 30px color-mix(in srgb, var(--ng-a1) 14%, transparent)';
            }
            if ($light && isset($light['--card-solid'])) {
                $light['--card'] = 'color-mix(in srgb, ' . $light['--card-solid'] . ' 82%, transparent)';
            }
            if ($dark && isset($dark['--card-solid'])) {
                $dark['--card'] = 'color-mix(in srgb, ' . $dark['--card-solid'] . ' 82%, transparent)';
            }
            if ($both)  $css .= 'body{' . $decl($both) . '}';
            /* 兼容 JS 被禁用、data-theme 尚未写入的情况：默认按亮色处理 */
            if ($light) $css .= 'html[data-theme="light"] body, html:not([data-theme]) body{' . $decl($light) . '}';
            if ($dark)  $css .= 'html[data-theme="dark"] body{' . $decl($dark) . '}';
        }

        $extra = trim((string)ng_opt('palette_css', ''));
        if ($extra !== '') {
            $extra = preg_replace('/@import[^;]*;/i', '', $extra);
            $extra = preg_replace('/url\(\s*["\']?\s*javascript:[^)]*\)/i', '', $extra);
            $extra = str_replace(array('<', '>'), '', $extra);   // 杜绝 </style> 提前闭合
            $extra = trim($extra);
            if ($extra !== '') $css .= "\n" . $extra;
        }
        return $css;
    }
}

/** 手机浏览器顶栏颜色：自定义主色 > 预设主色 */
if (!function_exists('ng_theme_color')) {
    function ng_theme_color()
    {
        $preset = array('sakura' => '#ff8fb7', 'sora' => '#6fb7ff', 'minto' => '#63d8b2', 'hoshimi' => '#ffb36b');
        $accent = ng_opt('accent', 'sakura');
        $color = isset($preset[$accent]) ? $preset[$accent] : $preset['sakura'];
        if (ng_on('palette_on', '0')) {
            $v = strtolower(trim((string)ng_opt('palette_a1', '')));
            if (preg_match('/^#[0-9a-f]{6}$/', $v)) $color = $v;
        }
        return $color;
    }
}

/** 文章封面：返回 array('url' => 图片地址, 'style' => 渐变兜底) */
if (!function_exists('ng_cover')) {
    function ng_cover($post)
    {
        $cover = function_exists('post_cover') ? post_cover($post) : (isset($post['cover']) ? $post['cover'] : '');
        $seed = isset($post['id']) ? (int)$post['id'] : 0;
        /* 无封面时的柔和渐变：由主题三色派生，换配色时占位图一起换色 */
        $c1 = 'color-mix(in srgb, var(--ng-a1) 24%, #fff)';
        $c2 = 'color-mix(in srgb, var(--ng-a2) 20%, #fff)';
        $c3 = 'color-mix(in srgb, var(--ng-a3) 24%, #fff)';
        $list = array(
            'linear-gradient(135deg,' . $c1 . ' 0%,' . $c2 . ' 50%,' . $c3 . ' 100%)',
            'linear-gradient(120deg,' . $c3 . ' 0%,' . $c1 . ' 48%,' . $c2 . ' 100%)',
            'linear-gradient(160deg,' . $c2 . ' 0%,' . $c3 . ' 45%,' . $c1 . ' 100%)',
            'linear-gradient(100deg,' . $c1 . ' 0%,' . $c3 . ' 52%,' . $c2 . ' 100%)',
            'linear-gradient(145deg,' . $c3 . ' 0%,' . $c2 . ' 50%,' . $c1 . ' 100%)',
            'linear-gradient(125deg,' . $c2 . ' 0%,' . $c1 . ' 55%,' . $c3 . ' 100%)',
        );
        return array('url' => $cover !== '' ? media_url($cover) : '', 'style' => $list[abs($seed) % count($list)]);
    }
}

/** 封面图标签：无图时不输出，由外层渐变占位；加载失败自动移除 */
if (!function_exists('ng_cover_img')) {
    function ng_cover_img($url, $eager = false)
    {
        if ((string)$url === '') return '';
        return '<img class="ng-cover-img" src="' . e($url) . '" alt="" '
            . ($eager ? 'fetchpriority="high"' : 'loading="lazy"') . ' decoding="async"'
            . ' onerror="this.remove()">';
    }
}

/** 文章标签：取「SEO 关键词」字段，中英文逗号 / 空格分隔 */
if (!function_exists('ng_tags')) {
    function ng_tags($post, $limit = 4)
    {
        $raw = isset($post['seo_keywords']) ? (string)$post['seo_keywords'] : '';
        if ($raw === '' && isset($post['tags'])) $raw = (string)$post['tags'];
        $parts = preg_split('/[,，、\s]+/u', $raw);
        $out = array();
        foreach ((array)$parts as $p) {
            $p = trim($p);
            if ($p === '' || ng_strlen($p) > 12) continue;
            if (!in_array($p, $out, true)) $out[] = $p;
            if (count($out) >= $limit) break;
        }
        return $out;
    }
}

/** 字符长度 / 截取：mbstring 未安装时退回 UTF-8 正则 */
if (!function_exists('ng_strlen')) {
    function ng_strlen($s)
    {
        $s = (string)$s;
        if (function_exists('mb_strlen')) return mb_strlen($s, 'UTF-8');
        return preg_match_all('/./us', $s, $m) ? count($m[0]) : strlen($s);
    }
}
if (!function_exists('ng_substr')) {
    function ng_substr($s, $start, $len = null)
    {
        $s = (string)$s;
        if (function_exists('mb_substr')) return $len === null ? mb_substr($s, $start, null, 'UTF-8') : mb_substr($s, $start, $len, 'UTF-8');
        preg_match_all('/./us', $s, $m);
        $chars = isset($m[0]) ? $m[0] : array();
        $slice = $len === null ? array_slice($chars, $start) : array_slice($chars, $start, $len);
        return implode('', $slice);
    }
}

/** 评论数（查询失败返回 0，不阻断页面渲染） */
if (!function_exists('ng_comments')) {
    function ng_comments($postId)
    {
        try {
            return function_exists('post_comment_count') ? (int)post_comment_count($postId) : 0;
        } catch (Throwable $e) {
            return 0;
        }
    }
}

/** 数字缩写：33900 → 3.4w */
if (!function_exists('ng_num')) {
    function ng_num($n)
    {
        $n = (int)$n;
        if ($n >= 10000) return round($n / 10000, 1) . 'w';
        if ($n >= 1000) return round($n / 1000, 1) . 'k';
        return (string)$n;
    }
}

/** 首页·分类卡片：分类 + 文章数 + 该分类最新一篇的封面（表结构不符时逐级降级） */
if (!function_exists('ng_cat_cards')) {
    function ng_cat_cards($limit = 8, $excludeId = 0)
    {
        $cTbl = moe_table('categories');
        $pTbl = moe_table('posts');
        $lim  = max(1, (int)$limit);
        $ex   = (int)$excludeId;
        $exW  = $ex > 0 ? " WHERE c.id<>{$ex} " : ' ';
        $try  = array(
            "SELECT c.id, c.name, c.slug, c.description, c.link,"
            . " (SELECT COUNT(*) FROM {$pTbl} p WHERE p.category_id=c.id AND p.type='post' AND p.status='published') AS n,"
            . " (SELECT p2.cover FROM {$pTbl} p2 WHERE p2.category_id=c.id AND p2.type='post' AND p2.status='published' AND p2.cover<>'' ORDER BY p2.id DESC LIMIT 1) AS cover"
            . " FROM {$cTbl} c{$exW}ORDER BY c.sort, c.id LIMIT {$lim}",
            "SELECT c.id, c.name, c.slug, c.description, c.link,"
            . " (SELECT COUNT(*) FROM {$pTbl} p WHERE p.category_id=c.id) AS n"
            . " FROM {$cTbl} c{$exW}ORDER BY c.id LIMIT {$lim}",
            "SELECT * FROM {$cTbl} c{$exW}ORDER BY c.id LIMIT {$lim}",
        );
        foreach ($try as $sql) {
            try {
                $r = rows($sql);
                if (is_array($r) && $r) {
                    foreach ($r as $k => $c) {
                        if (!isset($c['n']))           $r[$k]['n'] = null;
                        if (!isset($c['cover']))       $r[$k]['cover'] = '';
                        if (!isset($c['description'])) $r[$k]['description'] = '';
                        if (!isset($c['link']))        $r[$k]['link'] = '';
                    }
                    return $r;
                }
            } catch (Throwable $e) { /* 试下一条 */ }
        }
        return array();
    }
}

/** 文章页·分类聚合：每个分类挂上它最新的 N 篇（分类过多/无文章自动跳过，异常静默降级） */
if (!function_exists('ng_cat_groups')) {
    function ng_cat_groups($numCats = 3, $perCat = 3, $excludeId = 0)
    {
        $cats = ng_cat_cards(max(1, (int)$numCats), $excludeId);
        if (!$cats) return array();
        $pTbl = moe_table('posts');
        $per  = max(1, (int)$perCat);
        $out  = array();
        foreach ($cats as $c) {
            $cid = (int)(isset($c['id']) ? $c['id'] : 0);
            if ($cid <= 0) continue;
            $try = array(
                "SELECT * FROM {$pTbl} WHERE category_id={$cid} AND type='post' AND status='published' ORDER BY id DESC LIMIT {$per}",
                "SELECT * FROM {$pTbl} WHERE category_id={$cid} ORDER BY id DESC LIMIT {$per}",
            );
            $posts = array();
            foreach ($try as $sql) {
                try {
                    $r = rows($sql);
                    if (is_array($r)) { $posts = $r; break; }
                } catch (Throwable $e) { /* 试下一条 */ }
            }
            if (!$posts) continue;
            $c['posts'] = $posts;
            $out[] = $c;
        }
        return $out;
    }
}

/** 侧栏开关（模板设置 sidebar：on/off） */
if (!function_exists('ng_side_on')) {
    function ng_side_on()
    {
        return ng_opt('sidebar', 'on') === 'on';
    }
}

/** 侧栏·热门文章：按浏览量取前 N 篇；状态列不存在时自动降级为不过滤 */
if (!function_exists('ng_side_hot')) {
    function ng_side_hot($limit = 6)
    {
        $tbl  = moe_table('posts');
        $lim  = (int)$limit;
        $try  = array(
            "SELECT * FROM {$tbl} WHERE status='published' ORDER BY views DESC, id DESC LIMIT {$lim}",
            "SELECT * FROM {$tbl} ORDER BY views DESC, id DESC LIMIT {$lim}",
        );
        foreach ($try as $sql) {
            try {
                $r = rows($sql);
                if (is_array($r)) return $r;
            } catch (Throwable $e) { /* 列不存在则尝试下一条 */ }
        }
        return array();
    }
}

/** 侧栏·分类目录：按 category_id 聚合文章数挂到导航分类上（保留外链/页面型条目，查不到计数就不显示） */
if (!function_exists('ng_side_cats')) {
    function ng_side_cats($limit = 10, $fallback = array())
    {
        $map = array();
        try {
            foreach (rows('SELECT category_id, COUNT(*) AS n FROM ' . moe_table('posts') . " WHERE type='post' AND status='published' GROUP BY category_id") as $r) {
                $map[(int)$r['category_id']] = (int)$r['n'];
            }
        } catch (Throwable $e) { /* 查询失败则全部不显示计数 */ }
        $out = array();
        foreach ((array)$fallback as $c) {
            $cid = isset($c['id']) ? (int)$c['id'] : 0;
            $c['n'] = isset($map[$cid]) ? $map[$cid] : null;
            $out[] = $c;
            if (count($out) >= (int)$limit) break;
        }
        return $out;
    }
}

/** 侧栏·最新评论：取已通过的最新 N 条，任何异常都静默返回空 */
if (!function_exists('ng_side_comments')) {
    function ng_side_comments($limit = 5)
    {
        try {
            $r = rows('SELECT * FROM ' . moe_table('comments') . " WHERE status='approved' ORDER BY id DESC LIMIT " . (int)$limit);
            return is_array($r) ? $r : array();
        } catch (Throwable $e) {
            return array();
        }
    }
}

/** 侧栏·标签云：聚合最近 40 篇文章的关键词，按出现频次排序 */
if (!function_exists('ng_side_tags')) {
    function ng_side_tags($limit = 14)
    {
        $ps = array();
        try {
            $ps = rows('SELECT seo_keywords FROM ' . moe_table('posts') . " WHERE status='published' ORDER BY created_at DESC LIMIT 40");
        } catch (Throwable $e) {
            try {
                $ps = rows('SELECT seo_keywords FROM ' . moe_table('posts') . ' ORDER BY created_at DESC LIMIT 40');
            } catch (Throwable $e2) { $ps = array(); }
        }
        $freq = array();
        foreach ((array)$ps as $p) {
            foreach (ng_tags($p, 6) as $t) {
                $freq[$t] = (isset($freq[$t]) ? $freq[$t] : 0) + 1;
            }
        }
        arsort($freq);
        return array_slice($freq, 0, (int)$limit, true);
    }
}

/** 侧栏·友链精选：复用页脚同款过滤逻辑，取前 N 条 */
if (!function_exists('ng_side_links')) {
    function ng_side_links($limit = 5)
    {
        $out = array();
        try {
            foreach (rows('SELECT * FROM ' . moe_table('links') . ' ORDER BY sort, id') as $l) {
                if (!isset($l['status']) || $l['status'] === 'approved') $out[] = $l;
                if (count($out) >= (int)$limit) break;
            }
        } catch (Throwable $e) { /* 表未就绪时静默跳过 */ }
        return $out;
    }
}

/** 昵称 → 头像底色色相（同一个人始终同色） */
if (!function_exists('ng_letter_hue')) {
    function ng_letter_hue($s)
    {
        $s = (string)$s;
        if ($s === '') return 330;
        return (int)(abs(crc32($s)) % 300) + 20;
    }
}

/** 常见 Gravatar 镜像（无头像时返回透明图，让首字占位透出来） */
if (!function_exists('ng_gravatar')) {
    function ng_gravatar($email, $size = 96)
    {
        $email = strtolower(trim((string)$email));
        if ($email === '' || strpos($email, '@') === false) return '';
        return 'https://cravatar.cn/avatar/' . md5($email) . '?d=blank&s=' . (int)$size;
    }
}

/**
 * 评论者信息：注册用户取真实昵称 / 头像 / 身份，游客回落评论表字段
 * 返回 array('name','avatar','admin','mail','letter','hue')
 * avatar 为空串时前端用 letter + hue 渲染首字头像
 */
if (!function_exists('ng_cmt_user')) {
    function ng_cmt_user($c)
    {
        $uid = (int)(isset($c['user_id']) ? $c['user_id'] : 0);
        $u = $uid > 0 && function_exists('moe_user_by') ? moe_user_by($uid) : null;
        $name = $u ? trim((string)($u['nickname'] ?? '')) : '';
        if ($name === '') $name = trim((string)(isset($c['author']) ? $c['author'] : ''));
        if ($name === '') $name = '匿名';

        $avatar = '';
        if ($u) {
            $a = trim((string)($u['avatar'] ?? ''));
            if ($a !== '') $avatar = media_url($a);
        }

        /* 邮箱头像兜底：注册用户取账户邮箱，游客取评论邮箱 */
        $mail = $u ? trim((string)($u['email'] ?? '')) : '';
        if ($mail === '') $mail = trim((string)(isset($c['email']) ? $c['email'] : ''));
        if ($avatar === '') $avatar = ng_gravatar($mail, 96);

        $admin = $u && (($u['role'] ?? '') === 'admin');
        $letter = function_exists('initial') ? initial($name) : ng_substr($name, 0, 1);
        return array(
            'name'   => $name,
            'avatar' => $avatar,
            'admin'  => $admin,
            'mail'   => $mail,
            'letter' => $letter,
            'hue'    => ng_letter_hue($name),
        );
    }
}

/** 封面式首页的「进入首页」地址：带 enter 参数绕开封面，且与普通首页分属不同页面缓存 */
if (!function_exists('ng_enter_url')) {
    function ng_enter_url()
    {
        return is_pretty_url()
            ? home_url() . '?enter=1'
            : base_url() . 'index.php?p=index&enter=1';
    }
}

/** 评论表单默认身份（登录用户自动带入昵称与邮箱，兼容核心同名函数缺失） */
if (!function_exists('ng_comment_defaults')) {
    function ng_comment_defaults()
    {
        if (function_exists('moe_comment_defaults')) return moe_comment_defaults();
        $out = array('author' => '', 'email' => '', 'admin' => false, 'user' => false, 'uid' => 0);
        if (!function_exists('current_user')) return $out;
        $u = current_user();
        if (!$u) return $out;
        $author = trim((string)($u['nickname'] ?? ''));
        if ($author === '') $author = trim((string)($u['username'] ?? ''));
        $out['author'] = $author;
        $out['email']  = trim((string)($u['email'] ?? ''));
        $out['uid']    = (int)($u['id'] ?? 0);
        $out['user']   = $out['uid'] > 0;
        $out['admin']  = $out['user'] && (($u['role'] ?? '') === 'admin');
        return $out;
    }
}
