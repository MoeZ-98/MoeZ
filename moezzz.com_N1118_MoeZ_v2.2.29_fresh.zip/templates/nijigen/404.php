<?php $page_title = '404 Not Found'; $cur_p = '404'; include partial_path('header.php'); ?>
<div class="ng-empty" style="margin:60px 0">
  <span class="big">🎀</span>
  <h2>404 · 页面去二次元了</h2>
  <p>你要找的内容不存在、已被删除，或者根本就是别的次元的链接～ (๑°⌓°๑)</p>
  <a class="ng-btn" href="<?php echo e(u()); ?>">回到首页 🏠</a>
</div>
<?php include partial_path('footer.php'); ?>
