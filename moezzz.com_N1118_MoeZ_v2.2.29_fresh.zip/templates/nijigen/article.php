<?php
/**
 * Nijigen 模板 · 全部文章列表（路由 /blog/article）
 * 可用变量：$posts $pager $total $page $cats（分类行，额外含 count） $sel_cat $site $nav_cats
 */
$page_title = '写作';
$cur_p = 'article';
include partial_path('header.php');
?>

<?php $ng_side = ng_side_on(); ?>
<?php if ($ng_side): ?><div class="ng-layout"><div class="ng-main"><?php endif; ?>

<header class="ng-page-head">
  <h1>📝 写作</h1>
  <p>这里收录全部 <?php echo (int)$total; ?> 篇文章，慢慢读～</p>
</header>

<?php if (!empty($cats)): ?>
<div class="ng-chips">
  <a class="<?php echo $sel_cat === '' ? 'cur' : ''; ?>" href="<?php echo e(base_url() . 'blog/article'); ?>">全部</a>
  <?php foreach ((array)$cats as $c): ?>
    <a class="<?php echo ($sel_cat !== '' && !empty($c['slug']) && $sel_cat === $c['slug']) ? 'cur' : ''; ?>"
       href="<?php echo e(cat_url($c)); ?>"><?php echo e(isset($c['name']) ? $c['name'] : ''); ?>
      <span>· <?php echo (int)(isset($c['count']) ? $c['count'] : 0); ?></span></a>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if (empty($posts)): ?>
  <div class="ng-empty">
    <span class="big">🍂</span>
    <h2>还没有文章～</h2>
    <p>登录后台写下第一篇吧！</p>
    <a class="ng-btn" href="<?php echo e(base_url() . 'admin/'); ?>">前往后台 ✍️</a>
  </div>
<?php else: ?>
  <?php
    $ng_posts = $posts;
    $ng_layout = ng_opt('layout', 'list');
    $ng_show_reading = ng_on('show_reading', '1');
    include theme_path('_list.php');
  ?>
  <?php echo $pager; ?>
<?php endif; ?>

<?php if ($ng_side): ?></div><?php include theme_path('_sidebar.php'); ?></div><?php endif; ?>

<?php include partial_path('footer.php'); ?>
