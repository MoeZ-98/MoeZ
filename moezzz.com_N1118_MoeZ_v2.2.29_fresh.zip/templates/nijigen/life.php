<?php
/**
 * Nijigen 模板 · 点滴时间线（路由 /life）
 * 可用变量：$groups（'YYYY-MM' => 文章行数组，行内额外含 comment_count） $total
 *           $life_cat（点滴分类行） $site $nav_cats
 */
$page_title = '点滴';
$cur_p = 'life';
include partial_path('header.php');
?>

<?php $ng_side = ng_side_on(); ?>
<?php if ($ng_side): ?><div class="ng-layout"><div class="ng-main"><?php endif; ?>

<header class="ng-page-head">
  <h1>💧 点滴</h1>
  <p><?php echo e(!empty($life_cat['name']) ? $life_cat['name'] : '日常碎片'); ?> · 共 <?php echo (int)$total; ?> 条记录，按月整理</p>
</header>

<?php if (empty($groups)): ?>
  <div class="ng-empty">
    <span class="big">🫧</span>
    <h2>还没有点滴记录</h2>
    <p>去「<?php echo e(!empty($life_cat['name']) ? $life_cat['name'] : '点滴'); ?>」分类写下第一条吧～</p>
    <a class="ng-btn" href="<?php echo e(u()); ?>">回到首页</a>
  </div>
<?php else: ?>
  <?php foreach ($groups as $month => $items): ?>
    <section class="ng-tl-group">
      <div class="ng-tl-head">
        <h2><?php echo e($month); ?></h2>
        <span class="ng-tl-count"><?php echo count((array)$items); ?> 条</span>
      </div>
      <ul class="ng-tl-list">
        <?php foreach ((array)$items as $p): ?>
          <li class="ng-tl-item ng-tl-item--life">
            <span class="ng-tl-date"><?php echo e(isset($p['created_at']) ? format_time($p['created_at'], 'm-d H:i') : ''); ?></span>
            <div class="tl-body">
              <a class="ng-tl-title" href="<?php echo e(!empty($p['id']) ? post_url($p) : '#'); ?>"><?php echo e(isset($p['title']) && $p['title'] !== '' ? $p['title'] : '（无标题）'); ?></a>
              <?php $ng_text = post_excerpt($p, 120); if ($ng_text !== ''): ?><p class="ng-tl-text"><?php echo e($ng_text); ?></p><?php endif; ?>
              <span class="ng-tl-extra">💬 <?php echo (int)(isset($p['comment_count']) ? $p['comment_count'] : 0); ?> · 👀 <?php echo (int)(isset($p['views']) ? $p['views'] : 0); ?></span>
            </div>
          </li>
        <?php endforeach; ?>
      </ul>
    </section>
  <?php endforeach; ?>
<?php endif; ?>

<?php if ($ng_side): ?></div><?php include theme_path('_sidebar.php'); ?></div><?php endif; ?>

<?php include partial_path('footer.php'); ?>
