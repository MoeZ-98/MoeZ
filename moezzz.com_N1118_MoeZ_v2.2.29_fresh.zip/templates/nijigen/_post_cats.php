<?php
/**
 * Nijigen 模板 · 文章页底部「分类聚合」区块
 * 结构：分类标题（含文章数 + 查看全部）+ 该分类最新 N 篇文章小卡片
 * 开关：post_cats；范围：post_cats_mode（other=其他分类 / all=全部分类）
 * 数量：post_cats_num（分类数）/ post_cats_per（每分类文章数）
 * 依赖外部变量：$cat（当前文章所属分类，可为 null）
 */
if (!defined('NG_ASSET_VER')) require_once theme_path('_lib.php');
if (!ng_on('post_cats', '1')) return;

$ng_pc_mode = ng_opt('post_cats_mode', 'other');
$ng_pc_cur  = (isset($cat) && is_array($cat) && isset($cat['id'])) ? (int)$cat['id'] : 0;
$ng_pc_ex   = ($ng_pc_mode === 'other' && $ng_pc_cur > 0) ? $ng_pc_cur : 0;

$ng_pc_num = (int)ng_opt('post_cats_num', '3');
if ($ng_pc_num < 1 || $ng_pc_num > 12) $ng_pc_num = 3;
$ng_pc_per = (int)ng_opt('post_cats_per', '3');
if ($ng_pc_per < 1 || $ng_pc_per > 8) $ng_pc_per = 3;

$ng_groups = ng_cat_groups($ng_pc_num, $ng_pc_per, $ng_pc_ex);
if (!$ng_groups) return;
/* 双保险：其他分类模式下再过滤一次（如查询降级导致 WHERE 未生效） */
if ($ng_pc_ex > 0) {
    $ng_groups = array_values(array_filter($ng_groups, function ($g) use ($ng_pc_ex) {
        return (int)(isset($g['id']) ? $g['id'] : 0) !== $ng_pc_ex;
    }));
}
if (!$ng_groups) return;

$ng_pc_title = trim((string)ng_opt('post_cats_title', ''));
if ($ng_pc_title === '') $ng_pc_title = '继续逛逛';
$ng_pc_desc = trim((string)ng_opt('post_cats_desc', ''));
if ($ng_pc_desc === '') $ng_pc_desc = $ng_pc_mode === 'other' ? '其他分类的最近更新 ✧' : '各分类最近更新 ✧';

$ng_pc_cur_post = isset($post['id']) ? (int)$post['id'] : 0;
?>
<section class="ng-cats ng-post-cats">
  <div class="ng-cats-head">
    <h2><i>🧭</i><?php echo e($ng_pc_title); ?></h2>
    <span class="ng-cats-more"><?php echo e($ng_pc_desc); ?></span>
  </div>

  <div class="ng-cat-groups">
    <?php foreach ($ng_groups as $g): ?>
      <?php
        $ng_gname = isset($g['name']) ? $g['name'] : '';
        $ng_gn    = (int)(isset($g['n']) ? $g['n'] : 0);
        $ng_gurl  = function_exists('cat_url') ? cat_url($g) : home_url();
        if (empty($ng_gurl)) $ng_gurl = function_exists('home_url') ? home_url() : '#';
        $ng_posts = isset($g['posts']) ? (array)$g['posts'] : array();
        if (!$ng_posts) continue;
      ?>
      <div class="ng-cat-group">
        <div class="ng-cat-group-head">
          <a class="nm" href="<?php echo e($ng_gurl); ?>"><?php echo e($ng_gname); ?></a>
          <span class="n"><?php echo $ng_gn > 0 ? $ng_gn . ' 篇' : '待更新'; ?></span>
          <a class="more" href="<?php echo e($ng_gurl); ?>">查看全部 →</a>
        </div>

        <div class="ng-ps-grid">
          <?php foreach ($ng_posts as $p): ?>
            <?php
              $ng_pid  = isset($p['id']) ? (int)$p['id'] : 0;
              if ($ng_pid === $ng_pc_cur_post) continue;   // 不重复推荐当前正文
              $ng_pcov = ng_cover($p);
              $ng_purl = function_exists('post_url') ? post_url($p) : '#';
              $ng_pt   = isset($p['title']) ? $p['title'] : '';
              $ng_pv   = (int)(isset($p['views']) ? $p['views'] : 0);
              $ng_pdt  = isset($p['created_at']) ? format_time($p['created_at'], 'Y-m-d') : '';
            ?>
            <a class="ng-ps" href="<?php echo e($ng_purl); ?>">
              <span class="ng-ps-pic" style="background:<?php echo e($ng_pcov['style']); ?>">
                <?php if ($ng_pcov['url'] !== ''): ?>
                  <img src="<?php echo e($ng_pcov['url']); ?>" alt="<?php echo e($ng_pt); ?>" loading="lazy" decoding="async" onerror="this.remove()">
                <?php else: ?>
                  <em><?php echo e(ng_substr($ng_pt, 0, 1)); ?></em>
                <?php endif; ?>
              </span>
              <span class="ng-ps-t">
                <b><?php echo e($ng_pt); ?></b>
                <small><?php echo e($ng_pdt); ?><?php if ($ng_pv > 0): ?> · <?php echo e(ng_num($ng_pv)); ?> 阅读<?php endif; ?></small>
              </span>
            </a>
          <?php endforeach; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>
