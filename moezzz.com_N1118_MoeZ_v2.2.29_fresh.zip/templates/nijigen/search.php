<?php
/**
 * Nijigen 模板 · 搜索结果（/search/关键词 与 /tag/标签 共用）
 * 可用变量：$posts $kw $pager $total $site $nav_cats
 */
$page_title = '搜索：' . $kw;
$cur_p = 'search';
include partial_path('header.php');
?>

<?php $ng_side = ng_side_on(); ?>
<?php if ($ng_side): ?><div class="ng-layout"><div class="ng-main"><?php endif; ?>

<header class="ng-page-head">
  <h1>🔍 搜索结果</h1>
  <p>关键词「<?php echo e($kw); ?>」共找到 <?php echo (int)$total; ?> 篇文章</p>
</header>

<?php if (empty($posts)): ?>
  <div class="ng-empty">
    <span class="big">🫧</span>
    <h2>没有找到相关内容</h2>
    <p>换个关键词试试？或者泡杯茶再搜一次～</p>
    <a class="ng-btn" href="<?php echo e(u()); ?>">回到首页 🏠</a>
  </div>
<?php else: ?>
  <?php
    $ng_posts = $posts;
    $ng_layout = ng_opt('layout', 'list');
    $ng_show_reading = ng_on('show_reading', '1');
    include theme_path('_list.php');
  ?>
  <?php echo $pager; ?>
<?php endif; ?>

<?php if ($ng_side): ?></div><?php include theme_path('_sidebar.php'); ?></div><?php endif; ?>

<?php include partial_path('footer.php'); ?>
