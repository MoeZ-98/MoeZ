<?php
/**
 * Nijigen 模板 · 独立页面
 * 可用变量：$page $site $nav_cats
 */
$page_title = $page['title'];
$cur_p = 'page';
include partial_path('header.php');
?>

<?php $ng_side = ng_side_on(); ?>
<?php if ($ng_side): ?><div class="ng-layout"><div class="ng-main"><?php endif; ?>
<div class="ng-simple">
  <article class="ng-article">
    <header class="ng-article-header">
      <h1><?php echo e($page['title']); ?></h1>
      <div class="meta"><span>📅 更新于 <?php echo e(format_time($page['updated_at'], 'Y-m-d')); ?></span></div>
    </header>
    <div class="md-body">
      <?php echo render_content($page['content'], isset($page['content_format']) ? $page['content_format'] : 'html'); ?>
    </div>
  </article>
</div>

<?php if ($ng_side): ?></div><?php include theme_path('_sidebar.php'); ?></div><?php endif; ?>

<?php include partial_path('footer.php'); ?>
