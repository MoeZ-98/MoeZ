<?php
/**
 * Nijigen 模板 · 友情链接（路由 /link）
 * 可用变量：$links（links 表行数组） $site $nav_cats
 * 申请表单提交到站点根 link.php（url 必填 / name / contact，带 CSRF 令牌），
 * 后端自动抓站名并检测回链，已加回链自动审核通过，否则转人工审核。
 */
$page_title = '友情链接';
$cur_p = 'link';
$hide_links = true;   // 本页已完整展示友链，隐藏页脚的友链区块避免重复
include partial_path('header.php');

$ng_site_url  = home_url();
$ng_site_name = $site['name'];
$ng_site_desc = $site['sub'] !== '' ? $site['sub'] : (string)$site['signature'];
$ng_site_ico  = media_url($site['avatar']);
$ng_link_cnt  = count((array)$links);
?>

<?php $ng_side = ng_side_on(); ?>
<?php if ($ng_side): ?><div class="ng-layout"><div class="ng-main"><?php endif; ?>
<header class="ng-page-head">
  <h1>🔗 友情链接</h1>
  <p>共收录 <?php echo $ng_link_cnt; ?> 位朋友，欢迎来串门～</p>
</header>

<?php if (empty($links)): ?>
  <div class="ng-empty">
    <span class="big">🤝</span>
    <h2>还没有友链</h2>
    <p>来和我交个朋友吧～</p>
  </div>
<?php else: ?>
  <div class="ng-links-grid">
    <?php foreach ((array)$links as $l): ?>
      <?php
        $l_name = isset($l['name']) ? $l['name'] : '';
        $l_url  = isset($l['url']) ? $l['url'] : '';
        $l_ico  = function_exists('link_icon') ? link_icon($l) : '';
        $l_desc = function_exists('link_desc') ? link_desc($l) : '';
        $l_sub  = $l_desc !== '' ? $l_desc : ('🔗 ' . (parse_url($l_url, PHP_URL_HOST) ?: $l_url));
      ?>
      <a class="ng-link-card" href="<?php echo e($l_url); ?>" target="_blank" rel="noopener nofollow" title="<?php echo e($l_name); ?>">
        <span class="face">
          <?php if ($l_ico !== ''): ?>
            <img src="<?php echo e($l_ico); ?>" alt="<?php echo e(initial($l_name)); ?>" loading="lazy"
                 onerror="this.parentNode.textContent=this.alt">
          <?php else: ?>
            <?php echo e(initial($l_name)); ?>
          <?php endif; ?>
        </span>
        <span class="info">
          <b><?php echo e($l_name); ?></b>
          <span><?php echo e($l_sub); ?></span>
        </span>
      </a>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<section class="ng-link-apply">
  <div class="ng-sec-title">
    <h2><i>📮</i>申请友链</h2>
    <?php if (!empty($site['mail'])): ?><a class="ng-more" href="mailto:<?php echo e($site['mail']); ?>">站长发邮件 →</a><?php endif; ?>
  </div>

  <div class="ng-link-grid2">
    <div class="ng-link-card-info">
      <h3>🌸 本站信息</h3>
      <p class="hint">把下面这段加到你的友链页，系统检测到回链后会立即自动通过。</p>
      <dl class="ng-link-dl">
        <dt>站点名称</dt><dd><?php echo e($ng_site_name); ?></dd>
        <dt>站点地址</dt><dd><code><?php echo e($ng_site_url); ?></code></dd>
        <?php if ($ng_site_desc !== ''): ?><dt>站点简介</dt><dd><?php echo e($ng_site_desc); ?></dd><?php endif; ?>
        <?php if ($ng_site_ico !== ''): ?><dt>站点图标</dt><dd><code><?php echo e($ng_site_ico); ?></code></dd><?php endif; ?>
      </dl>
      <div class="ng-link-copy">
        <button class="ng-btn ghost sm" type="button" data-copy="name" data-copy-val="<?php echo e($ng_site_name); ?>">复制名称</button>
        <button class="ng-btn ghost sm" type="button" data-copy="url" data-copy-val="<?php echo e($ng_site_url); ?>">复制地址</button>
        <button class="ng-btn ghost sm" type="button" data-copy="html"
                data-copy-val="<?php echo e('<a href="' . $ng_site_url . '" target="_blank">' . $ng_site_name . '</a>'); ?>">复制 HTML</button>
      </div>
    </div>

    <form class="ng-form ng-link-form" id="linkForm" method="post" action="<?php echo e(base_url() . 'link.php'); ?>">
      <?php echo csrf_field(); ?>
      <h3>✍️ 填写你的站点</h3>
      <div class="row">
        <input type="url" name="url" placeholder="你的站点地址 *（https://example.com）" required>
      </div>
      <div class="row">
        <input type="text" name="name" placeholder="站点名称（留空自动抓取）" maxlength="60">
        <input type="text" name="contact" placeholder="联系方式（邮箱 / QQ，选填）" maxlength="60">
      </div>
      <div class="row">
        <input type="text" name="description" placeholder="一句话简介（选填）" maxlength="80">
      </div>
      <p class="hint">
        提交后系统会自动访问你的站点：<br>
        · 检测到本站链接 → 立即通过并展示<br>
        · 未检测到 → 转人工审核，站长会尽快处理
      </p>
      <div style="text-align:right;margin-top:12px">
        <button class="ng-btn" type="submit" id="linkSubmit">🚀 提交申请</button>
      </div>
      <p id="linkMsg" class="ng-link-msg" style="display:none"></p>
    </form>
  </div>
</section>

<script>
(function () {
  /* 复制本站信息 */
  var cps = document.querySelectorAll('[data-copy]');
  for (var i = 0; i < cps.length; i++) {
    (function (btn) {
      btn.addEventListener('click', function () {
        var val = btn.getAttribute('data-copy-val') || '';
        var done = function () {
          var old = btn.textContent;
          btn.textContent = '✅ 已复制';
          setTimeout(function () { btn.textContent = old; }, 1400);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(val).then(done, done);
        } else {
          var ta = document.createElement('textarea');
          ta.value = val; document.body.appendChild(ta); ta.select();
          try { document.execCommand('copy'); } catch (e) {}
          document.body.removeChild(ta); done();
        }
      });
    })(cps[i]);
  }

  /* 提交申请：JSON 正常时按回执提示，非 JSON 也给出友好兜底 */
  var form = document.getElementById('linkForm');
  if (!form) return;
  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    var btn = document.getElementById('linkSubmit'), msg = document.getElementById('linkMsg');
    btn.disabled = true; btn.textContent = '检测中…';
    msg.style.display = 'block'; msg.className = 'ng-link-msg';
    msg.textContent = '正在访问你的站点检测回链，请稍候…';
    fetch(form.action, { method: 'POST', body: new FormData(form), credentials: 'same-origin' })
      .then(function (r) { return r.text(); })
      .then(function (txt) {
        var d = null;
        try { d = JSON.parse(txt); } catch (e) { d = null; }
        if (d && typeof d.ok !== 'undefined') {
          msg.className = 'ng-link-msg ' + (d.ok ? 'ok' : 'bad');
          msg.textContent = d.msg || (d.ok ? '提交成功，等待展示' : '提交失败，请检查后重试');
          if (d.ok) setTimeout(function () { location.reload(); }, 1800);
          else { btn.disabled = false; btn.textContent = '🚀 提交申请'; }
          return;
        }
        /* 后端未返回 JSON（例如直接渲染页面）：按已受理处理，提示刷新查看 */
        msg.className = 'ng-link-msg ok';
        msg.textContent = '已提交，正在等待站点处理；稍后刷新本页即可看到是否收录 ✧';
        setTimeout(function () { location.reload(); }, 2200);
      })
      .catch(function () {
        msg.className = 'ng-link-msg bad';
        msg.textContent = '网络开小差了，请稍后重试';
        btn.disabled = false; btn.textContent = '🚀 提交申请';
      });
  });
})();
</script>

<?php if ($ng_side): ?></div><?php include theme_path('_sidebar.php'); ?></div><?php endif; ?>

<?php include partial_path('footer.php'); ?>
