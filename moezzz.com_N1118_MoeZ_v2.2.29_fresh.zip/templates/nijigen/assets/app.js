/**
 * 二次元 · Nijigen 主题脚本
 * 明暗模式 / 打字机 / 樱花飘落 / 返回顶部 / 导航交互
 */
(function () {
  'use strict';

  /* ---------- 明暗模式（auto 跟随系统并实时切换） ---------- */
  var root = document.documentElement;
  var mode = document.body.getAttribute('data-dark') || 'auto';
  if (mode === 'auto' && window.matchMedia) {
    var mq = window.matchMedia('(prefers-color-scheme: dark)');
    var apply = function () { root.setAttribute('data-theme', mq.matches ? 'dark' : 'light'); };
    if (mq.addEventListener) mq.addEventListener('change', apply);
    else if (mq.addListener) mq.addListener(apply);
  }

  /* ---------- 访客前台配色切换（开关在模板设置 → 前端配色） ---------- */
  var palBox = document.getElementById('ngPaletteBox');
  var palBtn = document.getElementById('ngPaletteBtn');
  var palPop = document.getElementById('ngPalettePop');
  var palItems = document.querySelectorAll('[data-accent-set]');
  if (palItems.length) {
    var palIds = /^(sakura|sora|minto|hoshimi)$/;
    var syncPal = function () {
      var m = document.body.className.match(/\bng-accent-([a-z]+)/);
      var cur = m ? m[1] : 'sakura';
      for (var i = 0; i < palItems.length; i++) {
        palItems[i].classList.toggle('cur', palItems[i].getAttribute('data-accent-set') === cur);
      }
    };
    for (var pi = 0; pi < palItems.length; pi++) {
      palItems[pi].addEventListener('click', function () {
        var id = this.getAttribute('data-accent-set');
        if (!palIds.test(id)) return;
        document.body.className = document.body.className.replace(/\bng-accent-[a-z]+/, 'ng-accent-' + id);
        try { localStorage.setItem('ng-accent', id); } catch (e) { /* 隐私模式忽略 */ }
        syncPal();
        if (palPop) palPop.hidden = true;
        if (palBtn) palBtn.setAttribute('aria-expanded', 'false');
      });
    }
    if (palBtn && palPop) {
      palBtn.addEventListener('click', function (ev) {
        ev.stopPropagation();
        palPop.hidden = !palPop.hidden;
        palBtn.setAttribute('aria-expanded', palPop.hidden ? 'false' : 'true');
      });
      document.addEventListener('click', function (ev) {
        if (palBox && !palBox.contains(ev.target) && !palPop.hidden) {
          palPop.hidden = true;
          palBtn.setAttribute('aria-expanded', 'false');
        }
      });
    }
    syncPal();
  }

  /* ---------- 导航：滚动阴影 + 移动端抽屉 ---------- */
  var nav = document.getElementById('ngNav');
  var burger = document.getElementById('ngBurger');
  var drawer = document.getElementById('ngDrawer');
  if (nav) {
    var onScroll = function () {
      if (window.scrollY > 8) nav.classList.add('is-scrolled');
      else nav.classList.remove('is-scrolled');
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }
  if (burger && drawer) {
    var setDrawer = function (open) {
      drawer.classList.toggle('open', open);
      drawer.setAttribute('aria-hidden', open ? 'false' : 'true');
      burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      document.body.classList.toggle('ng-drawer-open', open);
    };
    burger.addEventListener('click', function () {
      setDrawer(!drawer.classList.contains('open'));
    });
    var closers = drawer.querySelectorAll('[data-dw-close]');
    for (var di = 0; di < closers.length; di++) {
      closers[di].addEventListener('click', function () { setDrawer(false); });
    }
    drawer.addEventListener('click', function (ev) {
      var a = ev.target.closest ? ev.target.closest('a') : null;
      if (a) setDrawer(false);
    });
    document.addEventListener('keydown', function (ev) {
      if (ev.key !== 'Escape') return;
      setDrawer(false);
      if (typeof closeMore === 'function') closeMore();
      if (palPop && palBtn && !palPop.hidden) {
        palPop.hidden = true;
        palBtn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  /* ---------- 窄屏侧栏：默认留在正文下方，模板设置开启后才搬进右侧抽屉 ---------- */
  var sideWrap = document.querySelector('.ng-side');
  var sideHome = sideWrap ? sideWrap.querySelector('.ng-side-sticky') : null;
  var sideBox  = document.getElementById('ngDrawerSide');
  var sideSlot = document.getElementById('ngDrawerSideBody');
  var drawerSideOn = document.body.getAttribute('data-drawer-side') === '1';
  if (sideHome && sideBox && sideSlot) {
    var mqSide = window.matchMedia('(max-width: 860px)');
    var syncSide = function () {
      if (drawerSideOn && mqSide.matches) {
        if (sideHome.parentNode !== sideSlot) sideSlot.appendChild(sideHome);
        sideBox.hidden = false;
      } else {
        if (sideHome.parentNode !== sideWrap) sideWrap.appendChild(sideHome);
        sideBox.hidden = true;
      }
      /* 抽屉里不能吸顶，否则整块会跟着滚动错位 */
      sideHome.classList.remove('is-sticky');
      sideHome.style.top = '';
    };
    syncSide();
    if (mqSide.addEventListener) mqSide.addEventListener('change', syncSide);
    else if (mqSide.addListener) mqSide.addListener(syncSide);
  }

  /* ---------- 导航项过多：把放不下的链接折叠进「更多」下拉，避免半个链接被裁 ---------- */
  var links = document.getElementById('ngLinks');
  var more = document.getElementById('ngMore');
  var moreBtn = document.getElementById('ngMoreBtn');
  var morePop = document.getElementById('ngMorePop');
  var closeMore = function () {
    if (!morePop || !moreBtn) return;
    morePop.hidden = true;
    moreBtn.setAttribute('aria-expanded', 'false');
  };
  var navMoreOn = document.body.getAttribute('data-nav-more') !== '0';
  if (navMoreOn && links && more && moreBtn && morePop) {
    var navLinks = Array.prototype.slice.call(links.querySelectorAll('a'));
    var fitNav = function () {
      closeMore();
      /* 每次先复位，避免窗口缩放后链接残留在下拉里 */
      for (var i = 0; i < navLinks.length; i++) links.appendChild(navLinks[i]);
      if (window.innerWidth <= 860 || !links.offsetParent) { more.hidden = true; return; }
      more.hidden = false;                 /* 先占位，量到链接区真正可用的宽度 */
      var avail = links.clientWidth - 2;
      if (avail <= 0) { more.hidden = true; return; }
      var used = 0, cut = -1;
      for (var j = 0; j < navLinks.length; j++) {
        used += navLinks[j].getBoundingClientRect().width + (j ? 4 : 0);
        if (used > avail) { cut = j; break; }
      }
      if (cut < 0) { more.hidden = true; return; }
      for (var k = cut; k < navLinks.length; k++) morePop.appendChild(navLinks[k]);
    };
    fitNav();
    var fitTimer;
    window.addEventListener('resize', function () {
      clearTimeout(fitTimer);
      fitTimer = setTimeout(fitNav, 120);
    }, { passive: true });
    moreBtn.addEventListener('click', function (ev) {
      ev.stopPropagation();
      morePop.hidden = !morePop.hidden;
      moreBtn.setAttribute('aria-expanded', morePop.hidden ? 'false' : 'true');
    });
    document.addEventListener('click', function (ev) {
      if (!morePop.hidden && !more.contains(ev.target)) closeMore();
    });
  }

  /* ---------- 伪静态搜索：/search/关键词（导航栏与侧栏共用同一表单类） ---------- */
  var forms = document.querySelectorAll('.ng-search');
  for (var fi = 0; fi < forms.length; fi++) {
    (function (sf) {
      if (sf.getAttribute('data-pretty') !== '1') return;
      sf.addEventListener('submit', function (ev) {
        var q = sf.querySelector('input[name=q]');
        if (!q || !q.value.trim()) { ev.preventDefault(); return; }
        ev.preventDefault();
        location.href = sf.getAttribute('data-base') + 'search/' + encodeURIComponent(q.value.trim());
      });
    })(forms[fi]);
  }

  /* ---------- 明暗切换：手动选择写入 localStorage，优先于默认模式 ---------- */
  var setTheme = function (next) {
    root.setAttribute('data-theme', next);
    try { localStorage.setItem('ng-theme', next); } catch (e) { /* 忽略 */ }
    var btn = document.getElementById('ngThemeBtn');
    if (btn) btn.textContent = next === 'dark' ? '☀️' : '🌙';
  };
  var themeBtn = document.getElementById('ngThemeBtn');
  if (themeBtn) themeBtn.textContent = root.getAttribute('data-theme') === 'dark' ? '☀️' : '🌙';
  var themeToggles = document.querySelectorAll('[data-theme-toggle], #ngThemeBtn');
  for (var ti = 0; ti < themeToggles.length; ti++) {
    themeToggles[ti].addEventListener('click', function () {
      setTheme(root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');
    });
  }

  /* ---------- 登录 / 注册弹窗：提交到用户中心，读回执在原位提示 ---------- */
  var auth = document.getElementById('ngAuth');
  if (auth) {
    var authUrl = auth.getAttribute('data-auth-url') || '';
    var capUrl = auth.getAttribute('data-cap-url') || '';
    var aMsg = auth.querySelector('.ng-auth-msg');
    var aTabs = auth.querySelectorAll('[data-auth-tab]');
    var aForms = auth.querySelectorAll('.ng-auth-form');
    var regForm = auth.querySelector('[data-auth-act="register"]');

    /* 页面缓存会把验证码题目一起缓存，切到注册页签时实时拉一份新的题目与令牌 */
    var refreshCaptcha = function () {
      if (!capUrl || !regForm) return;
      var qEl = regForm.querySelector('.ng-field b');
      var tokEl = regForm.querySelector('input[name="_token"]');
      fetch(capUrl, { credentials: 'same-origin' }).then(function (r) { return r.text(); }).then(function (html) {
        var doc = new DOMParser().parseFromString(html, 'text/html');
        var inp = doc.querySelector('input[name="captcha"]');
        var box = inp && inp.closest ? inp.closest('.field') : null;
        var q = box ? box.querySelector('b') : null;
        var tk = doc.querySelector('input[name="_token"]');
        if (qEl && q && q.textContent.trim()) qEl.textContent = q.textContent.trim();
        if (tokEl && tk && tk.value) tokEl.value = tk.value;
      }).catch(function () { /* 拉取失败则沿用页面自带题目 */ });
    };

    var say = function (text, kind) {
      if (!aMsg) return;
      aMsg.textContent = text;
      aMsg.className = 'ng-auth-msg' + (kind ? ' ' + kind : '');
    };
    var switchTab = function (name) {
      for (var i = 0; i < aTabs.length; i++) {
        var t = aTabs[i];
        if (t.parentNode && t.parentNode.classList.contains('ng-auth-tabs')) {
          t.classList.toggle('cur', t.getAttribute('data-auth-tab') === name);
        }
      }
      for (var j = 0; j < aForms.length; j++) {
        aForms[j].hidden = aForms[j].getAttribute('data-auth-act') !== name;
      }
      if (name === 'register') refreshCaptcha();
      say('', '');
    };
    var openAuth = function (tab) {
      auth.classList.add('open');
      auth.setAttribute('aria-hidden', 'false');
      document.body.classList.add('ng-drawer-open');
      switchTab(tab === 'register' && auth.querySelector('[data-auth-act="register"]') ? 'register' : 'login');
      var first = auth.querySelector('.ng-auth-form:not([hidden]) input');
      if (first && window.innerWidth > 860) setTimeout(function () { try { first.focus(); } catch (e) {} }, 120);
    };
    var closeAuth = function () {
      auth.classList.remove('open');
      auth.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('ng-drawer-open');
    };

    var openers = document.querySelectorAll('[data-auth-open]');
    for (var oi = 0; oi < openers.length; oi++) {
      (function (el) {
        el.addEventListener('click', function () {
          if (drawer && drawer.classList.contains('open')) {
            drawer.classList.remove('open');
            drawer.setAttribute('aria-hidden', 'true');
            if (burger) burger.setAttribute('aria-expanded', 'false');
          }
          openAuth(el.getAttribute('data-auth-open') || 'login');
        });
      })(openers[oi]);
    }
    var aClosers = auth.querySelectorAll('[data-auth-close]');
    for (var ci = 0; ci < aClosers.length; ci++) {
      aClosers[ci].addEventListener('click', closeAuth);
    }
    for (var tk = 0; tk < aTabs.length; tk++) {
      (function (btn) {
        btn.addEventListener('click', function (ev) {
          ev.preventDefault();
          switchTab(btn.getAttribute('data-auth-tab'));
        });
      })(aTabs[tk]);
    }
    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' && auth.classList.contains('open')) closeAuth();
    });

    for (var ai = 0; ai < aForms.length; ai++) {
      (function (form) {
        form.addEventListener('submit', function (ev) {
          ev.preventDefault();
          var act = form.getAttribute('data-auth-act') || 'login';
          var btn = form.querySelector('.ng-auth-submit');
          var old = btn ? btn.textContent : '';
          if (btn) { btn.disabled = true; btn.textContent = act === 'login' ? '登录中…' : '注册中…'; }
          say('正在处理，请稍等…', '');
          fetch(authUrl, {
            method: 'POST',
            body: new FormData(form),
            credentials: 'same-origin'
          }).then(function (r) { return r.text(); }).then(function (html) {
            var doc = new DOMParser().parseFromString(html, 'text/html');
            var bad = doc.querySelector('.alert.bad');
            var ok = doc.querySelector('.alert.ok');
            if (ok) {
              say(ok.textContent.trim() || (act === 'login' ? '登录成功，正在刷新…' : '注册成功'), 'ok');
              setTimeout(function () { location.reload(); }, 900);
              return;
            }
            if (bad) {
              say(bad.textContent.trim(), 'bad');
              if (btn) { btn.disabled = false; btn.textContent = old; }
              /* 注册会消耗一次算术验证码，失败后刷新页面重新出题并回到注册页签 */
              if (act === 'register') {
                setTimeout(function () { location.href = location.pathname + location.search + '#register'; }, 1800);
              }
              return;
            }
            say('提交没有成功，请刷新页面后重试', 'bad');
            if (btn) { btn.disabled = false; btn.textContent = old; }
          }).catch(function () {
            say('网络开小差了，请稍后重试', 'bad');
            if (btn) { btn.disabled = false; btn.textContent = old; }
          });
        });
      })(aForms[ai]);
    }

    if (location.hash === '#login' || location.hash === '#register') {
      openAuth(location.hash === '#register' ? 'register' : 'login');
    }
  }

  /* ---------- 页脚「建站运行」实时计时 ---------- */
  var upEl = document.querySelector('[data-uptime]');
  if (upEl) {
    var startAt = new Date(upEl.getAttribute('data-uptime')).getTime();
    if (!isNaN(startAt)) {
      var pad2 = function (n) { return (n < 10 ? '0' : '') + n; };
      var tickUp = function () {
        var diff = Math.max(0, Date.now() - startAt);
        var sec = Math.floor(diff / 1000);
        var days = Math.floor(sec / 86400);
        var h = Math.floor((sec % 86400) / 3600);
        var m = Math.floor((sec % 3600) / 60);
        var s = sec % 60;
        upEl.textContent = days + ' 天 ' + pad2(h) + ' 时 ' + pad2(m) + ' 分 ' + pad2(s) + ' 秒';
      };
      tickUp();
      setInterval(tickUp, 1000);
    }
  }

  /* ---------- 横幅打字机 ---------- */
  var tEl = document.getElementById('ngTyping');
  if (tEl) {
    var text = tEl.getAttribute('data-text') || '欢迎来到我的小站～';
    var i = 0, adding = true;
    (function tick() {
      if (adding) {
        i++;
        tEl.textContent = text.slice(0, i);
        if (i >= text.length) { adding = false; setTimeout(tick, 2400); return; }
      } else {
        i -= 2;
        if (i <= 0) { i = 0; adding = true; }
        tEl.textContent = text.slice(0, i);
      }
      setTimeout(tick, adding ? 130 : 45);
    })();
  }

  /* ---------- 侧栏吸顶：内容不超过一屏时才启用，避免长侧栏底部被裁 ---------- */
  var side = document.querySelector('.ng-side-sticky');
  if (side) {
    var checkSide = function () {
      if (window.innerWidth <= 1020) { side.classList.remove('is-sticky'); return; }
      if (side.offsetHeight + 120 < window.innerHeight) side.classList.add('is-sticky');
      else side.classList.remove('is-sticky');
    };
    checkSide();
    window.addEventListener('resize', checkSide, { passive: true });
  }

  /* ---------- 返回顶部 ---------- */
  var bt = document.getElementById('ngBackTop');
  if (bt) {
    window.addEventListener('scroll', function () {
      if (window.scrollY > 320) bt.classList.add('show');
      else bt.classList.remove('show');
    }, { passive: true });
    bt.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
  }

  /* ---------- 评论回复：点「回复」把 @昵称 写进表单并聚焦，可取消 ---------- */
  var cmForm = document.getElementById('cform');
  if (cmForm) {
    var cmText = cmForm.querySelector('textarea[name="content"]');
    var cmTip = document.getElementById('creplyTip');
    var cmTipName = document.getElementById('creplyName');
    var cmCancel = document.getElementById('creplyCancel');
    var cmAuthor = cmForm.querySelector('input[name="author"]');
    var cmCur = '';

    var cmStrip = function (v) { return String(v).replace(/^@[^\s：:，,]{1,24}\s?/, ''); };

    var cmApply = function (name) {
      cmCur = name || '';
      if (cmText) {
        var body = cmStrip(cmText.value);
        cmText.value = cmCur ? '@' + cmCur + ' ' + body : body;
      }
      if (cmTip) {
        if (cmCur) { cmTip.hidden = false; if (cmTipName) cmTipName.textContent = '@' + cmCur; }
        else { cmTip.hidden = true; }
      }
    };

    document.addEventListener('click', function (ev) {
      var el = ev.target;
      while (el && el !== document.body && !el.classList) el = el.parentNode;
      if (!el || !el.classList || !el.classList.contains('ng-cm-reply')) return;
      ev.preventDefault();
      var name = el.getAttribute('data-reply') || '';
      if (name === '') return;
      cmApply(name);
      // 表单在页面下方，滚过去并把光标放到正文末尾
      try { cmForm.scrollIntoView({ behavior: 'smooth', block: 'center' }); } catch (e) { cmForm.scrollIntoView(); }
      if (cmText) {
        setTimeout(function () {
          cmText.focus();
          var at = cmText.value.length;
          try { cmText.setSelectionRange(at, at); } catch (e) { /* 忽略 */ }
        }, 260);
      } else if (cmAuthor) {
        cmAuthor.focus();
      }
    });

    if (cmCancel) {
      cmCancel.addEventListener('click', function () {
        cmApply('');
        if (cmText) cmText.focus();
      });
    }
  }

  /* ---------- 樱花飘落 ---------- */
  var cvs = document.getElementById('ngPetals');
  if (cvs && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    var ctx = cvs.getContext('2d');
    var petals = [];
    var COUNT = Math.min(22, Math.max(10, Math.floor(window.innerWidth / 70)));
    var running = true;

    var resize = function () {
      cvs.width = window.innerWidth;
      cvs.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    var rnd = function (a, b) { return a + Math.random() * (b - a); };

    var make = function (initY) {
      return {
        x: rnd(0, cvs.width),
        y: initY === undefined ? rnd(-cvs.height, 0) : initY,
        s: rnd(4, 9),                 // 花瓣大小
        vy: rnd(.4, 1.1),             // 下落速度
        vx: rnd(-.5, .8),             // 水平漂移
        r: rnd(0, Math.PI * 2),       // 旋转角
        vr: rnd(-.02, .02),           // 旋转速度
        o: rnd(.35, .75),             // 透明度
        hue: Math.random() < .7 ? 340 : 280   // 粉 / 紫
      };
    };
    for (var k = 0; k < COUNT; k++) petals.push(make(rnd(0, cvs.height)));

    var draw = function () {
      if (!running) return;
      ctx.clearRect(0, 0, cvs.width, cvs.height);
      for (var j = 0; j < petals.length; j++) {
        var p = petals[j];
        p.y += p.vy;
        p.x += p.vx + Math.sin(p.y / 40) * .3;
        p.r += p.vr;
        if (p.y > cvs.height + 12 || p.x < -20 || p.x > cvs.width + 20) petals[j] = make();
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.r);
        ctx.globalAlpha = p.o;
        ctx.fillStyle = 'hsl(' + p.hue + ', 90%, 82%)';
        ctx.beginPath();
        ctx.ellipse(0, 0, p.s, p.s * .62, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
      requestAnimationFrame(draw);
    };
    draw();

    document.addEventListener('visibilitychange', function () {
      var was = running;
      running = !document.hidden;
      if (running && !was) draw();
    });
  }
})();
