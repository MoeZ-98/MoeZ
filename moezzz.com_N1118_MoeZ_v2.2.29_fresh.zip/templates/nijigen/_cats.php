<?php
/**
 * Nijigen 模板 · 首页「分类浏览」区块（图 + 文卡片）
 * 数据：ng_cat_cards()（分类 + 文章数 + 该分类最新文章封面）
 * 开关：模板设置 home_cats；标题：home_cats_title
 */
if (!defined('NG_ASSET_VER')) require_once theme_path('_lib.php');

$ng_cards = ng_on('home_cats', '1') ? ng_cat_cards(8) : array();
if (!$ng_cards) return;

$ng_cats_title = trim((string)ng_opt('home_cats_title', ''));
if ($ng_cats_title === '') $ng_cats_title = '分类浏览';
$ng_cats_desc = trim((string)ng_opt('home_cats_desc', ''));
if ($ng_cats_desc === '') $ng_cats_desc = '按主题逛逛吧 ✧';
?>
<section class="ng-cats">
  <div class="ng-cats-head">
    <h2><i>🗂</i><?php echo e($ng_cats_title); ?></h2>
    <span class="ng-cats-more"><?php echo e($ng_cats_desc); ?></span>
  </div>

  <div class="ng-cats-grid">
    <?php foreach ($ng_cards as $c): ?>
      <?php
        $ng_cn    = isset($c['name']) ? $c['name'] : '';
        $ng_cdesc = isset($c['description']) ? trim((string)$c['description']) : '';
        $ng_cn2   = (int)(isset($c['n']) ? $c['n'] : 0);
        $ng_curl  = function_exists('cat_url') ? cat_url($c) : home_url();
        if (empty($ng_curl)) $ng_curl = function_exists('home_url') ? home_url() : '#';
        $ng_ccov  = !empty($c['cover']) ? media_url($c['cover']) : '';
        $ng_cg    = ng_cover(array('id' => (int)(isset($c['id']) ? $c['id'] : 0), 'cover' => ''));
      ?>
      <a class="ng-cat-card" href="<?php echo e($ng_curl); ?>">
        <span class="ng-cat-pic" style="background:<?php echo e($ng_cg['style']); ?>">
          <?php if ($ng_ccov !== ''): ?>
            <img src="<?php echo e($ng_ccov); ?>" alt="<?php echo e($ng_cn); ?>" loading="lazy" onerror="this.remove()">
          <?php else: ?>
            <em><?php echo e(ng_substr($ng_cn, 0, 2)); ?></em>
          <?php endif; ?>
          <span class="ng-cat-num"><?php echo $ng_cn2 > 0 ? $ng_cn2 . ' 篇' : '待更新'; ?></span>
        </span>
        <span class="ng-cat-info">
          <b><?php echo e($ng_cn); ?></b>
          <small><?php echo $ng_cdesc !== '' ? e($ng_cdesc) : '共 ' . $ng_cn2 . ' 篇文章'; ?></small>
        </span>
      </a>
    <?php endforeach; ?>
  </div>
</section>
