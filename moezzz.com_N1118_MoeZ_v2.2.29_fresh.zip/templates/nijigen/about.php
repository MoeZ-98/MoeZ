<?php
/**
 * Nijigen 模板 · 关于页（路由 /about）
 * 可用变量：$site $nav_cats；模板设置 about_md 有值时优先渲染
 */
$page_title = '关于';
$cur_p = 'about';
include partial_path('header.php');

$ng_about_md = trim(ng_opt('about_md', ''));
$ng_stats = (!empty($site['stats']) && is_array($site['stats'])) ? $site['stats'] : site_stats();
?>

<?php $ng_side = ng_side_on(); ?>
<?php if ($ng_side): ?><div class="ng-layout"><div class="ng-main"><?php endif; ?>
<div class="ng-simple">
  <article class="ng-article">
    <header class="ng-article-header">
      <img src="<?php echo e(media_url($site['avatar'])); ?>" alt="<?php echo e($site['name']); ?> 的头像">
      <h1><?php echo e($site['name']); ?></h1>
      <div class="meta">
        <?php if (!empty($site['signature'])): ?><span><?php echo e($site['signature']); ?></span><?php endif; ?>
        <?php if (!empty($site['sub'])): ?><span><?php echo e($site['sub']); ?></span><?php endif; ?>
        <?php if (!empty($site['author'])): ?><span>✍️ <?php echo e($site['author']); ?></span><?php endif; ?>
      </div>
    </header>

    <div class="ng-stat-bar static">
      <span class="ng-stat"><b><?php echo (int)$ng_stats['posts']; ?></b><span>文章</span></span>
      <span class="ng-stat"><b><?php echo (int)$ng_stats['comments']; ?></b><span>评论</span></span>
      <span class="ng-stat"><b><?php echo e(ng_num($ng_stats['views'])); ?></b><span>浏览</span></span>
    </div>

    <div class="md-body" style="margin-top:22px">
      <?php if ($ng_about_md !== ''): ?>
        <?php echo render_content($ng_about_md, 'markdown'); ?>
      <?php else: ?>
        <p><?php echo e(!empty($site['desc']) ? $site['desc'] : '这里记录代码、生活与一些小小的好奇。'); ?></p>
        <p>目前这个小站已经写下 <b><?php echo (int)$ng_stats['posts']; ?></b> 篇文章，收到 <b><?php echo (int)$ng_stats['comments']; ?></b> 条评论，累计被浏览 <b><?php echo e(ng_num($ng_stats['views'])); ?></b> 次。</p>
        <p>如果喜欢这里，欢迎通过 <a href="<?php echo e(rss_url()); ?>">RSS</a> 订阅，或者在任意一篇文章下面留言聊聊～</p>
      <?php endif; ?>
    </div>

    <div class="article-tags" style="margin-top:24px">
      <?php if (!empty($site['github'])): ?><a class="ng-btn ghost" href="<?php echo e($site['github']); ?>" target="_blank" rel="noopener">🐱 GitHub</a><?php endif; ?>
      <?php if (!empty($site['bilibili'])): ?><a class="ng-btn ghost" href="<?php echo e($site['bilibili']); ?>" target="_blank" rel="noopener">📺 哔哩哔哩</a><?php endif; ?>
      <?php if (!empty($site['weibo'])): ?><a class="ng-btn ghost" href="<?php echo e($site['weibo']); ?>" target="_blank" rel="noopener">🔥 微博</a><?php endif; ?>
      <?php if (!empty($site['twitter'])): ?><a class="ng-btn ghost" href="<?php echo e($site['twitter']); ?>" target="_blank" rel="noopener">🐦 X / Twitter</a><?php endif; ?>
      <?php if (!empty($site['mail'])): ?><a class="ng-btn ghost" href="mailto:<?php echo e($site['mail']); ?>">✉️ 邮件</a><?php endif; ?>
      <a class="ng-btn ghost" href="<?php echo e(rss_url()); ?>" target="_blank" rel="noopener">📡 RSS</a>
    </div>
  </article>
</div>

<?php if ($ng_side): ?></div><?php include theme_path('_sidebar.php'); ?></div><?php endif; ?>

<?php include partial_path('footer.php'); ?>
