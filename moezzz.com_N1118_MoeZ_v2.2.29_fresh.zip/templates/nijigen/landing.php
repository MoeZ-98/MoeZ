<?php
/**
 * Nijigen 模板 · 个人资料封面页（Landing）
 * 在「模板设置 → 封面式首页」开启后，首次访问站点先看到本页；点击按钮或站内「首页」链接（?enter=1）进入真正的首页。
 * 背景支持自定义图片 / 视频：设置 landing_bg_video 优先，其次 landing_bg_img，都没有则用主题渐变兜底。
 * 可用变量：$site $nav_cats $page
 */
if (!defined('NG_ASSET_VER')) require_once theme_path('_lib.php');

$ng_limg = trim((string)ng_opt('landing_bg_img', ''));
$ng_lvid = trim((string)ng_opt('landing_bg_video', ''));
$ng_lbtn = trim((string)ng_opt('landing_btn', ''));
if ($ng_lbtn === '') $ng_lbtn = '进入首页 ✧';
/* 标题 / 签名 / 简介：模板设置里可单独覆盖，留空则回落到站点名称与站点签名 */
$ng_ltitle = trim((string)ng_opt('landing_title', ''));
if ($ng_ltitle === '') $ng_ltitle = $site['name'];
$ng_lsign = trim((string)ng_opt('landing_sign', ''));
if ($ng_lsign === '') {
    $ng_lsign = $site['signature'] ? $site['signature'] : '欢迎来到我的小站～ (๑>ᴗ<๑)';
}
/* 简介：支持多行，换行自动转 <br> */
$ng_lbio = trim((string)ng_opt('landing_bio', ''));
/* 文字位置：center / left / right —— 背景主体偏左时可以把文字挪到右侧空白处 */
$ng_lalign = ng_opt('landing_align', 'center');
if (!in_array($ng_lalign, array('center', 'left', 'right'), true)) $ng_lalign = 'center';
/* 遮罩强度：light / mid / strong —— 深色背景图用 light 更能留住画面质感 */
$ng_lveil = ng_opt('landing_veil', 'mid');
if (!in_array($ng_lveil, array('none', 'light', 'mid', 'strong'), true)) $ng_lveil = 'mid';

$page_title = $site['name'];
$cur_p = 'landing';
include partial_path('header.php');
?>

<section class="ng-landing ng-land-<?php echo e($ng_lalign); ?><?php echo ($ng_lvid === '' && $ng_limg === '') ? ' ng-land-grad' : ''; ?><?php echo $ng_lveil === 'none' ? ' ng-veil-none' : ''; ?>">

  <?php if ($ng_lvid !== ''): ?>
  <video class="ng-land-bg" src="<?php echo e(media_url($ng_lvid)); ?>"<?php echo $ng_limg !== '' ? ' poster="' . e(media_url($ng_limg)) . '"' : ''; ?>
         autoplay muted loop playsinline disablepictureinpicture></video>
  <?php elseif ($ng_limg !== ''): ?>
  <div class="ng-land-bg ng-land-img" style="background-image:url('<?php echo e(media_url($ng_limg)); ?>')"></div>
  <?php endif; ?>
  <div class="ng-land-veil veil-<?php echo e($ng_lveil); ?>"></div>

  <div class="ng-land-body">
    <div class="avatar-ring"><img src="<?php echo e(media_url($site['avatar'])); ?>" alt="<?php echo e($site['name']); ?> 的头像"></div>
    <h1><?php echo e($ng_ltitle); ?></h1>
    <div class="ng-typing"><span id="ngTyping" data-text="<?php echo e($ng_lsign); ?>"></span><span class="cursor"></span></div>

    <?php if ($ng_lbio !== ''): ?>
    <p class="ng-land-bio"><?php echo nl2br(e($ng_lbio)); ?></p>
    <?php endif; ?>

    <?php if (ng_on('show_socials', '1')): ?>
    <div class="socials">
      <?php foreach ($site['socials'] as $soc): ?>
        <?php $socImg = function_exists('social_icon_url') ? social_icon_url($soc['icon']) : ''; ?>
        <a href="<?php echo e($soc['url']); ?>" target="_blank" rel="noopener" title="<?php echo e($soc['name']); ?>">
          <?php if ($socImg !== ''): ?><img src="<?php echo e($socImg); ?>" alt="<?php echo e($soc['name']); ?>" onerror="this.remove()"><?php else: ?><?php echo e($soc['icon'] !== '' ? $soc['icon'] : '🔗'); ?><?php endif; ?>
        </a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <a class="ng-btn ng-land-btn" href="<?php echo e(ng_enter_url()); ?>"><?php echo e($ng_lbtn); ?></a>
  </div>
</section>

<?php include partial_path('footer.php'); ?>
