<?php
/**
 * 花墨 · Flowersink 模板 · 写作列表页（/blog/article）
 * 全部已发布文章卡片列表 + 分类导航 + 分页
 * 可用变量：$posts $pager $total $page $cats $sel_cat $site $nav_cats
 */
$cur_p = 'article';
include partial_path('header.php');

$fs_total     = isset($total) ? (int) $total : 0;
$fs_side_on   = fs_on('show_home_aside', '1');
$fs_sel_cat   = isset($sel_cat) ? (int) $sel_cat : 0;
$fs_cat_chips = (isset($cats) && is_array($cats) && !empty($cats)) ? $cats : fs_cats();
?>
<div class="fi-screen">
  <?php echo fs_page_head('写作', '共 ' . $fs_total . ' 篇文章，按发布时间倒序排列', '写作'); ?>

  <?php if (!empty($fs_cat_chips)): ?>
    <nav class="fi-chipbar" aria-label="分类导航">
      <span class="fi-chip is-active">全部文章<b><?php echo $fs_total; ?></b></span>
      <?php foreach ($fs_cat_chips as $fs_c): ?>
        <?php if (!is_array($fs_c) || empty($fs_c['name'])) continue; ?>
        <a class="fi-chip<?php echo (int) $fs_sel_cat === (int) $fs_c['id'] ? ' is-active' : ''; ?>" href="<?php echo e(cat_url($fs_c)); ?>"><?php echo e($fs_c['name']); ?><b><?php echo (int) (isset($fs_c['count']) ? $fs_c['count'] : (isset($fs_c['cnt']) ? $fs_c['cnt'] : 0)); ?></b></a>
      <?php endforeach; ?>
    </nav>
  <?php endif; ?>

  <div class="fl-shell">
    <div class="fl-content">
      <?php if (empty($posts)): ?>
        <p class="fi-empty-note">这里还没有文章～</p>
      <?php else: ?>
        <div class="fi-post-grid">
          <?php foreach ($posts as $fs_p): ?><?php echo fs_card_html($fs_p); ?><?php endforeach; ?>
        </div>
        <?php echo isset($pager) ? $pager : ''; ?>
      <?php endif; ?>
    </div>

    <?php if ($fs_side_on): ?>
      <aside class="fl-aside"><?php echo fs_aside_html($site, $fs_cat_chips); ?></aside>
    <?php endif; ?>
  </div>
</div>

<?php include partial_path('footer.php'); ?>