<?php
/**
 * 花墨 · Flowersink 模板 · 关于页（/about）
 * 模板设置「关于页正文」有内容时渲染 Markdown，否则展示站点名片与站点数据
 * 可用变量：$site $nav_cats
 */
$cur_p = 'about';
include partial_path('header.php');

$fs_about   = trim((string) fs_opt('about_md', ''));
$fs_me_name = $site['author'] !== '' ? $site['author'] : $site['name'];
$fs_uptime  = fs_uptime();
?>
<div class="fi-screen">
  <?php echo fs_page_head('关于', $site['sub'] !== '' ? $site['sub'] : '关于这个小站与写字的人', '关于'); ?>

  <div class="fl-shell">
    <div class="fl-content">
      <?php if ($fs_about !== ''): ?>
        <article class="fi-article fl-card-surface">
          <div class="prose"><?php echo render_content($fs_about, 'markdown'); ?></div>
        </article>
      <?php else: ?>
        <section class="fi-about fl-card-surface">
          <img class="fi-about-avatar" src="<?php echo e(fs_avatar($site)); ?>" alt="<?php echo e($fs_me_name); ?>" loading="lazy">
          <h2 class="fi-about-name"><?php echo e($fs_me_name); ?></h2>
          <?php if ($site['sub'] !== ''): ?><p class="fi-about-sub"><?php echo e($site['sub']); ?></p><?php endif; ?>
          <?php if ($site['desc'] !== ''): ?><p class="fi-about-desc"><?php echo e($site['desc']); ?></p><?php endif; ?>
          <?php if ($site['signature'] !== ''): ?><blockquote class="fi-about-quote"><?php echo e($site['signature']); ?></blockquote><?php endif; ?>
          <div class="fl-hero-stats fl-hero-stats--center">
            <span><b><?php echo (int) $site['stats']['posts']; ?></b>文章</span>
            <span><b><?php echo (int) $site['stats']['comments']; ?></b>评论</span>
            <span><b><?php echo (int) $site['stats']['views']; ?></b>浏览</span>
          </div>
          <p class="fi-about-tip">在「后台 → 模板设置 → 关于页正文」里填写 Markdown，这里就会换成你自己的介绍。</p>
        </section>
      <?php endif; ?>
    </div>

    <aside class="fl-aside">
      <div class="sidebar-card fl-card-surface">
        <p class="sidebar-card__title">联系方式</p>
        <div class="sidebar-card__body">
          <?php if ($site['mail'] !== ''): ?>
            <p class="fi-stat-line">邮箱：<a href="mailto:<?php echo e($site['mail']); ?>"><?php echo e($site['mail']); ?></a></p>
          <?php endif; ?>
          <?php if ($site['github'] !== ''): ?>
            <p class="fi-stat-line">GitHub：<a href="<?php echo e($site['github']); ?>" target="_blank" rel="noopener"><?php echo e($site['github']); ?></a></p>
          <?php endif; ?>
          <?php if ($site['mail'] === '' && $site['github'] === ''): ?>
            <p class="fi-stat-line fi-stat-line--muted">还没有公开联系方式，去「站点设置 → 社交」里补充吧。</p>
          <?php endif; ?>
          <?php if (!empty($site['socials'])): ?>
            <div class="fl-footer-socials fl-footer-socials--aside">
              <?php foreach ($site['socials'] as $fs_soc): ?>
                <?php if (!is_array($fs_soc) || empty($fs_soc['url'])) continue; ?>
                <?php $fs_soc_img = function_exists('social_icon_url') ? social_icon_url(isset($fs_soc['icon']) ? $fs_soc['icon'] : '') : ''; ?>
                <?php $fs_soc_name = !empty($fs_soc['name']) ? (string) $fs_soc['name'] : '链接'; ?>
                <a href="<?php echo e($fs_soc['url']); ?>" target="_blank" rel="noopener" title="<?php echo e($fs_soc_name); ?>">
                  <?php if ($fs_soc_img !== ''): ?><img src="<?php echo e($fs_soc_img); ?>" alt="<?php echo e($fs_soc_name); ?>" loading="lazy"><?php else: ?><?php echo e(!empty($fs_soc['icon']) ? (string) $fs_soc['icon'] : '🔗'); ?><?php endif; ?>
                </a>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <div class="sidebar-card fl-card-surface">
        <p class="sidebar-card__title">站点信息</p>
        <div class="sidebar-card__body">
          <p class="fi-stat-line">站点名：<?php echo e($site['name']); ?></p>
          <?php if ($site['keywords'] !== ''): ?><p class="fi-stat-line">关键词：<?php echo e($site['keywords']); ?></p><?php endif; ?>
          <p class="fi-stat-line">程序：MoeZ <?php echo e($site['version']); ?></p>
          <?php if (!empty($fs_uptime['text'])): ?>
            <p class="fi-stat-line fi-stat-line--muted">本站已运行 <?php echo e($fs_uptime['text']); ?></p>
          <?php endif; ?>
        </div>
      </div>
    </aside>
  </div>
</div>

<?php include partial_path('footer.php'); ?>