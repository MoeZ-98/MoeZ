<?php
/**
 * 花墨 · Flowersink 模板 · 搜索结果页
 * （标签聚合路由 /tag/关键词 也复用本模板，此时 $kw 为标签名）
 * 可用变量：$posts $kw $pager $total $site $nav_cats
 */
$cur_p = 'search';
include partial_path('header.php');

$fs_kw      = isset($kw) ? (string) $kw : '';
$fs_total   = isset($total) ? (int) $total : 0;
$fs_side_on = fs_on('show_home_aside', '1');
?>
<div class="fi-screen">
  <?php echo fs_page_head('搜索', $fs_kw !== '' ? ('关键词「' . $fs_kw . '」共命中 ' . $fs_total . ' 篇文章') : '输入关键词，从这个站里翻出想看的字', '搜索'); ?>

  <form class="fl-search-page fl-card-surface" method="get" action="<?php echo e(base_url() . 'index.php'); ?>" role="search">
    <input type="hidden" name="p" value="search">
    <input type="search" name="q" value="<?php echo e($fs_kw); ?>" placeholder="输入关键词后回车…" aria-label="站内搜索">
    <button type="submit">搜索</button>
  </form>

  <div class="fl-shell">
    <div class="fl-content">
      <?php if ($fs_kw === ''): ?>
        <p class="fi-empty-note">输入关键词开始搜索吧～</p>
      <?php elseif (empty($posts)): ?>
        <p class="fi-empty-note">没有找到与「<?php echo e($fs_kw); ?>」相关的文章，换个词试试？</p>
      <?php else: ?>
        <div class="fi-post-grid">
          <?php foreach ($posts as $fs_p): ?><?php echo fs_card_html($fs_p); ?><?php endforeach; ?>
        </div>
        <?php echo isset($pager) ? $pager : ''; ?>
      <?php endif; ?>
    </div>

    <?php if ($fs_side_on): ?>
      <aside class="fl-aside"><?php echo fs_aside_html($site, fs_cats()); ?></aside>
    <?php endif; ?>
  </div>
</div>

<?php include partial_path('footer.php'); ?>