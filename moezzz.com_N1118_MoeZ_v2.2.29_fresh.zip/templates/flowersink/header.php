<?php
/**
 * 花墨 · Flowersink 模板 · 公共头部
 * 结构：吸顶导航（花墨站标 / 站内菜单 / 搜索 / RSS / 移动端菜单按钮）+ 打开主内容容器（由 footer.php 收尾）
 * 可用变量：$site $nav_cats；页面可在 include 本文件前设置 $cur_p
 */
require_once __DIR__ . '/_lib.php';

$cur       = isset($cur_p) ? (string) $cur_p : 'index';
$site      = fs_site(isset($site) ? $site : null);
$nav_cats  = (isset($nav_cats) && is_array($nav_cats)) ? $nav_cats : array();
$fs_accent = fs_accent();
$fs_icon   = fs_favicon($site);
$fs_menu   = fs_menu($cur, $nav_cats, isset($cat) ? $cat : null);
$fs_kw     = isset($kw) ? (string) $kw : '';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php echo seo_head(); ?>
<meta name="theme-color" content="<?php echo e($fs_accent); ?>">
<?php echo function_exists('moe_icon_links') ? moe_icon_links($fs_icon) : '<link rel="icon" href="' . e($fs_icon) . '">' . "\n" . '<link rel="apple-touch-icon" href="' . e($fs_icon) . '">' . "\n"; ?>
<link rel="alternate" type="application/rss+xml" title="<?php echo e($site['name']); ?>" href="<?php echo e(rss_url()); ?>">
<link rel="stylesheet" href="<?php echo e(theme_url('assets/style.css')); ?>?v=<?php echo e(MOE_VERSION); ?>">
<style>
:root{ --fs-accent: <?php echo e($fs_accent); ?>; }
</style>
</head>
<body class="fl-body">

<header class="fl-nav" id="fl-nav">
  <div class="fl-nav-inner">
    <a class="fl-brand" href="<?php echo e(home_url()); ?>">
      <span class="fl-brand-mark" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 2.6c2.3 2.5 3.7 4.8 3.7 7.1 0 2.1-1.7 3.6-3.7 3.6s-3.7-1.5-3.7-3.6c0-2.3 1.4-4.6 3.7-7.1Z"/><path d="M12 13.4c2.7 1.5 4.4 3.2 4.4 4.8 0 1.4-2 2.5-4.4 2.5s-4.4-1.1-4.4-2.5c0-1.6 1.7-3.3 4.4-4.8Z"/><path d="M4.2 8.4c3.3.2 5.8 1.4 7.1 3.3"/><path d="M19.8 8.4c-3.3.2-5.8 1.4-7.1 3.3"/></svg></span>
      <span class="fl-brand-name"><?php echo e($site['name']); ?></span>
    </a>

    <nav class="fl-menu" id="fl-menu" aria-label="站内导航">
      <?php foreach ($fs_menu as $m): ?>
        <a class="fl-menu-link<?php echo $m['active'] ? ' is-active' : ''; ?>" href="<?php echo e($m['url']); ?>"><?php echo e($m['title']); ?></a>
      <?php endforeach; ?>
    </nav>

    <div class="fl-tools">
      <form class="fl-search" method="get" action="<?php echo e(base_url() . 'index.php'); ?>" data-base="<?php echo e(base_url()); ?>" data-pretty="<?php echo is_pretty_url() ? '1' : '0'; ?>" role="search">
        <input type="hidden" name="p" value="search">
        <svg class="fl-search-ic" viewBox="0 0 24 24" aria-hidden="true"><circle cx="11" cy="11" r="6.6"/><path d="m16.4 16.4 4.1 4.1"/></svg>
        <input class="fl-search-input" type="search" name="q" value="<?php echo e($fs_kw); ?>" placeholder="搜索…" aria-label="站内搜索">
      </form>
      <a class="fl-tool" href="<?php echo e(rss_url()); ?>" target="_blank" rel="noopener" title="RSS 订阅" aria-label="RSS 订阅">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/><path d="M5 11a8 8 0 0 1 8 8"/><path d="M5 5a14 14 0 0 1 14 14"/></svg>
      </a>
      <button class="fl-tool fl-menu-toggle" type="button" id="fl-menu-toggle" aria-expanded="false" aria-controls="fl-menu" aria-label="展开站内菜单">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
      </button>
    </div>
  </div>
</header>

<main class="fl-main" id="fl-main">