<?php
/**
 * 花墨 · Flowersink 模板 · 内部函数库
 * 仅在模板内部使用，函数统一 fs_ 前缀，避免与程序核心函数冲突。
 * 兼容 PHP 7.2+（不使用箭头函数 / match / 空合并赋值以外的 7.4 语法）。
 */

/** 读取模板设置（委托程序 theme_opt，未声明时用传入的兜底默认值） */
if (!function_exists('fs_opt')) {
    function fs_opt($key, $default = '')
    {
        return theme_opt($key, $default);
    }
}

/** 布尔开关：仅 '1' 视为开启 */
if (!function_exists('fs_on')) {
    function fs_on($key, $default = '1')
    {
        return theme_opt($key, $default) === '1';
    }
}

/** 主色：校验 6 位十六进制，非法时回落花墨胭脂色 */
if (!function_exists('fs_accent')) {
    function fs_accent()
    {
        $c = trim((string) theme_opt('accent', '#b8768f'));
        return preg_match('/^#[0-9a-fA-F]{6}$/', $c) ? $c : '#b8768f';
    }
}

/** 字符长度 / 截取：mbstring 不可用时退回 UTF-8 正则，避免模板报错 */
if (!function_exists('fs_strlen')) {
    function fs_strlen($s)
    {
        $s = (string) $s;
        if (function_exists('mb_strlen')) return mb_strlen($s, 'UTF-8');
        return preg_match_all('/./us', $s, $m) ? count($m[0]) : strlen($s);
    }
}
if (!function_exists('fs_substr')) {
    function fs_substr($s, $start, $len = null)
    {
        $s = (string) $s;
        if (function_exists('mb_substr')) {
            return $len === null ? mb_substr($s, $start, null, 'UTF-8') : mb_substr($s, $start, $len, 'UTF-8');
        }
        preg_match_all('/./us', $s, $m);
        $chars = isset($m[0]) ? $m[0] : array();
        $slice = $len === null ? array_slice($chars, $start) : array_slice($chars, $start, $len);
        return implode('', $slice);
    }
}

/**
 * 站点信息兜底：前台路由会注入 $site，
 * 维护页等「站点信息尚未构建」的场景下用 setting() 组装同名结构，保证头部/底部可渲染。
 */
if (!function_exists('fs_site')) {
    function fs_site($site = null)
    {
        $base = array(
            'name'      => (string) setting('site_name', 'MoeZ'),
            'sub'       => (string) setting('site_sub', ''),
            'desc'      => (string) setting('site_desc', ''),
            'keywords'  => (string) setting('site_keywords', ''),
            'author'    => (string) setting('site_author', ''),
            /* 目录适配：不再写死跨主题路径，由统一层解析（default 基准 → 当前主题兜底） */
            'avatar'    => (string) setting('site_avatar',
                function_exists('moe_theme_asset')
                    ? (moe_theme_asset('assets/avatar.svg') ?: 'templates/default/assets/avatar.svg')
                    : 'templates/default/assets/avatar.svg'),
            'signature' => (string) setting('site_signature', ''),
            'footer'    => (string) setting('footer_text', ''),
            'mail'      => (string) setting('social_mail', ''),
            'github'    => (string) setting('social_github', ''),
            'bilibili'  => (string) setting('social_bilibili', ''),
            'weibo'     => (string) setting('social_weibo', ''),
            'twitter'   => (string) setting('social_twitter', ''),
            'rss'       => (string) setting('social_rss', ''),
            'socials'   => array(),
            'stats'     => array('posts' => 0, 'comments' => 0, 'views' => 0),
            'version'   => defined('MOE_VERSION') ? MOE_VERSION : '',
        );
        // 数据库不可用时静默降级，保证维护页等场景仍能渲染
        try {
            if (function_exists('moe_social_list')) $base['socials'] = (array) moe_social_list();
        } catch (Throwable $e) { /* 忽略 */ }
        try {
            if (function_exists('site_stats')) $base['stats'] = (array) site_stats();
        } catch (Throwable $e) { /* 忽略 */ }

        if (is_array($site)) {
            foreach ($site as $k => $v) $base[$k] = $v;
        }

        // 归一化：字符串键保证可拼接，社交 / 统计保证为数组
        $strKeys = array('name', 'sub', 'desc', 'keywords', 'author', 'avatar', 'signature',
                         'footer', 'mail', 'github', 'bilibili', 'weibo', 'twitter', 'rss', 'version');
        foreach ($strKeys as $k) {
            if (!isset($base[$k]) || !is_scalar($base[$k])) $base[$k] = '';
        }
        if (!is_array($base['socials'])) $base['socials'] = array();
        if (!is_array($base['stats']))   $base['stats'] = array();
        foreach (array('posts', 'comments', 'views') as $k) {
            if (!isset($base['stats'][$k]) || !is_numeric($base['stats'][$k])) $base['stats'][$k] = 0;
        }
        return $base;
    }
}

/** 站长头像：模板设置 → 站点头像 → 模板自带占位图 */
if (!function_exists('fs_avatar')) {
    function fs_avatar($site)
    {
        $path = trim((string) fs_opt('hero_avatar', ''));
        if ($path === '' && is_array($site) && !empty($site['avatar'])) $path = (string) $site['avatar'];
        return $path !== '' ? media_url($path) : theme_url('assets/avatar.svg');
    }
}

/** favicon：模板设置 → 站点头像 → 模板自带图标 */
if (!function_exists('fs_favicon')) {
    function fs_favicon($site)
    {
        $path = trim((string) fs_opt('site_icon', ''));
        if ($path === '' && is_array($site) && !empty($site['avatar'])) $path = (string) $site['avatar'];
        /* 目录适配：无自定义图标时交给统一层，主题文件缺失自动回退根 favicon.ico */
        if ($path === '') {
            return function_exists('moe_theme_icon')
                ? moe_theme_icon('', 'assets/favicon.svg')
                : theme_url('assets/favicon.svg');
        }
        return media_url($path);
    }
}

/** 无封面时的渐变占位（按文章 id 稳定取色，纸感花墨色系） */
if (!function_exists('fs_gradient')) {
    function fs_gradient($seed = 0)
    {
        $list = array(
            'linear-gradient(135deg,#f3dfe4 0%,#fbf3f0 55%,#e6e0ee 100%)',
            'linear-gradient(135deg,#e7e2f0 0%,#f8f4fb 55%,#f2e2e6 100%)',
            'linear-gradient(135deg,#e2ece8 0%,#f4faf7 55%,#efe3e8 100%)',
            'linear-gradient(135deg,#f0e6dc 0%,#fdf8f2 55%,#e7e2ee 100%)',
            'linear-gradient(135deg,#e4e8f2 0%,#f5f7fc 55%,#f5e6ea 100%)',
            'linear-gradient(135deg,#f5e2ea 0%,#fdf5f7 55%,#e3e9ef 100%)',
        );
        $i = abs((int) $seed) % count($list);
        return $list[$i];
    }
}

/** 文章封面：返回 array('url' => 图片地址, 'style' => 无图时的渐变) */
if (!function_exists('fs_cover')) {
    function fs_cover($post)
    {
        $cover = function_exists('post_cover') ? post_cover($post) : (isset($post['cover']) ? $post['cover'] : '');
        if (is_string($cover) && trim($cover) !== '') {
            return array('url' => media_url($cover), 'style' => '');
        }
        return array('url' => '', 'style' => fs_gradient(isset($post['id']) ? (int) $post['id'] : 0));
    }
}

/** 数字缩写：12800 → 1.3w */
if (!function_exists('fs_num')) {
    function fs_num($n)
    {
        $n = (int) $n;
        if ($n >= 10000) return round($n / 10000, 1) . 'w';
        if ($n >= 1000)  return round($n / 1000, 1) . 'k';
        return (string) $n;
    }
}

/** 'YYYY-MM' → 'YYYY 年 M 月' */
if (!function_exists('fs_month_label')) {
    function fs_month_label($ym)
    {
        $ym = trim((string) $ym);
        if (preg_match('/^(\d{4})-(\d{1,2})$/', $ym, $m)) {
            return $m[1] . ' 年 ' . (int) $m[2] . ' 月';
        }
        return $ym;
    }
}

/** 分类列表（含已发布文章数），查询失败返回空数组 */
if (!function_exists('fs_cats')) {
    function fs_cats()
    {
        try {
            return rows('SELECT c.id, c.name, c.slug, (SELECT COUNT(*) FROM ' . moe_table('posts')
                . " p WHERE p.category_id = c.id AND p.type='post' AND p.status='published') AS cnt"
                . ' FROM ' . moe_table('categories') . ' c ORDER BY c.sort, c.id');
        } catch (Throwable $e) {
            return array();
        }
    }
}

/** 「点滴」入口是否可用：模板设置的点滴分类别名真实存在 */
if (!function_exists('fs_life_enabled')) {
    function fs_life_enabled()
    {
        static $ok = null;
        if ($ok !== null) return $ok;
        $slug = trim((string) fs_opt('life_slug', 'life'));
        if ($slug === '') return $ok = false;
        try {
            return $ok = (bool) row('SELECT id FROM ' . moe_table('categories') . ' WHERE slug = ? LIMIT 1', array($slug));
        } catch (Throwable $e) {
            return $ok = false;
        }
    }
}

/** 导航菜单：站内固定入口 + 全部分类；$cur 为当前路由，$cat 用于高亮分类 */
if (!function_exists('fs_menu')) {
    function fs_menu($cur, $nav_cats, $cat = null)
    {
        $cur = (string) $cur;
        $items = array(
            array('key' => 'index',   'title' => '首页', 'url' => home_url(),                  'cat_id' => 0),
            array('key' => 'archive', 'title' => '归档', 'url' => base_url() . 'archives',     'cat_id' => 0),
            array('key' => 'article', 'title' => '写作', 'url' => base_url() . 'blog/article', 'cat_id' => 0),
        );
        if (fs_life_enabled()) {
            $items[] = array('key' => 'life', 'title' => '点滴', 'url' => base_url() . 'life', 'cat_id' => 0);
        }
        $items[] = array('key' => 'link',  'title' => '友链', 'url' => base_url() . 'link',  'cat_id' => 0);
        $items[] = array('key' => 'about', 'title' => '关于', 'url' => base_url() . 'about', 'cat_id' => 0);

        $catId = (is_array($cat) && isset($cat['id'])) ? (int) $cat['id'] : 0;
        foreach ((array) $nav_cats as $c) {
            if (!is_array($c) || empty($c['name'])) continue;
            $items[] = array(
                'key'    => 'category',
                'title'  => (string) $c['name'],
                'url'    => cat_url($c),
                'cat_id' => isset($c['id']) ? (int) $c['id'] : 0,
            );
        }

        foreach ($items as $i => $it) {
            $active = false;
            if ($it['key'] === 'category') {
                $active = ($cur === 'category' && $catId > 0 && $catId === (int) $it['cat_id']);
            } else {
                $active = ($it['key'] === $cur);
            }
            $items[$i]['active'] = $active;
        }
        return $items;
    }
}

/** 页面标题块（面包屑 + 标题 + 副标题），列表类页面共用 */
if (!function_exists('fs_page_head')) {
    function fs_page_head($title, $sub = '', $crumb = '')
    {
        $html  = '<section class="fl-page-head fl-card-surface">';
        if ($crumb !== '') {
            $html .= '<p class="fl-crumb"><a href="' . e(home_url()) . '">首页</a><span>/</span>'
                   . '<span class="fl-crumb-cur">' . e($crumb) . '</span></p>';
        }
        $html .= '<h1 class="fl-page-title">' . e($title) . '</h1>';
        if ($sub !== '') $html .= '<p class="fl-page-sub">' . e($sub) . '</p>';
        return $html . '</section>';
    }
}

/** 文章卡片（首页 / 分类 / 搜索 / 写作列表共用同一套版式） */
if (!function_exists('fs_card_html')) {
    function fs_card_html($p, $cat = null)
    {
        if (!is_array($p) || empty($p['title'])) return '';
        $cover = fs_cover($p);
        $url   = post_url($p);
        $title = (string) $p['title'];

        // 分类：优先用列表 SQL JOIN 出来的 cat_name / cat_slug / cat_id，其次用传入的 $cat
        $catName = '';
        $catUrl  = '';
        if (!empty($p['cat_name'])) {
            $catName = (string) $p['cat_name'];
            $catUrl  = cat_url(array(
                'id'   => isset($p['cat_id']) ? (int) $p['cat_id'] : 0,
                'name' => $catName,
                'slug' => isset($p['cat_slug']) ? (string) $p['cat_slug'] : '',
            ));
        } elseif (is_array($cat) && !empty($cat['name'])) {
            $catName = (string) $cat['name'];
            $catUrl  = cat_url($cat);
        }

        $fmt  = isset($p['content_format']) && $p['content_format'] !== '' ? $p['content_format'] : 'html';
        $rt   = isset($p['content']) ? (int) reading_time($p) : 0;

        $html  = '<article class="fi-post-card">';
        if ($cover['url'] !== '') {
            $html .= '<a class="fi-post-cover" href="' . e($url) . '" style="background-image:url(' . e($cover['url']) . ')">';
        } else {
            $html .= '<a class="fi-post-cover is-blank" href="' . e($url) . '" style="background:' . e($cover['style']) . '">';
            $html .= '<span class="fi-cover-ink" aria-hidden="true">' . e(fs_substr($title, 0, 1)) . '</span>';
        }
        if (!empty($p['is_top'])) $html .= '<span class="fi-pin">置顶</span>';
        $html .= '</a>';

        $html .= '<div class="fi-post-body">';
        $html .= '<h3 class="fi-post-title"><a href="' . e($url) . '">' . e($title) . '</a></h3>';
        $html .= '<p class="fi-post-excerpt">' . e(function_exists('post_excerpt') ? post_excerpt($p, 96) : '') . '</p>';
        $html .= '<div class="fi-post-meta">';
        if ($catName !== '') $html .= '<a class="fi-chip" href="' . e($catUrl) . '">' . e($catName) . '</a>';
        if (!empty($p['created_at'])) $html .= '<span class="fi-meta-item">' . e(format_time($p['created_at'], 'Y-m-d')) . '</span>';
        if (!empty($p['views']))      $html .= '<span class="fi-meta-item">' . (int) $p['views'] . ' 阅读</span>';
        if ($rt > 0)                  $html .= '<span class="fi-meta-item">约 ' . $rt . ' 分钟</span>';
        $html .= '</div></div></article>';
        return $html;
    }
}

/** 右侧栏内容（站长卡 / 分类 / 站内数据），首页与各列表页共用保持视觉一致 */
if (!function_exists('fs_aside_html')) {
    function fs_aside_html($site, $cats = array())
    {
        $name = isset($site['name']) ? (string) $site['name'] : '';
        $sub  = trim((string) fs_opt('me_sub', ''));
        if ($sub === '') $sub = isset($site['signature']) && $site['signature'] !== '' ? (string) $site['signature'] : (isset($site['sub']) ? (string) $site['sub'] : '');
        $meName = isset($site['author']) && $site['author'] !== '' ? (string) $site['author'] : $name;
        $avatar = fs_avatar($site);
        $stats  = isset($site['stats']) && is_array($site['stats']) ? $site['stats'] : array('posts' => 0, 'comments' => 0, 'views' => 0);
        $uptime = fs_uptime();

        $html  = '<div class="me-inner">';
        $html .= '<span class="me-side-avatar"><img src="' . e($avatar) . '" alt="' . e($meName) . '" loading="lazy"></span>';
        $html .= '<div class="me_box fl-card-surface">';
        $html .= '<p class="me-name">' . e($meName) . '</p>';
        $html .= '<span class="me-side-sub">' . e($sub) . '</span>';
        $html .= '</div></div>';

        if (!empty($cats)) {
            $html .= '<div class="sidebar-card fl-card-surface">';
            $html .= '<p class="sidebar-card__title">分类</p>';
            $html .= '<div class="sidebar-card__body">';
            foreach ((array) $cats as $c) {
                if (!is_array($c) || empty($c['name'])) continue;
                $html .= '<a class="related-sidebar__item" href="' . e(cat_url($c)) . '">'
                       . '<span class="related-sidebar__title">' . e($c['name']) . '</span>'
                       . '<span class="related-sidebar__date">' . (int) (isset($c['cnt']) ? $c['cnt'] : 0) . ' 篇</span></a>';
            }
            $html .= '</div></div>';
        }

        $html .= '<div class="sidebar-card fl-card-surface">';
        $html .= '<p class="sidebar-card__title">小站资讯</p>';
        $html .= '<div class="sidebar-card__body">';
        $html .= '<p class="fi-stat-line">文章 <b>' . (int) $stats['posts'] . '</b> · 评论 <b>' . (int) $stats['comments'] . '</b> · 浏览 <b>' . (int) $stats['views'] . '</b></p>';
        if (!empty($uptime['text'])) $html .= '<p class="fi-stat-line fi-stat-line--muted">本站已运行 ' . e($uptime['text']) . '</p>';
        $html .= '</div></div>';
        return $html;
    }
}

/** 建站时长（模板设置「建站日期」，留空从最早一篇文章算起） */
if (!function_exists('fs_uptime')) {
    function fs_uptime()
    {
        $from = trim((string) fs_opt('run_from', ''));
        if ($from === '') {
            try {
                $from = (string) one('SELECT MIN(created_at) FROM ' . moe_table('posts') . " WHERE type='post' AND status='published'");
            } catch (Throwable $e) {
                $from = '';
            }
        }
        $ts = $from !== '' ? strtotime($from) : 0;
        if (!$ts || $ts > time()) return array('days' => 0, 'text' => '');
        $diff  = time() - $ts;
        $days  = (int) floor($diff / 86400);
        $hours = (int) floor(($diff % 86400) / 3600);
        $mins  = (int) floor(($diff % 3600) / 60);
        return array('days' => $days, 'text' => $days . ' 天 ' . sprintf('%02d 小时 %02d 分', $hours, $mins));
    }
}

/** 友链列表（仅已通过审核），查询失败返回空数组 */
if (!function_exists('fs_links')) {
    function fs_links($limit = 0)
    {
        $limit = (int) $limit;
        try {
            $sql = 'SELECT * FROM ' . moe_table('links') . " WHERE status='approved' ORDER BY sort, id";
            if ($limit > 0) $sql .= ' LIMIT ' . $limit;
            $list = rows($sql);
        } catch (Throwable $e) {
            return array();
        }
        $out = array();
        foreach ((array) $list as $l) {
            if (!is_array($l) || empty($l['url'])) continue;
            $out[] = $l;
        }
        return $out;
    }
}