<?php
/**
 * 花墨 · Flowersink 模板 · 归档时间线（/archives）
 * 按年份分组的时间线，每条含日期、标题、预计阅读时长
 * 可用变量：$groups（年份 => 文章行数组）$total $site $nav_cats
 */
$cur_p = 'archive';
include partial_path('header.php');

$fs_total   = isset($total) ? (int) $total : 0;
$fs_groups  = (isset($groups) && is_array($groups)) ? $groups : array();
?>
<div class="fi-screen">
  <?php echo fs_page_head('归档', '共 ' . $fs_total . ' 篇文章，按年份倒序排列', '归档'); ?>

  <?php if (empty($fs_groups)): ?>
    <p class="fi-empty-note">还没有文章可以归档～</p>
  <?php else: ?>
    <?php foreach ($fs_groups as $fs_year => $fs_items): ?>
      <section class="fi-group fl-card-surface">
        <div class="fl-section-title">
          <h2><span class="fi-group-year"><?php echo e($fs_year); ?></span></h2>
          <span class="fl-section-count"><?php echo count((array) $fs_items); ?> 篇</span>
        </div>
        <ul class="fi-timeline">
          <?php foreach ((array) $fs_items as $fs_p): ?>
            <?php if (!is_array($fs_p) || empty($fs_p['title'])) continue; ?>
            <?php $fs_rt = !empty($fs_p['content']) ? (int) reading_time($fs_p) : 0; ?>
            <li class="fi-timeline-item">
              <span class="fi-timeline-date"><?php echo e(format_time($fs_p['created_at'], 'm-d')); ?></span>
              <a class="fi-timeline-title" href="<?php echo e(post_url($fs_p)); ?>"><?php echo e($fs_p['title']); ?></a>
              <?php if ($fs_rt > 0): ?><span class="fi-timeline-extra">约 <?php echo $fs_rt; ?> 分钟</span><?php endif; ?>
            </li>
          <?php endforeach; ?>
        </ul>
      </section>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php include partial_path('footer.php'); ?>