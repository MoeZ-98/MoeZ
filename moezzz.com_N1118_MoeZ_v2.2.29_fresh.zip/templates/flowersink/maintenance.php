<?php
/**
 * 花墨 · Flowersink 模板 · 维护页
 * 后台「站点状态」非 open 时由 index.php 直接渲染（此时 $site / $nav_cats 尚未构建，
 * 头部与底部会自行用 setting() 兜底，保证页面仍能正常显示）。
 * 可用变量：（无）
 */
$cur_p = 'maintenance';
include partial_path('header.php');
?>
<div class="fi-screen">
  <section class="fi-404 fl-card-surface">
    <span class="fi-404-mark" aria-hidden="true">
      <svg viewBox="0 0 24 24"><path d="M12 3.4c2.4 2.2 3.8 4.2 3.8 6.2 0 1.9-1.7 3.2-3.8 3.2s-3.8-1.3-3.8-3.2c0-2 1.4-4 3.8-6.2Z"/><path d="M12 14.2c2.5 1.2 4.2 2.6 4.2 3.9 0 1.2-1.9 2.1-4.2 2.1s-4.2-.9-4.2-2.1c0-1.3 1.7-2.7 4.2-3.9Z"/></svg>
    </span>
    <p class="fi-404-code">维护中</p>
    <h1 class="fi-404-title">小站正在打理中</h1>
    <p class="fi-404-tip"><?php echo e(setting('site_name', 'MoeZ')); ?> 正在修整花草，稍后就会回来，感谢你的耐心等待。</p>
    <?php $fs_mail = trim((string) setting('social_mail', '')); ?>
    <?php if ($fs_mail !== ''): ?>
      <p class="fi-404-tip">急事可以邮件联系：<a href="mailto:<?php echo e($fs_mail); ?>"><?php echo e($fs_mail); ?></a></p>
    <?php endif; ?>
    <div class="fi-404-actions">
      <a class="fl-button" href="<?php echo e(rss_url()); ?>">订阅 RSS</a>
    </div>
  </section>
</div>
<?php include partial_path('footer.php'); ?>