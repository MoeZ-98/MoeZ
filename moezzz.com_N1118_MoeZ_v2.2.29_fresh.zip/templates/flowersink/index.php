<?php
/**
 * 花墨 · Flowersink 模板 · 首页
 * 花墨问候卡 + 最新文章卡片列表 + 分页 + 右侧栏（站长卡 / 分类 / 小站资讯）
 * 可用变量：$posts $pager $page $total $site $nav_cats
 */
$cur_p = 'index';
include partial_path('header.php');

$fs_page     = isset($page) ? max(1, (int) $page) : 1;
$fs_total    = isset($total) ? (int) $total : (is_array($posts) ? count($posts) : 0);
$fs_side_on  = fs_on('show_home_aside', '1');
$fs_welcome  = '';
if (function_exists('moe_welcome_line')) {
    $fs_welcome = $fs_page > 1 ? '第 ' . $fs_page . ' 页 · 继续翻翻往期的花与墨' : (string) moe_welcome_line();
}
?>
<div class="fi-screen">
  <section class="fl-hero fl-card-surface">
    <img class="fl-hero-avatar" src="<?php echo e(fs_avatar($site)); ?>" alt="<?php echo e($site['name']); ?>" loading="lazy">
    <div class="fl-hero-body">
      <?php if ($fs_welcome !== ''): ?><p class="fl-hero-line"><?php echo e($fs_welcome); ?></p><?php endif; ?>
      <h1 class="fl-hero-title"><?php echo e($site['name']); ?></h1>
      <?php if ($site['sub'] !== ''): ?><p class="fl-hero-sub"><?php echo e($site['sub']); ?></p><?php endif; ?>
      <?php if ($site['desc'] !== ''): ?><p class="fl-hero-desc"><?php echo e($site['desc']); ?></p><?php endif; ?>
      <div class="fl-hero-stats">
        <span><b><?php echo (int) $site['stats']['posts']; ?></b>文章</span>
        <span><b><?php echo (int) $site['stats']['comments']; ?></b>评论</span>
        <span><b><?php echo (int) $site['stats']['views']; ?></b>浏览</span>
      </div>
    </div>
  </section>

  <div class="fl-shell">
    <div class="fl-content">
      <div class="fl-section-title">
        <h2>最新文章</h2>
        <span class="fl-section-count">共 <?php echo $fs_total; ?> 篇</span>
        <a class="fl-more" href="<?php echo e(rss_url()); ?>" target="_blank" rel="noopener">RSS 订阅 →</a>
      </div>

      <?php if (empty($posts)): ?>
        <p class="fi-empty-note">还没有文章，去后台写一篇吧～</p>
      <?php else: ?>
        <div class="fi-post-grid">
          <?php foreach ($posts as $fs_p): ?><?php echo fs_card_html($fs_p); ?><?php endforeach; ?>
        </div>
        <?php echo isset($pager) ? $pager : ''; ?>
      <?php endif; ?>
    </div>

    <?php if ($fs_side_on): ?>
      <aside class="fl-aside"><?php echo fs_aside_html($site, fs_cats()); ?></aside>
    <?php endif; ?>
  </div>
</div>

<?php include partial_path('footer.php'); ?>