<?php
/**
 * 花墨 · Flowersink 模板 · 独立页面
 * 标题 + 元信息 + 正文（与文章详情页共用同一套纸感排版）
 * 可用变量：$page（页面对象）$site $nav_cats
 */
$cur_p = 'page';
include partial_path('header.php');

$fs_fmt   = isset($page['content_format']) && $page['content_format'] !== '' ? $page['content_format'] : 'html';
$fs_words = !empty($page['content']) ? (int) content_words($page['content'], $fs_fmt) : 0;
?>
<div class="fi-screen fi-page--flush">
  <div class="fl-shell fl-shell--single">
    <article class="fl-content fi-article fl-card-surface">
      <div class="article-topbar">
        <a class="article-back" href="<?php echo e(home_url()); ?>">
          <svg viewBox="0 0 1024 1024" aria-hidden="true"><path d="M724 218.3 436.6 505.7l287.4 287.4a32 32 0 0 1-45.3 45.3L368.7 528.3a32 32 0 0 1 0-45.3L678.7 173a32 32 0 0 1 45.3 45.3z" fill="currentColor"/></svg>
          <span>返回首页</span>
        </a>
      </div>

      <h1 class="article-title"><?php echo e($page['title']); ?></h1>
      <div class="article-meta">
        <span class="article-meta-stat"><svg class="meta-ico" viewBox="0 0 1024 1024" aria-hidden="true"><path d="M512 128a384 384 0 1 0 0 768 384 384 0 0 0 0-768z m0 704a320 320 0 0 1 0-640 320 320 0 0 1 0 640z" fill="currentColor"/><path d="M516 300h-56v256l196 118 28-46-168-100V300z" fill="currentColor"/></svg>&nbsp;<?php echo e(format_time($page['created_at'], 'Y年m月d日')); ?></span>
        <?php if (!empty($page['updated_at']) && substr((string) $page['updated_at'], 0, 10) !== substr((string) $page['created_at'], 0, 10)): ?>
          <span class="article-meta-sep">·</span>
          <span class="article-meta-stat">更新于 <?php echo e(format_time($page['updated_at'], 'Y-m-d')); ?></span>
        <?php endif; ?>
        <?php if (!empty($page['views'])): ?>
          <span class="article-meta-sep">·</span>
          <span class="article-meta-stat"><?php echo (int) $page['views']; ?> 次阅读</span>
        <?php endif; ?>
        <?php if ($fs_words > 0): ?>
          <span class="article-meta-sep">·</span>
          <span class="article-meta-stat"><?php echo $fs_words; ?> 字</span>
        <?php endif; ?>
      </div>

      <div class="prose" id="prose"><?php echo render_content(isset($page['content']) ? $page['content'] : '', $fs_fmt); ?></div>
    </article>
  </div>
</div>

<?php include partial_path('footer.php'); ?>