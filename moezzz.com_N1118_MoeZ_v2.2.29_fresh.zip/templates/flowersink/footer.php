<?php
/**
 * 花墨 · Flowersink 模板 · 公共底部
 * 结构：三栏页脚（花墨名片 / 站内导航 / 推荐友链）+ 版权行，
 * 并收尾 header.php 打开的主内容容器；内含回到顶部、移动菜单、
 * 伪静态搜索改写与评论 / 友链申请 AJAX 提交等公共脚本。
 */
require_once __DIR__ . '/_lib.php';
$site      = fs_site(isset($site) ? $site : null);
$fs_icp    = trim((string) fs_opt('icp', ''));
$fs_uptime = fs_uptime();
$fs_friends = fs_links(4);
$fs_life_on = fs_life_enabled();
?>
</main>

<footer class="fl-footer">
  <div class="fl-footer-inner">
    <div class="fl-footer-col fl-footer-col--brand">
      <p class="fl-footer-title"><?php echo e($site['name']); ?></p>
      <?php if ($site['desc'] !== ''): ?><p class="fl-footer-desc"><?php echo e($site['desc']); ?></p><?php endif; ?>
      <div class="fl-footer-socials">
        <?php if (!empty($site['socials'])): ?>
          <?php foreach ($site['socials'] as $fs_soc): ?>
            <?php if (!is_array($fs_soc) || empty($fs_soc['url'])) continue; ?>
            <?php $fs_soc_img = function_exists('social_icon_url') ? social_icon_url(isset($fs_soc['icon']) ? $fs_soc['icon'] : '') : ''; ?>
            <?php $fs_soc_name = !empty($fs_soc['name']) ? (string) $fs_soc['name'] : '链接'; ?>
            <a href="<?php echo e($fs_soc['url']); ?>" target="_blank" rel="noopener" title="<?php echo e($fs_soc_name); ?>">
              <?php if ($fs_soc_img !== ''): ?>
                <img src="<?php echo e($fs_soc_img); ?>" alt="<?php echo e($fs_soc_name); ?>" loading="lazy">
              <?php else: ?>
                <?php echo e(!empty($fs_soc['icon']) ? (string) $fs_soc['icon'] : '🔗'); ?>
              <?php endif; ?>
            </a>
          <?php endforeach; ?>
        <?php endif; ?>
        <a href="<?php echo e(rss_url()); ?>" target="_blank" rel="noopener" title="RSS 订阅">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"/><path d="M5 11a8 8 0 0 1 8 8"/><path d="M5 5a14 14 0 0 1 14 14"/></svg>
        </a>
      </div>
    </div>

    <div class="fl-footer-col">
      <p class="fl-footer-head">站内导航</p>
      <ul class="fl-footer-links">
        <li><a href="<?php echo e(home_url()); ?>">首页</a></li>
        <li><a href="<?php echo e(base_url() . 'archives'); ?>">归档</a></li>
        <li><a href="<?php echo e(base_url() . 'blog/article'); ?>">写作</a></li>
        <?php if ($fs_life_on): ?><li><a href="<?php echo e(base_url() . 'life'); ?>">点滴</a></li><?php endif; ?>
        <li><a href="<?php echo e(base_url() . 'link'); ?>">友链</a></li>
        <li><a href="<?php echo e(base_url() . 'about'); ?>">关于</a></li>
        <li><a href="<?php echo e(search_url('')); ?>">搜索</a></li>
        <li><a href="<?php echo e(sitemap_url()); ?>">Sitemap</a></li>
      </ul>
    </div>

    <div class="fl-footer-col">
      <p class="fl-footer-head">推荐友链</p>
      <?php if (!empty($fs_friends)): ?>
        <ul class="fl-footer-links">
          <?php foreach ($fs_friends as $fs_l): ?>
            <li><a href="<?php echo e($fs_l['url']); ?>" target="_blank" rel="noopener nofollow" title="<?php echo e($fs_l['name']); ?>"><?php echo e($fs_l['name']); ?></a></li>
          <?php endforeach; ?>
        </ul>
      <?php else: ?>
        <p class="fl-footer-tip">还没有友链，去 <a href="<?php echo e(base_url() . 'link'); ?>">友链页</a> 申请第一条吧～</p>
      <?php endif; ?>
    </div>
  </div>

  <div class="fl-footer-bottom">
    <span class="fl-copy"><?php echo $site['footer'] !== '' ? e($site['footer']) : '© ' . date('Y') . ' ' . e($site['name']); ?></span>
    <?php if ($fs_icp !== ''): ?><span class="fl-icp"><?php echo e($fs_icp); ?></span><?php endif; ?>
    <span class="fl-powered">Powered by MoeZ <?php echo e($site['version']); ?> · 模板 花墨 Flowersink</span>
    <?php if ($fs_uptime['text'] !== ''): ?><span class="fl-uptime">本站已运行 <?php echo e($fs_uptime['text']); ?></span><?php endif; ?>
  </div>
</footer>

<button class="fl-top" type="button" id="fl-top" aria-label="回到顶部" title="回到顶部">
  <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 19V6"/><path d="m6 12 6-6 6 6"/></svg>
</button>

<script>
(function () {
  /* 回到顶部 */
  var top = document.getElementById('fl-top');
  function syncTop() {
    if (!top) return;
    if (window.scrollY > 320) top.classList.add('is-show'); else top.classList.remove('is-show');
  }
  window.addEventListener('scroll', syncTop, { passive: true });
  syncTop();
  if (top) top.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });

  /* 移动端菜单 */
  var toggle = document.getElementById('fl-menu-toggle');
  var nav = document.getElementById('fl-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }

  /* 伪静态搜索：改写成 /search/关键词 */
  var sf = document.querySelector('.fl-search');
  if (sf && sf.getAttribute('data-pretty') === '1') {
    sf.addEventListener('submit', function (ev) {
      var q = sf.querySelector('input[name=q]');
      if (!q || !q.value.trim()) { ev.preventDefault(); return; }
      ev.preventDefault();
      location.href = sf.getAttribute('data-base') + 'search/' + encodeURIComponent(q.value.trim());
    });
  }

  /* 评论 / 友链申请：统一 AJAX 提交（表单本身仍可在无 JS 时正常 POST） */
  document.addEventListener('submit', function (ev) {
    var form = ev.target;
    if (!form || !form.classList) return;
    var isComment = form.classList.contains('comment-form');
    var isApply = form.classList.contains('fl-apply-form');
    if (!isComment && !isApply) return;
    if (!form.action) return;
    ev.preventDefault();

    var btn = form.querySelector('button[type=submit]');
    var hint = form.querySelector('.comment-form-hint') || form.querySelector('.fl-form-hint');
    if (btn) btn.disabled = true;
    var idle = btn ? btn.textContent : '';

    fetch(form.action, { method: 'POST', body: new FormData(form), credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        var ok = !!(d && d.ok);
        var msg = (d && d.msg) ? d.msg : (ok ? '提交成功' : '提交失败');
        if (hint) {
          hint.textContent = msg;
          hint.classList.remove('is-ok', 'is-err');
          hint.classList.add(ok ? 'is-ok' : 'is-err');
        }
        if (ok) {
          form.reset();
          setTimeout(function () { location.reload(); }, 900);
        } else {
          if (btn) { btn.disabled = false; btn.textContent = idle; }
          if (!hint) window.alert(msg);
        }
      })
      .catch(function () {
        var msg = '网络异常，请稍后再试';
        if (hint) {
          hint.textContent = msg;
          hint.classList.remove('is-ok');
          hint.classList.add('is-err');
        } else {
          window.alert(msg);
        }
        if (btn) { btn.disabled = false; btn.textContent = idle; }
      });
  });
})();
</script>
<?php if (!empty($page_script)) echo $page_script; ?>
</body>
</html>