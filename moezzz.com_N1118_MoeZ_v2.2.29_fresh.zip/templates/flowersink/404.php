<?php
/**
 * 花墨 · Flowersink 模板 · 404
 * 路由未命中时输出（moe_404() 已设置 404 状态码与 noindex）
 * 可用变量：$site $nav_cats
 */
$cur_p = '404';
include partial_path('header.php');
?>
<div class="fi-screen">
  <section class="fi-404 fl-card-surface">
    <span class="fi-404-mark" aria-hidden="true">
      <svg viewBox="0 0 24 24"><path d="M12 2.6c2.3 2.5 3.7 4.8 3.7 7.1 0 2.1-1.7 3.6-3.7 3.6s-3.7-1.5-3.7-3.6c0-2.3 1.4-4.6 3.7-7.1Z"/><path d="M12 13.4c2.7 1.5 4.4 3.2 4.4 4.8 0 1.4-2 2.5-4.4 2.5s-4.4-1.1-4.4-2.5c0-1.6 1.7-3.3 4.4-4.8Z"/><path d="M4.2 8.4c3.3.2 5.8 1.4 7.1 3.3"/><path d="M19.8 8.4c-3.3.2-5.8 1.4-7.1 3.3"/></svg>
    </span>
    <p class="fi-404-code">404</p>
    <h1 class="fi-404-title">这朵花好像没有开在这里</h1>
    <p class="fi-404-tip">你要找的内容不存在、被移动或删除了，也可能是链接拼错了一个字。</p>
    <div class="fi-404-actions">
      <a class="fl-button fl-button--solid" href="<?php echo e(home_url()); ?>">回到首页</a>
      <a class="fl-button" href="<?php echo e(base_url() . 'archives'); ?>">看看归档</a>
      <a class="fl-button" href="<?php echo e(base_url() . 'blog/article'); ?>">全部文章</a>
    </div>
  </section>
</div>
<?php include partial_path('footer.php'); ?>