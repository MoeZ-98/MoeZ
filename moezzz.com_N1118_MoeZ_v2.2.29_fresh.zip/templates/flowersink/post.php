<?php
/**
 * 花墨 · Flowersink 模板 · 文章页（严格复刻 flower-blog-detail）
 * 阅读进度条 + 顶栏返回 + 标题/元信息 + 正文 + 版权声明 + 评论 + 侧栏（头像卡/目录/相关文章）
 * 可用变量：$post $cat $prev $next $comments $site
 */
$cur_p = 'post';
include partial_path('header.php');
$opt_toc = theme_opt('show_toc', '1') === '1';
$opt_related = theme_opt('show_related', '1') === '1';
$me_avatar = theme_opt('hero_avatar', '');
/* 目录适配：占位图缺失时由统一层回退根图标 */
if ($me_avatar === '') $me_avatar = $site['avatar']
    ? media_url($site['avatar'])
    : (function_exists('moe_theme_icon') ? moe_theme_icon('', 'assets/favicon.svg') : theme_url('assets/favicon.svg'));
$me_name = $site['author'] !== '' ? $site['author'] : $site['name'];

/* 正文渲染 + 标题锚点 + 图片淡入 */
$fs_html = render_content($post['content'], isset($post['content_format']) ? $post['content_format'] : 'markdown');
/* 提取 h2/h3 生成目录 */
$toc = array();
if (preg_match_all('/<h([23])[^>]*>(.*?)<\/h\1>/s', $fs_html, $mm, PREG_SET_ORDER)) {
    foreach ($mm as $k => $m) {
        $text = trim(strip_tags($m[2]));
        if ($text === '') continue;
        $id = 'heading-' . ($k + 1);
        $toc[] = array('level' => (int)$m[1], 'text' => $text, 'id' => $id);
    }
    /* 给正文标题注入 id（按出现顺序） */
    $fs_hidx = 0;
    $fs_html = preg_replace_callback('/<h([23])([^>]*)>/s', function ($m) use (&$fs_hidx) {
        $fs_hidx++;
        return '<h' . $m[1] . $m[2] . ' id="heading-' . $fs_hidx . '">';
    }, $fs_html);
}
/* 相关文章：同分类最新 4 篇 */
$related = array();
if ($opt_related && $post['category_id']) {
    try {
        $related = rows('SELECT id, title, slug, type, category_id, url_num, created_at FROM ' . moe_table('posts')
            . " WHERE category_id = ? AND type='post' AND status='published' AND id <> ? ORDER BY created_at DESC LIMIT 4",
            array($post['category_id'], $post['id']));
    } catch (Throwable $e) { $related = array(); }
}
$words = (int)content_words($post['content'], isset($post['content_format']) ? $post['content_format'] : 'markdown');
?>
<div class="blog-detail-page article fi-screen fi-page--flush">
  <div class="reading-progress-bar" id="readingBar"></div>
  <div class="blog-detail-shell">
    <div class="content blog-detail-content">
      <div class="article-topbar">
        <button type="button" class="article-back" onclick="history.length>1?history.back():location.href='<?php echo e(home_url()); ?>'">
          <svg viewBox="0 0 1024 1024" aria-hidden="true"><path d="M724 218.3 436.6 505.7l287.4 287.4a32 32 0 0 1-45.3 45.3L368.7 528.3a32 32 0 0 1 0-45.3L678.7 173a32 32 0 0 1 45.3 45.3z" fill="currentColor"/></svg>
          <span>返回</span>
        </button>
        <?php if (!empty($cat)): ?><span class="article-topbar__hint"><?php echo e($cat['name']); ?></span><?php endif; ?>
      </div>
      <div class="article-title"><?php echo e($post['title']); ?></div>
      <div class="article-meta">
        <?php if (!empty($cat)): ?><span class="article-meta-stat"><?php echo e($cat['name']); ?></span><span class="article-meta-sep">·</span><?php endif; ?>
        <span class="article-meta-stat" title="阅读"><svg class="meta-ico" viewBox="0 0 1024 1024" aria-hidden="true"><path d="M942.2 486.2C847.4 286.5 704.1 186 512 186c-192.2 0-335.4 100.5-430.2 300.3a60.3 60.3 0 0 0 0 51.5C176.6 737.5 319.9 838 512 838c192.2 0 335.4-100.5 430.2-300.3 7.7-16.2 7.7-35.2 0-51.5zM512 766c-157.9 0-273.7-76.2-356.2-254C238.3 334.2 354.1 258 512 258c157.9 0 273.7 76.2 356.2 254C785.7 689.8 669.9 766 512 766z m-64-318a64 64 0 1 0 128 0 64 64 0 0 0-128 0z" fill="currentColor"/></svg>&nbsp;<?php echo (int)$post['views']; ?></span>
        <span class="article-meta-sep">·</span>
        <span class="article-meta-stat" title="评论人数"><svg class="meta-ico" viewBox="0 0 1024 1024" aria-hidden="true"><path d="M512 128c-212 0-384 150-384 335 0 105 56 198 144 259l-25 139a32 32 0 0 0 47 34l152-84c21 3 43 5 66 5 212 0 384-150 384-335S724 128 512 128z" fill="none" stroke="currentColor" stroke-width="48"/></svg>&nbsp;<?php echo count($comments); ?></span>
        <span class="article-meta-sep">·</span>
        <span class="article-meta-stat"><?php echo $words; ?> 字</span>
        <span class="article-meta-sep">·</span>
        <span class="article-meta-stat"><?php echo e(format_time($post['created_at'], 'Y年m月d日')); ?></span>
      </div>
      <div class="prose" id="prose"><?php echo $fs_html; ?></div>

      <?php echo function_exists('post_tags_html') ? post_tags_html($post) : ''; ?>

      <section class="copyright-card">
        <h2 class="copyright-card__title">版权声明</h2>
        <div class="copyright-card__body">
          <p>本文采用 <a href="https://creativecommons.org/licenses/by-nc-sa/4.0/deed.zh" target="_blank" rel="noopener">CC BY-NC-SA 4.0</a> 许可协议。</p>
          <p>转载、改编请注明作者「<?php echo e($me_name); ?>」及原文链接：<?php echo e(post_url($post)); ?></p>
        </div>
      </section>

      <div class="article-nav">
        <?php if ($prev): ?><a class="nav-prev fl-card-surface" href="<?php echo e(post_url($prev)); ?>">← 上一篇：<?php echo e($prev['title']); ?></a><?php endif; ?>
        <?php if ($next): ?><a class="nav-next fl-card-surface" href="<?php echo e(post_url($next)); ?>">下一篇：<?php echo e($next['title']); ?> →</a><?php endif; ?>
      </div>

      <nz-divider></nz-divider>
      <section class="comment-section" id="comment">
        <h2 class="comment-section__title">评论 <span class="comment-section__count"><?php echo count($comments); ?></span></h2>
        <form class="comment-form fl-card-surface" method="post" action="<?php echo e(base_url() . 'comment.php'); ?>">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="post_id" value="<?php echo (int)$post['id']; ?>">
          <div class="comment-form-row">
            <?php $__cdf = function_exists('moe_comment_defaults') ? moe_comment_defaults() : array('author' => '', 'email' => '', 'admin' => false); ?>
            <input type="text" name="author" placeholder="昵称 *" required maxlength="30" value="<?php echo e($__cdf['author']); ?>">
            <input type="email" name="email" placeholder="邮箱（选填，不会公开）" maxlength="100" value="<?php echo e($__cdf['email']); ?>">
          </div>
          <?php if (!empty($__cdf['admin'])): ?><p style="font-size:12px;color:#9a8fae;margin:-4px 0 8px">👋 站长已登录，已自动填入你的信息</p><?php endif; ?>
          <textarea name="content" rows="3" placeholder="写下你的评论…" required maxlength="1000"></textarea>
          <div class="comment-form-foot">
            <span class="comment-form-hint">发布后将显示 IP 归属地与设备信息</span>
            <button class="fl-button fl-button--solid" type="submit">发布评论</button>
          </div>
        </form>
        <?php if (empty($comments)): ?>
          <p class="fi-empty-note">还没有评论，来说点什么吧～</p>
        <?php else: ?>
        <div class="comment-list">
          <?php foreach ($comments as $cm): ?>
          <article class="fc-card">
            <div class="fc-card__head">
              <span class="fc-avatar"><?php echo e(initial($cm['author'])); ?></span>
              <div class="fc-card__meta">
                <span class="fc-name"><?php echo e($cm['author']); ?></span>
                <?php $cm_ua = trim((string)($cm['ua'] ?? '')); if ($cm_ua !== ''): ?>
                  <span class="fc-device"><?php echo e($cm_ua); ?></span>
                <?php endif; ?>
                <?php $__fsloc = function_exists('moe_comment_loc') ? moe_comment_loc($cm) : (isset($cm['location']) ? trim($cm['location']) : ''); ?>
                <?php if ($__fsloc !== ''): ?>
                  <span class="fc-location"><?php echo e($__fsloc); ?></span>
                <?php endif; ?>
              </div>
              <span class="fc-time"><?php echo e(nice_time($cm['created_at'])); ?></span>
            </div>
            <div class="fc-card__body"><?php echo nl2br(e($cm['content'])); ?></div>
          </article>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>
      </section>
    </div>

    <aside class="blog-detail-aside">
      <div class="me-inner">
        <span class="me-side-avatar"><img src="<?php echo e($me_avatar); ?>" alt="<?php echo e($me_name); ?>" loading="lazy"></span>
        <div class="me_box fl-card-surface">
          <p class="me-name"><?php echo e($me_name); ?></p>
          <span class="me-side-sub"><?php echo e(trim(theme_opt('me_sub', '')) !== '' ? theme_opt('me_sub') : $site['sub']); ?></span>
        </div>
      </div>
      <?php if ($opt_toc && count($toc) >= 2): ?>
      <div class="sidebar-card menu fl-card-surface">
        <p class="sidebar-card__title">目录</p>
        <div class="sidebar-card__body sidebar-card__body--toc">
          <?php foreach ($toc as $t): ?>
          <a class="toc-link toc-link--h<?php echo $t['level']; ?>" href="#<?php echo e($t['id']); ?>" data-target="<?php echo e($t['id']); ?>"><?php echo e($t['text']); ?></a>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>
      <?php if (!empty($related)): ?>
      <div class="sidebar-card related-sidebar fl-card-surface">
        <p class="sidebar-card__title">相关文章</p>
        <div class="sidebar-card__body">
          <?php foreach ($related as $r): ?>
          <a class="related-sidebar__item" href="<?php echo e(post_url($r)); ?>">
            <span class="related-sidebar__title"><?php echo e($r['title']); ?></span>
            <span class="related-sidebar__date"><?php echo e(format_time($r['created_at'], 'Y-m-d')); ?></span>
          </a>
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>
    </aside>
  </div>
</div>

<?php
$page_script = '<script>
(function(){
  var bar=document.getElementById("readingBar");
  var shell=document.querySelector(".blog-detail-shell");
  window.addEventListener("scroll",function(){
    if(!bar)return;
    var el=document.getElementById("prose");
    if(!el)return;
    var r=el.getBoundingClientRect();
    var total=r.height-window.innerHeight*0.4;
    var done=Math.min(Math.max(-r.top+window.innerHeight*0.3,0),Math.max(total,1));
    bar.style.width=(total>0?done/total*100:0)+"%";
  },{passive:true});
  var links=document.querySelectorAll(".toc-link");
  if(links.length){
    var heads=Array.prototype.map.call(links,function(a){return document.getElementById(a.getAttribute("data-target"));});
    window.addEventListener("scroll",function(){
      var cur=-1, top=window.scrollY+90;
      heads.forEach(function(h,i){if(h&&h.offsetTop<=top)cur=i;});
      links.forEach(function(a,i){a.classList.toggle("toc-link--active",i===cur);});
    },{passive:true});
    links.forEach(function(a){a.addEventListener("click",function(ev){ev.preventDefault();var t=document.getElementById(a.getAttribute("data-target"));if(t)window.scrollTo({top:t.offsetTop-70,behavior:"smooth"});});});
  }
})();
</script>';
include partial_path('footer.php');
