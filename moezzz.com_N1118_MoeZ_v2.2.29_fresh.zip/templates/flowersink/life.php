<?php
/**
 * 花墨 · Flowersink 模板 · 点滴时间线（/life）
 * 模板设置「点滴分类别名」下的文章按月分组，展示时刻、标题、摘要与评论数
 * 可用变量：$groups（'YYYY-MM' => 文章行数组，含 comment_count）$total $life_cat $site $nav_cats
 */
$cur_p = 'life';
include partial_path('header.php');

$fs_total  = isset($total) ? (int) $total : 0;
$fs_groups = (isset($groups) && is_array($groups)) ? $groups : array();
$fs_life_name = (isset($life_cat) && !empty($life_cat['name'])) ? (string) $life_cat['name'] : '点滴';
?>
<div class="fi-screen">
  <?php echo fs_page_head($fs_life_name, '日常记录共 ' . $fs_total . ' 条，按月份倒序排列', '点滴'); ?>

  <?php if (empty($fs_groups)): ?>
    <p class="fi-empty-note">还没有记录～去后台写一条今天的心情吧。</p>
  <?php else: ?>
    <?php foreach ($fs_groups as $fs_month => $fs_items): ?>
      <section class="fi-group fl-card-surface">
        <div class="fl-section-title">
          <h2><span class="fi-group-year"><?php echo e(fs_month_label($fs_month)); ?></span></h2>
          <span class="fl-section-count"><?php echo count((array) $fs_items); ?> 条</span>
        </div>
        <ul class="fi-life-list">
          <?php foreach ((array) $fs_items as $fs_p): ?>
            <?php if (!is_array($fs_p) || empty($fs_p['title'])) continue; ?>
            <li class="fi-life-item">
              <span class="fi-life-time"><?php echo e(format_time($fs_p['created_at'], 'm-d H:i')); ?></span>
              <div class="fi-life-body">
                <a class="fi-life-title" href="<?php echo e(post_url($fs_p)); ?>"><?php echo e($fs_p['title']); ?></a>
                <p class="fi-life-text"><?php echo e(post_excerpt($fs_p, 120)); ?></p>
                <span class="fi-life-meta">
                  <?php echo (int) (isset($fs_p['comment_count']) ? $fs_p['comment_count'] : 0); ?> 条评论
                  <?php if (!empty($fs_p['views'])): ?> · <?php echo (int) $fs_p['views']; ?> 阅读<?php endif; ?>
                </span>
              </div>
            </li>
          <?php endforeach; ?>
        </ul>
      </section>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php include partial_path('footer.php'); ?>