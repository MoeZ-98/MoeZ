<?php
/**
 * 花墨 · Flowersink 模板 · 友链页（/link）
 * 本站名片 + 友链墙 + 友链申请表单（提交到 link.php，返回 JSON 由页脚脚本接管）
 * 可用变量：$links $site $nav_cats
 */
$cur_p = 'link';
include partial_path('header.php');

$fs_links = (isset($links) && is_array($links)) ? $links : array();
$fs_apply = trim((string) fs_opt('link_apply', ''));
$fs_me_name = $site['author'] !== '' ? $site['author'] : $site['name'];
?>
<div class="fi-screen">
  <?php echo fs_page_head('友情链接', '共 ' . count($fs_links) . ' 个朋友的小站，欢迎交换链接', '友链'); ?>

  <section class="fi-link-self fl-card-surface">
    <img class="fi-link-self-avatar" src="<?php echo e(fs_avatar($site)); ?>" alt="<?php echo e($fs_me_name); ?>" loading="lazy">
    <div class="fi-link-self-body">
      <p class="fi-link-self-name"><?php echo e($fs_me_name); ?></p>
      <?php if ($site['sub'] !== ''): ?><p class="fi-link-self-sub"><?php echo e($site['sub']); ?></p><?php endif; ?>
      <p class="fi-link-self-url"><span>本站地址</span><code><?php echo e(base_url()); ?></code></p>
    </div>
  </section>

  <?php if ($fs_apply !== ''): ?>
    <section class="fi-apply-note fl-card-surface">
      <div class="prose prose--compact"><?php echo render_content($fs_apply, 'markdown'); ?></div>
    </section>
  <?php endif; ?>

  <?php if (empty($fs_links)): ?>
    <p class="fi-empty-note">还没有友链，来申请第一条吧～</p>
  <?php else: ?>
    <div class="fi-link-grid">
      <?php foreach ($fs_links as $fs_l): ?>
        <?php if (!is_array($fs_l) || empty($fs_l['url'])) continue; ?>
        <?php
          $fs_ico  = function_exists('link_icon') ? link_icon($fs_l) : '';
          $fs_desc = function_exists('link_desc') ? link_desc($fs_l) : '';
          $fs_name = !empty($fs_l['name']) ? (string) $fs_l['name'] : (string) $fs_l['url'];
        ?>
        <a class="fi-link-item fl-card-surface" href="<?php echo e($fs_l['url']); ?>" target="_blank" rel="noopener nofollow" title="<?php echo e($fs_name); ?>">
          <span class="fi-link-face">
            <?php if ($fs_ico !== ''): ?>
              <img src="<?php echo e($fs_ico); ?>" alt="<?php echo e($fs_name); ?>" loading="lazy" onerror="this.parentNode.textContent='<?php echo e(initial($fs_name)); ?>'">
            <?php else: ?>
              <?php echo e(initial($fs_name)); ?>
            <?php endif; ?>
          </span>
          <span class="fi-link-main">
            <span class="fi-link-name"><?php echo e($fs_name); ?></span>
            <span class="fi-link-desc"><?php echo e($fs_desc !== '' ? $fs_desc : $fs_l['url']); ?></span>
          </span>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <section class="fi-apply fl-card-surface">
    <div class="fl-section-title">
      <h2>申请友链</h2>
      <span class="fl-section-count">站长会尽快处理</span>
    </div>
    <p class="fi-apply-tip">请先在贵站添加本站链接，再填写下面表单；已检测到回链的申请会自动通过并展示。</p>
    <form class="fl-apply-form" method="post" action="<?php echo e(base_url() . 'link.php'); ?>">
      <?php echo csrf_field(); ?>
      <div class="fi-apply-row">
        <input type="text" name="name" maxlength="40" placeholder="站点名称（可留空自动抓取）" aria-label="站点名称">
        <input type="url" name="url" maxlength="200" placeholder="站点地址，如 https://your.site" required aria-label="站点地址">
        <input type="text" name="contact" maxlength="60" placeholder="联系方式（邮箱 / QQ，选填）" aria-label="联系方式">
      </div>
      <div class="fi-apply-foot">
        <span class="fl-form-hint">提交后会自动检测回链，结果会即时提示</span>
        <button class="fl-button fl-button--solid" type="submit">提交申请</button>
      </div>
    </form>
  </section>
</div>

<?php include partial_path('footer.php'); ?>