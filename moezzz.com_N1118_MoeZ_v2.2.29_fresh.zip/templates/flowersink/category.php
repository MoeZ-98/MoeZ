<?php
/**
 * 花墨 · Flowersink 模板 · 分类页
 * 分类标题卡 + 分类切换 + 该分类文章卡片列表 + 分页
 * 可用变量：$cat $posts $pager $total $page $site $nav_cats
 */
$cur_p = 'category';
include partial_path('header.php');

$fs_cat_id  = isset($cat['id']) ? (int) $cat['id'] : 0;
$fs_total   = isset($total) ? (int) $total : 0;
$fs_side_on = fs_on('show_home_aside', '1');
$fs_sub     = !empty($cat['description']) ? (string) $cat['description'] : ('分类下共 ' . $fs_total . ' 篇文章');
?>
<div class="fi-screen">
  <?php echo fs_page_head(isset($cat['name']) ? (string) $cat['name'] : '分类', $fs_sub, '分类'); ?>

  <?php $fs_cats = fs_cats(); ?>
  <?php if (!empty($fs_cats)): ?>
    <nav class="fi-chipbar" aria-label="分类切换">
      <?php foreach ($fs_cats as $fs_c): ?>
        <?php if (!is_array($fs_c) || empty($fs_c['name'])) continue; ?>
        <a class="fi-chip<?php echo (int) $fs_c['id'] === $fs_cat_id ? ' is-active' : ''; ?>" href="<?php echo e(cat_url($fs_c)); ?>"><?php echo e($fs_c['name']); ?><b><?php echo (int) (isset($fs_c['cnt']) ? $fs_c['cnt'] : 0); ?></b></a>
      <?php endforeach; ?>
    </nav>
  <?php endif; ?>

  <div class="fl-shell">
    <div class="fl-content">
      <?php if (empty($posts)): ?>
        <p class="fi-empty-note">这个分类下还没有文章～</p>
      <?php else: ?>
        <div class="fi-post-grid">
          <?php foreach ($posts as $fs_p): ?><?php echo fs_card_html($fs_p, $cat); ?><?php endforeach; ?>
        </div>
        <?php echo isset($pager) ? $pager : ''; ?>
      <?php endif; ?>
    </div>

    <?php if ($fs_side_on): ?>
      <aside class="fl-aside"><?php echo fs_aside_html($site, $fs_cats); ?></aside>
    <?php endif; ?>
  </div>
</div>

<?php include partial_path('footer.php'); ?>