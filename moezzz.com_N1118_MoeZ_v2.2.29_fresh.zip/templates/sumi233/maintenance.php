<?php
/**
 * sumi233 模板 · 维护页（站点设置里关闭前台访问时显示）
 */
$cur_p        = 'maintenance';
$banner_title = '稍后回来';
$banner_sub   = '站点正在维护中';
include partial_path('header.php');
?>
<section class="sumi-card sumi-maintenance">
  <p class="sumi-maintenance-code">🚧</p>
  <h2 class="sumi-404-title">站点正在维护中</h2>
  <p class="sumi-404-tip"><?php echo e($site['name']); ?> 正在做一些调整，请稍后再来访问。</p>
  <?php if (!empty($site['mail'])): ?>
  <p class="sumi-404-tip">急事可以邮件联系：<a href="mailto:<?php echo e($site['mail']); ?>"><?php echo e($site['mail']); ?></a></p>
  <?php endif; ?>
</section>
<?php include partial_path('footer.php'); ?>