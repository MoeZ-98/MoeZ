<?php
/**
 * sumi233 模板 · 文章卡片片段
 * 需要：$p（文章行）。可选：$card_cat = array('id'=>..,'name'=>..,'slug'=>..)，用于列表页补齐分类。
 */
$__cover = post_cover($p);
$__cn = !empty($p['cat_name']) ? $p['cat_name'] : (isset($card_cat['name']) ? $card_cat['name'] : '');
$__cs = !empty($p['cat_slug']) ? $p['cat_slug'] : (isset($card_cat['slug']) ? $card_cat['slug'] : '');
$__ci = !empty($p['cat_id']) ? $p['cat_id'] : (isset($card_cat['id']) ? $card_cat['id'] : 0);
$__url = post_url($p);
?>
<article class="sumi-card sumi-post-card">
  <a class="sumi-post-cover<?php echo $__cover ? '' : ' is-empty'; ?>" href="<?php echo e($__url); ?>">
    <?php if ($__cover): ?>
    <img src="<?php echo e(media_url($__cover)); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy">
    <?php else: ?>
    <span class="sumi-post-cover-text" aria-hidden="true"></span>
    <?php endif; ?>
    <?php if (!empty($p['is_top'])): ?><span class="sumi-pin">置顶</span><?php endif; ?>
  </a>
  <div class="sumi-post-body">
    <h3 class="sumi-post-title"><a href="<?php echo e($__url); ?>"><?php echo e($p['title']); ?></a></h3>
    <p class="sumi-post-excerpt"><?php echo e(post_excerpt($p, 88)); ?></p>
    <div class="sumi-post-meta">
      <?php if ($__cn !== ''): ?>
      <a class="sumi-chip" href="<?php echo e(cat_url(array('id' => $__ci, 'name' => $__cn, 'slug' => $__cs))); ?>"><?php echo e($__cn); ?></a>
      <?php endif; ?>
      <time datetime="<?php echo e($p['created_at']); ?>"><?php echo e(format_time($p['created_at'])); ?></time>
      <?php if (theme_opt('show_views', '1') === '1' && isset($p['views'])): ?><span><?php echo (int) $p['views']; ?> 阅读</span><?php endif; ?>
      <?php if (theme_opt('show_reading', '1') === '1'): ?><span>约 <?php echo reading_time($p); ?> 分钟</span><?php endif; ?>
    </div>
  </div>
</article>