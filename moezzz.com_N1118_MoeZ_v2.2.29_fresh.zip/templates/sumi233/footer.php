<?php
/**
 * sumi233 模板 · 页脚
 * 收尾主内容与侧栏，输出页脚、悬浮按钮、「模板设置」面板容器与前端默认值。
 */
$icp   = trim((string) theme_opt('icp', ''));
$extra = trim((string) theme_opt('footer_extra', ''));
$defaults = array(
    'hue'            => (int) theme_opt('hue', '100'),
    'mode'           => theme_opt('default_mode', 'auto'),
    'pageWidth'      => theme_opt('page_width', '100rem'),
    'navbarBlur'     => theme_opt('navbar_blur', '5px'),
    'bannerHome'     => theme_opt('banner_home', '65vh'),
    'bannerPage'     => theme_opt('banner_page', '35vh'),
    'cardOpacity'    => theme_opt('card_opacity', '0.6'),
    'wallpaperMode'  => theme_opt('wallpaper_mode', 'fullscreen'),
    'carousel'       => theme_opt('carousel', '1') === '1',
    'cardBorder'     => theme_opt('card_border', '1') === '1',
    'cardFollowHue'  => theme_opt('card_follow_hue', '0') === '1',
    'sakura'         => theme_opt('sakura', '0') === '1',
);
?>
      </div><!-- /.sumi-content -->
      <?php include partial_path('_sidebar.php'); ?>
    </div><!-- /.sumi-columns -->
  </div><!-- /.sumi-shell -->
</main>

<footer class="sumi-footer">
  <?php if (theme_opt('waves', '1') === '1'): ?>
  <div class="sumi-waves" aria-hidden="true">
    <svg viewBox="0 0 1440 90" preserveAspectRatio="none"><path d="M0 46c180 42 360-42 540-22s360 62 540 32 360-52 360-52v86H0Z"/></svg>
  </div>
  <?php endif; ?>
  <div class="sumi-footer-inner">
    <div class="sumi-footer-main">
      <p class="sumi-footer-title"><?php echo e($site['name']); ?></p>
      <?php if (!empty($site['desc'])): ?><p class="sumi-footer-desc"><?php echo e($site['desc']); ?></p><?php endif; ?>
    </div>
    <nav class="sumi-footer-links">
      <a href="<?php echo e(home_url()); ?>">主页</a>
      <a href="<?php echo e(base_url() . 'archives'); ?>">归档</a>
      <a href="<?php echo e(base_url() . 'blog/article'); ?>">写作</a>
      <a href="<?php echo e(base_url() . 'link'); ?>">友链</a>
      <a href="<?php echo e(base_url() . 'about'); ?>">关于</a>
      <a href="<?php echo e(rss_url()); ?>">RSS</a>
      <a href="<?php echo e(sitemap_url()); ?>">Sitemap</a>
    </nav>
  </div>
  <div class="sumi-footer-bottom">
    <span><?php echo $site['footer'] ? e($site['footer']) : '© ' . date('Y') . ' ' . e($site['name']); ?></span>
    <?php if ($icp !== ''): ?><span class="sumi-icp"><?php echo e($icp); ?></span><?php endif; ?>
    <span class="sumi-powered">Powered by MoeZ <?php echo e(isset($site['version']) ? $site['version'] : ''); ?> · 模板 sumi233</span>
  </div>
  <?php if ($extra !== ''): ?><div class="sumi-footer-extra"><?php echo $extra; ?></div><?php endif; ?>
</footer>

<div class="sumi-tools">
  <button type="button" class="sumi-btn sumi-btn-plain" data-sumi-action="top">回到顶部</button>
  <button type="button" class="sumi-btn sumi-btn-plain" data-sumi-action="panel">模板设置</button>
</div>

<button class="sumi-fab sumi-fab-top" id="sumi-top" type="button" title="回到顶部" aria-label="回到顶部">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 19V6M5.5 12.5 12 6l6.5 6.5"/></svg>
</button>
<button class="sumi-fab sumi-fab-panel" id="sumi-panel-btn" type="button" title="模板设置（仅本机预览）" aria-label="模板设置">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h8M17.5 7H20M4 12h4M13.5 12H20M4 17h9M18 17h2"/><circle cx="14.5" cy="7" r="2.1"/><circle cx="10.5" cy="12" r="2.1"/><circle cx="15" cy="17" r="2.1"/></svg>
</button>
<div class="sumi-panel" id="sumi-panel" hidden></div>

<script>window.SUMI_DEFAULTS = <?php echo json_encode($defaults, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;</script>
<?php if (!empty($page_script)) echo $page_script; ?>
</body>
</html>