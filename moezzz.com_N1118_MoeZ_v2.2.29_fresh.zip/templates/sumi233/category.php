<?php
/**
 * sumi233 模板 · 分类页
 * 可用变量：$cat、$posts、$pager、$total、$page
 */
$cur_p        = 'category';
$banner_title = !empty($cat) ? $cat['name'] : '分类';
$banner_sub   = !empty($cat['description']) ? $cat['description'] : ('共 ' . (int) $total . ' 篇文章');
include partial_path('header.php');

$cat_count = array();
try {
    $cat_count = rows('SELECT c.id, c.name, c.slug, COUNT(p.id) AS cnt FROM ' . moe_table('categories') . ' c'
        . ' LEFT JOIN ' . moe_table('posts') . " p ON p.category_id = c.id AND p.type = 'post' AND p.status = 'published'"
        . ' GROUP BY c.id, c.name, c.slug ORDER BY c.id ASC');
} catch (PDOException $e) { /* 忽略 */ }
?>
<?php if (!empty($cat_count)): ?>
<nav class="sumi-chipbar">
  <?php foreach ($cat_count as $c): ?>
  <a class="sumi-chip<?php echo (!empty($cat) && (int) $cat['id'] === (int) $c['id']) ? ' active' : ''; ?>" href="<?php echo e(cat_url($c)); ?>"><?php echo e($c['name']); ?> <b><?php echo (int) $c['cnt']; ?></b></a>
  <?php endforeach; ?>
</nav>
<?php endif; ?>

<div class="sumi-page-head">
  <h2 class="sumi-page-title"><?php echo e($banner_title); ?></h2>
  <span class="sumi-page-count">共 <?php echo (int) $total; ?> 篇</span>
</div>

<?php if (empty($posts)): ?>
  <div class="sumi-empty">这个分类下还没有文章。</div>
<?php else: ?>
<div class="sumi-post-grid">
  <?php $card_cat = !empty($cat) ? array('id' => $cat['id'], 'name' => $cat['name'], 'slug' => $cat['slug']) : null; ?>
  <?php foreach ($posts as $p): ?>
    <?php include partial_path('_post-card.php'); ?>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php echo $pager; ?>
<?php include partial_path('footer.php'); ?>