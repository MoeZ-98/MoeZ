<?php
/**
 * sumi233 模板 · 头部
 * 输出 <head>、壁纸层、顶部导航，并打开主内容容器（由 footer.php 收尾）。
 * 页面文件可在 include 本文件前设置：$cur_p（当前栏目）、$banner_title、$banner_sub
 */
$cur_p     = isset($cur_p) ? $cur_p : 'index';
$is_home   = ($cur_p === 'index');
$mode      = theme_opt('default_mode', 'auto');
$wall_mode = theme_opt('wallpaper_mode', 'fullscreen');
$hue       = (int) theme_opt('hue', '100');
$wall_idx  = max(1, min(5, (int) theme_opt('wallpaper', '1')));
$font_size = (int) theme_opt('font_size', '16');
$logo      = trim((string) theme_opt('logo', ''));

$bn_title = isset($banner_title) ? $banner_title : '';
$bn_sub   = isset($banner_sub) ? $banner_sub : '';
if ($is_home) {
    $bn_title = theme_opt('hero_title', '') !== '' ? theme_opt('hero_title', '') : $site['name'];
    $bn_sub   = theme_opt('hero_sub', '') !== '' ? theme_opt('hero_sub', '') : $site['sub'];
}

$body_class = 'sumi-body';
$body_class .= $is_home ? ' is-home' : '';
$body_class .= theme_opt('card_border', '1') === '1' ? ' has-card-border' : '';
$body_class .= theme_opt('card_follow_hue', '0') === '1' ? ' card-follow-theme-hue' : '';
?>
<!DOCTYPE html>
<html lang="zh-CN"<?php echo $mode === 'dark' ? ' class="dark"' : ''; ?>
      data-default-mode="<?php echo e($mode); ?>"
      data-wallpaper-mode="<?php echo e($wall_mode); ?>"
      data-tag-style="<?php echo e(theme_opt('tag_style', 'pill')); ?>"
      style="--hue: <?php echo $hue; ?>;--configHue: <?php echo $hue; ?>;--page-width: <?php echo e(theme_opt('page_width', '100rem')); ?>;--navbar-panel-blur: <?php echo e(theme_opt('navbar_blur', '5px')); ?>;--banner-height-home: <?php echo e(theme_opt('banner_home', '65vh')); ?>;--banner-height: <?php echo e(theme_opt('banner_page', '35vh')); ?>;--card-transparent-opacity: <?php echo e(theme_opt('card_opacity', '0.6')); ?>;--sumi-font-size: <?php echo $font_size; ?>px;">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo seo_head(); ?>
<?php
/* 目录适配：原有「自定义 logo → 主题 favicon.ico」优先级不变，另补根图标兜底 */
$moe_icon_ready = function_exists('moe_theme_icon') && function_exists('moe_icon_links');
$moe_icon_raw   = $logo !== '' ? media_url($logo) : '';
$moe_favicon = $moe_icon_ready ? moe_theme_icon($moe_icon_raw, 'assets/favicon.ico')
                              : ($moe_icon_raw !== '' ? $moe_icon_raw : theme_url('assets/favicon.ico'));
echo $moe_icon_ready ? moe_icon_links($moe_favicon)
                     : '<link rel="icon" href="' . e($moe_favicon) . '">' . "\n";
?>
<link rel="alternate" type="application/rss+xml" title="<?php echo e($site['name']); ?>" href="<?php echo e(rss_url()); ?>">
<style>
@layer properties, theme, base, components, utilities;
@font-face { font-family: "SUMI Sans"; src: url("<?php echo e(theme_url('assets/fonts/1cff8fc8782eb860.woff2')); ?>") format("woff2"); font-weight: 400; font-display: swap; }
@font-face { font-family: "SUMI Sans"; src: url("<?php echo e(theme_url('assets/fonts/81133e6a08c1533e.woff2')); ?>") format("woff2"); font-weight: 500; font-display: swap; }
@font-face { font-family: "SUMI Sans"; src: url("<?php echo e(theme_url('assets/fonts/954d4fd4837b74b5.woff2')); ?>") format("woff2"); font-weight: 700; font-display: swap; }
@font-face { font-family: "SUMI Mono"; src: url("<?php echo e(theme_url('assets/fonts/9aa2d1968e9e357e.woff2')); ?>") format("woff2"); font-weight: 400; font-display: swap; }
@font-face { font-family: "SUMI Mono"; src: url("<?php echo e(theme_url('assets/fonts/9cef9d0d0565489e.woff2')); ?>") format("woff2"); font-weight: 700; font-display: swap; }
</style>
<link rel="stylesheet" href="<?php echo e(theme_url('assets/theme.css')); ?>?v=<?php echo MOE_VERSION; ?>">
<link rel="stylesheet" href="<?php echo e(theme_url('assets/sumi233.css')); ?>?v=<?php echo MOE_VERSION; ?>">
<script src="<?php echo e(theme_url('assets/sumi233.js')); ?>?v=<?php echo MOE_VERSION; ?>" defer></script>
</head>
<body class="<?php echo $body_class; ?>">

<div id="sumi-progress" class="sumi-progress" aria-hidden="true"></div>

<?php if ($wall_mode !== 'none'): ?>
<div class="sumi-wallpaper" data-mode="<?php echo e($wall_mode); ?>" data-carousel="<?php echo theme_opt('carousel', '1') === '1' ? '1' : '0'; ?>">
  <?php for ($i = 1; $i <= 5; $i++): ?>
  <picture>
    <source media="(max-width: 768px)" srcset="<?php echo e(theme_url('assets/wallpapers/mobile-' . $i . '.webp')); ?>">
    <img class="sumi-wallpaper-img<?php echo $i === $wall_idx ? ' is-active' : ''; ?>" src="<?php echo e(theme_url('assets/wallpapers/desktop-' . $i . '.webp')); ?>" alt="" <?php echo $i === $wall_idx ? '' : 'loading="lazy"'; ?>>
  </picture>
  <?php endfor; ?>
  <div class="sumi-wallpaper-dim"></div>
</div>
<?php endif; ?>

<?php if (theme_opt('gradient', '1') === '1'): ?><div class="sumi-top-gradient" aria-hidden="true"></div><?php endif; ?>

<header class="sumi-nav" id="sumi-nav">
  <div class="sumi-nav-inner">
    <a class="sumi-brand" href="<?php echo e(home_url()); ?>">
      <img class="sumi-logo" src="<?php echo e($logo !== '' ? media_url($logo) : theme_url('assets/logo.webp')); ?>" alt="<?php echo e($site['name']); ?>">
      <span class="sumi-brand-name"><?php echo e($site['name']); ?></span>
    </a>
    <nav class="sumi-menu" id="sumi-menu">
      <a class="<?php echo $cur_p === 'index' ? 'active' : ''; ?>" href="<?php echo e(home_url()); ?>">主页</a>
      <a class="<?php echo $cur_p === 'archive' ? 'active' : ''; ?>" href="<?php echo e(base_url() . 'archives'); ?>">归档</a>
      <?php foreach ($nav_cats as $c): ?>
      <a class="<?php echo (!empty($cat) && (int) $cat['id'] === (int) $c['id']) ? 'active' : ''; ?>" href="<?php echo e(cat_url($c)); ?>"><?php echo e($c['name']); ?></a>
      <?php endforeach; ?>
      <a class="<?php echo $cur_p === 'article' ? 'active' : ''; ?>" href="<?php echo e(base_url() . 'blog/article'); ?>">写作</a>
      <a class="<?php echo $cur_p === 'link' ? 'active' : ''; ?>" href="<?php echo e(base_url() . 'link'); ?>">友链</a>
      <a class="<?php echo $cur_p === 'about' ? 'active' : ''; ?>" href="<?php echo e(base_url() . 'about'); ?>">关于</a>
    </nav>
    <div class="sumi-actions">
      <?php if (theme_opt('show_search', '1') === '1'): ?>
      <form class="sumi-search" method="get" action="<?php echo e(base_url() . 'index.php'); ?>" role="search">
        <input type="hidden" name="p" value="search">
        <svg class="sumi-search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="m16 16 4.5 4.5"/></svg>
        <input class="sumi-search-input" type="search" name="q" placeholder="搜索" value="<?php echo e(isset($kw) ? $kw : ''); ?>">
      </form>
      <?php endif; ?>
      <button class="sumi-icon-btn" id="sumi-mode" type="button" title="切换明暗" aria-label="切换明暗">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.5 14.6A8.6 8.6 0 1 1 9.4 3.5a7 7 0 0 0 11.1 11.1Z"/><path d="M17 6.2h3.2"/></svg>
      </button>
      <button class="sumi-icon-btn sumi-icon-btn-menu" id="sumi-menu-btn" type="button" title="菜单" aria-label="菜单">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
      </button>
    </div>
  </div>
</header>

<?php if ($bn_title !== '' && theme_opt('banner_title', '1') === '1'): ?>
<section class="sumi-banner<?php echo $is_home ? ' is-home' : ''; ?>">
  <div class="sumi-banner-text">
    <h1 class="sumi-banner-title"><?php echo e($bn_title); ?></h1>
    <?php if ($bn_sub !== ''): ?><p class="sumi-banner-sub"<?php echo $is_home ? ' data-sumi-typewriter="' . e($bn_sub) . '"' : ''; ?>><?php echo e($bn_sub); ?></p><?php endif; ?>
  </div>
  <?php if ($is_home): ?>
  <a class="sumi-scroll-down" href="#sumi-main" aria-label="向下浏览"><svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="m6 9 6 6 6-6"/></svg></a>
  <?php endif; ?>
</section>
<?php endif; ?>

<main class="sumi-main" id="sumi-main">
  <div class="sumi-shell">
    <div class="sumi-columns">
      <div class="sumi-content<?php echo isset($content_class) ? ' ' . e($content_class) : ''; ?>">