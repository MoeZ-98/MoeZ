<?php
/**
 * sumi233 模板 · 点滴时间线（/life）
 * 可用变量：$groups（年-月 => 文章数组，含 comment_count）、$total、$life_cat
 */
$cur_p        = 'life';
$banner_title = '点滴';
$banner_sub   = '共 ' . (int) $total . ' 条记录';
include partial_path('header.php');
?>
<?php if (empty($groups)): ?>
  <div class="sumi-empty">还没有记录。</div>
<?php else: ?>
  <?php foreach ($groups as $month => $items): ?>
  <section class="sumi-card sumi-life-group">
    <h3 class="sumi-block-title"><span class="sumi-archive-year"><?php echo e($month); ?></span><span class="sumi-archive-count"><?php echo count($items); ?> 条</span></h3>
    <ul class="sumi-life-list">
      <?php foreach ($items as $p): ?>
      <li>
        <span class="sumi-life-time"><?php echo e(format_time($p['created_at'], 'm-d H:i')); ?></span>
        <div class="sumi-life-body">
          <a class="sumi-life-title" href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a>
          <p class="sumi-life-text"><?php echo e(post_excerpt($p, 120)); ?></p>
          <span class="sumi-life-meta"><?php echo isset($p['comment_count']) ? (int) $p['comment_count'] : 0; ?> 条评论<?php if (!empty($p['views'])): ?> · <?php echo (int) $p['views']; ?> 阅读<?php endif; ?></span>
        </div>
      </li>
      <?php endforeach; ?>
    </ul>
  </section>
  <?php endforeach; ?>
<?php endif; ?>

<?php include partial_path('footer.php'); ?>