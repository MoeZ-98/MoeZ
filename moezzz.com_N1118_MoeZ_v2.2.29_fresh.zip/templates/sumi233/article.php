<?php
/**
 * sumi233 模板 · 写作列表页（/blog/article）
 * 可用变量：$posts（含 cat_name）、$pager、$total、$page、$cats、$sel_cat
 */
$cur_p        = 'article';
$banner_title = '写作';
$banner_sub   = '共 ' . (int) $total . ' 篇';
include partial_path('header.php');
?>
<?php if (!empty($cats)): ?>
<nav class="sumi-chipbar">
  <a class="sumi-chip<?php echo empty($sel_cat) ? ' active' : ''; ?>" href="<?php echo e(base_url() . 'blog/article'); ?>">全部</a>
  <?php foreach ($cats as $c): ?>
  <a class="sumi-chip<?php echo ((int) $sel_cat === (int) $c['id']) ? ' active' : ''; ?>" href="<?php echo e(base_url() . 'blog/article?cat=' . (int) $c['id']); ?>"><?php echo e($c['name']); ?><?php if (isset($c['count'])): ?> <b><?php echo (int) $c['count']; ?></b><?php endif; ?></a>
  <?php endforeach; ?>
</nav>
<?php endif; ?>

<?php if (empty($posts)): ?>
  <div class="sumi-empty">这里还没有文章。</div>
<?php else: ?>
<div class="sumi-post-grid">
  <?php foreach ($posts as $p): ?>
    <?php $card_cat = null; include partial_path('_post-card.php'); ?>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php echo $pager; ?>
<?php include partial_path('footer.php'); ?>