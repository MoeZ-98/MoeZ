<?php
/**
 * sumi233 模板 · 友情链接页
 * 可用变量：$links（status=approved 的友链）
 */
$cur_p        = 'link';
$banner_title = '友情链接';
$banner_sub   = '想交换友链的话，在下面留言板里申请就好';
include partial_path('header.php');

$avatar = trim((string) theme_opt('avatar', ''));
if ($avatar !== '') {
    $me_avatar = media_url($avatar);
} elseif (!empty($site['avatar'])) {
    $me_avatar = media_url($site['avatar']);
} else {
    $me_avatar = theme_url('assets/avatar.webp');
}
?>
<section class="sumi-card sumi-link-self">
  <img class="sumi-link-avatar" src="<?php echo e($me_avatar); ?>" alt="<?php echo e($site['name']); ?>">
  <div class="sumi-link-self-body">
    <h3><?php echo e($site['name']); ?></h3>
    <p><?php echo e($site['sub']); ?></p>
    <p class="sumi-link-self-url"><?php echo e(base_url()); ?></p>
  </div>
</section>

<section class="sumi-links">
  <?php if (empty($links)): ?>
  <div class="sumi-empty">还没有友链，快来申请第一条吧～</div>
  <?php else: ?>
  <div class="sumi-link-grid">
    <?php foreach ($links as $l): ?>
    <?php
      $ico = function_exists('link_icon') ? link_icon($l) : '';
      $ld  = function_exists('link_desc') ? link_desc($l) : '';
    ?>
    <a class="sumi-card sumi-link-item" href="<?php echo e($l['url']); ?>" target="_blank" rel="noopener nofollow" title="<?php echo e($l['name']); ?>">
      <?php if ($ico !== ''): ?>
      <img src="<?php echo e($ico); ?>" alt="<?php echo e($l['name']); ?>" loading="lazy"
           onerror="this.parentNode.replaceChild(document.createTextNode('<?php echo e(initial($l['name'])); ?>'),this)">
      <?php else: ?>
      <span class="sumi-link-initial"><?php echo e(initial($l['name'])); ?></span>
      <?php endif; ?>
      <span class="sumi-link-name"><?php echo e($l['name']); ?></span>
      <?php if ($ld !== ''): ?>
      <span class="sumi-link-desc" style="display:block;font-size:11.5px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo e($ld); ?></span>
      <?php endif; ?>
    </a>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</section>

<section class="sumi-card sumi-link-apply">
  <h3 class="sumi-block-title">申请友链</h3>
  <p class="sumi-apply-tip">请先在贵站添加本站链接，然后填写下面的表单；互为友链通过率更高。</p>
  <form method="post" action="<?php echo e(base_url() . 'link.php'); ?>">
    <?php echo csrf_field(); ?>
    <div class="sumi-apply-row">
      <input type="text" name="name" maxlength="40" placeholder="站点名称" required>
      <input type="url" name="url" maxlength="200" placeholder="https://your.site" required>
      <input type="text" name="contact" maxlength="100" placeholder="联系方式（邮箱 / QQ）">
    </div>
    <button type="submit">提交申请</button>
  </form>
</section>

<?php include partial_path('footer.php'); ?>