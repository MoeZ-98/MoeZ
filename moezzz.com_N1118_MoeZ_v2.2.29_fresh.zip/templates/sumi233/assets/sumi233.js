/*!
 * sumi233 模板 · 交互脚本
 * 明暗切换、色相、壁纸轮播、目录、阅读进度、回到顶部、
 * 「模板设置」面板（前端预览用，最终以后台模板设置为准）、评论提交。
 */
(function () {
  'use strict';

  var D = window.SUMI_DEFAULTS || {};
  var LS = 'sumi233';
  var root = document.documentElement;
  var body = document.body;

  function stored() {
    try { return JSON.parse(localStorage.getItem(LS) || 'null') || {}; } catch (e) { return {}; }
  }
  function save(cfg) {
    try { localStorage.setItem(LS, JSON.stringify(cfg)); } catch (e) {}
  }
  function cfg() {
    return Object.assign({}, D, stored());
  }
  function setVar(k, v) { if (v !== undefined && v !== null && v !== '') root.style.setProperty(k, String(v)); }

  /* ---------- 应用设置 ---------- */
  function applyMode(mode) {
    var dark = mode === 'dark';
    if (mode === 'auto') {
      dark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    root.classList.toggle('dark', dark);
  }

  function apply(c) {
    applyMode(c.mode);
    setVar('--hue', c.hue);
    setVar('--configHue', c.hue);
    setVar('--page-width', c.pageWidth);
    setVar('--navbar-panel-blur', c.navbarBlur);
    setVar('--banner-height-home', c.bannerHome);
    setVar('--banner-height', c.bannerPage);
    setVar('--card-transparent-opacity', c.cardOpacity);
    if (c.fontSize) setVar('--sumi-font-size', c.fontSize + 'px');
    root.classList.toggle('has-card-border', !!c.cardBorder);
    body.classList.toggle('card-follow-theme-hue', !!c.cardFollowHue);
    if (c.wallpaperMode) {
      root.setAttribute('data-wallpaper-mode', c.wallpaperMode);
      var wp = document.querySelector('.sumi-wallpaper');
      if (wp) wp.style.display = c.wallpaperMode === 'none' ? 'none' : '';
    }
    if (c.sakura && !document.querySelector('.sumi-sakura')) startSakura();
    if (!c.sakura) {
      var s = document.querySelector('.sumi-sakura');
      if (s) s.remove();
    }
  }

  /* ---------- 壁纸轮播 ---------- */
  function carousel(on) {
    var wp = document.querySelector('.sumi-wallpaper');
    if (!wp || !on) return;
    var imgs = wp.querySelectorAll('.sumi-wallpaper-img');
    if (imgs.length < 2) return;
    var i = 0;
    for (var k = 0; k < imgs.length; k++) if (imgs[k].classList.contains('is-active')) i = k;
    setInterval(function () {
      imgs[i].classList.remove('is-active');
      i = (i + 1) % imgs.length;
      imgs[i].classList.add('is-active');
    }, 9000);
  }

  /* ---------- 目录 ---------- */
  function buildToc() {
    var box = document.getElementById('sumi-toc');
    var list = document.getElementById('sumi-toc-body');
    var content = document.getElementById('sumi-article-content');
    if (!box || !list || !content) return;
    var heads = content.querySelectorAll('h2, h3, h4');
    if (heads.length < 2) return;
    var html = '';
    for (var i = 0; i < heads.length; i++) {
      var h = heads[i];
      if (!h.id) h.id = 'sumi-h-' + i;
      var lv = h.tagName === 'H2' ? 'lv2' : (h.tagName === 'H3' ? 'lv3' : 'lv4');
      html += '<a class="' + lv + '" href="#' + h.id + '">' + h.textContent + '</a>';
    }
    list.innerHTML = html;
    box.hidden = false;

    var links = list.querySelectorAll('a');
    var toggle = document.getElementById('sumi-toc-toggle');
    if (toggle) {
      toggle.addEventListener('click', function () {
        var hidden = list.style.display === 'none';
        list.style.display = hidden ? '' : 'none';
        toggle.textContent = hidden ? '−' : '+';
      });
    }
    var ticking = false;
    function onScroll() {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(function () {
        ticking = false;
        var best = null;
        for (var j = 0; j < heads.length; j++) {
          if (heads[j].getBoundingClientRect().top <= 140) best = heads[j];
        }
        for (var m = 0; m < links.length; m++) links[m].classList.remove('active');
        if (best) {
          for (var n = 0; n < links.length; n++) {
            if (links[n].getAttribute('href') === '#' + best.id) links[n].classList.add('active');
          }
        }
      });
    }
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ---------- 首页简介打字机 ---------- */
  function initTypewriter() {
    var nodes = document.querySelectorAll('[data-sumi-typewriter]');
    if (!nodes.length) return;
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    Array.prototype.forEach.call(nodes, function (el) {
      var text = el.getAttribute('data-sumi-typewriter') || el.textContent || '';
      if (!text) return;
      el.textContent = '';
      el.classList.add('is-typing');
      var caret = document.createElement('span');
      caret.className = 'sumi-caret';
      caret.setAttribute('aria-hidden', 'true');
      el.appendChild(caret);
      var i = 0;
      (function step() {
        if (i >= text.length) {
          el.classList.remove('is-typing');
          el.classList.add('is-typed');
          return;
        }
        var ch = text.charAt(i);
        caret.insertAdjacentText('beforebegin', ch);
        i += 1;
        var delay = /[，。！？、；：,.!?;:]/.test(ch) ? 200 : 62;
        setTimeout(step, delay);
      })();
    });
  }

  /* ---------- 樱花 ---------- */
  function startSakura() {
    var box = document.createElement('div');
    box.className = 'sumi-sakura';
    for (var i = 0; i < 14; i++) {
      var s = document.createElement('span');
      s.style.left = Math.random() * 100 + 'vw';
      s.style.animationDuration = (7 + Math.random() * 8) + 's';
      s.style.animationDelay = (Math.random() * 8) + 's';
      s.style.opacity = (0.5 + Math.random() * 0.4).toFixed(2);
      box.appendChild(s);
    }
    document.body.appendChild(box);
  }

  /* ---------- 面板 ---------- */
  var FIELDS = [
    { k: 'mode', l: '明暗模式', t: 'select', o: { auto: '跟随系统', light: '亮色', dark: '暗色' } },
    { k: 'hue', l: '主题色相', t: 'range', min: 0, max: 360, step: 1 },
    { k: 'cardOpacity', l: '卡片透明度', t: 'range', min: 0, max: 1, step: 0.05 },
    { k: 'pageWidth', l: '页面宽度', t: 'select', o: { '100rem': '100rem', '90rem': '90rem', '80rem': '80rem', '72rem': '72rem' } },
    { k: 'fontSize', l: '正文字号', t: 'select', o: { '15': '15px', '16': '16px', '17': '17px' } },
    { k: 'wallpaperMode', l: '壁纸模式', t: 'select', o: { fullscreen: '全屏', banner: '横幅', overlay: '浮层', none: '关闭' } },
    { k: 'cardBorder', l: '卡片描边', t: 'bool' },
    { k: 'cardFollowHue', l: '底色跟随色相', t: 'bool' },
    { k: 'carousel', l: '壁纸轮播', t: 'bool' },
    { k: 'sakura', l: '樱花特效', t: 'bool' }
  ];

  function buildPanel() {
    var panel = document.getElementById('sumi-panel');
    var btn = document.getElementById('sumi-panel-btn');
    if (!panel || !btn) return;
    var c = cfg();
    var html = '<h3>模板设置 <small style="font-weight:400;opacity:.6">（本机预览）</small></h3>';
    FIELDS.forEach(function (f) {
      var v = c[f.k];
      if (f.t === 'bool') {
        html += '<div class="sumi-row"><label>' + f.l + '</label><input type="checkbox" data-k="' + f.k + '"' + (v ? ' checked' : '') + '></div>';
      } else if (f.t === 'select') {
        html += '<div class="sumi-row"><label>' + f.l + '</label><select data-k="' + f.k + '">';
        Object.keys(f.o).forEach(function (ok) {
          html += '<option value="' + ok + '"' + (String(v) === ok ? ' selected' : '') + '>' + f.o[ok] + '</option>';
        });
        html += '</select></div>';
      } else {
        html += '<div class="sumi-row"><label>' + f.l + '</label><input type="range" data-k="' + f.k + '" min="' + f.min + '" max="' + f.max + '" step="' + f.step + '" value="' + v + '"><span class="sumi-val" data-v="' + f.k + '">' + v + '</span></div>';
      }
    });
    html += '<div class="sumi-panel-actions"><button type="button" id="sumi-panel-reset">恢复默认</button><button type="button" id="sumi-panel-close">关闭</button></div>';
    html += '<p class="sumi-panel-tip">这里的改动只保存在本机浏览器，用于预览；要让所有访客看到，请到「后台 → 模板设置」里调整对应项。</p>';
    panel.innerHTML = html;

    function collect() {
      var out = cfg();
      panel.querySelectorAll('[data-k]').forEach(function (el) {
        var k = el.getAttribute('data-k');
        if (el.type === 'checkbox') out[k] = el.checked;
        else if (el.type === 'range') out[k] = parseFloat(el.value);
        else out[k] = el.value;
      });
      return out;
    }
    panel.addEventListener('input', function (e) {
      var k = e.target.getAttribute && e.target.getAttribute('data-k');
      if (!k) return;
      var next = collect();
      var badge = panel.querySelector('[data-v="' + k + '"]');
      if (badge) badge.textContent = next[k];
      apply(next);
    });
    panel.addEventListener('change', function () {
      var next = collect();
      save(next);
      apply(next);
    });
    panel.addEventListener('click', function (e) {
      var id = e.target.id;
      if (id === 'sumi-panel-close') panel.hidden = true;
      if (id === 'sumi-panel-reset') { try { localStorage.removeItem(LS); } catch (err) {} location.reload(); }
    });
    btn.addEventListener('click', function () { panel.hidden = !panel.hidden; });
  }

  /* ---------- 其他交互 ---------- */
  function init() {
    var c = cfg();
    apply(c);
    carousel(c.carousel);
    buildToc();
    buildPanel();
    initTypewriter();

    var modeBtn = document.getElementById('sumi-mode');
    if (modeBtn) {
      modeBtn.addEventListener('click', function () {
        var cur = cfg();
        var order = ['auto', 'light', 'dark'];
        var i = order.indexOf(cur.mode);
        cur.mode = order[(i + 1) % order.length];
        save(cur);
        applyMode(cur.mode);
        var sel = document.querySelector('#sumi-panel [data-k="mode"]');
        if (sel) sel.value = cur.mode;
      });
    }

    var menuBtn = document.getElementById('sumi-menu-btn');
    var nav = document.getElementById('sumi-nav');
    if (menuBtn && nav) {
      menuBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        nav.classList.toggle('sumi-menu-open');
      });
      document.addEventListener('click', function () { nav.classList.remove('sumi-menu-open'); });
    }

    var top = document.getElementById('sumi-top');
    if (top) {
      top.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
    }

    // 窄屏（≤1080px）隐藏悬浮按钮，改用页脚里的静态工具按钮，避免遮住正文
    document.querySelectorAll('[data-sumi-action]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var act = btn.getAttribute('data-sumi-action');
        if (act === 'top') window.scrollTo({ top: 0, behavior: 'smooth' });
        if (act === 'panel') {
          var panel = document.getElementById('sumi-panel');
          if (panel) panel.hidden = !panel.hidden;
        }
      });
    });

    var bar = document.getElementById('sumi-progress');
    function progress() {
      if (!bar) return;
      var h = document.documentElement.scrollHeight - window.innerHeight;
      var p = h > 0 ? (window.scrollY / h) * 100 : 0;
      bar.style.width = Math.max(0, Math.min(100, p)) + '%';
      if (top) top.classList.toggle('show', window.scrollY > 400);
    }
    window.addEventListener('scroll', progress, { passive: true });
    progress();

    // 评论：fetch 提交，失败则退回普通表单
    var form = document.getElementById('sumi-comment-form');
    if (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var tip = document.getElementById('sumi-comment-tip');
        if (tip) { tip.textContent = '提交中…'; tip.className = 'sumi-comment-tip'; }
        fetch(form.action, { method: 'POST', body: new FormData(form), credentials: 'same-origin' })
          .then(function (r) { return r.json(); })
          .then(function (res) {
            if (res && (res.ok === 1 || res.ok === true)) {
              if (tip) { tip.textContent = res.msg || '评论成功，正在刷新…'; tip.className = 'sumi-comment-tip ok'; }
              setTimeout(function () { location.reload(); }, 900);
            } else {
              if (tip) { tip.textContent = (res && res.msg) ? res.msg : '提交失败，请稍后再试'; tip.className = 'sumi-comment-tip bad'; }
            }
          })
          .catch(function () { form.submit(); });
      });
    }

    // 内容区图片放大
    var content = document.getElementById('sumi-article-content');
    if (content) {
      content.addEventListener('click', function (e) {
        if (e.target.tagName !== 'IMG') return;
        var box = document.createElement('div');
        box.style.cssText = 'position:fixed;inset:0;z-index:99;background:rgba(0,0,0,.86);display:flex;align-items:center;justify-content:center;cursor:zoom-out;padding:2vh 2vw';
        var img = document.createElement('img');
        img.src = e.target.src;
        img.style.cssText = 'max-width:96vw;max-height:96vh;border-radius:.6rem';
        box.appendChild(img);
        box.addEventListener('click', function () { box.remove(); });
        document.body.appendChild(box);
      });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();