<?php
/**
 * sumi233 模板 · 归档页
 * 可用变量：$groups（年 => 文章数组）、$total
 */
$cur_p        = 'archive';
$banner_title = '归档';
$banner_sub   = '共 ' . (int) $total . ' 篇文章';
include partial_path('header.php');

$tops = array();
try {
    $tops = rows('SELECT id, title, slug, category_id, created_at, views FROM ' . moe_table('posts')
        . " WHERE type = 'post' AND status = 'published' AND is_top = 1 ORDER BY created_at DESC LIMIT 6");
} catch (PDOException $e) { /* 忽略 */ }
?>
<?php if (!empty($tops)): ?>
<section class="sumi-card sumi-tops">
  <h3 class="sumi-block-title">置顶文章</h3>
  <ul class="sumi-timeline">
    <?php foreach ($tops as $t): ?>
    <li>
      <span class="sumi-timeline-date"><?php echo e(format_time($t['created_at'], 'm-d')); ?></span>
      <a class="sumi-timeline-title" href="<?php echo e(post_url($t)); ?>"><?php echo e($t['title']); ?></a>
      <span class="sumi-timeline-views"><?php echo (int) $t['views']; ?> 阅读</span>
    </li>
    <?php endforeach; ?>
  </ul>
</section>
<?php endif; ?>

<?php if (empty($groups)): ?>
  <div class="sumi-empty">还没有文章可以归档。</div>
<?php else: ?>
  <?php foreach ($groups as $year => $items): ?>
  <section class="sumi-card sumi-archive-group">
    <h3 class="sumi-block-title"><span class="sumi-archive-year"><?php echo e($year); ?></span><span class="sumi-archive-count"><?php echo count($items); ?> 篇</span></h3>
    <ul class="sumi-timeline">
      <?php foreach ($items as $p): ?>
      <li>
        <span class="sumi-timeline-date"><?php echo e(format_time($p['created_at'], 'm-d')); ?></span>
        <a class="sumi-timeline-title" href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a>
        <span class="sumi-timeline-views"><?php echo isset($p['views']) ? (int) $p['views'] : 0; ?> 阅读</span>
      </li>
      <?php endforeach; ?>
    </ul>
  </section>
  <?php endforeach; ?>
<?php endif; ?>

<?php include partial_path('footer.php'); ?>