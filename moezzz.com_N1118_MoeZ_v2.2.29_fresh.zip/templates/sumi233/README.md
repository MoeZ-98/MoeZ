# sumi233 · 酥米复刻模板（MoeZ）

复刻 `sumi233.top`（Firefly 风格）的前台模板：全屏壁纸横幅、毛玻璃导航、卡片网格、
侧栏挂件、暗色模式、自动目录，配色与布局都能在后台「模板设置」里调。

## 安装 / 切换

1. 把整个 `sumi233` 目录放进博客根的 `templates/` 下（即 `templates/sumi233/`）；
2. 后台 → **模板管理** → 点「sumi233 · 酥米复刻」的切换按钮；
3. 后台 → **模板设置** → 按需调整（见下），改完直接生效。

> 需要伪静态（`.htaccess` 的 rewrite 或 Nginx `try_files $uri $uri/ /index.php?$query_string;`），
> 否则 `/archives`、`/分类名/` 这类地址会 404。

## 文件

| 文件 | 作用 |
| --- | --- |
| `info.php` | 模板信息 + 模板设置声明（后台读取） |
| `header.php` / `footer.php` | `<head>`、导航、壁纸、横幅 / 页脚、悬浮按钮、设置面板 |
| `index.php` | 首页：横幅 + 文章卡片网格 + 分页 + 侧栏 |
| `post.php` | 文章页：正文、目录、版权条、上/下一篇、相关文章、评论 |
| `category.php` `search.php` `article.php` `archive.php` `life.php` | 分类 / 搜索 / 写作列表 / 归档 / 点滴时间线 |
| `page.php` `about.php` `link.php` `404.php` `maintenance.php` | 独立页 / 关于 / 友链 / 404 / 维护 |
| `_post-card.php` `_sidebar.php` | 文章卡片、侧栏挂件片段 |
| `assets/theme.css` | 目标站点的设计变量与工具类（含深色主题变量） |
| `assets/sumi233.css` | 模板自己的布局与组件样式 |
| `assets/sumi233.js` | 明暗/色相、壁纸轮播、目录、阅读进度、设置面板、评论提交 |
| `assets/fonts` `assets/wallpapers` | 字体与 5 张桌面 / 5 张移动壁纸 |
| `screenshot.png` | 后台「模板管理」的预览图 |

## 模板设置（后台可调，共 37 项）

- **配色版式**：主题色相（0–360，整站着色基准）、页面宽度、正文字号、卡片透明度、卡片描边、卡片底色跟随色相
- **壁纸横幅**：壁纸模式（全屏/横幅/浮层/关闭）、默认壁纸、壁纸轮播、是否显示横幅文字、首页横幅高度、内页横幅高度、导航栏模糊、首页标题/副标题、波浪、顶部渐变高光
- **站点外观**：默认明暗（跟随系统/亮/暗）、Logo、头像、备案号、页脚附加内容
- **侧栏**：自我介绍（Markdown）、公告（HTML）、是否显示分类挂件、是否显示最新文章
- **内容细节**：导航搜索、文章目录、上/下一篇、相关文章、阅读量、阅读时长、版权条、评论区、樱花特效、标签样式（胶囊 / 圆角矩形）
- **关于页**：「关于正文」（Markdown；留空则显示站点名片）

前台左下角还有一个 ⚙ 面板，可以在本机浏览器里实时预览这些设置（只影响本机，不改服务器配置）。

## 说明

- 文章/页面/分类/友链/评论都走 CMS 自己的数据与路由，模板只负责呈现；
- 壁纸、字体、Logo 已随模板打包，不依赖外链；
- 主题色采用 `oklch(... var(--hue))`，改色相会同时影响背景、按钮、卡片与链接的色温。

---

# sumi233 · 目录与路径依赖

> 本主题在 **2.2.30 工程化改造**里随站点目录整理做了统一路径适配。
> **外观、布局、配色、页面结构与业务功能一律未改**，只把「写死目录」的写法收敛到统一适配层。

## 依赖的站点路径

| 路径 | 用途 | 状态 |
|---|---|---|
| `templates/sumi233/assets/` | 主题自带样式 / 脚本 / 字体 / 图标 | 原位保留，一律经 `theme_url()` 引用 |
| `favicon.ico`（站点根） | 图标最终兜底 | 原位保留 |
| `uploads/{image,video,audio,file}/YYYYMM/` | 正文图、封面、后台自定义图片 | 由 `includes/upload.php` 写入，经 `media_url()` 引用；文件名不再带时间戳，规则见 `docs/附件命名说明.md` |
| `includes/theme-assets.php` | 主题资源路径适配层 | 新增，由 `init.php` 自动加载 |

## 已归档、不要再引用的旧路径

- `favicon.png`、`docs.html` → `content/archive/legacy-assets/`；
- `tests/` 自测脚本与截图 → `content/archive/dev-tests/`；
- `templates/*.zip` 历史主题安装包 → `content/archive/theme-packages/`；
- `docs/` 下乱码命名的 md → 已合并为 `docs/更新说明-2.0.3-*.md` / `docs/更新说明-2.0.4-*.md`。

> 归档区不参与运行、不进在线更新包、Web 不可访问，**不要**把主题里的路径指过去。
> 全站目录职责见 `docs/目录导航.md`。

## 本主题本次的适配点

- 图标改走 `moe_theme_icon()`，保留「自定义 logo → 主题 favicon.ico」优先级；
- 补齐 `apple-touch-icon`。

## 以后目录再变，改哪里

1. 站内资源一律用 `theme_url()` / `media_url()`，不要在模板里写 `templates/xxx/`、`/uploads/xxx` 之类的绝对路径；
2. 图标统一走 `moe_theme_icon()` + `moe_icon_links()`；跨主题资源走 `moe_theme_asset()`；
   附件地址判断走 `moe_is_media_path()`；
3. 需要调整目录时，只改 `includes/theme-assets.php`（必要时同步 `includes/upload.php` 与部署配置），
   **7 套主题不用逐个翻代码**；
4. 主题侧所有适配调用都带 `function_exists()` 保护：万一在线更新只覆盖了半个包，
   会自动退回原来的写法，不会白屏。

## 🎙 版娘与语音（独立插件）

本主题的看板娘由 `content/plugins/moez-companion/` 插件提供，不再依赖任何单套主题的
CSS / JS。插件**首次部署自动启用**，通过 `front_head` / `front_footer` 钩子注入，
7 套主题通用；停用插件本主题的其它外观不受影响。

- 配置入口：后台 →「模板管理 → 模板设置 → 版娘与语音」，本主题 `info.php` 已声明该分组；
- 站点级默认：后台 →「站点设置 → 🎙 语音调试」，保存的值优先级高于主题设置；
- 男声 / 女声切换与调试：聊天窗头部 `♀ / ♂` 按钮、底部「🎙 语音调试」浮层，
  也可在 URL 加 `?voice_debug=1` 直接展开调试台；
- fomalhaut 主题另保留一份自带挂载块作为兼容回退，插件启用时自动让出，不会同页出现两套。

