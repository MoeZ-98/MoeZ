<?php
/**
 * sumi233 模板 · 搜索结果页
 * 可用变量：$posts、$kw、$pager、$total
 */
$cur_p        = 'search';
$banner_title = '搜索';
$banner_sub   = $kw !== '' ? ('关键词：' . $kw . ' · 命中 ' . (int) $total . ' 篇') : '';
include partial_path('header.php');
?>
<form class="sumi-card sumi-search-page" method="get" action="<?php echo e(base_url() . 'index.php'); ?>" role="search">
  <input type="hidden" name="p" value="search">
  <input type="search" name="q" value="<?php echo e($kw); ?>" placeholder="输入关键词后回车…" autofocus>
  <button type="submit">搜索</button>
</form>

<?php if ($kw === ''): ?>
  <div class="sumi-empty">输入关键词开始搜索。</div>
<?php elseif (empty($posts)): ?>
  <div class="sumi-empty">没有找到与「<?php echo e($kw); ?>」相关的文章。</div>
<?php else: ?>
  <div class="sumi-page-head">
    <h2 class="sumi-page-title">搜索结果</h2>
    <span class="sumi-page-count">共 <?php echo (int) $total; ?> 篇</span>
  </div>
  <div class="sumi-post-grid">
    <?php foreach ($posts as $p): ?>
      <?php $card_cat = null; include partial_path('_post-card.php'); ?>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php echo $pager; ?>
<?php include partial_path('footer.php'); ?>