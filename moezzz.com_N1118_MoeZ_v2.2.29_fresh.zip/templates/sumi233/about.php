<?php
/**
 * sumi233 模板 · 关于页（/about）
 * 内容取模板设置里的「关于正文」；留空时展示站点名片。
 */
$cur_p        = 'about';
$banner_title = '关于';
$banner_sub   = $site['sub'];
include partial_path('header.php');

$about_md = trim((string) theme_opt('about_md', ''));
$avatar   = trim((string) theme_opt('avatar', ''));
if ($avatar !== '') {
    $me_avatar = media_url($avatar);
} elseif (!empty($site['avatar'])) {
    $me_avatar = media_url($site['avatar']);
} else {
    $me_avatar = theme_url('assets/avatar.webp');
}
?>
<?php if ($about_md !== ''): ?>
<article class="sumi-card sumi-article">
  <header class="sumi-article-head"><h1 class="sumi-article-title">关于本站</h1></header>
  <div class="sumi-article-content">
    <?php echo render_content($about_md, 'markdown'); ?>
  </div>
</article>
<?php else: ?>
<section class="sumi-card sumi-about-card">
  <img class="sumi-about-avatar" src="<?php echo e($me_avatar); ?>" alt="<?php echo e($site['name']); ?>">
  <h2 class="sumi-about-name"><?php echo e($site['name']); ?></h2>
  <?php if (!empty($site['sub'])): ?><p class="sumi-about-sub"><?php echo e($site['sub']); ?></p><?php endif; ?>
  <?php if (!empty($site['desc'])): ?><p class="sumi-about-desc"><?php echo e($site['desc']); ?></p><?php endif; ?>
  <?php if (!empty($site['signature'])): ?><blockquote class="sumi-about-sign"><?php echo e($site['signature']); ?></blockquote><?php endif; ?>
  <div class="sumi-stats">
    <div><b><?php echo (int) $site['stats']['posts']; ?></b><span>文章</span></div>
    <div><b><?php echo (int) $site['stats']['comments']; ?></b><span>评论</span></div>
    <div><b><?php echo (int) $site['stats']['views']; ?></b><span>浏览</span></div>
  </div>
  <p class="sumi-about-tip">在「后台 → 模板设置 → 关于正文」里填写 Markdown 内容，这里就会替换成你自己的介绍。</p>
</section>
<?php endif; ?>
<?php include partial_path('footer.php'); ?>