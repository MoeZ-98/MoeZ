<?php
/**
 * sumi233 模板 · 侧边栏挂件
 */
$sb_profile = trim((string) theme_opt('sidebar_profile', ''));
$sb_ann     = trim((string) theme_opt('sidebar_announce', ''));
$avatar     = trim((string) theme_opt('avatar', ''));
if ($avatar !== '') {
    $avatar_url = media_url($avatar);
} elseif (!empty($site['avatar'])) {
    $avatar_url = media_url($site['avatar']);
} else {
    $avatar_url = theme_url('assets/avatar.webp');
}

$recent = array();
try {
    $recent = rows('SELECT id, title, slug, category_id, created_at, views FROM ' . moe_table('posts')
        . " WHERE type = 'post' AND status = 'published' ORDER BY is_top DESC, created_at DESC LIMIT 5");
} catch (PDOException $e) { /* 表未就绪时忽略 */ }

$cat_count = array();
try {
    $cat_count = rows('SELECT c.id, c.name, c.slug, COUNT(p.id) AS cnt FROM ' . moe_table('categories') . ' c'
        . ' LEFT JOIN ' . moe_table('posts') . " p ON p.category_id = c.id AND p.type = 'post' AND p.status = 'published'"
        . ' GROUP BY c.id, c.name, c.slug ORDER BY cnt DESC, c.id ASC');
} catch (PDOException $e) { /* 忽略 */ }

$social = array();
if (function_exists('moe_social_list')) {
    foreach (moe_social_list() as $soc) {
        $social[$soc['name']] = $soc['url'];
    }
} else {
    foreach (array('github' => 'GitHub', 'bilibili' => '哔哩哔哩', 'weibo' => '微博', 'twitter' => 'X', 'mail' => '邮箱') as $k => $label) {
        if (!empty($site[$k])) {
            $url = $k === 'mail' ? 'mailto:' . $site[$k] : $site[$k];
            $social[$label] = $url;
        }
    }
}
?>
<aside class="sumi-sidebar">

  <section class="sumi-widget sumi-profile">
    <div class="sumi-profile-head">
      <img class="sumi-profile-avatar" src="<?php echo e($avatar_url); ?>" alt="<?php echo e($site['name']); ?>">
      <div class="sumi-profile-name"><?php echo e($site['name']); ?></div>
      <?php if (!empty($site['sub'])): ?><div class="sumi-profile-sub"><?php echo e($site['sub']); ?></div><?php endif; ?>
    </div>
    <?php if (!empty($site['signature'])): ?><p class="sumi-profile-sign"><?php echo e($site['signature']); ?></p><?php endif; ?>
    <?php if ($sb_profile !== ''): ?><div class="sumi-md"><?php echo render_content($sb_profile, 'markdown'); ?></div><?php endif; ?>
    <div class="sumi-stats">
      <div><b><?php echo (int) $site['stats']['posts']; ?></b><span>文章</span></div>
      <div><b><?php echo (int) $site['stats']['comments']; ?></b><span>评论</span></div>
      <div><b><?php echo (int) $site['stats']['views']; ?></b><span>浏览</span></div>
    </div>
    <?php if (!empty($social)): ?>
    <div class="sumi-social">
      <?php foreach ($social as $label => $url): ?>
      <a href="<?php echo e($url); ?>" target="_blank" rel="noopener"><?php echo e($label); ?></a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </section>

  <?php if ($sb_ann !== ''): ?>
  <section class="sumi-widget sumi-announce">
    <h3 class="sumi-widget-title">公告</h3>
    <div class="sumi-widget-body"><?php echo $sb_ann; ?></div>
  </section>
  <?php endif; ?>

  <?php if (!empty($cat_count) && theme_opt('show_cats', '1') === '1'): ?>
  <section class="sumi-widget">
    <h3 class="sumi-widget-title">分类</h3>
    <ul class="sumi-cat-list">
      <?php foreach ($cat_count as $c): ?>
      <li><a href="<?php echo e(cat_url($c)); ?>"><span class="sumi-cat-name"><?php echo e($c['name']); ?></span><span class="sumi-count"><?php echo (int) $c['cnt']; ?></span></a></li>
      <?php endforeach; ?>
    </ul>
  </section>
  <?php endif; ?>

  <?php if (!empty($recent) && theme_opt('show_recent', '1') === '1'): ?>
  <section class="sumi-widget">
    <h3 class="sumi-widget-title">最新文章</h3>
    <ul class="sumi-recent-list">
      <?php foreach ($recent as $r): ?>
      <li>
        <a href="<?php echo e(post_url($r)); ?>"><?php echo e($r['title']); ?></a>
        <time><?php echo e(format_time($r['created_at'], 'Y-m-d')); ?></time>
      </li>
      <?php endforeach; ?>
    </ul>
  </section>
  <?php endif; ?>

  <section class="sumi-widget sumi-siteinfo">
    <h3 class="sumi-widget-title">站点</h3>
    <ul class="sumi-siteinfo-list">
      <li><a href="<?php echo e(rss_url()); ?>">RSS 订阅</a></li>
      <li><a href="<?php echo e(sitemap_url()); ?>">站点地图</a></li>
      <li><a href="<?php echo e(base_url() . 'archives'); ?>">文章归档</a></li>
      <li><a href="<?php echo e(base_url() . 'link'); ?>">友情链接</a></li>
      <?php if (!empty($site['rss'])): ?><li><a href="<?php echo e(base_url() . 'rss'); ?>">订阅源</a></li><?php endif; ?>
    </ul>
  </section>

</aside>