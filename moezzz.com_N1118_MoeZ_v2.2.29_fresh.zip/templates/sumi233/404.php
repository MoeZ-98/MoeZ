<?php
/**
 * sumi233 模板 · 404
 */
$cur_p        = '404';
$banner_title = '404';
$banner_sub   = '这条小路好像走不通了';
http_response_code(404);
include partial_path('header.php');
?>
<section class="sumi-card sumi-404">
  <p class="sumi-404-code">404</p>
  <h2 class="sumi-404-title">页面没有找到</h2>
  <p class="sumi-404-tip">你要找的内容可能被移动、删除，或者链接拼错了。</p>
  <div class="sumi-404-actions">
    <a class="sumi-btn" href="<?php echo e(home_url()); ?>">回到首页</a>
    <a class="sumi-btn sumi-btn-plain" href="<?php echo e(base_url() . 'archives'); ?>">看看归档</a>
  </div>
</section>
<?php include partial_path('footer.php'); ?>