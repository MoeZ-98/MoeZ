<?php
/**
 * sumi233 模板 · 独立页
 * 可用变量：$page（页面对象，注意不是页码）
 */
$cur_p        = 'page';
$banner_title = $page['title'];
$banner_sub   = '';
include partial_path('header.php');

$fmt = isset($page['content_format']) ? $page['content_format'] : 'markdown';
?>
<article class="sumi-card sumi-article">
  <header class="sumi-article-head">
    <h1 class="sumi-article-title"><?php echo e($page['title']); ?></h1>
    <div class="sumi-article-meta">
      <time datetime="<?php echo e($page['created_at']); ?>"><?php echo e(format_time($page['created_at'])); ?></time>
      <?php if (!empty($page['updated_at']) && $page['updated_at'] !== $page['created_at']): ?>
      <span>更新于 <?php echo e(format_time($page['updated_at'], 'Y-m-d')); ?></span>
      <?php endif; ?>
    </div>
  </header>

  <?php if (theme_opt('show_toc', '1') === '1'): ?>
  <nav class="sumi-toc" id="sumi-toc" hidden>
    <div class="sumi-toc-head"><span>目录</span><button type="button" id="sumi-toc-toggle" title="折叠">−</button></div>
    <div class="sumi-toc-body" id="sumi-toc-body"></div>
  </nav>
  <?php endif; ?>

  <div class="sumi-article-content" id="sumi-article-content">
    <?php echo render_content($page['content'], $fmt); ?>
  </div>
</article>

<?php include partial_path('footer.php'); ?>