<?php
/**
 * sumi233 模板 · 首页（文章卡片网格 + 分页）
 * 可用变量：$posts（含 cat_name/cat_slug）、$pager、$page、$total
 */
$cur_p = 'index';
include partial_path('header.php');

$show_views   = theme_opt('show_views', '1') === '1';
$show_reading = theme_opt('show_reading', '1') === '1';
?>
<div class="sumi-page-head">
  <h2 class="sumi-page-title">最新文章</h2>
  <span class="sumi-page-count">共 <?php echo (int) $total; ?> 篇</span>
</div>

<?php if (empty($posts)): ?>
  <div class="sumi-empty">还没有文章，去后台写一篇吧～</div>
<?php else: ?>
<div class="sumi-post-grid">
  <?php foreach ($posts as $p): $cover = post_cover($p); ?>
  <article class="sumi-card sumi-post-card">
    <a class="sumi-post-cover<?php echo $cover ? '' : ' is-empty'; ?>" href="<?php echo e(post_url($p)); ?>">
      <?php if ($cover): ?>
      <img src="<?php echo e(media_url($cover)); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy">
      <?php else: ?>
      <span class="sumi-post-cover-text" aria-hidden="true"></span>
      <?php endif; ?>
      <?php if (!empty($p['is_top'])): ?><span class="sumi-pin">置顶</span><?php endif; ?>
    </a>
    <div class="sumi-post-body">
      <h3 class="sumi-post-title"><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
      <p class="sumi-post-excerpt"><?php echo e(post_excerpt($p, 88)); ?></p>
      <div class="sumi-post-meta">
        <?php if (!empty($p['cat_name'])): ?>
        <a class="sumi-chip" href="<?php echo e(cat_url(array('id' => $p['cat_id'], 'name' => $p['cat_name'], 'slug' => $p['cat_slug']))); ?>"><?php echo e($p['cat_name']); ?></a>
        <?php endif; ?>
        <time datetime="<?php echo e($p['created_at']); ?>"><?php echo e(format_time($p['created_at'])); ?></time>
        <?php if ($show_views && isset($p['views'])): ?><span><?php echo (int) $p['views']; ?> 阅读</span><?php endif; ?>
        <?php if ($show_reading): ?><span>约 <?php echo reading_time($p); ?> 分钟</span><?php endif; ?>
      </div>
    </div>
  </article>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php echo $pager; ?>
<?php include partial_path('footer.php'); ?>