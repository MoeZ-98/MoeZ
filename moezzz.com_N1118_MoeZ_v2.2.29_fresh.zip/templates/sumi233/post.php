<?php
/**
 * sumi233 模板 · 文章页
 * 可用变量：$post、$cat、$prev、$next、$comments
 */
$cur_p        = 'post';
$banner_title = $post['title'];
$banner_sub   = format_time($post['created_at'], 'Y-m-d');
include partial_path('header.php');

$fmt          = isset($post['content_format']) ? $post['content_format'] : 'markdown';
$show_views   = theme_opt('show_views', '1') === '1';
$show_reading = theme_opt('show_reading', '1') === '1';
$show_comment = theme_opt('show_comments', '1') === '1' && setting('comment_enabled', '1') === '1';

$related = array();
if (theme_opt('show_related', '1') === '1' && !empty($cat)) {
    try {
        $related = rows('SELECT id, title, slug, category_id, created_at, views FROM ' . moe_table('posts')
            . " WHERE type = 'post' AND status = 'published' AND category_id = ? AND id <> ?"
            . ' ORDER BY created_at DESC LIMIT 3', array((int) $cat['id'], (int) $post['id']));
    } catch (PDOException $e) { /* 忽略 */ }
}
?>
<article class="sumi-card sumi-article" id="sumi-article">

  <header class="sumi-article-head">
    <h1 class="sumi-article-title"><?php echo e($post['title']); ?></h1>
    <div class="sumi-article-meta">
      <?php if (!empty($cat)): ?>
      <a class="sumi-chip" href="<?php echo e(cat_url($cat)); ?>"><?php echo e($cat['name']); ?></a>
      <?php endif; ?>
      <time datetime="<?php echo e($post['created_at']); ?>"><?php echo e(format_time($post['created_at'], 'Y-m-d')); ?></time>
      <?php if ($show_views): ?><span><?php echo (int) $post['views']; ?> 阅读</span><?php endif; ?>
      <?php if ($show_reading): ?><span>约 <?php echo reading_time($post); ?> 分钟</span><?php endif; ?>
      <span><?php echo (int) content_words($post['content'], $fmt); ?> 字</span>
    </div>
  </header>

  <?php if (theme_opt('show_toc', '1') === '1'): ?>
  <nav class="sumi-toc" id="sumi-toc" hidden>
    <div class="sumi-toc-head"><span>目录</span><button type="button" id="sumi-toc-toggle" title="折叠">−</button></div>
    <div class="sumi-toc-body" id="sumi-toc-body"></div>
  </nav>
  <?php endif; ?>

  <?php /* 文章详情页不展示封面：封面只在列表卡片里使用 */ ?>

  <div class="sumi-article-content" id="sumi-article-content">
    <?php echo render_content($post['content'], $fmt); ?>
  </div>

  <?php echo function_exists('post_tags_html') ? post_tags_html($post) : ''; ?>

  <?php if (theme_opt('show_meta_bar', '1') === '1'): ?>
  <div class="sumi-license">
    <p><b><?php echo e($post['title']); ?></b></p>
    <p>作者：<?php echo e($site['author'] ? $site['author'] : $site['name']); ?> · 链接：<a href="<?php echo e(post_url($post)); ?>"><?php echo e(post_url($post)); ?></a></p>
    <p>版权：本文采用 <b>署名-非商业性使用-相同方式共享 4.0 国际</b>（CC BY-NC-SA 4.0）许可协议，转载请注明出处。</p>
    <?php if (!empty($post['updated_at']) && $post['updated_at'] !== $post['created_at']): ?>
    <p class="sumi-license-updated">最后更新：<?php echo e(format_time($post['updated_at'], 'Y-m-d')); ?></p>
    <?php endif; ?>
  </div>
  <?php endif; ?>
</article>

<?php if (theme_opt('show_prev_next', '1') === '1' && (!empty($prev) || !empty($next))): ?>
<nav class="sumi-prev-next">
  <?php if (!empty($prev)): ?>
  <a class="sumi-card sumi-prev" href="<?php echo e(post_url($prev)); ?>"><small>上一篇</small><span><?php echo e($prev['title']); ?></span></a>
  <?php else: ?><span class="sumi-card sumi-prev is-empty"><small>上一篇</small><span>没有更早的文章了</span></span><?php endif; ?>
  <?php if (!empty($next)): ?>
  <a class="sumi-card sumi-next" href="<?php echo e(post_url($next)); ?>"><small>下一篇</small><span><?php echo e($next['title']); ?></span></a>
  <?php else: ?><span class="sumi-card sumi-next is-empty"><small>下一篇</small><span>没有更新的文章了</span></span><?php endif; ?>
</nav>
<?php endif; ?>

<?php if (!empty($related)): ?>
<section class="sumi-related">
  <h3 class="sumi-block-title">相关文章</h3>
  <ul class="sumi-related-list">
    <?php foreach ($related as $r): ?>
    <li>
      <a href="<?php echo e(post_url($r)); ?>"><?php echo e($r['title']); ?></a>
      <time><?php echo e(format_time($r['created_at'], 'Y-m-d')); ?></time>
    </li>
    <?php endforeach; ?>
  </ul>
</section>
<?php endif; ?>

<?php if ($show_comment): ?>
<section class="sumi-card sumi-comments" id="sumi-comments">
  <h3 class="sumi-block-title">评论 <span class="sumi-comment-count"><?php echo count($comments); ?></span></h3>

  <?php if (empty($comments)): ?>
  <p class="sumi-comment-empty">还没有评论，来抢个沙发～</p>
  <?php else: ?>
  <ul class="sumi-comment-list">
    <?php foreach ($comments as $c): ?>
    <li class="sumi-comment">
      <div class="sumi-comment-avatar"><?php echo e(initial($c['author'])); ?></div>
      <div class="sumi-comment-main">
        <div class="sumi-comment-head">
          <b><?php echo e($c['author']); ?></b>
          <time><?php echo e(nice_time($c['created_at'])); ?></time>
          <?php $__sloc = function_exists('moe_comment_loc') ? moe_comment_loc($c) : (isset($c['location']) ? trim($c['location']) : ''); ?>
          <?php if ($__sloc !== ''): ?><span class="sumi-comment-loc"><?php echo e($__sloc); ?></span><?php endif; ?>
        </div>
        <div class="sumi-comment-text"><?php echo nl2br(e($c['content'])); ?></div>
      </div>
    </li>
    <?php endforeach; ?>
  </ul>
  <?php endif; ?>

  <form class="sumi-comment-form" id="sumi-comment-form" method="post" action="<?php echo e(base_url() . 'comment.php'); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="post_id" value="<?php echo (int) $post['id']; ?>">
    <?php $__cdf = function_exists('moe_comment_defaults') ? moe_comment_defaults() : array('author' => '', 'email' => '', 'admin' => false); ?>
    <div class="sumi-comment-row">
      <input type="text" name="author" maxlength="30" placeholder="昵称（必填）" required value="<?php echo e($__cdf['author']); ?>">
      <input type="email" name="email" maxlength="100" placeholder="邮箱（选填，不公开）" value="<?php echo e($__cdf['email']); ?>">
    </div>
    <?php if (!empty($__cdf['admin'])): ?><p style="font-size:12px;color:#9a8fae;margin:-4px 0 8px">👋 站长已登录，已自动填入你的信息</p><?php endif; ?>
    <textarea name="content" maxlength="1000" rows="5" placeholder="说点什么…" required></textarea>
    <div class="sumi-comment-actions">
      <span class="sumi-comment-tip" id="sumi-comment-tip"></span>
      <button type="submit">发表评论</button>
    </div>
  </form>
</section>
<?php endif; ?>

<?php
$page_script = (isset($page_script) ? $page_script : '') . '';
include partial_path('footer.php'); ?>