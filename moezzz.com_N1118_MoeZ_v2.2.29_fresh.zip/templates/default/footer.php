<?php
/** 模板公共底部（在模板文件内通过 include partial_path('footer.php') 引入） */
$links = rows('SELECT * FROM ' . moe_table('links') . ' ORDER BY sort, id');
// 只展示已通过审核的友链（待审核 / 下架的不出现在前台）
$links = array_values(array_filter((array)$links, function ($l) {
    return !isset($l['status']) || $l['status'] === 'approved';
}));
?>
</main>

<?php if (!empty($links) && !(isset($hide_links) && $hide_links)): ?>
<section class="container">
  <div class="section-title"><h2>友情链接</h2><a class="more" href="mailto:<?php echo e($site['mail']); ?>">申请友链 →</a></div>
  <div class="links-grid">
    <?php foreach ($links as $l): ?>
      <?php
        $ico = function_exists('link_icon') ? link_icon($l) : '';
        $ld  = function_exists('link_desc') ? link_desc($l) : '';
        $sub = $ld !== '' ? $ld : ('🔗 ' . (parse_url($l['url'], PHP_URL_HOST) ?: $l['url']));
      ?>
      <a class="link-card" href="<?php echo e($l['url']); ?>" target="_blank" rel="noopener nofollow" title="<?php echo e($l['name']); ?>">
        <span class="face" style="overflow:hidden">
          <?php if ($ico !== ''): ?>
            <img src="<?php echo e($ico); ?>" alt="<?php echo e(initial($l['name'])); ?>" loading="lazy"
                 style="width:100%;height:100%;object-fit:cover;display:block"
                 onerror="this.parentNode.textContent=this.alt">
          <?php else: ?>
            <?php echo e(initial($l['name'])); ?>
          <?php endif; ?>
        </span>
        <span style="min-width:0">
          <b><?php echo e($l['name']); ?></b>
          <span style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo e($sub); ?></span>
        </span>
      </a>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<footer class="footer">
  <div class="container">
    <p><?php echo $site['footer'] ? e($site['footer']) : '© ' . date('Y') . ' ' . e($site['name']); ?></p>
    <p style="margin-top:6px">Made with <span class="heart">♥</span> · MoeZ v<?php echo MOE_VERSION; ?> · <?php echo round(microtime(true) - ($_SERVER['REQUEST_TIME_FLOAT'] ?? microtime(true)), 4) * 1000; ?>ms</p>
  </div>
</footer>

<button class="back-top" id="backTop" title="返回顶部" aria-label="返回顶部">↑</button>
<script>
(function () {
  var bt = document.getElementById('backTop');
  window.addEventListener('scroll', function () {
    if (window.scrollY > 320) bt.classList.add('show'); else bt.classList.remove('show');
  }, { passive: true });
  bt.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });

  // 伪静态搜索：/search/关键词
  var sf = document.querySelector('.nav-search');
  if (sf && sf.getAttribute('data-pretty') === '1') {
    sf.addEventListener('submit', function (ev) {
      var q = sf.querySelector('input[name=q]');
      if (!q || !q.value.trim()) return;
      ev.preventDefault();
      location.href = sf.getAttribute('data-base') + 'search/' + encodeURIComponent(q.value.trim());
    });
  }
})();
</script>
</body>
</html>
