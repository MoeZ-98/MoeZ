<?php header('Content-Type: text/html; charset=utf-8'); ?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>站点维护中 · <?php echo e(setting('site_name', 'MoeZ')); ?></title>
<style>
body{margin:0;font-family:"PingFang SC","Microsoft YaHei",sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;
  background:linear-gradient(135deg,#fff1f4,#f3f0ff,#eef6ff);color:#453a54;text-align:center}
.box{padding:40px}
.face{font-size:70px;animation:float 2.6s ease-in-out infinite;display:block}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-14px)}}
h1{background:linear-gradient(135deg,#ff7eb3,#a18cd1);-webkit-background-clip:text;background-clip:text;color:transparent;font-size:26px;margin:18px 0 8px}
p{color:#9a8fae;font-size:14px}
</style>
</head>
<body>
<div class="box">
  <span class="face">🛠️</span>
  <h1>小站正在维护中…</h1>
  <p><?php echo e(setting('site_name', 'MoeZ')); ?> 稍后回来哦，马上就好啦～</p>
</div>
</body>
</html>
