<?php
/** 模板公共头部（在模板文件内通过 include partial_path('header.php') 引入） */
/** @var array $site  @var array $nav_cats */
$cur = isset($cur_p) ? $cur_p : 'index';
$pretty = is_pretty_url();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo seo_head(); ?>
<meta name="theme-color" content="#ff7eb3">
<?php
/* 目录适配：default 历来只用主题自带图标，不跟随站点头像；文件缺失时回退根 favicon.ico */
$moe_icon_ready = function_exists('moe_theme_icon') && function_exists('moe_icon_links');
$moe_icon_raw   = '';
$moe_favicon = $moe_icon_ready ? moe_theme_icon($moe_icon_raw, 'assets/avatar.svg')
                              : ($moe_icon_raw !== '' ? $moe_icon_raw : theme_url('assets/avatar.svg'));
echo $moe_icon_ready ? moe_icon_links($moe_favicon)
                     : '<link rel="icon" href="' . e($moe_favicon) . '">' . "\n";
?>
<link rel="alternate" type="application/rss+xml" title="<?php echo e($site['name']); ?>" href="<?php echo e(rss_url()); ?>">
<link rel="stylesheet" href="<?php echo e(theme_url('assets/style.css')); ?>?v=<?php echo MOE_VERSION; ?>">
</head>
<body>
<div class="blobs"></div>

<nav class="nav">
  <div class="nav-inner">
    <a class="logo" href="<?php echo e(home_url()); ?>">
      <span class="mark">🌸</span><?php echo e($site['name']); ?>
    </a>
    <div class="nav-links">
      <a href="<?php echo e(home_url()); ?>" class="<?php echo $cur === 'index' ? 'cur' : ''; ?>">首页</a>
      <?php foreach ($nav_cats as $c): ?>
        <a href="<?php echo e(cat_url($c)); ?>" class="<?php echo (isset($cat) && $cat['id'] == $c['id']) ? 'cur' : ''; ?>">
          <?php echo e($c['name']); ?>
        </a>
      <?php endforeach; ?>
      <?php if ($site['mail']): ?><a href="mailto:<?php echo e($site['mail']); ?>">留言</a><?php endif; ?>
      <form class="nav-search" action="<?php echo e(base_url() . 'index.php'); ?>" method="get"
            data-pretty="<?php echo $pretty ? '1' : '0'; ?>" data-base="<?php echo e(base_url()); ?>">
        <input type="hidden" name="p" value="search">
        <input type="text" name="q" placeholder="搜索文章…" value="<?php echo isset($kw) ? e($kw) : ''; ?>">
      </form>
    </div>
  </div>
</nav>

<main class="container">
