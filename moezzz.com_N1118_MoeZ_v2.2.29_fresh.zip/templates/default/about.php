<?php
/**
 * 模板：关于页（路由 /about）
 * 可用变量：$site（name,sub,desc,signature,avatar,mail,github,bilibili,weibo,twitter,rss,stats{posts,comments,views},version）
 *           $nav_cats
 * 说明：本页无额外数据变量，内容由 $site 与 site_stats() 驱动；
 *       若模板声明了设置项 about_md（Markdown），有值时优先渲染它。
 */
$page_title = '关于';
$cur_p = 'about';
include partial_path('header.php');

$about_md = trim(theme_opt('about_md', ''));
$stats = (!empty($site['stats']) && is_array($site['stats'])) ? $site['stats'] : site_stats();
?>

<div class="simple-page">
  <article class="article">
    <header class="article-header" style="border-bottom:0;padding-bottom:0">
      <?php if (!empty($site['avatar'])): ?>
        <img src="<?php echo e(media_url($site['avatar'])); ?>" alt="<?php echo e($site['name']); ?> 的头像"
             style="width:96px;height:96px;border-radius:50%;object-fit:cover;border:3px solid #fff;box-shadow:var(--shadow);margin:0 auto 14px">
      <?php endif; ?>
      <h1><?php echo e($site['name']); ?></h1>
      <div class="meta">
        <?php if (!empty($site['signature'])): ?><span><?php echo e($site['signature']); ?></span><?php endif; ?>
        <?php if (!empty($site['sub'])): ?><span><?php echo e($site['sub']); ?></span><?php endif; ?>
        <?php if (!empty($site['author'])): ?><span>✍️ <?php echo e($site['author']); ?></span><?php endif; ?>
      </div>
    </header>

    <div class="stat-bar">
      <div class="stat"><b><?php echo (int)$stats['posts']; ?></b><span>文章</span></div>
      <div class="stat"><b><?php echo (int)$stats['comments']; ?></b><span>评论</span></div>
      <div class="stat"><b><?php echo (int)$stats['views']; ?></b><span>浏览</span></div>
    </div>

    <div class="article-content md-body">
      <?php if ($about_md !== ''): ?>
        <?php echo render_content($about_md, 'markdown'); ?>
      <?php else: ?>
        <p><?php echo e(!empty($site['desc']) ? $site['desc'] : '这里记录代码、生活与一些小小的好奇。'); ?></p>
        <p>
          目前这个小站已经写下 <b><?php echo (int)$stats['posts']; ?></b> 篇文章，
          收到 <b><?php echo (int)$stats['comments']; ?></b> 条评论，
          累计被浏览 <b><?php echo (int)$stats['views']; ?></b> 次。
        </p>
        <p>
          如果喜欢这里，欢迎通过 <a href="<?php echo e(rss_url()); ?>">RSS</a> 订阅，
          或者在任意一篇文章下面留言聊聊～
        </p>
      <?php endif; ?>
    </div>

    <div class="article-tags">
      <?php if (!empty($site['github'])): ?><a class="btn ghost" href="<?php echo e($site['github']); ?>" target="_blank" rel="noopener">🐱 GitHub</a><?php endif; ?>
      <?php if (!empty($site['bilibili'])): ?><a class="btn ghost" href="<?php echo e($site['bilibili']); ?>" target="_blank" rel="noopener">📺 哔哩哔哩</a><?php endif; ?>
      <?php if (!empty($site['weibo'])): ?><a class="btn ghost" href="<?php echo e($site['weibo']); ?>" target="_blank" rel="noopener">🔥 微博</a><?php endif; ?>
      <?php if (!empty($site['twitter'])): ?><a class="btn ghost" href="<?php echo e($site['twitter']); ?>" target="_blank" rel="noopener">🐦 X / Twitter</a><?php endif; ?>
      <?php if (!empty($site['mail'])): ?><a class="btn ghost" href="mailto:<?php echo e($site['mail']); ?>">✉️ 邮件</a><?php endif; ?>
      <a class="btn ghost" href="<?php echo e(rss_url()); ?>" target="_blank" rel="noopener">📡 RSS</a>
    </div>
  </article>
</div>

<?php include partial_path('footer.php'); ?>