<?php $page_title = '404 Not Found'; include partial_path('header.php'); ?>
<div class="empty-box" style="margin:60px 0">
  <span class="big">🎀(๑°⌓°๑)</span>
  <h2 style="margin-bottom:8px">404 · 页面去二次元了</h2>
  <p>你要找的内容不存在、已被删除，或者根本就是别的次元的链接～</p>
  <a class="btn" href="<?php echo u(); ?>">回到首页 🏠</a>
</div>
<?php include partial_path('footer.php'); ?>
