<?php
/**
 * 模板：文章详情页
 * 可用变量：$post $cat $prev $next $comments $site $nav_cats
 */
$page_title = $post['title'];
$cur_p = 'post';
include partial_path('header.php');
?>

<div class="article-wrap">
  <article class="article">
    <header class="article-header">
      <div class="meta">
        <?php if ($cat): ?>
          <a class="cat" style="background:var(--grad);color:#fff;padding:3px 14px;border-radius:999px;font-size:12px;font-weight:600"
             href="<?php echo e(cat_url($cat)); ?>"><?php echo e($cat['name']); ?></a>
        <?php endif; ?>
      </div>
      <h1><?php echo e($post['title']); ?></h1>
      <div class="meta">
        <span>📅 <?php echo e(format_time($post['created_at'], 'Y-m-d')); ?></span>
        <?php if (!empty($post['updated_at']) && substr($post['updated_at'], 0, 10) !== substr($post['created_at'], 0, 10)): ?>
          <span>🔄 更新于 <?php echo e(format_time($post['updated_at'], 'Y-m-d')); ?></span>
        <?php endif; ?>
        <span>👀 <?php echo (int)$post['views']; ?> 次阅读</span>
        <span>⏱ 约 <?php echo reading_time($post); ?> 分钟</span>
        <?php if ($site['author']): ?><span>✍️ <?php echo e($site['author']); ?></span><?php endif; ?>
      </div>
    </header>

    <div class="article-content md-body">
      <?php echo render_content($post['content'], isset($post['content_format']) ? $post['content_format'] : 'html'); ?>
    </div>

    <?php echo function_exists('post_tags_html') ? post_tags_html($post) : ''; ?>

    <?php if ($post['slug']): ?>
    <div class="article-tags">
      <span style="font-size:12px;color:var(--muted)">本文链接：</span>
      <code style="font-size:12px;background:rgba(161,140,209,.12);padding:3px 10px;border-radius:8px"><?php echo e(post_url($post)); ?></code>
    </div>
    <?php endif; ?>
  </article>

  <nav class="post-nav">
    <?php if ($prev): ?>
      <a href="<?php echo e(post_url($prev)); ?>"><span class="lab">← 上一篇</span><?php echo e($prev['title']); ?></a>
    <?php else: ?><span></span><?php endif; ?>
    <?php if ($next): ?>
      <a class="next" href="<?php echo e(post_url($next)); ?>"><span class="lab">下一篇 →</span><?php echo e($next['title']); ?></a>
    <?php endif; ?>
  </nav>

  <section class="comments">
    <h2>评论（<?php echo count($comments); ?>）</h2>

    <?php if (!empty($comments)): ?>
      <div class="comment-list">
        <?php foreach ($comments as $c): ?>
          <div class="comment-item">
            <div class="face"><?php echo e(initial($c['author'])); ?></div>
            <div class="c-body">
              <div class="c-head"><b><?php echo e($c['author']); ?></b><time><?php echo e(nice_time($c['created_at'])); ?></time></div>
              <div class="c-text"><?php echo nl2br(e($c['content'])); ?></div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if (setting('comment_enabled', '1') === '1'):
      $__cdf = function_exists('moe_comment_defaults') ? moe_comment_defaults() : array('author' => '', 'email' => '', 'admin' => false);
    ?>
      <form class="comment-form" id="cform" method="post" action="<?php echo e(base_url() . 'comment.php'); ?>">
        <input type="hidden" name="post_id" value="<?php echo (int)$post['id']; ?>">
        <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
        <h3>发表评论</h3>
        <div class="row">
          <input type="text" name="author" placeholder="昵称 *" maxlength="30" required value="<?php echo e($__cdf['author']); ?>">
          <input type="email" name="email" placeholder="邮箱（选填，不会公开）" value="<?php echo e($__cdf['email']); ?>">
        </div>
        <?php if (!empty($__cdf['admin'])): ?><p class="hint" style="font-size:12px;color:var(--muted);margin:-4px 0 8px">👋 站长已登录，已自动填入你的信息</p><?php endif; ?>
        <textarea name="content" placeholder="说点什么吧～（支持 1000 字以内）" maxlength="1000" required></textarea>
        <div style="margin-top:14px;text-align:right">
          <button class="btn" type="submit" id="csubmit">🚀 发射评论</button>
        </div>
        <p id="cmsg" style="font-size:13px;margin-top:10px;display:none"></p>
      </form>
      <script>
      document.getElementById('cform').addEventListener('submit', function (e) {
        e.preventDefault();
        var btn = document.getElementById('csubmit'), msg = document.getElementById('cmsg');
        btn.disabled = true; btn.textContent = '发射中…';
        fetch(this.action, { method: 'POST', body: new FormData(this) })
          .then(function (r) { return r.json(); })
          .then(function (d) {
            msg.style.display = 'block';
            msg.style.color = d.ok ? '#3fb984' : '#e0566b';
            msg.textContent = d.ok ? d.msg : d.msg;
            if (d.ok) setTimeout(function () { location.reload(); }, 900);
            else { btn.disabled = false; btn.textContent = '🚀 发射评论'; }
          })
          .catch(function () {
            msg.style.display = 'block'; msg.style.color = '#e0566b';
            msg.textContent = '网络开小差了，请重试';
            btn.disabled = false; btn.textContent = '🚀 发射评论';
          });
      });
      </script>
    <?php else: ?>
      <div class="empty-box" style="padding:30px"><p>评论区暂时关闭啦～</p></div>
    <?php endif; ?>
  </section>
</div>

<?php include partial_path('footer.php'); ?>
