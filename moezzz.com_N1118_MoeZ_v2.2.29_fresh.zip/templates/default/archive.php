<?php
/**
 * 模板：归档页（路由 /archives）
 * 可用变量：$groups（年份字符串 => 文章行数组，行含 id,title,slug,type,category_id,url_num,content,created_at）
 *           $total（全部文章数）  $site  $nav_cats
 */
$page_title = '归档';
$cur_p = 'archive';
include partial_path('header.php');
?>

<header class="hero" style="padding-bottom:16px">
  <h1>🗂 归档</h1>
  <p class="sub">共 <?php echo (int)$total; ?> 篇文章 · <?php echo count((array)$groups); ?> 个年份，按时间倒序排列</p>
</header>

<?php if (empty($groups)): ?>
  <div class="empty-box">
    <span class="big">🌱</span>
    <p>还没有可以归档的文章，先去后台写一篇吧～</p>
    <a class="btn" href="<?php echo e(u()); ?>">回到首页</a>
  </div>
<?php else: ?>
  <?php if (count((array)$groups) > 1): ?>
    <div class="chips" style="justify-content:center">
      <?php foreach ($groups as $year => $year_items): ?>
        <a href="#y<?php echo e($year); ?>"><?php echo e($year); ?> <span style="opacity:.65">· <?php echo count((array)$year_items); ?></span></a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <?php foreach ($groups as $year => $items): ?>
    <section class="tl-group" id="y<?php echo e($year); ?>">
      <div class="tl-head">
        <h2><?php echo e($year); ?></h2>
        <span class="tl-count"><?php echo count((array)$items); ?> 篇</span>
      </div>
      <ul class="tl-list">
        <?php foreach ((array)$items as $p): ?>
          <?php
            $arc_title = isset($p['title']) ? $p['title'] : '';
            $arc_link  = !empty($p['id']) ? post_url($p) : '#';
            $arc_date  = isset($p['created_at']) ? format_time($p['created_at'], 'm-d') : '';
            $arc_min   = isset($p['content']) ? (int)reading_time($p) : 1;
          ?>
          <li class="tl-item">
            <span class="tl-date"><?php echo e($arc_date); ?></span>
            <a class="tl-title" href="<?php echo e($arc_link); ?>"><?php echo e($arc_title !== '' ? $arc_title : '（无标题）'); ?></a>
            <span class="tl-extra">⏱ 约 <?php echo $arc_min; ?> 分钟</span>
          </li>
        <?php endforeach; ?>
      </ul>
    </section>
  <?php endforeach; ?>
<?php endif; ?>

<?php include partial_path('footer.php'); ?>