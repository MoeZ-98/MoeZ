<?php
/**
 * 模板：独立页面
 * 可用变量：$page $site $nav_cats
 */
$page_title = $page['title'];
$cur_p = 'page';
$hide_links = false;
include partial_path('header.php');
?>

<div class="simple-page">
  <article class="article">
    <header class="article-header">
      <h1 style="margin:0"><?php echo e($page['title']); ?></h1>
      <div class="meta" style="margin-top:12px">📅 更新于 <?php echo e(format_time($page['updated_at'], 'Y-m-d')); ?></div>
    </header>
    <div class="article-content md-body">
      <?php echo render_content($page['content'], isset($page['content_format']) ? $page['content_format'] : 'html'); ?>
    </div>
  </article>
</div>

<?php include partial_path('footer.php'); ?>
