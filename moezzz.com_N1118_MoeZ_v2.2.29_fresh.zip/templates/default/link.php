<?php
/**
 * 模板：友情链接（路由 /link）
 * 可用变量：$links（links 表行数组，字段 id,name,url,logo,description,contact,status,sort,created_at）
 *           $site  $nav_cats
 * 说明：申请表单提交到站点根 link.php，字段为 url（必填）/ name / contact，带 CSRF 令牌；
 *       后端会抓取对方站点名称并检测回链，已加回链自动审核通过，否则转人工审核。
 */
$page_title = '友情链接';
$cur_p = 'link';
$hide_links = true; // 本页已完整展示友链，隐藏页脚的友链区块避免重复
include partial_path('header.php');
?>

<header class="hero" style="padding-bottom:16px">
  <h1>🔗 友情链接</h1>
  <p class="sub">共收录 <?php echo count((array)$links); ?> 位朋友，欢迎来串门～</p>
</header>

<?php if (empty($links)): ?>
  <div class="empty-box">
    <span class="big">🤝</span>
    <p>还没有友链，来和我交个朋友吧～</p>
  </div>
<?php else: ?>
  <div class="links-grid">
    <?php foreach ((array)$links as $l): ?>
      <?php
        $l_name = isset($l['name']) ? $l['name'] : '';
        $l_url  = isset($l['url']) ? $l['url'] : '';
        $l_ico  = function_exists('link_icon') ? link_icon($l) : '';
        $l_desc = function_exists('link_desc') ? link_desc($l) : '';
        $l_sub  = $l_desc !== '' ? $l_desc : ('🔗 ' . (parse_url($l_url, PHP_URL_HOST) ?: $l_url));
      ?>
      <a class="link-card" href="<?php echo e($l_url); ?>" target="_blank" rel="noopener nofollow" title="<?php echo e($l_name); ?>">
        <span class="face" style="overflow:hidden">
          <?php if ($l_ico !== ''): ?>
            <img src="<?php echo e($l_ico); ?>" alt="<?php echo e(initial($l_name)); ?>" loading="lazy"
                 style="width:100%;height:100%;object-fit:cover;display:block"
                 onerror="this.parentNode.textContent=this.alt">
          <?php else: ?>
            <?php echo e(initial($l_name)); ?>
          <?php endif; ?>
        </span>
        <span style="min-width:0">
          <b><?php echo e($l_name); ?></b>
          <span style="display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?php echo e($l_sub); ?></span>
        </span>
      </a>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<section style="margin-top:34px">
  <div class="section-title">
    <h2>申请友链</h2>
    <?php if (!empty($site['mail'])): ?><a class="more" href="mailto:<?php echo e($site['mail']); ?>">站长发邮件 →</a><?php endif; ?>
  </div>
  <form class="comment-form" id="linkForm" method="post" action="<?php echo e(base_url() . 'link.php'); ?>">
    <?php echo csrf_field(); ?>
    <p style="font-size:13px;color:var(--muted);margin-bottom:14px">
      填好站点地址即可提交，系统会自动访问你的站点检测回链：<br>
      · 已添加本站链接 → 自动通过并展示<br>
      · 未检测到 → 转人工审核，站长会尽快处理
    </p>
    <div class="row">
      <input type="url" name="url" placeholder="你的站点地址 *（如 https://example.com）" required>
    </div>
    <div class="row">
      <input type="text" name="name" placeholder="站点名称（留空自动获取）" maxlength="60">
      <input type="text" name="contact" placeholder="联系方式（选填，邮箱 / QQ 等）" maxlength="60">
    </div>
    <div style="text-align:right;margin-top:14px">
      <button class="btn" type="submit" id="linkSubmit">🚀 提交申请</button>
    </div>
    <p id="linkMsg" style="font-size:13px;margin-top:10px;display:none"></p>
  </form>
</section>

<script>
(function () {
  var form = document.getElementById('linkForm');
  if (!form) return;
  form.addEventListener('submit', function (ev) {
    ev.preventDefault();
    var btn = document.getElementById('linkSubmit'), msg = document.getElementById('linkMsg');
    btn.disabled = true; btn.textContent = '检测中…';
    msg.style.display = 'block'; msg.style.color = 'var(--muted)'; msg.textContent = '正在访问你的站点检测回链…';
    fetch(form.action, { method: 'POST', body: new FormData(form) })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        msg.style.color = d.ok ? '#3fb984' : '#e0566b';
        msg.textContent = d.msg;
        if (d.ok) { setTimeout(function () { location.reload(); }, 1600); }
        else { btn.disabled = false; btn.textContent = '🚀 提交申请'; }
      })
      .catch(function () {
        msg.style.color = '#e0566b'; msg.textContent = '网络开小差了，请稍后重试';
        btn.disabled = false; btn.textContent = '🚀 提交申请';
      });
  });
})();
</script>

<?php include partial_path('footer.php'); ?>