<?php
/**
 * 模板：首页
 * 可用变量：$posts $pager $page $total $site $nav_cats
 */
$page_title = $site['name'];
$cur_p = 'index';
include partial_path('header.php');
?>

<header class="hero">
  <div class="avatar-ring">
    <img src="<?php echo e(media_url($site['avatar'])); ?>" alt="<?php echo e($site['name']); ?> 的头像">
  </div>
  <h1><?php echo e($site['name']); ?></h1>
  <?php if ($site['sub']): ?><p class="sub"><?php echo e($site['sub']); ?></p><?php endif; ?>
  <div class="typing"><span id="typing"></span><span class="cursor"></span></div>
  <div class="socials">
    <?php foreach ($site['socials'] as $soc): ?>
      <?php $socImg = function_exists('social_icon_url') ? social_icon_url($soc['icon']) : ''; ?>
      <a href="<?php echo e($soc['url']); ?>" target="_blank" rel="noopener" title="<?php echo e($soc['name']); ?>">
        <?php if ($socImg !== ''): ?><img src="<?php echo e($socImg); ?>" alt="<?php echo e($soc['name']); ?>" style="width:1em;height:1em;vertical-align:-2px"><?php else: ?><?php echo e($soc['icon'] !== '' ? $soc['icon'] : '🔗'); ?><?php endif; ?>
      </a>
    <?php endforeach; ?>
    <?php if ($site['rss']): ?><a href="<?php echo e(rss_url()); ?>" title="RSS">📡</a><?php endif; ?>
  </div>
  <div class="stat-bar">
    <div class="stat"><b><?php echo (int)$site['stats']['posts']; ?></b><span>文章</span></div>
    <div class="stat"><b><?php echo (int)$site['stats']['comments']; ?></b><span>评论</span></div>
    <div class="stat"><b><?php echo (int)$site['stats']['views']; ?></b><span>浏览</span></div>
  </div>
</header>

<section>
  <div class="section-title">
    <h2>最新文章</h2>
    <a class="more" href="<?php echo e(rss_url()); ?>">RSS 订阅 →</a>
  </div>

  <?php if (empty($posts)): ?>
    <div class="empty-box">
      <span class="big">🌱</span>
      <p>还没有文章哦，登录后台写下第一篇吧～</p>
      <a class="btn" href="<?php echo e(base_url() . 'admin/'); ?>">前往后台</a>
    </div>
  <?php else: ?>
    <div class="grid">
      <?php foreach ($posts as $p): ?>
        <article class="post-card">
          <?php if (post_cover($p)): ?>
            <a class="cover" href="<?php echo e(post_url($p)); ?>">
              <img src="<?php echo e(media_url(post_cover($p))); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy">
            </a>
          <?php else: ?>
            <a class="cover none" href="<?php echo e(post_url($p)); ?>">
              <span>🌸</span>
            </a>
          <?php endif; ?>
          <div class="body">
            <div class="meta">
              <?php if ($p['cat_name']): ?><span class="cat"><?php echo e($p['cat_name']); ?></span><?php endif; ?>
              <?php if ($p['is_top']): ?><span class="cat" style="background:linear-gradient(135deg,#f6a23c,#ff7e5f)">置顶</span><?php endif; ?>
              <span><?php echo e(format_time($p['created_at'])); ?></span>
            </div>
            <h3><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
            <p class="excerpt"><?php echo e(post_excerpt($p)); ?></p>
            <div class="foot">
              <span><?php echo e(nice_time($p['created_at'])); ?></span>
              <span class="views"><?php echo (int)$p['views']; ?> 次阅读</span>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
    <?php echo $pager; ?>
  <?php endif; ?>
</section>

<?php include partial_path('footer.php'); ?>

<script>
(function () {
  var text = <?php echo json_encode($site['signature'] ?: '欢迎来到我的小站～', JSON_UNESCAPED_UNICODE); ?>;
  var el = document.getElementById('typing'), i = 0, adding = true;
  function tick() {
    if (adding) { i++; if (i >= text.length) { adding = false; setTimeout(tick, 2200); el.textContent = text.slice(0, i); return; } }
    else { i -= 2; if (i <= 0) { i = 0; adding = true; } }
    el.textContent = text.slice(0, i);
    setTimeout(tick, adding ? 120 : 40);
  }
  tick();
})();
</script>
