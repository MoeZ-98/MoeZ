<?php
/**
 * 默认模板 · 看板娘小屋（/companion，2.2.13 核心兜底）
 * 任何主题没有自己的 companion.php 时自动落到这里 —— 前台 AI 用量监控不再依赖主题适配。
 * 可用变量：$cp_stats（total/today/cost_total/cost_today/price_in/price_out） $cp_name
 */
$cur_p = 'companion';
include partial_path('header.php');

$fmt = function ($n) { return number_format((float)$n); };
$fmtc = function ($n) { return number_format((float)$n, ($n > 0 && $n < 1) ? 4 : 2); };
$cp_ai_on = function_exists('moe_ai_cfg') ? moe_ai_cfg() : array('on' => false, 'model' => '');
?>
<style>
  .cp-wrap { max-width: 760px; margin: 0 auto; }
  .cp-hero {
    background: linear-gradient(135deg, rgba(124,92,255,.10), rgba(255,126,179,.12));
    border: 1px solid var(--line); border-radius: 18px; padding: 22px 26px;
    display: flex; align-items: center; gap: 16px; flex-wrap: wrap; margin-bottom: 26px;
  }
  .cp-ava {
    width: 64px; height: 64px; border-radius: 50%; flex: none;
    background: linear-gradient(135deg, #7c5cff, #ff7eb3); color: #fff;
    display: grid; place-items: center; font-size: 28px;
    box-shadow: 0 6px 18px rgba(124,92,255,.30);
  }
  .cp-hero b { font-size: 18px; }
  .cp-hero small { display: block; color: var(--muted); }
  .cp-go {
    margin-left: auto; padding: 9px 18px; border-radius: 12px; font-size: 13.5px; font-weight: 700;
    color: #fff; background: linear-gradient(135deg, #7c5cff, #ff7eb3);
    box-shadow: 0 6px 18px rgba(124,92,255,.28); text-decoration: none;
  }
  .cp-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; margin-bottom: 26px; }
  @media (max-width: 640px) { .cp-grid { grid-template-columns: repeat(2, 1fr); } }
  .cp-card {
    background: var(--card, #fff); border: 1px solid var(--line); border-radius: 14px;
    padding: 18px 14px; text-align: center;
  }
  .cp-card em { display: block; font-style: normal; font-size: 24px; font-weight: 900; color: var(--primary-deep, #5b3df0); }
  .cp-card span { font-size: 12.5px; color: var(--muted); }
  .cp-h2 { font-size: 16px; font-weight: 800; margin: 0 0 12px; }
  .cp-note { font-size: 13px; color: var(--muted); border-top: 1px dashed var(--line); padding-top: 14px; }
  .cp-badge {
    display: inline-block; padding: 3px 12px; border-radius: 999px; font-size: 12px; font-weight: 700;
    background: #e4f9ef; color: #17946a; margin-left: 8px; vertical-align: middle;
  }
  .cp-badge.off { background: #efe9ff; color: #5b3df0; }
</style>

<div class="cp-wrap">
  <header class="hero" style="padding-bottom:16px">
    <h1>🏠 <?php echo e($cp_name); ?>的小屋</h1>
    <p class="sub">这里记录着「<?php echo e($cp_name); ?>」陪大家聊天的痕迹，她一直在认真营业哦～</p>
  </header>

  <div class="cp-hero">
    <div class="cp-ava">🎀</div>
    <div>
      <b><?php echo e($cp_name); ?></b>
      <?php if (!empty($cp_ai_on['on'])): ?><span class="cp-badge">AI 在线 · <?php echo e($cp_ai_on['model']); ?></span>
      <?php else: ?><span class="cp-badge off">站内小助手模式</span><?php endif; ?>
      <small>住在这个站屏幕角落里的看板娘</small>
    </div>
    <a class="cp-go" href="<?php echo e(home_url()); ?>#companion">去聊天 →</a>
  </div>

  <h2 class="cp-h2">累计陪伴</h2>
  <div class="cp-grid">
    <div class="cp-card"><em><?php echo $fmt($cp_stats['total']['req']); ?></em><span>对话次数</span></div>
    <div class="cp-card"><em><?php echo $fmt($cp_stats['total']['in']); ?></em><span>输入 tokens</span></div>
    <div class="cp-card"><em><?php echo $fmt($cp_stats['total']['out']); ?></em><span>输出 tokens</span></div>
    <div class="cp-card"><em>¥<?php echo $fmtc($cp_stats['cost_total']); ?></em><span>累计花费</span></div>
  </div>

  <h2 class="cp-h2">今天</h2>
  <div class="cp-grid">
    <div class="cp-card"><em><?php echo $fmt($cp_stats['today']['req']); ?></em><span>今日对话</span></div>
    <div class="cp-card"><em><?php echo $fmt($cp_stats['today']['in']); ?></em><span>输入 tokens</span></div>
    <div class="cp-card"><em><?php echo $fmt($cp_stats['today']['out']); ?></em><span>输出 tokens</span></div>
    <div class="cp-card"><em>¥<?php echo $fmtc($cp_stats['cost_today']); ?></em><span>今日花费</span></div>
  </div>

  <p class="cp-note">tokens 是 AI 思考与回答的字数计量：她每次听懂你的话要「读」（输入），回答要「写」（输出）。
    花费按后台单价估算（输入 ¥<?php echo e($fmtc($cp_stats['price_in'])); ?> / 百万 tokens，输出 ¥<?php echo e($fmtc($cp_stats['price_out'])); ?> / 百万 tokens），仅供站长参考。</p>
</div>

<?php include partial_path('footer.php'); ?>
