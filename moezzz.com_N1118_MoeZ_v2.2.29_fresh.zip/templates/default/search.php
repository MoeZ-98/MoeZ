<?php
/**
 * 模板：搜索结果
 * 可用变量：$posts $kw $pager $total $site $nav_cats
 */
$page_title = '搜索：' . $kw;
$cur_p = 'search';
include partial_path('header.php');
?>

<header class="hero" style="padding-bottom:16px">
  <h1>🔍 搜索结果</h1>
  <p class="sub">关键词「<?php echo e($kw); ?>」共找到 <?php echo (int)$total; ?> 篇文章</p>
</header>

<?php if (empty($posts)): ?>
  <div class="empty-box"><span class="big">🫧</span><p>没有找到相关内容，换个关键词试试？</p><a class="btn" href="<?php echo u(); ?>">回到首页</a></div>
<?php else: ?>
  <?php foreach ($posts as $p): ?>
    <div class="list-item">
      <a class="thumb" href="<?php echo e(post_url($p)); ?>"><?php echo post_cover($p) ? '<img src="' . e(media_url(post_cover($p))) . '" alt="' . e($p['title']) . '" loading="lazy">' : '🌸'; ?></a>
      <div class="info">
        <div class="meta" style="font-size:12px;color:var(--muted)"><?php echo e(format_time($p['created_at'], 'Y-m-d')); ?></div>
        <h3><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
        <p><?php echo e(post_excerpt($p)); ?></p>
        <div class="meta"><span>👀 <?php echo (int)$p['views']; ?></span></div>
      </div>
    </div>
  <?php endforeach; ?>
  <?php echo $pager; ?>
<?php endif; ?>

<?php include partial_path('footer.php'); ?>
