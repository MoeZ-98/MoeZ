<?php
/**
 * 模板：点滴时间线（路由 /life）
 * 可用变量：$groups（'YYYY-MM' => 文章行数组，行内额外含 comment_count）  $total
 *           $life_cat（点滴分类行，字段 slug,name,...）  $site  $nav_cats
 */
$page_title = '点滴';
$cur_p = 'life';
include partial_path('header.php');
?>

<header class="hero" style="padding-bottom:16px">
  <h1>💧 点滴</h1>
  <p class="sub">
    <?php echo e(!empty($life_cat['name']) ? $life_cat['name'] : '日常碎片'); ?> ·
    共 <?php echo (int)$total; ?> 条记录，按月整理
  </p>
</header>

<?php if (empty($groups)): ?>
  <div class="empty-box">
    <span class="big">🫧</span>
    <p>还没有点滴记录，去「<?php echo e(!empty($life_cat['name']) ? $life_cat['name'] : '点滴'); ?>」分类写下第一条吧～</p>
    <a class="btn" href="<?php echo e(u()); ?>">回到首页</a>
  </div>
<?php else: ?>
  <?php foreach ($groups as $month => $items): ?>
    <section class="tl-group">
      <div class="tl-head">
        <h2><?php echo e($month); ?></h2>
        <span class="tl-count"><?php echo count((array)$items); ?> 条</span>
      </div>
      <ul class="tl-list tl-list--life">
        <?php foreach ((array)$items as $p): ?>
          <?php
            $life_title = isset($p['title']) ? $p['title'] : '';
            $life_link  = !empty($p['id']) ? post_url($p) : '#';
            $life_time  = isset($p['created_at']) ? format_time($p['created_at'], 'm-d H:i') : '';
            $life_text  = post_excerpt($p, 120);
            $life_cmt   = isset($p['comment_count']) ? (int)$p['comment_count'] : 0;
            $life_views = isset($p['views']) ? (int)$p['views'] : 0;
          ?>
          <li class="tl-item tl-item--life">
            <span class="tl-date"><?php echo e($life_time); ?></span>
            <div class="tl-body">
              <a class="tl-title" href="<?php echo e($life_link); ?>"><?php echo e($life_title !== '' ? $life_title : '（无标题）'); ?></a>
              <?php if ($life_text !== ''): ?><p class="tl-text"><?php echo e($life_text); ?></p><?php endif; ?>
              <span class="tl-extra">💬 <?php echo $life_cmt; ?> · 👀 <?php echo $life_views; ?></span>
            </div>
          </li>
        <?php endforeach; ?>
      </ul>
    </section>
  <?php endforeach; ?>
<?php endif; ?>

<?php include partial_path('footer.php'); ?>