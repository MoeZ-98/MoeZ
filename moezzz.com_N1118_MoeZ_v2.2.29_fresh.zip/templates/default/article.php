<?php
/**
 * 模板：全部文章列表（路由 /blog/article）
 * 可用变量：$posts $pager（分页 HTML） $total $page $cats（分类行，额外含 count） $sel_cat
 *           $site $nav_cats
 */
$page_title = '写作';
$cur_p = 'article';
include partial_path('header.php');
?>

<header class="hero" style="padding-bottom:16px">
  <h1>📝 写作</h1>
  <p class="sub">这里收录全部 <?php echo (int)$total; ?> 篇文章，慢慢读</p>
</header>

<?php if (!empty($cats)): ?>
  <div class="chips" style="justify-content:center">
    <a class="<?php echo $sel_cat === '' ? 'cur' : ''; ?>" href="<?php echo e(base_url() . 'blog/article'); ?>">全部</a>
    <?php foreach ((array)$cats as $c): ?>
      <?php
        $c_name  = isset($c['name']) ? $c['name'] : '';
        $c_count = isset($c['count']) ? (int)$c['count'] : 0;
        $c_cur   = ($sel_cat !== '' && !empty($c['slug']) && $sel_cat === $c['slug']);
      ?>
      <a class="<?php echo $c_cur ? 'cur' : ''; ?>" href="<?php echo e(cat_url($c)); ?>"><?php echo e($c_name); ?> <span style="opacity:.65">· <?php echo $c_count; ?></span></a>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php if (empty($posts)): ?>
  <div class="empty-box">
    <span class="big">🍂</span>
    <p>还没有文章，登录后台写下第一篇吧～</p>
    <a class="btn" href="<?php echo e(base_url() . 'admin/'); ?>">前往后台</a>
  </div>
<?php else: ?>
  <div class="grid">
    <?php foreach ($posts as $p): ?>
      <?php
        $p_title = isset($p['title']) ? $p['title'] : '';
        $p_link  = !empty($p['id']) ? post_url($p) : '#';
        $p_cover = function_exists('post_cover') ? post_cover($p) : '';
        $p_date  = isset($p['created_at']) ? $p['created_at'] : '';
      ?>
      <article class="post-card">
        <?php if ($p_cover !== ''): ?>
          <a class="cover" href="<?php echo e($p_link); ?>">
            <img src="<?php echo e(media_url($p_cover)); ?>" alt="<?php echo e($p_title); ?>" loading="lazy">
          </a>
        <?php else: ?>
          <a class="cover none" href="<?php echo e($p_link); ?>"><span>🌸</span></a>
        <?php endif; ?>
        <div class="body">
          <div class="meta">
            <?php if (!empty($p['cat_name'])): ?><span class="cat"><?php echo e($p['cat_name']); ?></span><?php endif; ?>
            <?php if (!empty($p['is_top'])): ?><span class="cat" style="background:linear-gradient(135deg,#f6a23c,#ff7e5f)">置顶</span><?php endif; ?>
            <span><?php echo e($p_date !== '' ? format_time($p_date) : ''); ?></span>
          </div>
          <h3><a href="<?php echo e($p_link); ?>"><?php echo e($p_title); ?></a></h3>
          <p class="excerpt"><?php echo e(post_excerpt($p)); ?></p>
          <div class="foot">
            <span><?php echo e($p_date !== '' ? nice_time($p_date) : ''); ?></span>
            <span class="views"><?php echo (int)(isset($p['views']) ? $p['views'] : 0); ?> 次阅读</span>
          </div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>
  <?php echo $pager; ?>
<?php endif; ?>

<?php include partial_path('footer.php'); ?>