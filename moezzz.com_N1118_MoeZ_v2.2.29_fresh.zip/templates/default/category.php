<?php
/**
 * 模板：分类文章列表
 * 可用变量：$cat $posts $pager $total $site $nav_cats
 */
$page_title = '分类：' . $cat['name'];
$cur_p = 'category';
include partial_path('header.php');
?>

<header class="hero" style="padding-bottom:16px">
  <h1><?php echo e($cat['name']); ?></h1>
  <p class="sub"><?php echo $cat['description'] ? e($cat['description']) : '分类下共 ' . (int)$total . ' 篇文章'; ?></p>
</header>

<div class="chips" style="justify-content:center">
  <?php foreach ($nav_cats as $c): ?>
    <a class="<?php echo $c['id'] == $cat['id'] ? 'cur' : ''; ?>" href="<?php echo e(cat_url($c)); ?>"><?php echo e($c['name']); ?></a>
  <?php endforeach; ?>
</div>

<?php if (empty($posts)): ?>
  <div class="empty-box"><span class="big">🍂</span><p>这个分类下还没有文章～</p><a class="btn" href="<?php echo u(); ?>">回到首页</a></div>
<?php else: ?>
  <?php foreach ($posts as $p): ?>
    <div class="list-item">
      <?php if (post_cover($p)): ?>
        <a class="thumb" href="<?php echo e(post_url($p)); ?>"><img src="<?php echo e(media_url(post_cover($p))); ?>" alt="<?php echo e($p['title']); ?>" loading="lazy"></a>
      <?php else: ?>
        <a class="thumb" href="<?php echo e(post_url($p)); ?>">🌸</a>
      <?php endif; ?>
      <div class="info">
        <div class="meta" style="font-size:12px;color:var(--muted)"><?php echo e(format_time($p['created_at'], 'Y-m-d')); ?></div>
        <h3><a href="<?php echo e(post_url($p)); ?>"><?php echo e($p['title']); ?></a></h3>
        <p><?php echo e(post_excerpt($p)); ?></p>
        <div class="meta"><span>👀 <?php echo (int)$p['views']; ?></span><span>💬 <?php echo function_exists('post_comment_count') ? (int)post_comment_count($p['id']) : 0; ?></span></div>
      </div>
    </div>
  <?php endforeach; ?>
  <?php echo $pager; ?>
<?php endif; ?>

<?php include partial_path('footer.php'); ?>
