<?php
/** 喵窝 · Mio —— 维护模式 */
require_once __DIR__ . '/_lib.php';
$cur_p = 'maintenance';
include partial_path('header.php');
$fo_mail = fo_email();
$fo_home_url = function_exists('home_url') ? home_url() : base_url();
?>
<section class="void">
  <div class="container">
    <p class="void__code" style="font-size:clamp(3rem,10vw,6rem)" aria-hidden="true">🌙</p>
    <h1>暂时闭馆整理</h1>
    <p class="text-muted" style="max-width:36ch;margin:var(--space-4) auto var(--space-8)">小窝正在维护，过一会儿再来看看。已经写下的东西都还在。</p>
    <?php if ($fo_mail !== ''): ?><a class="btn btn--primary" href="mailto:<?php echo e($fo_mail); ?>">给站长留言</a><?php else: ?><a class="btn btn--primary" href="<?php echo e($fo_home_url); ?>">回到首页</a><?php endif; ?>
  </div>
</section>

<?php include partial_path('footer.php'); ?>
