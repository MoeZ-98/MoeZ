<?php
/**
 * 喵窝 · Mio —— 文章详情
 * 可用变量：$post $cat $prev $next $comments $site $nav_cats
 */
require_once __DIR__ . '/_lib.php';
$cur_p = 'post';
include partial_path('header.php');

$fo_cover = post_cover($post);
$fo_tags = function_exists('post_tags') ? post_tags($post) : array();
$fo_content = function_exists('render_content')
    ? render_content($post['content'], isset($post['content_format']) ? $post['content_format'] : 'html')
    : nl2br(e($post['content']));
$fo_toc = fo_on('show_toc', '1') ? fo_toc($fo_content) : array('toc' => '', 'html' => $fo_content);
$fo_content = $fo_toc['html'];
$fo_home_url = function_exists('home_url') ? home_url() : base_url();
?>
<article class="article<?php echo fo_opt('reading_width') === 'wide' ? ' reading-wide' : ''; ?>">
  <div class="crumbs">
    <a href="<?php echo e($fo_home_url); ?>">首页</a><span aria-hidden="true">/</span>
    <?php if ($cat): ?><a href="<?php echo e(cat_url($cat)); ?>"><?php echo e($cat['name']); ?></a><span aria-hidden="true">/</span><?php endif; ?>
    <span class="text-muted"><?php echo e($post['title']); ?></span>
  </div>

  <header class="article__head">
    <?php if ($cat): ?><p class="article__cat"><?php echo e($cat['name']); ?></p><?php endif; ?>
    <h1 class="article__title"><?php echo e($post['title']); ?></h1>
    <div class="article__meta">
      <span>🕒 <?php echo e(function_exists('format_time') ? format_time($post['created_at']) : $post['created_at']); ?></span>
      <span>👀 <?php echo (int)$post['views']; ?> 次阅读</span>
    </div>
  </header>

  <?php if ($fo_cover !== '' && fo_on('show_cover', '1')): ?>
    <div class="article__cover"><img src="<?php echo e(fo_media($fo_cover)); ?>" alt="<?php echo e($post['title']); ?>"<?php echo fo_lazy(); ?>></div>
  <?php endif; ?>

  <?php if ($fo_toc['toc'] !== ''): ?><div class="container" style="padding:0"><?php echo $fo_toc['toc']; ?></div><?php endif; ?>

  <div class="prose">
    <?php echo $fo_content; ?>
  </div>

  <?php if (fo_on('show_tags', '1') && !empty($fo_tags)): ?>
    <div class="post-tags">
      <span class="text-muted" style="font-size:var(--text-sm)">🏷 标签</span>
      <?php foreach ($fo_tags as $t): ?>
        <a class="tag" href="<?php echo e(function_exists('post_tag_url') ? post_tag_url($t) : $fo_home_url); ?>">#<?php echo e($t); ?></a>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <?php if (fo_on('show_copyright', '1')): ?>
    <p class="copyright">© <?php echo date('Y'); ?> <?php echo e(fo_name()); ?> · <?php echo e(fo_opt('copyright_text', '未经授权禁止转载，转载请联系作者并注明出处。')); ?></p>
  <?php endif; ?>

  <?php if ($prev || $next): ?>
    <nav class="post-nav" aria-label="上一篇 / 下一篇">
      <?php if ($prev): ?><a href="<?php echo e(post_url($prev)); ?>">← <?php echo e($prev['title']); ?></a><?php else: ?><span></span><?php endif; ?>
      <?php if ($next): ?><a href="<?php echo e(post_url($next)); ?>"><?php echo e($next['title']); ?> →</a><?php else: ?><span></span><?php endif; ?>
    </nav>
  <?php endif; ?>
</article>

<?php include partial_path('_comments.php'); ?>

<?php include partial_path('footer.php'); ?>
