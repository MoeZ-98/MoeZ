<?php
/** 喵窝 · Mio —— 分类页；变量：$cat $posts $pager $total $page */
require_once __DIR__ . '/_lib.php';
$cur_p = 'category';
include partial_path('header.php');

$fo_list = fo_opt('list_style', 'card') === 'list';
$fo_show_cover = fo_on('show_cover', '1');
$fo_show_excerpt = fo_on('show_excerpt', '1');
$fo_home_url = function_exists('home_url') ? home_url() : base_url();
?>
<section class="section--tight">
  <div class="container">
    <div class="page-head">
      <h1><?php echo e($cat['name']); ?></h1>
      <?php if (!empty($cat['description'])): ?><p><?php echo e($cat['description']); ?></p><?php endif; ?>
      <p class="text-muted">共 <?php echo (int)$total; ?> 篇文章<?php echo (int)$page > 1 ? ' · 第 ' . (int)$page . ' 页' : ''; ?></p>
    </div>

    <?php if (!empty($posts)): ?>
      <div class="<?php echo $fo_list ? 'loop--list' : 'loop'; ?>">
        <?php foreach ($posts as $p): ?>
          <?php
            $purl = post_url($p);
            $cover = post_cover($p);
          ?>
          <?php if ($fo_list): ?>
            <a class="post-row" href="<?php echo e($purl); ?>">
              <?php if ($fo_show_cover && $cover !== ''): ?>
                <img class="post-row__cover" src="<?php echo e(fo_media($cover)); ?>" alt="<?php echo e($p['title']); ?>"<?php echo fo_lazy(); ?>>
              <?php else: ?>
                <img class="post-row__cover" src="<?php echo e(fo_cover_grad($p['id'])); ?>" alt=""<?php echo fo_lazy(); ?>>
              <?php endif; ?>
              <div class="post-row__body">
                <h3 class="post-card__title"><?php echo e($p['title']); ?></h3>
                <?php if ($fo_show_excerpt): ?><p class="post-card__excerpt"><?php echo e(post_excerpt($p, 80)); ?></p><?php endif; ?>
                <div class="post-card__meta"><span>🕒 <?php echo e(format_time($p['created_at'])); ?></span><span>👀 <?php echo (int)$p['views']; ?></span></div>
              </div>
            </a>
          <?php else: ?>
            <a class="post-card" href="<?php echo e($purl); ?>">
              <div class="post-card__cover">
                <?php if ($fo_show_cover && $cover !== ''): ?>
                  <img src="<?php echo e(fo_media($cover)); ?>" alt="<?php echo e($p['title']); ?>"<?php echo fo_lazy(); ?>>
                <?php else: ?>
                  <div class="work__art" style="position:absolute;inset:0;background:<?php echo e(fo_cover_grad($p['id'])); ?>">📝</div>
                <?php endif; ?>
              </div>
              <div class="post-card__body">
                <h3 class="post-card__title"><?php echo e($p['title']); ?></h3>
                <?php if ($fo_show_excerpt): ?><p class="post-card__excerpt"><?php echo e(post_excerpt($p, 90)); ?></p><?php endif; ?>
                <div class="post-card__meta"><span>🕒 <?php echo e(format_time($p['created_at'])); ?></span><span>👀 <?php echo (int)$p['views']; ?></span></div>
              </div>
            </a>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="empty">这个分类下还没有文章。</p>
    <?php endif; ?>

    <?php if (!empty($pager)): ?><div class="pager"><?php echo $pager; ?></div><?php endif; ?>
  </div>
</section>

<?php include partial_path('footer.php'); ?>
