<?php
/** 喵窝 · Mio —— 全部写作；变量：$posts $pager $total $page $cats $sel_cat */
require_once __DIR__ . '/_lib.php';
$cur_p = 'article';
include partial_path('header.php');

$fo_list = fo_opt('list_style', 'card') === 'list';
$fo_show_cover = fo_on('show_cover', '1');
$fo_show_excerpt = fo_on('show_excerpt', '1');
$fo_home_url = function_exists('home_url') ? home_url() : base_url();
?>
<section class="section--tight">
  <div class="container">
    <div class="page-head">
      <h1>📝 全部写作</h1>
      <p>共 <?php echo (int)$total; ?> 篇文章，从最近的开始。</p>
    </div>

    <?php if (!empty($cats)): ?>
      <div class="cluster" style="justify-content:center;margin-bottom:var(--space-10)">
        <a class="btn btn--sm <?php echo empty($sel_cat) ? 'btn--primary' : 'btn--ghost'; ?>" href="<?php echo e($fo_home_url); ?>article/">全部</a>
        <?php foreach ($cats as $c): ?>
          <a class="btn btn--sm <?php echo (isset($sel_cat['id']) && $sel_cat['id'] == $c['id']) ? 'btn--primary' : 'btn--ghost'; ?>" href="<?php echo e(isset($c['slug']) ? fo_home_url . 'category/' . $c['slug'] : cat_url($c)); ?>"><?php echo e($c['name']); ?></a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <?php if (!empty($posts)): ?>
      <div class="<?php echo $fo_list ? 'loop--list' : 'loop'; ?>">
        <?php foreach ($posts as $p): ?>
          <?php
            $purl = post_url($p);
            $cover = post_cover($p);
          ?>
          <?php if ($fo_list): ?>
            <a class="post-row" href="<?php echo e($purl); ?>">
              <?php if ($fo_show_cover && $cover !== ''): ?>
                <img class="post-row__cover" src="<?php echo e(fo_media($cover)); ?>" alt="<?php echo e($p['title']); ?>"<?php echo fo_lazy(); ?>>
              <?php else: ?>
                <img class="post-row__cover" src="<?php echo e(fo_cover_grad($p['id'])); ?>" alt=""<?php echo fo_lazy(); ?>>
              <?php endif; ?>
              <div class="post-row__body">
                <h3 class="post-card__title"><?php echo e($p['title']); ?></h3>
                <?php if ($fo_show_excerpt): ?><p class="post-card__excerpt"><?php echo e(post_excerpt($p, 80)); ?></p><?php endif; ?>
                <div class="post-card__meta"><span>🕒 <?php echo e(format_time($p['created_at'])); ?></span></div>
              </div>
            </a>
          <?php else: ?>
            <a class="post-card" href="<?php echo e($purl); ?>">
              <div class="post-card__cover">
                <?php if ($fo_show_cover && $cover !== ''): ?>
                  <img src="<?php echo e(fo_media($cover)); ?>" alt="<?php echo e($p['title']); ?>"<?php echo fo_lazy(); ?>>
                <?php else: ?>
                  <div class="work__art" style="position:absolute;inset:0;background:<?php echo e(fo_cover_grad($p['id'])); ?>">📝</div>
                <?php endif; ?>
              </div>
              <div class="post-card__body">
                <h3 class="post-card__title"><?php echo e($p['title']); ?></h3>
                <?php if ($fo_show_excerpt): ?><p class="post-card__excerpt"><?php echo e(post_excerpt($p, 90)); ?></p><?php endif; ?>
                <div class="post-card__meta"><span>🕒 <?php echo e(format_time($p['created_at'])); ?></span></div>
              </div>
            </a>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="empty">这里还没有文章。</p>
    <?php endif; ?>

    <?php if (!empty($pager)): ?><div class="pager"><?php echo $pager; ?></div><?php endif; ?>
  </div>
</section>

<?php include partial_path('footer.php'); ?>
