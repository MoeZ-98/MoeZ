<?php
/**
 * 喵窝 · Mio —— 首页（人物主页）
 * 区块：英雄区 → 关于我 → 兴趣 → 作品 → 追番 → 友链 → 联系
 * 可用变量：$posts $pager $page $total $site $nav_cats
 */
require_once __DIR__ . '/_lib.php';
$cur_p = 'index';
$fo_og = trim((string)fo_opt('og_image', ''));
if ($fo_og !== '' && function_exists('seo_set')) {
    seo_set(array('image' => fo_media($fo_og)));
}
include partial_path('header.php');

/* —— 英雄区数据 —— */
$fo_greet = trim((string)fo_opt('hero_greeting', ''));
$fo_name  = fo_opt('hero_name', '星野澪 Mio');
$fo_sub   = trim((string)fo_opt('hero_sub', ''));
$fo_tags = array_filter(array_map('trim', explode("\n", fo_opt('hero_tags', ''))), function ($v) { return $v !== ''; });
$fo_avatar = fo_avatar();
$fo_badge  = trim((string)fo_opt('avatar_badge', '🐾'));

/* —— 关于我 —— */
$fo_about_photo = fo_about_photo();
$fo_about_emoji = trim((string)fo_opt('about_emoji', '🌟'));
$fo_about_intro = trim((string)fo_opt('about_intro', ''));
$fo_about_stats = fo_pairs(fo_opt('about_stats', ''));

/* —— 兴趣 / 作品 / 追番 —— */
$fo_interests = fo_triples(fo_opt('interests', ''));
$fo_works = fo_work_posts();
$fo_work_title = trim((string)fo_opt('work_title', '我的小作品'));

$fo_anime = fo_anime_list(fo_opt('anime_list', ''));
$fo_anime_title = trim((string)fo_opt('anime_title', '最近在追的番'));

/* —— 友链（首页路由不传入，自行查询） —— */
$fo_links = array();
if (function_exists('moe_table')) {
    $fo_links = rows('SELECT * FROM ' . moe_table('links') . ' ORDER BY sort, id');
}

/* —— 联系 —— */
$fo_email = fo_email();
$fo_socials = fo_socials();
$fo_contact_note = trim((string)fo_opt('contact_note', ''));
?>

<!-- ============ 1. 英雄区 ============ -->
<section class="hero" id="top">
  <div class="container hero__inner">
    <div>
      <?php if ($fo_greet !== ''): ?><p class="eyebrow" data-reveal><?php echo e($fo_greet); ?></p><?php endif; ?>
      <h1 class="hero__title" data-reveal>你好呀，我是<br><span class="grad"><?php echo e($fo_name); ?></span> ✦</h1>
      <?php if ($fo_sub !== ''): ?><p class="hero__sub" data-reveal><?php echo nl2br(e($fo_sub), false); ?></p><?php endif; ?>
      <?php if (!empty($fo_tags)): ?>
        <div class="hero__tags" data-reveal>
          <?php foreach ($fo_tags as $t): ?><span class="tag"><?php echo e($t); ?></span><?php endforeach; ?>
        </div>
      <?php endif; ?>
      <div class="hero__actions" data-reveal>
        <a class="btn btn--primary" href="#works">看看我的画 →</a>
        <a class="btn btn--ghost" href="#contact">和我说句话</a>
      </div>
    </div>

    <div class="avatar" data-reveal aria-label="<?php echo e($fo_name); ?> 的头像">
      <div class="avatar__ring"><div class="avatar__ring-inner">
        <?php if ($fo_avatar !== ''): ?>
          <img class="avatar__photo" src="<?php echo e(fo_media($fo_avatar)); ?>" alt="<?php echo e($fo_name); ?>"<?php echo fo_lazy(); ?>>
        <?php else: ?>
          <?php echo fo_avatar_svg(); ?>
        <?php endif; ?>
      </div></div>
      <div class="avatar__badge" aria-hidden="true"><?php echo e($fo_badge); ?></div>
    </div>
  </div>
</section>

<!-- ============ 2. 关于我 ============ -->
<section class="section" id="about">
  <div class="container">
    <?php echo fo_section_head('💭', '关于我', '先自我介绍一下下——一个住在二次元边缘、不太正经的普通人类。'); ?>
    <div class="about">
      <div class="about__photo" data-reveal>
        <?php if ($fo_about_photo !== ''): ?>
          <img src="<?php echo e(fo_media($fo_about_photo)); ?>" alt="<?php echo e($fo_name); ?> 的照片"<?php echo fo_lazy(); ?>>
        <?php else: ?>
          <span class="sticker">本人（大概）</span>
          <span class="emoji" aria-hidden="true"><?php echo e($fo_about_emoji); ?></span>
        <?php endif; ?>
      </div>
      <div class="about__body" data-reveal>
        <?php echo fo_md($fo_about_intro); ?>
        <?php if (!empty($fo_about_stats)): ?>
          <div class="about__stats">
            <?php foreach ($fo_about_stats as $s): ?>
              <div class="chip"><span><?php echo e($s['name']); ?></span><strong><?php echo e($s['value']); ?></strong></div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>

<!-- ============ 3. 兴趣 ============ -->
<?php if (!empty($fo_interests)): ?>
<section class="section section--tight" id="interest">
  <div class="container">
    <?php echo fo_section_head('🎀', '我沉迷的东西', '把时间花在这些上面，我一点都不后悔。'); ?>
    <div class="grid-auto">
      <?php foreach ($fo_interests as $c): ?>
        <article class="card" data-reveal>
          <div class="card__icon" aria-hidden="true"><?php echo e($c['icon']); ?></div>
          <h3><?php echo e($c['title']); ?></h3>
          <p><?php echo e($c['desc']); ?></p>
        </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ============ 4. 作品画廊 ============ -->
<?php if (fo_show('show_works') && !empty($fo_works)): ?>
<section class="section" id="works">
  <div class="container">
    <?php echo fo_section_head('🖼️', e($fo_work_title), '练习稿与原创，画的都是我心里的那个世界。（配图用文章封面，未设置封面时显示柔彩占位）'); ?>
    <div class="gallery">
      <?php foreach ($fo_works as $w): ?>
        <?php
          $wurl = function_exists('post_url') ? post_url($w) : '#';
          $wcat = isset($w['cat_name']) && $w['cat_name'] !== '' ? $w['cat_name'] : '作品';
          $cover = fo_cover($w);
        ?>
        <a class="work" href="<?php echo e($wurl); ?>" data-reveal>
          <?php if ($cover !== ''): ?>
            <img class="work__img" src="<?php echo e(fo_media($cover)); ?>" alt="<?php echo e($w['title']); ?>"<?php echo fo_lazy(); ?>>
          <?php else: ?>
            <div class="work__art" style="background:<?php echo e(fo_cover_grad($w['id'])); ?>" aria-hidden="true">🖼️</div>
          <?php endif; ?>
          <span class="work__tag"><?php echo e($wcat); ?></span>
          <div class="work__overlay">
            <h3><?php echo e($w['title']); ?></h3>
            <p><?php echo e(mb_strlen(strip_tags(post_excerpt($w, 60)), 'UTF-8') > 0 ? post_excerpt($w, 60) : format_time($w['created_at'])); ?></p>
          </div>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ============ 5. 追番清单 ============ -->
<?php if (fo_show('show_anime') && !empty($fo_anime)): ?>
<section class="section section--tight" id="anime">
  <div class="container">
    <?php echo fo_section_head('📜', e($fo_anime_title), '实时更新（才怪，是手写的）。状态分三种：追更中 / 补番中 / 已追完。'); ?>
    <div class="anime-list">
      <?php foreach ($fo_anime as $a): ?>
        <div class="anime" data-reveal>
          <div class="anime__cover" aria-hidden="true"><?php echo e($a['emoji']); ?></div>
          <div class="anime__meta"><h3><?php echo e($a['title']); ?></h3><p><?php echo e($a['desc']); ?></p></div>
          <span class="badge badge--<?php echo e($a['cls']); ?>"><?php echo e($a['status']); ?></span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ============ 6. 友链 ============ -->
<?php if (fo_show('show_friends') && !empty($fo_links)): ?>
<section class="section section--tight" id="friends">
  <div class="container">
    <?php echo fo_section_head('🔗', '友情链接', '都是很可爱的人，去串门吧～'); ?>
    <div class="friends" data-reveal>
      <?php foreach ($fo_links as $l): ?>
        <?php
          $l_name = isset($l['name']) ? $l['name'] : '';
          $l_url  = isset($l['url']) ? $l['url'] : '';
          $l_ico  = function_exists('link_icon') ? link_icon($l) : '';
          $l_desc = function_exists('link_desc') ? link_desc($l) : '';
        ?>
        <a class="friend" href="<?php echo e($l_url); ?>" target="_blank" rel="noopener nofollow">
          <?php if ($l_ico !== ''): ?>
            <img class="ico" src="<?php echo e($l_ico); ?>" alt="" width="18" height="18" loading="lazy" style="border-radius:4px">
          <?php else: ?>
            <span class="ico" aria-hidden="true">🔗</span>
          <?php endif; ?>
          <?php echo e($l_name); ?>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ============ 7. 联系 / 留言 ============ -->
<section class="section" id="contact">
  <div class="container">
    <div class="contact">
      <div class="contact__art" data-reveal aria-hidden="true">💌</div>
      <div data-reveal>
        <div class="section-head" style="margin-bottom:var(--space-6)">
          <h2><span class="mark">✉️</span>和我说句话</h2>
          <p><?php echo e($fo_contact_note); ?></p>
        </div>
        <div class="social-row">
          <?php if ($fo_email !== ''): ?><a class="btn btn--primary" href="mailto:<?php echo e($fo_email); ?>">✉️ 写邮件</a><?php endif; ?>
          <?php foreach ($fo_socials as $s): ?>
            <a class="btn btn--ghost" href="<?php echo e($s['url']); ?>" target="_blank" rel="noopener"><?php echo e($s['icon'] . ' ' . $s['name']); ?></a>
          <?php endforeach; ?>
        </div>
        <p class="text-muted" style="margin-top:var(--space-5);font-size:var(--text-sm)">
          想认真留言？去<a href="<?php echo e(function_exists('page_url') ? page_url(array('slug' => 'guestbook')) : '#contact'); ?>">留言板页面</a>写下你的话～（新建一个别名为 guestbook 的页面即可启用）
        </p>
      </div>
    </div>
  </div>
</section>

<?php include partial_path('footer.php'); ?>
