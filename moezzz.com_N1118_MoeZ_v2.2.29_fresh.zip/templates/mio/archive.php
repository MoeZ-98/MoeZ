<?php
/** 喵窝 · Mio —— 时间归档；变量：$groups（年份 => 文章） $total */
require_once __DIR__ . '/_lib.php';
$cur_p = 'archive';
include partial_path('header.php');
?>
<section class="section--tight">
  <div class="container">
    <div class="page-head">
      <h1>📚 时间归档</h1>
      <p>全部 <?php echo (int)$total; ?> 篇文章，按写下的年份排好。</p>
    </div>
    <?php if (!empty($groups)): ?>
      <?php foreach ($groups as $year => $items): ?>
        <div class="archive-group">
          <h3><?php echo e($year); ?> <span class="text-faint" style="font-weight:400;font-size:var(--text-sm)">· <?php echo count($items); ?> 篇</span></h3>
          <div class="archive-list">
            <?php foreach ($items as $it): ?>
              <div class="archive-item">
                <time datetime="<?php echo e(substr((string)$it['created_at'], 0, 10)); ?>"><?php echo e(function_exists('format_time') ? format_time($it['created_at'], 'm.d') : substr((string)$it['created_at'], 5, 5)); ?></time>
                <a href="<?php echo e(post_url($it)); ?>"><?php echo e($it['title']); ?></a>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <p class="empty">还没有归档内容。</p>
    <?php endif; ?>
  </div>
</section>

<?php include partial_path('footer.php'); ?>
