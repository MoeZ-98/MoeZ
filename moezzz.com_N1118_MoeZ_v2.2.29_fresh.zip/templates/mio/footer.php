<?php
/** 喵窝 · Mio —— 公共底部：关闭 main + 全宽页脚 + 进度/回顶 + 脚本 */
$fo_stat = fo_stats();
$fo_menu = fo_footer_menu();
$fo_socials = fo_socials();
$fo_mail = fo_email();
$fo_motto = trim((string)fo_opt('footer_motto', ''));
$fo_icp = trim((string)fo_opt('icp', ''));
$fo_name = fo_name();
$fo_home_url = function_exists('home_url') ? home_url() : base_url();
$fo_rss  = function_exists('rss_url') ? rss_url() : (base_url() . 'rss');
function fo_foot_href($u, $home) {
    if ($u === '' || $u === '#') return $home;
    if ($u[0] === '#') return $home . $u;
    return $u;
}
?>
  </main>

  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div>
          <h4><?php echo e(fo_opt('logo_text', $fo_name)); ?> の小窝</h4>
          <p class="measure" style="max-width:30ch"><?php echo e($fo_motto); ?></p>
        </div>
        <div>
          <h4>逛逛</h4>
          <ul>
            <?php foreach ($fo_menu as $m): ?>
              <li><a href="<?php echo e(fo_foot_href($m['url'], $fo_home_url)); ?>"><?php echo e($m['name']); ?></a></li>
            <?php endforeach; ?>
          </ul>
        </div>
        <div>
          <h4>找到我</h4>
          <ul>
            <?php foreach ($fo_socials as $s): ?>
              <li><a href="<?php echo e($s['url']); ?>" target="_blank" rel="noopener"><?php echo e($s['name']); ?></a></li>
            <?php endforeach; ?>
            <?php if (fo_on('show_rss', '1')): ?><li><a href="<?php echo e($fo_rss); ?>">RSS 订阅</a></li><?php endif; ?>
          </ul>
        </div>
        <div>
          <h4>联系</h4>
          <ul>
            <?php if ($fo_mail !== ''): ?><li><a href="mailto:<?php echo e($fo_mail); ?>"><?php echo e($fo_mail); ?></a></li><?php endif; ?>
            <li><a href="<?php echo e($fo_home_url); ?>">回到首页</a></li>
          </ul>
        </div>
      </div>
      <?php if (fo_on('show_stats', '1')): ?>
        <div class="footer-legal" style="border-top:none;padding-top:var(--space-6);margin-top:var(--space-8)">
          <span>📝 <?php echo (int)$fo_stat['posts']; ?> 篇 · 💬 <?php echo (int)$fo_stat['comments']; ?> 条 · 👀 <?php echo (int)$fo_stat['views']; ?> 次 · ⏳ 运行 <?php echo (int)$fo_stat['days']; ?> 天</span>
        </div>
      <?php endif; ?>
      <div class="footer-legal">
        <span>© <?php echo date('Y'); ?> <?php echo e($fo_name); ?> · 用 <span class="heart">♥</span> 与一点点浪漫做成</span>
        <span>
          <?php if ($fo_icp !== ''): ?><?php echo e($fo_icp); ?> · <?php endif; ?>
          <?php if (fo_on('credit_on', '1')): ?>喵窝 · Mio 主题 · Powered by Moe Home<?php endif; ?>
        </span>
      </div>
    </div>
  </footer>

<?php if (fo_on('back_top', '1')): ?>
  <button class="back-top" id="mioBackTop" type="button" aria-label="回到顶部" title="回到顶部">↑</button>
<?php endif; ?>
<script src="<?php echo e(fo_asset('app.js')); ?>?v=<?php echo e(fo_ver()); ?>" defer></script>
<?php $fo_extra_foot = trim((string)fo_opt('extra_foot', '')); if ($fo_extra_foot !== '') echo "\n" . $fo_extra_foot . "\n"; ?>
</body>
</html>
