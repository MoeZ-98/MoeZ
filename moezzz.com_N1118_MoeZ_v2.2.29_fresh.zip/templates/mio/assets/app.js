/* 喵窝 · Mio — 交互层
   渐进增强：昼夜切换、滚动描边、移动端菜单、飘落花瓣与星星、入场动画、
   阅读进度、回到顶部。全部尊重 prefers-reduced-motion，关掉 JS 也不影响内容与导航。 */
(function () {
  "use strict";
  var root = document.documentElement;
  var body = document.body;

  /* —— 顶部导航：滚动描边 + 移动端菜单 —— */
  var header = document.querySelector('.site-header');
  if (header) {
    var onScroll = function () { header.dataset.scrolled = String(window.scrollY > 8); };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }
  var toggle = document.getElementById('navToggle');
  var links = document.getElementById('navLinks');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var open = links.dataset.open === 'true';
      links.dataset.open = String(!open);
      toggle.setAttribute('aria-expanded', String(!open));
    });
    links.addEventListener('click', function (e) {
      if (e.target.tagName === 'A') { links.dataset.open = 'false'; toggle.setAttribute('aria-expanded', 'false'); }
    });
  }

  /* —— 昼夜切换（带本地记忆） —— */
  var themeBtn = document.getElementById('themeToggle');
  var saved = null;
  try { saved = localStorage.getItem('mio-theme'); } catch (e) {}
  if (saved) root.setAttribute('data-theme', saved);
  function syncIcon() {
    if (!themeBtn) return;
    themeBtn.textContent = root.getAttribute('data-theme') === 'night' ? '☀️' : '🌙';
    themeBtn.setAttribute('aria-label', root.getAttribute('data-theme') === 'night' ? '切换到白天' : '切换到夜晚');
  }
  syncIcon();
  if (themeBtn) {
    themeBtn.addEventListener('click', function () {
      var next = root.getAttribute('data-theme') === 'night' ? 'day' : 'night';
      root.setAttribute('data-theme', next);
      try { localStorage.setItem('mio-theme', next); } catch (e) {}
      syncIcon();
    });
  }

  /* —— 减少动态 & 花瓣开关 —— */
  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var petalsOn = body && body.getAttribute('data-petals') !== '0';
  var fx = document.querySelector('.bg-fx');
  if (!reduce && petalsOn && fx) {
    for (var i = 0; i < 14; i++) {
      var p = document.createElement('span');
      p.className = 'petal';
      var dur = 9 + Math.random() * 9;
      p.style.left = (Math.random() * 100) + 'vw';
      p.style.animation = 'fall ' + dur + 's linear ' + (Math.random() * dur) + 's infinite';
      p.style.opacity = (0.5 + Math.random() * 0.4).toFixed(2);
      var s = 0.6 + Math.random() * 0.9;
      p.style.transform = 'scale(' + s + ')';
      fx.appendChild(p);
    }
    var marks = ['✦', '✧', '★', '·'];
    for (var j = 0; j < 22; j++) {
      var sp = document.createElement('span');
      sp.className = 'spark';
      sp.textContent = marks[Math.floor(Math.random() * marks.length)];
      sp.style.left = (Math.random() * 100) + 'vw';
      sp.style.top = (Math.random() * 100) + 'vh';
      sp.style.setProperty('--dur', (3 + Math.random() * 4).toFixed(1) + 's');
      sp.style.animationDelay = (Math.random() * 4).toFixed(1) + 's';
      fx.appendChild(sp);
    }
  }

  /* —— 滚动入场（IntersectionObserver 控制 reveal 播放；后台关闭入场动画时跳过） —— */
  var motionOff = body && body.getAttribute('data-motion') === 'off';
  if (!reduce && !motionOff && 'IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.style.animationPlayState = 'running'; io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    document.querySelectorAll('[data-reveal]').forEach(function (el) {
      el.style.animationPlayState = 'paused';
      io.observe(el);
    });
  }

  /* —— 阅读进度条 —— */
  var prog = document.getElementById('mioProgress');
  if (prog) {
    var onProg = function () {
      var h = document.documentElement;
      var max = h.scrollHeight - h.clientHeight;
      var pct = max > 0 ? (h.scrollTop / max) * 100 : 0;
      prog.style.width = pct + '%';
    };
    window.addEventListener('scroll', onProg, { passive: true });
    onProg();
  }

  /* —— 回到顶部 —— */
  var back = document.getElementById('mioBackTop');
  if (back) {
    var onBack = function () { back.classList.toggle('show', window.scrollY > 480); };
    window.addEventListener('scroll', onBack, { passive: true });
    back.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' }); });
    onBack();
  }

  /* —— 导航锚点平滑滚动（站内 #id） —— */
  document.querySelectorAll('a[href^="#"]').forEach(function (a) {
    a.addEventListener('click', function (e) {
      var id = a.getAttribute('href');
      if (id.length < 2) return;
      var target = document.querySelector(id);
      if (target) { e.preventDefault(); target.scrollIntoView({ behavior: reduce ? 'auto' : 'smooth', block: 'start' }); }
    });
  });
})();
