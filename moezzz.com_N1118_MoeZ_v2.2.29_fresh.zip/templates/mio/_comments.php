<?php
/** 喵窝 · Mio —— 评论片段，供 post.php / page.php 共用
 *  需要变量：$post（含 id）、$comments（已审核评论数组） */
$fo_comments = isset($comments) ? (array)$comments : array();
$fo_enabled = setting('comment_enabled', '1') === '1' && fo_on('show_comments', '1');
$fo_cdf = function_exists('moe_comment_defaults') ? moe_comment_defaults() : array('author' => '', 'email' => '', 'admin' => false);
?>
<section class="comments" id="comments" aria-labelledby="commentsH">
  <h3 id="commentsH">留言（<?php echo count($fo_comments); ?>）</h3>

  <?php if (!empty($fo_comments)): ?>
    <div class="comment-list">
      <?php foreach ($fo_comments as $c): ?>
        <article class="comment">
          <div class="comment__avatar" aria-hidden="true"><?php echo e(function_exists('initial') ? initial($c['author']) : mb_substr((string)$c['author'], 0, 1, 'UTF-8')); ?></div>
          <div class="comment__body">
            <div class="comment__meta"><b><?php echo e($c['author']); ?></b> · <time datetime="<?php echo e($c['created_at']); ?>"><?php echo e(function_exists('nice_time') ? nice_time($c['created_at']) : $c['created_at']); ?></time></div>
            <p class="comment__text"><?php echo nl2br(e($c['content'])); ?></p>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <p class="comment-empty">还没有留言，来当第一个吧～</p>
  <?php endif; ?>

  <?php if ($fo_enabled): ?>
    <form class="comment-form" method="post" action="<?php echo e(base_url() . 'comment.php'); ?>">
      <input type="hidden" name="post_id" value="<?php echo (int)$post['id']; ?>">
      <input type="hidden" name="_token" value="<?php echo e(function_exists('csrf_token') ? csrf_token() : ''); ?>">
      <h3 style="margin-bottom:var(--space-4)">写一句</h3>
      <div class="row">
        <input type="text" name="author" placeholder="昵称 *" maxlength="30" required value="<?php echo e($fo_cdf['author']); ?>">
        <input type="email" name="email" placeholder="邮箱（选填，不会公开）" value="<?php echo e($fo_cdf['email']); ?>">
      </div>
      <?php if (!empty($fo_cdf['admin'])): ?><p class="text-muted" style="font-size:12px">👋 站长已登录，已自动填入你的信息</p><?php endif; ?>
      <textarea name="content" placeholder="说点什么吧～（支持 1000 字以内）" maxlength="1000" required></textarea>
      <div style="text-align:right">
        <button class="btn btn--primary" type="submit">🚀 发射留言</button>
      </div>
      <p id="cmsg" style="font-size:13px;margin-top:10px;display:none"></p>
    </form>
    <script>
    (function(){
      var f=document.querySelector('.comment-form'); if(!f) return;
      f.addEventListener('submit', function(e){
        e.preventDefault();
        var btn=f.querySelector('button[type=submit]'), msg=document.getElementById('cmsg');
        btn.disabled=true; btn.textContent='发射中…';
        fetch(f.action,{method:'POST',body:new FormData(f)}).then(function(r){return r.json();}).then(function(d){
          msg.style.display='block'; msg.style.color=d.ok?'var(--success)':'var(--danger)'; msg.textContent=d.msg;
          if(d.ok){ setTimeout(function(){location.reload();},900); }
          else{ btn.disabled=false; btn.textContent='🚀 发射留言'; }
        }).catch(function(){
          msg.style.display='block'; msg.style.color='var(--danger)'; msg.textContent='网络开小差了，请重试';
          btn.disabled=false; btn.textContent='🚀 发射留言';
        });
      });
    })();
    </script>
  <?php else: ?>
    <p class="comment-empty">留言区暂时关闭啦～</p>
  <?php endif; ?>
</section>
