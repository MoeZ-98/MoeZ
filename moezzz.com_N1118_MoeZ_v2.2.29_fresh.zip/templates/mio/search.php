<?php
/** 喵窝 · Mio —— 搜索 / 标签聚合页；变量：$posts $kw $pager $total */
require_once __DIR__ . '/_lib.php';
$cur_p = 'search';
include partial_path('header.php');

$fo_list = fo_opt('list_style', 'card') === 'list';
$fo_show_cover = fo_on('show_cover', '1');
$fo_show_excerpt = fo_on('show_excerpt', '1');
$fo_home_url = function_exists('home_url') ? home_url() : base_url();
?>
<section class="section--tight">
  <div class="container">
    <div class="page-head">
      <h1><?php echo $kw !== '' ? '检索：' . e($kw) : '站内搜索'; ?></h1>
      <p><?php echo $kw !== '' ? '找到 ' . (int)$total . ' 篇相关内容。' : '输入关键词，看看这里写了什么。'; ?></p>
      <form class="search-box" method="get" action="<?php echo e($fo_home_url); ?>" aria-label="站内搜索">
        <input type="hidden" name="p" value="search">
        <input type="search" name="q" placeholder="再搜一次…" value="<?php echo e($kw); ?>" aria-label="关键词">
        <button class="btn btn--primary" type="submit">搜索</button>
      </form>
    </div>

    <?php if (!empty($posts)): ?>
      <div class="<?php echo $fo_list ? 'loop--list' : 'loop'; ?>">
        <?php foreach ($posts as $p): ?>
          <?php
            $purl = post_url($p);
            $cover = post_cover($p);
          ?>
          <?php if ($fo_list): ?>
            <a class="post-row" href="<?php echo e($purl); ?>">
              <?php if ($fo_show_cover && $cover !== ''): ?>
                <img class="post-row__cover" src="<?php echo e(fo_media($cover)); ?>" alt="<?php echo e($p['title']); ?>"<?php echo fo_lazy(); ?>>
              <?php else: ?>
                <img class="post-row__cover" src="<?php echo e(fo_cover_grad($p['id'])); ?>" alt=""<?php echo fo_lazy(); ?>>
              <?php endif; ?>
              <div class="post-row__body">
                <h3 class="post-card__title"><?php echo e($p['title']); ?></h3>
                <?php if ($fo_show_excerpt): ?><p class="post-card__excerpt"><?php echo e(post_excerpt($p, 80)); ?></p><?php endif; ?>
                <div class="post-card__meta"><span>🕒 <?php echo e(format_time($p['created_at'])); ?></span></div>
              </div>
            </a>
          <?php else: ?>
            <a class="post-card" href="<?php echo e($purl); ?>">
              <div class="post-card__cover">
                <?php if ($fo_show_cover && $cover !== ''): ?>
                  <img src="<?php echo e(fo_media($cover)); ?>" alt="<?php echo e($p['title']); ?>"<?php echo fo_lazy(); ?>>
                <?php else: ?>
                  <div class="work__art" style="position:absolute;inset:0;background:<?php echo e(fo_cover_grad($p['id'])); ?>">📝</div>
                <?php endif; ?>
              </div>
              <div class="post-card__body">
                <h3 class="post-card__title"><?php echo e($p['title']); ?></h3>
                <?php if ($fo_show_excerpt): ?><p class="post-card__excerpt"><?php echo e(post_excerpt($p, 90)); ?></p><?php endif; ?>
                <div class="post-card__meta"><span>🕒 <?php echo e(format_time($p['created_at'])); ?></span></div>
              </div>
            </a>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>
    <?php elseif ($kw !== ''): ?>
      <p class="empty">没有找到和「<?php echo e($kw); ?>」相关的内容，换个词试试？</p>
    <?php endif; ?>

    <?php if (!empty($pager)): ?><div class="pager"><?php echo $pager; ?></div><?php endif; ?>
  </div>
</section>

<?php include partial_path('footer.php'); ?>
