<?php
/** 喵窝 · Mio —— 看板娘小屋（可选页）；变量：$cp_stats $cp_name */
require_once __DIR__ . '/_lib.php';
$cur_p = 'companion';
include partial_path('header.php');
$t = isset($cp_stats['total']) ? $cp_stats['total'] : array('req' => 0, 'in' => 0, 'out' => 0);
$d = isset($cp_stats['today']) ? $cp_stats['today'] : array('req' => 0, 'in' => 0, 'out' => 0);
$fo_home_url = function_exists('home_url') ? home_url() : base_url();
?>
<section class="section--tight">
  <div class="container">
    <div class="page-head">
      <h1>🤖 <?php echo e(isset($cp_name) ? $cp_name : '小屋'); ?></h1>
      <p>陪聊用量记录，数字由程序核心实时统计。</p>
    </div>
    <div class="footer-legal" style="border-top:none;padding-top:var(--space-6);justify-content:center;gap:var(--space-8)">
      <span>💬 累计 <?php echo (int)(isset($t['req']) ? $t['req'] : 0); ?> 次对话</span>
      <span>☀️ 今日 <?php echo (int)(isset($d['req']) ? $d['req'] : 0); ?> 次对话</span>
      <span>✍️ 累计输出 <?php echo (int)(isset($t['out']) ? $t['out'] : 0); ?> 字符</span>
    </div>
    <p class="center" style="margin-top:var(--space-12)"><a class="btn btn--ghost" href="<?php echo e($fo_home_url); ?>">回到首页</a></p>
  </div>
</section>

<?php include partial_path('footer.php'); ?>
