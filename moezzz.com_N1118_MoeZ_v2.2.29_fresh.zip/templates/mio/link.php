<?php
/** 喵窝 · Mio —— 友情链接；变量：$links */
require_once __DIR__ . '/_lib.php';
$cur_p = 'link';
include partial_path('header.php');
$fo_mail = fo_email();
$fo_name = fo_name();
$fo_home_url = function_exists('home_url') ? home_url() : base_url();
?>
<section class="section--tight">
  <div class="container">
    <div class="page-head">
      <h1>🔗 友情链接</h1>
      <p>这些是常来常往的站点，一共 <?php echo count((array)$links); ?> 个。</p>
    </div>
    <?php if (!empty($links)): ?>
      <div class="link-grid">
        <?php foreach ($links as $l):
          $ico = function_exists('link_icon') ? link_icon($l) : '';
          $desc = function_exists('link_desc') ? link_desc($l) : '';
          $host = parse_url((string)$l['url'], PHP_URL_HOST);
          $sub = $desc !== '' ? $desc : ($host ? $host : $l['url']);
        ?>
          <a class="link-card" href="<?php echo e($l['url']); ?>" target="_blank" rel="noopener nofollow">
            <?php if ($ico !== ''): ?>
              <img class="link-card__logo" src="<?php echo e($ico); ?>" alt="" loading="lazy" onerror="this.outerHTML='<span class=\'link-card__logo link-card__logo--emoji\' aria-hidden=\'true\'>🔗</span>'">
            <?php else: ?>
              <span class="link-card__logo link-card__logo--emoji" aria-hidden="true">🔗</span>
            <?php endif; ?>
            <span><b><?php echo e($l['name']); ?></b><small style="display:block;font-size:var(--text-xs);color:var(--text-muted)"><?php echo e($sub); ?></small></span>
          </a>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="empty">朋友名单还是空的，来交个朋友吧～</p>
    <?php endif; ?>

    <div class="empty" style="margin-top:var(--space-16)">
      <p>想交换友链？附上 <b>站名 / 网址 / 一句话简介</b> 给 <?php echo e($fo_name); ?>
      <?php if ($fo_mail !== ''): ?><a href="mailto:<?php echo e($fo_mail); ?>?subject=<?php echo e(rawurlencode('申请友链')); ?>">写封信</a><?php else: ?><a href="<?php echo e($fo_home_url); ?>">留个言</a><?php endif; ?> 就好。</p>
    </div>
  </div>
</section>

<?php include partial_path('footer.php'); ?>
