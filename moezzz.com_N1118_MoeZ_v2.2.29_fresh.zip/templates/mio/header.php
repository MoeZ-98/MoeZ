<?php
/**
 * 喵窝 · Mio —— 公共头部 + 粘性导航 + 背景柔彩光斑
 * 各模板先设置 $cur_p（当前栏目），再 include partial_path('header.php')。
 * 仅依赖核心函数与 _lib.php，不改动任何核心文件。
 */
require_once __DIR__ . '/_lib.php';
$cur_p   = isset($cur_p) ? (string)$cur_p : 'index';
$fo_home = fo_is_home($cur_p);
$fo_name = fo_name();
$fo_mode = fo_default_mode();
$fo_nav  = fo_nav();
$fo_favicon = fo_media(fo_opt('favicon', ''));
if ($fo_favicon === '') $fo_favicon = fo_asset('favicon.svg');
$fo_home_url = function_exists('home_url') ? home_url() : base_url();
$fo_rss  = function_exists('rss_url') ? rss_url() : (base_url() . 'rss');

/* 锚点链接补全网址，使导航在任意页面都能跳回首页对应区块 */
function fo_nav_href($u, $home) {
    if ($u === '' || $u === '#') return $home;
    if ($u[0] === '#') return $home . $u;
    return $u;
}
?><!DOCTYPE html>
<html lang="zh-CN" data-theme="<?php echo e($fo_mode); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo function_exists('seo_head') ? seo_head() : '<title>' . e($fo_name) . '</title>'; ?>
<meta name="theme-color" content="<?php echo e($fo_mode === 'night' ? '#1A1426' : '#FFF6FB'); ?>">
<link rel="icon" href="<?php echo e($fo_favicon); ?>">
<link rel="alternate" type="application/rss+xml" title="<?php echo e($fo_name); ?> 的订阅" href="<?php echo e($fo_rss); ?>">
<link rel="stylesheet" href="<?php echo e(fo_asset('style.css')); ?>?v=<?php echo e(fo_ver()); ?>">
<style id="mio-tokens"><?php echo fo_tokens_css(); ?></style>
<?php if ($fo_home) echo fo_person_jsonld(isset($site) ? $site : null, true); ?>
<?php $fo_extra_head = trim((string)fo_opt('extra_head', '')); if ($fo_extra_head !== '') echo "\n" . $fo_extra_head . "\n"; ?>
<script>(function(){var d=document.documentElement,m=null;try{m=localStorage.getItem('mio-theme')}catch(e){}if(m==='day'||m==='night')d.setAttribute('data-theme',m);d.className+=' mio-js';})();</script>
</head>
<body class="fx-<?php echo e(fo_opt('blob_intensity', 'medium')); ?>" data-petals="<?php echo fo_on('show_petals', '1') ? '1' : '0'; ?>" data-motion="<?php echo fo_on('motion_on', '1') ? 'on' : 'off'; ?>">
<?php if (fo_on('progress_bar', '1')): ?><div class="progress" id="mioProgress" aria-hidden="true"></div><?php endif; ?>
<a class="sr-only" href="#main">跳到主内容</a>

<div class="bg-fx" aria-hidden="true">
  <div class="blob blob--1"></div>
  <div class="blob blob--2"></div>
  <div class="blob blob--3"></div>
</div>

<header class="site-header" id="siteHeader">
  <div class="container nav">
    <a class="nav__brand" href="<?php echo e($fo_home_url); ?>"><span class="dot"></span><?php echo e(fo_opt('logo_text', $fo_name)); ?></a>
    <button class="nav__toggle" id="navToggle" aria-label="打开菜单" aria-expanded="false">☰</button>
    <nav class="nav__links" id="navLinks" aria-label="主导航">
      <?php foreach ($fo_nav as $n): ?>
        <a href="<?php echo e(fo_nav_href($n['url'], $fo_home_url)); ?>"><?php echo e($n['name']); ?></a>
      <?php endforeach; ?>
    </nav>
    <div class="nav__right">
      <?php if (fo_on('show_search', '1')): ?>
        <form class="nav__search" method="get" action="<?php echo e($fo_home_url); ?>" aria-label="站内搜索">
          <input type="hidden" name="p" value="search">
          <input type="search" name="q" placeholder="搜索…" aria-label="搜索关键词" value="<?php echo isset($kw) ? e($kw) : ''; ?>">
        </form>
      <?php endif; ?>
      <?php if (fo_on('show_rss', '1')): ?>
        <a class="nav__icon" href="<?php echo e($fo_rss); ?>" title="RSS 订阅" aria-label="RSS 订阅">📰</a>
      <?php endif; ?>
      <?php if (fo_on('show_theme_toggle', '1')): ?>
        <button class="nav__icon" id="themeToggle" type="button" aria-label="切换昼夜模式" title="切换昼夜">🌙</button>
      <?php endif; ?>
    </div>
  </div>
</header>

<main id="main">
