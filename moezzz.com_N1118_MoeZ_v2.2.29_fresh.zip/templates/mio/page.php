<?php
/**
 * 喵窝 · Mio —— 独立页面（也可作留言板：开启评论即可）
 * 可用变量：$page（页面数组） $site $nav_cats
 */
require_once __DIR__ . '/_lib.php';
$cur_p = 'page';
include partial_path('header.php');

$post = $page;
$comments = array();
if (function_exists('rows') && function_exists('moe_table')) {
    try {
        $comments = (array)rows('SELECT * FROM ' . moe_table('comments') . " WHERE post_id = ? AND status='approved' ORDER BY id DESC", array((int)$page['id']));
    } catch (Throwable $e) { $comments = array(); }
}
$fo_cover = post_cover($page);
$fo_content = function_exists('render_content')
    ? render_content($page['content'], isset($page['content_format']) ? $page['content_format'] : 'html')
    : nl2br(e($page['content']));
$fo_home_url = function_exists('home_url') ? home_url() : base_url();
?>
<article class="article<?php echo fo_opt('reading_width') === 'wide' ? ' reading-wide' : ''; ?>">
  <div class="crumbs">
    <a href="<?php echo e($fo_home_url); ?>">首页</a><span aria-hidden="true">/</span>
    <span class="text-muted"><?php echo e($page['title']); ?></span>
  </div>
  <header class="article__head">
    <h1 class="article__title"><?php echo e($page['title']); ?></h1>
  </header>
  <?php if ($fo_cover !== ''): ?>
    <div class="article__cover"><img src="<?php echo e(fo_media($fo_cover)); ?>" alt="<?php echo e($page['title']); ?>"<?php echo fo_lazy(); ?>></div>
  <?php endif; ?>
  <div class="prose">
    <?php echo $fo_content; ?>
  </div>
</article>

<?php include partial_path('_comments.php'); ?>

<?php include partial_path('footer.php'); ?>
