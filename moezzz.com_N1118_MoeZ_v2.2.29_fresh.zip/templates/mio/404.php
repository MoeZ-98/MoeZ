<?php
/** 喵窝 · Mio —— 404 */
require_once __DIR__ . '/_lib.php';
$cur_p = '404';
include partial_path('header.php');
$fo_home_url = function_exists('home_url') ? home_url() : base_url();
?>
<section class="void">
  <div class="container">
    <p class="void__code" aria-hidden="true">404</p>
    <h1>这一页不在小窝里</h1>
    <p class="text-muted" style="max-width:36ch;margin:var(--space-4) auto var(--space-8)">可能换了地址，也可能还没写。回到首页，或者翻翻下面的链接。</p>
    <a class="btn btn--primary" href="<?php echo e($fo_home_url); ?>">回到首页</a>
  </div>
</section>

<?php include partial_path('footer.php'); ?>
