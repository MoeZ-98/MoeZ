<?php
/** 喵窝 · Mio —— 关于页（模板内置，无额外变量） */
require_once __DIR__ . '/_lib.php';
$cur_p = 'about';
include partial_path('header.php');

$fo_avatar = fo_avatar();
$fo_name = fo_name();
$fo_about_photo = fo_about_photo();
$fo_about_emoji = trim((string)fo_opt('about_emoji', '🌟'));
$fo_about_intro = trim((string)fo_opt('about_intro', ''));
$fo_about_stats = fo_pairs(fo_opt('about_stats', ''));
$fo_interests = fo_triples(fo_opt('interests', ''));
$fo_stat = fo_stats();
?>
<section class="section--tight">
  <div class="container">
    <div class="page-head"><h1>💭 关于我</h1><p>一个住在二次元边缘、不太正经的普通人类。</p></div>

    <div class="about">
      <div class="about__photo" data-reveal>
        <?php if ($fo_about_photo !== ''): ?>
          <img src="<?php echo e(fo_media($fo_about_photo)); ?>" alt="<?php echo e($fo_name); ?> 的照片"<?php echo fo_lazy(); ?>>
        <?php else: ?>
          <span class="sticker">本人（大概）</span>
          <span class="emoji" aria-hidden="true"><?php echo e($fo_about_emoji); ?></span>
        <?php endif; ?>
      </div>
      <div class="about__body" data-reveal>
        <?php echo fo_md($fo_about_intro); ?>
        <?php if (!empty($fo_about_stats)): ?>
          <div class="about__stats">
            <?php foreach ($fo_about_stats as $s): ?>
              <div class="chip"><span><?php echo e($s['name']); ?></span><strong><?php echo e($s['value']); ?></strong></div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <?php if (!empty($fo_interests)): ?>
      <div class="section-head" style="margin-top:var(--space-16)"><h2><span class="mark">🎀</span>我沉迷的东西</h2></div>
      <div class="grid-auto">
        <?php foreach ($fo_interests as $c): ?>
          <article class="card" data-reveal>
            <div class="card__icon" aria-hidden="true"><?php echo e($c['icon']); ?></div>
            <h3><?php echo e($c['title']); ?></h3>
            <p><?php echo e($c['desc']); ?></p>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <div class="footer-legal" style="border-top:none;padding-top:var(--space-8);margin-top:var(--space-12);text-align:center">
      <span>📝 <?php echo (int)$fo_stat['posts']; ?> 篇 · 💬 <?php echo (int)$fo_stat['comments']; ?> 条 · 👀 <?php echo (int)$fo_stat['views']; ?> 次 · ⏳ 运行 <?php echo (int)$fo_stat['days']; ?> 天</span>
    </div>
  </div>
</section>

<?php include partial_path('footer.php'); ?>
