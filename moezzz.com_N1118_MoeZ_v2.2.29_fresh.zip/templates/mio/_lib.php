<?php
/**
 * 喵窝 · Mio —— 公共函数库
 * 由 header.php 引入，所有模板文件都可直接使用 fo_* 系列函数。
 * 只依赖程序核心已有的函数，不改动任何核心文件。
 */
if (defined('MIO_LIB')) return;
define('MIO_LIB', 1);

/** 读取模板设置（info.php 里声明的默认值自动兜底） */
function fo_opt($key, $default = '') { return theme_opt($key, $default); }
function fo_on($key, $default = '1') { return (string)theme_opt($key, $default) === '1'; }

/** 静态资源版本：升级 style.css / app.js 时改这里即可刷新浏览器缓存 */
function fo_ver() { return '1.0.0'; }

/** 站内链接：完整 URL 原样；以 / 开头或短路径都按站点根拼接，兼容子目录部署 */
function fo_url($p) {
    $p = trim((string)$p);
    if ($p === '' || $p === '/') return function_exists('home_url') ? home_url() : base_url();
    if (preg_match('#^[a-z]+://#i', $p) || $p[0] === '#' || $p[0] === '{') return $p;
    if ($p[0] === '/') return base_url() . ltrim($p, '/');
    if (function_exists('home_url')) return home_url() . $p;
    return base_url() . $p;
}

/** 主题资源（assets 目录） */
function fo_asset($p) { return theme_url('assets/' . ltrim((string)$p, '/')); }

/** 上传媒体资源 */
function fo_media($p) { return media_url($p); }

/** 将多行文本解析为「名称 | 链接」数组 */
function fo_lines($raw) {
    $out = array();
    $raw = (string)$raw;
    if ($raw === '') return $out;
    foreach (explode("\n", $raw) as $line) {
        $line = trim($line);
        if ($line === '') continue;
        $parts = explode('|', $line, 2);
        $name = trim($parts[0]);
        $url  = isset($parts[1]) ? trim($parts[1]) : '';
        $out[] = array('name' => $name, 'url' => $url);
    }
    return $out;
}

/** 将多行文本解析为「标签 | 值」数组（关于小档案） */
function fo_pairs($raw) {
    $out = array();
    $raw = (string)$raw;
    if ($raw === '') return $out;
    foreach (explode("\n", $raw) as $line) {
        $line = trim($line);
        if ($line === '') continue;
        $parts = explode('|', $line, 2);
        $out[] = array('name' => trim($parts[0]), 'value' => isset($parts[1]) ? trim($parts[1]) : '');
    }
    return $out;
}

/** 将多行文本解析为「icon | 标题 | 描述」数组（兴趣卡片） */
function fo_triples($raw) {
    $out = array();
    $raw = (string)$raw;
    if ($raw === '') return $out;
    foreach (explode("\n", $raw) as $line) {
        $line = trim($line);
        if ($line === '') continue;
        $parts = explode('|', $line, 3);
        $out[] = array(
            'icon'  => trim($parts[0]),
            'title' => isset($parts[1]) ? trim($parts[1]) : '',
            'desc'  => isset($parts[2]) ? trim($parts[2]) : '',
        );
    }
    return $out;
}

/** 将多行文本解析为「emoji | 标题 | 简介 | 状态」数组（追番清单） */
function fo_anime_list($raw) {
    $out = array();
    $raw = (string)$raw;
    if ($raw === '') return $out;
    foreach (explode("\n", $raw) as $line) {
        $line = trim($line);
        if ($line === '') continue;
        $parts = explode('|', $line, 4);
        $status = isset($parts[3]) ? trim($parts[3]) : '';
        $cls = 'watching';
        if (mb_strpos($status, '完') !== false) $cls = 'done';
        elseif (mb_strpos($status, '补') !== false) $cls = 'catch';
        $out[] = array(
            'emoji' => trim($parts[0]),
            'title' => isset($parts[1]) ? trim($parts[1]) : '',
            'desc'  => isset($parts[2]) ? trim($parts[2]) : '',
            'status'=> $status,
            'cls'   => $cls,
        );
    }
    return $out;
}

/** 社交链接：名称 | 链接 | 图标 */
function fo_socials() {
    return fo_triples(fo_opt('social_links', ''));
}

/** 导航菜单 */
function fo_nav() {
    return fo_lines(fo_opt('nav_menu', "关于我|#about\n兴趣|#interest\n作品|#works\n追番|#anime\n友链|#friends\n留言|#contact"));
}

/** 页脚菜单 */
function fo_footer_menu() {
    return fo_lines(fo_opt('footer_menu', "关于我|#about\n我的作品|#works\n追番清单|#anime\n友情链接|#friends\n留言板|#contact"));
}

/** 品牌名（优先导航品牌名，否则站点名） */
function fo_name() {
    $t = trim((string)fo_opt('logo_text', ''));
    if ($t !== '') return $t;
    return function_exists('setting') ? setting('site_name', 'Moe Home') : 'Moe Home';
}

/** 联系邮箱 */
function fo_email() {
    $e = trim((string)fo_opt('contact_email', ''));
    return $e;
}

/** 关于区照片（留空返回空，由模板决定占位） */
function fo_about_photo() { return trim((string)fo_opt('about_photo', '')); }

/** 头像：设置了照片用照片，否则返回内置猫娘 SVG 标记 */
function fo_avatar() { return trim((string)fo_opt('avatar_image', '')); }

/** 站点统计 + 运行天数 */
function fo_stats() {
    $s = function_exists('site_stats') ? site_stats() : array('posts' => 0, 'comments' => 0, 'views' => 0);
    $from = trim((string)fo_opt('run_from', ''));
    $days = 0;
    if ($from !== '') {
        $ts = strtotime($from);
        if ($ts !== false) $days = max(0, floor((time() - $ts) / 86400));
    }
    $s['days'] = $days;
    return $s;
}

/** 运行天数（单独取用） */
function fo_run_days() { return fo_stats()['days']; }

/* ---------------- 配色预设 ---------------- */
function fo_palette_map() {
    return array(
        'sakura' => array('accent' => '#FF6FA5', 'a2' => '#7C5CFF', 'a3' => '#45C8F0'),
        'mint'   => array('accent' => '#5FD6A6', 'a2' => '#22A7D6', 'a3' => '#FF9EC6'),
        'honey'  => array('accent' => '#FFB15C', 'a2' => '#FF6FA5', 'a3' => '#FFD86B'),
        'berry'  => array('accent' => '#FF5C8A', 'a2' => '#7C5CFF', 'a3' => '#5FD0F5'),
        'ocean'  => array('accent' => '#45C8F0', 'a2' => '#6B48F0', 'a3' => '#7FE0BE'),
    );
}

/** 默认昼夜 */
function fo_default_mode() {
    $m = trim((string)fo_opt('default_mode', 'day'));
    return $m === 'night' ? 'night' : 'day';
}

/** 十六进制转 rgba（用于 accent-subtle 等） */
function fo_hex_rgba($hex, $alpha = 1) {
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    return 'rgba(' . $r . ',' . $g . ',' . $b . ',' . $alpha . ')';
}

/** 输出配色 / 圆角相关的 CSS 变量（注入到 <head>，叠在 style.css 之上） */
function fo_tokens_css() {
    $pal = fo_palette_map();
    $key = trim((string)fo_opt('palette', 'sakura'));
    if (!isset($pal[$key])) $key = 'sakura';
    $p = $pal[$key];

    $accent = trim((string)fo_opt('accent', ''));
    if (preg_match('/^#[0-9a-fA-F]{6}$/', $accent)) $p['accent'] = $accent;

    $hover = fo_hex_rgba($p['accent'], 1);
    $subtle = fo_hex_rgba($p['accent'], 0.14);

    $radius = trim((string)fo_opt('radius', 'soft'));
    if (!in_array($radius, array('soft', 'round', 'square'), true)) $radius = 'soft';
    $r = array(
        'soft'  => array(8, 12, 20, 28),
        'round' => array(14, 20, 28, 36),
        'square'=> array(6, 8, 12, 16),
    );
    list($sm, $md, $lg, $xl) = $r[$radius];

    return ":root{\n"
        . "  --accent:{$p['accent']}; --accent-hover:{$hover}; --accent-subtle:{$subtle};\n"
        . "  --accent-2:{$p['a2']}; --accent-2-hover:" . fo_hex_rgba($p['a2'], 1) . ";\n"
        . "  --accent-3:{$p['a3']}; --accent-3-hover:" . fo_hex_rgba($p['a3'], 1) . ";\n"
        . "  --radius-sm:{$sm}px; --radius-md:{$md}px; --radius-lg:{$lg}px; --radius-xl:{$xl}px; --radius-full:9999px;\n"
        . "  --btn-radius:var(--radius-full); --card-radius:var(--radius-xl); --input-radius:var(--radius-md);\n"
        . "}\n";
}

/** 极简安全 Markdown：空行分段、[文字](链接)、**粗**、*斜*，所有文本先转义 */
function fo_md($raw) {
    $raw = (string)$raw;
    $html = '';
    $blocks = preg_split('/\n\s*\n/', $raw);
    foreach ($blocks as $b) {
        $b = trim($b);
        if ($b === '') continue;
        $b = e($b);
        $b = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $b);
        $b = preg_replace('/\*(.+?)\*/', '<em>$1</em>', $b);
        $b = preg_replace_callback('/\[(.+?)\]\((.+?)\)/', function ($m) {
            $href = preg_match('#^[a-z]+://#i', $m[2]) || $m[2][0] === '/' || $m[2][0] === '#' ? $m[2] : 'https://' . $m[2];
            return '<a href="' . e($href) . '" rel="noopener">' . $m[1] . '</a>';
        }, $b);
        $html .= '<p>' . nl2br($b, false) . "</p>\n";
    }
    return $html;
}

/** 首页区块标题小标（mark emoji + 标题 + 副文案） */
function fo_section_head($mark, $title, $sub = '') {
    $h = '<div class="section-head" data-reveal>'
       . '<h2><span class="mark" aria-hidden="true">' . e($mark) . '</span>' . e($title) . '</h2>';
    if ($sub !== '') $h .= '<p>' . e($sub) . '</p>';
    return $h . '</div>';
}

/** 作品来源：最新文章 或 指定分类 */
function fo_work_posts() {
    $source = fo_opt('work_source', 'latest');
    $n = (int)fo_opt('work_count', '6');
    if ($n < 1) $n = 6;
    if ($source === 'category') {
        $slug = trim((string)fo_opt('work_cat', ''));
        if ($slug !== '' && function_exists('row')) {
            $cat = row('SELECT * FROM ' . moe_table('categories') . ' WHERE slug=?', array($slug));
            if ($cat) {
                return rows('SELECT p.*, c.name AS cat_name FROM ' . moe_table('posts') . ' p'
                    . ' LEFT JOIN ' . moe_table('categories') . ' c ON c.id=p.category_id'
                    . " WHERE p.type='post' AND p.status='published' AND p.category_id=?"
                    . ' ORDER BY p.is_top DESC, p.created_at DESC, p.id DESC LIMIT ' . $n,
                    array((int)$cat['id']));
            }
        }
    }
    return rows('SELECT p.*, c.name AS cat_name FROM ' . moe_table('posts') . ' p'
        . ' LEFT JOIN ' . moe_table('categories') . ' c ON c.id=p.category_id'
        . " WHERE p.type='post' AND p.status='published'"
        . ' ORDER BY p.is_top DESC, p.created_at DESC, p.id DESC LIMIT ' . $n);
}

/** 文章封面：有封面用封面，否则返回渐变占位 class（按 id 取色） */
function fo_cover($post) {
    $cover = post_cover($post);
    if ($cover !== '') return $cover;
    return '';
}

/** 封面占位渐变（无图时给 gallery / 卡片用） */
function fo_cover_grad($seed = 0) {
    $grads = array(
        'linear-gradient(140deg,#FFD1E8,#FF9EC6)',
        'linear-gradient(140deg,#C9B6FF,#7C5CFF)',
        'linear-gradient(140deg,#9BE2FF,#45C8F0)',
        'linear-gradient(140deg,#FFE0A8,#FFC36B)',
        'linear-gradient(140deg,#BFEAD6,#5FD6A6)',
        'linear-gradient(140deg,#F3C8FF,#C98CFF)',
    );
    return $grads[abs((int)$seed) % count($grads)];
}

/** 图片懒加载属性 */
function fo_lazy() {
    return fo_on('lazy_on', '1') ? ' loading="lazy" decoding="async"' : '';
}

/** 当前页判断（首页） */
function fo_is_home($cur_p) { return $cur_p === 'index' || $cur_p === 'home'; }

/** 区块开关标签：返回是否需要显示 */
function fo_show($key, $default = '1') { return fo_on($key, $default); }

/** Person / ProfilePage 结构化数据 */
function fo_person_jsonld($site, $is_home) {
    if (!function_exists('home_url')) return '';
    $name = trim((string)fo_opt('seo_person', ''));
    if ($name === '') $name = fo_name();
    $url = home_url();
    $img = trim((string)fo_opt('og_image', ''));
    if ($img !== '') $img = fo_media($img);
    $same = array();
    $raw = trim((string)fo_opt('person_sameas', ''));
    if ($raw !== '') {
        foreach (explode("\n", $raw) as $l) {
            $l = trim($l);
            if ($l !== '' && preg_match('#^[a-z]+://#i', $l)) $same[] = $l;
        }
    }
    $data = array(
        '@context' => 'https://schema.org',
        '@graph' => array(
            array(
                '@type' => 'ProfilePage',
                '@id' => $url . '#profile',
                'url' => $url,
                'mainEntity' => array('@type' => 'Person', 'name' => $name, 'url' => $url),
            ),
            array(
                '@type' => 'Person',
                'name' => $name,
                'url' => $url,
            ),
        ),
    );
    if ($img !== '') { $data['@graph'][1]['image'] = $img; }
    if (!empty($same)) { $data['@graph'][1]['sameAs'] = $same; }
    return '<script type="application/ld+json">' . e(json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)) . '</script>';
}

/** 轻量目录：从已渲染 HTML 中抽取 h2/h3，注入锚点 id 并返回目录与处理后的正文 */
function fo_toc($html) {
    if (!is_string($html) || $html === '') return array('toc' => '', 'html' => $html);
    $items = array(); $n = 0;
    $html = preg_replace_callback('/<h([23])(\s[^>]*)?>(.*?)<\/h\1>/is', function ($m) use (&$items, &$n) {
        $n++; $id = 'sec-' . $n; $level = $m[1]; $txt = trim(strip_tags($m[3]));
        $items[] = array('level' => $level, 'text' => $txt, 'id' => $id);
        return '<h' . $level . ' id="' . e($id) . '"' . (isset($m[2]) ? $m[2] : '') . '>' . $m[3] . '</h' . $level . '>';
    }, $html);
    if (empty($items)) return array('toc' => '', 'html' => $html);
    $lis = '';
    foreach ($items as $it) {
        $lis .= '<li' . ($it['level'] == 3 ? ' style="margin-left:1.1em"' : '') . '><a href="#' . e($it['id']) . '">' . e($it['text']) . '</a></li>';
    }
    $toc = '<nav class="toc" aria-label="目录"><h4>目录</h4><ol>' . $lis . '</ol></nav>';
    return array('toc' => $toc, 'html' => $html);
}

/** 内置猫娘头像 SVG（留空头像照片时回退） */
function fo_avatar_svg() {
    return '<svg class="avatar__art" viewBox="0 0 200 200" role="img" aria-label="二次元猫娘头像插画">
      <path d="M58 64 L44 22 L86 50 Z" fill="#FF8FBF"/>
      <path d="M142 64 L156 22 L114 50 Z" fill="#FF8FBF"/>
      <path d="M62 60 L53 34 L78 52 Z" fill="#FFC2DD"/>
      <path d="M138 60 L147 34 L122 52 Z" fill="#FFC2DD"/>
      <circle cx="100" cy="108" r="64" fill="#C9B6FF"/>
      <circle cx="100" cy="116" r="52" fill="#FFF1E6"/>
      <path d="M50 108 Q58 64 100 62 Q142 64 150 108 Q132 90 100 92 Q68 90 50 108 Z" fill="#B89CFF"/>
      <path d="M100 62 Q92 84 84 92 Q96 96 100 80 Q104 96 116 92 Q108 84 100 62 Z" fill="#A98CFF"/>
      <ellipse cx="80" cy="118" rx="9" ry="13" fill="#5E4C63"/>
      <ellipse cx="120" cy="118" rx="9" ry="13" fill="#5E4C63"/>
      <circle cx="83" cy="113" r="3.2" fill="#fff"/>
      <circle cx="123" cy="113" r="3.2" fill="#fff"/>
      <circle cx="78" cy="122" r="1.8" fill="#fff" opacity=".8"/>
      <circle cx="118" cy="122" r="1.8" fill="#fff" opacity=".8"/>
      <ellipse cx="68" cy="134" rx="9" ry="5" fill="#FF9EC6" opacity=".7"/>
      <ellipse cx="132" cy="134" rx="9" ry="5" fill="#FF9EC6" opacity=".7"/>
      <path d="M93 132 Q100 140 107 132" fill="none" stroke="#E0779B" stroke-width="2.4" stroke-linecap="round"/>
      <path d="M150 96 l3 6 6 1 -4.5 4.5 1 6 -5.5 -3 -5.5 3 1 -6 -4.5 -4.5 6 -1 z" fill="#FFD86B"/>
    </svg>';
}
