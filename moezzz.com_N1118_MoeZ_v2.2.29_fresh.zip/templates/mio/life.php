<?php
/** 喵窝 · Mio —— 点滴时间线；变量：$groups（yyyy-MM => 条目） $total $life_cat */
require_once __DIR__ . '/_lib.php';
$cur_p = 'life';
include partial_path('header.php');
?>
<section class="section--tight">
  <div class="container">
    <div class="page-head">
      <h1>🌸 <?php echo e(isset($life_cat['name']) ? $life_cat['name'] : '点滴'); ?></h1>
      <p>按月收好的 <?php echo (int)$total; ?> 条日常。</p>
    </div>
    <?php if (!empty($groups)): ?>
      <?php foreach ($groups as $month => $items): ?>
        <div class="archive-group">
          <h3><?php echo e(str_replace('-', ' / ', $month)); ?></h3>
          <div class="archive-list">
            <?php foreach ($items as $it): ?>
              <div class="archive-item">
                <time datetime="<?php echo e(substr((string)$it['created_at'], 0, 10)); ?>"><?php echo e(substr((string)$it['created_at'], 8, 2)); ?> 日</time>
                <a href="<?php echo e(post_url($it)); ?>"><?php echo e($it['title']); ?></a>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <p class="empty">这里还没有点滴。</p>
    <?php endif; ?>
  </div>
</section>

<?php include partial_path('footer.php'); ?>
