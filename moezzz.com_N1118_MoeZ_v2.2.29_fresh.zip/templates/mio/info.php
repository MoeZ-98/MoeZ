<?php
/**
 * 喵窝 · Mio — 二次元柔彩梦幻个人主页主题
 *
 * 把「星野澪の秘密基地」这般又软又亮的二次元小站，做成一套可在后台
 * 可视化配置的个人主页 / 作品集主题：pastel-kawaii 配色、昼夜切换、
 * 飘落花瓣与星星、猫娘头像、关于 / 兴趣 / 作品 / 追番 / 友链 / 留言。
 *
 * 所有人物资料、兴趣、追番、社交等均为「演示默认值」，站长可在
 * 「模板管理 → 模板设置」逐项替换；主题键前缀为 themeopt_mio_*。
 */
return array(
    'name'    => '喵窝 · Mio',
    'version' => '1.0.0',
    'author'  => 'WorkBuddy',
    'desc'    => '二次元柔彩梦幻个人主页 / 作品集主题：樱粉紫渐变、昼夜切换、飘落花瓣与星星、猫娘头像，关于/兴趣/作品/追番/友链/留言均为后台可视化设置。',

    'settings' => array(
        /* ============ 品牌与外观 ============ */
        array(
            'key'     => 'palette',
            'group'   => '品牌与外观',
            'label'   => '配色预设',
            'type'    => 'select',
            'default' => 'sakura',
            'options' => array(
                'sakura' => '樱粉紫（粉 + 紫 + 天蓝）',
                'mint'   => '薄荷绿（绿 + 青 + 樱）',
                'honey'  => '蜜橘暖（橙 + 粉 + 黄）',
                'berry'  => '莓果（玫红 + 紫 + 蓝）',
                'ocean'  => '海洋（蓝 + 青 + 紫）',
            ),
            'hint'    => '决定主色、辅助色、点缀色三件套；单色强调色可在此之下用「主强调色」覆盖',
        ),
        array(
            'key'     => 'accent',
            'group'   => '品牌与外观',
            'label'   => '主强调色',
            'type'    => 'color',
            'default' => '#FF6FA5',
            'hint'    => '覆盖预设里的主色（粉），用于标签、描边、光晕；辅助色与点缀色仍由预设提供',
        ),
        array(
            'key'     => 'radius',
            'group'   => '品牌与外观',
            'label'   => '圆角风格',
            'type'    => 'select',
            'default' => 'soft',
            'options' => array(
                'soft'  => '柔润（卡片圆角 20–28px）',
                'round' => '全圆角（胶囊按钮、大圆卡）',
                'square'=> '克制（小圆角 8–12px）',
            ),
        ),
        array(
            'key'     => 'default_mode',
            'group'   => '品牌与外观',
            'label'   => '默认昼夜',
            'type'    => 'select',
            'default' => 'day',
            'options' => array('day' => '白天（柔彩梦幻）', 'night' => '夜晚（深紫星云）'),
            'hint'    => '访客可手动切换并用浏览器记住偏好',
        ),
        array(
            'key'     => 'show_petals',
            'group'   => '品牌与外观',
            'label'   => '飘落花瓣与星星',
            'type'    => 'bool',
            'default' => '1',
            'hint'    => '首页背景飘落花瓣 + 闪烁星星；尊重系统「减少动态」设置，会自动关闭',
        ),
        array(
            'key'     => 'blob_intensity',
            'group'   => '品牌与外观',
            'label'   => '背景光斑强度',
            'type'    => 'select',
            'default' => 'medium',
            'options' => array('off' => '关闭', 'soft' => '轻柔', 'medium' => '中等', 'strong' => '明显'),
        ),
        array(
            'key'     => 'logo_text',
            'group'   => '品牌与外观',
            'label'   => '导航品牌名',
            'type'    => 'text',
            'default' => '星野澪',
        ),
        array(
            'key'     => 'favicon',
            'group'   => '品牌与外观',
            'label'   => 'Favicon',
            'type'    => 'text',
            'default' => '',
            'hint'    => '留空使用主题内置猫爪 favicon；可填 /uploads/xxx.svg 之类的路径',
        ),
        array(
            'key'     => 'og_image',
            'group'   => '品牌与外观',
            'label'   => '首页分享图',
            'type'    => 'text',
            'default' => '',
            'hint'    => '留空使用主题内置预览图；社交分享时展示',
        ),

        /* ============ 英雄区 ============ */
        array(
            'key'     => 'hero_greeting',
            'group'   => '英雄区',
            'label'   => '顶部小标',
            'type'    => 'text',
            'default' => 'SECRET BASE · 二次元小宇宙',
        ),
        array(
            'key'     => 'hero_name',
            'group'   => '英雄区',
            'label'   => '主名字',
            'type'    => 'text',
            'default' => '星野澪 Mio',
        ),
        array(
            'key'     => 'hero_sub',
            'group'   => '英雄区',
            'label'   => '副文案',
            'type'    => 'textarea',
            'default' => "画画的 / 追番的 / 在二次元里迷路的人。\n欢迎来到我的秘密基地，这里收藏着我的画、我爱的番，和一点点不切实际的浪漫。",
            'hint'    => '两段，空行分段',
        ),
        array(
            'key'     => 'hero_tags',
            'group'   => '英雄区',
            'label'   => '兴趣标签',
            'type'    => 'textarea',
            'default' => "🎨 板绘爱好者\n📺 日常番中毒\n🎮 手残音游党\n🌸 软绵绵系",
            'hint'    => '每行一个，可带 emoji',
        ),
        array(
            'key'     => 'avatar_image',
            'group'   => '英雄区',
            'label'   => '头像照片',
            'type'    => 'text',
            'default' => '',
            'hint'    => '留空使用主题内置猫娘 SVG 插画；可填图片路径替换为真实头像',
        ),
        array(
            'key'     => 'avatar_badge',
            'group'   => '英雄区',
            'label'   => '头像角标 emoji',
            'type'    => 'text',
            'default' => '🐾',
        ),

        /* ============ 关于我 ============ */
        array(
            'key'     => 'about_photo',
            'group'   => '关于我',
            'label'   => '关于区照片',
            'type'    => 'text',
            'default' => '',
            'hint'    => '留空使用渐变占位 + emoji',
        ),
        array(
            'key'     => 'about_emoji',
            'group'   => '关于我',
            'label'   => '占位 emoji',
            'type'    => 'text',
            'default' => '🌟',
        ),
        array(
            'key'     => 'about_intro',
            'group'   => '关于我',
            'label'   => '自我介绍',
            'type'    => 'textarea',
            'default' => "我是星野澪，白天写代码，晚上画画，深夜追番。喜欢一切柔软的、发光的、会让人心头一软的东西。\n这个站点是我自己搭的小窝，没有算法、没有信息流，只有我想留下的东西。如果它让你笑了一下，那我的 mission 就完成了。",
            'hint'    => '两段，空行分段',
        ),
        array(
            'key'     => 'about_stats',
            'group'   => '关于我',
            'label'   => '小档案',
            'type'    => 'textarea',
            'default' => "坐标|杭州\n属性|INTJ\n星座|双鱼 ♓\n入坑|2013\n最爱|孤独摇滚\n语言|中文·日本語",
            'hint'    => '每行 标签|值',
        ),

        /* ============ 兴趣 ============ */
        array(
            'key'     => 'interests',
            'group'   => '兴趣',
            'label'   => '兴趣卡片',
            'type'    => 'textarea',
            'default' => "📺|动画 / 番剧|什么都看，特别偏爱日常系与乐队番。一部好番能让我快乐一整个星期。\n🎮|游戏|原神、星穹铁道常驻，偶尔手残地打打音游，然后被判定劝退。\n🎧|音乐|Anison 循环播放，City Pop 入眠，Live 现场会哭的那种人。\n🖌️|绘画|板绘爱好者，正在和人体结构搏斗（每天都在哭，但还在画）。",
            'hint'    => '每行 icon|标题|描述',
        ),

        /* ============ 作品 ============ */
        array(
            'key'     => 'show_works',
            'group'   => '作品',
            'label'   => '首页显示作品',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'work_title',
            'group'   => '作品',
            'label'   => '作品区标题',
            'type'    => 'text',
            'default' => '我的小作品',
        ),
        array(
            'key'     => 'work_source',
            'group'   => '作品',
            'label'   => '作品来源',
            'type'    => 'select',
            'default' => 'latest',
            'options' => array('latest' => '最新文章', 'category' => '指定分类'),
        ),
        array(
            'key'     => 'work_cat',
            'group'   => '作品',
            'label'   => '分类别名',
            'type'    => 'text',
            'default' => '',
            'hint'    => '来源选「指定分类」时填写分类别名（slug）',
        ),
        array(
            'key'     => 'work_count',
            'group'   => '作品',
            'label'   => '展示数量',
            'type'    => 'text',
            'default' => '6',
        ),

        /* ============ 追番清单 ============ */
        array(
            'key'     => 'show_anime',
            'group'   => '追番清单',
            'label'   => '首页显示追番',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'anime_title',
            'group'   => '追番清单',
            'label'   => '追番区标题',
            'type'    => 'text',
            'default' => '最近在追的番',
        ),
        array(
            'key'     => 'anime_list',
            'group'   => '追番清单',
            'label'   => '追番清单',
            'type'    => 'textarea',
            'default' => "🎸|孤独摇滚|后巷变身 · 社恐少女的乐队梦|已追完\n🌿|葬送的芙莉莲|旅程之后 · 关于时间与记忆|追更中\n🔥|链锯人|恶魔与少年 · 又燃又疯|已追完\n🏐|排球少年|补番进行中 · 热血到爆|补番中\n🕵️|间谍过家家|假一家人的日常 · 笑着笑着就暖了|追更中",
            'hint'    => '每行 emoji|标题|简介|状态（追更中 / 补番中 / 已追完）',
        ),

        /* ============ 导航与用户 ============ */
        array(
            'key'     => 'nav_menu',
            'group'   => '导航与用户',
            'label'   => '导航菜单',
            'type'    => 'textarea',
            'default' => "关于我|#about\n兴趣|#interest\n作品|#works\n追番|#anime\n友链|#friends\n留言|#contact",
            'hint'    => '每行 名称|链接（站内锚点用 #id，外链用完整 URL）',
        ),
        array(
            'key'     => 'show_search',
            'group'   => '导航与用户',
            'label'   => '显示搜索',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'show_rss',
            'group'   => '导航与用户',
            'label'   => '显示 RSS',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'show_theme_toggle',
            'group'   => '导航与用户',
            'label'   => '显示昼夜切换',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'show_friends',
            'group'   => '导航与用户',
            'label'   => '首页显示友链',
            'type'    => 'bool',
            'default' => '1',
        ),

        /* ============ 联系与社交 ============ */
        array(
            'key'     => 'contact_email',
            'group'   => '联系与社交',
            'label'   => '联系邮箱',
            'type'    => 'text',
            'default' => 'mio@example.com',
        ),
        array(
            'key'     => 'social_links',
            'group'   => '联系与社交',
            'label'   => '社交链接',
            'type'    => 'textarea',
            'default' => "Bilibili|https://space.bilibili.com/|📺\nPixiv|https://www.pixiv.net/|🎨\nTwitter / X|https://x.com/|🐦\n网易云音乐|https://music.163.com/|🎵",
            'hint'    => '每行 名称|链接|图标 emoji',
        ),
        array(
            'key'     => 'contact_note',
            'group'   => '联系与社交',
            'label'   => '联系区文案',
            'type'    => 'textarea',
            'default' => '想夸我、想安利番、或者只是路过打个招呼，都欢迎！',
        ),

        /* ============ 页脚与站点 ============ */
        array(
            'key'     => 'footer_motto',
            'group'   => '页脚与站点',
            'label'   => '页脚标语',
            'type'    => 'text',
            'default' => '用爱与星星搭起来的个人小站，欢迎常来玩。',
        ),
        array(
            'key'     => 'footer_menu',
            'group'   => '页脚与站点',
            'label'   => '页脚菜单',
            'type'    => 'textarea',
            'default' => "关于我|#about\n我的作品|#works\n追番清单|#anime\n友情链接|#friends\n留言板|#contact",
            'hint'    => '每行 名称|链接',
        ),
        array(
            'key'     => 'icp',
            'group'   => '页脚与站点',
            'label'   => '备案号',
            'type'    => 'text',
            'default' => '',
        ),
        array(
            'key'     => 'show_stats',
            'group'   => '页脚与站点',
            'label'   => '显示站点统计',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'run_from',
            'group'   => '页脚与站点',
            'label'   => '建站日期',
            'type'    => 'text',
            'default' => '2023-01-01',
            'hint'    => '用于计算「已运行 N 天」',
        ),
        array(
            'key'     => 'credit_on',
            'group'   => '页脚与站点',
            'label'   => '显示主题署名',
            'type'    => 'bool',
            'default' => '1',
        ),

        /* ============ SEO 与结构化数据 ============ */
        array(
            'key'     => 'seo_person',
            'group'   => 'SEO 与结构化数据',
            'label'   => '人物名（Person）',
            'type'    => 'text',
            'default' => '星野澪',
            'hint'    => '用于首页 ProfilePage + Person 结构化数据',
        ),
        array(
            'key'     => 'person_sameas',
            'group'   => 'SEO 与结构化数据',
            'label'   => '同身 / 社交主页',
            'type'    => 'textarea',
            'default' => "https://space.bilibili.com/\nhttps://www.pixiv.net/\nhttps://x.com/",
            'hint'    => '每行一个 URL，写入 Person.sameAs',
        ),
        array(
            'key'     => 'extra_head',
            'group'   => 'SEO 与结构化数据',
            'label'   => '自定义 head 代码',
            'type'    => 'textarea',
            'default' => '',
            'hint'    => '如统计、字体等，输出在 </head> 前',
        ),
        array(
            'key'     => 'extra_foot',
            'group'   => 'SEO 与结构化数据',
            'label'   => '自定义 foot 代码',
            'type'    => 'textarea',
            'default' => '',
            'hint'    => '如客服、脚本，输出在 </body> 前',
        ),

        /* ============ 文章、评论与页面 ============ */
        array(
            'key'     => 'list_style',
            'group'   => '文章、评论与页面',
            'label'   => '列表样式',
            'type'    => 'select',
            'default' => 'card',
            'options' => array('card' => '卡片网格', 'list' => '图文列表'),
        ),
        array(
            'key'     => 'show_cover',
            'group'   => '文章、评论与页面',
            'label'   => '列表显示封面',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'show_excerpt',
            'group'   => '文章、评论与页面',
            'label'   => '列表显示摘要',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'show_toc',
            'group'   => '文章、评论与页面',
            'label'   => '文章显示目录',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'show_tags',
            'group'   => '文章、评论与页面',
            'label'   => '文章显示标签',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'show_copyright',
            'group'   => '文章、评论与页面',
            'label'   => '文章显示版权',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'copyright_text',
            'group'   => '文章、评论与页面',
            'label'   => '版权声明',
            'type'    => 'text',
            'default' => '未经授权禁止转载，转载请联系作者并注明出处。',
        ),
        array(
            'key'     => 'show_comments',
            'group'   => '文章、评论与页面',
            'label'   => '开启评论',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'reading_width',
            'group'   => '文章、评论与页面',
            'label'   => '正文字宽',
            'type'    => 'select',
            'default' => 'comfortable',
            'options' => array('comfortable' => '舒适（约 64ch）', 'wide' => '宽松（约 72ch）'),
        ),

        /* ============ 功能与动效 ============ */
        array(
            'key'     => 'motion_on',
            'group'   => '功能与动效',
            'label'   => '入场动画',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'progress_bar',
            'group'   => '功能与动效',
            'label'   => '阅读进度条',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'back_top',
            'group'   => '功能与动效',
            'label'   => '回到顶部',
            'type'    => 'bool',
            'default' => '1',
        ),
        array(
            'key'     => 'lazy_on',
            'group'   => '功能与动效',
            'label'   => '图片懒加载',
            'type'    => 'bool',
            'default' => '1',
        ),
    ),
);
