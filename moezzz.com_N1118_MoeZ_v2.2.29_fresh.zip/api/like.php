<?php
/**
 * MoeZ · 文章点赞接口（/like.php，2.1.2）
 * ------------------------------------------------------------
 * POST pid=文章ID
 * 行为：点赞 / 再点一次取消（切换式），同一访客同一篇文章只记一票：
 *   - 会话里记一份（登录 / 同会话防刷）
 *   - Cookie 里记一份（关浏览器后再来也不会重复加一，有效期 1 年）
 * 返回 JSON：{ok:1, likes:N, liked:1/0}
 * 不依赖伪静态规则，主题 JS 直接 POST 这个地址即可。
 */
if (!defined('MOE_ROOT')) {
    require dirname(__DIR__) . '/init.php';
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(405);
    exit(json_encode(array('ok' => 0, 'msg' => 'method not allowed')));
}

/* CSRF：评论表单里都带令牌，缺失 / 不对直接 403（防外站刷赞） */
if (function_exists('csrf_verify')) {
    csrf_verify();
}

$pid = isset($_POST['pid']) ? (int)$_POST['pid'] : (isset($_POST['id']) ? (int)$_POST['id'] : 0);

header('Content-Type: application/json; charset=utf-8');

if ($pid <= 0) {
    http_response_code(400);
    exit(json_encode(array('ok' => 0, 'msg' => '参数错误')));
}

try {
    $post = row('SELECT id, likes FROM ' . moe_table('posts') . " WHERE id = ? AND type = 'post' AND status = 'published'", array($pid));
    if (!$post) {
        http_response_code(404);
        exit(json_encode(array('ok' => 0, 'msg' => '文章不存在')));
    }

    /* 已点过 = 会话标记或 Cookie 标记 */
    if (!isset($_SESSION['moe_liked']) || !is_array($_SESSION['moe_liked'])) $_SESSION['moe_liked'] = array();
    $ckName = 'moe_like_' . $pid;
    $liked  = !empty($_SESSION['moe_liked'][$pid]) || (isset($_COOKIE[$ckName]) && $_COOKIE[$ckName] === '1');

    $likes = (int)$post['likes'];
    if ($liked) {
        /* 取消点赞：扣回一票，最低 0 */
        $likes = max(0, $likes - 1);
        q('UPDATE ' . moe_table('posts') . ' SET likes = ? WHERE id = ?', array($likes, $pid));
        unset($_SESSION['moe_liked'][$pid]);
        @setcookie($ckName, '', time() - 3600, '/');
        exit(json_encode(array('ok' => 1, 'likes' => $likes, 'liked' => 0)));
    }

    /* 点赞 */
    $likes = $likes + 1;
    q('UPDATE ' . moe_table('posts') . ' SET likes = ? WHERE id = ?', array($likes, $pid));
    $_SESSION['moe_liked'][$pid] = 1;
    if (!headers_sent()) {
        @setcookie($ckName, '1', time() + 86400 * 365, '/', '', false, true);
    }
    exit(json_encode(array('ok' => 1, 'likes' => $likes, 'liked' => 1)));
} catch (Throwable $e) {
    http_response_code(500);
    exit(json_encode(array('ok' => 0, 'msg' => '点赞失败，请稍后再试')));
}
