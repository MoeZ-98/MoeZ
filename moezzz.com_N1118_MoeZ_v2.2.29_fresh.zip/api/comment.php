<?php
/**
 * MoeZ - 前台评论提交处理
 */
require dirname(__DIR__) . '/init.php';

// IP 归属地 / UA 解析（缺失文件时静默降级，不影响评论提交）
if (is_file(dirname(__DIR__) . '/includes/ipinfo.php')) {
    require_once dirname(__DIR__) . '/includes/ipinfo.php';
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect(u());

$site_url = u(); // for redirect back
$post_id = isset($_POST['post_id']) ? (int)$_POST['post_id'] : 0;

if (setting('comment_enabled', '1') !== '1') {
    json_exit(false, '本站未开放评论');
}

csrf_verify();

$author  = trim($_POST['author'] ?? '');
$email   = trim($_POST['email'] ?? '');
$content = trim($_POST['content'] ?? '');

// 2.0.0：登录用户（站长 / 作者 / 会员）留空时自动带出自己的昵称与邮箱，并记录评论归属
$__uid = 0;
if (function_exists('moe_comment_defaults')) {
    $__cdf = moe_comment_defaults();
    if (!empty($__cdf['admin'])) {
        if ($author === '')  $author = $__cdf['author'];
        if ($email === '')   $email  = $__cdf['email'];
        $__uid = (int)($__cdf['user_id'] ?? 0);
    }
}

// 2.0.0：可选的「仅登录用户可评论」
if (setting('user_comment_login', '0') === '1' && $__uid === 0) {
    json_exit(false, '请先登录后再发表评论（页面左下角有「登录 / 注册」入口）');
}

if ($author === '' || $content === '') json_exit(false, '昵称和评论内容不能为空');
if (mb_strlen($author) > 30) json_exit(false, '昵称太长啦');
if (mb_strlen($content) > 1000) json_exit(false, '评论内容最多 1000 字');
if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) json_exit(false, '邮箱格式不正确');

$post = row('SELECT id FROM ' . moe_table('posts') . " WHERE id = ? AND type='post' AND status='published'", array($post_id));
if (!$post) json_exit(false, '文章不存在');

// 简单防灌水：60 秒内同一会话只能发一条
if (!empty($_SESSION['moe_last_comment']) && time() - (int)$_SESSION['moe_last_comment'] < 60) {
    json_exit(false, '评论太快啦，喝口水休息一下~');
}

// 归属地 + 系统·浏览器（解析失败不影响提交）
$ip  = $_SERVER['REMOTE_ADDR'] ?? '';
$ua  = isset($_SERVER['HTTP_USER_AGENT']) ? mb_substr((string)$_SERVER['HTTP_USER_AGENT'], 0, 255, 'UTF-8') : '';
$loc = function_exists('moe_ip_location') ? moe_ip_location($ip) : '';

// 老站点若尚未补齐 user_id 字段则自动回落，不影响评论提交
try {
    q('INSERT INTO ' . moe_table('comments') . ' (post_id,author,email,content,status,ip,ua,location,user_id,created_at) VALUES (?,?,?,?,?,?,?,?,?,NOW())',
        array($post_id, $author, $email, $content, 'approved', $ip, $ua, $loc, $__uid));
} catch (Throwable $e) {
    q('INSERT INTO ' . moe_table('comments') . ' (post_id,author,email,content,status,ip,ua,location,created_at) VALUES (?,?,?,?,?,?,?,?,NOW())',
        array($post_id, $author, $email, $content, 'approved', $ip, $ua, $loc));
}
$_SESSION['moe_last_comment'] = time();

/* 2.1.0：登录用户发表评论得积分（每日上限由后台设置；同一条评论只发一次） */
$__ptMsg = '';
$__ptExtra = array();
if ($__uid > 0 && function_exists('moe_pt_comment_grant')) {
    $__newCid = (int)last_id();
    $__grant = moe_pt_comment_grant($__uid, $__newCid);
    if (!empty($__grant['ok'])) {
        $__ptMsg = ' ' . (string)$__grant['msg'];
        $__ptExtra = array('points' => (int)$__grant['points'], 'balance' => (int)$__grant['balance']);
    }
}

// 1.9.0：新评论 → 统计缓存与页面缓存立即刷新（否则最多 2 分钟才看到新评论）
if (function_exists('moe_content_changed')) moe_content_changed();

// 评论直接通过展示：按后台开关给评论者发通知邮件（需评论者留了邮箱）
$postFull = row('SELECT title, id, slug FROM ' . moe_table('posts') . ' WHERE id = ?', array($post_id));
if ($postFull && function_exists('moe_notify_comment_result')) {
    $postUrl = function_exists('post_url') ? post_url(array('id' => $postFull['id'], 'slug' => isset($postFull['slug']) ? $postFull['slug'] : '')) : base_url();
    moe_notify_comment_result($author, $email, (string)$postFull['title'], $postUrl, $content);
}

json_exit(true, '评论发布成功！' . $__ptMsg, $__ptExtra);
