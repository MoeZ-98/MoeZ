<?php
/**
 * 前台 · UEditorPlus 上传服务端（会员投稿用，2.2.22）
 * ------------------------------------------------------------
 * 协议与 admin/ueditor-server.php 相同，但放行所有已登录用户；
 * 上传规则与 api/upload.php 对齐（白名单 / 10MB 图片 / upload_max_mb 附件 / 40 次/天）。
 * 2.2.30 工程化：命名与落盘统一走 includes/upload.php，投稿来源改由数据库记录归属，
 *        不再往文件名里塞 ct{uid}_ 前缀（全站无任何代码依赖该前缀）。
 */
require dirname(__DIR__) . '/init.php';
require_once dirname(__DIR__) . '/includes/upload.php';

if (session_status() === PHP_SESSION_NONE) session_start();
$t = (string)($_REQUEST['_token'] ?? '');
if ($t === '' || !hash_equals((string)($_SESSION['moe_csrf'] ?? ''), $t)) {
    ue2_out(array('state' => '令牌校验失败，请刷新页面重试'));
}
$u = current_user();
if (!$u) ue2_out(array('state' => '请先登录后再投稿'));

function ue2_out($payload) { echo json_encode($payload, JSON_UNESCAPED_UNICODE); exit; }

header('Content-Type: application/json; charset=utf-8');

$IMG = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'avif');
$VID = array('mp4', 'webm', 'm4v');
$ATT = array('zip', 'rar', '7z', 'tar', 'gz', 'pdf', 'txt', 'md', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'epub', 'mp3', 'wav', 'flac', 'ogg', 'm4a', 'aac');

$action = (string)($_GET['action'] ?? ($_POST['action'] ?? ''));

if ($action === 'config') {
    $maxBytes = max(1, (int)setting('upload_max_mb', 50)) * 1024 * 1024;
    ue2_out(array(
        'state' => 'SUCCESS',
        'imageActionName' => 'uploadimage', 'imageFieldName' => 'upfile', 'imageMaxSize' => 10 * 1024 * 1024,
        'imageAllowFiles' => array_values(preg_replace('/^([^\.]+)/', '.$1', $IMG)),
        'imageInsertAlign' => 'none', 'imageUrlPrefix' => '',
        'videoActionName' => 'uploadvideo', 'videoFieldName' => 'upfile', 'videoMaxSize' => $maxBytes,
        'videoAllowFiles' => array_values(preg_replace('/^([^\.]+)/', '.$1', $VID)),
        'fileActionName' => 'uploadfile', 'fileFieldName' => 'upfile', 'fileMaxSize' => $maxBytes,
        'fileAllowFiles' => array_values(preg_replace('/^([^\.]+)/', '.$1', $ATT)),
    ));
}

if (!in_array($action, array('uploadimage', 'uploadvideo', 'uploadfile'), true)) {
    ue2_out(array('state' => '不支持的操作：' . $action));
}

$uid = (int)$u['id'];
$key = 'moe_ct_up_' . $uid . '_' . date('Ymd');
$cnt = (int)($_SESSION[$key] ?? 0);
if ($cnt >= 40) ue2_out(array('state' => '今天的上传次数已达上限（40 次/天）'));

$allow = $action === 'uploadimage' ? $IMG : ($action === 'uploadvideo' ? $VID : $ATT);
if (empty($_FILES['upfile'])) ue2_out(array('state' => '没有收到文件'));
$f = $_FILES['upfile'];
if ($f['error'] !== UPLOAD_ERR_OK) ue2_out(array('state' => '上传出错（代码 ' . $f['error'] . '）'));

$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
if (!in_array($ext, $allow, true)) ue2_out(array('state' => '不支持 .' . $ext . ' 文件'));
$maxMb = $action === 'uploadimage' ? 10 : max(1, (int)setting('upload_max_mb', 50));
if ($f['size'] > $maxMb * 1024 * 1024) ue2_out(array('state' => '文件超过 ' . $maxMb . 'MB 限制'));
if (in_array($ext, array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp'), true)) {
    if (@getimagesize($f['tmp_name']) === false) ue2_out(array('state' => '文件不是有效的图片'));
}

/* 统一服务：真实 MIME / SVG 脚本扫描 + 按 YYYYMM 归档 + 原名/数字编号命名 + 落盘 */
$bad = moe_up_check($f, $ext, $action === 'uploadimage');
if ($bad !== '') ue2_out(array('state' => $bad));

$sub = $action === 'uploadvideo' ? 'video' : ($action === 'uploadimage' ? 'image' : 'file');
$res = moe_up_store($f, $sub, $f['name'], $ext);
if (!$res['ok']) ue2_out(array('state' => $res['msg']));

$_SESSION[$key] = $cnt + 1;

ue2_out(array(
    'state' => 'SUCCESS',
    'url' => $res['url'],
    'title' => $res['stem'], 'original' => $res['stem'],
    'size' => (int)$f['size'], 'type' => '.' . $ext,
));
