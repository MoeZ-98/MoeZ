<?php
/**
 * 前台 · 会员投稿上传接口（2.2.22）
 * ------------------------------------------------------------
 * 登录用户在「用户中心 → 投稿」上传封面图 / 正文配图 / 资源附件。
 * - 图片：jpg/jpeg/png/gif/webp/bmp ≤ 10MB，保存到 uploads/image/
 * - 附件：zip/rar/7z/tar/gz/pdf/txt/md/doc/docx/xls/xlsx/ppt/pptx/epub/mp3/wav/mp4/webm 等 ≤ upload_max_mb（默认 50MB），保存到 uploads/file/
 * - 限频：每用户每天最多 40 次
 * CSRF 走 X-CSRF-Token 请求头。
 * 2.2.30 工程化：命名与落盘统一走 includes/upload.php，投稿来源改由数据库记录归属，
 *        不再往文件名里塞 ct{uid}_ 前缀（全站无任何代码依赖该前缀）。
 */
require dirname(__DIR__) . '/init.php';
require_once dirname(__DIR__) . '/includes/upload.php';

header('Content-Type: application/json; charset=utf-8');

function ct_fail($msg) { echo json_encode(array('ok' => 0, 'msg' => $msg), JSON_UNESCAPED_UNICODE); exit; }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') ct_fail('请求方式不正确');
if (session_status() === PHP_SESSION_NONE) session_start();
$token = (string)($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['_token'] ?? ''));
if ($token === '' || !hash_equals((string)($_SESSION['moe_csrf'] ?? ''), $token)) ct_fail('令牌校验失败，请刷新页面重试');
$u = current_user();
if (!$u) ct_fail('请先登录');
$uid = (int)$u['id'];

/* 每日限频：防止滥用上传空间 */
$key = 'moe_ct_up_' . $uid . '_' . date('Ymd');
$cnt = (int)($_SESSION[$key] ?? 0);
if ($cnt >= 40) ct_fail('今天的上传次数已达上限（40 次/天），明天再来吧');
if (empty($_FILES['file'])) ct_fail('没有收到文件');
$f = $_FILES['file'];
if ($f['error'] === UPLOAD_ERR_INI_SIZE) ct_fail('文件超过服务器 PHP 限制（upload_max_filesize）');
if ($f['error'] !== UPLOAD_ERR_OK)       ct_fail('上传出错（代码 ' . $f['error'] . '）');

$IMG = array('jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'avif');
$ATT = array('zip', 'rar', '7z', 'tar', 'gz', 'pdf', 'txt', 'md', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'epub', 'mp3', 'wav', 'flac', 'ogg', 'm4a', 'aac', 'mp4', 'webm', 'm4v');

$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
$isImg = in_array($ext, $IMG, true);
$isAtt = in_array($ext, $ATT, true);
if (!$isImg && !$isAtt) ct_fail('不支持 .' . $ext . '：图片支持 jpg/png/gif/webp/bmp/avif，附件支持 zip/rar/7z/tar/gz/pdf/txt/md/doc/docx/xls/xlsx/ppt/pptx/epub/音频/视频');

$maxMb = $isImg ? 10 : max(1, (int)setting('upload_max_mb', 50));
if ($f['size'] > $maxMb * 1024 * 1024) ct_fail('文件超过 ' . $maxMb . 'MB 限制');

if ($isImg && $ext !== 'svg') {
    $info = @getimagesize($f['tmp_name']);
    if ($info === false) ct_fail('文件不是有效的图片');
}

/* 统一服务：真实 MIME / SVG 脚本扫描 + 按 YYYYMM 归档 + 原名/数字编号命名 + 落盘 */
$bad = moe_up_check($f, $ext, $isImg);
if ($bad !== '') ct_fail($bad);

$sub = $isImg ? 'image' : 'file';
$res = moe_up_store($f, $sub, $f['name'], $ext);
if (!$res['ok']) ct_fail($res['msg']);

$_SESSION[$key] = $cnt + 1;
echo json_encode(array('ok' => 1, 'url' => $res['url'],
                       'name' => $f['name'], 'size' => (int)$f['size']), JSON_UNESCAPED_UNICODE);
