<?php
/**
 * MoeZ · 看板娘聊天接口（/chat.php，2.1.18）
 * ------------------------------------------------------------
 * POST q=消息内容
 *      title=访客当前页面标题（可选）  url=当前地址（可选）
 *      reset=1 清空对话记忆（可选）
 * 返回 JSON：{ok:1, text:回复, links:[{t:标题,u:链接}], chips:[[显示,发送]], src:'ai|web|local'}
 * 安全：仅 POST + CSRF（X-CSRF-Token）+ 每分钟 20 条频率限制；纯只读、不改任何数据。
 * 2.1.18：接大模型（含联网搜索）+ 多轮记忆；未配置密钥时自动退回站内引擎。
 */
if (!defined('MOE_ROOT')) {
    require dirname(__DIR__) . '/init.php';
}

header('Content-Type: application/json; charset=utf-8');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    http_response_code(405);
    exit(json_encode(array('ok' => 0, 'msg' => 'method not allowed')));
}

/* CSRF：与点赞接口同款令牌（前端从页面 data-token 读取） */
if (function_exists('csrf_ajax')) {
    csrf_ajax();
}

/* 大模型可能要十几秒，给足执行时间 */
@set_time_limit(50);
@ini_set('default_socket_timeout', '30');

/* 清空对话记忆 */
if (!empty($_POST['reset'])) {
    if (function_exists('moe_chat_hist_clear')) moe_chat_hist_clear();
    if (function_exists('moe_chat_mem_clear')) moe_chat_mem_clear(array('cid' => (string)($_POST['cid'] ?? '')));
    exit(json_encode(array('ok' => 1, 'text' => '', 'links' => array(), 'chips' => array(), 'src' => 'local'), JSON_UNESCAPED_UNICODE));
}

/* 频率限制：同一会话每分钟最多 20 条 */
$now = time();
if (!isset($_SESSION['moe_chat_t']) || !is_array($_SESSION['moe_chat_t'])) {
    $_SESSION['moe_chat_t'] = array();
}
$_SESSION['moe_chat_t'] = array_values(array_filter($_SESSION['moe_chat_t'], function ($t) use ($now) {
    return $t > $now - 60;
}));
if (count($_SESSION['moe_chat_t']) >= 20) {
    exit(json_encode(array('ok' => 0, 'msg' => '聊得有点快，让我喘口气，一分钟后再来～')));
}

$q = trim((string)($_POST['q'] ?? ''));
if ($q === '') {
    exit(json_encode(array('ok' => 0, 'msg' => '说点什么吧～')));
}

/* 当前页面上下文：让「这一页讲什么」这类问题也能答；cid 是访客长期记忆的钥匙 */
$ctx = array(
    'title' => function_exists('mb_substr') ? mb_substr(trim((string)($_POST['title'] ?? '')), 0, 80, 'UTF-8') : substr(trim((string)($_POST['title'] ?? '')), 0, 240),
    'url'   => substr(trim((string)($_POST['url'] ?? '')), 0, 200),
    'cid'   => substr(preg_replace('/[^A-Za-z0-9_-]/', '', (string)($_POST['cid'] ?? '')), 0, 64),
);

try {
    $r = moe_chat_reply($q, $ctx);
} catch (Throwable $e) {
    $r = array('text' => '唔…我刚刚走神了，再说一遍好不好？', 'links' => array(), 'chips' => array(), 'src' => 'local');
}

$_SESSION['moe_chat_t'][] = $now;

exit(json_encode(
    array('ok' => 1)
    + array(
        'text'    => (string)($r['text'] ?? ''),
        'links'   => array_values((array)($r['links'] ?? array())),
        'chips'   => array_values((array)($r['chips'] ?? array())),
        'actions' => array_values((array)($r['actions'] ?? array())),
        'src'     => (string)($r['src'] ?? 'local'),
    ),
    JSON_UNESCAPED_UNICODE
));
