<?php
/**
 * MoeZ - 前台友链申请
 * 提交时自动抓取站点名称，并检测对方是否已添加本站链接：
 *   已加  → 自动审核通过并展示
 *   未加  → 转人工审核（后台「友情链接」里处理）
 */
require dirname(__DIR__) . '/init.php';

// 1.6.5 兜底：确保 links 表有 logo / description 字段
if (function_exists('moe_ensure_links_columns')) moe_ensure_links_columns();

if (!function_exists('moe_check_backlink') && is_file(dirname(__DIR__) . '/includes/linkcheck.php')) {
    require_once dirname(__DIR__) . '/includes/linkcheck.php';
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect(u());

csrf_verify();
@set_time_limit(30);

$name    = trim($_POST['name'] ?? '');
$url     = trim($_POST['url'] ?? '');
$contact = trim($_POST['contact'] ?? '');

if ($url === '') json_exit(false, '请填写你的站点地址');
if (!preg_match('#^https?://#i', $url)) $url = 'https://' . ltrim($url, '/');
if (!filter_var($url, FILTER_VALIDATE_URL)) json_exit(false, '站点地址格式不正确');
if (mb_strlen($contact) > 60) json_exit(false, '联系方式太长啦');

// 同域名防重复
$host = moe_url_host($url);
if ($host === '') json_exit(false, '站点地址格式不正确');
try {
    $exists = rows('SELECT name, status FROM ' . moe_table('links'));
    foreach ((array)$exists as $l) {
        if (moe_url_host($l['url']) === $host) {
            $st = $l['status'] === 'approved' ? '已在友链列表中展示' : '已在待审核列表中，等待站长处理';
            json_exit(false, '「' . $l['name'] . '」' . $st . '，请勿重复提交');
        }
    }
} catch (Throwable $e) { /* 表未升级时忽略 */ }

// 自动获取站点名称 + 回链检测
$check = moe_check_backlink($url);
if ($name === '') $name = $check['title'] !== '' ? $check['title'] : $host;
if (mb_strlen($name) > 60) $name = mb_substr($name, 0, 60, 'UTF-8');

$autoOk = $check['ok'];
$status = $autoOk ? 'approved' : 'pending';

// 图标 / 描述：优先抓取对方页面，抓不到则用 /favicon.ico 兜底
$logo = !empty($check['icon']) ? $check['icon'] : '';
$desc = !empty($check['desc']) ? $check['desc'] : '';

q('INSERT INTO ' . moe_table('links') . ' (name,url,logo,description,contact,status,check_result,last_check,sort,created_at)
   VALUES (?,?,?,?,?,?,?,?,0,NOW())',
    array($name, $url, $logo, $desc, $contact, $status, $check['msg'], date('Y-m-d H:i:s')));

if ($autoOk) {
    // 自动审批通过：按后台开关给申请者发通知邮件（联系方式里提取邮箱）
    if (function_exists('moe_notify_link_result')) {
        moe_notify_link_result($name, $url, true, $contact);
    }
    json_exit(true, '检测到你已添加本站链接，友链「' . $name . '」已自动通过并展示 🎉');
}
json_exit(true, '未检测到本站链接（可能被 JS 动态渲染），申请已提交，站长会尽快人工审核～');
