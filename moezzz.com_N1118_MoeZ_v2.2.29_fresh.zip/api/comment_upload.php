<?php
/**
 * MoeZ - 前台评论图片上传
 * 仅接收图片（jpg/png/gif/webp），保存到 uploads/image/YYYYMM/，返回 URL
 * 用于模板评论框插入 [img]图片地址[/img]，展示端由模板负责渲染
 * 2.2.30 工程化：命名与落盘统一走 includes/upload.php，并保留原文件名供媒体库显示。
 */
require dirname(__DIR__) . '/init.php';
require_once dirname(__DIR__) . '/includes/upload.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') redirect(u());

header('Content-Type: application/json; charset=utf-8');

if (setting('comment_enabled', '1') !== '1') {
    json_exit(false, '本站未开放评论');
}

csrf_verify();

/* 限频：15 秒内同一会话只允许上传一张，防止刷图 */
if (!empty($_SESSION['moe_last_cupload']) && time() - (int)$_SESSION['moe_last_cupload'] < 15) {
    json_exit(false, '上传太频繁啦，稍等几秒再试');
}

if (empty($_FILES['file'])) json_exit(false, '没有收到文件');
$f = $_FILES['file'];

if ($f['error'] === UPLOAD_ERR_INI_SIZE) json_exit(false, '图片超过服务器 PHP 限制');
if ($f['error'] !== UPLOAD_ERR_OK)       json_exit(false, '上传出错（代码 ' . $f['error'] . '）');

/* 仅图片类型 */
$IMG = array('jpg', 'jpeg', 'png', 'gif', 'webp');
$ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
if (!in_array($ext, $IMG, true)) json_exit(false, '仅支持 jpg/png/gif/webp 图片');

/* 大小限制：评论图最大 5MB（同时不超过后台 upload_max_mb 设置） */
$maxMb = (int)setting('upload_max_mb', 5);
if ($maxMb < 1) $maxMb = 1;
$maxMb = min(5, $maxMb);
if ($f['size'] > $maxMb * 1024 * 1024) json_exit(false, '图片超过 ' . $maxMb . 'MB 限制');

/* 真实图片内容校验，防止伪装文件 */
if (@getimagesize($f['tmp_name']) === false) json_exit(false, '文件不是有效的图片');

/* 统一服务：真实 MIME + 按 YYYYMM 归档 + 原名/数字编号命名 + 落盘 */
$bad = moe_up_check($f, $ext, true);
if ($bad !== '') json_exit(false, $bad);

$res = moe_up_store($f, 'image', $f['name'], $ext);
if (!$res['ok']) json_exit(false, $res['msg']);

$_SESSION['moe_last_cupload'] = time();

json_exit(true, '上传成功', array(
    'url'  => $res['url'],
    'name' => $res['name'],
    'type' => 'image',
));
