<?php
/**
 * MoeZ · 资源下载入口（/download.php?g=资源ID）
 * ------------------------------------------------------------
 * 主要入口是 /download/{id}（由 index.php 路由到 includes/points.php），
 * 这个文件给「直接访问下载脚本」的老链接 / 收藏夹留一个兼容入口。
 * 下载前会校验：登录状态 + 是否已用积分兑换 + 资源是否上架
 * （校验通过才记录一次下载并跳转 / 流式输出文件）。
 */
if (!defined('MOE_ROOT')) {
    require dirname(__DIR__) . '/init.php';
}

$__gid = isset($_GET['g']) ? (int)$_GET['g'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

if (function_exists('moe_pt_download_serve')) {
    moe_pt_download_serve($__gid);
}

http_response_code(500);
header('Content-Type: text/html; charset=utf-8');
exit('积分模块缺失：请重新上传 includes/points.php');
