<?php
/**
 * MoeZ - SMTP 邮件模块（1.8.0）
 * 纯 PHP 实现 SMTP 发信（支持 SSL / STARTTLS / AUTH LOGIN），
 * 不依赖外部类库。配置见 后台 → 站点设置 → 邮箱与登录。
 *
 * 邮件通知：友链审批结果 / 评论审核结果（均可在后台单独开关）
 */

if (!defined('MOE_ROOT')) exit;

/**
 * 邮件配置是否就绪（已启用且关键项已填）
 */
function moe_mail_ready()
{
    if (setting('smtp_enabled', '0') !== '1') return false;
    return setting('smtp_host', '') !== ''
        && setting('smtp_user', '') !== ''
        && setting('smtp_pass', '') !== '';
}

/**
 * 发件人地址（默认用 SMTP 账号；多数服务商要求发件人=认证账号）
 */
function moe_mail_from()
{
    $from = trim((string)setting('smtp_from', ''));
    if ($from !== '' && filter_var($from, FILTER_VALIDATE_EMAIL)) return $from;
    return (string)setting('smtp_user', '');
}

/**
 * 发件人显示名（默认站点名）
 */
function moe_mail_from_name()
{
    $n = trim((string)setting('smtp_from_name', ''));
    return $n !== '' ? $n : (trim((string)setting('site_name', '')) ?: 'MoeZ');
}

/**
 * 统一 HTML 邮件模板（粉紫渐变风格，与站点一致）
 */
function moe_mail_template($title, $lines, $btnText = '', $btnUrl = '')
{
    $site  = moe_mail_from_name();
    $home  = base_url();
    $btn = '';
    if ($btnText !== '' && $btnUrl !== '') {
        $btn = '<a href="' . htmlspecialchars($btnUrl, ENT_QUOTES, 'UTF-8') . '" '
             . 'style="display:inline-block;padding:11px 26px;border-radius:999px;'
             . 'background:linear-gradient(135deg,#ff7eb3,#a18cd1);color:#fff;text-decoration:none;'
             . 'font-size:14px;font-weight:600;margin:6px 0 4px">' . htmlspecialchars($btnText, ENT_QUOTES, 'UTF-8') . '</a>';
    }
    $body = '';
    foreach ((array)$lines as $ln) {
        if ($ln === '') { $body .= '<div style="height:10px"></div>'; continue; }
        $body .= '<p style="margin:6px 0;font-size:14px;line-height:1.8;color:#54496b">'
               . $ln . '</p>';
    }
    return '<!DOCTYPE html><html><body style="margin:0;padding:0;background:#f4f1f9">'
        . '<div style="max-width:520px;margin:0 auto;padding:28px 16px;font-family:-apple-system,\'PingFang SC\',\'Microsoft YaHei\',sans-serif">'
        . '<div style="border-radius:20px;overflow:hidden;background:#fff;box-shadow:0 10px 40px rgba(146,120,200,.18)">'
        . '<div style="padding:22px 30px;background:linear-gradient(135deg,#fff1f4,#f3f0ff)">'
        . '<div style="font-size:18px;font-weight:700;color:#54496b">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</div>'
        . '<div style="font-size:12px;color:#9a8fae;margin-top:4px">' . htmlspecialchars($site, ENT_QUOTES, 'UTF-8') . '</div>'
        . '</div>'
        . '<div style="padding:22px 30px 6px">' . $body
        . ($btn !== '' ? '<div style="margin:14px 0 6px">' . $btn . '</div>' : '')
        . '</div>'
        . '<div style="padding:14px 30px 22px;border-top:1px dashed #eee6f6">'
        . '<p style="margin:0;font-size:12px;color:#b3aac5">此邮件由 <a href="' . htmlspecialchars($home, ENT_QUOTES, 'UTF-8') . '" style="color:#a18cd1;text-decoration:none">' . htmlspecialchars($site, ENT_QUOTES, 'UTF-8') . '</a> 自动发送，请勿直接回复。</p>'
        . '</div>'
        . '</div></div></body></html>';
}

/**
 * SMTP 发送（阻塞，失败返回错误信息，不抛异常）
 * @return array('ok'=>bool, 'msg'=>string)
 */
function moe_mail_send($to, $subject, $html)
{
    if (!filter_var($to, FILTER_VALIDATE_EMAIL)) {
        return array('ok' => false, 'msg' => '收件邮箱格式不正确');
    }
    $host   = trim((string)setting('smtp_host', ''));
    $port   = (int)setting('smtp_port', '465');
    if ($port < 1 || $port > 65535) $port = 465;
    $secure = (string)setting('smtp_secure', 'ssl');   // ssl | tls | none
    $user   = (string)setting('smtp_user', '');
    $pass   = (string)setting('smtp_pass', '');
    $from   = moe_mail_from();
    $fromNm = moe_mail_from_name();

    if ($host === '' || $user === '' || $pass === '' || !filter_var($from, FILTER_VALIDATE_EMAIL)) {
        return array('ok' => false, 'msg' => 'SMTP 未配置完整（主机 / 账号 / 密码 / 发件人）');
    }

    $timeout = 12;
    $errNo = 0; $errStr = '';
    $remote = ($secure === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port;
    $fp = @stream_socket_client($remote, $errNo, $errStr, $timeout);
    if (!$fp) {
        return array('ok' => false, 'msg' => '连接 SMTP 服务器失败：' . ($errStr !== '' ? $errStr : ('errno ' . $errNo)));
    }
    stream_set_timeout($fp, $timeout);

    // --- 读取 + 命令的小工具 ---
    $lastCode = '000';
    $read = function () use ($fp, &$lastCode) {
        $data = '';
        while (($line = fgets($fp, 1024)) !== false) {
            $data .= $line;
            if (isset($line[3]) && $line[3] === ' ') break;   // 末行形如 "250 ..." 后跟空格
        }
        $lastCode = trim(substr($data, 0, 3));
        return array($lastCode, $data);
    };
    $cmd = function ($c) use ($fp, $read) {
        fwrite($fp, $c . "\r\n");
        return $read();
    };

    try {
        list($code) = $read();                                   // 220 greeting
        if ($code !== '220') throw new RuntimeException('服务器欢迎信息异常：' . $code);
        list($code,) = $cmd('EHLO moe-home');                    // EHLO
        if ($code !== '250') throw new RuntimeException('EHLO 被拒绝：' . $code);

        if ($secure === 'tls') {                                 // STARTTLS 明文升级加密
            list($code,) = $cmd('STARTTLS');
            if ($code !== '220') throw new RuntimeException('STARTTLS 失败：' . $code);
            if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                throw new RuntimeException('TLS 加密握手失败（可尝试改用 SSL 端口 465）');
            }
            list($code,) = $cmd('EHLO moe-home');
            if ($code !== '250') throw new RuntimeException('TLS 后 EHLO 被拒绝：' . $code);
        }

        list($code,) = $cmd('AUTH LOGIN');
        if ($code !== '334') throw new RuntimeException('服务器不支持 AUTH LOGIN：' . $code);
        list($code,) = $cmd(base64_encode($user));
        if ($code !== '334') throw new RuntimeException('SMTP 账号被拒绝（检查用户名）：' . $code);
        list($code,) = $cmd(base64_encode($pass));
        if ($code !== '235') throw new RuntimeException('SMTP 密码错误或需要授权码（QQ/163 邮箱要用「授权码」而不是登录密码）：' . $code);

        list($code,) = $cmd('MAIL FROM:<' . $from . '>');
        if ($code !== '250') throw new RuntimeException('MAIL FROM 被拒绝：' . $code);
        list($code,) = $cmd('RCPT TO:<' . $to . '>');
        if ($code !== '250' && $code !== '251') throw new RuntimeException('收件地址被拒绝：' . $code);
        list($code,) = $cmd('DATA');
        if ($code !== '354') throw new RuntimeException('DATA 被拒绝：' . $code);

        // --- 邮件头 + 正文 ---
        $subj = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        $fnm  = '=?UTF-8?B?' . base64_encode($fromNm) . '?=';
        $hdr  = 'From: ' . $fnm . ' <' . $from . '>' . "\r\n"
              . 'To: <' . $to . '>' . "\r\n"
              . 'Subject: ' . $subj . "\r\n"
              . 'Date: ' . date('r') . "\r\n"
              . 'MIME-Version: 1.0' . "\r\n"
              . 'Content-Type: text/html; charset=UTF-8' . "\r\n"
              . 'Content-Transfer-Encoding: base64' . "\r\n"
              . 'X-Mailer: MoeZ/' . MOE_VERSION . "\r\n\r\n";
        $body = chunk_split(base64_encode($html));
        // DATA 内容里独行 "." 表示结束，需转义
        $body = preg_replace('/^\./m', '..', $body);
        fwrite($fp, $hdr . $body . "\r\n.\r\n");
        list($code,) = $read();
        if ($code !== '250') throw new RuntimeException('邮件正文被拒绝：' . $code);

        $cmd('QUIT');
        fclose($fp);
        return array('ok' => true, 'msg' => '发送成功');
    } catch (Throwable $e) {
        if (is_resource($fp)) fclose($fp);
        return array('ok' => false, 'msg' => $e->getMessage());
    }
}

/* ================= 审核结果通知（可在后台单独开关） ================= */

/** 从联系方式字段里提取邮箱（友链申请的「联系方式」可能是 QQ / 邮箱 / 网址） */
function moe_contact_mail($contact)
{
    $contact = trim((string)$contact);
    if ($contact === '') return '';
    // 直接就是邮箱
    if (filter_var($contact, FILTER_VALIDATE_EMAIL)) return $contact;
    // 从文本里抓第一段像邮箱的东西
    if (preg_match('/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/', $contact, $m)) {
        return $m[0];
    }
    return '';
}

/**
 * 友链审批结果通知
 * @param string $name     站点名
 * @param string $url      站点地址
 * @param bool   $approved 是否通过
 * @param string $to       收件邮箱（联系方式中提取）
 */
function moe_notify_link_result($name, $url, $approved, $to)
{
    if (setting('mail_notify_link', '0') !== '1') return;
    $to = moe_contact_mail($to);
    if ($to === '' || !moe_mail_ready()) return;
    if ($approved) {
        $subject = '【' . moe_mail_from_name() . '】友链申请已通过 🎉';
        $html = moe_mail_template(
            '友链申请已通过 🎉',
            array(
                '你好呀～你在 <b>' . htmlspecialchars(moe_mail_from_name(), ENT_QUOTES, 'UTF-8') . '</b> 提交的友链申请<b>已通过审核</b>，现在已经在友情链接页面展示啦！',
                '站点名称：' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8'),
                '站点地址：' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8'),
                '感谢你添加本站链接，期待常来串门～',
            ),
            '去看看友链页',
            (function_exists('u') ? u('link') : base_url() . 'api/link.php')
        );
    } else {
        $subject = '【' . moe_mail_from_name() . '】友链申请已收到，等待站长审核 ☕';
        $html = moe_mail_template(
            '友链申请已收到 ☕',
            array(
                '你在 <b>' . htmlspecialchars(moe_mail_from_name(), ENT_QUOTES, 'UTF-8') . '</b> 提交的友链申请已收到，暂时<b>未检测到本站链接</b>，正在等待站长人工审核。',
                '站点名称：' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8'),
                '站点地址：' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8'),
                '如果方便的话，请先在贵站添加本站链接，通过率会更高哦～',
            )
        );
    }
    @set_time_limit(30);
    moe_mail_send($to, $subject, $html);
}

/**
 * 评论审核结果通知
 * @param string $author    评论者昵称
 * @param string $email     评论者邮箱
 * @param string $postTitle 文章标题
 * @param string $postUrl   文章链接
 * @param string $excerpt   评论内容摘要
 */
function moe_notify_comment_result($author, $email, $postTitle, $postUrl, $excerpt)
{
    if (setting('mail_notify_comment', '0') !== '1') return;
    $email = trim((string)$email);
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) return;
    if (!moe_mail_ready()) return;
    $subject = '【' . moe_mail_from_name() . '】你的评论已通过审核 ✅';
    $html = moe_mail_template(
        '你的评论已通过审核 ✅',
        array(
            '你好，<b>' . htmlspecialchars($author, ENT_QUOTES, 'UTF-8') . '</b>！',
            '你在文章 <b>《' . htmlspecialchars($postTitle, ENT_QUOTES, 'UTF-8') . '》</b> 下的评论<b>已通过审核</b>，现在已经在文章页面展示啦～',
            '评论内容：' . htmlspecialchars(mb_substr((string)$excerpt, 0, 100, 'UTF-8'), ENT_QUOTES, 'UTF-8'),
            '感谢参与互动，欢迎常来回访～',
        ),
        '查看文章页',
        $postUrl
    );
    @set_time_limit(30);
    moe_mail_send($email, $subject, $html);
}
