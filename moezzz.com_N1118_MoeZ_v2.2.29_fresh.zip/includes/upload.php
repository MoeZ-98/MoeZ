<?php
/**
 * MoeZ · 统一附件上传服务
 * ------------------------------------------------------------
 * 参照 emlog Pro 2.6.36 的三处设计收敛而来：
 *   include/lib/common.php   :: upload()         单一落盘入口、按 YYYYMM 分目录、统一命名
 *   include/service/media.php:: checkUpload()    校验集中、错误文案明确
 *   include/lib/common.php   :: get_mimetype()   finfo 探测真实 MIME，不只看扩展名
 *
 * 本文件只负责「校验增强 + 统一命名 + 落盘」三件事。
 * 鉴权 / CSRF / 限频 / 类型白名单 / 大小上限 / 返回字段 一律留在各业务入口，
 * 原有功能逻辑保持不变。
 *
 * 统一命名：uploads/{image|video|audio|file}/YYYYMM/{原名 或 000001}.ext
 *   · 目录已按 YYYYMM 归档，文件名不再重复叠加时间戳 / 随机串；
 *   · 默认保留净化后的原文件名，重名追加 _2 / _3；'numeric' 模式改为纯数字递增；
 *   · 历史「时间串_随机_原名」文件仍由 admin/resources.php 的显示名正则还原；
 *   · 目录结构与 includes/functions.php 的 moe_extract_upload_paths()
 *     引用提取正则 uploads/(image|video|audio|file)/\d{6}/ 保持一致，历史附件不受影响。
 *
 * 最低 PHP 版本：7.0（与站点现有 random_bytes / ?? 用法一致）
 */

if (defined('MOE_UPLOAD_SERVICE_LOADED')) {
    return;
}
define('MOE_UPLOAD_SERVICE_LOADED', true);

/* 命名模式：分月目录已承担时间信息，文件名不再叠加时间戳。
   'origin'  默认：保留净化后的原文件名，重名自动追加 _2 / _3 …
   'numeric' 纯数字递增 000001.ext，适合中文名容易落盘乱码的服务器 */
if (!defined('MOE_UP_NAME_MODE')) {
    define('MOE_UP_NAME_MODE', 'origin');
}

/* 可选开关：服务器文件系统编码异常时改成 true，文件名退化为纯 ASCII
   （原名段变成 file，重名自动加序号）。默认 false，保留中文原名。 */
if (!defined('MOE_UP_ASCII_ONLY')) {
    define('MOE_UP_ASCII_ONLY', false);
}

/** 探测真实 MIME（对齐 emlog get_mimetype）；无法判定时返回空串表示降级 */
function moe_up_real_mime($tmpFile)
{
    if (!$tmpFile || !is_file($tmpFile)) {
        return '';
    }
    if (function_exists('finfo_open')) {
        $fi = @finfo_open(FILEINFO_MIME_TYPE);
        if ($fi) {
            $mime = @finfo_file($fi, $tmpFile);
            @finfo_close($fi);
            if (is_string($mime) && trim($mime) !== '') {
                return strtolower(trim($mime));
            }
        }
    }
    if (function_exists('mime_content_type')) {
        $mime = @mime_content_type($tmpFile);
        if (is_string($mime) && trim($mime) !== '') {
            return strtolower(trim($mime));
        }
    }
    return '';
}

/** SVG 内容扫描：白名单保留 svg，但带脚本 / 外部实体的一律拒绝 */
function moe_up_svg_safe($tmpFile)
{
    $data = @file_get_contents($tmpFile, false, null, 0, 65536);
    if ($data === false) {
        return '无法读取文件内容';
    }
    if (preg_match('/<\s*script\b/i', $data)
        || preg_match('/\bon[a-z]+\s*=/i', $data)
        || preg_match('/javascript\s*:/i', $data)
        || preg_match('/<\s*!\s*ENTITY/i', $data)
        || preg_match('/<\s*foreignObject\b/i', $data)
        || preg_match('/<\s*!\s*DOCTYPE[^>]*\[/i', $data)) {
        return 'SVG 含有脚本或外部实体，已拒绝上传';
    }
    return '';
}

/**
 * 叠加校验：真实 MIME + SVG 脚本扫描。
 * 返回 '' 表示通过，否则返回可直接展示给用户的错误文案。
 * 扩展名白名单 / 大小上限 / getimagesize 仍由各入口按原规则执行，
 * 此处只做「额外拦截」，不会拒绝任何原本能正常上传的合法文件。
 */
function moe_up_check($file, $ext, $isImage)
{
    $tmp = isset($file['tmp_name']) ? (string)$file['tmp_name'] : '';
    if ($tmp === '' || !is_file($tmp)) {
        return '';
    }
    if ($ext === 'svg') {
        return moe_up_svg_safe($tmp);
    }
    $mime = moe_up_real_mime($tmp);
    if ($mime === '') {
        return '';   // finfo 扩展缺失时降级，不阻断上传
    }
    // HTML / PHP / 脚本内容伪装成任意扩展名，一律拒绝
    $danger = array('text/html', 'application/xhtml+xml', 'application/x-httpd-php',
                    'text/x-php', 'application/x-php', 'text/php', 'image/svg+xml');
    if (in_array($mime, $danger, true)) {
        return '文件内容与扩展名不符（检测到 ' . $mime . '），已拒绝上传';
    }
    // ico / avif 在部分系统被识别为 octet-stream，放行交给原有 getimagesize 判断
    if ($isImage && strpos($mime, 'image/') !== 0 && $mime !== 'application/octet-stream') {
        return '文件不是有效的图片（检测到 ' . $mime . '）';
    }
    return '';
}

/** 净化原始文件名主干：控制字符 / 路径字符 / Windows 保留字符 / 连续点 / 首尾符号 */
function moe_up_stem($originName)
{
    $stem = (string)pathinfo((string)$originName, PATHINFO_FILENAME);
    $stem = str_replace(array("\0", "\r", "\n", "\t"), '', $stem);
    $stem = preg_replace('/[\\\\\/\:\*\?"<>\|\x00-\x1F\x7F]+/u', '_', $stem);
    $stem = preg_replace('/\.{2,}/', '.', (string)$stem);
    $stem = trim((string)$stem, ' ._-');
    if (MOE_UP_ASCII_ONLY) {
        $stem = preg_replace('/[^\x20-\x7E]+/', '', (string)$stem);
        $stem = preg_replace('/[^A-Za-z0-9._-]+/', '_', (string)$stem);
        $stem = trim($stem, ' ._-');
    }
    if (function_exists('mb_substr')) {
        $stem = mb_substr((string)$stem, 0, 40, 'UTF-8');
    } else {
        $stem = substr((string)$stem, 0, 40);
    }
    if ($stem === '' || $stem === false) {
        $stem = 'file';
    }
    return $stem;
}

/** 基础文件名：原名.ext（不含时间串 / 随机串）；$time 仅为兼容旧调用签名保留 */
function moe_up_filename($stem, $ext, $time = 0)
{
    return $stem . '.' . ltrim((string)$ext, '.');
}

/**
 * 在目标目录内生成不冲突的文件名。
 * origin  模式：原名.ext → 原名_2.ext → 原名_3.ext …
 * numeric 模式：扫描目录内已有的纯数字名，从最大值 +1 起取 000001.ext。
 */
function moe_up_unique_name($dir, $stem, $ext)
{
    $ext = ltrim((string)$ext, '.');
    $dot = $ext !== '' ? '.' . $ext : '';

    if (strtolower((string)MOE_UP_NAME_MODE) === 'numeric') {
        $max = 0;
        foreach ((array)@glob($dir . '/*' . $dot) as $f) {
            $b = pathinfo($f, PATHINFO_FILENAME);
            if (preg_match('/^\d+$/', $b)) $max = max($max, (int)$b);
        }
        for ($i = 1; $i <= 9999; $i++) {
            $n = str_pad((string)($max + $i), 6, '0', STR_PAD_LEFT) . $dot;
            if (!is_file($dir . '/' . $n)) return $n;
        }
    }

    $base = (string)$stem;
    $n = $base . $dot;
    for ($i = 2; is_file($dir . '/' . $n) && $i <= 9999; $i++) {
        $n = $base . '_' . $i . $dot;
    }
    return $n;
}

/**
 * 统一落盘。文件名不含时间串：目录 uploads/{类型}/YYYYMM/ 已按月份归档。
 * @return array ok=1: name(实际文件名) / stem(净化主干) / display(展示名) / url / rel
 *               ok=0: msg(错误文案，沿用各入口原文案)
 */
function moe_up_store($file, $sub, $originName, $ext)
{
    $time = time();
    $sub  = trim((string)$sub, '/');
    $ym   = date('Ym', $time);
    $dir  = dirname(__DIR__) . '/uploads/' . $sub . '/' . $ym;
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
        return array('ok' => 0, 'msg' => '无法创建上传目录');
    }

    $stem   = moe_up_stem($originName);
    $name   = moe_up_unique_name($dir, $stem, $ext);
    $target = $dir . '/' . $name;

    $tmp = isset($file['tmp_name']) ? (string)$file['tmp_name'] : '';
    if (!@move_uploaded_file($tmp, $target) && !@rename($tmp, $target)) {
        return array('ok' => 0, 'msg' => '保存文件失败，请检查 uploads/ 目录写入权限');
    }
    @chmod($target, 0644);

    return array(
        'ok'      => 1,
        'name'    => $name,
        'stem'    => $stem,
        'display' => $stem . '.' . $ext,
        'url'     => base_url() . 'uploads/' . $sub . '/' . $ym . '/' . rawurlencode($name),
        'rel'     => 'uploads/' . $sub . '/' . $ym . '/' . $name,
    );
}
