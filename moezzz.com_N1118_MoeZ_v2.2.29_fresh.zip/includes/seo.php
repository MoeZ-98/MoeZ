<?php
/**
 * MoeZ - SEO 与链接体系
 * 1) 两种静态 URL 样式：
 *      cat_num  分类目录 / 编号.html   → /fenlei/1.html（编号按分类独立，每个分类都从 1 开始）
 *      id_html  站点根目录 / 编号.html → /1.html
 * 2) 页面级 TKD（Title / Keywords / Description）与 canonical、OG、JSON-LD
 * 3) sitemap.xml / robots.txt 动态输出
 */

/* ================= URL 样式 ================= */

/** 可选 URL 样式：code => array(名称, 说明) */
function url_styles()
{
    return array(
        'cat_num' => array('分类目录 / 编号', '/分类别名/1.html'),
        'id_html' => array('根目录 / 编号', '/1.html'),
    );
}

/** 当前 URL 样式（历史配置自动归一为新样式） */
function url_style()
{
    static $s = null;
    if ($s !== null) return $s;
    $v = (string)setting('url_style', 'cat_num');
    if (!array_key_exists($v, url_styles())) $v = 'cat_num';
    return $s = $v;
}

/** 两种样式都是静态地址 */
function is_pretty_url()
{
    return true;
}

/** 向后兼容旧调用 */
function mo_rewrite()
{
    return is_pretty_url();
}

/** URL 样式示例（设置页预览用） */
function url_style_sample($style, $catSlug = '')
{
    $base = base_url();
    $cat  = $catSlug !== '' ? $catSlug : 'fenlei';
    return $style === 'id_html' ? $base . '1.html' : $base . $cat . '/1.html';
}

/** 全部样式的示例链接（code => 链接），分类别名取站内第一个真实分类 */
function url_style_samples()
{
    $catSlug = 'fenlei';
    try {
        $c = row('SELECT slug FROM ' . moe_table('categories') . ' WHERE slug <> \'\' ORDER BY sort, id LIMIT 1');
        if ($c && !empty($c['slug'])) $catSlug = $c['slug'];
    } catch (Throwable $e) { /* 安装前忽略 */ }

    $out = array();
    foreach (array_keys(url_styles()) as $code) $out[$code] = url_style_sample($code, $catSlug);
    return $out;
}

/* ================= 分类别名与保留字 ================= */

/** 未分类文章使用的目录别名 */
function moe_uncat_slug()
{
    return 'uncategorized';
}

/** 不能用作分类别名的词（否则会和真实文件/系统路由冲突） */
function moe_reserved_slugs()
{
    return array(
        'admin', 'includes', 'templates', 'uploads', 'assets', 'static', 'api',
        'page', 'pages', 'post', 'posts', 'category', 'categories', 'archive', 'archives',
        'link', 'links', 'friend', 'friends', 'life', 'about', 'blog', 'article', 'blogarticle',
        'search', 'rss', 'feed', 'sitemap', 'robots', 'install', 'diag',
        'index', 'comment', 'login', 'logout', 'user', 'users', 'uncategorized',
        'tag',   // 1.8.3：标签聚合页路由 /tag/xxx，分类不能用这个词
    );
}

/** 分类别名是否可用 */
function moe_slug_ok($slug)
{
    $slug = strtolower(trim((string)$slug));
    if ($slug === '' || !preg_match('/^[a-z0-9_-]{1,64}$/', $slug)) return false;
    if (ctype_digit($slug)) return false;
    return !in_array($slug, moe_reserved_slugs(), true);
}

/**
 * 分类别名净化：把任意输入变成可用的目录名（**永不失败**）
 * 1.8.2 起「无法添加分类」不再因别名格式被拦下——非法字符自动转成 -
 */
function moe_slug_clean($slug, $fallback = '')
{
    $slug = strtolower(trim((string)$slug));
    $slug = preg_replace('/\s+/u', '-', $slug);
    $slug = preg_replace('/[^a-z0-9_-]+/', '-', $slug);
    $slug = trim(preg_replace('/-{2,}/', '-', $slug), '-_');

    if ($slug === '' || ctype_digit($slug) || in_array($slug, moe_reserved_slugs(), true)) {
        $base = strtolower(trim((string)$fallback));
        $base = trim(preg_replace('/[^a-z0-9]+/', '-', $base), '-');
        if ($base !== '' && !ctype_digit($base) && strlen($base) <= 60
            && !in_array($base, moe_reserved_slugs(), true)) {
            $slug = $base;
        } else {
            $slug = 'cat-' . substr(md5(uniqid('', true)), 0, 6);
        }
    }
    return substr($slug, 0, 64);
}

/** 分类别名去重：已占用时自动追加 -2 / -3 … */
function moe_cat_slug_unique($slug, $excludeId = 0)
{
    $base = (string)$slug;
    if ($base === '') return $base;
    $try = $base;
    $i = 1;
    while (row('SELECT id FROM ' . moe_table('categories') . ' WHERE slug = ? AND id <> ? LIMIT 1', array($try, (int)$excludeId))) {
        $i++;
        $try = $base . '-' . $i;
        if ($i > 50) return $base . '-' . substr(md5(uniqid('', true)), 0, 4);
    }
    return $try;
}

/**
 * 独立页面别名净化：**允许中文**（链接会 rawurlencode），只去掉路径危险字符
 * 用于「自定义添加页面」——中文标题直接当别名也能访问
 */
function moe_page_slug_clean($slug)
{
    $slug = trim((string)$slug);
    if ($slug === '') return '';
    $slug = preg_replace('/\s+/u', '-', $slug);
    $slug = preg_replace('~[/\\\\?%#&=\'"<>|*:;]+~u', '-', (string)$slug);
    $slug = trim(preg_replace('/-{2,}/u', '-', (string)$slug), '-_');
    if ($slug === '' || ctype_digit($slug)) return '';
    $slug = function_exists('mb_substr') ? mb_substr($slug, 0, 80, 'UTF-8') : substr($slug, 0, 80);
    return $slug;
}

/**
 * 1.9.7：由标题生成独立页面别名（别名留空时使用）
 * 中文标题直接当别名（如「关于我」→ /关于我.html），不再生成 page-随机串。
 * 纯数字标题会与文章 ID 路由冲突、全符号标题无法成路径，这两种情况加「页面-」前缀兜底。
 */
function moe_page_slug_from_title($title)
{
    $title = trim((string)$title);
    if ($title === '') return '';
    $s = moe_page_slug_clean($title);
    if ($s === '') $s = moe_page_slug_clean('页面-' . $title);
    return $s;
}

/** 独立页面别名去重（同类型页面占用时追加 -2 / -3 …；可排除多个 id，如「编辑草稿」副本） */
function moe_page_slug_unique($slug, $excludeIds = array())
{
    $base = (string)$slug;
    if ($base === '') return $base;
    $ex = array();
    foreach ((array)$excludeIds as $e) {
        $e = (int)$e;
        if ($e > 0) $ex[] = $e;
    }
    $try = $base;
    $i = 1;
    while (true) {
        $sql = 'SELECT id FROM ' . moe_table('posts') . " WHERE type='page' AND slug = ?";
        if (!empty($ex)) $sql .= ' AND id NOT IN (' . implode(',', $ex) . ')';
        $sql .= ' LIMIT 1';
        if (!row($sql, array($try))) return $try;
        $i++;
        $try = $base . '-' . $i;
        if ($i > 50) return $base . '-' . substr(md5(uniqid('', true)), 0, 4);
    }
}

/** 按别名取已发布的独立页面（供 /about、/别名 等自定义路径使用） */
function moe_find_page($slug)
{
    $slug = trim((string)$slug);
    if ($slug === '') return null;
    try {
        $pg = row('SELECT * FROM ' . moe_table('posts') . " WHERE type='page' AND slug = ? AND status='published' LIMIT 1", array($slug));
        return $pg ? $pg : null;
    } catch (Throwable $e) {
        return null;
    }
}

/** 取分类别名（分类 ID 为 0 时返回 uncategorized），带静态缓存 */
function moe_cat_slug($catId, $hint = '')
{
    static $cache = array();
    $catId = (int)$catId;
    if ($catId <= 0) return moe_uncat_slug();
    if ($hint !== '') return $hint;
    if (isset($cache[$catId])) return $cache[$catId];

    $slug = '';
    try {
        $r = row('SELECT slug FROM ' . moe_table('categories') . ' WHERE id = ?', array($catId));
        if ($r && !empty($r['slug'])) $slug = $r['slug'];
    } catch (Throwable $e) { /* 忽略 */ }
    return $cache[$catId] = ($slug !== '' ? $slug : moe_uncat_slug());
}

/* ================= 文章编号（每个分类独立，从 1 开始） ================= */

/** 读取文章的分类 / 别名 / 编号（带静态缓存） */
function moe_post_meta($id)
{
    static $cache = array();
    $id = (int)$id;
    if ($id <= 0) return array();
    if (isset($cache[$id])) return $cache[$id];

    $out = array();
    try {
        $r = row('SELECT p.id, p.slug, p.category_id, p.url_num, c.slug AS cat_slug
                  FROM ' . moe_table('posts') . ' p
                  LEFT JOIN ' . moe_table('categories') . ' c ON c.id = p.category_id
                  WHERE p.id = ?', array($id));
        if ($r) $out = $r;
    } catch (Throwable $e) { /* url_num 字段尚未升级时忽略 */ }
    return $cache[$id] = $out;
}

/** 为文章分配「分类内编号」并写库 */
function moe_assign_post_num($postId)
{
    $postId = (int)$postId;
    if ($postId <= 0) return 0;
    $pt = moe_table('posts');
    try {
        $p = row('SELECT id, category_id FROM ' . $pt . ' WHERE id = ?', array($postId));
        if (!$p) return 0;
        $cid = (int)$p['category_id'];
        $max = (int)one('SELECT COALESCE(MAX(url_num),0) FROM ' . $pt . " WHERE type='post' AND category_id = ?", array($cid));
        $num = $max + 1;
        q('UPDATE ' . $pt . ' SET url_num = ? WHERE id = ?', array($num, $postId));
        return $num;
    } catch (Throwable $e) {
        return 0;
    }
}

/** 确保文章已有编号（已有则原样返回） */
function moe_ensure_post_num($postId)
{
    $postId = (int)$postId;
    if ($postId <= 0) return 0;
    try {
        $cur = (int)one('SELECT url_num FROM ' . moe_table('posts') . ' WHERE id = ?', array($postId));
        if ($cur > 0) return $cur;
    } catch (Throwable $e) {
        return 0;
    }
    return moe_assign_post_num($postId);
}

/** 文章编号（读取，缺失时自动补齐） */
function post_url_num($post)
{
    static $cache = array();
    $id = is_array($post) ? (int)(isset($post['id']) ? $post['id'] : 0) : (int)$post;
    if ($id <= 0) return 0;
    if (is_array($post) && isset($post['url_num']) && (int)$post['url_num'] > 0) return (int)$post['url_num'];
    if (isset($cache[$id])) return $cache[$id];
    return $cache[$id] = moe_ensure_post_num($id);
}

/* ================= 编号自动补全（删除文章后不留空号） ================= */

/**
 * 重新整理文章编号：按原顺序（url_num, id）从 1 开始连续重排，补掉被删除留下的空号
 * 例：1、2、3、4 删掉 2、3 后 → 重排为 1、2
 * @param int|null $catId 指定分类；null 表示整理全部分类
 * @return int 被改动的文章数
 */
function moe_reindex_cat_nums($catId = null)
{
    $pt = moe_table('posts');
    try {
        $cids = array();
        if ($catId === null) {
            foreach ((array)rows('SELECT DISTINCT category_id FROM ' . $pt . " WHERE type='post'") as $r) {
                $cids[] = (int)$r['category_id'];
            }
        } else {
            $cids[] = (int)$catId;
        }
        $changed = 0;
        foreach ($cids as $cid) {
            $list = rows('SELECT id, url_num FROM ' . $pt
                . " WHERE type='post' AND category_id = ?"
                . ' ORDER BY (url_num = 0) ASC, url_num ASC, id ASC', array($cid));
            $i = 0;
            foreach ((array)$list as $it) {
                $i++;
                if ((int)$it['url_num'] !== $i) {
                    q('UPDATE ' . $pt . ' SET url_num = ? WHERE id = ?', array($i, (int)$it['id']));
                    $changed++;
                }
            }
        }
        return $changed;
    } catch (Throwable $e) {
        return 0;
    }
}

/* ================= 链接生成 ================= */

/** 文章链接（支持传数组或 ID，按当前样式生成） */
function post_url($post)
{
    $p  = is_array($post) ? $post : array('id' => (int)$post);
    $id = isset($p['id']) ? (int)$p['id'] : 0;

    // 缺少分类 / 编号时补查一次（带缓存，列表页不会重复查询）
    if ($id > 0 && (!isset($p['category_id']) || !isset($p['url_num']) || (int)$p['url_num'] <= 0)) {
        foreach (moe_post_meta($id) as $k => $v) {
            if (!isset($p[$k]) || $p[$k] === '' || ($k === 'url_num' && (int)$p[$k] <= 0)) $p[$k] = $v;
        }
    }

    $catSlug = !empty($p['cat_slug']) ? (string)$p['cat_slug'] : moe_cat_slug(isset($p['category_id']) ? $p['category_id'] : 0);
    $num     = post_url_num($id);

    if (url_style() === 'cat_num' && $num > 0) {
        return base_url() . rawurlencode($catSlug) . '/' . $num . '.html';
    }
    // 根目录 / 文章 ID.html
    return base_url() . ($id > 0 ? $id : 1) . '.html';
}

/** 独立页面链接 */
function page_url($page)
{
    $id   = is_array($page) ? (isset($page['id']) ? (int)$page['id'] : 0) : (int)$page;
    $slug = is_array($page) && !empty($page['slug']) ? (string)$page['slug'] : '';
    if ($slug === '' && $id > 0) {
        try {
            $r = row('SELECT slug FROM ' . moe_table('posts') . " WHERE id = ? AND type='page'", array($id));
            if ($r && !empty($r['slug'])) $slug = (string)$r['slug'];
        } catch (Throwable $e) { /* 忽略 */ }
    }
    if ($slug === '') $slug = (string)$id;
    // 1.8.4：独立页面直接使用根路径 /别名.html（不再带 /page/ 前缀；旧 /page/别名.html 仍兼容）
    return base_url() . rawurlencode($slug) . '.html';
}

/** 分类链接（1.8.4：设置了自定义链接的分类直接返回该链接，支持站内路径与外部网址） */
function cat_url($cat)
{
    // 自定义链接：http(s):// 开头原样使用；/path 相对站点根；纯路径（如 life）按站内路径拼接
    if (is_array($cat) && isset($cat['link']) && trim((string)$cat['link']) !== '') {
        $link = trim((string)$cat['link']);
        if (preg_match('#^https?://#i', $link)) return $link;
        $base = base_url();
        return $base . ltrim($link, '/');
    }
    $id   = is_array($cat) ? (isset($cat['id']) ? (int)$cat['id'] : 0) : (int)$cat;
    $slug = is_array($cat) && !empty($cat['slug']) ? (string)$cat['slug'] : '';
    if ($slug === '' && $id > 0) $slug = moe_cat_slug($id);
    if ($slug === '') $slug = (string)$id;
    if (url_style() === 'cat_num') return base_url() . rawurlencode($slug) . '/';
    return base_url() . 'category/' . rawurlencode($slug);
}

/** 搜索链接 */
function search_url($kw = '')
{
    return base_url() . 'search/' . rawurlencode($kw);
}

/** 首页 / 分页链接 */
function home_url($pageNo = 1)
{
    $pageNo = max(1, (int)$pageNo);
    return base_url() . ($pageNo > 1 ? '?page=' . $pageNo : '');
}

/** 按「分类别名 + 编号」查文章（cat_num 样式） */
function moe_post_by_catnum($catSlug, $num)
{
    $num = (int)$num;
    if ($num <= 0 || $catSlug === '') return null;
    $pt = moe_table('posts');
    try {
        if ($catSlug === moe_uncat_slug()) {
            return row('SELECT * FROM ' . $pt . " WHERE type='post' AND category_id = 0 AND url_num = ? ORDER BY id LIMIT 1", array($num));
        }
        return row('SELECT p.* FROM ' . $pt . ' p
                    INNER JOIN ' . moe_table('categories') . ' c ON c.id = p.category_id
                    WHERE p.type=\'post\' AND c.slug = ? AND p.url_num = ? ORDER BY p.id LIMIT 1', array($catSlug, $num));
    } catch (Throwable $e) {
        return null;
    }
}

/** 分页基址（拼接页码即得完整链接） */
function page_base($url)
{
    $url = preg_replace('/([?&])page=\d+$/i', '$1', $url);
    if (substr($url, -1) === '?' || substr($url, -1) === '&') return $url;
    return $url . (strpos($url, '?') === false ? '?page=' : '&page=');
}

/** RSS 链接 */
function rss_url()
{
    return base_url() . 'rss';
}

/** sitemap 链接 */
function sitemap_url()
{
    return base_url() . 'sitemap.xml';
}

/* ================= 路由路径解析 ================= */

/** 当前请求的相对路径（已剥离站点子目录与 index.php 前缀） */
function moe_request_path()
{
    static $path = null;
    if ($path !== null) return $path;

    if (!empty($_SERVER['PATH_INFO'])) {
        $p = $_SERVER['PATH_INFO'];
    } else {
        $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/';
        $p = parse_url($uri, PHP_URL_PATH);
        if (!is_string($p)) $p = '/';
    }

    $base = parse_url(base_url(), PHP_URL_PATH);
    $base = rtrim((string)$base, '/');
    if ($base !== '' && strpos($p, $base) === 0) $p = substr($p, strlen($base));

    $p = preg_replace('#^/index\.php#i', '', $p);
    $p = preg_replace('/\.html$/i', '', $p);
    $p = trim($p, '/');

    return $path = $p;
}

/** 当前页面完整地址 */
function current_url()
{
    return base_url() . ltrim(moe_request_path(), '/');
}

/* ================= TKD / Meta ================= */

/** 写入当前页面的 SEO 数据（可多次调用增量合并） */
function seo_set($arr)
{
    if (!isset($GLOBALS['moe_seo']) || !is_array($GLOBALS['moe_seo'])) $GLOBALS['moe_seo'] = array();
    $GLOBALS['moe_seo'] = array_merge($GLOBALS['moe_seo'], (array)$arr);
}

function seo_get($key, $default = '')
{
    return (isset($GLOBALS['moe_seo'][$key]) && $GLOBALS['moe_seo'][$key] !== '') ? $GLOBALS['moe_seo'][$key] : $default;
}

/**
 * 标题分隔符
 * 1.6.4 起不再由用户配置（旧设置项 seo_title_sep 已废弃），固定为「 - 」
 */
function seo_sep()
{
    return ' - ';
}

/** 网站标题：站点正式名称（设置项 site_name），留空时回退默认值 */
function seo_site_title()
{
    $t = trim((string)setting('site_name', ''));
    return $t !== '' ? $t : 'MoeZ';
}

/** 浏览器标题：只在首页的浏览器标签里显示；留空时回退为网站标题 */
function seo_browser_title()
{
    $t = trim((string)setting('browser_title', ''));
    return $t !== '' ? $t : seo_site_title();
}

/** 标题显示方式：browser（默认，首页用浏览器标题）/ site（首页也用网站标题） */
function seo_title_mode()
{
    $m = (string)setting('title_mode', 'browser');
    return $m === 'site' ? 'site' : 'browser';
}

/**
 * 首页完整标题（前台首页与后台「站点设置 → SEO」预览共用同一套逻辑）
 * browser 模式取浏览器标题，site 模式取网站标题；浏览器标题里可用 {site} 代表网站标题
 */
function seo_home_title($pageNo = 1)
{
    $t = seo_title_mode() === 'site' ? seo_site_title() : seo_browser_title();
    $t = str_replace('{site}', seo_site_title(), $t);
    $pageNo = max(1, (int)$pageNo);
    return $pageNo > 1 ? '第 ' . $pageNo . ' 页 · ' . $t : $t;
}

/** 内容页（文章 / 独立页面 / 分类页等）完整标题：页面名 + 分隔符 + 网站标题 */
function seo_content_title($title)
{
    $siteTitle = seo_site_title();
    $title = trim((string)$title);
    if ($title === '') return $siteTitle;
    return $title . seo_sep() . $siteTitle;
}

/** 生成完整页面标题 */
function seo_full_title()
{
    $full = seo_get('title_full');
    if ($full !== '') return str_replace('{site}', seo_site_title(), $full);

    return seo_content_title(seo_get('title'));
}

/**
 * 输出 <head> 内的 SEO 标签
 * 依赖 $GLOBALS['moe_seo']（由路由按页面写入）
 */
function seo_head()
{
    $siteName = setting('site_name', 'MoeZ');
    $title    = seo_full_title();
    $keywords = trim(seo_get('keywords', setting('site_keywords', '')));
    $desc     = trim(seo_get('desc', setting('site_desc', '')));
    $canonical = seo_get('canonical', current_url());
    $type     = seo_get('type', 'website');
    $image    = seo_get('image', '');
    if ($image === '') $image = setting('site_avatar', '');
    $image = $image !== '' ? media_url($image) : '';
    // 社交平台不识别 SVG 缩略图，直接忽略
    if (preg_match('/\.svgz?(\?|$)/i', $image)) $image = '';
    if ($image !== '' && strpos($image, '//') === 0) $image = (strpos(base_url(), 'https://') === 0 ? 'https:' : 'http:') . $image;

    $robots = seo_get('robots', 'index,follow');
    if (setting('site_status', 'open') !== 'open') $robots = 'noindex,nofollow';
    if (seo_get('is_search') && setting('seo_noindex_search', '1') === '1') $robots = 'noindex,follow';

    if (function_exists('mb_substr')) {
        $desc = mb_strlen($desc, 'UTF-8') > 200 ? mb_substr($desc, 0, 200, 'UTF-8') : $desc;
    }

    $html  = '<title>' . e($title) . "</title>\n";
    if ($keywords !== '') $html .= '<meta name="keywords" content="' . e($keywords) . "\">\n";
    if ($desc !== '')     $html .= '<meta name="description" content="' . e($desc) . "\">\n";
    $html .= '<meta name="author" content="' . e(setting('site_author', $siteName)) . "\">\n";
    $html .= '<meta name="robots" content="' . e($robots) . "\">\n";
    if (setting('seo_canonical', '1') === '1') {
        $html .= '<link rel="canonical" href="' . e($canonical) . "\">\n";
    }

    // 分页的上一页 / 下一页
    if (seo_get('prev')) $html .= '<link rel="prev" href="' . e(seo_get('prev')) . "\">\n";
    if (seo_get('next')) $html .= '<link rel="next" href="' . e(seo_get('next')) . "\">\n";

    // Open Graph / Twitter
    if (setting('seo_og', '1') === '1') {
        $html .= '<meta property="og:site_name" content="' . e($siteName) . "\">\n";
        $html .= '<meta property="og:locale" content="zh_CN">' . "\n";
        $html .= '<meta property="og:type" content="' . e($type === 'article' ? 'article' : 'website') . "\">\n";
        $html .= '<meta property="og:title" content="' . e($title) . "\">\n";
        if ($desc !== '')  $html .= '<meta property="og:description" content="' . e($desc) . "\">\n";
        $html .= '<meta property="og:url" content="' . e($canonical) . "\">\n";
        if ($image !== '') $html .= '<meta property="og:image" content="' . e($image) . "\">\n";
        if (seo_get('published')) $html .= '<meta property="article:published_time" content="' . e(date('c', strtotime(seo_get('published')))) . "\">\n";
        if (seo_get('modified'))  $html .= '<meta property="article:modified_time" content="' . e(date('c', strtotime(seo_get('modified')))) . "\">\n";
        $html .= '<meta name="twitter:card" content="' . ($image !== '' ? 'summary_large_image' : 'summary') . "\">\n";
        $html .= '<meta name="twitter:title" content="' . e($title) . "\">\n";
        if ($desc !== '')  $html .= '<meta name="twitter:description" content="' . e($desc) . "\">\n";
        if ($image !== '') $html .= '<meta name="twitter:image" content="' . e($image) . "\">\n";
    }

    // 结构化数据
    if (setting('seo_jsonld', '1') === '1') {
        $html .= seo_jsonld($title, $desc, $canonical, $image);
    }

    return $html;
}

/** JSON-LD 结构化数据 */
function seo_jsonld($title, $desc, $canonical, $image = '')
{
    $siteName = setting('site_name', 'MoeZ');
    $type = seo_get('type', 'website');
    $graph = array();

    $graph[] = array(
        '@type'       => 'WebSite',
        '@id'         => base_url() . '#website',
        'name'        => $siteName,
        'url'         => base_url(),
        'description' => setting('site_desc', ''),
        'inLanguage'  => 'zh-CN',
    );

    if ($type === 'article') {
        $article = array(
            '@type'            => 'BlogPosting',
            'headline'         => seo_get('title', $title),
            'description'      => $desc,
            'url'              => $canonical,
            'mainEntityOfPage' => array('@type' => 'WebPage', '@id' => $canonical),
            'inLanguage'       => 'zh-CN',
            'author'           => array('@type' => 'Person', 'name' => setting('site_author', $siteName)),
            'publisher'        => array('@type' => 'Organization', 'name' => $siteName),
        );
        if (seo_get('published')) $article['datePublished'] = date('c', strtotime(seo_get('published')));
        if (seo_get('modified'))  $article['dateModified']  = date('c', strtotime(seo_get('modified')));
        if ($image !== '')        $article['image']         = $image;
        $graph[] = $article;
    } else {
        $graph[] = array(
            '@type'      => 'WebPage',
            '@id'        => $canonical . '#webpage',
            'url'        => $canonical,
            'name'       => $title,
            'isPartOf'   => array('@id' => base_url() . '#website'),
            'inLanguage' => 'zh-CN',
        );
    }

    $data = array('@context' => 'https://schema.org', '@graph' => $graph);
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return '<script type="application/ld+json">' . $json . "</script>\n";
}

/* ================= sitemap / robots ================= */

/** 输出 sitemap.xml（全自动：自动识别站点地址与 URL 样式，收录首页 / 分类 / 文章 / 独立页面） */
function seo_sitemap()
{
    header('Content-Type: application/xml; charset=utf-8');
    $base = base_url();
    $out  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $out .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

    // 首页：lastmod 取最新文章更新时间
    $lastMod = '';
    try {
        $lm = row('SELECT updated_at FROM ' . moe_table('posts') . " WHERE status='published' ORDER BY updated_at DESC LIMIT 1");
        if ($lm && !empty($lm['updated_at'])) $lastMod = '<lastmod>' . date('c', strtotime($lm['updated_at'])) . '</lastmod>';
    } catch (Throwable $e) {}
    $out .= '  <url><loc>' . e($base) . '</loc>' . $lastMod . '<changefreq>daily</changefreq><priority>1.0</priority></url>' . "\n";

    // 归档 / 写作 / 点滴 / 关于 / 友链页（flowersink 风格模板的固定入口）
    $out .= '  <url><loc>' . e($base . 'archives') . '</loc><changefreq>weekly</changefreq><priority>0.5</priority></url>' . "\n";
    $out .= '  <url><loc>' . e($base . 'blog/article') . '</loc><changefreq>daily</changefreq><priority>0.8</priority></url>' . "\n";
    if (trim(theme_opt('life_slug', 'life')) !== '') {
        $out .= '  <url><loc>' . e($base . 'life') . '</loc><changefreq>weekly</changefreq><priority>0.6</priority></url>' . "\n";
    }
    $out .= '  <url><loc>' . e($base . 'about') . '</loc><changefreq>monthly</changefreq><priority>0.5</priority></url>' . "\n";
    if (function_exists('moe_table')) {
        try {
            $linkCount = (int)one('SELECT COUNT(*) FROM ' . moe_table('links'));
        } catch (Throwable $e) {
            $linkCount = 0;
        }
        if ($linkCount > 0) {
            $out .= '  <url><loc>' . e($base . 'link') . '</loc><changefreq>weekly</changefreq><priority>0.5</priority></url>' . "\n";
        }
    }

    foreach (rows('SELECT * FROM ' . moe_table('categories') . ' ORDER BY sort, id') as $c) {
        // 1.8.4：设置了自定义链接的分类是外链/站内跳转，不进 sitemap
        if (!empty($c['link'])) continue;
        $out .= '  <url><loc>' . e(cat_url($c)) . '</loc><changefreq>weekly</changefreq><priority>0.6</priority></url>' . "\n";
    }

    $items = rows('SELECT id, slug, type, category_id, url_num, updated_at, created_at FROM ' . moe_table('posts')
        . " WHERE status='published' AND type IN ('post','page') ORDER BY updated_at DESC LIMIT 5000");
    foreach ($items as $it) {
        $url = $it['type'] === 'page' ? page_url($it) : post_url($it);
        $out .= '  <url><loc>' . e($url) . '</loc><lastmod>' . date('c', strtotime($it['updated_at'])) . '</lastmod>'
              . '<changefreq>monthly</changefreq><priority>0.8</priority></url>' . "\n";
    }

    $out .= '</urlset>';
    echo $out;
    exit;
}

/** 输出 robots.txt */
function seo_robots()
{
    header('Content-Type: text/plain; charset=utf-8');
    $base = base_url();
    echo "User-agent: *\n";
    echo "Allow: /\n";
    echo "Disallow: " . parse_url($base, PHP_URL_PATH) . "admin/\n";
    echo "Disallow: " . parse_url($base, PHP_URL_PATH) . "install.php\n";
    if (setting('seo_noindex_search', '1') === '1') {
        echo "Disallow: " . parse_url($base, PHP_URL_PATH) . "search/\n";
    }
    echo "\nSitemap: " . $base . "sitemap.xml\n";
    exit;
}
