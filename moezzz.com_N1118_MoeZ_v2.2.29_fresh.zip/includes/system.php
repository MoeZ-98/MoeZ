<?php
/**
 * MoeZ · 软件信息 / 版本检测 / 在线更新（2.0.3）
 * ------------------------------------------------------------
 * 2.0.2：只做「检测 + 提示」。
 * 2.0.3：仪表盘进页面自动检测；新增一键在线更新与上传 zip 更新包。
 *        覆盖前自动备份到 content/backups/，任何一步失败自动回滚；
 *        config.php 与 content/ 下的用户数据永不覆盖，路径做 ZipSlip 防护。
 *
 * 安全边界：仅站长可调用（admin/update-check.php 校验 CSRF + 角色 + 二次确认），
 *           远程地址一律走 moe_update_feed_valid() 拒绝内网 / 非 http(s)，
 *           下载不跟随重定向，压缩包逐条校验路径、类型、体积。
 */

/** 服务器环境信息（后台仪表盘展示用） */
function moe_system_info()
{
    $driver = '—';
    $dbver  = '—';
    $dbname = '—';
    try {
        $pdo = moe_db();
        $driver = (string)$pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
        $dbver  = (string)$pdo->getAttribute(PDO::ATTR_SERVER_VERSION);
        $dbname = (string)one('SELECT DATABASE()');
    } catch (Throwable $e) { /* 数据库信息取不到不影响其它项 */ }

    $web = trim((string)($_SERVER['SERVER_SOFTWARE'] ?? ''));
    if ($web === '') $web = '未公开';
    $osFamily = defined('PHP_OS_FAMILY') ? PHP_OS_FAMILY : PHP_OS;
    $osName   = function_exists('php_uname') ? php_uname('s') : PHP_OS;
    $arch     = function_exists('php_uname') ? php_uname('m') : '';
    $tz       = function_exists('date_default_timezone_get') ? date_default_timezone_get() : '（未设置）';

    $mem = trim((string)ini_get('memory_limit'));
    $upl = trim((string)ini_get('upload_max_filesize'));

    return array(
        array('k' => 'PHP 版本',      'v' => PHP_VERSION,                       's' => PHP_SAPI . ' · 内存上限 ' . $mem . ' · 上传上限 ' . $upl),
        array('k' => '数据库',        'v' => strtoupper($driver) . ' ' . $dbver, 's' => '当前库 ' . ($dbname !== '' ? $dbname : '—') . ' · PDO 驱动 ' . $driver),
        array('k' => 'Web 服务',      'v' => $web,                              's' => '协议 ' . (string)($_SERVER['SERVER_PROTOCOL'] ?? '—')),
        array('k' => '操作系统',      'v' => $osFamily . ' / ' . $osName,       's' => $arch !== '' ? '架构 ' . $arch : ''),
        array('k' => '系统时区',      'v' => $tz,                               's' => '当前时间 ' . date('Y-m-d H:i:s')),
        array('k' => '程序版本',      'v' => 'MoeZ v' . MOE_VERSION,        's' => 'DB ' . (defined('MOE_DB_VERSION') ? MOE_DB_VERSION : '—') . ' · zip 扩展 ' . (class_exists('ZipArchive') ? '已开启' : '未开启')),
    );
}

/** 在线更新源地址（后台可配置） */
function moe_update_feed_url()
{
    return trim((string)setting('update_check_url', ''));
}

/** 更新源 / 更新包地址基本校验：只允许公网 http/https，防 SSRF */
function moe_update_feed_valid($url, &$err)
{
    $err = '';
    $url = trim((string)$url);
    if ($url === '') { $err = '地址不能为空'; return false; }
    /* 2.2.14：蓝奏云等地址允许附加提取码（?pwd=xxx 或尾部「密码:xxx」），先拆掉再校验 */
    $dummyPwd = '';
    $url = moe_update_lz_split($url, $dummyPwd);
    if ($url === '') { $err = '地址不能为空'; return false; }
    $p = parse_url($url);
    if (!is_array($p) || !in_array(strtolower((string)($p['scheme'] ?? '')), array('http', 'https'), true)) {
        $err = '必须是 http:// 或 https:// 开头的完整地址'; return false;
    }
    $host = strtolower((string)($p['host'] ?? ''));
    if ($host === '' || strpos($host, ' ') !== false) { $err = '缺少主机名'; return false; }
    if (isset($p['user']) || isset($p['pass'])) { $err = '地址不允许带账号密码'; return false; }
    if ($host === 'localhost' || $host === '::1' || preg_match('/^(127\.|10\.|192\.168\.|169\.254\.|0\.|localhost\.)/', $host)
        || preg_match('/^172\.(1[6-9]|2[0-9]|3[01])\./', $host)) {
        $err = '不能指向本机或内网地址'; return false;
    }
    return true;
}

/** 随程序包发布的本地版本清单（离线兜底） */
function moe_update_local_meta()
{
    $f = MOE_ROOT . '/version.json';
    $j = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
    if (!is_array($j)) $j = array();
    return array(
        'version'   => isset($j['version']) ? (string)$j['version'] : MOE_VERSION,
        'date'      => isset($j['date']) ? (string)$j['date'] : '',
        'changelog' => isset($j['changelog']) ? (string)$j['changelog'] : '',
        'download'  => isset($j['download']) ? (string)$j['download'] : '',
    );
}

/** 首次检测结果缓存（只读，不联网；仪表盘首屏秒出） */
function moe_update_cached()
{
    $c = json_decode((string)setting('update_check_cache', ''), true);
    // 2.0.2 的旧缓存没有 can_online 等字段，必须让它重新检测一次
    return is_array($c) && !empty($c['ok']) && isset($c['can_online']) ? $c : array();
}

/** 拉取远程 version.json（不跟随重定向，避免绕过地址校验） */
function moe_update_fetch($url, &$err)
{
    $err = '';
    $ua  = 'MoeZ/' . MOE_VERSION;
    $body = false;
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 6,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT      => $ua,
        ));
        $body = curl_exec($ch);
        if ($body === false) $err = '连接更新源失败：' . curl_error($ch);
        curl_close($ch);
    } else {
        $ctx = stream_context_create(array('http' => array(
            'timeout'          => 6,
            'follow_location'  => 0,
            'user_agent'       => $ua,
        )));
        $body = @file_get_contents($url, false, $ctx);
        if ($body === false) $err = '连接更新源失败（请检查地址，或开启 allow_url_fopen）';
    }
    if ($body === false || $body === '') return null;
    $j = json_decode(trim((string)$body), true);
    if (!is_array($j) || empty($j['version'])) {
        $err = '更新源返回格式不正确，需包含 version 字段的 JSON'; return null;
    }
    return $j;
}

/**
 * 自动检测更新：返回统一结构
 * source = remote（在线检测） / local（离线兜底）
 * 2.0.3 追加 can_online / zip_ready / writable / ready_reason 供前端判断按钮可用性
 */
function moe_update_check($force = false)
{
    $cacheKey = 'update_check_cache';
    $cached = json_decode((string)setting($cacheKey, ''), true);
    // 旧版（≤2.0.2）缓存缺 can_online 字段，命中也要重算，避免升级后按钮判断失效
    if (!$force && is_array($cached) && !empty($cached['checked_ts']) && isset($cached['can_online'])
        && (time() - (int)$cached['checked_ts'] < 600)) {
        return $cached;
    }

    $url    = moe_update_feed_url();
    $source = 'local';
    $msg    = '尚未配置在线更新源，已按随程序包的版本清单检测';
    $meta   = moe_update_local_meta();

    if ($url !== '') {
        $err = '';
        if (!moe_update_feed_valid($url, $err)) {
            $msg = '更新源地址不合法：' . $err . '（已回落到本地版本清单）';
        } else {
            $remote = moe_update_fetch($url, $err);
            if (is_array($remote)) {
                $source = 'remote';
                $msg    = '在线检测完成';
                $meta   = array(
                    'version'   => (string)$remote['version'],
                    'date'      => isset($remote['date']) ? (string)$remote['date'] : '',
                    'changelog' => isset($remote['changelog']) ? (string)$remote['changelog'] : '',
                    'download'  => isset($remote['download']) ? (string)$remote['download'] : '',
                );
                if (isset($remote['notice'])) $msg .= '：' . (string)$remote['notice'];
            } else {
                $msg = $err . '（已回落到本地版本清单）';
            }
        }
    }

    $latest = trim((string)$meta['version']);
    if ($latest === '') $latest = MOE_VERSION;
    $res = array(
        'ok'         => 1,
        'source'     => $source,
        'msg'        => $msg,
        'current'    => MOE_VERSION,
        'latest'     => $latest,
        'has_new'    => version_compare($latest, MOE_VERSION, '>') ? 1 : 0,
        'date'       => (string)$meta['date'],
        'changelog'  => (string)$meta['changelog'],
        'download'   => (string)$meta['download'],
        'feed'       => $url,
        'checked_at' => date('Y-m-d H:i:s'),
        'checked_ts' => time(),
    );

    // 2.0.3：在线更新的前置条件（结果一并缓存，前端直接用来决定按钮显隐）
    $derr = '';
    $downloadOk = $res['download'] !== '' && moe_update_feed_valid($res['download'], $derr);
    $zipReady   = class_exists('ZipArchive');
    $writable   = is_writable(MOE_ROOT) || (is_dir(MOE_ROOT . '/content') && is_writable(MOE_ROOT . '/content'));
    $reasons = array();
    if ($res['download'] === '') $reasons[] = '官方未提供在线更新包地址，可改用「上传更新包」';
    elseif (!$downloadOk) $reasons[] = '更新包地址不合法：' . $derr;
    if (!$zipReady) $reasons[] = 'PHP 未开启 zip 扩展';
    if (!$writable) $reasons[] = '程序目录不可写';
    $res['download_ok']  = $downloadOk ? 1 : 0;
    $res['zip_ready']    = $zipReady ? 1 : 0;
    $res['writable']     = $writable ? 1 : 0;
    $res['can_online']   = ($res['has_new'] && $downloadOk && $zipReady && $writable) ? 1 : 0;
    $res['ready_reason'] = implode('；', $reasons);

    setting_set($cacheKey, json_encode($res, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    return $res;
}

/* ============================================================
   2.0.3 · 在线更新（下载 / 校验 / 备份 / 覆盖 / 回滚）
   ============================================================ */

/** 创建并保护备份工作区 content/backups/ */
function moe_update_workspace(&$err)
{
    $err = '';
    $dir = MOE_ROOT . '/content/backups';
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
        $err = '无法创建 content/backups/，请给程序目录写入权限'; return '';
    }
    if (!is_writable($dir)) { $err = 'content/backups/ 不可写，无法生成更新备份'; return ''; }
    if (!is_file($dir . '/index.html')) {
        @file_put_contents($dir . '/index.html', '<!doctype html><title>403</title><body><h1>403 Forbidden</h1></body>');
    }
    if (!is_file($dir . '/.htaccess')) {
        @file_put_contents($dir . '/.htaccess',
            "# MoeZ backup protection\n"
            . "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n"
            . "<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
    }
    return $dir;
}

/** 单条压缩包路径的安全校验：ZipSlip + 受保护数据 + 文件类型白名单 */
function moe_update_safe_path($path, &$err)
{
    $err = '';
    $path = str_replace('\\', '/', trim((string)$path));
    if ($path === '' || substr($path, -1) === '/' || strpos($path, "\0") !== false) {
        $err = '空路径或目录条目'; return false;
    }
    if ($path[0] === '/' || preg_match('#^[A-Za-z]:#', $path)) { $err = '绝对路径'; return false; }
    $segs = explode('/', $path);
    foreach ($segs as $s) {
        if ($s === '' || $s === '.' || $s === '..') { $err = '路径越界'; return false; }
        if ($s[0] === '.') { $err = '隐藏文件'; return false; }
    }
    // 用户数据 / 运行环境配置一律不覆盖
    $denyTop = array('content', 'data', 'backup', 'backups', 'vendor', '.git', '.workbuddy');
    if (in_array(strtolower($segs[0]), $denyTop, true)) { $err = '受保护目录'; return false; }
    $denyFile = array('config.php', '.htaccess', '.user.ini', '.env', 'install.lock',
                      'robots.txt', 'sitemap.xml', 'web.config', '.DS_Store');
    if (in_array(strtolower(basename($path)), $denyFile, true)) { $err = '受保护文件'; return false; }

    $ext = strtolower((string)pathinfo($path, PATHINFO_EXTENSION));
    $denyExt = array('phtml', 'php3', 'php4', 'php5', 'php7', 'phar', 'pht', 'shtml',
                     'exe', 'sh', 'bat', 'cmd', 'dll', 'so', 'py', 'pl', 'cgi',
                     'jsp', 'asp', 'aspx', 'htaccess', 'ini', 'env', 'lock');
    if (in_array($ext, $denyExt, true)) { $err = '危险文件类型'; return false; }
    $allowExt = array('php', 'css', 'js', 'json', 'md', 'html', 'htm', 'txt', 'xml',
                      'svg', 'png', 'jpg', 'jpeg', 'gif', 'webp', 'ico',
                      'woff', 'woff2', 'ttf', 'eot', 'map', 'conf', 'yml', 'yaml');
    if (!in_array($ext, $allowExt, true)) { $err = '不在允许的文件类型内'; return false; }
    return true;
}

/**
 * 2.2.25：覆盖写入前确保目标可写 —— 先尝试 chmod 自修复再判定。
 * 常见故障：宝塔下用 root 解压 / FTP 上传导致文件属主不是 PHP 运行用户，
 * 权限常为 444/644（属主无写位）或 640，is_writable 直接判死。
 * 这里先 @chmod 把文件抬到 0644、目录抬到 0755，再复检；仍不可写才算真失败。
 * 注意：属主完全不对（root 属主且非同组）时 chmod 会失败 —— 这属于
 * PHP 进程无权修改的情况，只能由用户在宝塔/SSH 手工修，错误文案里会给出指引。
 */
function moe_update_ensure_writable($path)
{
    if (@is_writable($path)) return true;
    @chmod($path, is_dir($path) ? 0755 : 0644);
    clearstatcache(true, $path);
    return @is_writable($path);
}

/** 面向用户的不可写报错文案：带上「已尝试自动修复失败」与宝塔修权限指引 */
function moe_update_unwritable_msg($path, $what = '文件')
{
    return $what . '不可写：' . $path
        . '（已尝试自动 chmod 修复仍未成功，通常是文件属主不是 PHP 运行用户；'
        . '宝塔用户请在文件管理中把该文件/目录权限改为 ' . ($what === '目录' ? '755' : '644')
        . ' 并勾选「应用到子目录」，或把站点目录属主改为 www）';
}

/* ==================== 蓝奏云分享链接解析（2.2.14） ==================== */

/** 判断是否蓝奏云系域名（lanzou* 全系子域 / lanpv / lanzn / lanso / lanpw / woozooo 等） */
function moe_update_lz_is($host)
{
    $host = strtolower((string)$host);
    if ($host === '') return false;
    if (strpos($host, 'lanzou') !== false || strpos($host, 'woozooo') !== false) return true;
    return (bool)preg_match('/^lan[a-z]{1,4}\.(com|net|cc|org|vip|top)$/i', $host);
}

/** 从更新地址中拆出提取码：支持 ?pwd=xxx / &pwd=xxx，以及尾部「密码/提取码/访问码: xxxx」（可紧跟链接、也可带空格）与「 pwd xxxx」，返回纯链接 */
function moe_update_lz_split($url, &$pwd)
{
    $pwd = '';
    $url = trim((string)$url);
    if (preg_match('~[?&](?:pwd|psw)=([0-9A-Za-z@#%!._-]{1,24})~i', $url, $m)) {
        $pwd = $m[1];
        $url = preg_replace('~[?&](?:pwd|psw)=[0-9A-Za-z@#%!._-]{1,24}~i', '', $url);
    }
    if ($pwd === '') {
        /* 中文标记（密码/提取码/访问码）允许紧跟链接末尾，也可带空格；纯 pwd 关键词须带空白或冒号，避免误吞链接里的字符 */
        if (preg_match('~(?:密码|提取码|访问码)\s*[:：]?\s*([0-9A-Za-z]{2,16})\s*$~iu', $url, $m2)) {
            $pwd = $m2[1];
            $url = preg_replace('~(?:密码|提取码|访问码)\s*[:：]?\s*[0-9A-Za-z]{2,16}\s*$~iu', '', $url);
        } elseif (preg_match('~(?:\s+|[:：=])pwd\s*[:：]?\s*([0-9A-Za-z]{2,16})\s*$~iu', $url, $m3)) {
            $pwd = $m3[1];
            $url = preg_replace('~(?:\s+|[:：=])pwd\s*[:：]?\s*[0-9A-Za-z]{2,16}\s*$~iu', '', $url);
        }
    }
    return trim($url);
}

/** 阿里云盾 acw_sc__v2 挑战求解（蓝奏云部分节点启用） */
function moe_update_lz_acw($html)
{
    if (!preg_match("/arg1='([0-9A-Z]+)'/", $html, $m)) return '';
    $arg1 = $m[1];
    $box = array(15, 35, 29, 24, 33, 16, 1, 38, 10, 9, 19, 31, 40, 27, 22, 23, 25, 13, 6, 11, 39, 18, 20, 8,
                 14, 21, 32, 26, 2, 30, 7, 4, 17, 5, 3, 28, 34, 37, 12, 36);
    $out = array_fill(0, count($box), '');
    for ($i = 0, $len = strlen($arg1); $i < $len; $i++) {
        for ($j = 0; $j < count($box); $j++) {
            if ($box[$j] === $i + 1) { $out[$j] = $arg1[$i]; break; }
        }
    }
    $uns = implode('', $out);
    $key = '3000176000856006061501533003690027800375';
    $res = '';
    $max = min(strlen($uns), strlen($key));
    for ($i = 0; $i < $max; $i += 2) {
        $v = dechex(hexdec(substr($uns, $i, 2)) ^ hexdec(substr($key, $i, 2)));
        $res .= strlen($v) === 1 ? '0' . $v : $v;
    }
    return $res;
}

/**
 * 2.2.18 · 更新链路统一 curl 执行：SSL 证书校验失败时自动降级重试一次。
 * 部分服务器 CA 证书包不全，或更新源（如个人站）证书链含自签名节点，
 * curl 会报「SSL certificate problem: self signed certificate in certificate chain」——
 * 先严格校验，失败才降级（仅限本次请求），兼顾安全与可用。
 */
function moe_update_curl_exec($ch, &$insecure = null)
{
    $body = @curl_exec($ch);
    if ($body === false) {
        $cerr = (string)curl_error($ch);
        if (stripos($cerr, 'SSL certificate problem') !== false
            || (stripos($cerr, 'SSL') !== false && stripos($cerr, 'certificate') !== false)) {
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            $body = @curl_exec($ch);
            if ($body !== false && $insecure !== null) $insecure = true;
        }
    }
    return $body;
}

/** 蓝奏云请求封装：cookie 持久化 + 手动跟随最多 5 跳重定向 + 自动过 acw 盾重试一次；返回 body 或 '' */
function moe_update_lz_http($url, $post = null, $referer = '', $jar = '')
{
    $hdr = array(
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
    );
    if ($post !== null) {
        $hdr[] = 'Content-Type: application/x-www-form-urlencoded';
        $hdr[] = 'Referer: ' . $referer;
    }
    for ($try = 0; $try < 2; $try++) {
        $body = ''; $code = 0;
        for ($hop = 0, $u = $url; $hop < 3; $hop++) {
            $ch = curl_init();
            $opts = array(
                CURLOPT_URL            => $u,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_HEADER         => true,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_CONNECTTIMEOUT => 6,
                CURLOPT_TIMEOUT        => 12,
                CURLOPT_HTTPHEADER     => $hdr,
            );
            if ($jar !== '') { $opts[CURLOPT_COOKIEJAR] = $jar; $opts[CURLOPT_COOKIEFILE] = $jar; }
            if ($post !== null) {
                $opts[CURLOPT_POST] = true;
                $opts[CURLOPT_POSTFIELDS] = is_array($post) ? http_build_query($post) : $post;
                $opts[CURLOPT_REFERER] = $referer;
            }
            curl_setopt_array($ch, $opts);
            $raw  = moe_update_curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($raw === false || $raw === '' || $code === 0) return '';
            if ($code >= 300 && $code < 400 && preg_match('/(?im)^Location:\\s*(\\S+)/', $raw, $lm)) {
                $loc = trim($lm[1]);
                if (strpos($loc, 'http') !== 0) {
                    $p = parse_url($u);
                    $loc = (string)($p['scheme'] ?? 'https') . '://' . (string)($p['host'] ?? '') . '/' . ltrim($loc, '/');
                }
                $u = $loc;                                  // 手动跟随重定向（最多 5 跳）
                continue;
            }
            $body = preg_match('/\\r?\\n\\r?\\n(.*)$/s', $raw, $bm) ? $bm[1] : $raw;
            break;
        }
        if ($body === '' || $code === 0) return '';
        if (strpos($body, 'arg1=') !== false && strpos($body, 'acw_sc__v2') !== false) {
            $ck = moe_update_lz_acw($body);
            if ($ck !== '' && $jar !== '') {
                $host = (string)parse_url($url, PHP_URL_HOST);
                @file_put_contents($jar, "# Netscape HTTP Cookie File\n{$host}\tFALSE\t/\tFALSE\t0\tacw_sc__v2\t{$ck}\n" .
                    '.' . implode('.', array_slice(explode('.', $host), -2)) . "\tTRUE\t/\tFALSE\t0\tacw_sc__v2\t{$ck}\n", FILE_APPEND);
                continue;                                  // 带新 cookie 重试一次
            }
            return '';
        }
        return $body;
    }
    return '';
}

/** 解析蓝奏云单文件分享链接（含提取码）为临时直链；失败返回 false 并带 $err */
function moe_update_lz_resolve($shareUrl, $pwd, &$err)
{
    $err = '';
    if (!function_exists('curl_init')) { $err = '解析蓝奏云链接需要服务器开启 curl 扩展'; return false; }
    $jar = tempnam(sys_get_temp_dir(), 'lzjar_');
    $host = (string)parse_url($shareUrl, PHP_URL_HOST);
    $fail = function ($msg) use ($jar, &$err) { @unlink($jar); $err = $msg; return false; };

    $html = moe_update_lz_http($shareUrl, null, '', $jar);
    if ($html === '') return $fail('无法访问蓝奏云分享页（网络超时或节点异常，可稍后重试）');
    if (strpos($html, '文件取消分享了') !== false || strpos($html, '文件不存在') !== false) {
        return $fail('该蓝奏云分享已取消或文件不存在');
    }
    // 文件夹分享不支持：更新包请分享单个 zip 文件
    if (strpos($html, 'filemoreajax.php') !== false
        || preg_match('~/b[0-9A-Za-z]+/?$~', (string)parse_url($shareUrl, PHP_URL_PATH))) {
        return $fail('这是蓝奏云文件夹分享，请分享单个 zip 文件的链接');
    }

    $resp = '';
    if (strpos($html, 'function down_p()') !== false || strpos($html, 'id="pwd"') !== false || strpos($html, 'passwddiv') !== false) {
        /* ---------- 带提取码：sign + pwd 走 ajaxfile ---------- */
        if ($pwd === '') {
            return $fail('该蓝奏云链接需要提取码：请在地址后面加上提取码（如「https://xxx.lanzoue.com/xxxx密码:abcd」，密码可直接紧跟链接，或用「?pwd=abcd」）');
        }
        $sign = '';
        foreach (array('isngis', 'skdklds', 'v3c') as $v) {
            if (preg_match_all("~var\\s+{$v}\\s*=\\s*'([^']*)'~", $html, $ms)) {
                foreach ($ms[1] as $c) { if (strlen($c) > 10) $sign = $c; }
            }
        }
        if ($sign === '' && preg_match_all("~'sign'\\s*:\\s*'([^']+)'~", $html, $ms)) {
            foreach ($ms[1] as $c) { if (strlen($c) > 10) $sign = $c; }
        }
        $fid = (preg_match('~ajax(?:file|m)\\.php\\?file=(\\d+)~', $html, $fm)) ? $fm[1] : '';
        if ($sign === '' || $fid === '') return $fail('蓝奏云解析失败：无法提取签名参数（接口可能已变更）');
        $api = (preg_match("~https://apifile\\.[a-z0-9.]+/ajaxfile\\.php\\?file={$fid}~", $html, $am)) ? $am[0]
             : 'https://apifile.woozooo.com/ajaxfile.php?file=' . $fid;
        $resp = moe_update_lz_http($api, array('action' => 'downprocess', 'sign' => $sign, 'p' => $pwd, 'kd' => 1), $shareUrl, $jar);
    } else {
        /* ---------- 无提取码：iframe → wp_sign/ajaxdata → ajaxfile ---------- */
        if (!preg_match('~<iframe[^>]+src="(/[^"]+)"~i', $html, $iframe)) {
            return $fail('蓝奏云解析失败：未找到下载页 iframe（接口可能已变更）');
        }
        $iframeUrl = 'https://' . $host . '/' . ltrim($iframe[1], '/');
        $html2 = moe_update_lz_http($iframeUrl, null, '', $jar);
        if ($html2 === '') return $fail('获取蓝奏云下载页失败（可稍后重试）');
        preg_match("~var wp_sign = '([^']*)'~", $html2, $wpSign);
        preg_match("~var ajaxdata = '([^']*)'~", $html2, $ajaxdata);
        preg_match("~var aihidcms = '([^']*)'~", $html2, $websign);
        $fid = (preg_match('~ajax(?:file|m)\\.php\\?file=(\\d+)~', $html2, $fm)) ? $fm[1] : '';
        if (empty($wpSign[1]) || $fid === '') return $fail('蓝奏云解析失败：无法提取下载参数（接口可能已变更）');
        $api = (preg_match("~https://apifile\\.[a-z0-9.]+/ajaxfile\\.php\\?file={$fid}~", $html2, $am)) ? $am[0]
             : 'https://apifile.woozooo.com/ajaxfile.php?file=' . $fid;
        $sg = isset($ajaxdata[1]) ? $ajaxdata[1] : '?ctdf';
        $resp = moe_update_lz_http($api, array(
            'action' => 'downprocess', 'websignkey' => $sg, 'signs' => $sg,
            'sign' => $wpSign[1], 'websign' => isset($websign[1]) ? $websign[1] : '', 'kd' => 1, 'ves' => 1,
        ), $shareUrl, $jar);
    }

    $j = json_decode($resp, true);
    if (!is_array($j)) return $fail('蓝奏云解析失败：接口返回异常（可稍后重试）');
    if ((string)($j['url'] ?? '') === '0' || (int)($j['zt'] ?? 0) !== 1) {
        $info = (string)($j['inf'] ?? ($j['info'] ?? ''));
        if ($info !== '' && $info !== '文件') return $fail('蓝奏云：' . $info . ($pwd !== '' && strpos($info, '密码') !== false ? '（请核对提取码）' : ''));
        return $fail('蓝奏云解析失败' . ($pwd !== '' ? '：请核对提取码是否正确' : ''));
    }
    $link = rtrim((string)$j['dom'], '/') . '/file/' . (string)$j['url'];

    /* 请求直链拿最终跳转地址（最多 2 次 acw 盾重试），拿不到 Location 就直接用原直链 */
    $final = '';
    $hdr = array(
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
        'Referer: ' . $shareUrl,
    );
    for ($try = 0; $try < 2; $try++) {
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $link, CURLOPT_RETURNTRANSFER => true, CURLOPT_HEADER => true,
            CURLOPT_NOBODY => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 20, CURLOPT_HTTPHEADER => $hdr,
            CURLOPT_COOKIEJAR => $jar, CURLOPT_COOKIEFILE => $jar,
        ));
        $raw = @curl_exec($ch);
        curl_close($ch);
        if (is_string($raw) && preg_match('/(?im)^Location:\\s*(\\S+)/', $raw, $lm)) {
            $final = trim($lm[1]);
            if (strpos($final, 'http') !== 0) $final = 'https://' . (string)parse_url($link, PHP_URL_HOST) . '/' . ltrim($final, '/');
            break;
        }
        $body = is_string($raw) && preg_match('/\\r?\\n\\r?\\n(.*)$/s', $raw, $bm) ? $bm[1] : '';
        if ($body === '' || strpos($body, 'arg1=') === false || strpos($body, 'acw_sc__v2') === false) break;
        $ck = moe_update_lz_acw($body);
        if ($ck === '') break;
        @file_put_contents($jar, "# Netscape HTTP Cookie File\n" . (string)parse_url($link, PHP_URL_HOST) . "\tFALSE\t/\tFALSE\t0\tacw_sc__v2\t{$ck}\n", FILE_APPEND);
    }
    /* 2.2.17：保留 cookie jar 供下载阶段复用——解析与下载若分成两次会话，
       文件服务器同盾（acw）时无 cookie 会拿到 HTML 盾页，导致误报「不是 zip 文件」 */
    if ($final === '' || strpos($final, 'http') !== 0) $final = $link;
    return array('url' => $final, 'referer' => $shareUrl, 'jar' => $jar);
}

/* ================= 微云分享解析（2.2.17，免登录流程，2026-11 实测可用） ================= */

/** 是否微云分享域名 */
function moe_update_wy_is($host)
{
    $host = strtolower(trim((string)$host));
    return $host !== '' && preg_match('/(^|\\.)weiyun\\.com$/', $host) === 1;
}

/** 微云接口封装：POST webapp/json/weiyunShareNoLogin/<method>，返回 body 或 '' */
function moe_update_wy_post($method, $payload, $tok, $referer, $jar, $ua)
{
    $ch = curl_init();
    curl_setopt_array($ch, array(
        CURLOPT_URL            => 'https://share.weiyun.com/webapp/json/weiyunShareNoLogin/' . $method
            . '?refer=chrome_windows&g_tk=' . urlencode($tok) . '&r=' . (mt_rand(1000, 9999) / 10000),
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 6,
        CURLOPT_TIMEOUT        => 15,
        CURLOPT_HTTPHEADER     => array('Content-Type: application/json;charset=UTF-8'),
        CURLOPT_REFERER        => $referer,
        CURLOPT_USERAGENT      => $ua,
        CURLOPT_COOKIEJAR      => $jar,
        CURLOPT_COOKIEFILE     => $jar,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ));
    $body = moe_update_curl_exec($ch);
    curl_close($ch);
    return is_string($body) ? $body : '';
}

/** 微云 req_header（接口要求 req_header / req_body 均为字符串化 JSON） */
function moe_update_wy_req_header($cmd)
{
    return json_encode(array(
        'seq' => (int)(microtime(true) * 1000), 'type' => 1, 'cmd' => $cmd, 'appid' => 30013,
        'version' => 3, 'major_version' => 3, 'minor_version' => 3, 'fix_version' => 3,
        'wx_openid' => '', 'user_flag' => 0, 'device_info' => '{"browser":"chrome"}',
    ), JSON_UNESCAPED_SLASHES);
}

/** 从文本（分享页内嵌 JSON 或接口响应）中提取微云文件参数 */
function moe_update_wy_pick_file($txt, &$fileId, &$pdirKey, &$fileName, &$fsize)
{
    if (preg_match('~"file_id"\\s*:\\s*"([0-9a-f\\-]{16,64})"~i', $txt, $m)) $fileId = $m[1];
    if (preg_match('~"pdir_key"\\s*:\\s*"([0-9a-f]{16,64})"~i', $txt, $m)) $pdirKey = $m[1];
    if (preg_match('~"file_name"\\s*:\\s*"([^"]+)"~', $txt, $m)) $fileName = $m[1];
    if (preg_match('~"file_size"\\s*:\\s*(\\d+)~', $txt, $m)) $fsize = (int)$m[1];
}

/**
 * 解析微云单文件分享链接为临时直链；失败返回 false 并带 $err。
 * ① GET 分享页留存 wyctoken 会话，页面内嵌 JSON 含 share_key / file_id / pdir_key / file_name / file_size
 * ② 带 wyctoken 调 weiyunShareNoLogin/WeiyunSharePartDownload（cmd 12023）
 * ③ 响应 data.rsp_body.RspMsg_body.https_download_url 即临时直链（实测无需 cookie 可直接下载）
 * 带访问密码的分享：页面不含文件信息，先调 WeiyunShareView 验证密码（尽力兼容）。
 */
function moe_update_wy_resolve($shareUrl, $pwd, &$err)
{
    $err = '';
    if (!function_exists('curl_init')) { $err = '解析微云链接需要服务器开启 curl 扩展'; return false; }
    $ua  = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
    $jar = tempnam(sys_get_temp_dir(), 'wyjar_');
    $fail = function ($msg) use ($jar, &$err) { @unlink($jar); $err = $msg; return false; };

    /* ① 分享页（手动跟随重定向，留存 cookie）
       关键：wyctoken 是会话级 cookie（Set-Cookie 不带 Expires），libcurl 不会把它写进 cookie jar，
       必须直接从响应头抓取，再手动补写进 jar 供后续接口请求使用 */
    $u = trim((string)$shareUrl);
    $html = '';
    $tok = '';
    for ($hop = 0; $hop < 2 && $u !== ''; $hop++) {
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL            => $u,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER         => true,          // 头体一起拿：wyctoken 在 Set-Cookie 响应头里
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_TIMEOUT        => 12,
            CURLOPT_USERAGENT      => $ua,
            CURLOPT_COOKIEJAR      => $jar,
            CURLOPT_COOKIEFILE     => $jar,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ));
        $raw = moe_update_curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $loc  = (string)curl_getinfo($ch, CURLINFO_REDIRECT_URL);
        $hsz  = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);
        if ($raw === false || $raw === '' || $code === 0) return $fail('无法访问微云分享页（网络超时，可稍后重试）');
        /* 头体切分：优先按 HEADER_SIZE，异常时按首个空行切 */
        $hs = $hsz > 0 && $hsz < strlen($raw) ? $hsz : strpos($raw, "\r\n\r\n");
        if ($hs === false || $hs <= 0) $hs = 0;
        $hdrs  = (string)substr($raw, 0, $hs);
        $body  = (string)substr($raw, $hs);
        if ($tok === '' && preg_match('~(?i)Set-Cookie:\\s*wyctoken=([0-9A-Za-z_\\-]+)~', $hdrs, $tm)) {
            $tok = $tm[1];
            /* 手动补写进 cookie jar（Netscape 格式），后续接口请求自动带上 */
            @file_put_contents($jar, "# Netscape HTTP Cookie File\nshare.weiyun.com\tFALSE\t/\tFALSE\t0\twyctoken\t{$tok}\n"
                . ".weiyun.com\tTRUE\t/\tFALSE\t0\twyctoken\t{$tok}\n", FILE_APPEND);
        }
        if ($code >= 300 && $code < 400 && $loc !== '') { $u = $loc; continue; }
        $html = $body;
        break;
    }
    if (strpos($html, '分享已过期') !== false || strpos($html, '文件已删除') !== false || strpos($html, '分享不存在') !== false) {
        return $fail('该微云分享已过期或文件已删除');
    }
    $shareKey = trim((string)parse_url($u, PHP_URL_PATH), '/');
    if ($shareKey === '' || strlen($shareKey) > 64) return $fail('微云分享链接格式不正确');

    /* 兜底：老版本 jar 里恰好留有 wyctoken 时也可用 */
    if ($tok === '' && is_file($jar)) {
        $jarTxt = (string)@file_get_contents($jar);
        if (preg_match('~wyctoken\\s+(\\S+)~', $jarTxt, $m)) $tok = trim($m[1]);
    }

    /* ② 提取文件参数；没有则尝试密码验证流程 */
    $fileId = ''; $pdirKey = ''; $fileName = ''; $fsize = 0;
    moe_update_wy_pick_file($html, $fileId, $pdirKey, $fileName, $fsize);
    if ($fileId === '' || $pdirKey === '') {
        if ($pwd === '') {
            return $fail('该微云链接需要访问密码：请把密码填到资源的「下载密码」栏，或在地址后附加「密码:xxxx」');
        }
        if ($tok === '') return $fail('微云解析失败：未获取到会话令牌（服务器网络无法取到微云下发的 cookie，可稍后重试；多次失败请改用蓝奏云或媒体库直链）');
        $viewBody = json_encode(array(
            'req_header' => moe_update_wy_req_header(12002),
            'req_body'   => json_encode(array('ReqMsg_body' => array(
                'ext_req_head' => array(
                    'token_info'    => array('token_type' => 0, 'login_key_type' => 1, 'login_key_value' => ''),
                    'language_info' => array('language_type' => 2052),
                ),
                'share_pwd'  => $pwd,
                'share_key'  => $shareKey,
            )), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ), JSON_UNESCAPED_UNICODE);
        $resp = moe_update_wy_post('WeiyunShareView', $viewBody, $tok, $u, $jar, $ua);
        $j = json_decode($resp, true);
        $ret = is_array($j) ? (int)($j['data']['rsp_header']['retcode'] ?? -1) : -1;
        if ($ret !== 0) return $fail('微云访问密码不正确或分享已失效');
        moe_update_wy_pick_file((string)json_encode($j, JSON_UNESCAPED_UNICODE), $fileId, $pdirKey, $fileName, $fsize);
        if ($fileId === '' || $pdirKey === '') {
            return $fail('微云解析失败：密码验证通过但未取得文件参数（若是文件夹分享，请分享单个 zip 文件）');
        }
    }
    if ($tok === '') return $fail('微云解析失败：未获取到会话令牌（可稍后重试）');

    /* ③ PartDownload 换直链 */
    $dlBody = json_encode(array(
        'req_header' => moe_update_wy_req_header(12023),
        'req_body'   => json_encode(array('ReqMsg_body' => array(
            'ext_req_head' => array(
                'token_info'    => array('token_type' => 0, 'login_key_type' => 1, 'login_key_value' => ''),
                'language_info' => array('language_type' => 2052),
            ),
            '.weiyun.WeiyunSharePartDownloadMsgReq_body' => array(
                'share_key'     => $shareKey,
                'pwd'           => $pwd,
                'file_owner'    => null,
                'download_type' => 0,
                'file_list'     => array(array(
                    'pdir_key'  => $pdirKey,
                    'file_id'   => $fileId,
                    'filename'  => $fileName !== '' ? $fileName : 'file.zip',
                    'file_size' => $fsize,
                )),
            ),
        )), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ), JSON_UNESCAPED_UNICODE);
    $resp = moe_update_wy_post('WeiyunSharePartDownload', $dlBody, $tok, $u, $jar, $ua);
    $j = json_decode($resp, true);
    if (!is_array($j)) return $fail('微云解析失败：接口返回异常（可稍后重试）');
    $ret = (int)($j['data']['rsp_header']['retcode'] ?? -1);
    $dl  = (string)($j['data']['rsp_body']['RspMsg_body']['https_download_url'] ?? '');
    if ($ret !== 0 || $dl === '') {
        $msg = (string)($j['msg'] ?? '');
        return $fail('微云解析失败' . ($msg !== '' ? '：' . $msg : '（接口返回异常，可稍后重试）'));
    }
    /* 保留解析会话 cookie（jar 由 moe_update_download 传输后统一删除），下载阶段复用 */
    return array('url' => $dl, 'referer' => $shareUrl, 'jar' => $jar);
}

/** 下载远程更新包到临时文件（30MB 上限、校验 zip 魔数；2.2.14 蓝奏云 / 2.2.17 微云 + 资源密码字段 + 百度网盘提示） */
function moe_update_download($url, $dest, &$err, $opts = array())
{
    $err = '';
    $max = 30 * 1024 * 1024;
    $ua  = 'MoeZ/' . MOE_VERSION;
    /* 网盘分享链接：先解析成临时直链再走常规下载（2.2.14 蓝奏云 / 2.2.17 微云、密码字段、百度网盘提示）
       密码优先级：地址里附加的（密码:xxx / ?pwd=xxx）> 资源「下载密码」字段（opts['pwd']） */
    $host   = strtolower((string)parse_url(trim((string)$url), PHP_URL_HOST));
    $optPwd = trim((string)($opts['pwd'] ?? ''));
    $meta   = false;
    if (moe_update_lz_is($host)) {
        $pwd  = '';
        $pure = moe_update_lz_split((string)$url, $pwd);
        if ($pwd === '') $pwd = $optPwd;
        $meta = moe_update_lz_resolve($pure, $pwd, $err);
        if ($meta === false) return false;
    } elseif (moe_update_wy_is($host)) {
        $pwd  = '';
        $pure = moe_update_lz_split((string)$url, $pwd);   // 通用「密码:xxx / ?pwd=xxx」拆分
        if ($pwd === '') $pwd = $optPwd;
        $meta = moe_update_wy_resolve($pure, $pwd, $err);
        if ($meta === false) return false;
    } elseif ($host !== '' && preg_match('/(^|\\.)pan\\.baidu\\.com$/', $host) === 1) {
        $err = '百度网盘分享链接无法在服务器端直接下载（需要登录账号与客户端，且有下载加速限制）。'
             . '请改用蓝奏云、微云分享链接，或把 zip 上传到媒体库后填直链。';
        return false;
    }
    if (is_array($meta)) {
        $url  = $meta['url'];
        $opts['referer'] = $opts['referer'] ?? $meta['referer'];
        $opts['follow']  = true;
        $opts['ua']      = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
    }
    $dlJar    = is_array($meta) ? (string)($meta['jar'] ?? '') : '';   // 解析会话的 cookie，下载阶段复用（过盾）
    $follow   = !empty($opts['follow']);
    $referer  = (string)($opts['referer'] ?? '');
    $forceUa  = (string)($opts['ua'] ?? '');
    if (function_exists('curl_init')) {
        /* 两段式：第一次用程序 UA；若拿到的是网页（源站 / CDN 对非浏览器身份返回防护页），
           第二次自动换浏览器 UA + Accept 头重试。每次失败都带诊断信息（状态 / 类型 / 大小 / 开头字节）。 */
        $diag = ''; $magic = '';
        for ($attempt = 0; $attempt < 2; $attempt++) {
            $fp = @fopen($dest, 'wb');
            if (!$fp) { $err = '无法创建临时文件'; return false; }
            $size = 0; $tooBig = false; $sslInsecure = false;
            $browser = ($attempt === 1);
            $ch = curl_init();
            curl_setopt_array($ch, array(
                CURLOPT_URL            => $url,
                CURLOPT_FOLLOWLOCATION => $follow,
                CURLOPT_MAXREDIRS      => $follow ? 6 : 0,
                CURLOPT_CONNECTTIMEOUT => 6,
                CURLOPT_TIMEOUT        => $follow ? 150 : 90,   // 网盘直链走外网 CDN，放宽到 150s（调用方已 set_time_limit 300）
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_ENCODING       => '',   // 支持 gzip/deflate 并自动解码，防止中间层压缩导致魔数失真
                CURLOPT_USERAGENT      => $browser
                    ? 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
                    : ($forceUa !== '' ? $forceUa : $ua),
            ));
            if ($browser) {
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
                ));
            }
            if ($referer !== '') curl_setopt($ch, CURLOPT_REFERER, $referer);
            if ($dlJar !== '' && is_file($dlJar)) curl_setopt($ch, CURLOPT_COOKIEFILE, $dlJar);
            curl_setopt($ch, CURLOPT_WRITEFUNCTION, function ($h, $chunk) use ($fp, &$size, $max, &$tooBig) {
                $size += strlen($chunk);
                if ($size > $max) { $tooBig = true; return 0; }
                return fwrite($fp, $chunk);
            });
            $ok   = @curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $ctype = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
            if ($ok === false) {
                $cerr1 = (string)curl_error($ch);
                if (stripos($cerr1, 'SSL certificate problem') !== false
                    || (stripos($cerr1, 'SSL') !== false && stripos($cerr1, 'certificate') !== false)) {
                    /* 证书链有问题（自签名 / CA 不全）：降级重试一次，先清空半途写入的数据 */
                    rewind($fp); ftruncate($fp, 0); $size = 0; $tooBig = false;
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    $ok = @curl_exec($ch);
                    if ($ok !== false) {
                        $sslInsecure = true;
                        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                        $ctype = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
                    }
                }
            }
            $cerr = $ok === false ? curl_error($ch) : '';
            curl_close($ch);
            fclose($fp);
            if ($tooBig) { @unlink($dest); $err = '更新包超过 30MB 限制'; return false; }
            if ($ok === false) { @unlink($dest); $err = '下载失败：' . ($cerr !== '' ? $cerr : '连接被中断'); return false; }
            if ($code !== 200) { @unlink($dest); $err = '下载失败：更新源返回 HTTP ' . $code; return false; }
            /* 魔数检查：PK → 成功；否则记录诊断，HTML 时换浏览器身份重试一次 */
            $head = '';
            if (is_file($dest) && filesize($dest) >= 2) {
                $h = @fopen($dest, 'rb');
                $head = $h ? (string)fread($h, 64) : '';
                if ($h) fclose($h);
            }
            if (substr($head, 0, 2) === 'PK') { $magic = 'PK'; break; }
            $snip = str_replace(array("\r", "\n", "\t"), array('', ' ', ' '), trim((string)substr($head, 0, 24)));
            $diag = 'HTTP ' . $code
                . ($ctype !== '' ? '，返回类型「' . trim($ctype) . '」' : '')
                . (is_file($dest) ? '，大小 ' . filesize($dest) . 'B' : '')
                . ($snip !== '' ? '，内容开头「' . $snip . '」' : '，内容为空');
            @unlink($dest);
            if ($attempt === 0 && (strpos(ltrim((string)$head), '<') === 0 || stripos($ctype, 'text/html') !== false)) {
                continue;   // 返回的是网页（防护挑战页常见）：换浏览器身份再试一次
            }
            break;
        }
        if ($dlJar !== '') @unlink($dlJar);   // cookie 仅传输阶段需要
        if ($magic !== 'PK') {
            $err = '下载地址返回的不是 zip 文件' . ($diag !== '' ? '（' . $diag . '）' : '')
                 . '。若是网盘分享链接，多为解析未拿到真实直链（或密码不对拿到的仍是网页），请核对下载地址与「下载密码」；'
                 . '若是直链，请确认指向 .zip 包；若内容开头是网页，多为源站对服务器有 UA / IP 防护，建议改用媒体库直链';
            return false;
        }
    } else {
        $ctx = stream_context_create(array('http' => array(
            'timeout' => 60, 'follow_location' => 0, 'user_agent' => $ua,
        )));
        $in = @fopen($url, 'rb', false, $ctx);
        if (!$in) { $err = '下载失败（请检查地址，或开启 allow_url_fopen / curl）'; return false; }
        $out = @fopen($dest, 'wb');
        if (!$out) { fclose($in); $err = '无法创建临时文件'; return false; }
        $size = 0; $tooBig = false;
        while (!feof($in)) {
            $chunk = fread($in, 65536);
            if ($chunk === false) break;
            $size += strlen($chunk);
            if ($size > $max) { $tooBig = true; break; }
            fwrite($out, $chunk);
        }
        fclose($in); fclose($out);
        if ($tooBig) { @unlink($dest); $err = '更新包超过 30MB 限制'; return false; }
    }
    if (!is_file($dest) || filesize($dest) < 4) { @unlink($dest); $err = '更新包内容为空'; return false; }
    if (!function_exists('curl_init')) {
        $h = @fopen($dest, 'rb');
        $magic = $h ? (string)fread($h, 2) : '';
        if ($h) fclose($h);
        if ($magic !== 'PK') {
            @unlink($dest);
            $err = '下载地址返回的不是 zip 文件。若是网盘分享链接，多为解析未拿到真实直链（或密码不对拿到的仍是网页），'
                 . '请核对下载地址与「下载密码」；若是直链，请确认指向 .zip 包';
            return false;
        }
    }
    return true;
}

/** 失败回滚：把已写入的文件按备份还原，新建的文件删除 */
function moe_update_rollback($backupDir, $written)
{
    $n = 0;
    foreach ($written as $p) {
        $dest = MOE_ROOT . '/' . $p;
        $bak  = $backupDir . '/files/' . $p;
        if (is_file($bak)) { if (@copy($bak, $dest)) $n++; }
        else { @unlink($dest); $n++; }
    }
    return $n;
}

/**
 * 应用官方覆盖包（在线下载或本地上传的 zip 共用）
 * 返回 array(ok, msg, steps, version, backup, files, rolled_back)
 */
function moe_update_apply_zip($zipFile, $origin = 'upload')
{
    $steps = array();
    $fail = function ($msg, $rolled = 0) use (&$steps) {
        return array('ok' => 0, 'msg' => $msg, 'steps' => $steps, 'rolled_back' => $rolled);
    };
    $log = function ($s) use (&$steps) { $steps[] = $s; };

    if (!class_exists('ZipArchive')) {
        return $fail('PHP 未开启 zip 扩展，请在宝塔「软件商店 → PHP 设置 → 安装扩展」开启 zip 后重试');
    }
    $za = new ZipArchive();
    if ($za->open($zipFile) !== true) return $fail('更新包不是有效的 zip 文件，或文件已损坏');

    // ① 读取条目（忽略目录与系统垃圾文件）
    $items = array(); $total = 0; $skipped = 0;
    for ($i = 0; $i < $za->numFiles; $i++) {
        $stat = $za->statIndex($i);
        if (!is_array($stat)) continue;
        $name = str_replace('\\', '/', (string)$stat['name']);
        if (substr($name, -1) === '/') continue;
        $base = basename($name);
        if ($base === '.DS_Store' || strtolower($base) === 'thumbs.db' || strpos($name, '__MACOSX/') === 0) {
            $skipped++; continue;
        }
        $items[] = array('idx' => $i, 'path' => $name, 'size' => (int)$stat['size']);
        $total += (int)$stat['size'];
    }
    if (!$items) { $za->close(); return $fail('更新包里没有可覆盖的文件'); }
    if (count($items) > 2000) { $za->close(); return $fail('更新包文件数超过 2000，疑似不是官方覆盖包'); }
    if ($total > 60 * 1024 * 1024) { $za->close(); return $fail('更新包解压后超过 60MB，已中止'); }
    $log('📦 读取更新包：' . count($items) . ' 个文件 / ' . round($total / 1024, 1) . ' KB'
         . ($skipped ? '（忽略 ' . $skipped . ' 个系统垃圾文件）' : ''));

    // ② 自动剥离一层外层目录（用户手动压缩时常带一层文件夹）
    $firsts = array();
    foreach ($items as $it) { $s = explode('/', $it['path']); $firsts[$s[0]] = 1; }
    $known = array('admin' => 1, 'includes' => 1, 'templates' => 1, 'content' => 1, 'docs' => 1,
                   'api' => 1, 'pay' => 1, 'tools' => 1,
                   'init.php' => 1, 'index.php' => 1, 'install.php' => 1, 'comment.php' => 1,
                   'link.php' => 1, 'version.json' => 1, 'config.php' => 1, 'robots.txt' => 1);
    if (count($firsts) === 1) {
        $only = key($firsts);
        if (!isset($known[$only])) {
            foreach ($items as $k => $it) $items[$k]['path'] = substr($it['path'], strlen($only) + 1);
            $log('📁 检测到外层目录「' . $only . '」，已自动剥离');
        }
    }

    // ③ 路径安全校验（ZipSlip / 受保护数据 / 危险类型）
    $seen = array();
    foreach ($items as $it) {
        $err = '';
        if (!moe_update_safe_path($it['path'], $err)) {
            $za->close();
            return $fail('更新包含不允许的路径：' . $it['path'] . '（' . $err . '），已中止且未覆盖任何文件');
        }
        $key = strtolower($it['path']);
        if (isset($seen[$key])) { $za->close(); return $fail('更新包含重复路径：' . $it['path']); }
        $seen[$key] = 1;
    }

    // ④ 必须含根目录 init.php，且能读出版本号（防误传插件包 / 主题包）
    $initIdx = -1; $newVersion = '';
    foreach ($items as $it) {
        if (strtolower($it['path']) === 'init.php') { $initIdx = $it['idx']; break; }
    }
    if ($initIdx < 0) { $za->close(); return $fail('更新包根目录没有 init.php，可能不是官方覆盖包'); }
    $initSrc = $za->getFromIndex($initIdx);
    if (!is_string($initSrc) || strpos($initSrc, 'MOE_VERSION') === false) {
        $za->close(); return $fail('更新包的 init.php 里没有 MOE_VERSION，可能不是官方覆盖包');
    }
    if (preg_match("/define\\s*\\(\\s*['\"]MOE_VERSION['\"]\\s*,\\s*['\"]([^'\"]+)['\"]\\s*\\)/", $initSrc, $m)) {
        $newVersion = $m[1];
    }
    $log('🔎 校验通过 · 包内版本 v' . ($newVersion !== '' ? $newVersion : '未知') . '（当前 v' . MOE_VERSION . '）');

    // ⑤ 建备份目录
    $werr = '';
    $ws = moe_update_workspace($werr);
    if ($ws === '') { $za->close(); return $fail($werr); }
    $backupName = 'up-' . date('Ymd-His') . '-' . substr(md5(uniqid('', true)), 0, 6);
    $backupDir  = $ws . '/' . $backupName;
    if (!@mkdir($backupDir . '/files', 0755, true) && !is_dir($backupDir . '/files')) {
        $za->close(); return $fail('无法创建备份目录，请检查 content/ 写入权限');
    }
    @file_put_contents($backupDir . '/index.html', '<!doctype html><title>403</title><h1>403 Forbidden</h1>');

    // ⑥ 写入前预检 + 逐文件备份（任一失败都不动线上文件）
    $updated = array(); $created = array();
    foreach ($items as $it) {
        $dest = MOE_ROOT . '/' . $it['path'];
        if (is_file($dest)) {
            if (!moe_update_ensure_writable($dest)) {
                $za->close(); return $fail(moe_update_unwritable_msg($it['path'], '程序文件'));
            }
            $bak = $backupDir . '/files/' . $it['path'];
            if (!is_dir(dirname($bak))) @mkdir(dirname($bak), 0755, true);
            if (!@copy($dest, $bak)) {
                $za->close(); return $fail('备份失败：' . $it['path'] . '，已中止（未覆盖任何文件）');
            }
            $updated[] = $it['path'];
        } else {
            $probe = dirname($dest);
            while (!is_dir($probe) && $probe !== MOE_ROOT && dirname($probe) !== $probe) {
                $probe = dirname($probe);
            }
            if (!moe_update_ensure_writable($probe)) {
                $za->close(); return $fail(moe_update_unwritable_msg($it['path'], '目录'));
            }
            $created[] = $it['path'];
        }
    }
    @file_put_contents($backupDir . '/manifest.json', json_encode(array(
        'time'            => date('Y-m-d H:i:s'),
        'origin'          => $origin,
        'from_version'    => MOE_VERSION,
        'to_version'      => $newVersion,
        'updated'         => $updated,
        'created'         => $created,
        'how_to_rollback' => '把 files/ 下的文件按相同相对路径复制回程序根目录，并删除 created 里列出的新增文件。',
    ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
    $log('🗂 已备份 ' . count($updated) . ' 个将被覆盖的文件 → content/backups/' . $backupName);

    // ⑦ 覆盖写入；任何一步失败立即回滚
    $written = array();
    foreach ($items as $it) {
        $dest = MOE_ROOT . '/' . $it['path'];
        $data = $za->getFromIndex($it['idx']);
        if (!is_string($data)) {
            $n = moe_update_rollback($backupDir, $written);
            $za->close();
            $log('↩️ 已回滚 ' . $n . ' 个文件');
            return $fail('读取更新包内容失败：' . $it['path'], 1);
        }
        $written[] = $it['path'];
        if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0755, true);
        $okWrite = @file_put_contents($dest, $data, LOCK_EX);
        if ($okWrite === false || $okWrite !== strlen($data)) {
            $n = moe_update_rollback($backupDir, $written);
            $za->close();
            $log('↩️ 已回滚 ' . $n . ' 个文件');
            return $fail('写入失败：' . $it['path'] . '（请检查磁盘空间与权限）', 1);
        }
    }
    $za->close();
    $log('✅ 已覆盖 ' . count($written) . ' 个文件');

    // ⑧ 成功后清理缓存，让新版本与新设置立刻生效
    if (function_exists('setting_set')) {
        setting_set('update_check_cache', '');
        setting_set('update_last_done', json_encode(array(
            'time'   => date('Y-m-d H:i:s'),
            'from'   => MOE_VERSION,
            'to'     => $newVersion,
            'origin' => $origin,
            'backup' => 'content/backups/' . $backupName,
            'files'  => count($written),
        ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }
    if (function_exists('moe_content_changed')) moe_content_changed();
    if (function_exists('opcache_reset')) @opcache_reset();
    $log('🧹 已清除版本检测缓存与页面缓存');

    return array(
        'ok'      => 1,
        'msg'     => '更新完成',
        'steps'   => $steps,
        'version' => $newVersion,
        'backup'  => 'content/backups/' . $backupName,
        'files'   => count($written),
    );
}
