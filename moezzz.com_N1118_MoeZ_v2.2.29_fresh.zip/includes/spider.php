<?php
/**
 * MoeZ - 搜索引擎蜘蛛识别与来访记录
 *
 * 只记录国内主流搜索引擎（百度 / 360 / 搜狗 / 必应）**身份已校验**的蜘蛛：
 *   1) UA 命中上述引擎；
 *   2) 反向 DNS（PTR）落在引擎自有域名下，并正向解析回同一 IP（防止 PTR 伪造）；
 *   3) 反向 DNS 不可用时，退化为「引擎官方 IP 段」白名单判断。
 * UA 伪装（第三方采集器 / 恶意爬虫）与校验不通过的请求一律屏蔽，不写入记录。
 * 任何数据库 / DNS 异常都不影响前台访问。
 */

/** 支持的搜索引擎：UA 特征 / 反向 DNS 后缀 / 官方 IP 段（DNS 不可用时的兜底） */
function moe_spider_engines()
{
    return array(
        '百度' => array(
            'ua'     => '/baiduspider/i',
            'ptr'    => array('.baidu.com', '.baidu.jp'),
            'ranges' => array('180.76.0.0/16', '123.125.0.0/16', '111.206.0.0/16', '220.181.0.0/16', '180.149.0.0/16', '61.135.168.0/24'),
        ),
        '360搜索' => array(
            'ua'     => '/(360spider|haosouspider)/i',
            'ptr'    => array('.360.cn', '.so.com'),
            'ranges' => array(
                '180.153.0.0/16', '180.163.0.0/16',
                '42.236.10.0/24', '42.236.12.0/23', '42.236.14.0/24',
                '42.236.101.0/24', '42.236.102.0/24', '42.236.103.0/24',
            ),
        ),
        '搜狗' => array(
            'ua'     => '/sogou/i',
            'ptr'    => array('.sogou.com', '.sogou-inc.com'),
            'ranges' => array('123.126.0.0/16', '106.120.0.0/16', '49.7.0.0/16'),
        ),
        '必应' => array(
            'ua'     => '/(bingbot|msnbot|adidxbot)/i',
            'ptr'    => array('.search.msn.com', '.msnbot.com', '.bing.com'),
            'ranges' => array('40.77.0.0/16', '13.107.0.0/16', '157.55.0.0/16', '207.46.0.0/16', '199.30.0.0/16', '204.79.197.0/24', '202.89.235.0/24'),
        ),
    );
}

/** 引擎显示图标（后台统一取用） */
function moe_spider_icons()
{
    return array('百度' => '🐾', '360搜索' => '🔄', '搜狗' => '🐕', '必应' => '🅱');
}

/** 根据 UA 识别国内搜索引擎，返回中文名（非目标蜘蛛返回 ''） */
function moe_spider_name($ua = null)
{
    $ua = $ua === null ? (string)($_SERVER['HTTP_USER_AGENT'] ?? '') : (string)$ua;
    if ($ua === '') return '';
    foreach (moe_spider_engines() as $name => $cfg) {
        if (@preg_match($cfg['ua'], $ua)) return $name;
    }
    return '';
}

/**
 * 访客真实 IP
 * 直连时用 REMOTE_ADDR；本机 / 内网地址（常见于 Nginx→Apache 等反向代理）时，
 * 从代理头里取第一个公网 IP，避免把代理本机地址当成蜘蛛 IP
 */
function moe_spider_client_ip()
{
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    $private = function_exists('moe_ip_private') ? moe_ip_private($ip) : ($ip === '');
    if ($private) {
        foreach (array('HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR') as $key) {
            if (empty($_SERVER[$key])) continue;
            foreach (explode(',', (string)$_SERVER[$key]) as $cand) {
                $cand = trim($cand);
                if ($cand === '' || filter_var($cand, FILTER_VALIDATE_IP) === false) continue;
                if (function_exists('moe_ip_private') && moe_ip_private($cand)) continue;
                return $cand;
            }
        }
    }
    return $ip;
}

/** IPv4 是否落在 CIDR 段内（只处理 IPv4） */
function moe_ip_in_cidr($ip, $cidr)
{
    $ip = trim((string)$ip);
    if ($ip === '' || strpos($ip, ':') !== false || strpos($ip, '.') === false) return false;
    $cidr = trim((string)$cidr);
    if ($cidr === '') return false;
    if (strpos($cidr, '/') === false) $cidr .= '/32';
    list($net, $bits) = explode('/', $cidr, 2);
    $bits = (int)$bits;
    if ($bits < 0 || $bits > 32) return false;
    $ipL  = ip2long($ip);
    $netL = ip2long(trim($net));
    if ($ipL === false || $netL === false) return false;
    $ipL  = $ipL & 0xFFFFFFFF;
    $netL = $netL & 0xFFFFFFFF;
    $mask = ($bits === 0) ? 0 : ((-1 << (32 - $bits)) & 0xFFFFFFFF);
    return (($ipL & $mask) === ($netL & $mask));
}

/** IP 是否属于该引擎的官方 IP 段 */
function moe_spider_ip_in_ranges($ip, $engine)
{
    $engines = moe_spider_engines();
    if (!isset($engines[$engine])) return false;
    foreach ($engines[$engine]['ranges'] as $cidr) {
        if (moe_ip_in_cidr($ip, $cidr)) return true;
    }
    return false;
}

/**
 * 反向 DNS + 正向 DNS 双重校验
 * 返回 'ok'（确认是该引擎真实蜘蛛）/ 'bad'（确认伪造）/ 'unknown'（无法判定）
 */
function moe_spider_dns_state($ip, $engine)
{
    $engines = moe_spider_engines();
    if (!isset($engines[$engine])) return 'bad';
    if (!function_exists('gethostbyaddr') || !function_exists('gethostbyname')) return 'unknown';

    $host = '';
    try { $host = (string)@gethostbyaddr($ip); } catch (Throwable $e) { $host = ''; }
    if ($host === '' || strcasecmp($host, (string)$ip) === 0) return 'unknown';   // 没有 PTR 记录

    $hostL = strtolower($host);
    $match = false;
    foreach ($engines[$engine]['ptr'] as $suffix) {
        $suffix = strtolower((string)$suffix);
        if ($suffix !== '' && substr($hostL, -strlen($suffix)) === $suffix) { $match = true; break; }
    }
    if (!$match) return 'bad';   // PTR 落在引擎自有域名之外 → 伪装

    $back = '';
    try { $back = (string)@gethostbyname($host); } catch (Throwable $e) { $back = ''; }
    if ($back === '' || strcasecmp($back, $host) === 0) return 'unknown';   // 正向解析失败
    return strcasecmp($back, (string)$ip) === 0 ? 'ok' : 'bad';
}

/** 带缓存的校验状态（同一 IP 7 天内只做一次 DNS 查询） */
function moe_spider_state($ip, $engine)
{
    $ip = trim((string)$ip);
    if ($ip === '' || filter_var($ip, FILTER_VALIDATE_IP) === false) return 'bad';
    if (function_exists('moe_ip_private') && moe_ip_private($ip)) return 'bad';

    $cached = '';
    try {
        $r = row('SELECT state, checked_at FROM ' . moe_table('spider_check') . ' WHERE ip = ? AND engine = ?', array($ip, $engine));
        if ($r && isset($r['state']) && strtotime((string)$r['checked_at']) > time() - 604800) {
            $cached = (string)$r['state'];
        }
    } catch (Throwable $e) { /* 表未就绪，忽略 */ }
    if (in_array($cached, array('ok', 'bad', 'unknown'), true)) return $cached;

    $state = moe_spider_dns_state($ip, $engine);
    try {
        q('INSERT INTO ' . moe_table('spider_check') . ' (ip, engine, state, checked_at) VALUES (?,?,?,NOW())
           ON DUPLICATE KEY UPDATE state = VALUES(state), checked_at = VALUES(checked_at)', array($ip, $engine, $state));
    } catch (Throwable $e) { /* 忽略：缓存失败不影响判断 */ }
    return $state;
}

/** 写记录用：只有确认是真实蜘蛛才返回 true（DNS 无法判定时用官方 IP 段兜底） */
function moe_spider_verify($ip, $engine)
{
    $state = moe_spider_state($ip, $engine);
    if ($state === 'ok') return true;
    if ($state === 'bad') return false;
    return moe_spider_ip_in_ranges($ip, $engine);
}

/** 清理历史记录用：仅「确认伪造 / 非法 IP」判定为无效，无法判定时保守保留 */
function moe_spider_is_fake($ip, $engine)
{
    return moe_spider_state($ip, $engine) === 'bad';
}

/** 记录一次蜘蛛来访（非目标蜘蛛 / 校验不通过一律静默跳过；任何异常不影响前台访问） */
function moe_spider_log($path = null)
{
    $name = moe_spider_name();
    if ($name === '') return false;

    $ip = moe_spider_client_ip();
    if (!moe_spider_verify($ip, $name)) return false;   // 无效 / 伪装蜘蛛：直接屏蔽

    try {
        if ($path === null) {
            $path = parse_url((string)($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH);
            if ($path === '' || $path === null) $path = '/';
        }
        if (function_exists('mb_substr') && mb_strlen($path, 'UTF-8') > 200) {
            $path = mb_substr($path, 0, 200, 'UTF-8');
        } else {
            $path = substr($path, 0, 200);
        }
        q('INSERT INTO ' . moe_table('spiders') . ' (spider, path, ip, created_at) VALUES (?,?,?,NOW())',
            array($name, (string)$path, $ip));
        return true;
    } catch (Throwable $e) {
        return false;   // 表尚未创建等情况，静默忽略
    }
}