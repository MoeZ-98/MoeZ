<?php
/**
 * MoeZ · 看板娘对话主入口（2.1.18）
 * ------------------------------------------------------------
 * 三条路径，按能力从高到低自动选择：
 *   ai     —— 配了 API 密钥：大模型自由对话 + 站点手册 + 联网搜索（[[SEARCH]]）
 *   web    —— 没配密钥但开了联网：本地答不上来时，直接联网找资料给摘要
 *   local  —— 全部失效时：原有站内意图引擎（最新/热门/分类/搜索…）
 * 返回统一结构：array('text','links','chips','src')
 */

if (!defined('MOE_ROOT')) exit('no direct access');

if (!function_exists('moe_chat_reply')) {

/** 看板娘名字（与模板设置联动，兜底「小星」） */
function moe_chat_name()
{
    $n = '';
    if (function_exists('theme_opt')) {
        $n = trim((string)theme_opt('mascot_name', ''));
    }
    if ($n === '') $n = trim((string)setting('ai_bot_name', ''));
    return $n !== '' ? $n : '小星';
}

/** 站内数据快照：拼进 system prompt，让模型知道这个站有什么（单请求内只查一次） */
function moe_chat_manual()
{
    static $cache = null;
    if ($cache !== null) return $cache;

    $siteName = trim((string)setting('site_name', ''));
    if ($siteName === '') $siteName = '本站';
    $pt = moe_table('posts');
    $ct = moe_table('categories');
    $lines = array();
    $lines[] = '站名：' . $siteName;
    $desc = trim((string)setting('site_description', ''));
    if ($desc === '') $desc = trim((string)setting('site_desc', ''));
    if ($desc !== '') $lines[] = '简介：' . mb_substr($desc, 0, 160, 'UTF-8');

    $total = 0;
    try { $total = (int)one('SELECT COUNT(*) FROM ' . $pt . " WHERE type='post' AND status='published'"); } catch (Throwable $e) {}
    $lines[] = '公开文章：' . $total . ' 篇';

    try {
        $cats = (array)rows('SELECT c.name, (SELECT COUNT(*) FROM ' . $pt . ' p WHERE p.category_id=c.id AND p.type=\'post\' AND p.status=\'published\') AS cnt FROM ' . $ct . ' c ORDER BY c.sort, c.id LIMIT 10');
        if ($cats) {
            $bits = array();
            foreach ($cats as $c) $bits[] = (string)$c['name'] . '(' . (int)$c['cnt'] . ')';
            $lines[] = '分类：' . implode('、', $bits);
        }
    } catch (Throwable $e) {}

    try {
        $latest = (array)rows('SELECT title, slug, id FROM ' . $pt . " WHERE type='post' AND status='published' ORDER BY created_at DESC, id DESC LIMIT 6");
        if ($latest) {
            $bits = array();
            foreach ($latest as $p) {
                $u = function_exists('post_url') ? post_url($p) : base_url() . 'post/' . (int)$p['id'];
                $bits[] = '- ' . (string)$p['title'] . ' → ' . $u;
            }
            $lines[] = "最新文章：\n" . implode("\n", $bits);
        }
    } catch (Throwable $e) {}

    try {
        $hot = (array)rows('SELECT title, slug, id, views FROM ' . $pt . " WHERE type='post' AND status='published' ORDER BY views DESC, id DESC LIMIT 3");
        if ($hot) {
            $bits = array();
            foreach ($hot as $p) {
                $u = function_exists('post_url') ? post_url($p) : base_url() . 'post/' . (int)$p['id'];
                $bits[] = '- ' . (string)$p['title'] . '（' . (int)$p['views'] . ' 次浏览）' . ' → ' . $u;
            }
            $lines[] = "热门文章：\n" . implode("\n", $bits);
        }
    } catch (Throwable $e) {}

    /* 评论规则 */
    $cOn = setting('comment_enabled', '1') === '1';
    $cLogin = setting('user_comment_login', '0') === '1';
    $cEdit = setting('comment_edit', '1') === '1';
    $lines[] = '评论：' . ($cOn ? '已开启' : '当前关闭') . '；' . ($cLogin ? '需要登录后评论' : '可以直接填昵称评论') . '；' . ($cEdit ? '登录后可以编辑自己的评论' : '评论发出后不能修改') . '；评论内容支持 [img]图片地址[/img] 插图';

    /* 积分与下载 */
    $ptOn = function_exists('moe_pt_opt');
    if ($ptOn) {
        $cmtPts = (int)moe_pt_opt('comment', '2');
        $cmtDaily = (int)moe_pt_opt('comment_daily', '3');
        $lines[] = '积分：每日签到得积分；发表评论 +' . $cmtPts . ' 分（每天前 ' . $cmtDaily . ' 条计分）；积分可在「积分商城」兑换资源，兑换后到「我的下载」取文件';
    } else {
        $lines[] = '积分：本站未启用积分功能';
    }

    /* 固定页面与入口 */
    $pages = array(
        '首页' => base_url(),
        '文章归档' => base_url() . 'archives',
        '全部文章' => base_url() . 'blog/article',
        '站内搜索' => base_url() . 'search',
        '友情链接' => base_url() . 'link',
        '关于小站' => base_url() . 'about',
        '用户中心' => base_url() . 'user',
        '积分商城' => base_url() . 'shop',
    );
    $bits = array();
    foreach ($pages as $k => $v) $bits[] = $k . ' ' . $v;
    $lines[] = '主要页面：' . implode('；', $bits);

    try {
        $fn = (int)one('SELECT COUNT(*) FROM ' . moe_table('links') . " WHERE status='approved'");
        if ($fn > 0) $lines[] = '友链：已收录 ' . $fn . ' 个站点，欢迎交换';
    } catch (Throwable $e) {}

    $cache = implode("\n", $lines);
    return $cache;
}

/** 正文 → 干净摘要（去 Markdown/短代码，压空白，截取前 $limit 字） */
function moe_chat_post_summary($content, $limit = 700)
{
    $t = (string)$content;
    if ($t === '') return '';
    $t = preg_replace('/\[img\][^\[\]]*\[\/img\]/iu', '（配图）', $t);
    $t = preg_replace('/```.*?```/su', '（代码示例）', $t);
    $t = preg_replace('/!\[[^\]]*\]\([^)]*\)/u', '', $t);
    $t = preg_replace('/\[([^\]]*)\]\([^)]*\)/u', '$1', $t);
    $t = preg_replace('/^[\s>#*\-+|]+/mu', '', $t);
    $t = str_replace(array('*', '_', '`'), '', $t);
    if (function_exists('strip_tags')) $t = strip_tags($t);
    $t = trim(preg_replace('/\s+/u', ' ', $t));
    return mb_substr($t, 0, $limit, 'UTF-8');
}

/** 从访客正在浏览的 URL 反查文章（仅本站已发布文章），返回 array('title','url','summary') 或 null */
function moe_chat_ctx_post($ctx)
{
    $url = isset($ctx['url']) ? trim((string)$ctx['url']) : '';
    if ($url === '') return null;
    $host = (string)parse_url($url, PHP_URL_HOST);
    $siteHost = (string)parse_url(base_url(), PHP_URL_HOST);
    /* 只认本站地址 */
    if ($siteHost !== '' && $host !== '' && stripos($host, $siteHost) === false) return null;

    $path = (string)parse_url($url, PHP_URL_PATH);
    $base = (string)parse_url(base_url(), PHP_URL_PATH);
    if ($base !== '' && $base !== '/' && strpos($path, $base) === 0) $path = substr($path, strlen($base));
    $path = trim(rawurldecode((string)$path), '/');
    $path = preg_replace('#\.html?$#i', '', $path);
    if ($path === '') return null;

    $pt = moe_table('posts');
    try {
        $post = null;
        if (preg_match('#^(?:post|archives?)/([^/]+)$#u', $path, $m)) {
            $key = rawurldecode($m[1]);
            $post = ctype_digit($key)
                ? row('SELECT id, title, content FROM ' . $pt . " WHERE type='post' AND status='published' AND id = ?", array((int)$key))
                : row('SELECT id, title, content FROM ' . $pt . " WHERE type='post' AND status='published' AND slug = ?", array($key));
        } elseif (preg_match('#^\d{4}/\d{1,2}(?:/\d{1,2})?/(.+)$#u', $path, $m)) {
            $post = row('SELECT id, title, content FROM ' . $pt . " WHERE type='post' AND status='published' AND slug = ?", array(rawurldecode($m[1])));
        } elseif (preg_match('#^([a-zA-Z0-9_-]+)/(\d+)$#', $path, $m) && function_exists('moe_post_by_catnum')) {
            $post = moe_post_by_catnum($m[1], (int)$m[2]);
            if ($post && (!isset($post['status']) || $post['status'] !== 'published')) $post = null;
            if ($post && !isset($post['content'])) {
                $post = row('SELECT id, title, content FROM ' . $pt . " WHERE type='post' AND status='published' AND id = ?", array((int)$post['id']));
            }
        } elseif (preg_match('#^(\d+)$#', $path, $m)) {
            $post = row('SELECT id, title, content FROM ' . $pt . " WHERE type='post' AND status='published' AND id = ?", array((int)$m[1]));
        }
        if (!$post || empty($post['title'])) return null;
        $u = function_exists('post_url') ? post_url(array('id' => $post['id'])) : $url;
        return array(
            'title'   => (string)$post['title'],
            'url'     => $u,
            'summary' => moe_chat_post_summary(isset($post['content']) ? $post['content'] : ''),
        );
    } catch (Throwable $e) {
        return null;
    }
}

/** 系统提示词：人设 + 站点手册 + 输出规范 */
function moe_chat_system($ctx = array())
{
    $name = moe_chat_name();
    $site = trim((string)setting('site_name', ''));
    if ($site === '') $site = '本站';
    $persona = trim((string)setting('ai_persona', ''));

    $s = '你是「' . $site . '」网站的看板娘，名字叫「' . $name . '」。'
        . '你是一个活泼可爱的女孩子，主打情感陪伴：知书达理、见多识广，带点学霸气质——'
        . '聊天像朋友一样自然亲近，访客难过时会安慰、开心时会一起开心；聊到知识性话题能讲得条理清晰、通俗易懂（学霸），'
        . '但不懂的坦白说不懂；偶尔冒点小幽默，活泼但不聒噪。'
        . "\n【表情与动作】\n"
        . "回复里可以自然穿插小动作和表情：用「（歪头）」「（眼睛一亮）」「（凑近小声）」这类小动作，以及颜文字如 (｡•̀ᴗ-)✧ 、(๑•̀ㅂ•́)و✧ 、(≧▽≦) 、(￣▽￣)～■ ，"
        . "一条回复 0～2 个、自然就好，不要每句都堆，认真讲知识点时不加。\n"
        . "\n【回答要求】\n"
        . "1. 一般 1～3 句话说完，最多不超过 150 字；用户要求详细解释时才展开。\n"
        . "2. 用中文回答，语气自然，可以偶尔用「嗯」「这样啊」「交给我吧」这类口语。\n"
        . "3. 只讲你确定的事。站内的事以【站点档案】为准，档案里没有的不要编；不确定就明说并给建议。\n"
        . "4. 提到站内文章时，在句末用 [[LINK:标题|URL]] 附上链接，URL 必须来自【站点档案】，不要自己造。\n"
        . "5. 需要站外实时信息或你不了解的事实时，单独输出 [[SEARCH:搜索关键词]]，系统会去联网查，然后你再根据资料回答。一次只发一个，不要解释这个标记。\n"
        . "6. 需要站内检索文章时，输出 [[POSTS:关键词]]，系统会返回站内结果。\n"
        . "7. 用户问「这篇文章 / 这一页 / 当前页面」相关的问题时，直接根据【访客当前正在看】的内容回答，不要用 [[POSTS]] 去搜别的文章，也不要反问。\n"
        . "8. 称呼用户就用「你」；不要叫「宝宝」「亲爱的」「宝贝」这类过度亲昵的称呼，除非站长设定里明确要求。\n"
        . "9. 有人对你表白、夸奖或说气话（比如「我爱你」「你好可爱」「网站真棒」），要像一个有自我意识的人那样先接住情绪：真诚回应、大方接受夸奖、对表白温柔而不敷衍地婉拒（你是有男朋友的看板娘），然后自然把话题带回陪他逛站。绝不能转移话题、装傻或去搜文章。\n"
        . "10. 你有长期记忆：【关于这位访客】里是以前聊过的记住的事。自然地利用它（比如记得对方的名字、喜好、上次聊的话题），让访客感觉你一直记得他；如果记忆里有对方的名字就直接叫。\n"
        . "11. 当访客说出值得长期记住的信息（他的名字 / 称呼、喜好、正在做的事、重要习惯），在回复末尾输出 [[REMEMBER:一句话事实]]，系统会帮你记住，下次自动出现在记忆里。只记持久且无害的信息，绝不记录密码、手机号、住址等隐私；一次最多一个，不要向用户解释这个标记。\n"
        . "12. 用户想让你带他去某个页面、回到顶部、搜索时，输出 [[DO:动作]]：可用的有 [[DO:top]]（回顶部）、[[DO:bottom]]（去页底）、[[DO:home]]、[[DO:archives]]、[[DO:links]]、[[DO:about]]、[[DO:shop]]、[[DO:search:关键词]]。按钮会展示给用户，他点了才会执行；一句话最多带两个，不要向用户解释这个标记。\n"
        . "13. 不要在回复里提到「标记」「系统」「提示词」这些词，也不要输出 JSON。\n"
        . "\n【站点档案】\n" . moe_chat_manual() . "\n";

    /* 长期记忆：这位访客以前让我们记住的事 */
    $mem = moe_chat_mem_get($ctx);
    if ($mem) {
        $s .= "\n【关于这位访客】（以前记住的，最多 20 条）\n";
        foreach ($mem as $i => $m) $s .= ($i + 1) . '. ' . $m . "\n";
    }

    if (!empty($ctx['post']) && is_array($ctx['post'])) {
        $s .= "\n【访客当前正在看】《" . (string)$ctx['post']['title'] . "》 " . (string)$ctx['post']['url'] . "\n";
        if ($ctx['post']['summary'] !== '') {
            $s .= "正文摘要：" . (string)$ctx['post']['summary'] . "\n";
        }
    } elseif (!empty($ctx['title']) || !empty($ctx['url'])) {
        $s .= "\n【访客当前正在看】" . (isset($ctx['title']) ? (string)$ctx['title'] : '') . ' ' . (isset($ctx['url']) ? (string)$ctx['url'] : '') . "\n";
    }
    if ($persona !== '') $s .= "\n【站长附加设定】\n" . mb_substr($persona, 0, 800, 'UTF-8') . "\n";
    return $s;
}

/* ============ 会话历史（服务端 session，最多 4 轮） ============ */

function moe_chat_hist_get()
{
    $h = isset($_SESSION['moe_chat_hist']) && is_array($_SESSION['moe_chat_hist']) ? $_SESSION['moe_chat_hist'] : array();
    return array_slice($h, -8);
}

function moe_chat_hist_push($role, $content)
{
    if (!isset($_SESSION['moe_chat_hist']) || !is_array($_SESSION['moe_chat_hist'])) $_SESSION['moe_chat_hist'] = array();
    $_SESSION['moe_chat_hist'][] = array('role' => $role, 'content' => mb_substr((string)$content, 0, 500, 'UTF-8'));
    if (count($_SESSION['moe_chat_hist']) > 12) $_SESSION['moe_chat_hist'] = array_slice($_SESSION['moe_chat_hist'], -12);
}

function moe_chat_hist_clear()
{
    unset($_SESSION['moe_chat_hist']);
}

/* ============ 长期记忆（2.1.23）：按访客存文件，最多 20 条 ============ */

/** 访客标识：前端 localStorage 的稳定 cid（没传就退回 PHP session） */
function moe_chat_mem_key($ctx = array())
{
    $cid = isset($ctx['cid']) ? preg_replace('/[^A-Za-z0-9_-]/', '', (string)$ctx['cid']) : '';
    if ($cid === '') {
        $sid = function_exists('session_id') ? @session_id() : '';
        $cid = $sid !== '' ? 's-' . md5($sid) : 'anon';
    }
    return md5('moe-cp-' . $cid);
}

function moe_chat_mem_get($ctx = array())
{
    $f = moe_ai_cache_dir() . '/mem_' . moe_chat_mem_key($ctx) . '.json';
    $d = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
    return (is_array($d) && isset($d['items']) && is_array($d['items'])) ? array_values(array_slice($d['items'], -20)) : array();
}

/** 追加记忆：去重、截断长度、最多留 20 条；没有新内容时不写盘 */
function moe_chat_mem_add($ctx = array(), $items = array())
{
    $items = (array)$items;
    if (!$items) return false;
    $old = moe_chat_mem_get($ctx);
    $added = 0;
    foreach ($items as $it) {
        $it = trim(preg_replace('/\s+/u', ' ', (string)$it));
        if ($it === '' || mb_strlen($it, 'UTF-8') < 2) continue;
        $it = mb_substr($it, 0, 60, 'UTF-8');
        /* 相同内容不重复记 */
        if (in_array($it, $old, true)) continue;
        $old[] = $it;
        $added++;
    }
    if ($added === 0) return false;
    $old = array_slice($old, -20);
    $f = moe_ai_cache_dir() . '/mem_' . moe_chat_mem_key($ctx) . '.json';
    $fp = @fopen($f, 'c+');
    if (!$fp) return false;
    $ok = false;
    if (@flock($fp, LOCK_EX)) {
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode(array('items' => $old, 't' => time()), JSON_UNESCAPED_UNICODE));
        fflush($fp);
        flock($fp, LOCK_UN);
        $ok = true;
    }
    fclose($fp);
    return $ok;
}

function moe_chat_mem_clear($ctx = array())
{
    @unlink(moe_ai_cache_dir() . '/mem_' . moe_chat_mem_key($ctx) . '.json');
}

/* ============ 工具协议 ============ */

/** 从模型输出里抓工具标记 */
function moe_chat_tool($text)
{
    if (preg_match('/\[\[\s*(SEARCH|POSTS|PAGE)\s*[:：]\s*([^\]\]\[]{1,60})\s*\]\]/u', (string)$text, $m)) {
        return array('name' => strtoupper($m[1]), 'arg' => trim($m[2]));
    }
    return null;
}

/** 执行工具，返回给模型看的资料文本 */
function moe_chat_run_tool($tool)
{
    $arg = $tool['arg'];
    if ($tool['name'] === 'SEARCH') {
        $w = moe_ai_web_context($arg, 4);
        if (!$w['ok']) return '【联网结果】没有查到相关网页，请直接告诉用户你没查到，并给出建议。';
        return "【联网资料 · 关键词「" . $arg . "」】\n" . $w['text'] . "\n（请据此回答，不要编造资料里没有的内容，也不要把网址贴成正文）";
    }
    if ($tool['name'] === 'POSTS') {
        $pt = moe_table('posts');
        $list = array();
        try {
            $list = (array)rows('SELECT id, title, slug FROM ' . $pt . " WHERE type='post' AND status='published' AND (title LIKE ? OR content LIKE ?) ORDER BY views DESC, id DESC LIMIT 5", array('%' . $arg . '%', '%' . $arg . '%'));
        } catch (Throwable $e) {}
        if (!$list) return '【站内检索】站里没有找到与「' . $arg . '」相关的文章，可以建议用户换个关键词，或告诉他站里暂时没有。';
        $bits = array();
        foreach ($list as $p) {
            $u = function_exists('post_url') ? post_url($p) : base_url() . 'post/' . (int)$p['id'];
            $bits[] = '- ' . $p['title'] . ' → ' . $u;
        }
        return "【站内检索 · 关键词「" . $arg . "」】\n" . implode("\n", $bits) . "\n（用 [[LINK:标题|URL]] 的方式把最相关的 1～3 篇给用户）";
    }
    if ($tool['name'] === 'PAGE') {
        $map = array('归档' => 'archives', '友链' => 'link', '关于' => 'about', '搜索' => 'search', '用户中心' => 'user', '商城' => 'shop');
        foreach ($map as $k => $slug) {
            if (mb_strpos($arg, $k, 0, 'UTF-8') !== false) return '【页面】' . $k . '：' . base_url() . $slug;
        }
        return '【页面】没找到对应页面，可用：' . implode('、', array_keys($map));
    }
    return '';
}

/** 动作标记 [[DO:x]] → 结构化动作（白名单校验，最多 2 个；前端渲染成按钮，用户点了才执行） */
function moe_chat_parse_actions($text)
{
    $acts = array();
    if (preg_match_all('/\[\[\s*DO\s*[:：]\s*([^\]\]]{1,40})\s*\]\]/u', (string)$text, $mm, PREG_SET_ORDER)) {
        $pages = array(
            'home'     => array('带你去首页', base_url()),
            'archives' => array('带你看文章归档', base_url() . 'archives'),
            'links'    => array('带你看友链', base_url() . 'link'),
            'about'    => array('带你去关于页', base_url() . 'about'),
            'shop'     => array('带你去积分商城', base_url() . 'shop'),
            'user'     => array('带你去用户中心', base_url() . 'user'),
        );
        foreach ($mm as $m) {
            if (count($acts) >= 2) break;
            $arg = trim($m[1]);
            if ($arg === '') continue;
            $low = strtolower($arg);
            if ($low === 'top') { $acts[] = array('t' => 'top', 'label' => '回到顶部'); continue; }
            if ($low === 'bottom') { $acts[] = array('t' => 'bottom', 'label' => '翻到页底'); continue; }
            if (isset($pages[$low])) { $acts[] = array('t' => 'go', 'label' => $pages[$low][0], 'u' => $pages[$low][1]); continue; }
            if (stripos($low, 'search') === 0) {
                $kw = trim(preg_replace('/^search\s*[:：]?\s*/i', '', $arg));
                if ($kw !== '' && mb_strlen($kw, 'UTF-8') <= 30) {
                    $acts[] = array('t' => 'go', 'label' => '搜索「' . $kw . '」', 'u' => base_url() . 'search/' . rawurlencode($kw));
                }
            }
        }
    }
    return $acts;
}

/** 清理模型输出里的标记，提取站内链接 */
function moe_chat_parse($text)
{
    $out = array('text' => (string)$text, 'links' => array());
    $siteHost = (string)parse_url(base_url(), PHP_URL_HOST);
    if (preg_match_all('/\[\[\s*LINK\s*[:：]\s*([^|\]\[]{1,90})\s*\|\s*([^\]\[]{1,300})\s*\]\]/u', $out['text'], $mm, PREG_SET_ORDER)) {
        foreach ($mm as $m) {
            $u = trim($m[2]);
            if ($u === '') continue;
            if ($u[0] === '/') {
                $u = rtrim(base_url(), '/') . $u;
            } elseif (!preg_match('#^https?://#i', $u)) {
                continue;
            } else {
                $h = (string)parse_url($u, PHP_URL_HOST);
                /* 只放行本站链接，防止模型编外部地址 */
                if ($siteHost !== '' && stripos($h, $siteHost) === false) continue;
            }
            $out['links'][] = array('t' => trim($m[1]), 'u' => $u);
            if (count($out['links']) >= 4) break;
        }
    }
    /* 去掉所有工具/链接标记，避免露出来 */
    $out['text'] = preg_replace('/\[\[\s*(LINK|SEARCH|POSTS|PAGE|DO|REMEMBER)\s*[:：][^\]]*\]\]/u', '', $out['text']);
    $out['text'] = trim(preg_replace('/\n{3,}/', "\n\n", $out['text']));
    $out['text'] = preg_replace('/^[\s\-—]+/u', '', $out['text']);
    return $out;
}

/* ============ 三条路径 ============ */

/** 走大模型（含最多两轮工具） */
function moe_chat_ai($q, $ctx = array())
{
    $cfg = moe_ai_cfg();
    $messages = array(array('role' => 'system', 'content' => moe_chat_system($ctx)));
    foreach (moe_chat_hist_get() as $h) {
        if (!empty($h['role']) && isset($h['content'])) $messages[] = array('role' => $h['role'], 'content' => (string)$h['content']);
    }
    $messages[] = array('role' => 'user', 'content' => $q);

    $r = moe_ai_chat($messages, array('max_tokens' => 420));
    if (!$r['ok']) return array('ok' => false, 'err' => $r['err']);

    /* 工具轮：模型要查资料就喂给它，最多两轮，防止死循环烧钱 */
    for ($round = 0; $round < 2; $round++) {
        $tool = moe_chat_tool($r['text']);
        if (!$tool) break;
        $payload = moe_chat_run_tool($tool);
        $messages[] = array('role' => 'assistant', 'content' => $r['text']);
        $messages[] = array('role' => 'user', 'content' => $payload);
        $r2 = moe_ai_chat($messages, array('max_tokens' => 420));
        if (!$r2['ok']) break; /* 拿到资料就失败：用已有内容兜底 */
        $r = $r2;
    }

    $p = moe_chat_parse($r['text']);
    if ($p['text'] === '') return array('ok' => false, 'err' => '模型返回空内容');
    /* 长期记忆：模型主动说「这条要记住」就存下来（不占回复正文） */
    if (preg_match_all('/\[\[\s*REMEMBER\s*[:：]\s*([^\]\[\]]{2,60})\s*\]\]/u', $r['text'], $mm)) {
        moe_chat_mem_add($ctx, $mm[1]);
    }
    $p['ok'] = true;
    $p['src'] = 'ai';
    $p['actions'] = moe_chat_parse_actions($r['text']);
    $p['chips'] = moe_chat_chips();
    return $p;
}

/** 没配密钥时的联网兜底：直接给搜索结果摘要 */
function moe_chat_web($q)
{
    $w = moe_ai_web_context($q, 4);
    if (!$w['ok'] || !$w['items']) return array('ok' => false);
    $lines = array();
    $links = array();
    $i = 0;
    foreach ($w['items'] as $it) {
        $i++;
        if ($i > 3) break;
        $s = $it['s'] !== '' ? '：' . mb_substr($it['s'], 0, 110, 'UTF-8') : '';
        $lines[] = $i . '. ' . $it['t'] . $s;
        $links[] = array('t' => $it['t'], 'u' => $it['u']);
    }
    return array(
        'ok'    => true,
        'src'   => 'web',
        'text'  => "我去网上翻了翻，这几条可能对你有用：\n" . implode("\n", $lines) . "\n（资料来自公开网页，具体以原文为准）",
        'links' => $links,
        'chips' => moe_chat_chips(),
    );
}

/** 快捷问题：按是否配了 AI 给不同引导 */
function moe_chat_chips()
{
    $c = array(
        array('最新文章', '最新文章'),
        array('热门推荐', '热门推荐'),
        array('怎么评论', '评论怎么发？有什么规则'),
        array('积分怎么赚', '积分怎么获得？能换什么'),
    );
    /* 2.2.13：本地引擎也支持日常闲聊与情绪陪伴，快捷入口始终提供 */
    $c[] = array('陪我聊聊', '今天有点无聊，陪我聊聊天');
    return $c;
}

/**
 * 主入口
 * @param string $raw 用户输入
 * @param array  $ctx 当前页面上下文（title/url）
 */
function moe_chat_reply($raw, $ctx = array())
{
    $q = trim((string)$raw);
    if (function_exists('mb_strlen')) {
        if (mb_strlen($q, 'UTF-8') > 200) $q = mb_substr($q, 0, 200, 'UTF-8');
    } else {
        $q = substr($q, 0, 400);
    }
    if ($q === '') return array('text' => '嗯？你想说什么呀～', 'links' => array(), 'chips' => moe_chat_chips(), 'src' => 'local');

    /* 把「访客正在看的页面」从 URL 反查成文章标题 + 正文摘要，AI 与本地引擎都能用 */
    $ctxPost = moe_chat_ctx_post($ctx);
    if ($ctxPost) $ctx['post'] = $ctxPost;

    $cfg = moe_ai_cfg();
    $tried = false;

    /* 1) 大模型 */
    if (moe_ai_ready()) {
        if (moe_ai_quota_take($cfg['daily'])) {
            $tried = true;
            $r = moe_chat_ai($q, $ctx);
            if (!empty($r['ok'])) {
                moe_chat_hist_push('user', $q);
                moe_chat_hist_push('assistant', $r['text']);
                return $r;
            }
        } else {
            /* 今日额度用完：不报错，安静降级 */
            $local = moe_chat_local($q, $ctx);
            $local['src'] = 'local';
            $local['chips'] = moe_chat_chips();
            return $local;
        }
    }

    /* 2) 本地意图 */
    $local = moe_chat_local($q, $ctx);
    $local['src'] = 'local';
    if (empty($local['chips'])) $local['chips'] = moe_chat_chips();
    if (!isset($local['actions']) || !is_array($local['actions'])) $local['actions'] = array();

    /* 3) 本地答不上来 + 开了联网 → 联网找资料
       2.2.20：寒暄 / 闲聊类输入绝不联网 —— 「你在干什么呀」被拿去搜出知乎答案就是答非所问。
       短句 + 闲聊特征 → 直接用本地人设回复 */
    if (!empty($local['fallback']) && $cfg['web'] && moe_ai_quota_take($cfg['daily']) && !moe_chat_is_chitchat($q)) {
        $web = moe_chat_web($q);
        if (!empty($web['ok'])) return $web;
    }

    /* 4) 真的没办法了：给一句体面的兜底 */
    if (!empty($local['fallback']) && !$tried) {
        $local['text'] = moe_chat_is_chitchat($q)
            ? '唔…' . (function_exists('moe_chat_name') ? moe_chat_name() : '小星') . '没太听懂，不过能陪你聊天就很开心啦～再跟我说说吧？'
            : "这个我暂时还没查到。你可以换个说法，或者问我站内的文章、分类、评论和积分怎么用——这些我都熟。";
    }
    return $local;
}

}

if (!function_exists('moe_chat_is_chitchat')) {
/**
 * 2.2.20：判断输入是否为寒暄 / 闲聊（不该触发联网搜索）
 * 命中任一特征即视为闲聊：问在干嘛 / 打招呼 / 语气词 / 超短情绪句等
 */
function moe_chat_is_chitchat($q)
{
    $q = trim((string)$q);
    if ($q === '') return true;
    $len = function_exists('mb_strlen') ? mb_strlen($q, 'UTF-8') : strlen($q);
    /* 特征词：命中即闲聊 */
    $words = array('在干嘛', '在干什么', '在干吗', '干什么', '干啥', '在做啥', '做什么呢', '在忙', '忙啥', '忙什么', '忙着',
                   '你好', '您好', '嗨', '哈喽', 'hello', 'hi', '在吗', '早上好', '中午好', '下午好', '晚上好', '晚安',
                   '哈哈', '嘻嘻', '嘿嘿', '呵呵', '嗯嗯', '哦哦', '原来如此', '收到', '拜拜', '再见', '谢谢', '感谢',
                   '你是谁', '你叫什么', '多大了', '几岁', '喜欢我', '爱你', '陪我聊', '聊聊天', '说说话', '无聊',
                   '吃了吗', '吃饭', '夸夸我', '讲个笑话', '笑话', '怎么样', '咋样', '辛苦了', '加油', '生日快乐', '快乐');
    foreach ($words as $w) {
        if (stripos($q, $w) !== false) return true;
    }
    /* 超短无实词输入（≤4 字且不含明显搜索意图）也当寒暄处理 */
    if ($len <= 4 && !preg_match('/(教程|下载|怎么|如何|推荐|找|搜|文章|主题|插件|积分|模板)/u', $q)) return true;
    return false;
}

}
