<?php
/**
 * MoeZ - 评论 IP 归属地 / 系统·浏览器解析
 * 归属地查询：ip-api.com（中文，免费无 Key），仅在写入评论时调用一次并落库，展示时零开销
 */

/** 是否内网 / 保留地址 */
function moe_ip_private($ip)
{
    $ip = trim((string)$ip);
    if ($ip === '') return true;
    if ($ip === '::1' || $ip === '0.0.0.0') return true;
    if (strpos($ip, '127.') === 0) return true;
    if (strpos($ip, '10.') === 0) return true;
    if (strpos($ip, '192.168.') === 0) return true;
    if (strpos($ip, '169.254.') === 0) return true;
    if (preg_match('/^172\.(1[6-9]|2\d|3[01])\./', $ip)) return true;
    if (preg_match('/^(f[cd]|fe80)/i', $ip)) return true;   // IPv6 内网 / 链路本地
    return false;
}

/**
 * 查询 IP 归属地，如「广东 深圳」「日本」
 * 1.8.5 起不再拼接运营商（ISP）；失败 / 内网返回说明文字，不抛异常
 */
function moe_ip_location($ip)
{
    $ip = trim((string)$ip);
    if ($ip === '' || filter_var($ip, FILTER_VALIDATE_IP) === false) return '';
    if (moe_ip_private($ip)) return '内网 / 保留地址';

    $api = 'http://ip-api.com/json/' . rawurlencode($ip)
         . '?lang=zh-CN&fields=status,country,regionName,city';
    $body = function_exists('moe_http_get') ? moe_http_get($api, 4) : '';
    if ($body === '' && is_file(dirname(__FILE__) . '/linkcheck.php')) {
        require_once dirname(__FILE__) . '/linkcheck.php';
        $body = moe_http_get($api, 4);
    }
    if ($body === '') return '';

    $d = json_decode($body, true);
    if (!is_array($d) || ($d['status'] ?? '') !== 'success') return '';

    $parts = array();
    $region = trim($d['regionName'] ?? '');
    $city   = trim($d['city'] ?? '');
    if ($region !== '') $parts[] = $region;
    if ($city !== '' && $city !== $region) $parts[] = $city;
    if (empty($parts)) {
        $country = trim($d['country'] ?? '');
        if ($country !== '') $parts[] = $country;
    }
    return implode(' ', $parts);
}

/**
 * 解析 User-Agent → array('os' => 'Windows 10/11', 'browser' => 'Edge 156.0.0.0')
 * 2.1.2：拆分出系统与浏览器两个字段（评论区分徽标展示用），浏览器带完整版本号
 */
function moe_ua_parts($ua)
{
    $ua = trim((string)$ua);
    if ($ua === '') return array('os' => '', 'browser' => '');

    /* ---------- 操作系统 ---------- */
    $os = '';
    if (preg_match('/Windows NT ([\d.]+)/i', $ua, $m)) {
        $map = array('10.0' => 'Windows 10/11', '6.3' => 'Windows 8.1', '6.2' => 'Windows 8', '6.1' => 'Windows 7');
        $os = $map[$m[1]] ?? ('Windows NT ' . $m[1]);
    } elseif (stripos($ua, 'android') !== false) {
        preg_match('/Android[ \/]?([\d.]+)/i', $ua, $m2);
        $os = 'Android' . (!empty($m2[1]) ? ' ' . substr($m2[1], 0, 4) : '');
    } elseif (preg_match('/iPhone|iPad|iPod/i', $ua)) {
        preg_match('/OS ([\d_]+)/i', $ua, $m3);
        $os = 'iOS' . (!empty($m3[1]) ? ' ' . str_replace('_', '.', substr($m3[1], 0, 4)) : '');
    } elseif (preg_match('/Mac OS X ([\d_]+)/i', $ua, $m4)) {
        $os = 'macOS ' . str_replace('_', '.', substr($m4[1], 0, 4));
    } elseif (preg_match('/Macintosh|Mac/i', $ua)) {
        $os = 'macOS';
    } elseif (preg_match('/Linux/i', $ua)) {
        $os = 'Linux';
    }

    /* ---------- 浏览器（顺序敏感：先判壳，再判内核；带完整版本号） ---------- */
    $br = '';
    if (preg_match('#MicroMessenger/([\d.]+)#i', $ua, $m)) {
        $br = '微信内置浏览器';
    } elseif (preg_match('#QQBrowser/([\d.]+)#i', $ua, $m)) {
        $br = 'QQ浏览器 ' . $m[1];
    } elseif (preg_match('#Edg(?:e|A|iOS)?/([\d.]+)#i', $ua, $m)) {
        $br = 'Edge ' . $m[1];
    } elseif (preg_match('#(OPR|Opera)[ /]([\d.]+)#i', $ua, $m)) {
        $br = 'Opera ' . $m[2];
    } elseif (preg_match('#UCBrowser/([\d.]+)#i', $ua, $m)) {
        $br = 'UC浏览器 ' . $m[1];
    } elseif (preg_match('#Quark/([\d.]+)#i', $ua, $m)) {
        $br = '夸克浏览器';
    } elseif (preg_match('#Firefox/([\d.]+)#i', $ua, $m)) {
        $br = 'Firefox ' . $m[1];
    } elseif (preg_match('#Chrome/([\d.]+)#i', $ua, $m)) {
        $br = 'Chrome ' . $m[1];
    } elseif (preg_match('#Version/([\d.]+).*Safari#i', $ua, $m) || preg_match('#Safari/[\d.]+#i', $ua)) {
        $br = 'Safari' . (!empty($m[1]) ? ' ' . $m[1] : '');
    }

    return array('os' => $os, 'browser' => $br);
}

/**
 * 解析 User-Agent → 「系统 · 浏览器」，如：
 *   Windows 10/11 · Chrome 120 / Android 13 · 微信内置浏览器 / iOS 17 · Safari
 */
function moe_ua_info($ua)
{
    $p = moe_ua_parts($ua);
    if ($p['os'] === '' && $p['browser'] === '') return '';
    return trim($p['os'] . ($p['os'] && $p['browser'] ? ' · ' : '') . $p['browser']);
}
