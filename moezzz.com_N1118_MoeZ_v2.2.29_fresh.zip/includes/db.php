<?php
/**
 * MoeZ - PDO 数据库连接
 */
function moe_db() {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $cfg = $GLOBALS['moe_config'];
    try {
        $pdo = new PDO(
            "mysql:host={$cfg['db']['host']};port={$cfg['db']['port']};dbname={$cfg['db']['name']};charset=utf8mb4",
            $cfg['db']['user'],
            $cfg['db']['pass'],
            array(
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            )
        );
        // DSN 已带 charset=utf8mb4（PHP 5.3.6+ 由驱动设定连接字符集），
        // 2.2.30 优化：无需再执行一次 SET NAMES，每请求省一次 SQL 往返。
    } catch (PDOException $e) {
        if (defined('MOE_ADMIN') && MOE_ADMIN) {
            die('数据库连接失败：' . htmlspecialchars($e->getMessage()));
        }
        http_response_code(500);
        die('<!DOCTYPE html><meta charset="utf-8"><title>呜…出错了</title><body style="font-family:sans-serif;text-align:center;padding-top:80px">😲 数据库连接失败<br><small>' . htmlspecialchars($e->getMessage()) . '</small></body>');
    }
    return $pdo;
}

/** 前缀表名 */
function moe_table($name) {
    return $GLOBALS['moe_config']['db']['prefix'] . $name;
}
