<?php
/**
 * MoeZ - Redis 缓存层（1.6.6）
 * 依赖 phpredis 扩展（宝塔 PHP 可在「安装扩展」里一键安装 redis）。
 * 未开启或扩展缺失时所有函数安全降级为空操作，不影响站点运行。
 * 配置保存在设置项：redis_enabled / redis_host / redis_port / redis_auth / redis_db
 */

/** 读取 Redis 配置（直接查库，避免与 setting() 的加载过程互相递归）
 * 2.2.28：缓存位置由函数 static 改为 $GLOBALS —— 修复同一请求内先后改 Redis
 * 配置时的过期读取：后台保存设置的请求里，页面加载时（保存前）Redis 还是
 * 未启用状态，static 会把 false 缓存到请求结束；保存后立刻做的连接检测拿到的
 * 仍是这份旧值，于是误报「连接失败」（而「测试连接」是独立请求、显示成功）。
 * 改存 $GLOBALS 后，setting_set() 保存 redis_* 配置时可直接作废本请求内的缓存。
 * $fresh=true 时跳过所有缓存强制查库（文件缓存 cache_cfg 也会被重写）。
 */
function moe_cache_cfg($fresh = false)
{
    if (!$fresh && isset($GLOBALS['moe_cache_cfg'])) return $GLOBALS['moe_cache_cfg'];
    $cfg = false;
    // 1.9.0：配置本身也走文件缓存（内部用途），避免每个请求都为「Redis 是否开启」多查一次设置表
    if (!$fresh) {
        $cachedCfg = function_exists('moe_fcache_get') ? moe_fcache_get('cache_cfg') : null;
        if (is_array($cachedCfg) && isset($cachedCfg['enabled'])) {
            return $GLOBALS['moe_cache_cfg'] = ($cachedCfg['enabled'] === '1' ? $cachedCfg : false);
        }
    }
    try {
        $cfg = array('enabled' => '0', 'host' => '127.0.0.1', 'port' => '6379', 'auth' => '', 'db' => '0');
        foreach (rows('SELECT skey, svalue FROM ' . moe_table('settings') . " WHERE skey LIKE 'redis\\_%' ESCAPE '\\'") as $s) {
            if (isset($cfg[$s['skey']])) $cfg[$s['skey']] = (string)$s['svalue'];
        }
        if (function_exists('moe_fcache_set')) moe_fcache_set('cache_cfg', $cfg, 600);
        if ($cfg['enabled'] !== '1') $cfg = false;
    } catch (Throwable $e) {
        $cfg = false; // 表未就绪等情况
    }
    return $GLOBALS['moe_cache_cfg'] = $cfg;
}

/** 缓存是否可用（开启 + phpredis 扩展存在） */
function moe_cache_ready()
{
    if (!moe_cache_cfg()) return false;
    return class_exists('Redis');
}

/** 获取（或建立）Redis 连接；失败返回 null
 * 2.2.28：连接失败时先用强制刷新的新配置重试一次 —— 覆盖配置刚改完
 * （改密码 / 改库号）而文件缓存 cache_cfg 还是旧值的窗口期。
 * 2.2.29：连接尝试本身也支持强制重置 —— 保存 redis_* 设置的请求里，
 * 页面加载阶段（Redis 尚未启用）可能已消耗掉唯一一次尝试（static $tried），
 * 保存后的状态检测必须能带着新配置重新连，否则误报「连接失败」。
 */
function moe_cache_client($fresh = false)
{
    static $client = null;
    static $tried = false;
    if ($fresh) { $client = null; $tried = false; }
    if ($tried) return $client;
    $tried = true;
    if (!class_exists('Redis')) return null;
    $cfg = moe_cache_cfg();
    if (!$cfg) return null;
    $err = '';
    foreach (array(false, true) as $i => $fresh) {
        if ($i > 0) {
            $newCfg = moe_cache_cfg(true);
            if ($newCfg === false || $newCfg === $cfg) break;   // 配置没变化，重试无意义
            $cfg = $newCfg;
        }
        try {
            $r = new Redis();
            $host = trim($cfg['host']) !== '' ? trim($cfg['host']) : '127.0.0.1';
            $port = (int)($cfg['port'] ?: 6379);
            $ok = filter_var($host, FILTER_VALIDATE_IP)
                ? $r->connect($host, $port, 1.5)
                : $r->connect($host, $port, 1.5, null, 0, 1.5); // 域名走解析超时
            if (!$ok) { $err = 'connect() 返回 false（连接超时或拒绝）'; $client = null; continue; }
            $auth = (string)$cfg['auth'];
            if ($auth !== '') {
                // 兼容 Redis 6+ ACL（user:pass）与旧版仅密码两种写法
                try { $r->auth($auth); }
                catch (Throwable $e) {
                    if (strpos($auth, ':') !== false) { $r->auth(explode(':', $auth, 2)); }
                    else { $err = 'auth 参数无效（' . $e->getMessage() . '）'; $client = null; continue; }
                }
            }
            $db = (int)$cfg['db'];
            if ($db > 0) $r->select($db);
            $client = $r;
            $err = '';
            if (function_exists('moe_fcache_del')) moe_fcache_del('cache_err');   // 连上了就清掉旧错误
            break;
        } catch (Throwable $e) {
            $client = null;
            $err = $e->getMessage();
        }
    }
    if ($client === null && $err !== '' && function_exists('moe_fcache_set')) {
        // 2.2.8：连接失败原因记下来，设置页能直接看到「为什么没切换成功」
        // 2.2.30 优化：错误原因未变化时不再重复写文件（Redis 不通时每请求都会走到这里）；
        // 连接时序未改，Redis 恢复后仍即时生效。
        $prev = function_exists('moe_fcache_get') ? moe_fcache_get('cache_err') : null;
        if (!is_array($prev) || (string)(isset($prev['msg']) ? $prev['msg'] : '') !== $err) {
            moe_fcache_set('cache_err', array('msg' => $err, 'at' => date('Y-m-d H:i:s')), 300);
        }
    }
    return $client;
}

/** 2.2.8：后台缓存状态诊断（设置页实时展示用）
 * 2.2.29：$fresh = true 时用「刚保存的新配置 + 全新连接」检测 —— 保存设置
 * 后立即展示的那次状态必须如实反映新配置，不能复用请求早前的旧尝试。
 */
function moe_cache_status($fresh = false)
{
    $st = array(
        'ext'       => class_exists('Redis'),
        'enabled'   => false,
        'connected' => false,
        'driver'    => '未启用（数据不缓存，直接查库）',
        'err'       => '',
        'err_at'    => '',
        'ver'       => '',
    );
    if (!$fresh) {
        $err = function_exists('moe_fcache_get') ? moe_fcache_get('cache_err') : null;
        if (is_array($err)) { $st['err'] = (string)$err['msg']; $st['err_at'] = (string)$err['at']; }
    }
    $cfg = moe_cache_cfg($fresh);
    $st['enabled'] = (bool)$cfg;
    if ($cfg && class_exists('Redis')) {
        $r = moe_cache_client($fresh);
        if ($r) {
            $st['connected'] = true;
            $st['driver'] = 'Redis ✅';
            try { $info = $r->info(); $st['ver'] = isset($info['redis_version']) ? (string)$info['redis_version'] : ''; } catch (Throwable $e) {}
            $st['err'] = '';
        } else {
            // 2.2.27：连接失败不再落文件兜底 —— 如实显示「不缓存」
            $st['driver'] = '连接失败（缓存停用，直接查库）';
        }
    }
    return $st;
}

/** 读缓存（miss 或不可用时返回 null） */
function cache_get($key)
{
    $r = moe_cache_client();
    if (!$r) return null;
    try {
        $v = $r->get('moe:' . $key);
        return $v === false ? null : json_decode($v, true);
    } catch (Throwable $e) { return null; }
}

/** 写缓存（默认 300 秒） */
function cache_set($key, $value, $ttl = 300)
{
    $r = moe_cache_client();
    if (!$r) return false;
    try {
        return $r->setex('moe:' . $key, max(10, (int)$ttl), json_encode($value, JSON_UNESCAPED_UNICODE));
    } catch (Throwable $e) { return false; }
}

/** 删除缓存 */
function cache_del($key)
{
    $r = moe_cache_client();
    if (!$r) return false;
    try { $r->del('moe:' . $key); return true; }
    catch (Throwable $e) { return false; }
}

/** 清空本程序全部缓存（按前缀匹配，不影响库里其他数据） */
function cache_flush()
{
    $r = moe_cache_client();
    if (!$r) return 0;
    try {
        $n = 0;
        $it = null;
        while (($keys = $r->scan($it, 'moe:*', 200)) !== false) {
            if ($keys) { $r->del($keys); $n += count($keys); }
            if ((int)$it === 0) break;
        }
        return $n;
    } catch (Throwable $e) { return 0; }
}

/**
 * 连接测试（后台「测试连接」用）
 * 返回 array('ok' => bool, 'msg' => string)
 */
function moe_cache_test($host, $port, $auth, $db)
{
    if (!class_exists('Redis')) {
        return array('ok' => false, 'msg' => 'PHP 未安装 phpredis 扩展（宝塔：PHP 设置 → 安装扩展 → redis）');
    }
    try {
        $r = new Redis();
        $host = trim($host) !== '' ? trim($host) : '127.0.0.1';
        $port = (int)($port ?: 6379);
        $r->connect($host, $port, 2.0);
        $auth = (string)$auth;
        if ($auth !== '') {
            try { $r->auth($auth); }
            catch (Throwable $e) {
                if (strpos($auth, ':') !== false) $r->auth(explode(':', $auth, 2));
                else return array('ok' => false, 'msg' => '认证失败：' . $e->getMessage());
            }
        }
        $db = (int)$db;
        if ($db > 0) $r->select($db);
        $r->setex('moe:ping_test', 10, 'pong');
        $v = $r->get('moe:ping_test');
        $r->del('moe:ping_test');
        if ($v !== 'pong') return array('ok' => false, 'msg' => '读写测试失败');
        $info = array();
        try { $info = $r->info(); } catch (Throwable $e) {}
        $ver = isset($info['redis_version']) ? ' · Redis ' . $info['redis_version'] : '';
        return array('ok' => true, 'msg' => '连接成功 ✅ 读写测试通过' . $ver);
    } catch (Throwable $e) {
        return array('ok' => false, 'msg' => '连接失败：' . $e->getMessage());
    }
}

/* ============================================================
 * 1.9.0 · 轻量文件缓存（2.2.27 起仅限内部用途 + 页面缓存）
 * 2.2.27：站长拍板「拒绝文件兜底」—— 数据缓存只走 Redis（或直接查库），
 *         文件缓存仅保留给：cache_cfg 内部配置读取、cache_err 诊断记录、
 *         以及独立的「页面缓存」功能（cache/pc，设置页单独开关）。
 * 数据存为 cache/{子目录}/md5.php，文件开头 exit，直接访问也不会泄漏内容。
 * 目录不可写时所有函数安全降级为空操作。
 * ============================================================ */

/** 缓存子目录（不可写返回空串） */
function moe_fcache_dir($sub = 'data')
{
    static $ok = array();
    $sub = preg_replace('/[^a-z0-9_]/i', '', (string)$sub);
    if ($sub === '') $sub = 'data';
    $dir = MOE_ROOT . '/cache/' . $sub;
    if (!isset($ok[$dir])) {
        if (!is_dir($dir)) @mkdir($dir, 0755, true);
        $ok[$dir] = is_dir($dir) && is_writable($dir);
    }
    return $ok[$dir] ? $dir : '';
}

function moe_fcache_path($key, $sub = 'data')
{
    $dir = moe_fcache_dir($sub);
    return $dir === '' ? '' : $dir . '/' . md5((string)$key) . '.php';
}

/** 读文件缓存（过期 / 不存在返回 null） */
function moe_fcache_get($key, $sub = 'data')
{
    $f = moe_fcache_path($key, $sub);
    if ($f === '' || !is_file($f)) return null;
    $raw = @file_get_contents($f);
    if ($raw === false || $raw === '') return null;
    $pos = strpos($raw, '?>');
    if ($pos === false) return null;
    $data = json_decode(substr($raw, $pos + 2), true);
    if (!is_array($data) || !isset($data['e'])) return null;
    if ((int)$data['e'] < time()) { @unlink($f); return null; }
    return array_key_exists('v', $data) ? $data['v'] : null;
}

/** 写文件缓存（原子写：先写临时文件再 rename，避免并发读到半截内容） */
function moe_fcache_set($key, $value, $ttl = 300, $sub = 'data')
{
    $f = moe_fcache_path($key, $sub);
    if ($f === '') return false;
    $ttl = max(10, (int)$ttl);
    $flags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) $flags |= JSON_INVALID_UTF8_SUBSTITUTE;
    $body = '<?php exit; ?>' . json_encode(array('e' => time() + $ttl, 'v' => $value), $flags);
    $tmp = $f . '.' . getmypid() . '.tmp';
    if (@file_put_contents($tmp, $body, LOCK_EX) === false) return false;
    if (!@rename($tmp, $f)) { @unlink($tmp); return false; }
    return true;
}

function moe_fcache_del($key, $sub = 'data')
{
    $f = moe_fcache_path($key, $sub);
    if ($f !== '' && is_file($f)) @unlink($f);
}

/** 清空某个子目录的缓存（页面缓存清理用） */
function moe_fcache_flush($sub = 'data')
{
    $dir = moe_fcache_dir($sub);
    if ($dir === '') return 0;
    $n = 0;
    foreach ((array)glob($dir . '/*.php') as $f) {
        if (@unlink($f)) $n++;
    }
    return $n;
}

/* ============ 统一缓存 API（2.2.27：只走 Redis，不做文件兜底） ============
 * 站长拍板：拒绝文件兜底缓存 —— Redis 启用且连接正常时数据缓存走 Redis；
 * 未启用 / 扩展缺失 / 连接失败时一律「不缓存，直接查库」，绝不把热点数据落盘。
 * 文件缓存（moe_fcache_*）仅保留给：内部配置读取 + 页面缓存（cache/pc，独立开关）。
 */

function moe_cache_store_get($key)
{
    if (function_exists('moe_cache_ready') && moe_cache_ready()) {
        return cache_get($key);   // Redis 未命中 / 连接失败都返回 null：直接查库，不读文件
    }
    return null;
}

function moe_cache_store_set($key, $value, $ttl = 300)
{
    if (function_exists('moe_cache_ready') && moe_cache_ready()) {
        return cache_set($key, $value, $ttl);   // 连接失败时 cache_set 内部安全返回 false
    }
    return false;
}

function moe_cache_store_del($key)
{
    if (function_exists('moe_cache_ready') && moe_cache_ready()) {
        return cache_del($key);
    }
    return false;
}

/** 读缓存 → 未命中执行回调并回写（热门统计 / 分类列表用） */
function moe_remember($key, $ttl, $cb)
{
    $hit = moe_cache_store_get($key);
    if ($hit !== null) return $hit;
    $val = $cb();
    moe_cache_store_set($key, $val, $ttl);
    return $val;
}

/** 主动失效（内容变更时调用） */
function moe_forget($key)
{
    moe_cache_store_del($key);
}

/* ============================================================
 * 1.9.0 · 页面缓存（访客静态化）
 * 逻辑：访客 GET 请求命中缓存直接输出，省掉全部数据库查询与模板渲染；
 *      后台登录用户不缓存；评论表单的 CSRF 令牌用占位符替换，避免串号。
 * ============================================================ */

/** 页面缓存的「内容版本号」：内容变更时自增，旧缓存自然失效 */
function moe_pcache_ver()
{
    static $ver = null;
    if ($ver !== null) return $ver;
    $f = MOE_ROOT . '/cache/pc_ver.txt';
    $v = is_file($f) ? trim((string)@file_get_contents($f)) : '';
    if ($v === '') {
        if (!is_dir(MOE_ROOT . '/cache')) @mkdir(MOE_ROOT . '/cache', 0755, true);
        $v = (string)time();
        @file_put_contents($f, $v, LOCK_EX);
    }
    return $ver = $v;
}

/** 内容变更后调用：换版本号 → 全站页面缓存立即失效（并顺手清掉一天前的旧文件） */
function moe_pcache_bump()
{
    // 2.2.30 优化：一次请求只换一次版本号。保存设置会连续触发数十次，
    // 多次 bump 与一次效果相同，却会重复写文件 + 重复 glob 扫描缓存目录。
    static $done = false;
    if ($done) return;
    $done = true;
    if (!is_dir(MOE_ROOT . '/cache')) @mkdir(MOE_ROOT . '/cache', 0755, true);
    $v = time() . mt_rand(100, 999);
    @file_put_contents(MOE_ROOT . '/cache/pc_ver.txt', (string)$v, LOCK_EX);
    foreach ((array)glob(MOE_ROOT . '/cache/pc/*.php') as $f) {
        if (@filemtime($f) < time() - 86400) @unlink($f);
    }
}

/** 当前请求是否适合走页面缓存 */
function moe_pcache_allowed($p)
{
    if (!in_array((string)$p, array('index', 'post', 'category', 'page', 'tag', 'archive', 'article', 'life', 'about', 'links'), true)) return false;
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') return false;
    if (!empty($_SESSION['moe_uid'])) return false;                 // 站长登录：不缓存（含评论表单预填）
    if (!empty($_GET['preview']) || !empty($_GET['nocache'])) return false;
    if (function_exists('setting') && setting('page_cache', '1') !== '1') return false;
    return true;
}

/** 页面缓存键（含内容版本 / 主题 / 完整 URI，分页与参数天然区分） */
function moe_pcache_key()
{
    $uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
    // 去掉常见的跟踪参数，避免同一页面被缓存多份
    $uri = preg_replace('/([?&])(from|spm|ref|utm_[a-z]+)=[^&]*/i', '$1', $uri);
    $uri = rtrim(str_replace('?&', '?', $uri), '?&');
    return moe_pcache_ver() . '|' . theme() . '|' . $uri;
}

/**
 * 进入页面缓存：命中则直接输出并结束请求，未命中则登记缓存键由 render() 回写
 * @return bool 是否启用页面缓存
 */
function moe_pcache_begin($p)
{
    if (!moe_pcache_allowed($p)) return false;
    $key  = moe_pcache_key();
    $html = moe_fcache_get($key, 'pc');
    if (is_string($html) && strlen($html) > 500) {
        // 评论表单令牌按当前会话替换，避免访客之间串用
        $tok = function_exists('csrf_token') ? csrf_token() : '';
        if ($tok !== '' && strpos($html, '__MOE_CSRF__') !== false) {
            $html = str_replace('__MOE_CSRF__', $tok, $html);
        }
        // 文章浏览数仍然要计数（缓存里不重复跑查询，只加一条 UPDATE）
        $meta = moe_fcache_get($key . '|meta', 'pc');
        if (is_array($meta) && !empty($meta['post']) && function_exists('moe_add_view')) {
            moe_add_view((int)$meta['post']);
        }
        if (!headers_sent()) {
            header('X-Moe-Cache: HIT');
            header('Content-Type: text/html; charset=utf-8');
        }
        echo $html;
        exit;
    }
    $GLOBALS['moe_pcache_key'] = $key;
    return true;
}

/** 把渲染好的 HTML 写入页面缓存（CSRF 令牌换成占位符） */
function moe_pcache_save($html, $postId = 0)
{
    if (empty($GLOBALS['moe_pcache_key'])) return;
    if (strlen((string)$html) < 500) return;
    if (function_exists('http_response_code') && http_response_code() !== 200) return;
    $key = $GLOBALS['moe_pcache_key'];
    $tok = function_exists('csrf_token') ? csrf_token() : '';
    if ($tok !== '' && strpos($html, $tok) !== false) {
        $html = str_replace($tok, '__MOE_CSRF__', $html);
    }
    $ttl = (int)setting('page_cache_ttl', 120);
    if ($ttl < 10) $ttl = 10;
    moe_fcache_set($key, $html, $ttl, 'pc');
    if ($postId > 0) moe_fcache_set($key . '|meta', array('post' => (int)$postId), $ttl, 'pc');
}
