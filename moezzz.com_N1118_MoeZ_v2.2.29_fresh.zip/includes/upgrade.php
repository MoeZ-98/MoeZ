<?php
/**
 * MoeZ - 数据库结构自动升级
 * 覆盖安装升级时自动补齐新字段与新增设置项，老站点无需手动改表
 */

function moe_upgrade()
{
    static $ran = false;
    if ($ran) return;
    $ran = true;

    try {
        $cur = (string)setting('db_version', '0');
        // 注意：结构字段不在此处按版本号补齐，统一交给 moe_ensure_schema()（与版本号无关、失败会重试）
        $schemaOk = function_exists('moe_ensure_schema') ? moe_ensure_schema() : true;
        if (version_compare($cur, MOE_DB_VERSION, '>=')) return;

        // 新增设置项默认值
        $defaults = array(
            'site_url'           => '',
            'url_style'          => 'cat_num',
            'browser_title'      => '',
            'title_mode'         => 'browser',
            'seo_canonical'      => '1',
            'seo_og'             => '1',
            'seo_jsonld'         => '1',
            'seo_sitemap'        => '1',
            'seo_noindex_search' => '1',
            'editor_default'     => 'markdown',
            'upload_max_mb'      => '50',
            // 1.6.5：搜索引擎收录推送
            'seo_push_baidu'     => '',
            'seo_push_360'       => '',
            'seo_push_sogou'     => '',
            'seo_push_bing'      => '',
            'seo_push_auto'      => '0',
            'seo_push_last'      => '',
            // 1.6.6：品牌 / 外观 / 欢迎语 / 缓存 / 社交列表
            'admin_accent'       => '',   // 后台配色（留空 = 默认粉紫）
            'admin_c1'           => '',   // 自定义配色 1
            'admin_c2'           => '',   // 自定义配色 2
            'admin_c3'           => '',   // 自定义配色 3
            'admin_logo'         => '',   // 后台 logo（侧栏 / 登录页）
            'login_logo'         => '',   // 登录页 logo（留空用 admin_logo）
            'welcome_enabled'    => '1',  // 登录欢迎弹窗开关
            'welcome_text'       => '',   // 自定义欢迎语（每行一条）
            'social_links'       => '',   // 社交链接 JSON（空则回落旧 social_* 设置）
            'redis_enabled'      => '0',
            'redis_host'         => '127.0.0.1',
            // 1.8.0：登录页外观 / 验证码 / SMTP 邮箱 / 审核结果通知
            'login_bg'           => '',   // 登录页大背景图（留空用粉紫渐变兜底）
            'login_card_bg'      => '',   // 登录卡片背景色（留空 #ffffff）
            'login_captcha'      => '0',  // 登录图形验证码开关
            'smtp_enabled'       => '0',
            'smtp_host'          => '',
            'smtp_port'          => '465',
            'smtp_secure'        => 'ssl',
            'smtp_user'          => '',
            'smtp_pass'          => '',
            'smtp_from'          => '',
            'smtp_from_name'     => '',
            'mail_test_to'       => '',
            'mail_notify_link'   => '0',  // 友链审核结果邮件通知
            'mail_notify_comment'=> '0',  // 评论审核结果邮件通知
            'redis_port'         => '6379',
            'redis_auth'         => '',
            'redis_db'           => '0',
            // 1.9.0：页面缓存（访客静态化）与查询缓存
            'page_cache'         => '1',
            'page_cache_ttl'     => '120',
        );
        try {
            foreach ($defaults as $k => $v) {
                if (!isset($GLOBALS['moe_settings'][$k])) setting_set($k, $v);
            }
        } catch (Throwable $e) { /* 设置表未就绪时忽略 */ }

        // 1.6.6：旧的固定社交设置迁移为动态 JSON 列表（一次迁移，之后以后台动态列表为准）
        try {
            if ((string)setting('social_links', '') === '') {
                $mig = array();
                $map = array(
                    'social_github'    => array('GitHub', '🐱'),
                    'social_bilibili'  => array('哔哩哔哩', '📺'),
                    'social_weibo'     => array('微博', '🔥'),
                    'social_twitter'   => array('X / Twitter', '🐦'),
                    'social_mail'      => array('邮箱', '✉️'),
                );
                foreach ($map as $k => $info) {
                    $url = trim((string)setting($k, ''));
                    if ($url === '') continue;
                    if (strpos($url, '@') !== false && strpos($url, '/') === false) $url = 'mailto:' . $url;
                    $mig[] = array('name' => $info[0], 'url' => $url, 'icon' => $info[1]);
                }
                if (!empty($mig)) setting_set('social_links', json_encode($mig, JSON_UNESCAPED_UNICODE));
            }
        } catch (Throwable $e) { /* 迁移失败不影响升级 */ }

        // 1.8.3：老站点没有任何社交链接时，预置常用社交链接（后台可随意增删改）
        // 已配置过的站点（social_links 非空）完全不受影响
        try {
            if (trim((string)setting('social_links', '')) === '') {
                setting_set('social_links', json_encode(array(
                    array('name' => 'GitHub',   'url' => 'https://github.com/',         'icon' => '🐱'),
                    array('name' => '哔哩哔哩', 'url' => 'https://space.bilibili.com/', 'icon' => '📺'),
                    array('name' => '微博',     'url' => 'https://weibo.com/',          'icon' => '🔥'),
                ), JSON_UNESCAPED_UNICODE));
            }
        } catch (Throwable $e) { /* 预置失败不影响升级 */ }

        // 1.6.4：标题拆分为「网站标题（site_name）+ 浏览器标题（browser_title）+ 标题显示方式（title_mode）」
        // 旧「首页标题」的值迁移为浏览器标题，旧的标题分隔符设置废弃并清理
        try {
            $oldHome = trim((string)setting('seo_home_title', ''));
            if ($oldHome !== '' && trim((string)setting('browser_title', '')) === '') {
                setting_set('browser_title', $oldHome);
            }
            q('DELETE FROM ' . moe_table('settings') . " WHERE skey IN ('seo_home_title','seo_title_sep')");
            unset($GLOBALS['moe_settings']['seo_home_title'], $GLOBALS['moe_settings']['seo_title_sep']);
        } catch (Throwable $e) { /* 设置表未就绪时忽略 */ }

        // 1.5.0：蜘蛛来访记录表
        q('CREATE TABLE IF NOT EXISTS ' . moe_table('spiders') . " (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            spider VARCHAR(30) NOT NULL DEFAULT '',
            path VARCHAR(255) NOT NULL DEFAULT '',
            ip VARCHAR(46) NOT NULL DEFAULT '',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY spider (spider),
            KEY created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // 1.6.3：蜘蛛身份校验缓存表（同一 IP + 引擎 7 天内只做一次 DNS 校验）
        q('CREATE TABLE IF NOT EXISTS ' . moe_table('spider_check') . " (
            ip VARCHAR(46) NOT NULL DEFAULT '',
            engine VARCHAR(30) NOT NULL DEFAULT '',
            state VARCHAR(10) NOT NULL DEFAULT 'unknown',
            checked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (ip, engine),
            KEY checked (checked_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // 1.6.3：清理历史遗留的非国内搜索引擎蜘蛛记录（Google / 其他 UA 通配等）
        try {
            $keep = array('百度', '360搜索', '搜狗', '必应');
            q('DELETE FROM ' . moe_table('spiders') . ' WHERE spider NOT IN (?,?,?,?)', $keep);
        } catch (Throwable $e) { /* 表未就绪时忽略 */ }

        // URL 样式收敛为两种（分类目录/编号、根目录/编号），历史配置统一迁移
        if (!array_key_exists((string)setting('url_style', ''), url_styles())) {
            setting_set('url_style', 'cat_num');
        }

        // 文章编号：为历史文章按分类从 1 开始补齐（每个分类独立计算）
        $pt = moe_table('posts');
        $buckets = rows('SELECT DISTINCT category_id FROM ' . $pt . " WHERE type='post' AND url_num = 0");
        foreach ((array)$buckets as $b) {
            $cid = (int)$b['category_id'];
            $max = (int)one('SELECT COALESCE(MAX(url_num),0) FROM ' . $pt . " WHERE type='post' AND category_id = ?", array($cid));
            $list = rows('SELECT id FROM ' . $pt . " WHERE type='post' AND category_id = ? AND url_num = 0 ORDER BY created_at ASC, id ASC", array($cid));
            foreach ((array)$list as $it) {
                $max++;
                q('UPDATE ' . $pt . ' SET url_num = ? WHERE id = ?', array($max, (int)$it['id']));
            }
        }

        // 1.2.0：默认模板切换为「萌站 Zz · 极光名片」
        // 仅在用户仍停留在旧默认模板 default 时切换；后台手动选过的模板不受影响
        if (setting('theme', '') === 'default' && is_dir(MOE_ROOT . '/templates/moezzz')) {
            setting_set('theme', 'moezzz');
        }

        // 1.9.0：性能索引 —— 首页/分类列表按「类型 + 状态 + 时间」排序、文章评论按「文章 + 状态」统计
        // 已存在索引时跳过；表很大时 ALTER 会有短暂开销，仅执行一次
        try {
            $pt = moe_table('posts');
            $have = array();
            foreach (rows('SHOW INDEX FROM ' . $pt) as $ix) {
                if (isset($ix['Key_name'])) $have[(string)$ix['Key_name']] = true;
            }
            if (!isset($have['type_status_created'])) {
                q('ALTER TABLE ' . $pt . ' ADD INDEX type_status_created (type, status, created_at)');
            }
        } catch (Throwable $e) { /* 权限不足或已存在：忽略 */ }
        try {
            $ct = moe_table('comments');
            $have = array();
            foreach (rows('SHOW INDEX FROM ' . $ct) as $ix) {
                if (isset($ix['Key_name'])) $have[(string)$ix['Key_name']] = true;
            }
            if (!isset($have['post_status'])) {
                q('ALTER TABLE ' . $ct . ' ADD INDEX post_status (post_id, status)');
            }
        } catch (Throwable $e) { /* 忽略 */ }

        // 只有结构真的补齐了才推进版本号，否则下次请求继续尝试
        if ($schemaOk !== false) setting_set('db_version', MOE_DB_VERSION);
    } catch (Throwable $e) {
        // 数据库未就绪（首次安装）或权限不足时静默跳过
    }
}
