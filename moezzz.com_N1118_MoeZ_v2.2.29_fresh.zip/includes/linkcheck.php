<?php
/**
 * MoeZ - 友链回链检测 / 站点信息抓取
 * 零依赖：优先 curl，缺失时降级 file_get_contents
 */

/** 抓取 URL 内容（带超时），失败返回空字符串；2.2.20 起支持超时参数分级 */
function moe_http_get($url, $timeout = 8)
{
    $url = trim((string)$url);
    if ($url === '' || !preg_match('#^https?://#i', $url)) return '';

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 3,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
            CURLOPT_ENCODING       => '',
            CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; MoeZ/1.4; friend-link check)',
        ));
        $body = curl_exec($ch);
        curl_close($ch);
        return is_string($body) ? $body : '';
    }

    $ctx = stream_context_create(array(
        'http' => array(
            'timeout'        => $timeout,
            'max_redirects'  => 3,
            'ignore_errors'  => true,
            'header'         => "User-Agent: Mozilla/5.0 (compatible; MoeZ/1.4; friend-link check)\r\n",
        ),
        'ssl' => array('verify_peer' => false, 'verify_peer_name' => false),
    ));
    return (string)@file_get_contents($url, false, $ctx);
}

/** 本站域名集合（含带 www / 不带 www 两种形式，站点地址设置优先） */
function moe_site_hosts()
{
    $hosts = array();
    foreach (array(setting('site_url', ''), base_url()) as $src) {
        $h = strtolower((string)parse_url((string)$src, PHP_URL_HOST));
        if ($h === '') continue;
        $hosts[] = $h;
        if (strpos($h, 'www.') === 0) $hosts[] = substr($h, 4);
        else $hosts[] = 'www.' . $h;
    }
    return array_values(array_unique($hosts));
}

/**
 * 2.2.20：判断一段 HTML 里是否含有指向本站的 <a href>
 * @return bool
 */
function moe_html_has_backlink($html, $hosts = null)
{
    if ($hosts === null) $hosts = moe_site_hosts();
    if (!is_array($hosts) || !$hosts) return false;
    if (preg_match_all('#<a\b[^>]*href\s*=\s*(["\'])([^"\']+)\1#is', (string)$html, $ms)) {
        foreach ($ms[2] as $href) {
            $h = strtolower((string)parse_url(trim($href), PHP_URL_HOST));
            if ($h !== '' && in_array($h, $hosts, true)) return true;
        }
    }
    return false;
}

/**
 * 2.2.20：生成对方站点的「候选内页」地址列表 —— 友情链接不一定挂在首页，
 * 很多站点放在独立的友链页 / 关于页 / 分类内页。按命中概率排序，控制数量防止检测过慢。
 */
function moe_backlink_candidate_pages($url)
{
    $p = parse_url($url);
    $scheme = !empty($p['scheme']) ? $p['scheme'] : 'https';
    $host   = !empty($p['host']) ? $p['host'] : '';
    if ($host === '') return array();
    $base = $scheme . '://' . $host;
    $paths = array(
        '/links', '/link', '/links/', '/link/', '/fl', '/yqlj',
        '/friend', '/friends', '/friendlink', '/friendly-link', '/blogroll',
        '/links.html', '/link.html', '/fl.html', '/yqlj.html',
        '/about', '/about/links', '/about/friend', '/about/me',
        '/navigation', '/nav', '/daohang', '/sites', '/webdir',
        '/links/index.html', '/link/index.html', '/blogroll.html',
    );
    $out = array();
    foreach ($paths as $pt) $out[] = $base . $pt;
    return $out;
}

/**
 * 检测目标站点是否已添加本站链接（2.2.20：首页 → 友链独立页 → 常见内页，全部覆盖）
 * @return array array('ok'=>bool, 'title'=>'对方站点名', 'msg'=>'结果说明')
 */
function moe_check_backlink($url)
{
    $url = trim((string)$url);
    if ($url === '') return array('ok' => false, 'title' => '', 'desc' => '', 'icon' => '', 'msg' => 'URL 为空');

    if (!preg_match('#^https?://#i', $url)) $url = 'https://' . ltrim($url, '/');

    $html = moe_http_get($url, 8);
    if (trim($html) === '') {
        return array('ok' => false, 'title' => '', 'desc' => '', 'icon' => moe_link_icon($url, ''), 'msg' => '无法访问对方站点（超时或拒绝连接）');
    }

    // 对方站点标题（自动获取站点名用）
    $title = '';
    if (preg_match('#<title[^>]*>(.*?)</title>#is', $html, $m)) {
        $title = trim(html_entity_decode(strip_tags($m[1]), ENT_QUOTES, 'UTF-8'));
        if (function_exists('mb_substr') && mb_strlen($title, 'UTF-8') > 60) $title = mb_substr($title, 0, 60, 'UTF-8');
    }

    // 对方站点描述（meta description / og:description）
    $desc = '';
    if (preg_match('#<meta[^>]+name\s*=\s*["\']description["\'][^>]*content\s*=\s*["\']([^"\']*)["\']#is', $html, $m)
        || preg_match('#<meta[^>]+content\s*=\s*["\']([^"\']*)["\'][^>]*name\s*=\s*["\']description["\']#is', $html, $m)) {
        $desc = trim(html_entity_decode($m[1], ENT_QUOTES, 'UTF-8'));
    }
    if ($desc === '' && preg_match('#<meta[^>]+property\s*=\s*["\']og:description["\'][^>]*content\s*=\s*["\']([^"\']*)["\']#is', $html, $m)) {
        $desc = trim(html_entity_decode($m[1], ENT_QUOTES, 'UTF-8'));
    }
    if ($desc !== '' && function_exists('mb_substr')) $desc = mb_substr($desc, 0, 120, 'UTF-8');

    // 是否存在指向本站的 <a href>：先查首页，查不到再扫常见友链独立页 / 内页
    $ok = moe_html_has_backlink($html);
    $where = '对方首页';
    if (!$ok) {
        $candidates = moe_backlink_candidate_pages($url);
        foreach ($candidates as $cu) {
            $sub = moe_http_get($cu, 6);
            if (trim($sub) === '') continue;
            if (moe_html_has_backlink($sub)) {
                $ok = true;
                $where = (string)parse_url($cu, PHP_URL_PATH);
                break;
            }
        }
    }

    $msg = $ok
        ? ('已检测到本站链接 ✅（' . $where . '）')
        : '对方首页与常见友链页均未检测到本站链接（若为 JS 动态渲染可能误判，可人工审核）';

    return array('ok' => $ok, 'title' => $title, 'desc' => $desc, 'icon' => moe_link_icon($url, $html), 'msg' => $msg);
}

/**
 * 解析站点图标地址：优先页面 <link rel="icon">，其次 /favicon.ico
 * @param string $url  站点地址
 * @param string $html 首页 HTML（为空则直接返回 favicon.ico）
 */
function moe_link_icon($url, $html = '')
{
    $p = parse_url($url);
    $scheme = !empty($p['scheme']) ? $p['scheme'] : 'https';
    $host   = !empty($p['host']) ? $p['host'] : '';
    if ($host === '') return '';

    if ($html !== '') {
        if (preg_match_all('#<link\b[^>]*>#is', $html, $ms)) {
            foreach ($ms[0] as $tag) {
                if (!preg_match('#rel\s*=\s*(["\'])([^"\']*)\1#is', $tag, $rm)) continue;
                $rel = strtolower($rm[2]);
                if (strpos($rel, 'icon') === false) continue;
                if (!preg_match('#href\s*=\s*(["\'])([^"\']+)\1#is', $tag, $hm)) continue;
                $href = trim(html_entity_decode($hm[2], ENT_QUOTES, 'UTF-8'));
                if ($href === '') continue;
                if (preg_match('#^//#', $href)) return $scheme . ':' . $href;
                if (preg_match('#^https?://#i', $href)) return $href;
                if ($href[0] === '/') return $scheme . '://' . $host . $href;
                return $scheme . '://' . $host . '/' . ltrim($href, './');
            }
        }
    }
    return $scheme . '://' . $host . '/favicon.ico';
}

/** 从站点 URL 提取主机名（不含 www.），失败返回空 */
function moe_url_host($url)
{
    $h = strtolower((string)parse_url(trim((string)$url), PHP_URL_HOST));
    return preg_replace('/^www\./', '', $h);
}
