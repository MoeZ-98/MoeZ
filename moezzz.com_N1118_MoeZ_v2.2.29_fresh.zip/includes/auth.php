<?php
/**
 * MoeZ · 授权与官方增量更新（2.2.0）
 * ------------------------------------------------------------
 * 设计目标：不额外建站、不使用独立的「授权管理端」。
 * 官方主站（运行本程序的授权站）通过根目录 update-api.php 对外提供：
 *   act=verify    授权码验证 + 最新版本信息（程序 + 全部主题）
 *   act=manifest  官方文件清单（路径 + sha1 + 大小）
 *   act=file      按路径下载单个官方文件
 *
 * 客户站（其他站长）在后台仪表盘填写授权码后：
 *   · 自动检测程序与当前全部主题是否落后于官方最新版；
 *   · 一键「增量在线更新」：对比文件清单 sha1，只下载有变化的文件，
 *     官方站无需存放任何更新包（存储零额外占用），流量也最小；
 *   · 更新前逐文件备份到 content/backups/，失败自动回滚；
 *   · 更新成功后自动清理旧备份（默认仅保留最近 3 份）。
 *
 * 授权码格式（HMAC 自校验，无需数据库存储）：
 *   MH-<到期时间戳>-<8位随机>-<HMAC-SHA256 前 20 位>
 *   签名内容 = 绑定域名 | 到期时间戳 | 随机数，密钥仅授权站持有
 *   （update_hub_secret，在授权站后台「授权发放」卡片初始化）
 */

/* ============ 域名与授权码 ============ */

/** 规整域名：取 host、去端口、去 www.、转小写；支持直接填 URL */
function moe_auth_normalize_domain($input)
{
    $s = trim((string)$input);
    if ($s === '') return '';
    if (strpos($s, '://') !== false) $s = (string)parse_url($s, PHP_URL_HOST);
    $s = strtolower(trim($s));
    $s = preg_replace('/:\d+$/', '', $s);
    $s = preg_replace('/^www\./', '', $s);
    return preg_match('/^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}$/', $s) ? $s : '';
}

/** 当前站点绑定域名（客户站自身） */
function moe_auth_site_domain()
{
    $host = (string)($_SERVER['HTTP_HOST'] ?? '');
    if ($host === '') $host = (string)parse_url(base_url(), PHP_URL_HOST);
    return moe_auth_normalize_domain($host);
}

/** 授权码签名（HMAC-SHA256 前 20 位） */
function moe_auth_code_sign($domain, $expireTs, $rand, $secret)
{
    return substr(hash_hmac('sha256', $domain . '|' . $expireTs . '|' . $rand, (string)$secret), 0, 20);
}

/** 生成授权码（仅授权站后台调用）；$days<=0 表示永久授权 */
function moe_auth_code_generate($domain, $days, $secret)
{
    $domain = moe_auth_normalize_domain($domain);
    if ($domain === '') return array('ok' => 0, 'msg' => '绑定域名格式不正确');
    $days = (int)$days;
    if ($days > 0) $days = max(1, min(3650, $days));
    $expireTs = $days > 0 ? time() + $days * 86400 : 0;
    $rand = bin2hex(function_exists('random_bytes') ? random_bytes(4) : substr(md5(uniqid('', true)), 0, 4));
    return array('ok' => 1, 'code' => 'MH-' . $expireTs . '-' . $rand . '-' . moe_auth_code_sign($domain, $expireTs, $rand, $secret),
                 'expire_ts' => $expireTs, 'expire' => $expireTs > 0 ? date('Y-m-d', $expireTs) : '永久',
                 'domain' => $domain);
}

/** 校验授权码：返回 array(ok, msg, expire_ts, expire) */
function moe_auth_code_verify($code, $domain, $secret)
{
    $code = trim((string)$code);
    $domain = moe_auth_normalize_domain($domain);
    if ($domain === '') return array('ok' => 0, 'msg' => '域名格式不正确');
    $p = explode('-', strtoupper(trim($code)));
    if (count($p) !== 4 || $p[0] !== 'MH' || !ctype_digit($p[1]) || !preg_match('/^[0-9A-Fa-f]{8}$/', $p[2])
        || !preg_match('/^[0-9A-Fa-f]{20,}$/', $p[3])) {
        return array('ok' => 0, 'msg' => '授权码格式不正确');
    }
    $expireTs = (int)$p[1]; $rand = strtolower($p[2]);
    /* 2.2.23：兼容早期版本签发的更长签名 —— 前 20 位与当前算法一致即视为有效 */
    $sign = strtoupper(moe_auth_code_sign($domain, $expireTs, $rand, (string)$secret));
    if (strncmp($sign, strtoupper($p[3]), 20) !== 0) {
        return array('ok' => 0, 'msg' => '授权码无效（签名不匹配，请核对授权码与绑定的域名）');
    }
    if ($expireTs > 0 && $expireTs < time()) {
        return array('ok' => 0, 'msg' => '授权码已于 ' . date('Y-m-d', $expireTs) . ' 过期');
    }
    return array('ok' => 1, 'msg' => '授权有效', 'expire_ts' => $expireTs,
                 'expire' => $expireTs > 0 ? date('Y-m-d', $expireTs) : '永久');
}

/* ============ 客户站：授权状态与检测 ============ */

function moe_auth_hub_url()
{
    $u = trim((string)setting('auth_hub_url', ''));
    if ($u === '') return '';
    return rtrim($u, '/');
}

function moe_auth_code()
{
    return trim((string)setting('auth_code', ''));
}

/** 本地已装插件（各插件目录的 plugin.json），key = 插件目录名 */
function moe_auth_local_plugins()
{
    $out = array();
    $files = glob(MOE_ROOT . '/content/plugins/*/plugin.json');
    foreach (is_array($files) ? $files : array() as $f) {
        $j = json_decode((string)@file_get_contents($f), true);
        if (!is_array($j)) continue;
        $dir = basename(dirname($f));
        $j['dir'] = $dir;
        $out[$dir] = $j;
    }
    return $out;
}

/** 授权检测结果缓存（10 分钟，不联网） */
function moe_auth_cached()
{
    $c = json_decode((string)setting('auth_check_cache', ''), true);
    return is_array($c) && !empty($c['checked_ts']) && (time() - (int)$c['checked_ts'] < 600) ? $c : array();
}

/** 2.2.23：从授权检测结果缓存提取官方主题 / 插件最新版本映射（仅供提示展示，允许略过期） */
function moe_auth_remote_versions()
{
    $c = json_decode((string)setting('auth_check_cache', ''), true);
    $out = array('themes' => array(), 'plugins' => array(), 'authed' => 0);
    if (!is_array($c)) return $out;
    $out['authed'] = !empty($c['authed']);
    foreach (array('themes', 'plugins') as $key) {
        foreach ((array)($c[$key] ?? array()) as $e) {
            if (is_array($e) && !empty($e['dir']) && isset($e['version'])) {
                $out[$key][(string)$e['dir']] = (string)$e['version'];
            }
        }
    }
    return $out;
}

/** 拉取授权站 JSON（GET，不跟随重定向） */
function moe_auth_api_get($url, &$err)
{    $err = '';
    $fe = '';
    if (!function_exists('moe_update_feed_valid') || !moe_update_feed_valid($url, $fe)) {
        $err = '授权站地址不合法：' . $fe; return null;
    }
    $body = false;
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 12,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT      => 'MoeZ/' . MOE_VERSION . ' auth',
        ));
        $body = curl_exec($ch);
        if ($body === false) $err = '连接授权站失败：' . curl_error($ch);
        curl_close($ch);
    } else {
        $ctx = stream_context_create(array('http' => array('timeout' => 12, 'follow_location' => 0,
            'user_agent' => 'MoeZ/' . MOE_VERSION . ' auth')));
        $body = @file_get_contents($url, false, $ctx);
        if ($body === false) $err = '连接授权站失败（请检查地址或 allow_url_fopen）';
    }
    if ($body === false || $body === '') return null;
    $j = json_decode(trim((string)$body), true);
    if (!is_array($j)) { $err = '授权站返回格式不正确'; return null; }
    return $j;
}

/**
 * 授权检测（程序 + 主题最新版）：结果缓存 10 分钟
 * 返回 {ok, authed, auth{domain,expire}, program{version,has_new,...}, themes[], msg, checked_at}
 */
function moe_auth_check($force = false)
{
    if (!$force) {
        $c = moe_auth_cached();
        if ($c) return $c;
    }
    $res = array('ok' => 1, 'authed' => 0, 'msg' => '', 'themes' => array(), 'plugins' => array(),
                 'program' => array('version' => MOE_VERSION, 'has_new' => 0),
                 'checked_at' => date('Y-m-d H:i:s'), 'checked_ts' => time());

    $code = moe_auth_code();
    $hub  = moe_auth_hub_url();
    $domain = moe_auth_site_domain();
    if ($code === '' || $hub === '') {
        $res['msg'] = '尚未填写授权码，填入后可自动检测程序与主题更新并在线增量更新';
        setting_set('auth_check_cache', json_encode($res, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return $res;
    }

    $err = '';
    $r = moe_auth_api_get($hub . '/update-api.php?act=verify'
        . '&code=' . urlencode($code) . '&domain=' . urlencode($domain)
        . '&v=' . urlencode(MOE_VERSION), $err);
    if (!is_array($r)) {
        $res['msg'] = $err !== '' ? $err : '授权站无响应';
        setting_set('auth_check_cache', json_encode($res, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return $res;
    }
    if (empty($r['ok'])) {
        $res['msg'] = (string)($r['msg'] ?? '授权验证未通过');
        // 明确的授权失效 → 清掉本地保存的授权码，避免反复报错
        if (stripos($res['msg'], '无效') !== false || stripos($res['msg'], '过期') !== false
            || stripos($res['msg'], '锁定') !== false) {
            setting_set('auth_code', '');
        }
        setting_set('auth_check_cache', json_encode($res, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        return $res;
    }

    // 授权有效：组装程序 + 主题检测结果
    $auth = is_array($r['auth'] ?? null) ? $r['auth'] : array();
    $res['authed'] = 1;
    $res['auth'] = array(
        'domain' => (string)($auth['domain'] ?? $domain),
        'expire' => (string)($auth['expire'] ?? ''),
        'note'   => (string)($auth['note'] ?? ''),
    );
    $prog = is_array($r['program'] ?? null) ? $r['program'] : array();
    $latest = trim((string)($prog['version'] ?? ''));
    $res['program'] = array(
        'version'   => $latest !== '' ? $latest : MOE_VERSION,
        'date'      => (string)($prog['date'] ?? ''),
        'changelog' => (string)($prog['changelog'] ?? ''),
        'download'  => (string)($prog['download'] ?? ''),
        'download_pwd' => (string)($prog['download_pwd'] ?? ''),   // 2.2.17：网盘分享密码（官方资源「下载密码」字段）
        'has_new'   => $latest !== '' && version_compare($latest, MOE_VERSION, '>') ? 1 : 0,
    );
    // 主题：官方主题列表 × 本地已装版本（未安装的官方主题也可一键安装）
    $localThemes = array();
    foreach (themes_list() as $t) $localThemes[$t['dir']] = $t;
    $remoteThemes = is_array($r['themes'] ?? null) ? $r['themes'] : array();
    foreach ($remoteThemes as $rt) {
        if (!is_array($rt)) continue;
        $slug = trim((string)($rt['dir'] ?? ''));
        if ($slug === '') continue;
        $installed = isset($localThemes[$slug]);
        $cur = $installed ? (string)$localThemes[$slug]['version'] : '';
        $lat = trim((string)($rt['version'] ?? ''));
        $res['themes'][] = array(
            'dir'       => $slug,
            'name'      => (string)($rt['name'] !== '' ? $rt['name'] : $slug),
            'desc'      => (string)($rt['desc'] ?? ''),
            'installed' => $installed ? 1 : 0,
            'current'   => $cur,
            'latest'    => $lat,
            'has_new'   => $installed && $lat !== '' && version_compare($lat, $cur, '>') ? 1 : 0,
            'download'  => (string)($rt['download'] ?? ''),   // 官方资源里填的整包直链（可选）
            'download_pwd' => (string)($rt['download_pwd'] ?? ''),   // 2.2.17：网盘分享密码
        );
    }
    // 插件：官方插件列表 × 本地 content/plugins 版本（未安装也可一键安装）
    $localPlugins = moe_auth_local_plugins();
    $remotePlugins = is_array($r['plugins'] ?? null) ? $r['plugins'] : array();
    foreach ($remotePlugins as $rp) {
        if (!is_array($rp)) continue;
        $slug = trim((string)($rp['dir'] ?? ''));
        if ($slug === '') continue;
        $installed = isset($localPlugins[$slug]);
        $cur = $installed ? (string)($localPlugins[$slug]['version'] ?? '') : '';
        $lat = trim((string)($rp['version'] ?? ''));
        $res['plugins'][] = array(
            'dir'       => $slug,
            'name'      => (string)($rp['name'] !== '' ? $rp['name'] : $slug),
            'desc'      => (string)($rp['desc'] ?? ''),
            'installed' => $installed ? 1 : 0,
            'current'   => $cur,
            'latest'    => $lat,
            'has_new'   => $installed && $lat !== '' && version_compare($lat, $cur, '>') ? 1 : 0,
            'download'  => (string)($rp['download'] ?? ''),
            'download_pwd' => (string)($rp['download_pwd'] ?? ''),   // 2.2.17：网盘分享密码
        );
    }
    // 授权站的违规警告（warn 状态）随检测结果透出
    if (isset($r['notice']) && (string)$r['notice'] !== '') $res['notice'] = (string)$r['notice'];
    $res['msg'] = '授权有效' . ($res['auth']['expire'] !== '' ? '（' . $res['auth']['expire'] . '）' : '');
    setting_set('auth_check_cache', json_encode($res, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    return $res;
}

/* ============ 客户站：增量在线更新 ============ */

/** 拉取单个官方文件到本地（act=file），并按清单 sha1 校验 */
function moe_auth_fetch_file($hub, $code, $domain, $type, $slug, $path, $sha1, $dest, &$err)
{
    $err = '';
    $url = $hub . '/update-api.php?act=file&type=' . $type
         . ($slug !== '' ? '&slug=' . urlencode($slug) : '')
         . '&path=' . urlencode($path) . '&code=' . urlencode($code) . '&domain=' . urlencode($domain);
    $fe = '';
    if (!moe_update_feed_valid($url, $fe)) { $err = '地址不合法：' . $fe; return false; }
    $ok = false;
    if (function_exists('curl_init')) {
        $fp = @fopen($dest, 'wb');
        if (!$fp) { $err = '无法创建临时文件'; return false; }
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT      => 'MoeZ/' . MOE_VERSION . ' incr',
        ));
        $body = curl_exec($ch);
        $code2 = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $cerr = curl_error($ch);
        curl_close($ch);
        if ($body !== false && $code2 === 200) {
            fwrite($fp, $body); $ok = true;
        } else {
            $err = '下载失败：' . ($cerr !== '' ? $cerr : 'HTTP ' . $code2);
        }
        fclose($fp);
        if (!$ok) { @unlink($dest); return false; }
    } else {
        $ctx = stream_context_create(array('http' => array('timeout' => 30, 'follow_location' => 0,
            'user_agent' => 'MoeZ/' . MOE_VERSION . ' incr')));
        $body = @file_get_contents($url, false, $ctx);
        if ($body === false) { $err = '下载失败（请开启 curl 扩展）'; return false; }
        if (@file_put_contents($dest, $body) === false) { $err = '写入临时文件失败'; return false; }
    }
    $real = hash_file('sha1', $dest);
    if ($real !== strtolower($sha1)) { @unlink($dest); $err = '文件校验不一致：' . $path; return false; }
    return true;
}

/** 递归删除目录（清理暂存目录用） */
function moe_auth_rrmdir($dir)
{
    if (!is_dir($dir)) return;
    $items = @scandir($dir);
    foreach (is_array($items) ? $items : array() as $it) {
        if ($it === '.' || $it === '..') continue;
        $p = rtrim($dir, '/\\') . '/' . $it;
        if (is_dir($p)) moe_auth_rrmdir($p);
        else @unlink($p);
    }
    @rmdir($dir);
}

/**
 * 通用增量更新（程序 / 主题 / 插件共用）
 * $type = program | theme | plugin；theme/plugin 时 $slug 为目录名，
 * 本地不存在该目录时视为全新安装（授权站清单为准）
 * 返回 {ok, msg, steps[], files, version, backup}
 */
function moe_auth_incremental_apply($type, $slug, $confirm = false)
{
    $steps = array();
    $fail = function ($msg, $rolled = 0) use (&$steps) {
        return array('ok' => 0, 'msg' => $msg, 'steps' => $steps, 'rolled_back' => $rolled);
    };
    $log = function ($s) use (&$steps) { $steps[] = $s; };

    if ((string)$confirm !== '1') return $fail('缺少二次确认，请从仪表盘点击更新按钮');
    $type = in_array($type, array('theme', 'plugin'), true) ? $type : 'program';
    if ($type === 'theme') {
        $slug = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$slug);
        if ($slug === '') return $fail('模板目录名不合法');
    } elseif ($type === 'plugin') {
        $slug = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$slug);
        if ($slug === '') return $fail('插件目录名不合法');
    }

    $check = moe_auth_check(false);
    if (empty($check['authed'])) return $fail('授权无效或未验证，请先在「授权与主题更新」卡验证授权');
    $code = moe_auth_code();
    $hub  = moe_auth_hub_url();
    $domain = moe_auth_site_domain();

    // ① 拉取官方文件清单
    $err = '';
    $man = moe_auth_api_get($hub . '/update-api.php?act=manifest&type=' . $type
        . ($type !== 'program' ? '&slug=' . urlencode($slug) : '')
        . '&code=' . urlencode($code) . '&domain=' . urlencode($domain), $err);
    if (!is_array($man) || empty($man['ok'])) return $fail('获取官方清单失败：' . ($err !== '' ? $err : (string)($man['msg'] ?? '未知错误')));
    $files = is_array($man['files'] ?? null) ? $man['files'] : array();
    if (!$files) return $fail('官方清单为空，已中止');
    if (count($files) > 3000) return $fail('官方清单文件数异常（超过 3000），已中止');
    $log('📋 已获取官方清单：' . count($files) . ' 个文件 · 官方版本 v' . (string)($man['version'] ?? '?'));

    // ② 对比本地 sha1，找出需要更新的文件（本地缺失的文件也纳入安装）
    $baseDir = $type === 'theme' ? MOE_ROOT . '/templates/' . $slug
             : ($type === 'plugin' ? MOE_ROOT . '/content/plugins/' . $slug : MOE_ROOT);
    $need = array(); $totalSize = 0; $same = 0;
    foreach ($files as $row) {
        if (!is_array($row) || count($row) < 3) continue;
        list($p, $sha1, $size) = $row;
        $ve = '';
        if (!moe_update_safe_path($p, $ve)) continue;   // 与官方包同一套安全规则，跳过受保护项
        $abs = $baseDir . '/' . $p;
        if (is_file($abs) && strtolower((string)hash_file('sha1', $abs)) === strtolower((string)$sha1)) { $same++; continue; }
        $need[] = array('p' => $p, 'sha1' => $sha1, 'size' => (int)$size);
        $totalSize += (int)$size;
    }
    if ($totalSize > 60 * 1024 * 1024) return $fail('需下载内容超过 60MB，已中止');
    $verb = is_dir($baseDir) ? '需要更新' : '全新安装';
    $log('🔎 对比完成：' . $same . ' 个文件已一致，' . count($need) . ' 个' . $verb . '（约 ' . round($totalSize / 1024, 1) . ' KB）');
    if (!$need) {
        return array('ok' => 1, 'msg' => '已与官方最新版一致，无需更新', 'steps' => $steps,
                     'files' => 0, 'version' => (string)($man['version'] ?? ''), 'backup' => '');
    }

    // ③ 下载到暂存目录并逐个校验
    $wsErr = '';
    $ws = moe_update_workspace($wsErr);
    if ($ws === '') return $fail($wsErr);
    $stage = MOE_ROOT . '/content/updates/stage-' . substr(md5(uniqid('', true)), 0, 8);
    if (!@mkdir($stage, 0755, true) && !is_dir($stage)) return $fail('无法创建暂存目录 content/updates/');
    register_shutdown_function(function () use ($stage) { if (is_dir($stage)) moe_auth_rrmdir($stage); });

    $got = 0;
    foreach ($need as $i => $it) {
        $dest = $stage . '/' . $it['p'];
        if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0755, true);
        $derr = '';
        if (!moe_auth_fetch_file($hub, $code, $domain, $type, $type !== 'program' ? $slug : '', $it['p'], $it['sha1'], $dest, $derr)) {
            return $fail('下载失败：' . $it['p'] . '（' . $derr . '），已中止且未改动任何线上文件');
        }
        $got++;
        if ($got % 20 === 0) $log('⬇ 已下载 ' . $got . '/' . count($need) . ' …');
    }
    $log('⬇ 下载完成 ' . $got . ' 个文件，全部通过 sha1 校验');

    // ④ 预检可写性 + 备份将被覆盖的文件
    $backupName = 'au-' . date('Ymd-His') . '-' . substr(md5(uniqid('', true)), 0, 6);
    $backupDir  = $ws . '/' . $backupName;
    if (!@mkdir($backupDir . '/files', 0755, true) && !is_dir($backupDir . '/files')) {
        return $fail('无法创建备份目录，请检查 content/ 写入权限');
    }
    $updated = array(); $created = array();
    foreach ($need as $it) {
        $dest = $baseDir . '/' . $it['p'];
        if (is_file($dest)) {
            if (!moe_update_ensure_writable($dest)) return $fail(moe_update_unwritable_msg($it['p'], '文件'));
            $bak = $backupDir . '/files/' . $it['p'];
            if (!is_dir(dirname($bak))) @mkdir(dirname($bak), 0755, true);
            if (!@copy($dest, $bak)) return $fail('备份失败：' . $it['p'] . '，已中止（未覆盖任何文件）');
            $updated[] = $it['p'];
        } else {
            $probe = dirname($dest);
            while (!is_dir($probe) && $probe !== MOE_ROOT && dirname($probe) !== $probe) $probe = dirname($probe);
            if (!moe_update_ensure_writable($probe)) return $fail(moe_update_unwritable_msg($it['p'], '目录'));
            $created[] = $it['p'];
        }
    }
    @file_put_contents($backupDir . '/manifest.json', json_encode(array(
        'time' => date('Y-m-d H:i:s'), 'origin' => 'auth-incremental:' . $type . ($type === 'theme' ? ':' . $slug : ''),
        'from_version' => $type === 'theme' ? (string)($check['themes'][0]['current'] ?? '') : MOE_VERSION,
        'to_version' => (string)($man['version'] ?? ''),
        'updated' => $updated, 'created' => $created,
        'how_to_rollback' => '把 files/ 下的文件按相同相对路径复制回程序根目录' . ($type === 'theme' ? '（模板目录内）' : '') . '，并删除 created 里列出的新增文件。',
    ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
    $log('🗂 已备份 ' . count($updated) . ' 个文件 → content/backups/' . $backupName);

    // ⑤ 覆盖写入；失败立即回滚
    $written = array();
    foreach ($need as $it) {
        $dest = $baseDir . '/' . $it['p'];
        $src  = $stage . '/' . $it['p'];
        $data = @file_get_contents($src);
        if ($data === false) {
            $n = function_exists('moe_update_rollback') ? moe_update_rollback($backupDir, $written) : 0;
            $log('↩️ 已回滚 ' . $n . ' 个文件');
            return $fail('读取暂存内容失败：' . $it['p'], 1);
        }
        $written[] = $it['p'];
        if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0755, true);
        if (@file_put_contents($dest, $data, LOCK_EX) !== strlen($data)) {
            $n = function_exists('moe_update_rollback') ? moe_update_rollback($backupDir, $written) : 0;
            $log('↩️ 已回滚 ' . $n . ' 个文件');
            return $fail('写入失败：' . $it['p'] . '（请检查磁盘空间与权限）', 1);
        }
    }
    $log('✅ 已更新 ' . count($written) . ' 个文件');

    // ⑥ 收尾：清暂存、清缓存、备份自动瘦身
    moe_auth_rrmdir($stage);
    if (function_exists('setting_set')) {
        setting_set('update_check_cache', '');
        setting_set('auth_check_cache', '');
        setting_set('update_last_done', json_encode(array(
            'time' => date('Y-m-d H:i:s'), 'from' => MOE_VERSION, 'to' => (string)($man['version'] ?? ''),
            'origin' => 'auth-incremental:' . $type . ($type === 'theme' ? ':' . $slug : ''),
            'backup' => 'content/backups/' . $backupName, 'files' => count($written),
        ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }
    if (function_exists('moe_backup_gc')) { $gc = moe_backup_gc(3); $log('🧹 备份自动清理：' . $gc); }
    if ($type === 'program' && function_exists('moe_content_changed')) moe_content_changed();
    if (function_exists('opcache_reset')) @opcache_reset();
    $log('🔄 缓存已清除，页面即将自动刷新');

    return array('ok' => 1, 'msg' => '更新完成', 'steps' => $steps, 'files' => count($written),
                 'version' => (string)($man['version'] ?? ''), 'backup' => 'content/backups/' . $backupName);
}

/**
 * 主题 / 插件 zip 整包应用（2.2.2）：用于官方在资源里填的网盘直链更新。
 * 自动识别包内结构（templates/<slug>/ 前缀、<slug>/ 前缀或直接主题根），
 * 备份被覆盖文件 → 写入 → 失败回滚，config.php 与 content/ 数据不受影响。
 * 返回 {ok, msg, steps[], files, backup}
 */
function moe_auth_zip_apply($zipFile, $type, $slug, $origin = 'hub-goods-zip')
{
    $steps = array();
    $fail = function ($msg, $rolled = 0) use (&$steps) {
        return array('ok' => 0, 'msg' => $msg, 'steps' => $steps, 'rolled_back' => $rolled);
    };
    $log = function ($s) use (&$steps) { $steps[] = $s; };

    $type = $type === 'plugin' ? 'plugin' : 'theme';
    $slug = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)$slug);
    if ($slug === '') return $fail(($type === 'theme' ? '主题' : '插件') . '目录名不合法');
    if (!class_exists('ZipArchive')) return $fail('PHP 未开启 zip 扩展，无法解压更新包');

    $za = new ZipArchive();
    if ($za->open($zipFile) !== true) return $fail('更新包不是有效的 zip 文件，或文件已损坏');

    // ① 读取条目（忽略目录与系统垃圾文件）
    $items = array(); $total = 0;
    for ($i = 0; $i < $za->numFiles; $i++) {
        $stat = $za->statIndex($i);
        if (!is_array($stat)) continue;
        $name = str_replace('\\', '/', (string)$stat['name']);
        if (substr($name, -1) === '/') continue;
        $base = basename($name);
        if ($base === '.DS_Store' || strtolower($base) === 'thumbs.db' || strpos($name, '__MACOSX/') !== false) continue;
        $items[] = array('idx' => $i, 'path' => $name, 'size' => (int)$stat['size']);
        $total += (int)$stat['size'];
    }
    if (!$items) { $za->close(); return $fail('更新包里没有文件'); }
    if (count($items) > 2000) { $za->close(); return $fail('更新包文件数超过 2000，已中止'); }
    if ($total > 60 * 1024 * 1024) { $za->close(); return $fail('更新包解压后超过 60MB，已中止'); }
    $log('📦 读取更新包：' . count($items) . ' 个文件 / ' . round($total / 1024, 1) . ' KB');

    // ② 识别并剥离包内前缀：templates/<slug>/ > content/plugins/<slug>/ > <slug>/ > 无前缀
    $prefixes = $type === 'theme'
        ? array('templates/' . $slug . '/', 'templates/' . $slug, $slug . '/')
        : array('content/plugins/' . $slug . '/', 'content/plugins/' . $slug, $slug . '/');
    $chosen = '';
    foreach ($prefixes as $pre) {
        $all = true;
        foreach ($items as $it) {
            if (stripos($it['path'], $pre) !== 0 && strcasecmp($it['path'], rtrim($pre, '/')) !== 0) { $all = false; break; }
        }
        if ($all) { $chosen = $pre; break; }
    }
    if ($chosen !== '') {
        $len = strlen($chosen);
        foreach ($items as $k => $it) $items[$k]['path'] = substr($it['path'], $len);
        $log('📁 已识别包内目录前缀「' . rtrim($chosen, '/') . '」，自动对齐到 ' . ($type === 'theme' ? 'templates/' : 'content/plugins/') . $slug . '/');
    }
    // 剥离后路径不允许再带 templates/ 或 content/ 顶层（防止写错位置）
    foreach ($items as $k => $it) {
        if ($it['path'] === '') { $za->close(); return $fail('更新包路径异常（空路径）'); }
        $top = strtolower(explode('/', $it['path'])[0]);
        if ($top === 'templates' || $top === 'content' || $top === 'admin' || $top === 'includes') {
            $za->close(); return $fail('更新包结构与预期不符（包含 ' . $top . '/ 顶层目录），已中止');
        }
    }

    // ③ 路径安全校验（与官方覆盖包同一套规则）
    $seen = array();
    foreach ($items as $it) {
        $err = '';
        if (!moe_update_safe_path($it['path'], $err)) {
            $za->close();
            return $fail('更新包含不允许的路径：' . $it['path'] . '（' . $err . '），已中止且未覆盖任何文件');
        }
        $key = strtolower($it['path']);
        if (isset($seen[$key])) { $za->close(); return $fail('更新包含重复路径：' . $it['path']); }
        $seen[$key] = 1;
    }

    // ④ 目标目录 + 备份
    $baseDir = $type === 'theme' ? MOE_ROOT . '/templates/' . $slug : MOE_ROOT . '/content/plugins/' . $slug;
    if ($type === 'theme' && !is_file($baseDir . '/info.php')) {
        $za->close();
        return $fail('本地没有该主题（templates/' . $slug . '/），请先在主题列表点「安装主题」');
    }
    $werr = '';
    $ws = moe_update_workspace($werr);
    if ($ws === '') { $za->close(); return $fail($werr); }
    $backupName = 'au-' . date('Ymd-His') . '-' . substr(md5(uniqid('', true)), 0, 6);
    $backupDir  = $ws . '/' . $backupName;
    if (!@mkdir($backupDir . '/files', 0755, true) && !is_dir($backupDir . '/files')) {
        $za->close(); return $fail('无法创建备份目录，请检查 content/ 写入权限');
    }

    $updated = array(); $created = array();
    foreach ($items as $it) {
        $dest = $baseDir . '/' . $it['path'];
        if (is_file($dest)) {
            if (!moe_update_ensure_writable($dest)) { $za->close(); return $fail(moe_update_unwritable_msg($it['path'], '文件')); }
            $bak = $backupDir . '/files/' . $it['path'];
            if (!is_dir(dirname($bak))) @mkdir(dirname($bak), 0755, true);
            if (!@copy($dest, $bak)) { $za->close(); return $fail('备份失败：' . $it['path'] . '，已中止（未覆盖任何文件）'); }
            $updated[] = $it['path'];
        } else {
            if (!is_dir(dirname($dest)) && !@mkdir(dirname($dest), 0755, true) && !is_dir(dirname($dest))) {
                $za->close(); return $fail('目录不可写，无法新建：' . $it['path']);
            }
            if (!moe_update_ensure_writable(dirname($dest))) { $za->close(); return $fail(moe_update_unwritable_msg(dirname($dest), '目录')); }
            $created[] = $it['path'];
        }
    }
    @file_put_contents($backupDir . '/manifest.json', json_encode(array(
        'time' => date('Y-m-d H:i:s'), 'origin' => $origin . ':' . $type . ':' . $slug,
        'updated' => $updated, 'created' => $created,
        'how_to_rollback' => '把 files/ 下的文件按相同相对路径复制回目标目录，并删除 created 里列出的新增文件。',
    ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
    $log('🗂 已备份 ' . count($updated) . ' 个将被覆盖的文件 → content/backups/' . $backupName);

    // ⑤ 覆盖写入；失败回滚
    $written = array();
    foreach ($items as $it) {
        $data = $za->getFromIndex($it['idx']);
        if (!is_string($data) || strlen($data) !== (int)$it['size']) {
            $n = function_exists('moe_update_rollback') ? moe_update_rollback($backupDir, $written) : 0;
            $za->close();
            $log('↩️ 已回滚 ' . $n . ' 个文件');
            return $fail('读取包内文件失败：' . $it['path'], 1);
        }
        $dest = $baseDir . '/' . $it['path'];
        $written[] = $it['path'];
        if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0755, true);
        if (@file_put_contents($dest, $data, LOCK_EX) !== strlen($data)) {
            $n = function_exists('moe_update_rollback') ? moe_update_rollback($backupDir, $written) : 0;
            $za->close();
            $log('↩️ 已回滚 ' . $n . ' 个文件');
            return $fail('写入失败：' . $it['path'], 1);
        }
    }
    $za->close();
    $log('✅ 已写入 ' . count($written) . ' 个文件');

    if (function_exists('setting_set')) {
        setting_set('update_check_cache', '');
        setting_set('auth_check_cache', '');
        setting_set('update_last_done', json_encode(array(
            'time' => date('Y-m-d H:i:s'), 'from' => MOE_VERSION, 'origin' => $origin . ':' . $type . ':' . $slug,
            'backup' => 'content/backups/' . $backupName, 'files' => count($written),
        ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }
    if (function_exists('moe_backup_gc')) { $gc = moe_backup_gc(3); $log('🧹 备份自动清理：' . $gc); }
    if (function_exists('opcache_reset')) @opcache_reset();

    return array('ok' => 1, 'msg' => ($type === 'theme' ? '主题' : '插件') . '整包更新完成',
                 'steps' => $steps, 'files' => count($written), 'backup' => 'content/backups/' . $backupName);
}

/* ============ 备份自动清理（存储守护） ============ */
/**
 * 备份瘦身：content/backups/ 只保留最近 $keep 份更新备份（按目录名时间排序），
 * 同时清理残留的临时 zip。返回人话描述。
 */
function moe_backup_gc($keep = 3)
{
    $keep = max(1, (int)$keep);
    $dir = MOE_ROOT . '/content/backups';
    if (!is_dir($dir)) return '暂无备份目录';
    $subs = glob($dir . '/*', GLOB_ONLYDIR);
    $dirs = array();
    foreach (is_array($subs) ? $subs : array() as $d) {
        $name = basename($d);
        if (preg_match('/^(up|au)-\d{8}-\d{6}/', $name)) $dirs[] = $name;
    }
    sort($dirs);
    $removed = 0; $freed = 0;
    $count = count($dirs);
    for ($i = 0; $i < $count - $keep; $i++) {
        $d = $dir . '/' . $dirs[$i];
        $freed += (int)moe_auth_dirsize($d);
        moe_auth_rrmdir($d);
        $removed++;
    }
    // 清理残留临时 zip
    $tmps = glob($dir . '/_tmp-*.zip');
    foreach (is_array($tmps) ? $tmps : array() as $t) { $freed += (int)@filesize($t); @unlink($t); }
    return '删除 ' . $removed . ' 份旧备份，释放 ' . round($freed / 1024, 1) . ' KB（保留最近 ' . $keep . ' 份）';
}

function moe_auth_dirsize($dir)
{
    $s = 0;
    $items = @scandir($dir);
    foreach (is_array($items) ? $items : array() as $it) {
        if ($it === '.' || $it === '..') continue;
        $p = rtrim($dir, '/\\') . '/' . $it;
        $s += is_dir($p) ? moe_auth_dirsize($p) : (int)@filesize($p);
    }
    return $s;
}
