<?php
/**
 * MoeZ · AI 助手内核（2.1.18）
 * ------------------------------------------------------------
 * 三件事：
 *   1) 大模型对话：任意 OpenAI 兼容接口（默认 DeepSeek），curl 直连，失败自动降级；
 *   2) 联网搜索：Bing / DuckDuckGo / 维基百科多源抓取 + 正文提取，供模型阅读后回答；
 *   3) 安全与成本：SSRF 防护、结果文件缓存、每日调用配额。
 * 所有函数带 moe_ai_ 前缀，不依赖 chat.php，任何地方都能调用。
 */

if (!defined('MOE_ROOT')) exit('no direct access');

if (!function_exists('moe_ai_cfg')) {

/** 读取 AI 配置（后台「AI 助手」页签写入 settings 表） */
function moe_ai_cfg()
{
    $base = trim((string)setting('ai_base', ''));
    if ($base === '') $base = 'https://api.deepseek.com/v1/chat/completions';
    /* 允许只填到 /v1 或域名，自动补全 chat/completions */
    if (strpos($base, '/chat/completions') === false) {
        $base = rtrim($base, '/');
        if (substr($base, -3) === '/v1') $base .= '/chat/completions';
        elseif (substr($base, -4) !== '/v1/') $base .= '/v1/chat/completions';
    }
    $temp = (float)setting('ai_temp', '0.7');
    if ($temp < 0 || $temp > 1.5) $temp = 0.7;
    return array(
        'on'      => setting('ai_enabled', '0') === '1',
        'base'    => $base,
        'key'     => trim((string)setting('ai_key', '')),
        'model'   => trim((string)setting('ai_model', '')) ?: 'deepseek-v4-flash',
        'temp'    => $temp,
        'web'     => setting('ai_web', '1') === '1',
        'daily'   => max(0, (int)setting('ai_daily', '200')),
        'persona' => trim((string)setting('ai_persona', '')),
        'timeout' => max(8, min(45, (int)setting('ai_timeout', '22'))),
    );
}

/** 是否配好了、可以走大模型 */
function moe_ai_ready()
{
    $c = moe_ai_cfg();
    return $c['on'] && $c['key'] !== '' && $c['base'] !== '';
}

/* ============ 缓存（cache/ai，失败静默） ============ */

function moe_ai_cache_dir()
{
    if (!empty($GLOBALS['moe_ai_cache_override'])) return (string)$GLOBALS['moe_ai_cache_override'];
    $dir = MOE_ROOT . '/cache/ai';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    if (is_dir($dir) && !is_file($dir . '/index.html')) @file_put_contents($dir . '/index.html', '');
    return $dir;
}

function moe_ai_cache_get($key, $ttl = 0)
{
    $f = moe_ai_cache_dir() . '/' . md5((string)$key) . '.json';
    if (!is_file($f)) return null;
    if ($ttl > 0 && (time() - (int)@filemtime($f)) > $ttl) return null;
    $raw = @file_get_contents($f);
    if ($raw === false || $raw === '') return null;
    $v = json_decode($raw, true);
    return is_array($v) ? $v : null;
}

function moe_ai_cache_set($key, $val)
{
    $f = moe_ai_cache_dir() . '/' . md5((string)$key) . '.json';
    @file_put_contents($f, json_encode($val, JSON_UNESCAPED_UNICODE), LOCK_EX);
}

/* ============ 每日配额（全站合计，防刷爆 API 账单） ============ */

function moe_ai_quota_file()
{
    return moe_ai_cache_dir() . '/quota-' . date('Ymd') . '.txt';
}

function moe_ai_quota_used()
{
    return (int)@file_get_contents(moe_ai_quota_file());
}

/** 取一次配额；返回 false 表示今天已经用光 */
function moe_ai_quota_take($limit)
{
    if ($limit <= 0) return true; /* 0 = 不限 */
    $f = moe_ai_quota_file();
    $fp = @fopen($f, 'c+');
    if (!$fp) return true; /* 写不了就别拦着用户 */
    @flock($fp, LOCK_EX);
    $n = (int)stream_get_contents($fp);
    if ($n >= $limit) { @flock($fp, LOCK_UN); @fclose($fp); return false; }
    @ftruncate($fp, 0); @rewind($fp);
    @fwrite($fp, (string)($n + 1));
    @fflush($fp);
    @flock($fp, LOCK_UN);
    @fclose($fp);
    return true;
}

/* ============ 网络请求 ============ */

/** 只允许 http/https，且不允许指向内网 / 本机（挡 SSRF） */
function moe_ai_url_safe($url)
{
    $p = @parse_url((string)$url);
    if (!is_array($p) || empty($p['host'])) return false;
    $scheme = strtolower(isset($p['scheme']) ? $p['scheme'] : '');
    if ($scheme !== 'http' && $scheme !== 'https') return false;
    $host = strtolower($p['host']);
    if ($host === 'localhost' || substr($host, -6) === '.local' || substr($host, -7) === '.local.') return false;
    $ips = array();
    if (filter_var($host, FILTER_VALIDATE_IP)) {
        $ips[] = $host;
    } else {
        $list = @gethostbynamel($host);
        if (is_array($list)) $ips = $list;
    }
    foreach ($ips as $ip) {
        if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) return false;
    }
    return true;
}

/** 统一 HTTP 客户端：优先 curl，没装 curl 时退回流包装 */
function moe_ai_http($url, $method = 'GET', $body = null, $headers = array(), $timeout = 20, $maxBytes = 0)
{
    $out = array('ok' => false, 'code' => 0, 'body' => '', 'err' => '');
    /* 测试钩子：单测里用它模拟接口与网页，生产环境不设置这个全局变量 */
    if (!empty($GLOBALS['moe_ai_http_mock']) && is_callable($GLOBALS['moe_ai_http_mock'])) {
        $m = call_user_func($GLOBALS['moe_ai_http_mock'], $url, $method, $body, $headers);
        return is_array($m) ? $m + $out : $out;
    }
    if (!moe_ai_url_safe($url)) { $out['err'] = '地址不允许访问'; return $out; }
    $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
    $method = strtoupper($method);

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        $opt = array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => min(8, $timeout),
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 3,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_ENCODING       => '',
            CURLOPT_USERAGENT      => $ua,
            CURLOPT_HTTPHEADER     => $headers,
        );
        if ($method === 'POST') {
            $opt[CURLOPT_POST] = true;
            $opt[CURLOPT_POSTFIELDS] = (string)$body;
        }
        curl_setopt_array($ch, $opt);
        $resp = curl_exec($ch);
        $out['code'] = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($resp === false) $out['err'] = 'curl: ' . curl_error($ch);
        else { $out['body'] = (string)$resp; $out['ok'] = true; }
        curl_close($ch);
    } else {
        $ctx = stream_context_create(array('http' => array(
            'method'        => $method,
            'header'        => implode("\r\n", array_merge(array('User-Agent: ' . $ua), $headers)),
            'content'       => $method === 'POST' ? (string)$body : null,
            'timeout'       => $timeout,
            'ignore_errors' => true,
        ), 'ssl' => array('verify_peer' => true, 'verify_peer_name' => true)));
        $resp = @file_get_contents($url, false, $ctx);
        if ($resp === false) { $out['err'] = '无法连接'; }
        else { $out['body'] = (string)$resp; $out['ok'] = true; $out['code'] = 200; }
    }
    if ($maxBytes > 0 && strlen($out['body']) > $maxBytes) $out['body'] = substr($out['body'], 0, $maxBytes);
    return $out;
}

/* ============ 大模型对话 ============ */

/**
 * 发起一次对话补全
 * @param array $messages [['role'=>'system|user|assistant','content'=>'...'], ...]
 * @return array('ok'=>bool,'text'=>string,'err'=>string,'usage'=>array)
 */
/** 把接口原始报错翻译成人话 + 该去干什么（保留原文便于排查） */
function moe_ai_err_hint($msg)
{
    $raw = trim((string)$msg);
    $low = strtolower($raw);
    $map = array(
        'insufficient balance'      => '账户余额不足 → 到 DeepSeek 开放平台「充值」后再测试（新注册的赠送额度用完也会这样）',
        'insufficient_quota'        => '账户额度用尽 → 到服务商后台充值或换一个密钥',
        'exceeded your current quota' => '账户额度用尽 → 到服务商后台充值或换一个密钥',
        'invalid api key'           => 'API 密钥无效 → 检查是否复制完整（以 sk- 开头，别带空格）',
        'incorrect api key'         => 'API 密钥不对 → 重新复制一次，注意首尾空格',
        'authentication'            => '密钥验证失败 → 确认密钥与接口地址属于同一家服务商',
        'model not exist'           => '模型名不存在 → 填 deepseek-v4-flash 或 deepseek-v4-pro',
        'does not exist'            => '模型名不存在 → 填 deepseek-v4-flash 或 deepseek-v4-pro',
        'no such model'             => '模型名不存在 → 填 deepseek-v4-flash 或 deepseek-v4-pro',
        'rate limit'                => '请求太频繁 → 等一两分钟再试',
        'context length'            => '上下文超长 → 点聊天窗的 ↻ 重新开始',
        'timeout'                   => '接口超时 → 服务器网络慢，可把「单次超时」调大',
        'gateway'                   => '网关错误 → 服务商临时故障，稍后再试',
    );
    foreach ($map as $k => $v) {
        if (strpos($low, $k) !== false) {
            return $v . '（原文：' . mb_substr($raw, 0, 90, 'UTF-8') . '）';
        }
    }
    return '接口报错：' . mb_substr($raw, 0, 120, 'UTF-8');
}

function moe_ai_chat($messages, $opts = array())
{
    $c = moe_ai_cfg();
    $res = array('ok' => false, 'text' => '', 'err' => '', 'usage' => array());
    if ($c['key'] === '') { $res['err'] = '还没有配置 API 密钥'; return $res; }

    $payload = array(
        'model'    => isset($opts['model']) && $opts['model'] !== '' ? $opts['model'] : $c['model'],
        'messages' => array_values($messages),
        'stream'   => false,
    );
    $payload['temperature'] = isset($opts['temp']) ? (float)$opts['temp'] : $c['temp'];
    if (isset($opts['max_tokens']) && (int)$opts['max_tokens'] > 0) $payload['max_tokens'] = (int)$opts['max_tokens'];
    /* DeepSeek-V4 默认思考模式又慢又贵，闲聊用不上；只对 DeepSeek 域名注入（其他兼容接口可能不认这个字段），
       需要深度思考可在 opts 里传 thinking => 'enabled' 覆盖 */
    if (isset($opts['thinking']) && $opts['thinking'] === 'enabled') {
        $payload['thinking'] = array('type' => 'enabled');
    } elseif (stripos($c['base'], 'deepseek') !== false) {
        $payload['thinking'] = array('type' => 'disabled');
    }

    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if ($json === false) { $res['err'] = '请求体编码失败'; return $res; }

    $headers = array('Content-Type: application/json', 'Authorization: Bearer ' . $c['key'], 'Accept: application/json');
    $timeout = isset($opts['timeout']) ? (int)$opts['timeout'] : $c['timeout'];
    $r = moe_ai_http($c['base'], 'POST', $json, $headers, $timeout, 262144);

    /* 少数服务器 CA 证书链不全：SSL 校验失败时放弃校验重试一次（只对这里，抓网页不降级） */
    if (!$r['ok'] && stripos($r['err'], 'SSL') !== false && function_exists('curl_init')) {
        $ch = curl_init($c['base']);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => $timeout, CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_POST => true, CURLOPT_POSTFIELDS => $json, CURLOPT_HTTPHEADER => $headers,
            CURLOPT_SSL_VERIFYPEER => false, CURLOPT_SSL_VERIFYHOST => 0, CURLOPT_ENCODING => '',
        ));
        $resp = curl_exec($ch);
        $r = array('ok' => $resp !== false, 'code' => (int)curl_getinfo($ch, CURLINFO_HTTP_CODE), 'body' => (string)$resp, 'err' => $resp === false ? curl_error($ch) : '');
        curl_close($ch);
    }

    if (!$r['ok']) { $res['err'] = $r['err'] !== '' ? $r['err'] : '网络异常'; return $res; }
    if ($r['code'] === 401 || $r['code'] === 403) { $res['err'] = 'API 密钥无效或无权限（HTTP ' . $r['code'] . '）'; return $res; }
    if ($r['code'] === 429) { $res['err'] = '接口限流或余额不足（HTTP 429）'; return $res; }

    $d = json_decode($r['body'], true);
    if (!is_array($d)) { $res['err'] = '接口返回的不是 JSON（HTTP ' . $r['code'] . '）'; return $res; }
    if (isset($d['error'])) {
        $msg = is_array($d['error']) ? (isset($d['error']['message']) ? $d['error']['message'] : '') : (string)$d['error'];
        $res['err'] = moe_ai_err_hint((string)$msg);
        return $res;
    }
    $text = '';
    if (isset($d['choices'][0]['message']['content'])) {
        $text = (string)$d['choices'][0]['message']['content'];
    } elseif (isset($d['choices'][0]['text'])) {
        $text = (string)$d['choices'][0]['text'];
    }
    /* 兼容部分模型把内容放在 content 数组里 */
    if ($text === '' && isset($d['choices'][0]['message']['content']) && is_array($d['choices'][0]['message']['content'])) {
        foreach ($d['choices'][0]['message']['content'] as $seg) {
            if (is_array($seg) && isset($seg['text'])) $text .= (string)$seg['text'];
        }
    }
    /* 兜底：思考模型可能在思考上耗尽额度导致正文为空，退而取思考内容 */
    if (trim($text) === '' && isset($d['choices'][0]['message']['reasoning_content'])) {
        $text = (string)$d['choices'][0]['message']['reasoning_content'];
    }
    $res['text'] = trim($text);
    $res['ok'] = $res['text'] !== '';
    if (!$res['ok']) $res['err'] = '模型返回了空内容';
    if (isset($d['usage'])) {
        $res['usage'] = (array)$d['usage'];
        moe_ai_usage_record($res['usage']);
    }
    return $res;
}

/* ============ Token 用量统计（2.1.23） ============ */

/** 用量账本：cache/ai/usage.json，total + 按日（保留 30 天） */
function moe_ai_usage_read()
{
    $f = moe_ai_cache_dir() . '/usage.json';
    $d = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
    if (!is_array($d)) $d = array('total' => array('req' => 0, 'in' => 0, 'out' => 0), 'daily' => array());
    if (!isset($d['total']) || !is_array($d['total'])) $d['total'] = array('req' => 0, 'in' => 0, 'out' => 0);
    if (!isset($d['daily']) || !is_array($d['daily'])) $d['daily'] = array();
    return $d;
}

/** 成功调用后记账：输入 / 输出 token 各记一笔 */
function moe_ai_usage_record($usage)
{
    $in = isset($usage['prompt_tokens']) ? (int)$usage['prompt_tokens'] : 0;
    $out = isset($usage['completion_tokens']) ? (int)$usage['completion_tokens'] : 0;
    if ($in <= 0 && $out <= 0) return false;
    $f = moe_ai_cache_dir() . '/usage.json';
    $fp = @fopen($f, 'c+');
    if (!$fp) return false;
    $ok = false;
    if (@flock($fp, LOCK_EX)) {
        /* 必须用同一个句柄读：Windows 的 flock 是强制锁，另开 file_get_contents 会读失败导致账本被覆盖 */
        rewind($fp);
        $raw = stream_get_contents($fp);
        $d = is_string($raw) && $raw !== '' ? json_decode($raw, true) : null;
        if (!is_array($d)) $d = array('total' => array('req' => 0, 'in' => 0, 'out' => 0), 'daily' => array());
        if (!isset($d['total']) || !is_array($d['total'])) $d['total'] = array('req' => 0, 'in' => 0, 'out' => 0);
        if (!isset($d['daily']) || !is_array($d['daily'])) $d['daily'] = array();
        $day = date('Ymd');
        $buckets = array(&$d['total'], &$d['daily'][$day]);
        foreach ($buckets as &$b) {
            if (!is_array($b)) $b = array('req' => 0, 'in' => 0, 'out' => 0);
            $b['req']++;
            $b['in'] += $in;
            $b['out'] += $out;
        }
        unset($b);
        /* 只留最近 30 天 */
        if (count($d['daily']) > 30) {
            ksort($d['daily']);
            $d['daily'] = array_slice($d['daily'], -30, null, true);
        }
        ftruncate($fp, 0);
        rewind($fp);
        fwrite($fp, json_encode($d, JSON_UNESCAPED_UNICODE));
        fflush($fp);
        flock($fp, LOCK_UN);
        $ok = true;
    }
    fclose($fp);
    return $ok;
}

/** 读账本并算钱：单价 = 后台设置，元 / 百万 token（默认参考 DeepSeek v4-flash 官方价） */
function moe_ai_usage_stats()
{
    $d = moe_ai_usage_read();
    $pin = (float)setting('ai_price_in', '1');
    $pout = (float)setting('ai_price_out', '2');
    $cost = function ($b) use ($pin, $pout) {
        if (!is_array($b)) return 0.0;
        return $b['in'] / 1000000 * $pin + $b['out'] / 1000000 * $pout;
    };
    $today = date('Ymd');
    return array(
        'total' => is_array($d['total']) ? $d['total'] : array('req' => 0, 'in' => 0, 'out' => 0),
        'today' => isset($d['daily'][$today]) && is_array($d['daily'][$today]) ? $d['daily'][$today] : array('req' => 0, 'in' => 0, 'out' => 0),
        'cost_total' => round($cost($d['total']), 4),
        'cost_today' => round($cost(isset($d['daily'][$today]) ? $d['daily'][$today] : null), 4),
        'price_in' => $pin,
        'price_out' => $pout,
    );
}

/** 一次性的「测试连接」，给后台按钮用 */
function moe_ai_ping($base = '', $key = '', $model = '')
{
    $c = moe_ai_cfg();
    $old = array($c['base'], $c['key'], $c['model']);
    $b = $base !== '' ? $base : $c['base'];
    $k = $key !== '' ? $key : $c['key'];
    $m = $model !== '' ? $model : $c['model'];
    if (strpos($b, '/chat/completions') === false) $b = rtrim($b, '/') . '/v1/chat/completions';
    $start = microtime(true);
    /* DeepSeek-V4 默认开启思考模式，会先烧掉 max_tokens 再给正文：
       测试消息显式关闭思考，并给足额度，否则 HTTP 200 但 content 为空会被误判成失败 */
    $payload = array(
        'model' => $m, 'stream' => false, 'max_tokens' => 200,
        'messages' => array(array('role' => 'user', 'content' => '用一句中文回答：你好，请回复「连接成功」。')),
    );
    if (stripos($b, 'deepseek') !== false) $payload['thinking'] = array('type' => 'disabled');
    $r = moe_ai_http($b, 'POST', json_encode($payload, JSON_UNESCAPED_UNICODE), array('Content-Type: application/json', 'Authorization: Bearer ' . $k), 20, 262144);
    $ms = (int)round((microtime(true) - $start) * 1000);
    $txt = '';
    if ($r['ok']) {
        $d = json_decode($r['body'], true);
        if (isset($d['choices'][0]['message']['content'])) $txt = trim((string)$d['choices'][0]['message']['content']);
        if ($txt === '' && isset($d['choices'][0]['message']['reasoning_content'])) {
            /* 兜底：思考内容也算「通了」 */
            $txt = trim((string)$d['choices'][0]['message']['reasoning_content']);
            if ($txt !== '') $txt = mb_substr($txt, 0, 60, 'UTF-8') . '…（模型思考内容）';
        }
        if ($txt === '' && isset($d['error'])) {
            $emsg = is_array($d['error']) ? (isset($d['error']['message']) ? $d['error']['message'] : '') : $d['error'];
            $r['err'] = moe_ai_err_hint((string)$emsg);
        } elseif ($txt === '' && $r['code'] === 200) {
            $r['err'] = '接口通了（HTTP 200）但没返回内容：可能模型名不对，或该接口要求更长的输出额度';
        }
    }
    return array('ok' => $txt !== '', 'ms' => $ms, 'code' => $r['code'], 'text' => $txt, 'err' => $r['err'], 'used' => $old);
}

/* ============ 网页抓取与搜索 ============ */

/** HTML → 纯文本（去脚本样式、压缩空白、修正 GBK 编码） */
function moe_ai_html_text($html, $limit = 1500)
{
    $html = (string)$html;
    if ($html === '') return '';
    /* 编码：GBK/GB2312 站点很多，统一转 UTF-8 */
    if (!mb_check_encoding($html, 'UTF-8')) {
        if (preg_match('/charset=["\']?([\w-]+)/i', substr($html, 0, 3000), $m)) {
            $enc = strtoupper($m[1]);
            if ($enc === 'GB2312' || $enc === 'GBK') $enc = 'GB18030';
            $html = @mb_convert_encoding($html, 'UTF-8', $enc);
        } else {
            $html = @mb_convert_encoding($html, 'UTF-8', 'GB18030');
        }
    }
    $html = preg_replace('#<!--.*?-->#s', ' ', $html);
    $html = preg_replace('#<(script|style|noscript|svg|iframe|head)[^>]*>.*?</\1>#is', ' ', $html);
    $html = preg_replace('#<(br|/p|/div|/li|/h[1-6]|/tr)[^>]*>#i', "\n", $html);
    $t = strip_tags($html);
    $t = html_entity_decode($t, ENT_QUOTES, 'UTF-8');
    $t = str_replace(array("\xc2\xa0", "\xe3\x80\x80"), ' ', $t);
    $t = preg_replace('/[ \t]+/u', ' ', $t);
    $t = preg_replace('/\n\s*\n+/u', "\n", $t);
    $t = trim($t);
    if ($limit > 0 && mb_strlen($t, 'UTF-8') > $limit) $t = mb_substr($t, 0, $limit, 'UTF-8') . '…';
    return $t;
}

/** 抓一个网页的正文（带 6 小时缓存） */
function moe_ai_fetch_text($url, $limit = 1200)
{
    if (!moe_ai_url_safe($url)) return '';
    $ck = 'page:' . md5($url);
    $hit = moe_ai_cache_get($ck, 21600);
    if (is_array($hit) && isset($hit['t'])) return (string)$hit['t'];
    $r = moe_ai_http($url, 'GET', null, array('Accept: text/html,application/xhtml+xml', 'Accept-Language: zh-CN,zh;q=0.9'), 9, 512000);
    if (!$r['ok'] || $r['body'] === '') return '';
    $t = moe_ai_html_text($r['body'], $limit);
    if ($t !== '') moe_ai_cache_set($ck, array('t' => $t));
    return $t;
}

/** 从 HTML 结果页里按「结果块」抽标题 / 链接 / 摘要 */
function moe_ai_parse_block($html, $startRe, $endRe)
{
    $out = array();
    if (!preg_match_all($startRe, $html, $mm, PREG_OFFSET_CAPTURE)) return $out;
    $offs = array();
    foreach ($mm[0] as $one) $offs[] = (int)$one[1];
    $n = count($offs);
    for ($i = 0; $i < $n; $i++) {
        $st = $offs[$i];
        $en = ($i + 1 < $n) ? $offs[$i + 1] : strlen($html);
        $seg = substr($html, $st, $en - $st);
        $out[] = $seg;
        if (count($out) >= 10) break;
    }
    return $out;
}

/**
 * 联网搜索：多源串行，先到先得
 * @return array(array('t'=>标题,'u'=>链接,'s'=>摘要), ...)
 */
function moe_ai_search($query, $limit = 5)
{
    $query = trim((string)$query);
    if ($query === '') return array();
    $ck = 'search:' . md5($query);
    $hit = moe_ai_cache_get($ck, 1800);
    if (is_array($hit) && isset($hit['r']) && is_array($hit['r'])) return array_slice($hit['r'], 0, $limit);

    $host = (string)parse_url(base_url(), PHP_URL_HOST);
    $hl = 'zh-CN';
    $results = array();

    /* 源 1：Bing（中文覆盖最好） */
    $engines = array(
        'https://cn.bing.com/search?q=' . urlencode($query) . '&count=10&setlang=' . $hl,
        'https://www.bing.com/search?q=' . urlencode($query) . '&count=10&cc=CN',
    );
    foreach ($engines as $url) {
        $r = moe_ai_http($url, 'GET', null, array('Accept: text/html', 'Accept-Language: zh-CN,zh;q=0.9'), 10, 700000);
        if (!$r['ok'] || $r['body'] === '') continue;
        $blocks = moe_ai_parse_block($r['body'], '#<li class="b_algo"#i', '');
        foreach ($blocks as $seg) {
            $u = ''; $t = ''; $s = '';
            if (preg_match('#<h2[^>]*>\s*<a[^>]+href="(https?://[^"]+)"[^>]*>(.*?)</a>#is', $seg, $m)) {
                $u = html_entity_decode($m[1], ENT_QUOTES, 'UTF-8');
                $t = moe_ai_html_text($m[2], 120);
            }
            if ($u === '') continue;
            if (preg_match('#<p[^>]*>(.*?)</p>#is', $seg, $m2)) $s = moe_ai_html_text($m2[1], 220);
            if ($t === '') $t = parse_url($u, PHP_URL_HOST);
            $results[] = array('t' => $t, 'u' => $u, 's' => $s);
        }
        if (count($results) >= 3) break;
        $results = array();
    }

    /* 源 2：DuckDuckGo（Bing 被反爬时兜底） */
    if (!$results) {
        $r = moe_ai_http('https://html.duckduckgo.com/html/?q=' . urlencode($query), 'GET', null, array('Accept: text/html', 'Accept-Language: zh-CN,zh;q=0.9'), 10, 700000);
        if ($r['ok'] && $r['body'] !== '') {
            $blocks = moe_ai_parse_block($r['body'], '#<div class="result results_links#i', '');
            foreach ($blocks as $seg) {
                $u = ''; $t = ''; $s = '';
                if (preg_match('#class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>#is', $seg, $m)) {
                    $u = html_entity_decode($m[1], ENT_QUOTES, 'UTF-8');
                    $t = moe_ai_html_text($m[2], 120);
                }
                if ($u === '' && preg_match('#<a[^>]+class="result__a"[^>]*href="([^"]+)"#i', $seg, $m)) $u = html_entity_decode($m[1], ENT_QUOTES, 'UTF-8');
                if ($u === '') continue;
                /* DDG 的链接是跳转形式，还原真实地址 */
                if (strpos($u, 'duckduckgo.com/l/') !== false) {
                    parse_str((string)parse_url($u, PHP_URL_QUERY), $qq);
                    if (!empty($qq['uddg'])) $u = urldecode($qq['uddg']);
                }
                if (preg_match('#class="result__snippet"[^>]*>(.*?)</a>#is', $seg, $m3)) $s = moe_ai_html_text($m3[1], 220);
                $results[] = array('t' => $t !== '' ? $t : (string)parse_url($u, PHP_URL_HOST), 'u' => $u, 's' => $s);
            }
        }
    }

    /* 源 3：维基百科（知识类问题命中率高，且无广告） */
    if (count($results) < 2) {
        $api = 'https://zh.wikipedia.org/w/api.php?action=query&list=search&format=json&utf8=1&srlimit=5&srsearch=' . urlencode($query);
        $r = moe_ai_http($api, 'GET', null, array('Accept: application/json'), 10, 300000);
        if ($r['ok']) {
            $d = json_decode($r['body'], true);
            if (isset($d['query']['search']) && is_array($d['query']['search'])) {
                foreach ($d['query']['search'] as $it) {
                    if (empty($it['title'])) continue;
                    $title = (string)$it['title'];
                    $results[] = array(
                        't' => $title . ' - 维基百科',
                        'u' => 'https://zh.wikipedia.org/wiki/' . rawurlencode(str_replace(' ', '_', $title)),
                        's' => moe_ai_html_text(isset($it['snippet']) ? $it['snippet'] : '', 220),
                    );
                }
            }
        }
    }

    /* 去掉本站与重复、过滤不合法链接 */
    $seen = array();
    $clean = array();
    foreach ($results as $r) {
        $u = (string)$r['u'];
        if ($u === '' || !preg_match('#^https?://#i', $u)) continue;
        if ($host !== '' && stripos($u, $host) !== false) continue;
        $k = strtolower(preg_replace('#\?.*$#', '', $u));
        if (isset($seen[$k])) continue;
        $seen[$k] = 1;
        $clean[] = array('t' => (string)$r['t'], 'u' => $u, 's' => (string)$r['s']);
        if (count($clean) >= 8) break;
    }
    if ($clean) moe_ai_cache_set($ck, array('r' => $clean));
    return array_slice($clean, 0, $limit);
}

/**
 * 联网查资料：搜索 + 抓前两条正文，拼成给模型看的资料块
 * @return array('ok'=>bool,'text'=>string,'items'=>array)
 */
function moe_ai_web_context($query, $limit = 4)
{
    $list = moe_ai_search($query, $limit);
    if (!$list) return array('ok' => false, 'text' => '', 'items' => array());
    $lines = array();
    $i = 0;
    $fetched = 0;
    foreach ($list as $r) {
        $i++;
        $lines[] = $i . '. ' . $r['t'] . "\n   " . $r['u'] . ($r['s'] !== '' ? "\n   " . $r['s'] : '');
        /* 前两条再抓正文，让模型看到真实细节而不是只有摘要 */
        if ($fetched < 2) {
            $body = moe_ai_fetch_text($r['u'], 1000);
            if ($body !== '') { $lines[] = '   正文摘录：' . preg_replace('/\s+/u', ' ', $body); $fetched++; }
        }
    }
    return array('ok' => true, 'text' => implode("\n", $lines), 'items' => $list);
}

/** 清理过期缓存（后台/定时任务可调用；7 天前的直接删） */
function moe_ai_cache_gc($days = 7)
{
    $dir = moe_ai_cache_dir();
    if (!is_dir($dir)) return 0;
    $n = 0;
    $dead = time() - max(1, (int)$days) * 86400;
    foreach ((array)@scandir($dir) as $f) {
        if ($f === '.' || $f === '..' || $f === 'index.html') continue;
        $p = $dir . '/' . $f;
        if (is_file($p) && @filemtime($p) < $dead && strpos($f, 'quota-') !== 0) { @unlink($p); $n++; }
    }
    return $n;
}

}
