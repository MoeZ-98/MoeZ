<?php
/**
 * MoeZ · 插件系统（2.0.2）
 * ------------------------------------------------------------
 * 目录：content/plugins/<插件ID>/
 * 描述：plugin.json（推荐），也兼容入口 PHP 的头部注释
 * 状态：settings 表 plugins_enabled（JSON 数组），不新增表 / 不改 DB_VERSION
 *
 * 安全约定：
 *   - 插件目录名必须是 [a-zA-Z][a-zA-Z0-9_-]{0,48}
 *   - 入口文件必须位于插件目录内，且是 .php
 *   - 每个插件独立 try/catch 加载，单个插件报错不会白屏
 *   - 只有「已启用」的插件才会被 include
 *
 * 可用钩子：
 *   front_head      前台 </head> 前注入 HTML（返回字符串或 echo）
 *   front_footer    前台 </body> 前注入 HTML
 *   admin_menu      后台菜单数组（过滤器，接收并返回 $menu）
 *   admin_dashboard 仪表盘末尾追加卡片
 *   admin_footer    后台 </body> 前注入 HTML
 */

/** 插件根目录 */
function moe_plugins_dir()
{
    return MOE_ROOT . '/content/plugins';
}

/** 确保插件目录存在且可写 */
function moe_plugins_prepare_dir()
{
    $d = moe_plugins_dir();
    if (!is_dir($d)) @mkdir($d, 0755, true);
    return is_dir($d) && is_writable($d);
}

/** 插件 ID 合法性：字母开头，只允许字母数字下划线中划线 */
function moe_plugin_id_valid($id)
{
    // 2.2.23：允许中文插件 ID（插件名即目录名），仍禁止点开头 / 斜杠等路径字符
    return (bool)preg_match('/^[\x{4e00}-\x{9fa5}a-zA-Z][\x{4e00}-\x{9fa5}a-zA-Z0-9_-]{0,48}$/u', (string)$id);
}

/** 已启用的插件 ID 列表 */
function moe_plugins_enabled()
{
    if (isset($GLOBALS['moe_plugins_enabled_cache'])) return $GLOBALS['moe_plugins_enabled_cache'];
    $raw = setting('plugins_enabled', '[]');
    $arr = json_decode((string)$raw, true);
    if (!is_array($arr)) $arr = array();
    $out = array();
    foreach ($arr as $id) {
        if (is_string($id) && moe_plugin_id_valid($id)) $out[] = $id;
    }
    $out = array_values(array_unique($out));

    // 2.2.30：内置「萌Z 版娘」插件首次部署自动启用（只做一次）。
    // marker 保证站长在「插件管理」停用后不会被下次访问重新打开；
    // 数据库尚未就绪（安装向导 / 只读）时静默跳过，等下一个请求再试。
    if (function_exists('setting') && function_exists('setting_set')
        && (string)setting('moez_cp_autoinstall', '') !== '1'
        && is_dir(moe_plugins_dir() . '/moez-companion')) {
        try {
            setting_set('moez_cp_autoinstall', '1');
            if (!in_array('moez-companion', $out, true)) {
                $out[] = 'moez-companion';
                return moe_plugins_set_enabled($out);
            }
        } catch (Exception $e) { /* 安装前 / 数据库只读：忽略，下次请求重试 */ }
    }
    return $GLOBALS['moe_plugins_enabled_cache'] = $out;
}

/** 写回启用列表 */
function moe_plugins_set_enabled(array $ids)
{
    $clean = array();
    foreach ($ids as $id) {
        if (moe_plugin_id_valid($id)) $clean[] = $id;
    }
    $clean = array_values(array_unique($clean));
    setting_set('plugins_enabled', json_encode($clean, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    $GLOBALS['moe_plugins_enabled_cache'] = $clean;
    return $clean;
}

/** 是否有启用中的插件（用于关闭前台页面缓存，避免插件输出被固化） */
function moe_plugins_active()
{
    return count(moe_plugins_enabled()) > 0;
}

/* ============================================================
   一、插件描述读取
   ============================================================ */

/** 从 plugin.json / 入口 PHP 头部注释读取插件信息 */
function moe_plugin_meta($id, $withStats = true)
{
    if (!moe_plugin_id_valid($id)) return null;
    $dir = moe_plugins_dir() . '/' . $id;
    if (!is_dir($dir)) return null;

    $m = array(
        'id'          => $id,
        'dir'         => $dir,
        'name'        => $id,
        'version'     => '1.0.0',
        'author'      => '未知作者',
        'description' => '',
        'entry'       => 'plugin.php',
        'icon'        => '🧩',
        'hooks'       => array(),
        'has_json'    => false,
        'enabled'     => false,
        'files'       => 0,
        'size'        => 0,
        'error'       => '',
    );

    $jf = $dir . '/plugin.json';
    if (is_file($jf)) {
        $j = json_decode((string)@file_get_contents($jf), true);
        if (is_array($j)) {
            $m['has_json'] = true;
            foreach (array('name', 'version', 'author', 'description', 'entry', 'icon') as $k) {
                if (isset($j[$k]) && is_string($j[$k]) && trim($j[$k]) !== '') $m[$k] = trim($j[$k]);
            }
            if (!empty($j['hooks']) && is_array($j['hooks'])) $m['hooks'] = $j['hooks'];
        } else {
            $m['error'] = 'plugin.json 不是有效的 JSON';
        }
    }

    // 入口不存在时回落到目录里的第一个 PHP 文件
    if (!moe_plugin_entry_safe($m['entry']) || !is_file($dir . '/' . $m['entry'])) {
        $found = glob($dir . '/*.php');
        $m['entry'] = $found ? basename($found[0]) : '';
    }
    if ($m['entry'] !== '' && !moe_plugin_entry_safe($m['entry'])) $m['entry'] = '';

    // 没有 plugin.json：从入口文件头部注释解析 WordPress 风格字段
    if (!$m['has_json'] && $m['entry'] !== '') {
        $head = (string)@file_get_contents($dir . '/' . $m['entry'], false, null, 0, 8192);
        $labels = array('Plugin Name' => 'name', 'Version' => 'version',
                        'Author' => 'author', 'Description' => 'description', 'Icon' => 'icon');
        foreach ($labels as $label => $k) {
            if (preg_match('/^[ \t\/*#]*' . preg_quote($label, '/') . '\s*:\s*(.+)$/mi', $head, $mm)) {
                $m[$k] = trim($mm[1]);
            }
        }
    }

    // 文件数与体积（只统计本目录及子目录的常规文件；前台加载时跳过，避免每次请求遍历目录）
    if ($withStats) {
        try {
            $it = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS)
            );
            foreach ($it as $f) {
                if ($f->isFile()) { $m['files']++; $m['size'] += (int)$f->getSize(); }
            }
        } catch (Throwable $e) { /* 统计失败不影响使用 */ }
    }

    $m['enabled'] = in_array($id, moe_plugins_enabled(), true);
    if ($m['entry'] === '') $m['error'] = '缺少可执行的 PHP 入口文件';
    return $m;
}

/** 入口文件名必须是不带路径的 .php */
function moe_plugin_entry_safe($entry)
{
    return (bool)preg_match('/^[a-zA-Z0-9_-]+\.php$/', (string)$entry);
}

/** 扫描全部插件（含未启用） */
function moe_plugins_scan()
{
    $out = array();
    if (!is_dir(moe_plugins_dir())) return $out;
    $dirs = glob(moe_plugins_dir() . '/*', GLOB_ONLYDIR);
    if (!$dirs) return $out;
    foreach ($dirs as $d) {
        $id = basename($d);
        if (!moe_plugin_id_valid($id)) continue;   // 跳过 .stage_xxx / .bak_xxx
        $m = moe_plugin_meta($id);
        if ($m) $out[$id] = $m;
    }
    uasort($out, function ($a, $b) { return strcasecmp($a['name'], $b['name']); });
    return $out;
}

/* ============================================================
   二、钩子注册与调用
   ============================================================ */

/** 插件调用：moe_plugin_register('front_footer', function () { return '<p>Hi</p>'; }); */
function moe_plugin_register($hook, $fn, $priority = 10)
{
    if (!is_string($hook) || !preg_match('/^[a-z_]+$/', $hook) || !is_callable($fn)) return false;
    if (!isset($GLOBALS['moe_plugin_hooks'])) $GLOBALS['moe_plugin_hooks'] = array();
    $GLOBALS['moe_plugin_hooks'][$hook][] = array(
        'fn'     => $fn,
        'p'      => (int)$priority,
        'plugin' => isset($GLOBALS['moe_plugin_loading']) ? $GLOBALS['moe_plugin_loading'] : '',
    );
    return true;
}

/** 取某钩子的回调（按优先级稳定排序，只排一次） */
function moe_plugin_callbacks($hook)
{
    if (empty($GLOBALS['moe_plugin_hooks'][$hook])) return array();
    $list = $GLOBALS['moe_plugin_hooks'][$hook];
    usort($list, function ($a, $b) { return $a['p'] === $b['p'] ? 0 : ($a['p'] < $b['p'] ? -1 : 1); });
    return $list;
}

function moe_plugin_error($cb, $e)
{
    $msg = ($cb['plugin'] !== '' ? '[' . $cb['plugin'] . '] ' : '') . $e->getMessage();
    if (!isset($GLOBALS['moe_plugin_errors'])) $GLOBALS['moe_plugin_errors'] = array();
    $GLOBALS['moe_plugin_errors'][] = $msg;
    @error_log('MoeZ plugin error: ' . $msg);
}

function moe_plugin_last_errors()
{
    return isset($GLOBALS['moe_plugin_errors']) ? $GLOBALS['moe_plugin_errors'] : array();
}

/** 过滤器型钩子：依次传递值，回调可 return 新值；return null 表示不修改 */
function moe_plugin_apply($hook, $value)
{
    foreach (moe_plugin_callbacks($hook) as $cb) {
        try {
            $r = call_user_func($cb['fn'], $value);
            if ($r !== null) $value = $r;
        } catch (Throwable $e) { moe_plugin_error($cb, $e); }
    }
    return $value;
}

/** 输出型钩子：收集 echo 与 return 的字符串 */
function moe_plugin_render($hook)
{
    $cbs = moe_plugin_callbacks($hook);
    if (!$cbs) return '';
    $out = '';
    foreach ($cbs as $cb) {
        $lvl = ob_get_level();
        ob_start();
        try {
            $r = call_user_func($cb['fn']);
            $buf = ob_get_clean();
            $out .= $buf . (is_string($r) ? $r : '');
        } catch (Throwable $e) {
            while (ob_get_level() > $lvl) ob_end_clean();
            moe_plugin_error($cb, $e);
        }
    }
    return $out;
}

/* ============================================================
   三、加载已启用的插件（init.php 末尾调用一次）
   ============================================================ */
function moe_plugins_load()
{
    if (!empty($GLOBALS['moe_plugins_loaded'])) return;
    $GLOBALS['moe_plugins_loaded'] = true;
    foreach (moe_plugins_enabled() as $id) {
        $m = moe_plugin_meta($id, false);
        if (!$m || $m['entry'] === '') continue;
        $file = realpath($m['dir'] . '/' . $m['entry']);
        $base = realpath($m['dir']);
        if (!$file || !$base || strpos($file, $base . DIRECTORY_SEPARATOR) !== 0) continue;
        $GLOBALS['moe_plugin_loading'] = $id;
        // 插件加载期不允许直接输出：意外 echo / BOM / 空格会破坏 JSON 与页面缓存，统一丢弃
        $lvl = ob_get_level();
        ob_start();
        try {
            include_once $file;
        } catch (Throwable $e) {
            moe_plugin_error(array('plugin' => $id, 'fn' => 'load'), $e);
        }
        while (ob_get_level() > $lvl) ob_end_clean();
        $GLOBALS['moe_plugin_loading'] = '';
    }
}

/* ============================================================
   四、安装 / 删除（zip 上传服务，含 ZipSlip 防护）
   ============================================================ */

/** 递归删除目录，只允许删除插件目录内部的路径 */
function moe_plugin_remove_dir($dir)
{
    $base = realpath(moe_plugins_dir());
    $real = realpath($dir);
    if (!$base || !$real || $real === $base || strpos($real, $base . DIRECTORY_SEPARATOR) !== 0) return false;
    try {
        $it = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($real, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($it as $f) {
            if ($f->isDir()) @rmdir($f->getPathname());
            else @unlink($f->getPathname());
        }
    } catch (Throwable $e) { return false; }
    return @rmdir($real);
}

/**
 * 安装 zip 插件包，成功返回插件 ID，失败返回 false 并写入 $err
 * 逐条校验路径与扩展名、限制文件数与总体积，再手工落盘（不依赖 extractTo 的路径处理）
 */
function moe_plugin_install_zip($tmpFile, $origName, &$err)
{
    $err = '';
    if (!class_exists('ZipArchive')) { $err = '服务器未开启 php-zip 扩展，请先在宝塔面板的 PHP 设置中安装 zip 扩展'; return false; }
    if (!moe_plugins_prepare_dir()) { $err = '插件目录不可写：' . moe_plugins_dir(); return false; }

    $z = new ZipArchive();
    if ($z->open($tmpFile) !== true) { $err = '不是有效的 zip 压缩包'; return false; }

    $allow = array('php', 'json', 'css', 'js', 'map', 'md', 'txt', 'xml', 'html', 'htm',
                   'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico',
                   'ttf', 'woff', 'woff2', 'eot');
    $maxFiles = 200;
    $maxBytes = 20 * 1024 * 1024;
    $total = 0;
    $items = array();
    for ($i = 0; $i < $z->numFiles; $i++) {
        $st = $z->statIndex($i);
        if (!is_array($st)) continue;
        $name = str_replace('\\', '/', (string)$st['name']);
        // 2.2.23：Windows 压缩包的中文文件名多为 GBK 编码，统一转成 UTF-8，否则落盘全是乱码
        if (!function_exists('mb_check_encoding') || !mb_check_encoding($name, 'UTF-8')) {
            if (function_exists('iconv')) {
                $conv = @iconv('GBK', 'UTF-8//IGNORE', $name);
                if (is_string($conv) && $conv !== '' && !strpos($conv, "\0")) $name = $conv;
            }
        }
        $name = preg_replace('/[\x00-\x1f\x7f]/', '', $name);
        if ($name === '' || $name[0] === '/' || strpos($name, "\0") !== false) { $z->close(); $err = '压缩包包含非法路径'; return false; }
        if (preg_match('#(^|/)\.\.(/|$)#', $name) || preg_match('/^[A-Za-z]:/', $name)) {
            $z->close(); $err = '压缩包包含越界路径（已阻止 ZipSlip 攻击）'; return false;
        }
        if (substr($name, -1) === '/') continue;
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (!in_array($ext, $allow, true)) { $z->close(); $err = '不允许的文件类型：.' . $ext; return false; }
        $total += (int)$st['size'];
        $items[] = array('i' => $i, 'name' => $name);
    }
    if (count($items) > $maxFiles) { $z->close(); $err = '压缩包文件数超过 ' . $maxFiles . ' 个'; return false; }
    if ($total > $maxBytes) { $z->close(); $err = '解压后体积超过 20MB'; return false; }
    if (!$items) { $z->close(); $err = '压缩包是空的'; return false; }

    $stage = moe_plugins_dir() . '/.stage_' . bin2hex(random_bytes(6));
    if (!@mkdir($stage, 0755, true)) { $z->close(); $err = '无法创建临时目录'; return false; }
    foreach ($items as $it2) {
        $dest = $stage . '/' . $it2['name'];
        if (!is_dir(dirname($dest))) @mkdir(dirname($dest), 0755, true);
        $data = $z->getFromIndex($it2['i']);
        if ($data === false || @file_put_contents($dest, $data) === false) {
            $z->close(); moe_plugin_remove_dir($stage); $err = '解压写入失败，请检查目录权限'; return false;
        }
    }
    $z->close();

    // 若包内只有一个顶层目录，则把它当作插件根目录
    $tops = glob($stage . '/*');
    $topDirs = glob($stage . '/*', GLOB_ONLYDIR);
    $root = (count($tops) === 1 && count($topDirs) === 1) ? $topDirs[0] : $stage;

    // 插件 ID：plugin.json 的 id > 顶层目录名 > zip 文件名
    $id = '';
    $jf = $root . '/plugin.json';
    if (is_file($jf)) {
        $j = json_decode((string)@file_get_contents($jf), true);
        if (is_array($j) && isset($j['id']) && moe_plugin_id_valid($j['id'])) $id = $j['id'];
    }
    if ($id === '' && $root !== $stage) $id = basename($root);
    if ($id === '') $id = pathinfo((string)$origName, PATHINFO_FILENAME);
    // 2.2.23：保留中文（插件名即目录名），只剔除路径非法字符
    $id = preg_replace('/[^\x{4e00}-\x{9fa5}a-zA-Z0-9_-]+/u', '-', $id);
    $id = trim($id, '-');
    if (!moe_plugin_id_valid($id)) $id = 'p-' . date('Ymd-His');
    if (!moe_plugin_id_valid($id)) { moe_plugin_remove_dir($stage); $err = '无法生成合法的插件 ID'; return false; }

    $target = moe_plugins_dir() . '/' . $id;
    if (is_dir($target) && !moe_plugin_remove_dir($target)) {
        moe_plugin_remove_dir($stage); $err = '同名插件已存在且无法覆盖'; return false;
    }
    if (!@rename($root, $target)) {
        moe_plugin_remove_dir($stage); $err = '安装失败（目录移动被拒绝）'; return false;
    }
    if ($root !== $stage) @rmdir($stage);
    return $id;
}
