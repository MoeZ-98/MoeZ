<?php
/**
 * MoeZ - 搜索引擎收录推送
 * 支持：百度搜索资源平台、360 搜索站长平台、搜狗、必应 Webmaster
 *
 * 说明：
 *   - 百度：data.zz.baidu.com 官方 API，text/plain 换行分隔，单次 ≤ 2000 条
 *   - 360 ：data.360.cn 站长平台 API，token 在「数据提交 → URL 提交」获取
 *   - 搜狗：官方未开放批量 API，这里走站长平台的「提交收录」表单接口，
 *           一次只提交少量 URL（建议配合 sitemap），失败多半是被限频
 *   - 必应：Bing Webmaster SubmitUrlbatch，JSON 批量提交，单次 ≤ 500 条
 */

/** 简易 HTTP POST（优先 curl，无 curl 时用流封装） */
function moe_http_post($url, $body, $headers = array(), $timeout = 10)
{
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => (int)$timeout,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_FOLLOWLOCATION => true,
        ));
        $res  = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = (string)curl_error($ch);
        curl_close($ch);
        return array('ok' => $res !== false && $code > 0 && $code < 400, 'code' => $code, 'body' => (string)$res, 'err' => $err);
    }

    $ctx = stream_context_create(array('http' => array(
        'method'        => 'POST',
        'header'        => implode("\r\n", $headers),
        'content'       => $body,
        'timeout'       => (int)$timeout,
        'ignore_errors' => true,
    )));
    $res = @file_get_contents($url, false, $ctx);
    $code = 0;
    if (isset($http_response_header[0]) && preg_match('#\s(\d{3})\s#', $http_response_header[0], $m)) $code = (int)$m[1];
    return array('ok' => $res !== false && $code > 0 && $code < 400, 'code' => $code, 'body' => (string)$res, 'err' => $res === false ? '请求失败' : '');
}

/** 本站要推送的 URL 清单：首页 + 分类 + 已发布文章 + 独立页面 */
function moe_push_targets()
{
    $out = array(base_url());
    try {
        foreach ((array)rows('SELECT id, slug FROM ' . moe_table('categories') . ' ORDER BY sort, id') as $c) {
            $out[] = cat_url($c);
        }
    } catch (Throwable $e) { /* 忽略 */ }
    try {
        $list = rows('SELECT id, slug, type, category_id, url_num FROM ' . moe_table('posts')
            . " WHERE status='published' ORDER BY id DESC LIMIT 2000");
        foreach ((array)$list as $p) {
            $out[] = ($p['type'] === 'page') ? page_url($p) : post_url($p);
        }
    } catch (Throwable $e) { /* 忽略 */ }
    return array_values(array_unique(array_filter($out)));
}

/**
 * 从用户填写的值里提取真正的 token：
 *   - 直接填 token            → 原样返回
 *   - 粘贴完整接口地址         → 自动解析出 token 参数（百度 / 360 常见误填）
 *   - 粘贴 API 地址但没带 token → 返回空串，视为未配置
 */
function moe_push_token($raw)
{
    $raw = trim((string)$raw);
    if ($raw === '' || strpos($raw, '//') === false && strpos($raw, 'token=') === false) return $raw;
    // 含 URL 或 query 的：解析其中的 token 参数
    $q = $raw;
    if (preg_match('#[?&]([A-Za-z0-9_]*token[A-Za-z0-9_]*)=([^&\s]+)#i', $raw, $m)) {
        return trim($m[2]);
    }
    // 纯 URL 却没带 token：截掉协议头和路径，避免整串被当 token 用
    if (preg_match('#^https?://#i', $raw)) return '';
    return $q;
}

/** 引擎清单与是否已配置 */
function moe_push_engines()
{
    return array(
        'baidu' => array(
            'label' => '百度',
            'icon'  => '🐾',
            'token' => moe_push_token(setting('seo_push_baidu', '')),
            'tip'   => '百度搜索资源平台 → 普通收录 → API 提交，复制 token（粘贴完整接口地址也可以，会自动提取）',
        ),
        '360' => array(
            'label' => '360 搜索',
            'icon'  => '🟢',
            'token' => moe_push_token(setting('seo_push_360', '')),
            'tip'   => '360 站长平台 → 数据提交 → URL 提交 → API 提交，复制 token（粘贴完整接口地址也可以）',
        ),
        'sogou' => array(
            'label' => '搜狗',
            'icon'  => '🐶',
            'token' => trim((string)setting('seo_push_sogou', '')),
            'tip'   => '搜狗未开放批量 API，填「接收通知的邮箱」即可，走站长平台收录提交',
        ),
        'bing' => array(
            'label' => '必应',
            'icon'  => '🅱️',
            'token' => moe_push_token(setting('seo_push_bing', '')),
            'tip'   => 'Bing Webmaster Tools → 设置 → API 访问 → API 密钥',
        ),
    );
}

/** 把引擎返回的错误翻成人话，附上排查建议 */
function moe_push_explain($engine, $raw)
{
    $raw = (string)$raw;
    $msg = $raw;
    if (preg_match('#"message"\s*:\s*"([^"]*)"#i', $raw, $m)) $msg = $m[1];
    $msg = trim($msg);
    if ($msg === '') $msg = $raw !== '' ? mb_substr($raw, 0, 80, 'UTF-8') : '接口无响应';

    if ($engine === 'baidu') {
        if (stripos($msg, 'site init fail') !== false || stripos($msg, 'site') !== false && stripos($msg, 'fail') !== false)
            return $msg . ' —— 站点未在百度搜索资源平台验证，或推送域名与验证站点不一致（检查 https/www 是否与平台添加的完全相同），验证通过后才能 API 推送';
        if (stripos($msg, 'token') !== false)
            return $msg . ' —— token 不正确，请到百度资源平台「普通收录 → API 推送」重新复制';
        if (stripos($msg, 'daily limit') !== false || stripos($msg, 'quota') !== false)
            return $msg . ' —— 今日推送配额已用完（平台正常限制，不是故障）：明天再试或改用 sitemap';
        if (stripos($msg, 'empty content') !== false)
            return $msg . ' —— 本次没有可推送的内容';
    }
    return mb_substr($msg, 0, 120, 'UTF-8');
}

/**
 * 推送 URL 到指定引擎
 * @param array $urls    要推送的完整 URL 列表
 * @param array $only    仅推送这些引擎（默认：所有已配置的）
 * @return array         每个引擎的结果 array('ok'=>bool,'msg'=>string,'n'=>int)
 */
function moe_push_urls($urls, $only = array())
{
    $urls = array_values(array_unique(array_filter(array_map('trim', (array)$urls))));
    if (empty($urls)) return array();
    $engines = moe_push_engines();
    $host = parse_url(base_url(), PHP_URL_HOST);
    $site = rtrim(base_url(), '/');
    $out = array();

    foreach ($engines as $key => $e) {
        if (!empty($only) && !in_array($key, $only, true)) continue;
        if ($e['token'] === '') continue;

        if ($key === 'baidu') {
            $chunk = array_slice($urls, 0, 2000);
            // 百度 API 的 site 参数要求是不带协议的站点域名（与资源平台验证的一致）
            $bsite = $host !== '' ? $host : preg_replace('#^https?://#i', '', rtrim(base_url(), '/'));
            $r = moe_http_post('http://data.zz.baidu.com/urls?site=' . urlencode($bsite) . '&token=' . urlencode($e['token']),
                implode("\n", $chunk), array('Content-Type: text/plain'));
            $j = json_decode($r['body'], true);
            $ok = is_array($j) && (isset($j['success']) ? (int)$j['success'] > 0 : isset($j['remain']));
            // 2.2.8：over quota 属平台正常限制，标记为警告而不是失败
            $warn = !$ok && stripos((string)$r['body'], 'quota') !== false;
            $out['baidu'] = array('ok' => $ok, 'warn' => $warn, 'n' => $ok ? count($chunk) : 0,
                'msg' => $ok ? ('成功 ' . count($chunk) . ' 条' . (isset($j['remain']) ? '，今日剩余 ' . (int)$j['remain'] : ''))
                             : ('失败：' . moe_push_explain('baidu', trim((string)($r['body'] ?: $r['err'])))));
        } elseif ($key === '360') {
            $chunk = array_slice($urls, 0, 500);
            $r = moe_http_post('https://data.360.cn/api/submit?site=' . urlencode($host) . '&token=' . urlencode($e['token']),
                implode("\n", $chunk), array('Content-Type: text/plain'));
            $j = json_decode($r['body'], true);
            $ok = $r['ok'] && (!is_array($j) || (isset($j['success']) ? (bool)$j['success'] : true));
            $out['360'] = array('ok' => $ok, 'n' => $ok ? count($chunk) : 0,
                'msg' => $ok ? ('已提交 ' . count($chunk) . ' 条') : ('失败：' . moe_push_explain('360', trim((string)($r['body'] ?: $r['err'])))));
        } elseif ($key === 'sogou') {
            // 非官方接口：逐条提交，最多 10 条，避免被限频
            $chunk = array_slice($urls, 0, 10);
            $mail  = trim((string)setting('seo_push_sogou', ''));   // 这一栏填的是接收邮箱
            $okN = 0; $lastMsg = '';
            foreach ($chunk as $u) {
                $body = http_build_query(array(
                    'Shoulu[webAdr]' => $u,
                    'site_type'      => 3,
                    'Shoulu[reason]' => '站点更新，提交收录',
                    'Shoulu[email]'  => $mail,
                    'source'         => 1,
                ));
                $r = moe_http_post('http://fankui.help.sogou.com/index.php/web/web/addShoulu', $body,
                    array('Content-Type: application/x-www-form-urlencoded', 'Referer: http://fankui.help.sogou.com/index.php/web/web/'), 8);
                $j = json_decode($r['body'], true);
                if (is_array($j) && !empty($j['success'])) $okN++;
                else $lastMsg = trim((string)($r['body'] ?: $r['err']));
            }
            $out['sogou'] = array('ok' => $okN > 0, 'n' => $okN,
                'msg' => $okN > 0 ? ('成功 ' . $okN . ' / ' . count($chunk) . ' 条（搜狗为逐条提交）')
                                  : ('失败：' . mb_substr($lastMsg !== '' ? $lastMsg : '接口无响应', 0, 100, 'UTF-8')));
        } elseif ($key === 'bing') {
            $chunk = array_slice($urls, 0, 500);
            $r = moe_http_post('https://ssl.bing.com/webmaster/api.svc/json/SubmitUrlbatch?apikey=' . urlencode($e['token']),
                json_encode(array('siteUrl' => $site, 'urlList' => $chunk), JSON_UNESCAPED_SLASHES),
                array('Content-Type: application/json; charset=utf-8'));
            $ok = $r['ok'] && (trim($r['body']) === '' || stripos($r['body'], 'error') === false);
            $out['bing'] = array('ok' => $ok, 'n' => $ok ? count($chunk) : 0,
                'msg' => $ok ? ('已提交 ' . count($chunk) . ' 条') : ('失败：' . moe_push_explain('bing', trim((string)($r['body'] ?: $r['err'])))));
        }
    }
    return $out;
}

/** 把推送结果写进一句人话，用于 flash 提示与设置页展示 */
function moe_push_summary($results)
{
    if (empty($results)) return '没有已配置的搜索引擎，请先填写 token / 密钥';
    $engines = moe_push_engines();
    $parts = array();
    foreach ($results as $k => $r) {
        $name = isset($engines[$k]) ? $engines[$k]['label'] : $k;
        $parts[] = $name . '：' . ($r['ok'] ? '✅ ' : (!empty($r['warn']) ? '⚠️ ' : '❌ ')) . $r['msg'];
    }
    return implode(' · ', $parts);
}

/* ============================================================
 * 2.2.8 · 推送提交记录
 * 每次推送（手动全站 / 发文自动推送）都留档到 content/updates/push-log.json，
 * 保留最近 200 条，设置页可回看每次各引擎的成功 / 配额 / 失败详情。
 * ============================================================ */

/** 追加一条推送记录 */
function moe_push_log_results($urlCount, $results)
{
    $dir = MOE_ROOT . '/content/updates';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $f = $dir . '/push-log.json';
    $log = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
    if (!is_array($log)) $log = array();
    $engines = moe_push_engines();
    $entry = array('time' => date('Y-m-d H:i:s'), 'urls' => (int)$urlCount, 'items' => array());
    foreach ((array)$results as $k => $r) {
        $entry['items'][] = array(
            'engine' => isset($engines[$k]) ? $engines[$k]['label'] : (string)$k,
            'ok'   => !empty($r['ok']) ? 1 : 0,
            'warn' => !empty($r['warn']) ? 1 : 0,
            'n'    => (int)($r['n'] ?? 0),
            'msg'  => mb_substr((string)($r['msg'] ?? ''), 0, 160, 'UTF-8'),
        );
    }
    array_unshift($log, $entry);
    @file_put_contents($f, json_encode(array_slice($log, 0, 200),
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
}

/** 读取推送记录（最新在前，$limit=0 返回全部） */
function moe_push_log_read($limit = 0)
{
    $f = MOE_ROOT . '/content/updates/push-log.json';
    $log = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
    if (!is_array($log)) $log = array();
    return $limit > 0 ? array_slice($log, 0, (int)$limit) : $log;
}
