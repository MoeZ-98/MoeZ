<?php
/**
 * MoeZ · 金币充值（2.2.1）
 * ------------------------------------------------------------
 * 1:1（比例可调）充值购买金币，两种收款方式，均自动写入积分流水：
 *   A. 收款码模式：用户扫码转账后提交「实付金额 + 转账单号」，
 *      订单进入后台「金币充值」待审核，站长一键确认到账；
 *   B. 第三方接口模式：后台配置支付网关地址与回调密钥，
 *      用户点击支付跳转网关，网关回调根目录 pay-notify.php 自动到账。
 *
 * 订单存储：content/recharge/orders.json（content/ 为用户数据目录，
 * 不随更新覆盖）；订单号全局唯一 + 幂等校验，重复回调不会重复加币。
 *
 * 回调签名：sign = HMAC-SHA256(订单号|金额|用户ID, recharge_secret) 前 32 位大写
 */

/* ============ 设置项 ============ */

function moe_rc_on()
{
    return setting('recharge_on', '0') === '1' && (float)setting('recharge_rate', '1') > 0;
}

function moe_rc_rate()
{
    $r = (float)setting('recharge_rate', '1');
    return $r > 0 ? $r : 1.0;
}

function moe_rc_secret()
{
    return trim((string)setting('recharge_secret', ''));
}

/** 回调签名（HMAC 前 32 位大写） */
function moe_rc_sign($orderNo, $amount, $uid, $secret)
{
    return strtoupper(substr(hash_hmac('sha256', $orderNo . '|' . $amount . '|' . (int)$uid, (string)$secret), 0, 32));
}

/* ============ 订单存储 ============ */

function moe_rc_orders_file()
{
    return MOE_ROOT . '/content/recharge/orders.json';
}

function moe_rc_orders_load()
{
    $f = moe_rc_orders_file();
    $j = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
    return is_array($j) ? $j : array();
}

function moe_rc_orders_save($orders)
{
    $f = moe_rc_orders_file();
    if (!is_dir(dirname($f))) @mkdir(dirname($f), 0755, true);
    @file_put_contents($f, json_encode(array_values($orders),
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), LOCK_EX);
}

function moe_rc_status_label($s)
{
    $m = array('pending' => '待确认', 'approved' => '已到账', 'rejected' => '已驳回');
    return isset($m[$s]) ? $m[$s] : (string)$s;
}

/* ============ 下单 / 到账 ============ */

/** 生成订单号：YmdHis + 6 位随机 */
function moe_rc_order_no()
{
    return date('YmdHis') . substr((string)mt_rand(100000, 999999), 0, 6);
}

/**
 * 收款码模式：用户提交实付金额 + 转账单号
 * 返回 array(ok, msg)
 */
function moe_rc_submit($uid, $amount, $trans, $contact = '')
{
    if (!moe_rc_on()) return array('ok' => 0, 'msg' => '本站暂未开放充值');
    $amount = round((float)$amount, 2);
    if ($amount < 0.1 || $amount > 100000) return array('ok' => 0, 'msg' => '金额需在 0.1 ~ 100000 元之间');
    $trans = trim((string)$trans);
    // 2.2.20：转账单号改为选填（扫码付完先提交金额即可开始实时跟踪；填了单号站长核对更快）
    if (mb_strlen($trans, 'UTF-8') > 64) return array('ok' => 0, 'msg' => '转账单号过长（64 字以内）');

    $orders = moe_rc_orders_load();
    // 同一转账单号防重复提交（单号为空时跳过查重）
    if ($trans !== '') {
        foreach ($orders as $o) {
            if (($o['trans'] ?? '') === $trans && in_array($o['status'], array('pending', 'approved'), true)) {
                return array('ok' => 0, 'msg' => '该转账单号已提交过，请勿重复提交');
            }
        }
    }
    if (count($orders) > 2000) $orders = array_slice($orders, 0, 1500);
    $no = moe_rc_order_no();   // 2.2.20 修复：此前 $no 未定义，提交成功后订单号带不回前端，实时跟踪面板从不启动
    array_unshift($orders, array(
        'no'       => $no,
        'user_id'  => (int)$uid,
        'amount'   => $amount,
        'coins'    => round($amount * moe_rc_rate(), 2),
        'trans'    => $trans,
        'contact'  => mb_substr(trim((string)$contact), 0, 60, 'UTF-8'),
        'source'   => 'qrcode',
        'status'   => 'pending',
        'time'     => date('Y-m-d H:i:s'),
    ));
    moe_rc_orders_save($orders);
    return array('ok' => 1, 'msg' => '充值订单已提交，确认到账后' . moe_pt_coin_name() . '自动入账（页面会实时跟踪状态，到账自动刷新）', 'no' => $no);
}

/** 创建第三方接口模式的待支付订单，返回跳转参数 */
function moe_rc_api_order($uid, $amount)
{
    if (!moe_rc_on()) return array('ok' => 0, 'msg' => '本站暂未开放充值');
    $api = trim((string)setting('recharge_api_url', ''));
    if ($api === '') return array('ok' => 0, 'msg' => '站长未配置第三方支付接口，请使用扫码 + 提交单号的方式');
    if (moe_rc_secret() === '') return array('ok' => 0, 'msg' => '站长未配置回调密钥，第三方模式不可用');
    $amount = round((float)$amount, 2);
    if ($amount < 0.1 || $amount > 100000) return array('ok' => 0, 'msg' => '金额需在 0.1 ~ 100000 元之间');

    $no = moe_rc_order_no();
    $orders = moe_rc_orders_load();
    if (count($orders) > 2000) $orders = array_slice($orders, 0, 1500);
    array_unshift($orders, array(
        'no' => $no, 'user_id' => (int)$uid, 'amount' => $amount,
        'coins' => round($amount * moe_rc_rate(), 2), 'trans' => '', 'contact' => '',
        'source' => 'api', 'status' => 'pending', 'time' => date('Y-m-d H:i:s'),
    ));
    moe_rc_orders_save($orders);
    $q = http_build_query(array(
        'order_no'   => $no,
        'uid'        => (int)$uid,
        'money'      => $amount,
        'coins'      => round($amount * moe_rc_rate(), 2),
        'notify_url' => base_url() . 'pay/pay-notify.php',
        // 2.2.3：支付完成后浏览器回跳商城充值区（网关支持时生效，自动展示实时状态）
        'return_url' => base_url() . 'user?a=shop&rc_no=' . urlencode($no) . '#rc-top',
        'sign'       => moe_rc_sign($no, $amount, $uid, moe_rc_secret()),
    ));
    return array('ok' => 1, 'url' => $api . (strpos($api, '?') === false ? '?' : '&') . $q, 'no' => $no);
}

/** 订单到账：加金币（幂等，重复调用不会重复入账） */
function moe_rc_approve_order(&$orders, $i, $source = 'admin')
{
    $o = $orders[$i];
    if (($o['status'] ?? '') !== 'pending') return array('ok' => 0, 'msg' => '订单已处理过');
    if (!function_exists('moe_pt_add')) return array('ok' => 0, 'msg' => '积分模块缺失');
    // 2.2.2：充值入账到「金币」余额（商城兑换时可选择用积分或金币）
    $r = moe_pt_add((int)$o['user_id'], (float)$o['coins'], 'recharge',
        '充值到账 ' . $o['amount'] . ' 元 · 订单 ' . $o['no'], 'coins');
    if (empty($r['ok'])) return array('ok' => 0, 'msg' => moe_pt_coin_name() . '入账失败：' . (string)($r['msg'] ?? ''));
    $orders[$i]['status'] = 'approved';
    $orders[$i]['done_at'] = date('Y-m-d H:i:s');
    $orders[$i]['done_by'] = $source;
    return array('ok' => 1);
}

/** 站长确认 / 驳回（后台） */
function moe_rc_admin_review($orderNo, $action, $reason = '')
{
    $orders = moe_rc_orders_load();
    foreach ($orders as $i => $o) {
        if (($o['no'] ?? '') !== $orderNo) continue;
        if ($action === 'approve') {
            $r = moe_rc_approve_order($orders, $i, 'admin');
            if (empty($r['ok'])) return $r;
            moe_rc_orders_save($orders);
            return array('ok' => 1, 'msg' => '订单 ' . $orderNo . ' 已确认，' . $o['coins'] . ' ' . moe_pt_coin_name() . '已入账');
        }
        if ($action === 'reject') {
            if (($o['status'] ?? '') !== 'pending') return array('ok' => 0, 'msg' => '订单已处理过');
            $orders[$i]['status'] = 'rejected';
            $orders[$i]['done_at'] = date('Y-m-d H:i:s');
            $orders[$i]['done_note'] = mb_substr(trim((string)$reason), 0, 120, 'UTF-8');
            moe_rc_orders_save($orders);
            return array('ok' => 1, 'msg' => '订单 ' . $orderNo . ' 已驳回');
        }
        break;
    }
    return array('ok' => 0, 'msg' => '没有找到该订单');
}

/**
 * 第三方回调：验证签名 + 幂等到账
 * $amount 为支付金额（元）；订单金额不一致时拒绝（防篡改）
 */
function moe_rc_notify($orderNo, $amount, $uid, $sign)
{
    if (moe_rc_secret() === '') return array('ok' => 0, 'msg' => '本站未启用第三方充值');
    $orderNo = trim((string)$orderNo);
    if ($orderNo === '') return array('ok' => 0, 'msg' => '缺少订单号');
    $amount = round((float)$amount, 2);
    // 2.2.30：签名比较改用 hash_equals（恒定时间），消除理论时序侧信道；结果完全一致。
    if (!hash_equals((string)moe_rc_sign($orderNo, $amount, (int)$uid, moe_rc_secret()), strtoupper(trim((string)$sign)))) {
        return array('ok' => 0, 'msg' => '签名校验失败');
    }
    $orders = moe_rc_orders_load();
    foreach ($orders as $i => $o) {
        if (($o['no'] ?? '') !== $orderNo) continue;
        if ((int)$o['user_id'] !== (int)$uid) return array('ok' => 0, 'msg' => '订单用户不匹配');
        if (abs((float)$o['amount'] - $amount) > 0.001) return array('ok' => 0, 'msg' => '支付金额与订单不符');
        if (($o['status'] ?? '') === 'approved') {
            return array('ok' => 1, 'msg' => 'success', 'already' => 1);   // 幂等：重复回调直接成功
        }
        $r = moe_rc_approve_order($orders, $i, 'api');
        if (empty($r['ok'])) return $r;
        moe_rc_orders_save($orders);
        return array('ok' => 1, 'msg' => 'success');
    }
    return array('ok' => 0, 'msg' => '订单不存在');
}

/** 用户中心：我的充值记录（最近 N 条） */
function moe_rc_user_orders($uid, $limit = 10)
{
    $out = array();
    foreach (moe_rc_orders_load() as $o) {
        if ((int)($o['user_id'] ?? 0) === (int)$uid) $out[] = $o;
        if (count($out) >= $limit) break;
    }
    return $out;
}
