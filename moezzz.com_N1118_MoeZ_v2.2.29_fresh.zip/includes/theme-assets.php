<?php
/**
 * MoeZ · 主题资源路径适配层（工程化改造 2.2.30）
 *
 * 背景：站点做过一次目录整理 —— tests/、templates/ 下的历史主题包、docs.html、
 * favicon.png 已移入 content/archive/；docs/ 下的乱码文档已合并改名；
 * uploads/ 由「平铺」改为 uploads/{image|video|audio|file}/YYYYMM/ 分月存放。
 * 主题里凡是「写死站点目录」的写法，目录一变就会 404，故统一收敛到本文件。
 *
 * 对外提供 4 个函数（只定义、不执行，加载顺序无依赖）：
 *   moe_theme_icon()    图标 URL 兜底：主题自带图标文件缺失时回退站点根 favicon.ico
 *   moe_icon_links()    统一输出 icon + apple-touch-icon 两行，7 套主题一致
 *   moe_theme_asset()   跨主题资源解析：优先 default 基准主题，缺失回落当前主题（输出与原写法一致）
 *   moe_is_media_path() 判断字符串是否为附件 / 外链地址，兼容 uploads/ 任意层级
 *
 * 设计约束（重要）：
 *   1. 不改变各主题原有的图标优先级 —— 主题把「按原逻辑算好的 URL」传进来，
 *      非空即原样返回，只有为空时才走「主题文件存在性检查 → 根图标」兜底；
 *   2. 不做任何输出、不读数据库、不写文件，纯函数；
 *   3. 主题侧一律用 function_exists() 判断后再调用：万一官方在线更新只覆盖了
 *      核心而没覆盖主题（或反之），也能安全退回原来的写法，绝不白屏。
 *
 * 目录若再调整，只需要改这一个文件 + docs/目录导航.md，不必逐套主题翻代码。
 */

/** 站点根图标：目录整理后保留 favicon.ico；favicon.png 已归档，切勿再引用 */
if (!function_exists('moe_root_icon')) {
    function moe_root_icon()
    {
        return function_exists('base_url') ? base_url() . 'favicon.ico' : '/favicon.ico';
    }
}

/**
 * 主题图标 URL 兜底。
 * @param string $url       主题按原有优先级算好的图标 URL；非空时原样返回
 * @param string $fallback  主题自带图标的相对路径，如 'assets/favicon.svg'
 */
if (!function_exists('moe_theme_icon')) {
    function moe_theme_icon($url = '', $fallback = '')
    {
        $url = trim((string)$url);
        if ($url !== '') return $url;

        $fallback = ltrim((string)$fallback, '/');
        if ($fallback !== ''
            && strpos($fallback, '..') === false
            && function_exists('theme_path')
            && is_file(theme_path($fallback))) {
            return theme_url($fallback);
        }
        return moe_root_icon();
    }
}

/** 统一输出两行图标声明，避免各主题有的带 apple-touch-icon 有的不带 */
if (!function_exists('moe_icon_links')) {
    function moe_icon_links($url = '', $fallback = '')
    {
        $u = trim((string)$url);
        if ($u === '') $u = moe_theme_icon('', $fallback);
        if ($u === '') return '';
        $h = function_exists('e') ? e($u) : htmlspecialchars($u, ENT_QUOTES, 'UTF-8');
        return '<link rel="icon" href="' . $h . '">' . "\n"
             . '<link rel="apple-touch-icon" href="' . $h . '">' . "\n";
    }
}

/**
 * 跨主题资源解析：返回「站内相对路径」（交给 media_url() 转 URL）。
 * 优先「基准主题」（默认 default）里的文件，缺失时才回落到当前主题自带文件，
 * 都没有则返回空串 —— 这样替换掉主题里写死的 'templates/default/assets/xxx'
 * 之后，输出与原来完全一致，不会悄悄换掉一张图片。
 */
if (!function_exists('moe_theme_asset')) {
    function moe_theme_asset($rel, $base_theme = 'default')
    {
        $rel = ltrim((string)$rel, '/');
        if ($rel === '' || strpos($rel, '..') !== false || !defined('MOE_ROOT')) return '';

        $base = preg_replace('/[^A-Za-z0-9_\-\x{4e00}-\x{9fa5}]/u', '', (string)$base_theme);
        if ($base !== '' && is_file(MOE_ROOT . '/templates/' . $base . '/' . $rel)) {
            return 'templates/' . $base . '/' . $rel;
        }
        $cur = function_exists('theme') ? (string)theme() : '';
        $cur = preg_replace('/[^A-Za-z0-9_\-\x{4e00}-\x{9fa5}]/u', '', $cur);
        if ($cur !== '' && $cur !== $base && is_file(MOE_ROOT . '/templates/' . $cur . '/' . $rel)) {
            return 'templates/' . $cur . '/' . $rel;
        }
        return '';
    }
}

/**
 * 是否为「可直接当图片地址使用」的字符串。
 * 兼容：外链 / 协议相对 / 根绝对路径 / 历史 media/ 前缀 /
 *       uploads/ 下任意层级（含新增的 image/YYYYMM/ 分月目录）。
 */
if (!function_exists('moe_is_media_path')) {
    function moe_is_media_path($s)
    {
        $s = trim((string)$s);
        if ($s === '') return false;
        return (bool)preg_match('#^(?:(?:https?:)?//|/|media/|uploads/)#i', $s);
    }
}
