<?php
/**
 * MoeZ - 公共函数库
 * 兼容 PHP 7.2+
 */

/* ============ 数据库快捷操作 ============ */

function q($sql, $params = array()) {
    $st = moe_db()->prepare($sql);
    $st->execute($params);
    return $st;
}
function rows($sql, $params = array()) { return q($sql, $params)->fetchAll(); }
function row($sql, $params = array()) { $r = q($sql, $params)->fetch(); return $r === false ? null : $r; }
function one($sql, $params = array()) { $r = q($sql, $params)->fetchColumn(); return $r === false ? null : $r; }
function last_id() { return moe_db()->lastInsertId(); }

/* ============ 设置项 ============ */

function setting($key, $default = '') {
    if (!isset($GLOBALS['moe_settings'])) {
        $GLOBALS['moe_settings'] = array();
        // 1.9.0：Redis 开启走 Redis，未开启走文件缓存 —— 命中时整页 0 次设置表查询
        $cached = function_exists('moe_cache_store_get') ? moe_cache_store_get('settings') : null;
        if (is_array($cached) && !empty($cached)) {
            $GLOBALS['moe_settings'] = $cached;
        } else {
            try {
                foreach (rows('SELECT skey, svalue FROM ' . moe_table('settings')) as $s) {
                    $GLOBALS['moe_settings'][$s['skey']] = $s['svalue'];
                }
            } catch (PDOException $e) { /* 安装前调用时忽略 */ }
            if (function_exists('moe_cache_store_set')) {
                moe_cache_store_set('settings', $GLOBALS['moe_settings'], 300);
            }
        }
    }
    return array_key_exists($key, $GLOBALS['moe_settings']) ? $GLOBALS['moe_settings'][$key] : $default;
}
function setting_set($key, $value) {
    q('INSERT INTO ' . moe_table('settings') . ' (skey, svalue) VALUES (?,?)
       ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)', array($key, $value));
    $GLOBALS['moe_settings'][$key] = $value;
    // 设置变更：$GLOBALS 已即时生效；删除缓存键让下一次请求从数据库整表重载
    // —— 避免并发写入时缓存数组缺项。
    // 2.2.30 优化：不再先 SETEX 再 DEL（写完立刻删，那次 Redis 写入是纯浪费）。
    if (function_exists('moe_cache_store_set')) {
        moe_cache_store_del('settings');
        // Redis 连接参数变了 → 缓存的 Redis 配置也要作废：
        // 2.2.28 起 moe_cache_cfg 缓存在 $GLOBALS（本请求内），一并清掉，
        // 否则「保存设置 → 立即连接检测」拿到的还是保存前的旧配置，误报连接失败。
        if (strpos((string)$key, 'redis_') === 0) {
            if (function_exists('moe_fcache_del')) moe_fcache_del('cache_cfg');
            unset($GLOBALS['moe_cache_cfg']);
        }
    }
    // 设置项变化（换主题 / 改站点信息）→ 页面缓存整体失效
    if (function_exists('moe_pcache_bump')) moe_pcache_bump();
}
function site($key, $default = '') { return setting($key, $default); }

/* ============ URL 与路径 ============ */

/** 是否 HTTPS */
function is_ssl() {
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443')
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && strpos($_SERVER['HTTP_X_FORWARDED_PROTO'], 'https') !== false);
}

/**
 * 站点根 URL（含协议，结尾带 /）
 * 优先使用后台「站点地址」设置；未设置时按文档根目录自动探测，兼容子目录与后台页面。
 */
function base_url() {
    static $u = null;
    if ($u !== null) return $u;

    $custom = trim((string)setting('site_url', ''));
    if ($custom !== '') {
        if (strpos($custom, '//') === 0) {
            $custom = (is_ssl() ? 'https:' : 'http:') . $custom;
        } elseif (strpos($custom, '://') === false) {
            $custom = (is_ssl() ? 'https:' : 'http:') . '//' . ltrim($custom, '/');
        }
        return $u = rtrim($custom, '/') . '/';
    }

    $dir = '';
    $docRoot = isset($_SERVER['DOCUMENT_ROOT']) ? realpath($_SERVER['DOCUMENT_ROOT']) : '';
    $root    = realpath(MOE_ROOT);
    if ($docRoot && $root) {
        $dr = rtrim(str_replace('\\', '/', $docRoot), '/');
        $rt = rtrim(str_replace('\\', '/', $root), '/');
        if (strcasecmp($dr, $rt) === 0) {
            $dir = '';
        } elseif (stripos($rt . '/', $dr . '/') === 0) {
            $dir = substr($rt, strlen($dr));
        }
    }
    if ($dir === '' && !empty($_SERVER['SCRIPT_NAME']) && strcasecmp((string)$docRoot, (string)$root) !== 0) {
        // 兜底：由入口脚本推断（后台脚本位于 /admin 下，需去掉一层）
        $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME']);
        $dir = rtrim(dirname($script), '/');
        if (substr($dir, -6) === '/admin') $dir = substr($dir, 0, -6);
    }

    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : 'localhost';
    return $u = (is_ssl() ? 'https:' : 'http:') . '//' . $host . $dir . '/';
}

/** 站点根 URL 的协议无关形式（//host/dir/），用于图文等 http/https 通用引用 */
function base_path() {
    static $p = null;
    if ($p !== null) return $p;
    return $p = preg_replace('#^https?:#i', '', base_url());
}

/**
 * 统一链接助手（兼容旧模板写法）
 * u() / u('post/3') / u('category/tech') / u('page/about') / u('search/关键词')
 */
function u($path = '') {
    $path = trim((string)$path, '/');
    if ($path === '' || $path === 'index') return home_url();
    $parts = explode('/', $path, 2);
    $kind  = $parts[0];
    $arg   = isset($parts[1]) ? $parts[1] : '';
    switch ($kind) {
        case 'post':     return post_url($arg);
        case 'category': return cat_url($arg);
        case 'page':     return page_url($arg);
        case 'search':   return search_url(rawurldecode($arg));
        case 'rss':      return rss_url();
    }
    if (url_style() === 'default') return base_url() . 'index.php?p=' . $path;
    return base_url() . $path;
}

/** 当前激活模板目录名 */
function theme() { return setting('theme', 'moezzz'); }
/** 模板资源 URL（绝对地址：伪静态后页面层级不一，必须用站点根绝对路径） */
function theme_url($p = '') { return base_url() . 'templates/' . theme() . '/' . ltrim($p, '/'); }
function theme_path($file) { return MOE_ROOT . '/templates/' . theme() . '/' . $file; }

/** 2.2.22：后台 / 投稿共用的正文编辑器（markdown = 自研 Markdown；ueditor = UEditorPlus 富文本） */
function moe_editor_mode() {
    return strtolower(trim((string)setting('editor_mode', 'markdown'))) === 'ueditor' ? 'ueditor' : 'markdown';
}

/** 媒体地址归一化：完整 URL / 绝对路径原样返回，相对路径用协议无关形式拼站点根（http/https 页面均可用） */
function media_url($path) {
    $path = (string)$path;
    if ($path === '' || strpos($path, '://') !== false || $path[0] === '/' || $path[0] === '{') return $path;
    return base_path() . $path;
}

/* ============ 渲染 ============ */

/** 渲染模板（从当前激活模板加载，可传入变量）。$file 可不带 .php 后缀 */
function render($file, $vars = array()) {
    if (substr($file, -4) !== '.php') $file .= '.php';
    // 合并公共视图变量（$site / $nav_cats 等，由前端路由定义）
    if (!empty($GLOBALS['moe_view_common'])) {
        $vars = array_merge($GLOBALS['moe_view_common'], $vars);
    }
    $f = theme_path($file);
    if (!is_file($f)) $f = MOE_ROOT . '/templates/default/' . $file;
    if (!is_file($f)) { http_response_code(500); die('模板文件缺失：' . htmlspecialchars($file)); }
    // 2.2.30 优化：列表页统一预取评论数（一条 GROUP BY），模板循环里零查询。
    // 只读取传入的 posts 数组，不新增 / 修改任何模板变量，输出逐字节不变。
    if (isset($vars['posts']) && is_array($vars['posts']) && !empty($vars['posts'])
        && function_exists('moe_prime_comment_counts')) {
        moe_prime_comment_counts($vars['posts']);
    }
    extract($vars, EXTR_SKIP);

    // 统一捕获渲染结果：① 页面缓存回写
    // 2.1.5：移除前台「我的中心」浮标注入（导航里已有用户入口，浮标属于重复入口）
    $__postId = (isset($post) && is_array($post) && isset($post['id'])) ? (int)$post['id'] : 0;
    $__pcache = !empty($GLOBALS['moe_pcache_key']) && function_exists('moe_pcache_save');
    ob_start();
    include $f;
    $__html = ob_get_clean();
    if ($__pcache) moe_pcache_save($__html, $__postId);
    // 2.0.2：插件输出放在缓存写入之后，插件停用后不会残留在缓存里
    if (function_exists('moe_plugin_render')) {
        $__ph = moe_plugin_render('front_head');
        $__pf = moe_plugin_render('front_footer');
        // 用 callback 而非 preg_replace，避免插件内容里的 $1 / \1 被当成反向引用
        if ($__ph !== '' && stripos($__html, '</head>') !== false) {
            $__html = preg_replace_callback('#</head\s*>#i', function ($mm) use ($__ph) {
                return $__ph . "\n" . $mm[0];
            }, $__html, 1);
        }
        if ($__pf !== '' && stripos($__html, '</body>') !== false) {
            $__html = preg_replace_callback('#</body\s*>#i', function ($mm) use ($__pf) {
                return $__pf . "\n" . $mm[0];
            }, $__html, 1);
        }
    }
    echo $__html;
}

/**
 * 模板片段路径（header/footer 等）。
 * 在模板文件内用 include partial_path('header.php') 引入，
 * 可与模板共享 render() 的变量作用域（$site、$page_title 等）。
 */
function partial_path($file) {
    if (substr($file, -4) !== '.php') $file .= '.php';
    $f = theme_path($file);
    if (!is_file($f)) $f = MOE_ROOT . '/templates/default/' . $file;
    return $f;
}

/* ============ 文本与时间 ============ */

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function excerpt_text($html, $len = 140) {
    $t = trim(preg_replace('/\s+/u', ' ', strip_tags((string)$html)));
    if (function_exists('mb_substr') && mb_strlen($t, 'UTF-8') > $len) {
        return mb_substr($t, 0, $len, 'UTF-8') . '…';
    }
    return $t;
}

/** 取首字符（头像占位用，兼容未安装 mbstring 的环境） */
function initial($str) {
    $str = trim((string)$str);
    if ($str === '') return '?';
    $c = preg_match('/^./us', $str, $m) ? $m[0] : substr($str, 0, 1);
    return function_exists('mb_strtoupper') ? mb_strtoupper($c, 'UTF-8') : strtoupper($c);
}

/* ============ 友情链接展示助手（图标 / 描述） ============ */

/**
 * 程序期望的全部表字段（唯一数据源）
 * 新增字段只改这里：install.php 用于新建站点，moe_ensure_schema() 用于老站点自愈
 */
function moe_schema_defs()
{
    return array(
        'posts' => array(
            'content_format' => "VARCHAR(10) NOT NULL DEFAULT 'markdown'",
            'seo_title'      => "VARCHAR(200) NOT NULL DEFAULT ''",
            'seo_keywords'   => "VARCHAR(255) NOT NULL DEFAULT ''",
            'seo_desc'       => "VARCHAR(500) NOT NULL DEFAULT ''",
            'url_num'        => "INT UNSIGNED NOT NULL DEFAULT 0",
            // 1.6.3：自动保存的「编辑草稿」指向的原文 id（0 = 普通内容）
            'draft_of'       => "INT UNSIGNED NOT NULL DEFAULT 0",
            // 1.8.3：文章标签（逗号分隔，如：php,萌Z,教程）
            'tags'           => "VARCHAR(255) NOT NULL DEFAULT ''",
            // 1.8.7：自动保存草稿槽位标记（1 = 系统自动草稿，全局只保留一篇；发布后自动清除）
            'auto_draft'     => "TINYINT UNSIGNED NOT NULL DEFAULT 0",
            // 2.1.2：文章点赞数
            'likes'          => "INT UNSIGNED NOT NULL DEFAULT 0",
            // 2.2.22：内容来源（'' = 后台发布，contribute = 用户中心投稿）
            'src'            => "VARCHAR(20) NOT NULL DEFAULT ''",
        ),
        'categories' => array(
            'seo_title'    => "VARCHAR(200) NOT NULL DEFAULT ''",
            'seo_keywords' => "VARCHAR(255) NOT NULL DEFAULT ''",
            'seo_desc'     => "VARCHAR(500) NOT NULL DEFAULT ''",
            // 1.8.4：分类自定义链接（填了则前台导航/列表点击直接跳转该链接，如外链或站内页面）
            'link'         => "VARCHAR(255) NOT NULL DEFAULT ''",
        ),
        'comments' => array(
            'ua'       => "VARCHAR(255) NOT NULL DEFAULT ''",
            'location' => "VARCHAR(150) NOT NULL DEFAULT ''",
            // 2.0.0：登录用户评论归属（0 = 游客评论）
            'user_id'  => "INT UNSIGNED NOT NULL DEFAULT 0",
        ),
        // 2.0.0：用户体系（角色 / 状态 / 资料）
        'users' => array(
            'role'       => "VARCHAR(20) NOT NULL DEFAULT 'member'",
            'status'     => "VARCHAR(20) NOT NULL DEFAULT 'active'",
            'bio'        => "VARCHAR(255) NOT NULL DEFAULT ''",
            'qq'         => "VARCHAR(20) NOT NULL DEFAULT ''",
            'site'       => "VARCHAR(255) NOT NULL DEFAULT ''",
            'last_login' => "DATETIME NULL DEFAULT NULL",
        ),
        'links' => array(
            'status'       => "VARCHAR(20) NOT NULL DEFAULT 'approved'",
            'contact'      => "VARCHAR(128) NOT NULL DEFAULT ''",
            'last_check'   => "DATETIME NULL DEFAULT NULL",
            'check_result' => "VARCHAR(255) NOT NULL DEFAULT ''",
            'logo'         => "VARCHAR(255) NOT NULL DEFAULT ''",
            'description'  => "VARCHAR(255) NOT NULL DEFAULT ''",
        ),
    );
}

/**
 * 表结构自愈：与版本号无关地检查并补齐缺失字段。
 *
 * 背景：自动升级靠 db_version 门槛触发，而单表 ALTER 失败会被静默吞掉、
 * 版本号却照样推进 —— 一旦某次 ALTER 失败（锁表 / 权限 / 超时），
 * 后续升级再也不会执行，表现为「Unknown column 'xxx' in 'field list'」。
 *
 * 本函数用字段定义的指纹存到设置项 schema_sig：全部成功后只读一次设置即返回；
 * 任意一张表失败则不写指纹，下次请求自动重试，直到补齐为止。
 *
 * @return bool 结构是否完整
 */
function moe_ensure_schema($force = false)
{
    static $res = null;
    if ($res !== null && !$force) return $res;

    $res = true;
    try {
        $defs = moe_schema_defs();
        $sig  = md5(json_encode($defs));
        if (!$force && (string)setting('schema_sig', '') === $sig) return true;

        $ok = true;
        foreach ($defs as $table => $cols) {
            try {
                $t = moe_table($table);
                $have = array();
                foreach (rows('SHOW COLUMNS FROM ' . $t) as $c) {
                    if (isset($c['Field'])) $have[$c['Field']] = true;
                }
                foreach ($cols as $name => $ddl) {
                    if (isset($have[$name])) continue;
                    q('ALTER TABLE ' . $t . ' ADD COLUMN `' . $name . '` ' . $ddl);
                    // 新增 content_format 时，历史文章正文均为 HTML
                    if ($table === 'posts' && $name === 'content_format') {
                        q('UPDATE ' . $t . " SET content_format = 'html'");
                    }
                }
            } catch (Throwable $e) {
                $ok = false;   // 不写指纹 → 下次请求继续重试
            }
        }
        if ($ok) {
            try { setting_set('schema_sig', $sig); } catch (Throwable $e) {}
        }
        $res = $ok;
    } catch (Throwable $e) {
        $res = false;
    }
    return $res;
}

/** 确保单张表字段存在（内部使用，命中缓存后零开销） */
function moe_ensure_columns($table, $defs)
{
    moe_ensure_schema();
}

/** links 表新字段兜底（1.6.5：logo / description） */
function moe_ensure_links_columns()
{
    moe_ensure_schema();
}

/** 友链图标地址：有 logo 用 logo，否则回落到对方站点的 /favicon.ico（模板里 onerror 显示首字母） */
function link_icon($l) {
    $logo = isset($l['logo']) ? trim((string)$l['logo']) : '';
    if ($logo !== '') return media_url($logo);
    $host = isset($l['url']) ? strtolower((string)parse_url($l['url'], PHP_URL_HOST)) : '';
    return $host !== '' ? 'https://' . $host . '/favicon.ico' : '';
}

/** 友链描述（可能为空） */
function link_desc($l) {
    return isset($l['description']) ? trim((string)$l['description']) : '';
}

/* ============ 社交链接（1.6.6 动态列表） ============ */

/**
 * 社交链接列表：JSON 存储（social_links），后台可增删改、可自定义图标。
 * 未配置时自动回落到旧的 social_github 等固定设置项，兼容老站点与老模板。
 * 返回：array(array('name'=>..., 'url'=>..., 'icon'=>...), ...)
 */
function moe_social_list()
{
    $out = array();
    $raw = trim((string)setting('social_links', ''));
    if ($raw !== '') {
        $arr = json_decode($raw, true);
        if (is_array($arr)) {
            foreach ($arr as $r) {
                if (!is_array($r)) continue;
                $url  = trim((string)($r['url'] ?? ''));
                if ($url === '') continue;
                $name = trim((string)($r['name'] ?? ''));
                if ($name === '') $name = (string)(parse_url($url, PHP_URL_HOST) ?: '链接');
                $icon = trim((string)($r['icon'] ?? ''));
                $out[] = array('name' => $name, 'url' => $url, 'icon' => $icon);
            }
        }
        return $out;
    }
    // 旧设置迁移兼容
    $legacy = array(
        array('GitHub',   setting('social_github', ''),    '🐱'),
        array('哔哩哔哩', setting('social_bilibili', ''),  '📺'),
        array('微博',     setting('social_weibo', ''),     '🔥'),
        array('X / Twitter', setting('social_twitter', ''), '🐦'),
        array('邮箱',     setting('social_mail', ''),      '✉️'),
    );
    foreach ($legacy as $l) {
        $url = trim($l[1]);
        if ($url === '') continue;
        if (strpos($url, '@') !== false && strpos($url, '/') === false) $url = 'mailto:' . $url;
        $out[] = array('name' => $l[0], 'url' => $url, 'icon' => $l[2]);
    }
    return $out;
}

/** 社交图标地址：icon 为 URL（http/相对路径）时返回图片地址，否则返回空（模板显示 emoji / SVG） */
function social_icon_url($icon)
{
    $icon = trim((string)$icon);
    if ($icon === '') return '';
    if (preg_match('#^https?://#i', $icon) || strpos($icon, 'uploads/') === 0 || strpos($icon, 'templates/') === 0 || strpos($icon, 'assets/') === 0) {
        return media_url($icon);
    }
    return '';
}

/* ============ 社交图标自动匹配（2.1.5） ============ */

/**
 * 按平台名称在 assets/social/ 目录下自动找图标文件。
 * 目录里的文件由站长自行放置（png / svg / jpg / webp 均可），
 * 找不到时返回空字符串，调用方回落 emoji。
 * 返回相对路径（如 assets/social/github.png），经 social_icon_url() 转成完整地址。
 */
function moe_social_auto_icon($name)
{
    static $memo = array();
    $name = trim((string)$name);
    if ($name === '') return '';
    if (array_key_exists($name, $memo)) return $memo[$name];

    // 名称 → 候选文件名（不含扩展名），命中第一个存在的文件
    $n = mb_strtolower($name);
    $map = array(
        'github'                     => array('github'),
        '哔哩哔哩'                   => array('bilibili', 'bili', 'bl', 'oauth-bl'),
        'b站'                        => array('bilibili', 'bili', 'bl', 'oauth-bl'),
        'bilibili'                   => array('bilibili', 'bili', 'bl', 'oauth-bl'),
        '微博'                       => array('weibo', 'wb', 'oauth-wb'),
        'weibo'                      => array('weibo', 'wb', 'oauth-wb'),
        'x / twitter'                => array('twitter', 'x', 'oauth-x'),
        'twitter'                    => array('twitter', 'x', 'oauth-x'),
        'x'                          => array('twitter', 'x', 'oauth-x'),
        '邮箱'                       => array('mail', 'email', 'yx', 'oauth-yx'),
        '邮件'                       => array('mail', 'email', 'yx', 'oauth-yx'),
        'email'                      => array('mail', 'email', 'yx', 'oauth-yx'),
        'mail'                       => array('mail', 'email', 'yx', 'oauth-yx'),
        'telegram'                   => array('telegram', 'tg'),
        '知乎'                       => array('zhihu'),
        'zhihu'                      => array('zhihu'),
        '抖音'                       => array('douyin'),
        'douyin'                     => array('douyin'),
        'tiktok'                     => array('douyin', 'tiktok'),
        '小红书'                     => array('xiaohongshu', 'xhs', 'redbook'),
        'xiaohongshu'                => array('xiaohongshu', 'xhs', 'redbook'),
        'qq'                         => array('qq', 'oauth-qq'),
        '微信'                       => array('wechat', 'weixin', 'wx', 'oauth-wx'),
        'wechat'                     => array('wechat', 'weixin', 'wx', 'oauth-wx'),
        'weixin'                     => array('wechat', 'weixin', 'wx', 'oauth-wx'),
        '支付宝'                     => array('alipay', 'zfb', 'oauth-zfb'),
        'alipay'                     => array('alipay', 'zfb', 'oauth-zfb'),
        'rss'                        => array('rss'),
        '订阅'                       => array('rss'),
    );
    // 精确匹配 → 包含匹配（如「我的 GitHub」也能命中）
    $cands = array();
    if (isset($map[$n])) {
        $cands = $map[$n];
    } else {
        foreach ($map as $k => $v) {
            if ($k !== '' && mb_strpos($n, $k) !== false) { $cands = $v; break; }
        }
    }
    foreach ($cands as $c) {
        foreach (array('png', 'svg', 'webp', 'jpg') as $ext) {
            $rel = 'assets/social/' . $c . '.' . $ext;
            if (is_file(MOE_ROOT . '/' . $rel)) {
                return $memo[$name] = $rel;
            }
        }
    }
    return $memo[$name] = '';
}

/**
 * 社交图标统一出口：先看站长填的 icon 是否为图片地址，
 * 不是再按名称去 assets/social/ 自动匹配，都失败返回空（显示 emoji）。
 */
function moe_social_icon($icon, $name = '')
{
    $url = social_icon_url($icon);
    if ($url !== '') return $url;
    return social_icon_url(moe_social_auto_icon($name));
}

/* ============ 登录欢迎语（1.6.6） ============ */

/** 欢迎语列表：后台自定义（每行一条）优先，留空使用内置祝福语，随机抽一条 */
function moe_welcome_line()
{
    $lines = array();
    $custom = trim((string)setting('welcome_text', ''));
    if ($custom !== '') {
        foreach (preg_split('/\r\n|\r|\n/', $custom) as $ln) {
            $ln = trim($ln);
            if ($ln !== '') $lines[] = $ln;
        }
    }
    if (empty($lines)) {
        $lines = array(
            '欢迎回家～今天也是元气满满的一天 🌸',
            '回家啦！茶已经泡好，开始今天的创作吧 ☕',
            '欢迎回来！你的小站一直在等你哦 🏠',
            '又见面啦～快看看今天有没有新评论吧 💬',
            '欢迎回家！记得多喝水，劳逸结合哦 💗',
            '站长的书桌已擦亮，今天写点什么呢？📖',
        );
    }
    return $lines[array_rand($lines)];
}

/** 文章摘要：优先使用自定义摘要，否则由正文（Markdown / HTML）提取纯文本 */
function post_excerpt($post, $len = 140) {
    if (!empty($post['excerpt'])) return $post['excerpt'];
    $fmt = isset($post['content_format']) && $post['content_format'] !== '' ? $post['content_format'] : 'html';
    return excerpt_text(content_plain(isset($post['content']) ? $post['content'] : '', $fmt), $len);
}

/**
 * 后台发布校验：标题必填；文章正文必填，独立页面允许空正文
 * 页面留空用于商城 / 下载中心这类「只需要别名、正文由主题渲染」的视图页。
 */
function moe_content_errors($type, $title, $content) {
    $errs = array();
    if (trim((string)$title) === '') $errs[] = '标题不能为空';
    if ($type !== 'page' && trim((string)$content) === '') $errs[] = '内容不能为空';
    return $errs;
}

/** 是否为视频资源地址（不作为封面图 / 图片输出） */
function moe_is_video_url($url) {
    return (bool)preg_match('/\.(m3u8|mp4|webm|ogg|ogv|mov|avi|flv|mkv)(\?|#|$)/i', (string)$url);
}

/** 从正文（Markdown / HTML）提取第一张图片地址，无图返回 '' */
function moe_first_image($content) {
    $c = (string)$content;
    if ($c === '') return '';
    // Markdown 图片（排除视频资源）
    if (preg_match('/!\[[^\]]*\]\(\s*([^)\s]+?)(?:\s+["\'][^"\']*["\'])?\s*\)/', $c, $m)) {
        if (!moe_is_video_url($m[1])) return $m[1];
    }
    // 原始 <img> 标签
    if (preg_match('/<img\b[^>]*?src=["\']([^"\']+)["\']/i', $c, $m)) {
        if (!moe_is_video_url($m[1])) return $m[1];
    }
    return '';
}

/**
 * 文章封面：未手动设置时自动取正文第一张图
 * 返回原始地址（一般配合 media_url() 使用），无可用图片返回 ''
 */
function post_cover($post) {
    static $memo = array();
    $cover = is_array($post) && !empty($post['cover']) ? $post['cover'] : '';
    if ($cover !== '') return $cover;
    $content = isset($post['content']) ? (string)$post['content'] : '';
    if ($content === '') return '';
    // 2.2.30 优化：模板里一篇文章常连调 2~3 次，避免重复对整篇正文跑两条正则。
    // 键含 id 与正文摘要，编辑预览等「同 id 不同正文」不会读到旧结果。
    $key = (isset($post['id']) ? (int)$post['id'] : 0) . ':' . md5($content);
    if (!array_key_exists($key, $memo)) $memo[$key] = moe_first_image($content);
    return $memo[$key];
}

/** 预计阅读时长（分钟，按 350 字/分钟估算） */
function reading_time($post) {
    $fmt = isset($post['content_format']) && $post['content_format'] !== '' ? $post['content_format'] : 'html';
    $words = content_words(isset($post['content']) ? $post['content'] : '', $fmt);
    return max(1, (int)ceil($words / 350));
}

function format_time($dt, $fmt = 'Y-m-d') {
    $ts = is_numeric($dt) ? (int)$dt : strtotime($dt);
    return date($fmt, $ts);
}
function nice_time($dt) {
    $ts = is_numeric($dt) ? (int)$dt : strtotime($dt);
    $d  = time() - $ts;
    if ($d < 60)   return '刚刚';
    if ($d < 3600) return floor($d / 60) . ' 分钟前';
    if ($d < 86400) return floor($d / 3600) . ' 小时前';
    if ($d < 2592000) return floor($d / 86400) . ' 天前';
    return date('Y-m-d', $ts);
}

/* ============ CSRF 防护 ============ */

function csrf_token() {
    if (empty($_SESSION['moe_csrf'])) $_SESSION['moe_csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['moe_csrf'];
}
function csrf_field() {
    return '<input type="hidden" name="_token" value="' . csrf_token() . '">';
}
function csrf_verify() {
    $ok = isset($_POST['_token']) && hash_equals($_SESSION['moe_csrf'] ?? '', $_POST['_token']);
    if (!$ok) { http_response_code(403); die('❌ 令牌校验失败，请返回刷新页面重试'); }
}
function csrf_ajax() {
    $ok = isset($_SERVER['HTTP_X_CSRF_TOKEN']) && hash_equals($_SESSION['moe_csrf'] ?? '', $_SERVER['HTTP_X_CSRF_TOKEN']);
    if (!$ok) { http_response_code(403); die('{"ok":0,"msg":"令牌校验失败"}'); }
}

/* ============ 会话与权限 ============ */

/* 2.0.0：会话统一存放登录用户 id（管理员 / 作者 / 会员共用）。
 * current_user() 对所有已登录角色都返回用户；is_admin() 只放行可进后台的角色，
 * 会员在前台能拿到自己的资料，但访问后台会被 require_admin() 拦下。 */
function is_admin() {
    $u = current_user();
    if (!$u) return false;
    if (isset($u['status']) && (string)$u['status'] !== 'active') return false;
    $role = isset($u['role']) ? (string)$u['role'] : 'admin';   // 老结构（无 role 列）按站长处理
    return $role === 'admin' || $role === 'author';
}
function require_admin() {
    if (!is_admin()) {
        header('Location: login.php');
        exit;
    }
}
function current_user() {
    static $u = null;
    if ($u === null && !empty($_SESSION['moe_uid'])) {
        try {
            $u = row('SELECT * FROM ' . moe_table('users') . ' WHERE id = ?', array((int)$_SESSION['moe_uid']));
        } catch (Throwable $e) { $u = null; }
        if (!$u) $u = false;   // 缓存「查无此人」，避免每次重复查询
    }
    return $u ? $u : null;
}

/* ============ 分页 ============ */

/**
 * 生成分页 HTML
 * $base 形如 "index.php?p=index&page=" 或 "post/..." 已含页码前缀
 */
function paginate($total, $perPage, $cur, $base) {
    $pages = max(1, (int)ceil($total / $perPage));
    if ($pages <= 1) return '';
    $cur = min(max(1, $cur), $pages);
    $html = '<div class="pager">';
    if ($cur > 1) $html .= '<a class="page-btn" href="' . e($base . ($cur - 1)) . '">‹ 上一页</a>';
    for ($i = 1; $i <= $pages; $i++) {
        if ($pages > 9 && $i > 2 && $i < $pages - 1 && abs($i - $cur) > 1) {
            if ($i === 3) $html .= '<span class="page-dots">…</span>';
            continue;
        }
        $html .= '<a class="page-btn' . ($i === $cur ? ' cur' : '') . '" href="' . e($base . $i) . '">' . $i . '</a>';
    }
    if ($cur < $pages) $html .= '<a class="page-btn" href="' . e($base . ($cur + 1)) . '">下一页 ›</a>';
    return $html . '</div>';
}

/* ============ 其他 ============ */

function redirect($url) { header('Location: ' . $url); exit; }
function json_exit($ok, $msg = '', $extra = array()) {
    header('Content-Type: application/json; charset=utf-8');
    $payload = array_merge(array('ok' => $ok ? 1 : 0, 'msg' => $msg), $extra);

    /* 2.2.10 关键修复：json_encode 遇到非法 UTF-8（多为历史 GBK 编码的附件
     * 文件名 / 解压出来的中文目录）会返回 false，echo false = 空响应体，
     * 前端表现为「接口无响应（HTTP 200）」。这里两层兜底：
     *   ① INVALID_UTF8_SUBSTITUTE 标志保证非法字节被替换而非整体失败；
     *   ② 仍失败时逐字段尝试 GBK→UTF-8 转码重试，再失败输出固定错误 JSON。 */
    $flags = JSON_UNESCAPED_UNICODE;
    if (defined('JSON_INVALID_UTF8_SUBSTITUTE')) $flags |= JSON_INVALID_UTF8_SUBSTITUTE;

    $json = json_encode($payload, $flags);
    if ($json === false) {
        $__fix_utf8 = function (&$v) use (&$__fix_utf8) {
            if (is_string($v)) {
                if (!preg_match('//u', $v)) {
                    $c = function_exists('mb_convert_encoding')
                        ? @mb_convert_encoding($v, 'UTF-8', 'GBK, GB2312, BIG5, UTF-8') : '';
                    $v = is_string($c) && preg_match('//u', $c) ? $c : '';
                }
            } elseif (is_array($v)) {
                foreach ($v as $k => $vv) $__fix_utf8($v[$k]);
            }
        };
        $__fix_utf8($payload);
        $json = json_encode($payload, $flags);
        if ($json === false) {
            $json = '{"ok":0,"msg":"响应数据包含无法识别的编码（多为历史附件文件名），请检查 uploads 目录中的中文文件名"}';
        }
    }
    echo $json;
    exit;
}

/** 站点统计信息（1.9.0：整站 SUM/COUNT 较重，缓存 5 分钟；发文章 / 评论后主动失效） */
function site_stats() {
    static $s = null;
    if ($s !== null) return $s;
    $calc = function () {
        $posts = (int)one('SELECT COUNT(*) FROM ' . moe_table('posts') . " WHERE type='post' AND status='published'");
        $cmts  = (int)one('SELECT COUNT(*) FROM ' . moe_table('comments') . " WHERE status='approved'");
        $views = (int)one('SELECT COALESCE(SUM(views),0) FROM ' . moe_table('posts') . " WHERE type='post'");
        return array('posts' => $posts, 'comments' => $cmts, 'views' => $views);
    };
    $s = function_exists('moe_remember') ? moe_remember('site_stats', 300, $calc) : $calc();
    return $s;
}

/** 前台导航分类（1.9.0：缓存 5 分钟，分类增删改时主动失效） */
function nav_categories() {
    $calc = function () {
        return rows('SELECT * FROM ' . moe_table('categories') . ' ORDER BY sort, id');
    };
    return function_exists('moe_remember') ? moe_remember('nav_cats', 300, $calc) : $calc();
}

/** 文章浏览数 +1（1.9.0：同一会话同一篇只计一次，显著减少写库压力） */
function moe_add_view($id) {
    $id = (int)$id;
    if ($id <= 0) return false;
    if (isset($_SESSION['moe_seen'][$id])) return false;
    $_SESSION['moe_seen'][$id] = 1;
    if (count($_SESSION['moe_seen']) > 200) $_SESSION['moe_seen'] = array($id => 1);   // 防止会话无限增长
    try {
        q('UPDATE ' . moe_table('posts') . ' SET views = views + 1 WHERE id = ?', array($id));
        return true;
    } catch (Throwable $e) { return false; }
}

/**
 * 批量取评论数（1.9.0）
 * 列表页原来对每篇文章发一条 COUNT 查询（N+1），这里合并成一条 GROUP BY。
 * 同一次请求内的结果会复用，模板可以放心循环调用。
 */
function moe_comment_counts(array $ids) {
    static $map = array();
    $need = array();
    foreach ($ids as $id) {
        $id = (int)$id;
        if ($id > 0 && !array_key_exists($id, $map)) $need[] = $id;
    }
    $need = array_values(array_unique($need));
    if (!empty($need)) {
        $in = implode(',', array_fill(0, count($need), '?'));
        try {
            foreach (rows('SELECT post_id, COUNT(*) AS c FROM ' . moe_table('comments')
                . " WHERE status='approved' AND post_id IN ($in) GROUP BY post_id", $need) as $r) {
                $map[(int)$r['post_id']] = (int)$r['c'];
            }
        } catch (Throwable $e) { /* 表未就绪忽略 */ }
        foreach ($need as $id) if (!isset($map[$id])) $map[$id] = 0;
    }
    $out = array();
    foreach ($ids as $id) $out[(int)$id] = isset($map[(int)$id]) ? $map[(int)$id] : 0;
    return $out;
}

/** 单篇评论数（自动走上面的批量缓存） */
function post_comment_count($id) {
    $m = moe_comment_counts(array((int)$id));
    return isset($m[(int)$id]) ? $m[(int)$id] : 0;
}

/** 列表渲染前预取评论数：一次查询拿全页所需数据，模板循环里零查询 */
function moe_prime_comment_counts(array $posts) {
    $ids = array();
    foreach ($posts as $p) {
        if (is_array($p) && isset($p['id'])) $ids[] = (int)$p['id'];
    }
    if (!empty($ids)) moe_comment_counts($ids);
}

/**
 * 内容变更统一入口（1.9.0）
 * 发文 / 删文 / 评论审核 / 分类增删改 / 友链变更后调用：
 * 统计与导航缓存失效 + 页面缓存换版本号（全站静态缓存立即刷新）
 */
function moe_content_changed() {
    if (function_exists('moe_forget')) {
        moe_forget('site_stats');
        moe_forget('nav_cats');
    }
    if (function_exists('moe_pcache_bump')) moe_pcache_bump();
}

/** 模板列表（后台模板管理） */
function themes_list() {
    $out = array();
    $files = glob(MOE_ROOT . '/templates/*/info.php');
    foreach (is_array($files) ? $files : array() as $f) {
        $dir = basename(dirname($f));
        $info = array('name' => $dir, 'version' => '1.0', 'author' => '', 'desc' => '', 'dir' => $dir, 'screenshot' => '');
        $arr = include $f;
        if (is_array($arr)) $info = array_merge($info, $arr);
        $info['dir'] = $dir;
        $shot = dirname($f) . '/screenshot.png';
        if (is_file($shot)) $info['screenshot'] = 'templates/' . $dir . '/screenshot.png';
        $out[] = $info;
    }
    return $out;
}

/* ============ 模板设置（主题可配置项） ============ */

/**
 * 当前模板声明的设置项，定义于模板 info.php 的 'settings' 键：
 *   array('key'=>'accent', 'label'=>'主色调', 'type'=>'color', 'default'=>'#cbbfff', 'hint'=>'...'),
 *   array('key'=>'mode',   'label'=>'模式',   'type'=>'select', 'default'=>'a', 'options'=>array('a'=>'方案A','b'=>'方案B')),
 * type 支持：text / color / bool / select / textarea
 */
function theme_settings($dir = null) {
    static $cache = array();
    $dir = $dir !== null ? $dir : theme();
    $dir = basename((string)$dir);   // 防路径穿越
    if (isset($cache[$dir])) return $cache[$dir];   // 1.9.0：一次请求只解析一次 info.php
    $f = MOE_ROOT . '/templates/' . $dir . '/info.php';
    if (!is_file($f)) return $cache[$dir] = array();
    $arr = include $f;
    $defs = is_array($arr) && isset($arr['settings']) && is_array($arr['settings']) ? $arr['settings'] : array();
    $out = array();
    foreach ($defs as $row) {
        $row = array_merge(array('key' => '', 'label' => '', 'type' => 'text', 'default' => '', 'options' => array(), 'hint' => ''), (array)$row);
        if ($row['key'] === '' || !preg_match('/^[a-zA-Z0-9_]{1,40}$/', $row['key'])) continue;
        if (!in_array($row['type'], array('text', 'color', 'bool', 'select', 'textarea'), true)) $row['type'] = 'text';
        $out[] = $row;
    }
    return $cache[$dir] = $out;
}

/** 读取模板设置项（存于 settings 表：themeopt_模板目录_键名；未保存时取 info.php 默认值） */
function theme_opt($key, $default = '') {
    static $map = array();
    $theme = theme();
    if (!isset($map[$theme])) {
        $map[$theme] = array();
        foreach (theme_settings($theme) as $row) $map[$theme][$row['key']] = $row['default'];
    }
    if (array_key_exists($key, $map[$theme])) {
        return setting('themeopt_' . $theme . '_' . $key, $map[$theme][$key]);
    }
    return $default;
}

/* ============ 文章标签（1.8.3） ============ */

/** 解析文章标签（逗号 / 中文逗号 / 顿号 / 空格分隔），返回去重后的数组 */
function post_tags($post) {
    $raw = is_array($post) ? (isset($post['tags']) ? (string)$post['tags'] : '') : (string)$post;
    $raw = trim($raw);
    if ($raw === '') return array();
    $parts = preg_split('/[,，、;；\s]+/u', $raw);
    $out = array();
    foreach ((array)$parts as $t) {
        $t = trim($t);
        if ($t === '' || mb_strlen($t, 'UTF-8') > 30) continue;
        if (in_array($t, $out, true)) continue;
        $out[] = $t;
        if (count($out) >= 10) break;
    }
    return $out;
}

/** 标签聚合页链接：/tag/关键词 */
function post_tag_url($tag) {
    return base_url() . 'tag/' . rawurlencode((string)$tag);
}

/** 文章标签展示区块（内联样式，五套模板通用；无标签返回空串） */
function post_tags_html($post) {
    $tags = post_tags($post);
    if (empty($tags)) return '';
    $html = '<div class="post-tags" style="margin:20px 0 4px;display:flex;flex-wrap:wrap;gap:8px;align-items:center">';
    $html .= '<span style="font-size:12.5px;color:#9a8fae">🏷 标签</span>';
    foreach ($tags as $t) {
        $html .= '<a href="' . e(post_tag_url($t)) . '" style="font-size:12.5px;line-height:1;padding:5px 12px;border-radius:999px;'
               . 'background:rgba(161,140,209,.14);color:#7f6bff;text-decoration:none">#' . e($t) . '</a>';
    }
    $html .= '</div>';
    return $html;
}

/** 规范化用户输入的标签串：去重 / 去空 / 最多 8 个，返回逗号分隔字符串 */
function moe_tags_normalize($raw) {
    return implode(',', post_tags(array('tags' => (string)$raw)));
}

/* ==== 附件 / 资源管理（1.8.4） ==== */

/**
 * 从 Markdown / HTML / URL 文本里提取本站上传的附件相对路径
 * 匹配 uploads/{image|video|audio|file}/YYYYMM/文件名，返回去重后的相对路径数组
 */
function moe_extract_upload_paths($text) {
    $paths = array();
    if (preg_match_all('#uploads/(?:image|video|audio|file)/\d{6}/[^\s"\'<>\)\]\}，。；]+#u', (string)$text, $m)) {
        foreach ($m[0] as $p) {
            $p = rtrim($p, " \t\r\n");
            if ($p !== '') $paths[$p] = true;
        }
    }
    return array_keys($paths);
}

/** 相对路径是否是合法的上传目录内文件（防目录穿越）；兼容 uploads/ 与旧版 upload/ */
function moe_upload_path_safe($rel) {
    $rel = str_replace('\\', '/', trim((string)$rel));
    if ($rel === '' || strpos($rel, '..') !== false || strpos($rel, "\0") !== false) return false;
    // 2.2.4：uploads/（现行）+ upload/（旧版）+ content/uploadfile/（更早版本）三处均可管理/删除
    if (!preg_match('#^(?:uploads?|content/uploadfile)/[^/]+(/[^/]+)*$#', $rel)) return false;
    return is_file(dirname(__DIR__) . '/' . $rel);
}

/**
 * 删除文章后处理其引用的本站附件
 * 仅当附件不再被其他文章/页面引用时才删文件；返回 array(已删文件数, 保留数)
 */
function moe_post_assets_cleanup(array $relPaths, $withFiles) {
    $removed = 0;
    $kept = 0;
    foreach ($relPaths as $rel) {
        if (!moe_upload_path_safe($rel)) { $kept++; continue; }
        // 是否仍被其他内容引用（正文 / 封面）
        $used = 0;
        try {
            $used = (int)one('SELECT COUNT(*) FROM ' . moe_table('posts') . ' WHERE content LIKE ? OR cover LIKE ?',
                array('%' . addcslashes($rel, '%_\\') . '%', '%' . addcslashes($rel, '%_\\') . '%'));
        } catch (Throwable $e) { $used = 1; }
        if ($used > 0) { $kept++; continue; }
        if ($withFiles) {
            $fs = dirname(__DIR__) . '/' . $rel;
            if (@unlink($fs)) $removed++; else $kept++;
        } else {
            $kept++;
        }
    }
    return array($removed, $kept);
}

/**
 * 递归列出 uploads/ 下全部文件（返回相对路径数组，按修改时间倒序）
 * 2.2.2：迭代异常时降级为 scandir 递归；兼容旧版 upload/ 目录（一并列出，前缀 upload/）
 */
function moe_list_upload_files($sub = '') {
    $root = dirname(__DIR__) . '/uploads';
    $base = $sub !== '' ? $root . '/' . $sub : $root;
    $out = array();
    $scan = function ($dir, $prefix) use (&$scan, &$out) {
        if (!is_dir($dir)) return;
        $items = @scandir($dir);
        foreach (is_array($items) ? $items : array() as $it) {
            if ($it === '.' || $it === '..') continue;
            $p = rtrim($dir, '/\\') . '/' . $it;
            if (is_dir($p)) { $scan($p, $prefix); continue; }
            if (!is_file($p)) continue;
            $rel = $prefix . str_replace('\\', '/', substr($p, strlen(rtrim($dir, '/\\')) + 1));
            $out[$rel] = @filemtime($p) ?: 0;
        }
    };
    if (is_dir($base)) {
        // 优先用迭代器（快），任何异常降级为 scandir 递归
        try {
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base, FilesystemIterator::SKIP_DOTS));
            foreach ($it as $f) {
                if (!$f->isFile()) continue;
                $rel = ($sub !== '' ? 'uploads/' : 'uploads/')
                     . str_replace('\\', '/', substr($f->getPathname(), strlen($root) + 1));
                $out[$rel] = @filemtime($f->getPathname()) ?: 0;
            }
        } catch (Throwable $e) {
            // 保留已列出的部分，降级补齐剩余
            $scan($base, 'uploads/');
        }
    }
    // 旧版程序把附件放在 upload/（无 s）或 content/uploadfile/：一并纳入管理，删除 / 引用计数都能正常工作
    $legacy = dirname(__DIR__) . '/upload';
    if (is_dir($legacy)) $scan($legacy, 'upload/');
    $legacy2 = dirname(__DIR__) . '/content/uploadfile';
    if (is_dir($legacy2)) $scan($legacy2, 'content/uploadfile/');
    arsort($out);
    return array_keys($out);
}

/** 统计一个相对路径被文章/页面引用的次数（正文 + 封面，一次取全量在 PHP 侧比对） */
/**
 * 资源引用计数：正文 / 封面等文本里出现该路径的次数
 * 2.2.20 修复「引用却显示未引用」的误判：
 *   ① 中文 / 空格文件名在 Markdown 里通常以 URL 编码形式出现（%E4%B8%AD…），纯 strpos 匹配不到 → 同时匹配编码形式；
 *   ② 部分正文以 / 开头的绝对路径或带 ./ 前缀引用 → 同时匹配去掉前导 ./ 的形式。
 * 判定为「被引用」只需任一形式命中。
 */
function moe_asset_usage_count($rel, array $allContents) {
    $rel = str_replace('\\', '/', trim((string)$rel));
    if ($rel === '') return 0;
    $needles = array($rel);
    $enc = rawurlencode($rel);
    if ($enc !== $rel) $needles[] = $enc;                       // 全路径编码
    $segEnc = implode('/', array_map('rawurlencode', explode('/', $rel)));
    if ($segEnc !== $rel && !in_array($segEnc, $needles, true)) $needles[] = $segEnc;  // 仅文件名段编码
    $rel2 = preg_replace('#^\./#', '', $rel);
    if ($rel2 !== $rel) $needles[] = $rel2;
    // 中文文件名场景：URL 编码只编文件名部分、目录保留原样的混合形式
    $bn = basename($rel);
    $bnEnc = rawurlencode($bn);
    if ($bnEnc !== $bn) $needles[] = $bnEnc;
    $n = 0;
    foreach ($allContents as $c) {
        $c = (string)$c;
        if ($c === '') continue;
        foreach ($needles as $nd) {
            if ($nd !== '' && strpos($c, $nd) !== false) { $n++; break; }
        }
    }
    return $n;
}

/**
 * 2.2.20：全站引用源扫描 —— 资源管理「未引用」判定前的引用文本采集。
 * 除文章正文 / 封面外，还要扫：独立页面（posts 同表）、系统设置与模板设置
 * （logo / 看板娘立绘 / 收款码等都存在 settings 表）、友链图标、积分商城资源
 * 封面与下载地址、用户头像。此前只扫 posts 表导致「被设置引用的文件显示未引用」，
 * 站长按未引用筛选清理时容易误删。
 * @return string[]
 */
function moe_asset_collect_refs() {
    $refs = array();
    $t = moe_table('posts');
    try {
        foreach (rows('SELECT content, cover FROM ' . moe_table('posts')) as $r) {
            $refs[] = (string)$r['content'];
            $refs[] = (string)$r['cover'];
        }
    } catch (Throwable $e) {}
    // 系统设置 + 模板设置（键值表，值里可能存任何媒体地址）
    try {
        foreach (rows('SELECT skey, svalue FROM ' . moe_table('settings')) as $r) {
            $refs[] = (string)$r['svalue'];
        }
    } catch (Throwable $e) {}
    // 友链图标
    try {
        foreach (rows('SELECT logo FROM ' . moe_table('links')) as $r) {
            $refs[] = (string)$r['logo'];
        }
    } catch (Throwable $e) {}
    // 积分商城资源（封面 / 下载地址）
    if (function_exists('moe_pt_table')) {
        try {
            foreach (rows('SELECT cover, download_url FROM ' . moe_pt_table('goods')) as $r) {
                $refs[] = (string)$r['cover'];
                $refs[] = (string)$r['download_url'];
            }
        } catch (Throwable $e) {}
    }
    // 用户头像
    try {
        foreach (rows('SELECT avatar FROM ' . moe_table('users')) as $r) {
            $refs[] = (string)$r['avatar'];
        }
    } catch (Throwable $e) {}
    return $refs;
}

/* ==== 评论展示辅助（1.8.5） ==== */

/**
 * 评论归属地展示文本：截掉「 · 运营商」尾巴
 * 1.8.5 起评论不再记录运营商；本函数同时兜底处理历史数据里已带运营商的 location
 */
function moe_comment_loc($c) {
    $loc = isset($c['location']) ? trim((string)$c['location']) : '';
    if ($loc === '') {
        if (isset($c['ip']) && function_exists('moe_ip_private') && moe_ip_private($c['ip'])) return '内网 / 保留地址';
        return '';
    }
    $pos = strrpos($loc, ' · ');
    if ($pos !== false) {
        $loc = function_exists('mb_substr') ? trim(mb_substr($loc, 0, $pos)) : trim(substr($loc, 0, $pos));
    }
    return $loc;
}

/**
 * 评论表单默认信息：站长已登录后台时自动带出站点昵称与邮箱（访客仍可修改）
 */
function moe_comment_defaults() {
    if (session_status() === PHP_SESSION_NONE && !defined('MOE_SESSION_STARTED')) {
        // init.php 已统一开启会话，这里兜底避免模板直调时报错
        if (session_status() === PHP_SESSION_NONE) @session_start();
    }
    if (empty($_SESSION['moe_uid'])) return array('author' => '', 'email' => '', 'admin' => false, 'user_id' => 0);
    // 2.0.0：登录用户（含会员）用自己的资料；站长没填资料时回落站点作者名
    $u = current_user();
    $nick = $u ? trim((string)($u['nickname'] ?? '')) : '';
    $mail = $u ? trim((string)($u['email'] ?? '')) : '';
    return array(
        'author'  => $nick !== '' ? $nick : setting('site_author', ''),
        'email'   => $mail !== '' ? $mail : setting('social_mail', ''),
        'admin'   => true,
        'user_id' => $u ? (int)$u['id'] : (int)$_SESSION['moe_uid'],
    );
}

/**
 * 自动生成标签：根据标题 + 正文提取关键词（纯 PHP 实现，无需外部接口）
 * 英文取整词词频；中文取 2~4 字 n-gram 词频；标题命中的词大幅加分；过长/过低频的候选丢弃
 */
function moe_auto_tags($title, $content, $max = 6) {
    $title = trim((string)$title);
    $text  = trim(strip_tags((string)$content));
    if ($title === '' && $text === '') return array();
    if (function_exists('mb_substr')) $text = mb_substr($text, 0, 2000, 'UTF-8');
    else $text = substr($text, 0, 4000);

    $stop = array(
        // 中文虚词 / 高频无义词
        '我们','你们','他们','她们','自己','什么','这个','那个','这样','那样','一个','一些','没有','就是','但是','可是',
        '因为','所以','如果','虽然','然后','于是','还是','也是','都是','可以','应该','可能','已经','现在','时候','地方',
        '东西','事情','问题','方法','方式','结果','开始','最后','一下','一点','非常','真的','感觉','觉得','知道','看到',
        '这里','那里','哪里','这么','那么','怎么','为什么','关于','通过','进行','出来','起来','上来','下来','不了','的话',
        // 英文停用词 / 无关词
        'the','and','for','with','that','this','from','have','has','are','was','were','you','your','our','their','its',
        'not','but','can','will','all','any','out','get','one','two','use','using','com','www','org','net','html','php',
        'http','https','css','png','jpg','gif','webp','div','span','class','style','font','left','right','width','height',
    );

    $score = array();
    $titleL = function_exists('mb_strtolower') ? mb_strtolower($title, 'UTF-8') : strtolower($title);

    // 1) 英文 / 数字词
    if (preg_match_all('/[A-Za-z][A-Za-z0-9_-]{1,19}/', $title . ' ' . $text, $mEn)) {
        foreach (array_count_values(array_map('strtolower', $mEn[0])) as $w => $c) {
            $w = trim($w, '-_');
            if (strlen($w) < 2 || isset($stop[$w]) || in_array($w, $stop, true)) continue;
            $s = (float)$c;
            if ($titleL !== '' && mb_stripos($titleL, $w) !== false) $s += 4;
            $score[$w] = ($score[$w] ?? 0) + $s;
        }
    }

    // 2) 中文 2~4 字 n-gram
    $zh = $title . (($title !== '' && $text !== '') ? '，' : '') . $text;
    if (preg_match_all('/[\x{4e00}-\x{9fa5}]{2,20}/u', $zh, $mZh)) {
        $freq = array();
        foreach ($mZh[0] as $seg) {
            $L = function_exists('mb_strlen') ? mb_strlen($seg, 'UTF-8') : strlen($seg) / 3;
            $L = (int)$L;
            for ($n = 2; $n <= 4; $n++) {
                for ($i = 0; $i + $n <= $L; $i++) {
                    $w = function_exists('mb_substr') ? mb_substr($seg, $i, $n, 'UTF-8') : '';
                    if ($w === '') continue;
                    $freq[$w] = ($freq[$w] ?? 0) + 1;
                }
            }
        }
        foreach ($freq as $w => $c) {
            if (in_array($w, $stop, true)) continue;
            $inTitle = $title !== '' && mb_strpos($title, $w) !== false;
            if ($c < 2 && !$inTitle) continue;              // 出现太少又不在标题 → 丢弃
            $len = function_exists('mb_strlen') ? mb_strlen($w, 'UTF-8') : 2;
            $s = $c * $len;
            if ($inTitle) $s += 6 + $len;
            $score[$w] = ($score[$w] ?? 0) + $s;
        }
    }

    arsort($score);
    $picked = array();
    foreach ($score as $w => $s) {
        if (count($picked) >= $max) break;
        if (preg_match('/^\d+$/u', $w)) continue;
        // 与已选词互相包含 → 视为同一个词的不同切法，跳过
        $dup = false;
        foreach ($picked as $p) {
            if ($w !== $p && (mb_strpos($p, $w) !== false || mb_strpos($w, $p) !== false)) { $dup = true; break; }
        }
        if ($dup) continue;
        $picked[] = $w;
    }
    return $picked;
}
