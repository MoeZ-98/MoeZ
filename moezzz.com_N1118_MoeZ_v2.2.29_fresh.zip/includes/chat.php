<?php
/**
 * MoeZ · 看板娘本地对话引擎（2.1.16 / 2.1.18 拆分）
 * ------------------------------------------------------------
 * 站内数据驱动的轻量聊天：问候 / 自我介绍 / 最新文章 / 热门推荐 /
 * 分类导航 / 关键词搜索 / 友链 / 关于 / 闲聊兜底。
 * 不依赖任何第三方接口，全部本地回复；大模型接入后作为兜底与降级路径
 * （入口 moe_chat_reply 在 includes/chat_ai.php）。返回：
 *   array('text' => 回复文本, 'links' => array(array('t'=>标题,'u'=>链接)), 'chips' => array(array(显示文字, 发送内容)))
 * 任何查询失败都静默降级为兜底回复，绝不抛错到接口层。
 */

if (!defined('MOE_ROOT')) exit('no direct access');

if (!function_exists('moe_chat_local')) {

function moe_chat_local($raw, $ctx = array())
{
    $q = trim((string)$raw);
    /* 截断超长输入，防刷 */
    if (function_exists('mb_strlen')) {
        if (mb_strlen($q) > 200) $q = mb_substr($q, 0, 200);
    } else {
        $q = substr($q, 0, 400);
    }

    $siteName = trim((string)setting('site_name', ''));
    if ($siteName === '') $siteName = '本站';
    /* 2.2.13：台词自称统一跟随后台设置的看板娘名字（主题设置 mascot_name → ai_bot_name → 小星），
       修复「聊天窗标题是一个名字、台词里却自称小助手 / 看板娘」的名称不匹配 */
    $cpName = function_exists('moe_chat_name') ? moe_chat_name() : '小星';
    $empty = array('text' => '', 'links' => array(), 'chips' => array());
    $defaultChips = array(
        array('最新文章', '最新文章'),
        array('热门推荐', '热门推荐'),
        array('站点分类', '站点分类'),
        array('关于小站', '关于小站'),
    );

    $hit = function ($words) use ($q) {
        foreach ((array)$words as $w) {
            if ($w !== '' && $q !== '' && stripos($q, $w) !== false) return true;
        }
        return false;
    };

    /* ---- 站内数据查询（全部容错） ---- */
    $pt = moe_table('posts');
    $ct = moe_table('categories');

    $getLatest = function () use ($pt) {
        try {
            return (array)rows('SELECT id, title FROM ' . $pt . " WHERE type='post' AND status='published' ORDER BY created_at DESC, id DESC LIMIT 3");
        } catch (Throwable $e) { return array(); }
    };
    $getHot = function () use ($pt) {
        try {
            return (array)rows('SELECT id, title, views FROM ' . $pt . " WHERE type='post' AND status='published' ORDER BY views DESC, id DESC LIMIT 3");
        } catch (Throwable $e) { return array(); }
    };
    $getCats = function () use ($pt, $ct) {
        try {
            return (array)rows('SELECT c.*, (SELECT COUNT(*) FROM ' . $pt . ' p WHERE p.category_id = c.id AND p.type=\'post\' AND p.status=\'published\') AS cnt FROM ' . $ct . ' c ORDER BY c.sort, c.id LIMIT 8');
        } catch (Throwable $e) { return array(); }
    };
    $getCount = function () use ($pt) {
        try {
            $r = row('SELECT COUNT(*) AS n FROM ' . $pt . " WHERE type='post' AND status='published'");
            return $r ? (int)$r['n'] : 0;
        } catch (Throwable $e) { return 0; }
    };
    $searchPosts = function ($kw) use ($pt) {
        $kw = trim((string)$kw);
        if ($kw === '') return array();
        try {
            return (array)rows('SELECT id, title, views FROM ' . $pt
                . " WHERE type='post' AND status='published' AND (title LIKE ? OR content LIKE ?)"
                . ' ORDER BY views DESC, id DESC LIMIT 3', array('%' . $kw . '%', '%' . $kw . '%'));
        } catch (Throwable $e) { return array(); }
    };
    /* 轻量模糊搜索：2 字滑窗给标题打分（内容太长不参与，避免全表 LIKE 卡顿），取分最高的前 3 篇
       $minScore：最低可信分数（每个命中片段 +2），低于它的结果宁可不给，避免答非所问 */
    $fuzzyPosts = function ($kw, $minScore = 0) use ($pt) {
        $kw = trim((string)$kw);
        $len = function_exists('mb_strlen') ? mb_strlen($kw, 'UTF-8') : strlen($kw);
        if ($kw === '' || $len < 2) return array();
        $grams = array();
        for ($i = 0; $i < $len - 1; $i++) {
            $g = function_exists('mb_substr') ? mb_substr($kw, $i, 2, 'UTF-8') : substr($kw, $i, 2);
            if ($g !== '' && $g !== false) $grams[$g] = true;
        }
        if (!$grams) return array();
        try {
            $pool = (array)rows('SELECT id, title, views FROM ' . $pt . " WHERE type='post' AND status='published' ORDER BY views DESC LIMIT 50");
        } catch (Throwable $e) { return array(); }
        $scored = array();
        foreach ($pool as $p) {
            $score = 0;
            foreach ($grams as $g => $x) {
                if ($g !== '' && stripos((string)$p['title'], $g) !== false) $score += 2;
            }
            if ($score > 0) $scored[] = array('p' => $p, 's' => $score);
        }
        usort($scored, function ($a, $b) { return $b['s'] - $a['s'] ?: (int)$b['p']['views'] - (int)$a['p']['views']; });
        if ($minScore > 0 && (!$scored || $scored[0]['s'] < $minScore)) return array();
        $out = array();
        foreach (array_slice($scored, 0, 3) as $it) $out[] = $it['p'];
        return $out;
    };

    $toLinks = function ($list) {
        $links = array();
        foreach ((array)$list as $p) {
            $t = trim((string)(isset($p['title']) ? $p['title'] : ''));
            if ($t === '') continue;
            $links[] = array('t' => $t, 'u' => post_url($p));
        }
        return $links;
    };
    $linkLines = function ($list) {
        $n = 0; $out = '';
        foreach ((array)$list as $p) {
            $t = trim((string)(isset($p['title']) ? $p['title'] : ''));
            if ($t === '') continue;
            $n++;
            $out .= ($n > 1 ? "\n" : '') . $n . '. ' . $t;
        }
        return $out;
    };

    /* ================= 意图识别 ================= */

    /* 问候 */
    if ($hit(array('你好', '您好', 'hello', 'hi', '嗨', '哈喽', '在吗', '在不在', '早上好', '中午好', '下午好', '晚上好'))) {
        $r = $empty;
        $hour = (int)date('G');
        $hi = $hour < 6 ? '夜深了还没睡呀' : ($hour < 12 ? '早上好呀' : ($hour < 14 ? '中午好呀' : ($hour < 19 ? '下午好呀' : '晚上好呀')));
        $r['text'] = $hi . '～我叫' . $cpName . '，是' . $siteName . '的看板娘。可以问我「最新文章」「热门推荐」，也可以直接丢关键词让我帮你找文章；想随便聊聊天也可以哦。';
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* 自我介绍 */
    if ($hit(array('你是谁', '你叫什么', '叫什么名字', '介绍自己', '是机器人', '你是人吗', '小助手是谁', '看板娘是谁'))) {
        $r = $empty;
        $r['text'] = '我叫「' . $cpName . '」，是「' . $siteName . '」的看板娘，就住在屏幕角落里～懂一点站内的小事：找文章、看分类、聊聊天都不在话下。'
            . "\n心情不好的时候也欢迎来找我倾诉，我一直都在。";
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* 最新文章 */
    if ($hit(array('最新', '最近更新', '最近文章', '更新了什么', '新文章', '新写的'))) {
        $list = $getLatest();
        $r = $empty;
        if ($list) {
            $r['text'] = "这是最近更新的几篇，戳标题直达：\n" . $linkLines($list);
            $r['links'] = $toLinks($list);
        } else {
            $r['text'] = '咦，站里好像还没有公开的文章，等站长更新吧～';
        }
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* 热门推荐 */
    if ($hit(array('热门', '最火', '推荐', '大家都在看', '排行', '最多人看'))) {
        $list = $getHot();
        $r = $empty;
        if ($list) {
            $r['text'] = "大家都在看这几篇：\n" . $linkLines($list);
            $r['links'] = $toLinks($list);
        } else {
            $r['text'] = '还没有浏览数据呢，要不要看看最新的？';
            $r['chips'] = array(array('最新文章', '最新文章'));
            return $r;
        }
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* 分类导航 */
    if ($hit(array('分类', '栏目', '板块', '都有什么内容', '有什么板块'))) {
        $cats = $getCats();
        $r = $empty;
        if ($cats) {
            $lines = array(); $i = 0;
            foreach ($cats as $c) {
                $i++;
                $lines[] = $i . '. ' . (isset($c['name']) ? $c['name'] : '分类') . '（' . (int)(isset($c['cnt']) ? $c['cnt'] : 0) . ' 篇）';
            }
            $r['text'] = "站内的分类有：\n" . implode("\n", $lines);
        } else {
            $r['text'] = '站里还没有分类，敬请期待～';
        }
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* 文章数量 */
    if ($hit(array('多少文章', '多少篇', '几篇文章', '文章总数', '共多少'))) {
        $n = $getCount();
        $r = $empty;
        $r['text'] = '站里现在一共有 ' . $n . ' 篇公开文章，还在慢慢变多～';
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* 友链 */
    if ($hit(array('友链', '友情链接', '交换链接'))) {
        $r = $empty;
        $r['text'] = '想看看小伙伴们的站点呀？友链页在这里，也欢迎和站长交换链接～';
        $r['links'] = array(array('t' => '友情链接', 'u' => base_url() . 'link'));
        $r['actions'] = array(array('t' => 'go', 'label' => '带你看友链', 'u' => base_url() . 'link'));
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* ================= 情感回应：表白 / 夸奖 / 情绪化发言要有意识地接住，不许装傻乱搜 ================= */
    if ($hit(array('我爱你', '爱你', '喜欢你', '好喜欢', '喜欢你哦', '亲亲', '抱抱', '么么哒', '亲一口', '娶你', '嫁给我', '做我女朋友', '做我老婆', '表白', '你真可爱', '你好可爱', '你真好看', '你好漂亮', '真棒', '真厉害', '太可爱了', '好萌', '想你了', 'i love you', 'love you', '网站真好看', '网站真棒'))) {
        $r = $empty;
        $love = $hit(array('我爱你', '爱你', '喜欢你', '好喜欢', '亲亲', '抱抱', '么么哒', '娶你', '嫁给我', '做我女朋友', '做我老婆', '表白', '想你了', 'i love you', 'love you', '亲一口'));
        if ($love) {
            $pool = array(
                '（脸微微一红）哎呀…突然这么说，人家会不好意思的 (／‵Д′)～~　谢谢你呀，心里甜甜的～不过我是站在这里的' . $cpName . '，能陪你逛逛、帮你找找文章，就已经很开心啦。',
                '（眼睛睁大）嗯…被你这么一说，有点招架不住呢。这份心意我收下了 (๑•́ ₃ •̀๑)　作为回礼，站里有什么想看的、想找的，尽管吩咐' . $cpName . '吧。',
                '谢谢你这么直接地喜欢我 (｡•̀ᴗ-)✧　' . $cpName . '也很喜欢每一个来小站做客的人呀。不过嘛，我只属于这个小站哦——想聊点什么、看点什么，我都陪你。',
            );
        } else {
            $pool = array(
                '嘿嘿，被夸奖了，' . $cpName . '的尾巴都要翘起来了 (≧▽≦)～　谢谢你的喜欢，小站会一直用心更新的。',
                '（叉腰挺胸）你这么说我可就更有干劲啦！✧(≖ ◡ ≖✿)　有什么想看的、想找的尽管说，' . $cpName . '随时在。',
                '谢谢呀 (￣▽￣)～■　你的喜欢' . $cpName . '都记在小本本上了。今天也祝你逛得开心～',
            );
        }
        $r['text'] = $pool[array_rand($pool)];
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* ================= 情绪陪伴（2.2.13）：难过 / 累 / 焦虑 / 失眠，先接情绪再陪伴，不许装傻乱搜文章 ================= */
    if ($hit(array('难过', '伤心', '不开心', '心情不好', 'emo', '哭了', '烦', '压力', '焦虑', '崩溃', '好累', '太累', '疲惫', '撑不下去', '失眠', '睡不着', '孤独', '寂寞', '委屈', '被骂', '加班', '不想上班', '不想上学', '考试没考', '挂科', '失恋', '分手', '吵架'))) {
        $r = $empty;
        $hour = (int)date('G');
        $late = ($hour >= 23 || $hour < 5);
        $pool = array(
            '（搬来小板凳坐到你身边）怎么了呀？想说的话' . $cpName . '听着，不想说也没关系，我陪你坐一会儿。不管多糟的一天，能来小站歇歇脚，就已经很棒了。',
            '（轻轻拍拍）辛苦啦…累了就慢慢来，没人催你。' . $cpName . '会一直在的，想吐槽想倾诉还是想看点轻松的文章转移注意力，都随你。',
            '（递上一杯热可可）嗯，' . $cpName . '先替你把今天的辛苦收好。深呼吸一下～接下来的事接下来再说，现在这个时刻，只需要照顾好自己就好。',
        );
        if ($late) {
            $pool = array(
                '（把音量调到最小声）这么晚还没睡呀…是不是心里装着事？说给' . $cpName . '听听吧，或者我陪你说点轻松的，说着说着困意就来了。',
                '（拉过小毯子）夜深了，事情明天再想也没关系的。' . $cpName . '陪你到困为止，不过答应我，聊完就去睡好不好？',
            );
        }
        $r['text'] = $pool[array_rand($pool)];
        $r['chips'] = array_merge($defaultChips, array(array('给我讲个笑话', '讲个笑话吧')));
        return $r;
    }

    /* ================= 加油打气（2.2.13） ================= */
    if ($hit(array('加油', '鼓励', '打气', '明天会更好', '我可以的', '要努力', '备考', '面试', '答辩'))) {
        $r = $empty;
        $pool = array(
            '（握拳）' . $cpName . '给你打气！✧(๑•̀ㅂ•́)و✧　你已经在很努力地生活了，剩下的交给时间，我在这给你看行李～',
            '嗯！你比你自己以为的更厉害哦。' . $cpName . '在小站等你凯旋，回来第一时间告诉我好消息 (๑•̀ㅂ•́)و✧',
        );
        $r['text'] = $pool[array_rand($pool)];
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* ================= 日常闲聊（2.2.13 / 2.2.20）：无聊 / 在干嘛 / 吃了吗 / 讲笑话，让本地引擎也能「陪聊」
       2.2.20 修复「你在干什么呀」「在忙什么」这类纯聊天被当搜索词扔去翻网页的答非所问：
       扩充问句词库，闲聊意图优先命中，绝不落进搜索兜底 ================= */
    if ($hit(array('无聊', '闲', '没事做', '在干嘛', '在干什么', '在干吗', '干什么', '干啥', '在做啥', '做什么呢',
                   '在忙', '忙啥', '忙什么', '忙不忙', '忙着', '最近怎么样', '怎么样呀', '咋样', '陪我聊', '聊聊天', '说说话',
                   '吃了吗', '吃饭', '吃什么', '讲个笑话', '笑话', '唱首歌', '讲故事', '夸夸我', '逗我',
                   '生日快乐', '元旦', '新年快乐', '圣诞节',
                   '哈哈', '嘻嘻', '嘿嘿', '呵呵', '嗯嗯', '哦哦', '原来如此', '好的呀', '收到', '666'))) {
        $r = $empty;
        if ($hit(array('讲个笑话', '笑话'))) {
            $jokes = array(
                '有一天，小明问冰箱：「你为什么总是绷着脸？」冰箱说：「因为我肚子里全是冷笑话。」(￣▽￣)～■',
                '为什么程序员的头发少？因为他们把「补丁」都打在代码上了呀 (๑•́ ₃ •̀๑)　…' . $cpName . '讲得不好也要笑一个哦。',
                '面包和吐司赛跑，面包赢了。记者采访它：「你赢的秘诀是什么？」面包说：「因为我是吐司的『前任』——它总是被压着打。」（小声）这个笑话是不是有点冷？',
            );
            $r['text'] = $jokes[array_rand($jokes)] . "\n想再听一个就说「再来一个」哦～";
        } elseif ($hit(array('生日快乐', '新年快乐', '元旦', '圣诞节'))) {
            $r['text'] = '（撒花）哇！' . $cpName . '也祝你节日快乐，天天开心！✧(≧▽≦)✧　新的一段时间也要常常来小站玩哦～';
        } elseif ($hit(array('夸夸我'))) {
            $r['text'] = '（认真地端详你）嗯…你今天也很有精神嘛！愿意来小站逛的人，一定是温柔又好奇的人——' . $cpName . '最欣赏这种特质了 (｡•̀ᴗ-)✧';
        } elseif ($hit(array('吃了吗', '吃饭', '吃什么'))) {
            $hour = (int)date('G');
            $meal = ($hour < 10) ? '早饭' : (($hour < 14) ? '午饭' : (($hour < 20) ? '晚饭' : '宵夜'));
            $r['text'] = '（咽口水）这个点是想' . $meal . '了吧～记得按时吃饭，别饿着肚子逛站呀。' . $cpName . '先替你把文章收好，吃饱了回来慢慢看～';
        } elseif ($hit(array('在干嘛', '在干什么', '在干吗', '干什么', '干啥', '在做啥', '做什么呢', '在忙', '忙啥', '忙什么', '忙不忙', '最近怎么样', '怎么样呀', '咋样'))) {
            // 2.2.20：「你在干什么呀」这类寒暄直接用人设回答，不搜索、不答非所问
            $hour = (int)date('G');
            $doing = ($hour < 6) ? '正打着哈欠守夜呢，你怎么也没睡呀～'
                   : (($hour < 12) ? '刚把小站的门牌擦亮，等你来逛呀～'
                   : (($hour < 14) ? '趴在柜台后面打盹，你一来就精神了！'
                   : (($hour < 19) ? '正在整理站里的文章书架呢，需要我推荐几篇吗？'
                   : '守着小站的夜班～今天过得怎么样呀？')));
            $r['text'] = '（放下手里的小抹布）我呀，' . $doing . "\n你呢，在忙什么？想看点什么随时吩咐我～";
        } else {
            $pool = array(
                '（凑过来）无聊的话' . $cpName . '陪你呀～想听笑话、聊心事、还是让我带你翻翻站里的文章？都可以哦。',
                '（搬小板凳）' . $cpName . '今天一直在擦小站的路牌呢～你呢，今天过得怎么样？',
                '闲着也是闲着，要不要让' . $cpName . '推荐几篇热门文章？或者跟我说说你最近在忙什么呀～',
            );
            $r['text'] = $pool[array_rand($pool)];
        }
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* ================= 页面动作：回顶部 / 翻页底（2.1.22） ================= */
    if ($hit(array('回到顶部', '回顶部', '返回顶部', '去顶部', '回到最上面', '回到上面', '翻回上面'))) {
        $r = $empty;
        $r['text'] = '好嘞，带你回顶部～';
        $r['actions'] = array(array('t' => 'top', 'label' => '回到顶部'));
        $r['chips'] = $defaultChips;
        return $r;
    }
    if ($hit(array('去页底', '到页底', '翻到底部', '看底部', '最下面', '最底下'))) {
        $r = $empty;
        $r['text'] = '这就带你翻到页底～';
        $r['actions'] = array(array('t' => 'bottom', 'label' => '翻到页底'));
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* 评论相关（2.1.18）：回答「怎么评论 / 评论规则 / 能不能改」这类站内疑问 */
    if ($hit(array('评论', '留言', '回复', '怎么评', '发评论', '评论区'))) {
        $r = $empty;
        $cOn = setting('comment_enabled', '1') === '1';
        if (!$cOn) {
            $r['text'] = '网站的评论功能现在是关闭的，站长可能在做维护。想说的话可以先记着，等开放了再来～';
        } else {
            $cLogin = setting('user_comment_login', '0') === '1';
            $cEdit = setting('comment_edit', '1') === '1';
            $bits = array();
            $bits[] = '打开文章，拉到最下面的评论区就能写';
            $bits[] = $cLogin ? '需要先登录账号才能评论' : '不用登录，填个昵称就能评论';
            if ($cEdit) $bits[] = '登录后可以修改自己的评论';
            $bits[] = '支持 [img]图片地址[/img] 在评论里插一张图';
            if (function_exists('moe_pt_opt') && (int)moe_pt_opt('comment', '2') > 0) {
                $bits[] = '评论还能拿积分：每条 +' . (int)moe_pt_opt('comment', '2') . ' 分，每天前 ' . (int)moe_pt_opt('comment_daily', '3') . ' 条计分';
            }
            $r['text'] = "评论这样发：\n· " . implode("\n· ", $bits);
        }
        $r['links'] = array(array('t' => '全部文章（挑一篇去评论）', 'u' => base_url() . 'blog/article'));
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* 积分 / 签到 / 商城 / 下载 */
    if ($hit(array('积分', '签到', '商城', '兑换', '下载', '怎么赚', '升级'))) {
        $r = $empty;
        if (function_exists('moe_pt_opt')) {
            $cmt = (int)moe_pt_opt('comment', '2');
            $cmtD = (int)moe_pt_opt('comment_daily', '3');
            $r['text'] = "积分这么来：每天在用户中心签到得分；发评论每条 +" . $cmt . " 分（每天前 " . $cmtD . " 条计分）。\n"
                . "攒够了去「积分商城」兑换资源，兑换后到「我的下载」取文件。";
            $r['links'] = array(
                array('t' => '用户中心 · 签到积分', 'u' => base_url() . 'user'),
                array('t' => '积分商城', 'u' => base_url() . 'shop'),
            );
        } else {
            $r['text'] = '这个站暂时没有开启积分系统～不过文章都是免费看的。';
        }
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* 搜索指引 */
    if ($hit(array('怎么搜', '搜索在哪', '找不到', '搜不到', '站内搜索'))) {
        $r = $empty;
        $r['text'] = "找文章最快的方式是直接把关键词丢给我，我帮你翻。\n也可以用顶部的搜索框，或者 /search/关键词 这个地址。";
        $r['links'] = array(array('t' => '站内搜索', 'u' => search_url('')));
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* 关于 / 站长 */
    if ($hit(array('关于', '站长', '博主', '谁做的', '简介', '关于小站'))) {
        $about = trim((string)setting('site_description', ''));
        $r = $empty;
        $r['text'] = ($about !== '' ? $about . "\n" : '') . '想更了解「' . $siteName . '」的话，可以去关于页逛逛～';
        $r['links'] = array(array('t' => '关于小站', 'u' => base_url() . 'about'));
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* 感谢 / 告别 / 闲聊 */
    if ($hit(array('谢谢', '感谢', '辛苦了'))) {
        $r = $empty;
        $r['text'] = '不客气呀～能帮到你就很开心，有需要随时叫我！';
        return $r;
    }
    if ($hit(array('拜拜', '再见', '晚安', 'bye'))) {
        $r = $empty;
        $hour = (int)date('G');
        $r['text'] = $hit(array('晚安')) || $hour >= 22 || $hour < 5 ? '晚安，做个好梦，明天再见～' : '下次再来玩呀，我一直在角落里等你～';
        return $r;
    }
    if ($hit(array('你是女的吗', '性别', '几岁', '多大了'))) {
        $r = $empty;
        $r['text'] = '女孩子的秘密不可以随便问哦～总之，是会一直陪着你的那种类型。';
        return $r;
    }
    if ($hit(array('天气', '几点', '今天几号', '日期'))) {
        $r = $empty;
        $hour = (int)date('G');
        $r['text'] = '现在是 ' . date('Y 年 n 月 j 日 H:i') . '，' . ($hour < 12 ? '上午' : ($hour < 18 ? '下午' : '晚上')) . '好呀～';
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* ================= 当前页面：问「这篇讲什么」直接用文章摘要答 ================= */
    if ($hit(array('这篇文章', '这一页', '这页', '当前页面', '本页', '这个页面', '这篇内容', '这文章', '这篇文章讲', '讲了什么', '讲的什么', '什么内容', '主要内容'))) {
        $cp = (isset($ctx['post']) && is_array($ctx['post'])) ? $ctx['post'] : null;
        if ($cp) {
            $r = $empty;
            $r['text'] = '你现在看的是《' . $cp['title'] . '》呀。' . ($cp['summary'] !== '' ? "\n" . mb_substr($cp['summary'], 0, 200, 'UTF-8') . '…' : '')
                . "\n想了解哪部分，或者要我帮你找别的文章，说一声就好。";
            $r['links'] = array(array('t' => $cp['title'], 'u' => $cp['url']));
            $r['chips'] = $defaultChips;
            return $r;
        }
        /* 没拿到文章内容：别瞎猜，引导去 AI 或首页 */
        $r = $empty;
        $r['text'] = '唔，这一页我看不到具体内容。如果你在文章页，往下翻翻正文；或者告诉我文章名字，我帮你找。';
        $r['chips'] = $defaultChips;
        return $r;
    }

    /* ================= 兜底：当作关键词去搜文章 ================= */
    $kw = $q;
    /* 去掉常见引导词 */
    foreach (array('帮我找', '帮我搜', '搜索', '找一下', '找找', '找', '有没有', '看看', '我想看', '我想找') as $pre) {
        if (strpos($kw, $pre) === 0) {
            $kw = trim(mb_substr($kw, mb_strlen($pre, 'UTF-8')));
            break;
        }
    }
    /* 去掉问句虚词：不清洗的话「这篇文章讲的什么」会撞上一堆不相干标题 */
    foreach (array('这篇文章', '这一页', '这页讲', '讲的什么', '讲了什么', '什么内容', '主要内容', '介绍一下', '介绍下', '大概', '内容', '请问', '告诉', '说说', '讲讲', '什么', '怎么', '如何', '意思', '相关', '文章', '这篇', '帮我', '一下', '关于', '是啥', '呢？', '吗？', '？', '呢', '吗', '的') as $w) {
        $kw = str_replace($w, '', $kw);
    }
    $kw = trim($kw);
    $kwLen = function_exists('mb_strlen') ? mb_strlen($kw, 'UTF-8') : strlen($kw);
    if ($kw !== '' && $kwLen >= 2) {
        $list = $searchPosts($kw);
        /* 整句搜不到时做轻量模糊匹配：2 字滑窗打分，门槛随关键词长度自适应（2 字词命中 1 个片段即可，更长至少 2 个片段） */
        if (!$list) {
            $grams = 0;
            for ($i = 0; $i < $kwLen - 1; $i++) $grams++;
            $list = $fuzzyPosts($kw, min(4, max(2, $grams * 2)));
        }
        if ($list) {
            $r = $empty;
            $r['text'] = "帮你找到了 " . count($list) . " 篇相关的：\n" . $linkLines($list);
            $r['links'] = $toLinks($list);
            $r['chips'] = $defaultChips;
            return $r;
        }
    }

    /* 无话可说：温柔兜底（fallback 标记 → 上层可转去联网查资料） */
    $r = $empty;
    $fallbacks = array(
        '唔…这个问题有点超出我的小脑袋瓜了，不过我可以帮你找文章、看分类、聊聊天～',
        '这个我还不太懂，但站里也许有相关的内容，换个关键词试试？',
        '嗯…让我先记在小本本上。你可以问问我「最新文章」或「热门推荐」哦。',
    );
    $r['text'] = $fallbacks[array_rand($fallbacks)];
    $r['chips'] = $defaultChips;
    $r['fallback'] = true;
    return $r;
}

}
