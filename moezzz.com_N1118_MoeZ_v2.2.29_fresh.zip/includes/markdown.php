<?php
/**
 * MoeZ - 轻量 Markdown 渲染器
 * 零第三方依赖，兼容 PHP 7.2+
 *
 * 支持：ATX / Setext 标题、段落、加粗、斜体、删除线、行内代码、围栏代码块、
 *      引用、有序 / 无序 / 嵌套 / 任务列表、表格（含对齐）、分割线、
 *      链接、图片、自动链接、原始 HTML 块
 */

class MoeMarkdown
{
    /** @var array 占位符 => 已生成的 HTML 片段 */
    private static $store = array();
    /** @var int 占位符自增序号 */
    private static $seq = 0;

    /** 渲染 Markdown 为 HTML */
    public static function parse($text)
    {
        self::$store = array();
        self::$seq = 0;

        $text = str_replace(array("\r\n", "\r"), "\n", (string)$text);
        $text = str_replace("\t", '    ', $text);
        $text = str_replace("\x01", '', $text);           // 清理占位符控制字符
        $text = preg_replace('/\n{4,}/', "\n\n\n", $text);

        // 2.1.7：@[login]…@[/login] / @[comment]…@[/comment]（登录可见 / 评论可见）
        $text = preg_replace_callback(
            '/^[ \t]*@\[(login|登录可见|comment|评论可见|回复可见)\][ \t]*\n(.*?)\n[ \t]*@\[\/\1\][ \t]*$/imsu',
            function ($m) {
                $type  = in_array($m[1], array('comment', '评论可见', '回复可见'), true) ? 'comment' : 'login';
                $inner = self::blocks(explode("\n", $m[2]));
                $shell = function_exists('moe_lock_shell') ? moe_lock_shell($type, $inner) : $inner;
                return "\n" . self::token($shell) . "\n";
            },
            $text
        );

        $html = self::blocks(explode("\n", $text));
        return strtr($html, self::$store);
    }

    /** 提取纯文本（用于摘要 / 字数统计） */
    public static function plain($text)
    {
        $text = str_replace(array("\r\n", "\r"), "\n", (string)$text);

        // 剔除围栏代码块内容（代码不该出现在摘要里）
        $keep = array();
        $inFence = false;
        foreach (explode("\n", $text) as $line) {
            if (preg_match('/^[ \t]*(`{3,}|~{3,})/', $line)) { $inFence = !$inFence; continue; }
            if (!$inFence) $keep[] = $line;
        }
        $text = implode("\n", $keep);

        $text = preg_replace('/^[ \t]*@\[(?:login|登录可见|comment|评论可见|回复可见)\][ \t]*\n.*?\n[ \t]*@\[\/(?:login|登录可见|comment|评论可见|回复可见)\][ \t]*\n?/imsu', '', $text); // 登录/评论可见块整体剔除
        $text = preg_replace('/@\[[^\]]*\]\([^)]*\)/u', '', $text);              // 视频语法
        $text = preg_replace('/!\[[^\]]*\]\(\s*[^)\s]*\.(?:m3u8|mp4|webm|ogg|ogv|mov)(?:\?[^)]*)?\s*\)/i', '', $text); // 视频图片语法
        $text = preg_replace('/!\[([^\]]*)\]\([^)]*\)/u', '$1', $text);        // 图片 -> alt
        $text = preg_replace('/\[([^\]]+)\]\([^)]*\)/u', '$1', $text);          // 链接 -> 文字
        $text = preg_replace('/^[ \t]*#{1,6}\s+/m', '', $text);                 // 标题
        $text = preg_replace('/^[ \t]*>\s?/m', '', $text);                      // 引用
        $text = preg_replace('/^[ \t]*\|?[\s:\-|]+\|[\s:\-|]*$/m', '', $text);  // 表格分隔行
        $text = preg_replace('/^[ \t]*([-*+]|\d{1,9}[.)])\s+\[[ xX]\]\s+/m', '', $text); // 任务列表标记
        $text = preg_replace('/^[ \t]*([-*+]|\d{1,9}[.)])\s+/m', '', $text);    // 列表
        $text = preg_replace('/^[ \t]*([-*_])(\s*\1){2,}\s*$/m', '', $text);    // 分割线
        $text = str_replace(array('**', '__', '~~', '`'), '', $text);
        $text = preg_replace('/(?<![\*\w])\*(?!\s)([^\*]+?)\*(?!\*)/u', '$1', $text);
        $text = str_replace('|', ' ', $text);
        $text = strip_tags($text);
        return trim(preg_replace('/\s+/u', ' ', $text));
    }

    /* ================= 块级解析 ================= */

    private static function blocks(array $lines)
    {
        $out = '';
        $n = count($lines);
        $i = 0;

        while ($i < $n) {
            $line = $lines[$i];

            if (trim($line) === '') { $i++; continue; }

            // 已生成的代码块占位符
            if (preg_match('/^\x01MOECODE(\d+)\x01$/', trim($line))) {
                $out .= trim($line) . "\n";
                $i++;
                continue;
            }

            // 围栏代码块
            if (preg_match('/^ {0,3}(`{3,}|~{3,})\s*([A-Za-z0-9#+._-]*)\s*$/', $line, $m)) {
                $fence = $m[1][0];
                $len   = strlen($m[1]);
                $lang  = $m[2];
                $buf   = array();
                $i++;
                while ($i < $n) {
                    if (preg_match('/^ {0,3}' . preg_quote($fence, '/') . '{' . $len . ',}\s*$/', $lines[$i])) {
                        $i++;
                        break;
                    }
                    $buf[] = $lines[$i];
                    $i++;
                }
                $code = htmlspecialchars(implode("\n", $buf), ENT_QUOTES, 'UTF-8');
                $cls  = $lang !== '' ? ' class="language-' . htmlspecialchars($lang, ENT_QUOTES, 'UTF-8') . '"' : '';
                $out .= self::token('<pre><code' . $cls . '>' . $code . '</code></pre>') . "\n";
                continue;
            }

            // ATX 标题
            if (preg_match('/^ {0,3}(#{1,6})\s+(.*)$/', $line, $m)) {
                $lv  = strlen($m[1]);
                $txt = preg_replace('/\s+#+\s*$/', '', trim($m[2]));
                $out .= '<h' . $lv . '>' . self::inline($txt) . '</h' . $lv . ">\n";
                $i++;
                continue;
            }

            // Setext 标题
            if ($i + 1 < $n && trim($line) !== ''
                && preg_match('/^ {0,3}(=+|-{2,})\s*$/', $lines[$i + 1], $m2)
                && !preg_match('/^ {0,3}([-*+]|\d{1,9}[.)])\s+/', $line)) {
                $lv = $m2[1][0] === '=' ? 1 : 2;
                $out .= '<h' . $lv . '>' . self::inline(trim($line)) . '</h' . $lv . ">\n";
                $i += 2;
                continue;
            }

            // 分割线
            if (preg_match('/^ {0,3}([-*_])(?:\s*\1){2,}\s*$/', $line)) {
                $out .= "<hr>\n";
                $i++;
                continue;
            }

            // 引用（支持 > **粗体** 与内部嵌套）
            if (preg_match('/^ {0,3}>/', $line)) {
                $buf = array();
                while ($i < $n && preg_match('/^ {0,3}>/', $lines[$i])) {
                    $buf[] = preg_replace('/^ {0,3}>\s?/', '', $lines[$i]);
                    $i++;
                    // 引用中的空行后续仍属于引用
                    if ($i < $n && trim($lines[$i]) === '' && isset($lines[$i + 1]) && preg_match('/^ {0,3}>/', $lines[$i + 1])) {
                        $buf[] = '';
                        $i++;
                    }
                }
                $out .= "<blockquote>\n" . self::blocks($buf) . "</blockquote>\n";
                continue;
            }

            // 表格
            if (strpos($line, '|') !== false && $i + 1 < $n
                && preg_match('/^ {0,3}\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/', $lines[$i + 1])) {
                $out .= self::table($lines, $i);
                continue;
            }

            // 2.1.6：正文内嵌下载卡片 @[download](资源ID) / @[dl](ID) / @[下载](ID)
            if (preg_match('/^ {0,3}@\[(?:download|dl|下载|资源)\]\(\s*(\d+)\s*\)\s*$/iu', $line, $m4)) {
                $gid  = (int)$m4[1];
                $card = function_exists('moe_pt_dl_card') ? moe_pt_dl_card($gid) : '';
                if ($card === '' && function_exists('moe_pt_dl_card_missing')) $card = moe_pt_dl_card_missing($gid);
                if ($card !== '') $out .= $card . "\n";
                $i++;
                continue;
            }

            // 列表
            if (preg_match('/^( {0,3})([-*+]|\d{1,9}[.)])\s+/', $line)) {
                $out .= self::listing($lines, $i);
                continue;
            }

            // 原始 HTML 块
            if (preg_match('/^ {0,3}<(\/?)([a-zA-Z][a-zA-Z0-9]*)/', $line, $m3)
                && in_array(strtolower($m3[2]), array('div', 'section', 'article', 'aside', 'details', 'summary',
                    'figure', 'table', 'thead', 'tbody', 'tr', 'td', 'th', 'ul', 'ol', 'li', 'dl', 'dt', 'dd',
                    'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'pre', 'blockquote', 'iframe', 'video', 'audio',
                    'hr', 'br', 'img', 'a', 'span', 'strong', 'em', 'center', 'script'), true)) {
                $buf = array();
                while ($i < $n && trim($lines[$i]) !== '') {
                    $buf[] = $lines[$i];
                    $i++;
                }
                $out .= implode("\n", $buf) . "\n";
                continue;
            }

            // 段落
            $buf = array();
            while ($i < $n && trim($lines[$i]) !== '') {
                // 段落中遇到新的块级起始则中断
                if (!empty($buf) && (
                    preg_match('/^ {0,3}(#{1,6}\s|>|`{3,}|~{3,})/', $lines[$i])
                    || preg_match('/^ {0,3}([-*+]|\d{1,9}[.)])\s+/', $lines[$i])
                    || preg_match('/^ {0,3}@\[(?:download|dl|下载|资源)\]\(\s*\d+\s*\)\s*$/iu', $lines[$i])
                    || preg_match('/^ {0,3}([-*_])(?:\s*\1){2,}\s*$/', $lines[$i])
                )) break;
                $buf[] = $lines[$i];
                $i++;
            }
            $out .= '<p>' . self::inline(implode("\n", $buf)) . "</p>\n";
        }

        return $out;
    }

    /** 表格 */
    private static function table(array $lines, &$i)
    {
        $head = self::row($lines[$i]);
        $sep  = self::row($lines[$i + 1]);
        $i += 2;

        $aligns = array();
        foreach ($sep as $cell) {
            $c = trim($cell);
            $left  = isset($c[0]) && $c[0] === ':';
            $right = substr($c, -1) === ':';
            $aligns[] = $left && $right ? 'center' : ($right ? 'right' : ($left ? 'left' : ''));
        }

        $html = "<table>\n<thead><tr>";
        foreach ($head as $k => $cell) {
            $al = isset($aligns[$k]) && $aligns[$k] !== '' ? ' style="text-align:' . $aligns[$k] . '"' : '';
            $html .= '<th' . $al . '>' . self::inline(trim($cell)) . '</th>';
        }
        $html .= "</tr></thead>\n<tbody>\n";

        $n = count($lines);
        while ($i < $n && trim($lines[$i]) !== '' && strpos($lines[$i], '|') !== false) {
            $row = self::row($lines[$i]);
            $html .= '<tr>';
            foreach ($head as $k => $cell) {
                $val = isset($row[$k]) ? trim($row[$k]) : '';
                $al  = isset($aligns[$k]) && $aligns[$k] !== '' ? ' style="text-align:' . $aligns[$k] . '"' : '';
                $html .= '<td' . $al . '>' . self::inline($val) . '</td>';
            }
            $html .= "</tr>\n";
            $i++;
        }
        return $html . "</tbody>\n</table>\n";
    }

    /** 拆分表格行 */
    private static function row($line)
    {
        $line = trim($line);
        $line = preg_replace('/^\|/', '', $line);
        $line = preg_replace('/\|$/', '', $line);
        return explode('|', $line);
    }

    /** 列表（含嵌套 / 任务列表） */
    private static function listing(array $lines, &$i)
    {
        $n = count($lines);
        preg_match('/^( *)([-*+]|\d{1,9}[.)])\s+/', $lines[$i], $m);
        $base    = strlen($m[1]);
        $ordered = (bool)preg_match('/\d/', $m[2]);
        $start   = $ordered ? (int)$m[2] : 1;

        $items = array();
        while ($i < $n && preg_match('/^( *)([-*+]|\d{1,9}[.)])\s+(.*)$/', $lines[$i], $mm)) {
            $indent = strlen($mm[1]);
            if ($indent !== $base) break;
            if ((bool)preg_match('/\d/', $mm[2]) !== $ordered) break;

            $content = array($mm[3]);
            $cut = $base + strlen($mm[2]) + 1;   // 该条目的正文起始列，用于剥离缩进
            $i++;
            $loose = false;
            while ($i < $n) {
                $l = $lines[$i];
                if (trim($l) === '') {
                    // 空行后若是同级新条目，则本条结束
                    $j = $i;
                    while ($j < $n && trim($lines[$j]) === '') $j++;
                    if ($j >= $n) { $i = $j; break; }
                    if (preg_match('/^( *)([-*+]|\d{1,9}[.)])\s+/', $lines[$j], $nn) && strlen($nn[1]) <= $base) break;
                    $content[] = '';
                    $loose = true;
                    $i++;
                    continue;
                }
                if (preg_match('/^( *)([-*+]|\d{1,9}[.)])\s+/', $l, $nn) && strlen($nn[1]) <= $base) break;
                if (preg_match('/^ {0,3}(#{1,6}\s|>|`{3,}|~{3,})/', $l)) break;
                $content[] = preg_replace('/^ {1,' . $cut . '}/', '', $l);
                $i++;
            }
            // 去掉条目末尾的空行，避免把紧凑列表误判为松散列表
            while (count($content) > 1 && end($content) === '') array_pop($content);
            $loose = in_array('', $content, true);
            $items[] = array('lines' => $content, 'loose' => $loose);
        }

        $tag = $ordered ? 'ol' : 'ul';
        $html = '<' . $tag . ($ordered && $start !== 1 ? ' start="' . $start . '"' : '') . ">\n";

        foreach ($items as $item) {
            $body = $item['lines'];
            $task = '';
            if (!$ordered && isset($body[0]) && preg_match('/^\[([ xX])\]\s+(.*)$/', $body[0], $tm)) {
                $task = '<input type="checkbox" disabled' . ($tm[1] !== ' ' ? ' checked' : '') . '> ';
                $body[0] = $tm[2];
            }
            $inner = self::blocks($body);
            // 紧凑列表去掉段落包裹
            if (!$item['loose']) {
                $inner = preg_replace('#^<p>(.*?)</p>\n?#s', '$1', $inner, 1);
            }
            $html .= '<li>' . $task . $inner . "</li>\n";
        }

        return $html . '</' . $tag . ">\n";
    }

    /* ================= 行内解析 ================= */

    private static function inline($text)
    {
        $hold = array();
        $put = function ($html) use (&$hold) {
            $hold[] = $html;
            return "\x01MOEHLD" . (count($hold) - 1) . "\x01";
        };

        // 1) 行内代码（最先保护，避免内部符号被解析）
        $text = preg_replace_callback('/(`+)([^`\n]+?)\1/', function ($m) use ($put) {
            return $put('<code>' . htmlspecialchars(trim($m[2]), ENT_QUOTES, 'UTF-8') . '</code>');
        }, $text);

        // 2) 视频语法：@[video](url) / @[m3u8](url) —— 任意文字均可
        $text = preg_replace_callback('/@\[([^\]]*)\]\(\s*([^)]*?)\s*\)/', function ($m) use ($put) {
            return $put(self::video_tag(self::norm_url($m[2]), $m[1]));
        }, $text);

        // 3) 图片（指向 mp4 / m3u8 等视频资源时自动转为播放器）
        $text = preg_replace_callback('/!\[([^\]]*)\]\(\s*([^)]*?)\s*\)/', function ($m) use ($put) {
            $src = $m[2];
            $ti  = '';
            // 尾部带 "标题" / '标题' 时拆分出来（URL 本身允许含空格）
            if (preg_match('/^(.*?)\s+([\'"])([^\'"]*)\2$/s', $src, $sm) && trim($sm[1]) !== '') {
                $src = $sm[1];
                $ti  = $sm[3];
            }
            $src = self::norm_url($src);
            if (preg_match('/\.(m3u8|mp4|webm|ogg|ogv|mov)(\?|#|$)/i', $src)) {
                return $put(self::video_tag($src, $m[1]));
            }
            $alt = htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8');
            $src = htmlspecialchars($src, ENT_QUOTES, 'UTF-8');
            $tit = $ti !== '' ? ' title="' . htmlspecialchars($ti, ENT_QUOTES, 'UTF-8') . '"' : '';
            return $put('<img src="' . $src . '" alt="' . $alt . '"' . $tit . ' loading="lazy">');
        }, $text);

        // 4) 链接
        $text = preg_replace_callback('/\[([^\]]+)\]\(\s*([^)]*?)\s*\)/', function ($m) use ($put) {
            $href = $m[2];
            $ti   = '';
            // 先拆尾部标题（URL 本身允许含空格），再做 URL 规范化
            if (preg_match('/^(.*?)\s+([\'"])([^\'"]*)\2$/s', $href, $sm) && trim($sm[1]) !== '') {
                $href = $sm[1];
                $ti   = $sm[3];
            }
            $href = htmlspecialchars(self::norm_url($href), ENT_QUOTES, 'UTF-8');
            $tit  = $ti !== '' ? ' title="' . htmlspecialchars($ti, ENT_QUOTES, 'UTF-8') . '"' : '';
            $ext  = preg_match('#^https?://#i', $href) ? ' target="_blank" rel="noopener"' : '';
            return $put('<a href="' . $href . '"' . $tit . $ext . '>' . self::inline($m[1]) . '</a>');
        }, $text);

        // 5) 自动链接 <https://...>
        $text = preg_replace_callback('#<((?:https?|mailto):[^>\s]+)>#i', function ($m) use ($put) {
            $u = htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8');
            return $put('<a href="' . $u . '" target="_blank" rel="nofollow noopener">' . $u . '</a>');
        }, $text);

        // 6) 裸链接
        $text = preg_replace_callback('#(?<![\w"\'=>])(https?://[^\s<>"\x01]+)#i', function ($m) use ($put) {
            $u = htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8');
            return $put('<a href="' . $u . '" target="_blank" rel="nofollow noopener">' . $u . '</a>');
        }, $text);

        // 7) 转义非标签的 < 与裸 &
        $text = preg_replace('/<(?![a-zA-Z\/!?])/', '&lt;', $text);
        $text = preg_replace('/&(?!#?\w+;)/', '&amp;', $text);

        // 8) 强调
        $text = preg_replace('/\*\*(?=\S)(.+?)(?<=\S)\*\*/s', '<strong>$1</strong>', $text);
        $text = preg_replace('/__(?=\S)(.+?)(?<=\S)__/s', '<strong>$1</strong>', $text);
        $text = preg_replace('/(?<![\*\w])\*(?=\S)(.+?)(?<=\S)\*(?!\*)/s', '<em>$1</em>', $text);
        $text = preg_replace('/(?<![\w_])_(?=\S)(.+?)(?<=\S)_(?!\w)/s', '<em>$1</em>', $text);
        $text = preg_replace('/~~(?=\S)(.+?)(?<=\S)~~/s', '<del>$1</del>', $text);

        // 9) 换行（单个换行即换行，更贴合中文随笔排版）
        $text = nl2br($text, false);

        // 10) 还原占位符
        foreach ($hold as $k => $html) {
            $text = str_replace("\x01MOEHLD{$k}\x01", $html, $text);
        }
        return $text;
    }

    /** 生成代码块占位符 */
    private static function token($html)
    {
        $id = self::$seq++;
        self::$store["\x01MOECODE{$id}\x01"] = $html;
        return "\x01MOECODE{$id}\x01";
    }

    /**
     * 视频标签：mp4 / webm 直接播放；m3u8 输出 HLS 播放器占位，
     * 页面渲染时由 moe_hls_script() 补挂 hls.js（Safari 走原生 HLS）
     */
    /** 规范化行内 URL：去首尾空白与尖括号，空格（含全角）转 %20，避免粘贴的地址带空格时图片/链接失效 */
    private static function norm_url($u)
    {
        $u = trim((string)$u);
        $u = preg_replace('/^<|>$/', '', $u);
        $u = str_replace(array('　', ' '), '%20', $u);
        return $u;
    }

    private static function video_tag($url, $label = '')
    {
        $src = htmlspecialchars(trim($url), ENT_QUOTES, 'UTF-8');
        $alt = htmlspecialchars(trim((string)$label), ENT_QUOTES, 'UTF-8');
        if (preg_match('/\.m3u8(\?|#|$)/i', $url)) {
            return '<video class="moe-video moe-hls" data-src="' . $src . '" data-alt="' . $alt . '"'
                 . ' controls preload="metadata" playsinline webkit-playsinline></video>';
        }
        return '<video class="moe-video" src="' . $src . '" data-alt="' . $alt . '"'
             . ' controls preload="metadata" playsinline webkit-playsinline></video>';
    }
}

/* ================= 对外辅助函数 ================= */

/** Markdown 转 HTML */
function markdown($text)
{
    return MoeMarkdown::parse($text);
}

/**
 * 2.1.7：判断当前读者是否满足可见条件（login=已登录；comment=已评论）
 */
function moe_lock_allowed($type)
{
    $u = function_exists('current_user') ? current_user() : null;
    if (!$u) return false;
    if ($type !== 'comment') return true;
    // 评论可见：本篇文章下有该会员的评论（拿不到文章 ID 时放宽为发过任意评论）
    $pid = isset($GLOBALS['moe_render_post_id']) ? (int)$GLOBALS['moe_render_post_id'] : 0;
    try {
        if ($pid > 0) {
            $r = row('SELECT COUNT(*) AS c FROM ' . moe_table('comments') . ' WHERE post_id = ? AND user_id = ? LIMIT 1',
                array($pid, (int)$u['id']));
        } else {
            $r = row('SELECT COUNT(*) AS c FROM ' . moe_table('comments') . ' WHERE user_id = ? LIMIT 1',
                array((int)$u['id']));
        }
        return !empty($r['c']);
    } catch (Throwable $e) {
        return false;
    }
}

/** 2.1.7：可见性外壳 —— 满足条件输出原内容，否则输出提示框 */
function moe_lock_shell($type, $inner)
{
    $inner = (string)$inner;
    if (function_exists('moe_lock_allowed') && moe_lock_allowed($type)) return $inner;
    $uc = base_url() . 'user';
    if ($type === 'comment') {
        $msg = '💬 <b>评论后可见</b>：这部分内容需要在本文下发表评论后才能查看。';
        if (!function_exists('current_user') || !current_user()) {
            $msg .= ' <a href="' . e($uc . '?a=login&back=' . urlencode(isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/')) . '">先登录</a>';
        } else {
            $msg .= ' 在本文下方发表一条评论即可查看～';
        }
    } else {
        $msg = '🔒 <b>登录可见</b>：这部分内容仅登录用户可见。<a href="' . e($uc . '?a=login') . '">去登录</a>'
             . ' <a href="' . e($uc . '?a=register') . '">注册</a>';
    }
    return '<div class="moe-lock-box" style="margin:18px 0;padding:14px 18px;border:1.5px dashed #d8c8ec;'
        . 'border-radius:12px;background:#fbf8ff;color:#6b5c88;font-size:13.5px;line-height:1.9">' . $msg . '</div>';
}

/**
 * 按内容格式渲染正文
 * @param string $content 正文
 * @param string $format  markdown | html
 */
function render_content($content, $format = 'markdown')
{
    $format = strtolower((string)$format);
    if ($format === 'html') {
        $html = (string)$content;
        if (strpos($html, '@[') !== false) {
            $html = preg_replace_callback(
                '/@\[(login|登录可见|comment|评论可见|回复可见)\]\s*(.*?)\s*@\[\/\1\]/isu',
                function ($m) {
                    $type = in_array($m[1], array('comment', '评论可见', '回复可见'), true) ? 'comment' : 'login';
                    return function_exists('moe_lock_shell') ? moe_lock_shell($type, $m[2]) : $m[2];
                },
                $html
            );
        }
        return $html;
    }
    $html = MoeMarkdown::parse($content);
    // 正文标题整体降一级，避免与页面 H1（文章标题）冲突
    $html = preg_replace_callback('/<h([1-5])([^>]*)>(.*?)<\/h\1>/s', function ($m) {
        $lv = (int)$m[1] + 1;
        return '<h' . $lv . $m[2] . '>' . $m[3] . '</h' . $lv . '>';
    }, $html);
    // m3u8：追加 hls.js 挂载脚本（每个页面只挂一次）
    if (strpos($html, 'moe-hls') !== false) {
        $html .= moe_hls_script();
    }
    return $html;
}

/** m3u8 播放器脚本：Safari 原生 HLS，其余浏览器懒加载 hls.js */
function moe_hls_script()
{
    return <<<'HTML'
<script>
(function () {
  var vids = [].slice.call(document.querySelectorAll('video.moe-hls:not([data-ready])'));
  if (!vids.length) return;
  vids.forEach(function (v) { v.setAttribute('data-ready', '1'); });

  function fail() {
    vids.forEach(function (v) {
      if (v.dataset.fail) return;
      v.dataset.fail = '1';
      var a = document.createElement('a');
      a.href = v.getAttribute('data-src');
      a.target = '_blank';
      a.rel = 'noopener';
      a.textContent = '无法播放该 m3u8 视频，点此在新窗口打开 ▶';
      a.style.cssText = 'display:inline-block;padding:10px 14px;border-radius:10px;background:rgba(255,255,255,.08);color:inherit;text-decoration:none;font-size:14px';
      v.parentNode.replaceChild(a, v);
    });
  }

  // Safari / iOS：原生支持 HLS
  if (document.createElement('video').canPlayType('application/vnd.apple.mpegurl')) {
    vids.forEach(function (v) { v.src = v.getAttribute('data-src'); });
    return;
  }

  var s = document.createElement('script');
  s.src = 'https://cdn.jsdelivr.net/npm/hls.js@1/dist/hls.min.js';
  s.onload = function () {
    if (!window.Hls || !Hls.isSupported()) { fail(); return; }
    vids.forEach(function (v) {
      try {
        var hls = new Hls();
        hls.loadSource(v.getAttribute('data-src'));
        hls.attachMedia(v);
      } catch (e) { fail(); }
    });
  };
  s.onerror = fail;
  document.head.appendChild(s);
})();
</script>
HTML;
}

/** 正文纯文本（摘要 / 字数统计） */
function content_plain($content, $format = 'markdown')
{
    $format = strtolower((string)$format);
    if ($format === 'html') {
        return trim(preg_replace('/\s+/u', ' ', strip_tags((string)$content)));
    }
    return MoeMarkdown::plain($content);
}

/** 中英文混排字数统计 */
function content_words($content, $format = 'markdown')
{
    $t = content_plain($content, $format);
    $cjk = preg_match_all('/[\x{4e00}-\x{9fff}\x{3040}-\x{30ff}]/u', $t, $m);
    $latin = preg_match_all('/[A-Za-z0-9]+/', $t, $m2);
    return (int)$cjk + (int)$latin;
}
