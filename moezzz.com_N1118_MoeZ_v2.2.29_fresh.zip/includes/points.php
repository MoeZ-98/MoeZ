<?php
/**
 * MoeZ 2.1.0 · 积分 / 签到 / 积分商城 / 下载（核心模块）
 * ------------------------------------------------------------------
 * 为什么放进核心而不是模板：
 *   前台 /user（用户中心）由 includes/user.php 直接渲染，不经过任何模板，
 *   模板里的 user.php 永远拿不到路由 —— 所以积分、签到、商城、下载
 *   必须在核心里实现，任何模板都能用。
 *
 * 数据表（首次访问自动创建，表名带程序前缀，默认 moe_）：
 *   pt_points   积分余额（每人一行）
 *   pt_log      积分流水
 *   pt_sign     签到记录（每人每天一条，带连签天数）
 *   pt_goods    商城商品（积分兑换的下载资源）
 *   pt_orders   兑换订单（每人每件一条，兑换一次永久可下）
 *   pt_downloads 下载记录
 *
 * 约定：时间全部由 PHP 生成字符串写入，不依赖 MySQL 专有函数；
 *       扣分用「余额 >= 扣减额」的原子 UPDATE，避免并发兑换把余额扣成负数。
 */

if (!defined('MOE_PT_LOADED')) define('MOE_PT_LOADED', true);

/* ============================================================
   一、设置项
   ============================================================ */

/** 读取积分相关设置（带默认值） */
function moe_pt_opt($key, $default = '')
{
    $map = array(
        'name'          => array('points_name', '积分'),
        'sign_base'     => array('points_sign_base', '5'),
        'sign_bonus'    => array('points_sign_bonus', '2'),
        'sign_maxdays'  => array('points_sign_maxdays', '6'),
        'comment'       => array('points_comment', '2'),
        'comment_daily' => array('points_comment_daily', '3'),
        'enabled'       => array('points_enabled', '1'),
        'shop'          => array('points_shop_enabled', '1'),
        // 2.2.12 修复：后台「积分规则」保存互兑比例后，重新打开页面输入框回显为 0
        //（moe_pt_opt 映射表漏了这两个键，导致读不到已保存的值；兑换逻辑本身走 setting() 不受影响）
        'ex_p2c'        => array('points_ex_p2c', '0'),
        'ex_c2p'        => array('points_ex_c2p', '0'),
    );
    if (isset($map[$key])) {
        $v = setting($map[$key][0], $map[$key][1]);
        return $v === '' ? $map[$key][1] : $v;
    }
    return $default;
}

/** 积分名称（前台所有位置统一使用） */
/** 2.1.7：积分 / 价格统一按两位小数处理；显示时去掉多余的 0（10.00→10、0.50→0.5） */
function moe_pt_num($v)
{
    $s = number_format(round((float)$v, 2), 2, '.', '');
    return rtrim(rtrim($s, '0'), '.');
}

/** 读取资源的展示价格（非负、两位小数；2.2.7 起负数 = 不支持萌豆兑换，返回 null） */
function moe_pt_price_of($g)
{
    $p = (float)($g['price'] ?? 0);
    return $p < 0 ? null : round($p, 2);
}

/** 2.2.5：读取资源的金币价（0 = 未单独定价，双币时回落到积分价、仅金币时 0 = 免费；负数 = 不支持金币兑换，返回 null） */
function moe_pt_coins_price_of($g)
{
    $c = (float)($g['price_coins'] ?? 0);
    if ($c < 0) return null;
    if ($c > 0) return round($c, 2);
    $p = moe_pt_price_of($g);
    return $p !== null ? $p : 0;
}

/** 2.2.7：定价方式三选一 —— 仅萌豆（coins=-1）/ 仅金币（price=-1）/ 双币同售（两者都 ≥ 0） */
function moe_pt_price_mode_of($g)
{
    $p = (float)($g['price'] ?? 0);
    $c = (float)($g['price_coins'] ?? 0);
    if ($c < 0 && $p >= 0) return 'points';   // 仅萌豆
    if ($p < 0 && $c >= 0) return 'coins';    // 仅金币
    return 'both';                            // 双币同售
}

/** 2.2.7：资源的价格展示文案（兼容三种定价方式） */
function moe_pt_price_label_of($g)
{
    $unit = moe_pt_name();
    $cn = moe_pt_coin_name();
    $p = moe_pt_price_of($g);
    $c = moe_pt_coins_price_of($g);
    if ($p !== null && $c !== null) {
        return ($p > 0 ? moe_pt_num($p) . ' ' . $unit : '免费')
            . ($p > 0 && $c > 0 ? ' / ' . moe_pt_num($c) . ' ' . $cn : '');
    }
    if ($c !== null) return moe_pt_num($c) . ' ' . $cn;
    if ($p !== null) return ($p > 0 ? moe_pt_num($p) . ' ' . $unit : '免费');
    return '免费';
}

/** 2.2.5：关联文章的链接（无关联 / 文章已删除时返回空串） */
function moe_pt_post_url_of($postId)
{
    $postId = (int)$postId;
    if ($postId <= 0) return '';
    try {
        $p = row('SELECT * FROM ' . moe_table('posts') . " WHERE id = ? AND type='post' LIMIT 1", array($postId));
        return $p ? post_url($p) : '';
    } catch (Throwable $e) {
        return '';
    }
}

function moe_pt_name()
{
    $n = trim((string)moe_pt_opt('name'));
    return $n !== '' ? $n : '积分';
}

/** 2.2.10：金币自定义名称（后台「积分规则」可改，默认「金币」） */
function moe_pt_coin_name()
{
    $n = trim((string)setting('coin_name', ''));
    return $n !== '' ? $n : '金币';
}

/** 2.2.10：积分 ⇄ 金币互兑处理（用户中心与 /shop 独立页共用）
 *  @return array [bool ok, string msg] */
function moe_pt_exchange_run($act, $uid)
{
    if (!function_exists('moe_pt_add')) return array(false, '积分模块未加载');
    $name = moe_pt_name();
    $cn   = moe_pt_coin_name();
    $n    = round((float)($_POST['coins'] ?? 0), 2);

    if ($act === 'ex_p2c') {
        // 比例 points_ex_p2c：多少积分 = 1 金币，0 = 关闭
        $rate = round(max(0, (float)setting('points_ex_p2c', '0')), 2);
        if ($rate <= 0)            return array(false, '站长没有开启' . $name . '兑' . $cn);
        if ($n <= 0 || $n > 99999) return array(false, '请输入有效的兑换数量');
        $cost = round($n * $rate, 2);
        $ded  = moe_pt_add((int)$uid, -$cost, 'exchange', '兑换' . $cn . '（' . moe_pt_num($n) . ' 个）', 'points');
        if (empty($ded['ok'])) {
            return array(false, '兑换失败：' . $name . '余额不足（本次需要 ' . moe_pt_num($cost) . '，当前 ' . moe_pt_num($ded['balance']) . '）');
        }
        $add = moe_pt_add((int)$uid, $n, 'exchange', $name . '兑' . $cn . '入账', 'coins');
        return !empty($add['ok'])
            ? array(true, '兑换成功 ✅ ' . moe_pt_num($cost) . ' ' . $name . ' → ' . moe_pt_num($n) . ' ' . $cn)
            : array(false, '扣款成功但入账异常，请联系站长处理');
    }

    if ($act === 'ex_c2p') {
        // 比例 points_ex_c2p：1 金币 = 多少积分，0 = 关闭
        $rate = round(max(0, (float)setting('points_ex_c2p', '0')), 2);
        if ($rate <= 0)            return array(false, '站长没有开启' . $cn . '兑' . $name);
        if ($n <= 0 || $n > 99999) return array(false, '请输入有效的兑换数量');
        $gain = round($n * $rate, 2);
        $ded  = moe_pt_add((int)$uid, -$n, 'exchange', '兑换' . $name . '（' . moe_pt_num($n) . ' 个' . $cn . '）', 'coins');
        if (empty($ded['ok'])) {
            return array(false, '兑换失败：' . $cn . '余额不足（本次需要 ' . moe_pt_num($n) . '，当前 ' . moe_pt_num($ded['balance']) . '）');
        }
        $add = moe_pt_add((int)$uid, $gain, 'exchange', $cn . '兑' . $name . '入账', 'points');
        return !empty($add['ok'])
            ? array(true, '兑换成功 ✅ ' . moe_pt_num($n) . ' ' . $cn . ' → ' . moe_pt_num($gain) . ' ' . $name)
            : array(false, '扣款成功但入账异常，请联系站长处理');
    }

    return array(false, '未知操作');
}

/** 2.2.10：积分 ⇄ 金币互兑卡片（商城页顶部，双向比例任一开启才显示） */
function moe_pt_exchange_card($u)
{
    if (!$u || !function_exists('moe_pt_add')) return '';
    $name = moe_pt_name();
    $cn   = moe_pt_coin_name();
    $p2c  = round(max(0, (float)setting('points_ex_p2c', '0')), 2);
    $c2p  = round(max(0, (float)setting('points_ex_c2p', '0')), 2);
    if ($p2c <= 0 && $c2p <= 0) return '';

    $bal  = moe_pt_balance((int)$u['id']);
    $coin = moe_pt_coins((int)$u['id']);
    $h = '<div class="card" style="box-shadow:none"><h2>🔄 ' . e($name) . ' ⇄ ' . e($cn) . ' 互兑</h2>'
        . '<p class="hint" style="margin:0 0 12px">当前余额：<b>' . moe_pt_num($bal) . ' ' . e($name) . '</b> · <b>' . moe_pt_num($coin) . ' ' . e($cn) . '</b></p>'
        . '<div style="display:flex;gap:16px;flex-wrap:wrap">';
    if ($p2c > 0) {
        $h .= '<form method="post" style="flex:1;min-width:230px;padding:14px;border:1px dashed #d9c9ee;border-radius:12px">'
            . csrf_field() . '<input type="hidden" name="act" value="ex_p2c">'
            . '<div style="font-weight:700;margin-bottom:8px">' . e($name) . ' → ' . e($cn) . '</div>'
            . '<p class="hint" style="margin:0 0 10px">比例：' . moe_pt_num($p2c) . ' ' . e($name) . ' = 1 ' . e($cn) . '</p>'
            . '<div class="field"><label>兑换多少' . e($cn) . '</label>'
            . '<input type="number" name="coins" min="0.01" step="0.01" required placeholder="如 10"></div>'
            . '<button class="btn sm" type="submit">立即兑换（需 ' . e($p2c) . ' ' . e($name) . '/个）</button></form>';
    }
    if ($c2p > 0) {
        $h .= '<form method="post" style="flex:1;min-width:230px;padding:14px;border:1px dashed #c9d9ee;border-radius:12px">'
            . csrf_field() . '<input type="hidden" name="act" value="ex_c2p">'
            . '<div style="font-weight:700;margin-bottom:8px">' . e($cn) . ' → ' . e($name) . '</div>'
            . '<p class="hint" style="margin:0 0 10px">比例：1 ' . e($cn) . ' = ' . moe_pt_num($c2p) . ' ' . e($name) . '</p>'
            . '<div class="field"><label>兑换多少' . e($cn) . '</label>'
            . '<input type="number" name="coins" min="0.01" step="0.01" required placeholder="如 5"></div>'
            . '<button class="btn sm" type="submit">立即兑换（' . e($c2p) . ' ' . e($name) . '/个）</button></form>';
    }
    $h .= '</div></div>';
    return $h;
}

/** 积分功能总开关 */
function moe_pt_on()
{
    return (string)moe_pt_opt('enabled', '1') === '1';
}

/** 商城是否开放 */
function moe_pt_shop_on()
{
    return moe_pt_on() && (string)moe_pt_opt('shop', '1') === '1';
}

/* ============================================================
   二、建表 / 初始化
   ============================================================ */

function moe_pt_table($name)
{
    return moe_table('pt_' . $name);
}

/** 表是否存在（直接探测，不依赖 information_schema，兼容性更好） */
function moe_pt_table_exists($name)
{
    try {
        one('SELECT 1 FROM ' . moe_pt_table($name) . ' LIMIT 1');
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * 确保积分数据表就绪（只在第一次真正建表，之后读设置项即返回）
 * @return bool 表是否可用
 */
function moe_pt_ready($force = false)
{
    static $ready = null;
    if ($force) $ready = null;
    if ($ready !== null) return $ready;

    // 2.1.7：老表一次性升级 —— 积分 / 价格支持两位小数，资源表加「下载密码」列
    if ((string)setting('pt_schema_217', '') !== '1') {
        try {
            $p = moe_table('');
            $goodsT = $p . 'pt_goods';
            $cols = array();
            foreach (rows('SHOW COLUMNS FROM ' . $goodsT) as $c) {
                $cols[(string)($c['Field'] ?? '')] = true;
            }
            if (!isset($cols['download_pwd'])) {
                q('ALTER TABLE ' . $goodsT . " ADD download_pwd VARCHAR(64) NOT NULL DEFAULT '' AFTER download_url");
            }
            q('ALTER TABLE ' . $goodsT . ' MODIFY price DECIMAL(10,2) NOT NULL DEFAULT 0');
            q('ALTER TABLE ' . $p . 'pt_points'
                . ' MODIFY balance DECIMAL(10,2) NOT NULL DEFAULT 0'
                . ', MODIFY earned DECIMAL(10,2) NOT NULL DEFAULT 0'
                . ', MODIFY spent DECIMAL(10,2) NOT NULL DEFAULT 0');
            q('ALTER TABLE ' . $p . 'pt_log MODIFY amount DECIMAL(10,2) NOT NULL DEFAULT 0');
            q('ALTER TABLE ' . $p . 'pt_orders MODIFY price DECIMAL(10,2) NOT NULL DEFAULT 0');
            setting_set('pt_schema_217', '1');
        } catch (Throwable $e) {
            /* 权限不足 / SQLite 等环境：忽略，下次请求再试 */
        }
    }

    // 2.2.2：老表一次性升级 —— 资源加「分类」列，积分加「金币」余额列，订单加「币种」列
    if ((string)setting('pt_schema_222', '') !== '1') {
        try {
            $p = moe_table('');
            foreach (array('pt_goods', 'pt_points', 'pt_orders') as $tName) {
                $cols = array();
                foreach (rows('SHOW COLUMNS FROM ' . $p . $tName) as $c) {
                    $cols[(string)($c['Field'] ?? '')] = true;
                }
                if ($tName === 'pt_goods' && !isset($cols['cat'])) {
                    q('ALTER TABLE ' . $p . $tName . " ADD cat VARCHAR(30) NOT NULL DEFAULT '' AFTER summary");
                }
                if ($tName === 'pt_points' && !isset($cols['coins'])) {
                    q('ALTER TABLE ' . $p . $tName . ' ADD coins DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER balance');
                }
                if ($tName === 'pt_orders' && !isset($cols['currency'])) {
                    q('ALTER TABLE ' . $p . $tName . " ADD currency VARCHAR(10) NOT NULL DEFAULT 'points' AFTER price");
                }
            }
            setting_set('pt_schema_222', '1');
        } catch (Throwable $e) {
            /* 权限不足 / SQLite 等环境：忽略，下次请求再试 */
        }
    }

    // 2.2.5：老表一次性升级 —— 资源加「金币价」与「关联文章」列（双货币定价 / 商城卡片跳文章）
    if ((string)setting('pt_schema_224', '') !== '1') {
        try {
            $p = moe_table('');
            $cols = array();
            foreach (rows('SHOW COLUMNS FROM ' . $p . 'pt_goods') as $c) {
                $cols[(string)($c['Field'] ?? '')] = true;
            }
            if (!isset($cols['price_coins'])) {
                q('ALTER TABLE ' . $p . 'pt_goods ADD price_coins DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER price');
            }
            if (!isset($cols['post_id'])) {
                q('ALTER TABLE ' . $p . 'pt_goods ADD post_id INT UNSIGNED NOT NULL DEFAULT 0 AFTER cat');
            }
            setting_set('pt_schema_224', '1');
        } catch (Throwable $e) {
            /* 权限不足 / SQLite 等环境：忽略，下次请求再试 */
        }
    }

    if ((string)setting('points_ready', '') === '1') return $ready = true;
    // 建表失败后 10 分钟内不再重试，避免每次访问都跑 6 条 DDL 拖慢页面
    $failAt = (int)setting('points_ready_fail', '0');
    if ($failAt > 0 && time() - $failAt < 600) return $ready = false;

    $charset = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4';
    $p = moe_table('');
    $ddl = array(
        'CREATE TABLE IF NOT EXISTS ' . $p . 'pt_points (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            balance DECIMAL(10,2) NOT NULL DEFAULT 0,
            coins DECIMAL(10,2) NOT NULL DEFAULT 0,
            earned DECIMAL(10,2) NOT NULL DEFAULT 0,
            spent DECIMAL(10,2) NOT NULL DEFAULT 0,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_user (user_id)
        ) ' . $charset,
        'CREATE TABLE IF NOT EXISTS ' . $p . 'pt_log (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            type VARCHAR(16) NOT NULL DEFAULT \'\',
            amount DECIMAL(10,2) NOT NULL DEFAULT 0,
            note VARCHAR(160) NOT NULL DEFAULT \'\',
            created_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY user_time (user_id, created_at)
        ) ' . $charset,
        'CREATE TABLE IF NOT EXISTS ' . $p . 'pt_sign (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            sign_date DATE NOT NULL,
            points INT NOT NULL DEFAULT 0,
            streak INT NOT NULL DEFAULT 1,
            created_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_user_day (user_id, sign_date)
        ) ' . $charset,
        'CREATE TABLE IF NOT EXISTS ' . $p . 'pt_goods (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            title VARCHAR(120) NOT NULL,
            summary VARCHAR(255) NOT NULL DEFAULT \'\',
            cat VARCHAR(30) NOT NULL DEFAULT \'\',
            post_id INT UNSIGNED NOT NULL DEFAULT 0,
            cover VARCHAR(255) NOT NULL DEFAULT \'\',
            price DECIMAL(10,2) NOT NULL DEFAULT 0,
            price_coins DECIMAL(10,2) NOT NULL DEFAULT 0,
            download_url TEXT,
            download_pwd VARCHAR(64) NOT NULL DEFAULT \'\',
            downloads INT NOT NULL DEFAULT 0,
            status VARCHAR(10) NOT NULL DEFAULT \'on\',
            sort INT NOT NULL DEFAULT 0,
            created_at DATETIME NULL,
            updated_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY status_sort (status, sort)
        ) ' . $charset,
        'CREATE TABLE IF NOT EXISTS ' . $p . 'pt_orders (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            goods_id INT UNSIGNED NOT NULL,
            price DECIMAL(10,2) NOT NULL DEFAULT 0,
            status VARCHAR(10) NOT NULL DEFAULT \'paid\',
            created_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_user_goods (user_id, goods_id)
        ) ' . $charset,
        'CREATE TABLE IF NOT EXISTS ' . $p . 'pt_downloads (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            goods_id INT UNSIGNED NOT NULL,
            created_at DATETIME NULL,
            PRIMARY KEY (id),
            KEY user_goods (user_id, goods_id)
        ) ' . $charset,
    );

    try {
        foreach ($ddl as $sql) q($sql);
    } catch (Throwable $e) {
        // 建表失败（没给 CREATE 权限 / 库不可写）：不写就绪标记，10 分钟后重试
        try { setting_set('points_ready_fail', (string)time()); } catch (Throwable $e2) { /* 忽略 */ }
        return $ready = false;
    }

    // 2.2.5：旧表补列（列已存在时的报错属正常，直接吞掉）
    try { q('ALTER TABLE ' . $p . 'pt_goods ADD COLUMN price_coins DECIMAL(10,2) NOT NULL DEFAULT 0'); } catch (Throwable $e) { /* 已存在 */ }
    try { q('ALTER TABLE ' . $p . 'pt_goods ADD COLUMN post_id INT UNSIGNED NOT NULL DEFAULT 0'); } catch (Throwable $e) { /* 已存在 */ }
    try { q('ALTER TABLE ' . $p . "pt_goods ADD COLUMN cat VARCHAR(30) NOT NULL DEFAULT ''"); } catch (Throwable $e) { /* 已存在 */ }
    try { q('ALTER TABLE ' . $p . 'pt_points ADD COLUMN coins DECIMAL(10,2) NOT NULL DEFAULT 0'); } catch (Throwable $e) { /* 已存在 */ }
    try { q('ALTER TABLE ' . $p . "pt_orders ADD COLUMN currency VARCHAR(10) NOT NULL DEFAULT 'points'"); } catch (Throwable $e) { /* 已存在 */ }

    moe_pt_seed_settings();
    moe_pt_migrate_legacy();
    try { setting_set('points_ready', '1'); } catch (Throwable $e) { /* 忽略 */ }
    // 沿用主题时代的开关标记，主题里判断「积分表就绪」的地方继续可用
    try {
        if ((string)setting('themeopt_fomalhaut_shop_ready', '') !== '1') {
            setting_set('themeopt_fomalhaut_shop_ready', '1');
        }
    } catch (Throwable $e) { /* 忽略 */ }
    return $ready = true;
}

/** 首次启用时，把主题里已经配过的数值带进核心设置，站长不用重新填一遍 */
function moe_pt_seed_settings()
{
    if ((string)setting('points_seed', '') === '1') return;
    $inherit = array(
        'points_name'         => 'themeopt_fomalhaut_points_name',
        'points_sign_base'    => 'themeopt_fomalhaut_sign_points',
        'points_sign_bonus'   => 'themeopt_fomalhaut_sign_streak_bonus',
        'points_comment'      => 'themeopt_fomalhaut_comment_points',
        'points_comment_daily' => 'themeopt_fomalhaut_comment_daily_limit',
    );
    foreach ($inherit as $core => $themeKey) {
        try {
            $old = trim((string)setting($themeKey, ''));
            if ($old !== '' && trim((string)setting($core, '')) === '') setting_set($core, $old);
        } catch (Throwable $e) { /* 忽略 */ }
    }
    try { setting_set('points_seed', '1'); } catch (Throwable $e) { /* 忽略 */ }
}

/**
 * 兼容迁移：老版本把积分存在主题表 moe_fo_* 里，这里一次性搬到 moe_pt_*
 * （只在新表为空时搬，重复执行不会翻倍）
 */
function moe_pt_migrate_legacy()
{
    if ((string)setting('points_migrated', '') === '1') return;
    $pairs = array(
        'points'    => array('user_id', 'balance', 'earned', 'spent', 'updated_at'),
        'points_log' => array('user_id', 'type', 'amount', 'note', 'created_at'),
        'signin'    => array('user_id', 'sign_date', 'points', 'streak', 'created_at'),
        'goods'     => array('title', 'summary', 'cover', 'price', 'download_url', 'downloads', 'status', 'sort', 'created_at', 'updated_at'),
        'orders'    => array('user_id', 'goods_id', 'price', 'status', 'created_at'),
        'downloads' => array('user_id', 'goods_id', 'created_at'),
    );
    $newOf = array('points' => 'points', 'points_log' => 'log', 'signin' => 'sign',
                   'goods' => 'goods', 'orders' => 'orders', 'downloads' => 'downloads');
    try {
        foreach ($pairs as $legacy => $cols) {
            $oldTable = moe_table('fo_' . $legacy);
            $newTable = moe_pt_table($newOf[$legacy]);
            try {
                one('SELECT 1 FROM ' . $oldTable . ' LIMIT 1');
            } catch (Throwable $e) {
                continue;   // 老表不存在：没什么可迁的
            }
            if ((int)one('SELECT COUNT(*) FROM ' . $newTable) > 0) continue;
            $oldRows = rows('SELECT * FROM ' . $oldTable);
            foreach ((array)$oldRows as $r) {
                $vals = array();
                foreach ($cols as $c) $vals[] = isset($r[$c]) ? $r[$c] : null;
                $ph = implode(',', array_fill(0, count($cols), '?'));
                try {
                    q('INSERT IGNORE INTO ' . $newTable . ' (' . implode(',', $cols) . ') VALUES (' . $ph . ')', $vals);
                } catch (Throwable $e) { /* 单行失败不影响其它 */ }
            }
        }
        setting_set('points_migrated', '1');
    } catch (Throwable $e) {
        // 迁移失败不写标记，下次再试
    }
}

/* ============================================================
   三、余额与流水
   ============================================================ */

function moe_pt_uid()
{
    return isset($_SESSION['moe_uid']) ? (int)$_SESSION['moe_uid'] : 0;
}

/** 取（必要时创建）用户积分行 */
function moe_pt_row($uid)
{
    $uid = (int)$uid;
    $zero = array('user_id' => 0, 'balance' => 0, 'earned' => 0, 'spent' => 0);
    if ($uid <= 0) return $zero;
    if (!moe_pt_ready()) {
        $zero['user_id'] = $uid;
        return $zero;
    }
    $t = moe_pt_table('points');
    $pick = function ($r) {
        return array('user_id' => (int)$r['user_id'], 'balance' => round((float)$r['balance'], 2),
                     'earned' => (int)$r['earned'], 'spent' => (int)$r['spent']);
    };
    try {
        $r = row('SELECT user_id, balance, earned, spent FROM ' . $t . ' WHERE user_id = ? LIMIT 1', array($uid));
        if ($r) return $pick($r);
        q('INSERT INTO ' . $t . ' (user_id, balance, earned, spent, updated_at) VALUES (?,0,0,0,?)',
            array($uid, date('Y-m-d H:i:s')));
    } catch (Throwable $e) {
        // 并发下可能已被另一个请求插入，再读一次
        try {
            $r = row('SELECT user_id, balance, earned, spent FROM ' . $t . ' WHERE user_id = ? LIMIT 1', array($uid));
            if ($r) return $pick($r);
        } catch (Throwable $e2) { /* 忽略 */ }
    }
    $zero['user_id'] = $uid;
    return $zero;
}

function moe_pt_balance($uid)
{
    $r = moe_pt_row($uid);
    return round((float)$r['balance'], 2);
}

/** 金币余额（充值获得的第二种货币，2.2.2） */
function moe_pt_coins($uid)
{
    $uid = (int)$uid;
    if ($uid <= 0 || !moe_pt_ready()) return 0.0;
    $r = moe_pt_row($uid);
    return round((float)($r['coins'] ?? 0), 2);
}

/**
 * 加减积分并记流水
 * @param int    $uid
 * @param int    $amount 正数加分、负数扣分
 * @param string $type   sign|comment|download|admin|refund
 * @param string $note   流水备注（前台可见）
 * @return array array('ok'=>bool,'balance'=>int,'msg'=>string)
 */
function moe_pt_add($uid, $amount, $type = 'admin', $note = '', $currency = 'points')
{
    $uid = (int)$uid;
    $amount = round((float)$amount, 2);
    $currency = $currency === 'coins' ? 'coins' : 'points';
    if ($uid <= 0) return array('ok' => false, 'balance' => 0, 'msg' => '用户无效');
    if ($amount == 0.0) return array('ok' => true, 'balance' => $currency === 'coins' ? moe_pt_coins($uid) : moe_pt_balance($uid), 'msg' => '');
    if (!moe_pt_ready()) return array('ok' => false, 'balance' => 0, 'msg' => '积分数据表未就绪');

    moe_pt_row($uid);
    $t = moe_pt_table('points');
    $log = moe_pt_table('log');
    $now = date('Y-m-d H:i:s');
    $col = $currency === 'coins' ? 'coins' : 'balance';

    try {
        if ($amount < 0) {
            // 原子扣减：余额不足时影响行数为 0
            $st = q('UPDATE ' . $t . ' SET ' . $col . ' = ' . $col . ' + ?, updated_at = ?'
                . ' WHERE user_id = ? AND ' . $col . ' >= ?', array($amount, $now, $uid, -$amount));
            if ($st->rowCount() < 1) {
                $cur = row('SELECT balance, coins FROM ' . $t . ' WHERE user_id = ? LIMIT 1', array($uid));
                return array('ok' => false, 'balance' => round((float)($cur[$col] ?? 0), 2),
                             'msg' => $currency === 'coins' ? moe_pt_coin_name() . '不足' : '积分不足');
            }
            // 金币消费同样计入 spent（总消费口径不变）
            if ($currency === 'coins') {
                q('UPDATE ' . $t . ' SET spent = spent + ?, updated_at = ? WHERE user_id = ?', array(-$amount, $now, $uid));
            }
        } else {
            if ($currency === 'coins') {
                q('UPDATE ' . $t . ' SET coins = coins + ?, updated_at = ? WHERE user_id = ?', array($amount, $now, $uid));
            } else {
                q('UPDATE ' . $t . ' SET balance = balance + ?, earned = earned + ?, updated_at = ? WHERE user_id = ?',
                    array($amount, $amount, $now, $uid));
            }
        }

        $note = mb_substr((string)$note, 0, 160, 'UTF-8');
        try {
            q('INSERT INTO ' . $log . ' (user_id, type, amount, note, created_at) VALUES (?,?,?,?,?)',
                array($uid, (string)$type, $amount, $note, $now));
        } catch (Throwable $e) {
            // 流水写失败：按方向回滚，保证余额与累计值对得上
            if ($amount < 0) {
                q('UPDATE ' . $t . ' SET ' . $col . ' = ' . $col . ' + ?, updated_at = ? WHERE user_id = ?',
                    array(-$amount, $now, $uid));
                if ($currency === 'coins') {
                    q('UPDATE ' . $t . ' SET spent = spent - ?, updated_at = ? WHERE user_id = ?', array(-$amount, $now, $uid));
                }
            } else {
                q('UPDATE ' . $t . ' SET ' . $col . ' = ' . $col . ' - ?, updated_at = ? WHERE user_id = ?',
                    array($amount, $now, $uid));
                if ($currency !== 'coins') {
                    q('UPDATE ' . $t . ' SET earned = earned - ?, updated_at = ? WHERE user_id = ?', array($amount, $now, $uid));
                }
            }
            return array('ok' => false, 'balance' => $currency === 'coins' ? moe_pt_coins($uid) : moe_pt_balance($uid), 'msg' => '积分流水写入失败');
        }

        $cur = row('SELECT balance, coins FROM ' . $t . ' WHERE user_id = ? LIMIT 1', array($uid));
        return array('ok' => true, 'balance' => round((float)($cur[$col] ?? 0), 2), 'msg' => '');
    } catch (Throwable $e) {
        return array('ok' => false, 'balance' => 0, 'msg' => '积分写入失败');
    }
}

/** 积分流水 */
function moe_pt_logs($uid, $limit = 12)
{
    $uid = (int)$uid;
    $limit = max(1, min(100, (int)$limit));
    if ($uid <= 0 || !moe_pt_ready()) return array();
    try {
        return (array)rows('SELECT type, amount, note, created_at FROM ' . moe_pt_table('log')
            . ' WHERE user_id = ? ORDER BY id DESC LIMIT ' . $limit, array($uid));
    } catch (Throwable $e) {
        return array();
    }
}

/** 流水类型文案 */
function moe_pt_type_label($type)
{
    $map = array('sign' => '每日签到', 'comment' => '发表评论', 'download' => '兑换资源',
                 'admin' => '站长调整', 'refund' => '订单退回', 'recharge' => '充值' . moe_pt_coin_name());
    return isset($map[$type]) ? $map[$type] : '积分变动';
}

/* ============================================================
   四、签到
   ============================================================ */

/** 今天是否已签到 + 连签天数 + 今天能得多少 */
function moe_pt_sign_status($uid)
{
    $uid = (int)$uid;
    $out = array('signed' => false, 'streak' => 0, 'today_points' => 0, 'yesterday' => false, 'next_points' => 0);
    if ($uid <= 0 || !moe_pt_ready()) return $out;
    $t = moe_pt_table('sign');
    try {
        $today = date('Y-m-d');
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $r = row('SELECT sign_date, points, streak FROM ' . $t . ' WHERE user_id = ? AND sign_date = ? LIMIT 1',
            array($uid, $today));
        if ($r) {
            $out['signed'] = true;
            $out['streak'] = (int)$r['streak'];
            $out['today_points'] = (int)$r['points'];
            return $out;
        }
        $prev = row('SELECT streak FROM ' . $t . ' WHERE user_id = ? AND sign_date = ? LIMIT 1', array($uid, $yesterday));
        $out['yesterday'] = (bool)$prev;
        $out['streak'] = $prev ? (int)$prev['streak'] : 0;
        $out['next_points'] = moe_pt_sign_preview($uid, (int)$out['streak']);
    } catch (Throwable $e) { /* 忽略 */ }
    return $out;
}

/** 按当前规则算「若今天签到能得多少分」 */
function moe_pt_sign_preview($uid, $prevStreak = null)
{
    if ($prevStreak === null) $prevStreak = 0;
    $base  = max(0, (int)moe_pt_opt('sign_base', '5'));
    $bonus = max(0, (int)moe_pt_opt('sign_bonus', '2'));
    $cap   = max(0, (int)moe_pt_opt('sign_maxdays', '6'));
    $streak = (int)$prevStreak + 1;
    return $base + $bonus * min(max(0, $streak - 1), $cap);
}

/** 执行签到 */
function moe_pt_sign_do($uid)
{
    $uid = (int)$uid;
    $fail = array('ok' => false, 'msg' => '', 'points' => 0, 'streak' => 0, 'balance' => 0);
    if ($uid <= 0) { $fail['msg'] = '请先登录'; return $fail; }
    if (!moe_pt_ready()) { $fail['msg'] = '积分数据表未就绪，请联系站长'; return $fail; }

    $st = moe_pt_sign_status($uid);
    if ($st['signed']) {
        $fail['msg'] = '今天已经签到过啦，明天再来～';
        $fail['streak'] = $st['streak'];
        $fail['balance'] = moe_pt_balance($uid);
        return $fail;
    }

    $streak = (int)$st['streak'] + 1;
    $points = moe_pt_sign_preview($uid, (int)$st['streak']);
    $t = moe_pt_table('sign');

    try {
        q('INSERT INTO ' . $t . ' (user_id, sign_date, points, streak, created_at) VALUES (?,?,?,?,?)',
            array($uid, date('Y-m-d'), $points, $streak, date('Y-m-d H:i:s')));
    } catch (Throwable $e) {
        // 唯一键冲突 = 并发重复签到
        $fail['msg'] = '今天已经签到过啦，明天再来～';
        $fail['balance'] = moe_pt_balance($uid);
        return $fail;
    }

    $add = moe_pt_add($uid, $points, 'sign', '签到第 ' . $streak . ' 天');
    if (!$add['ok']) {
        // 积分没发出去就把签到记录删掉，避免「签到成功却一分没有」
        try { q('DELETE FROM ' . $t . ' WHERE user_id = ? AND sign_date = ?', array($uid, date('Y-m-d'))); }
        catch (Throwable $e) { /* 留给站长手动补分 */ }
    }
    return array(
        'ok' => $add['ok'],
        'msg' => $add['ok'] ? ('签到成功，+' . $points . ' ' . moe_pt_name()) : $add['msg'],
        'points' => $points,
        'streak' => $streak,
        'balance' => round((float)$add['balance'], 2),
    );
}

/** 最近 N 天的签到情况（用于日历条） */
function moe_pt_sign_recent($uid, $days = 14)
{
    $days = max(7, min(31, (int)$days));
    $out = array();
    $map = array();
    $uid = (int)$uid;
    if ($uid > 0 && moe_pt_ready()) {
        try {
            $since = date('Y-m-d', strtotime('-' . ($days - 1) . ' day'));
            foreach ((array)rows('SELECT sign_date, points, streak FROM ' . moe_pt_table('sign')
                . ' WHERE user_id = ? AND sign_date >= ? ORDER BY sign_date ASC', array($uid, $since)) as $r) {
                $map[(string)$r['sign_date']] = $r;
            }
        } catch (Throwable $e) { /* 忽略 */ }
    }
    for ($i = $days - 1; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime('-' . $i . ' day'));
        $hit = isset($map[$d]);
        $out[] = array(
            'date'   => $d,
            'day'    => (int)date('j', strtotime($d)),
            'week'   => (int)date('w', strtotime($d)),
            'today'  => $i === 0,
            'signed' => $hit,
            'points' => $hit ? (int)$map[$d]['points'] : 0,
        );
    }
    return $out;
}

/** 本月签到天数 */
function moe_pt_sign_month_count($uid)
{
    $uid = (int)$uid;
    if ($uid <= 0 || !moe_pt_ready()) return 0;
    try {
        return (int)one('SELECT COUNT(*) FROM ' . moe_pt_table('sign')
            . ' WHERE user_id = ? AND sign_date >= ?', array($uid, date('Y-m-01')));
    } catch (Throwable $e) {
        return 0;
    }
}

/* ============================================================
   五、签到排行榜
   ============================================================ */

/** 排行榜可选周期 */
function moe_pt_rank_periods()
{
    return array('week' => '本周', 'month' => '本月', 'all' => '总榜');
}

/** 规范化周期参数，非法值退回本周 */
function moe_pt_rank_period($period)
{
    $map = moe_pt_rank_periods();
    $period = (string)$period;
    return isset($map[$period]) ? $period : 'week';
}

function moe_pt_rank_label($period)
{
    $map = moe_pt_rank_periods();
    return $map[moe_pt_rank_period($period)];
}

/** 周期起点（空字符串 = 不限日期） */
function moe_pt_rank_start($period)
{
    switch (moe_pt_rank_period($period)) {
        case 'month':
            return date('Y-m-01');
        case 'all':
            return '';
    }
    $mon = strtotime('monday this week');
    return date('Y-m-d', $mon ? $mon : time());
}

/**
 * 签到排行榜数据：按周期内签到天数排序，天数相同比积分
 * 只统计状态正常的用户；同一请求内复用结果（侧栏 / 用户中心都可能调两次）
 *
 * @param string $period week|month|all
 * @param int    $limit  取前 N 名（1-50）
 * @return array{rows:array,today:int,signers:int,period:string}
 */
function moe_pt_rank_board($period = 'week', $limit = 10)
{
    $period = moe_pt_rank_period($period);
    $limit  = max(1, min(50, (int)$limit));

    static $memo = array();
    $mk = $period . '|' . $limit;
    if (isset($memo[$mk])) return $memo[$mk];

    $out = array('rows' => array(), 'today' => 0, 'signers' => 0, 'period' => $period);
    if (!moe_pt_ready()) return $memo[$mk] = $out;

    $t     = moe_pt_table('sign');
    $ut    = moe_table('users');
    $start = moe_pt_rank_start($period);
    // 只统计状态正常的用户（表里 status 为空的老账号也认作正常）
    $alive = "u.status IS NULL OR u.status = '' OR u.status = 'active'";
    $join  = ' FROM ' . $t . ' s INNER JOIN ' . $ut . ' u ON u.id = s.user_id WHERE ' . $alive;

    try {
        $out['today'] = (int)one('SELECT COUNT(DISTINCT s.user_id)' . $join . ' AND s.sign_date = ?',
            array(date('Y-m-d')));
        $pick = 'SELECT s.user_id, COUNT(*) AS days, COALESCE(SUM(s.points),0) AS pts' . $join;
        $tail = ' GROUP BY s.user_id ORDER BY days DESC, pts DESC, s.user_id ASC LIMIT ' . ($limit * 2);
        if ($start !== '') {
            $out['signers'] = (int)one('SELECT COUNT(DISTINCT s.user_id)' . $join . ' AND s.sign_date >= ?', array($start));
            $rs = rows($pick . ' AND s.sign_date >= ?' . $tail, array($start));
        } else {
            $out['signers'] = (int)one('SELECT COUNT(DISTINCT s.user_id)' . $join);
            $rs = rows($pick . $tail);
        }
    } catch (Throwable $e) {
        return $memo[$mk] = $out;
    }
    if (!$rs) return $memo[$mk] = $out;

    /* 批量取用户资料，避免每行一次查询 */
    $ids = array();
    foreach ($rs as $r) $ids[(int)$r['user_id']] = 1;
    $ids = array_keys($ids);
    $ph  = implode(',', array_fill(0, count($ids), '?'));
    $users = array();
    try {
        foreach ((array)rows('SELECT id, username, nickname, avatar, status FROM ' . moe_table('users')
            . ' WHERE id IN (' . $ph . ')', $ids) as $u) {
            $users[(int)$u['id']] = $u;
        }
    } catch (Throwable $e) { /* 忽略 */ }

    /* 当前连签：只认今天 / 昨天签过的人，取最新一天的 streak */
    $streak = array();
    try {
        $args = $ids;
        $args[] = date('Y-m-d', strtotime('-1 day'));
        foreach ((array)rows('SELECT user_id, sign_date, streak FROM ' . $t
            . ' WHERE user_id IN (' . $ph . ') AND sign_date >= ? ORDER BY sign_date DESC', $args) as $r) {
            $u0 = (int)$r['user_id'];
            if (!isset($streak[$u0])) $streak[$u0] = (int)$r['streak'];
        }
    } catch (Throwable $e) { /* 忽略 */ }

    foreach ($rs as $r) {
        if (count($out['rows']) >= $limit) break;
        $uid = (int)$r['user_id'];
        $u   = isset($users[$uid]) ? $users[$uid] : null;
        if ($u && isset($u['status']) && (string)$u['status'] !== 'active') continue;   // 封禁用户不上榜
        $name = '用户' . $uid;
        $ava  = '';
        $url  = '';
        if ($u) {
            $name = function_exists('moe_user_display') ? moe_user_display($u)
                : (trim((string)$u['nickname']) !== '' ? (string)$u['nickname'] : (string)$u['username']);
            $ava  = function_exists('moe_user_avatar') ? moe_user_avatar($u)
                : media_url(trim((string)$u['avatar']) !== '' ? (string)$u['avatar'] : 'templates/default/assets/avatar.svg');
            $url  = function_exists('moe_user_url') ? moe_user_url($u) : '';
        }
        $out['rows'][] = array(
            'uid'     => $uid,
            'name'    => $name,
            'avatar'  => $ava,
            'url'     => $url,
            'days'    => (int)$r['days'],
            'points'  => (int)$r['pts'],
            'streak'  => isset($streak[$uid]) ? (int)$streak[$uid] : 0,
        );
    }
    return $memo[$mk] = $out;
}

/**
 * 我的排名：排名 = 比我强的人数 + 1
 * @return array{rank:int,days:int,points:int,streak:int,total:int}
 */
function moe_pt_rank_me($uid, $period = 'week')
{
    $uid    = (int)$uid;
    $period = moe_pt_rank_period($period);
    $out    = array('rank' => 0, 'days' => 0, 'points' => 0, 'streak' => 0, 'total' => 0);
    if ($uid <= 0 || !moe_pt_ready()) return $out;

    $t     = moe_pt_table('sign');
    $start = moe_pt_rank_start($period);
    $st    = moe_pt_sign_status($uid);
    $out['streak'] = (int)$st['streak'];

    try {
        $where = ' WHERE user_id = ?' . ($start !== '' ? ' AND sign_date >= ?' : '');
        $args  = $start !== '' ? array($uid, $start) : array($uid);
        $r = row('SELECT COUNT(*) AS days, COALESCE(SUM(points),0) AS pts FROM ' . $t . $where, $args);
        $out['days']   = $r ? (int)$r['days'] : 0;
        $out['points'] = $r ? (int)$r['pts'] : 0;

        $inner = 'SELECT s.user_id, COUNT(*) AS d, COALESCE(SUM(s.points),0) AS p FROM ' . $t . ' s'
               . ' INNER JOIN ' . moe_table('users') . ' u ON u.id = s.user_id'
               . " WHERE (u.status IS NULL OR u.status = '' OR u.status = 'active')"
               . ($start !== '' ? ' AND s.sign_date >= ?' : '')
               . ' GROUP BY s.user_id';
        $iArgs = $start !== '' ? array($start) : array();
        $out['total'] = (int)one('SELECT COUNT(*) FROM (' . $inner . ') tb', $iArgs);
        if ($out['days'] > 0) {
            // 直接内联整数：不同驱动对「字符串参数 vs 整型列」的比较规则不一致（SQLite 会按文本比）
            $better = (int)one('SELECT COUNT(*) FROM (' . $inner . ') tb WHERE tb.d > ' . (int)$out['days']
                . ' OR (tb.d = ' . (int)$out['days'] . ' AND tb.p > ' . (int)$out['points'] . ')', $iArgs);
            $out['rank'] = $better + 1;
        }
    } catch (Throwable $e) { /* 忽略 */ }
    return $out;
}

/* ============================================================
   六、评论得分
   ============================================================ */

/** 今天还剩几次评论得分机会 */
function moe_pt_comment_left($uid)
{
    $uid = (int)$uid;
    $limit = (int)moe_pt_opt('comment_daily', '3');
    if ($uid <= 0 || $limit <= 0 || !moe_pt_ready()) return 0;
    if ((int)moe_pt_opt('comment', '2') <= 0) return 0;
    try {
        $n = (int)one('SELECT COUNT(*) FROM ' . moe_pt_table('log')
            . " WHERE user_id = ? AND type = 'comment' AND created_at >= ?",
            array($uid, date('Y-m-d') . ' 00:00:00'));
        return max(0, $limit - $n);
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * 评论得分：按规则与每日上限发放；同一评论只发一次
 * @param int $uid
 * @param int $commentId 评论 id（0 = 不做去重，调用方保证只调一次）
 */
function moe_pt_comment_grant($uid, $commentId = 0)
{
    $uid = (int)$uid;
    $fail = array('ok' => false, 'msg' => '', 'points' => 0, 'balance' => 0);
    if ($uid <= 0) { $fail['msg'] = '未登录'; return $fail; }
    $points = max(0, (int)moe_pt_opt('comment', '2'));
    if ($points <= 0) { $fail['msg'] = '本站未开启评论得分'; return $fail; }
    if (!moe_pt_ready()) { $fail['msg'] = '积分数据表未就绪'; return $fail; }

    $note = $commentId > 0 ? ('评论 #' . (int)$commentId) : '发表评论';
    if ($commentId > 0) {
        try {
            $exist = row('SELECT id FROM ' . moe_pt_table('log') . ' WHERE user_id = ? AND note = ? LIMIT 1',
                array($uid, $note));
            if ($exist) { $fail['msg'] = '这条评论的积分已经领过了'; $fail['balance'] = moe_pt_balance($uid); return $fail; }
        } catch (Throwable $e) { /* 交给每日上限兜底 */ }
    }
    if (moe_pt_comment_left($uid) <= 0) {
        $fail['msg'] = '今天的评论得分已经拿满啦';
        $fail['balance'] = moe_pt_balance($uid);
        return $fail;
    }
    $r = moe_pt_add($uid, $points, 'comment', $note);
    return array(
        'ok' => (bool)$r['ok'],
        'msg' => $r['ok'] ? ('评论 +' . $points . ' ' . moe_pt_name()) : (string)$r['msg'],
        'points' => $points,
        'balance' => round((float)$r['balance'], 2),
    );
}

/* ============================================================
   七、商品 / 订单 / 下载
   ============================================================ */

/** 商品列表 */
function moe_pt_goods($onlyOn = true)
{
    if (!moe_pt_ready()) return array();
    try {
        $sql = 'SELECT * FROM ' . moe_pt_table('goods');
        if ($onlyOn) $sql .= " WHERE status = 'on'";
        $sql .= ' ORDER BY sort ASC, id DESC';
        return (array)rows($sql);
    } catch (Throwable $e) {
        return array();
    }
}

function moe_pt_good($id)
{
    $id = (int)$id;
    if ($id <= 0 || !moe_pt_ready()) return null;
    try {
        $r = row('SELECT * FROM ' . moe_pt_table('goods') . ' WHERE id = ? LIMIT 1', array($id));
        return $r ? $r : null;
    } catch (Throwable $e) {
        return null;
    }
}

/** 用户已兑换的商品：goods_id => 订单行 */
function moe_pt_orders($uid)
{
    $uid = (int)$uid;
    if ($uid <= 0 || !moe_pt_ready()) return array();
    try {
        $rs = rows('SELECT o.*, g.title, g.cover, g.summary, g.price AS goods_price, g.download_url'
            . ' FROM ' . moe_pt_table('orders') . ' o'
            . ' LEFT JOIN ' . moe_pt_table('goods') . ' g ON g.id = o.goods_id'
            . ' WHERE o.user_id = ? ORDER BY o.id DESC', array($uid));
        $out = array();
        foreach ((array)$rs as $r) $out[(int)$r['goods_id']] = $r;
        return $out;
    } catch (Throwable $e) {
        return array();
    }
}

function moe_pt_has_bought($uid, $gid)
{
    $uid = (int)$uid; $gid = (int)$gid;
    if ($uid <= 0 || $gid <= 0 || !moe_pt_ready()) return false;
    try {
        return (bool)row('SELECT id FROM ' . moe_pt_table('orders') . ' WHERE user_id = ? AND goods_id = ? LIMIT 1',
            array($uid, $gid));
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * 兑换（下单）：扣积分或金币 + 写订单，任一步失败都把货币退回
 * $currency = points（赚来的积分）| coins（充值获得的金币），2.2.2 起可选
 * @return array('ok'=>bool,'msg'=>string,'balance'=>int)
 */
function moe_pt_buy($uid, $gid, $currency = 'points')
{
    $uid = (int)$uid; $gid = (int)$gid;
    $currency = $currency === 'coins' ? 'coins' : 'points';
    $cName = $currency === 'coins' ? moe_pt_coin_name() : moe_pt_name();
    $fail = array('ok' => false, 'msg' => '', 'balance' => 0);
    if ($uid <= 0) { $fail['msg'] = '请先登录后再兑换'; return $fail; }
    if (!moe_pt_ready()) { $fail['msg'] = '积分数据表未就绪，请联系站长'; return $fail; }

    $g = moe_pt_good($gid);
    if (!$g) { $fail['msg'] = '资源不存在或已删除'; return $fail; }
    if ((string)$g['status'] !== 'on') { $fail['msg'] = '该资源已下架'; return $fail; }
    if (moe_pt_has_bought($uid, $gid)) {
        $fail['msg'] = '你已经兑换过了，可直接下载';
        $fail['balance'] = moe_pt_balance($uid);
        return $fail;
    }

    // 2.2.5：金币兑换按资源的金币价（未单独定价时与积分同价）；2.2.7：null = 该资源不支持这种币种
    $price = $currency === 'coins' ? moe_pt_coins_price_of($g) : moe_pt_price_of($g);
    if ($price === null) {
        $fail['msg'] = '该资源不支持用' . $cName . '兑换';
        $fail['balance'] = $currency === 'coins' ? moe_pt_coins($uid) : moe_pt_balance($uid);
        return $fail;
    }
    if ($price > 0) {
        $deduct = moe_pt_add($uid, -$price, 'download', '兑换（' . $cName . '）：' . (string)$g['title'], $currency);
        if (!$deduct['ok']) {
            $have = $currency === 'coins' ? moe_pt_coins($uid) : moe_pt_balance($uid);
            $short = $price - $have;
            $fail['msg'] = ($deduct['msg'] === '积分不足' || $deduct['msg'] === '金币不足' || $deduct['msg'] === moe_pt_coin_name() . '不足')
                ? ($cName . '不足，还差 ' . max(0, $short) . ' ' . $cName)
                : (string)$deduct['msg'];
            $fail['balance'] = $have;
            return $fail;
        }
    }

    try {
        q('INSERT INTO ' . moe_pt_table('orders') . ' (user_id, goods_id, price, currency, status, created_at) VALUES (?,?,?,?,?,?)',
            array($uid, $gid, $price, $currency, 'paid', date('Y-m-d H:i:s')));
    } catch (Throwable $e) {
        if ($price > 0) moe_pt_add($uid, $price, 'refund', '兑换失败退回：' . (string)$g['title'], $currency);
        $fail['msg'] = '订单写入失败，' . $cName . '已退回';
        $fail['balance'] = $currency === 'coins' ? moe_pt_coins($uid) : moe_pt_balance($uid);
        return $fail;
    }

    $have = $currency === 'coins' ? moe_pt_coins($uid) : moe_pt_balance($uid);
    return array('ok' => true, 'msg' => '兑换成功，现在可以下载啦', 'balance' => $have, 'currency' => $currency);
}

/**
 * 下载地址解析：支持外链（http/https）与站内文件（uploads/… 、/content/…）
 * @return array|null array('type'=>'remote'|'local','url'=>,'path'=>,'name'=>)
 */
function moe_pt_good_target($gid)
{
    $g = moe_pt_good($gid);
    if (!$g) return null;
    $raw = trim((string)($g['download_url'] ?? ''));
    if ($raw === '' || strpos($raw, "\n") !== false || strpos($raw, "\r") !== false) return null;

    if (preg_match('#^https?://#i', $raw)) {
        return array('type' => 'remote', 'url' => $raw, 'path' => '', 'name' => (string)$g['title']);
    }
    // 站内文件：去掉站点域名前缀，只取相对路径
    $base = base_url();
    if (strpos($raw, $base) === 0) $raw = substr($raw, strlen($base));
    $rel = ltrim(str_replace('\\', '/', $raw), '/');
    if ($rel === '' || strpos($rel, '..') !== false) return null;
    $abs = MOE_ROOT . '/' . $rel;
    if (!is_file($abs)) return null;
    $real = realpath($abs);
    $root = realpath(MOE_ROOT);
    if ($real === false || $root === false || strpos($real, $root) !== 0) return null;
    if (preg_match('/\.(php|phtml|phar|inc)$/i', $real)) return null;
    return array('type' => 'local', 'url' => media_url($rel), 'path' => $real, 'name' => (string)$g['title']);
}

/** 已兑换才给地址 */
function moe_pt_download_target($uid, $gid)
{
    if (!moe_pt_has_bought($uid, $gid)) return null;
    return moe_pt_good_target($gid);
}

/** 记录一次下载并累加商品下载数 */
function moe_pt_download_record($uid, $gid)
{
    $uid = (int)$uid; $gid = (int)$gid;
    if ($uid <= 0 || $gid <= 0 || !moe_pt_ready()) return false;
    try {
        q('INSERT INTO ' . moe_pt_table('downloads') . ' (user_id, goods_id, created_at) VALUES (?,?,?)',
            array($uid, $gid, date('Y-m-d H:i:s')));
        q('UPDATE ' . moe_pt_table('goods') . ' SET downloads = downloads + 1 WHERE id = ?', array($gid));
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/** 用户的下载记录（最近的，带商品信息） */
function moe_pt_download_history($uid, $limit = 20)
{
    $uid = (int)$uid;
    $limit = max(1, min(60, (int)$limit));
    if ($uid <= 0 || !moe_pt_ready()) return array();
    try {
        return (array)rows('SELECT d.*, g.title, g.cover FROM ' . moe_pt_table('downloads') . ' d'
            . ' LEFT JOIN ' . moe_pt_table('goods') . ' g ON g.id = d.goods_id'
            . ' WHERE d.user_id = ? ORDER BY d.id DESC LIMIT ' . $limit, array($uid));
    } catch (Throwable $e) {
        return array();
    }
}

/* ============================================================
   八、后台写操作
   ============================================================ */

function moe_pt_goods_save($d, $id = 0)
{
    if (!moe_pt_ready()) return false;
    $id = (int)$id;
    $now = date('Y-m-d H:i:s');
    $title = trim((string)($d['title'] ?? ''));
    if ($title === '') return false;
    $fields = array(
        mb_substr($title, 0, 120, 'UTF-8'),
        mb_substr(trim((string)($d['summary'] ?? '')), 0, 255, 'UTF-8'),
        mb_substr(trim((string)($d['cat'] ?? '')), 0, 30, 'UTF-8'),
        (int)($d['post_id'] ?? 0),
        mb_substr(trim((string)($d['cover'] ?? '')), 0, 255, 'UTF-8'),
        // 2.2.7：定价三选一 —— 传入负数表示不支持该币种（原样保存为哨兵值）
        round((float)($d['price'] ?? 0), 2),
        round((float)($d['price_coins'] ?? 0), 2),
        mb_substr(trim((string)($d['download_pwd'] ?? '')), 0, 64, 'UTF-8'),
        trim((string)($d['download_url'] ?? '')),
        ($d['status'] ?? 'on') === 'on' ? 'on' : 'off',
        (int)($d['sort'] ?? 0),
    );
    try {
        if ($id > 0) {
            q('UPDATE ' . moe_pt_table('goods') . ' SET title=?, summary=?, cat=?, post_id=?, cover=?, price=?, price_coins=?, download_pwd=?, download_url=?, status=?, sort=?, updated_at=? WHERE id=?',
                array_merge($fields, array($now, $id)));
            return $id;
        }
        q('INSERT INTO ' . moe_pt_table('goods') . ' (title, summary, cat, post_id, cover, price, price_coins, download_pwd, download_url, status, sort, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
            array_merge($fields, array($now, $now)));
        return (int)last_id();
    } catch (Throwable $e) {
        return false;
    }
}

function moe_pt_goods_status($id, $status)
{
    $id = (int)$id;
    if ($id <= 0 || !moe_pt_ready()) return false;
    $status = $status === 'on' ? 'on' : 'off';
    try {
        q('UPDATE ' . moe_pt_table('goods') . ' SET status = ?, updated_at = ? WHERE id = ?',
            array($status, date('Y-m-d H:i:s'), $id));
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * 2.2.23：后台编辑器「上架资源」联动 —— 按文章 id 增改关联商品
 * 封面默认直接取文章封面（传入 $d['cover'] 则覆盖）；同一文章只挂一个商品，已存在即更新
 * @param int  $postId 文章 id
 * @param array $d    title/cat/price/price_coins/download_url/summary/cover/status
 * @return int|false  商品 id
 */
function moe_pt_goods_sync_from_post($postId, $d)
{
    if (!moe_pt_ready()) return false;
    $postId = (int)$postId;
    if ($postId <= 0) return false;
    try {
        $p = row('SELECT title, cover, excerpt FROM ' . moe_table('posts') . ' WHERE id = ? LIMIT 1', array($postId));
        if (!$p) return false;
        $ex = row('SELECT id FROM ' . moe_pt_table('goods') . ' WHERE post_id = ? LIMIT 1', array($postId));
        $cover = trim((string)($d['cover'] ?? ''));
        if ($cover === '') $cover = trim((string)($p['cover'] ?? ''));   // 封面直接取文章封面
        $summary = trim((string)($d['summary'] ?? ''));
        if ($summary === '') $summary = mb_substr(trim((string)($p['excerpt'] ?? '')), 0, 255, 'UTF-8');
        return moe_pt_goods_save(array(
            'title'        => trim((string)($d['title'] ?? '')) !== '' ? (string)$d['title'] : (string)$p['title'],
            'summary'      => $summary,
            'cat'          => mb_substr(trim((string)($d['cat'] ?? '其他')), 0, 30, 'UTF-8'),
            'post_id'      => $postId,
            'cover'        => $cover,
            'price'        => round(max(0, (float)($d['price'] ?? 0)), 2),
            'price_coins'  => round(max(0, (float)($d['price_coins'] ?? 0)), 2),
            'download_url' => trim((string)($d['download_url'] ?? '')),
            'status'       => ($d['status'] ?? 'on') === 'on' ? 'on' : 'off',
            'sort'         => (int)($d['sort'] ?? 0),
        ), $ex ? (int)$ex['id'] : 0);
    } catch (Throwable $e) {
        return false;
    }
}

function moe_pt_goods_delete($id)
{    $id = (int)$id;
    if ($id <= 0 || !moe_pt_ready()) return false;
    try {
        q('DELETE FROM ' . moe_pt_table('goods') . ' WHERE id = ?', array($id));
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/** 撤销订单并退分（会员需重新兑换） */
function moe_pt_order_revoke($orderId)
{
    $orderId = (int)$orderId;
    if ($orderId <= 0 || !moe_pt_ready()) return array('ok' => false, 'msg' => '参数无效');
    try {
        $o = row('SELECT * FROM ' . moe_pt_table('orders') . ' WHERE id = ? LIMIT 1', array($orderId));
        if (!$o) return array('ok' => false, 'msg' => '订单不存在');
        $price = round((float)$o['price'], 2);
        if ($price > 0) {
            $r = moe_pt_add((int)$o['user_id'], $price, 'refund', '撤销订单 #' . $orderId . ' 退回');
            if (!$r['ok']) return array('ok' => false, 'msg' => '退分失败：' . $r['msg']);
        }
        q('DELETE FROM ' . moe_pt_table('orders') . ' WHERE id = ?', array($orderId));
        return array('ok' => true, 'msg' => '已撤销订单并退回 ' . moe_pt_num($price) . ' ' . moe_pt_name());
    } catch (Throwable $e) {
        return array('ok' => false, 'msg' => '撤销失败');
    }
}

/** 后台概览数据 */
function moe_pt_stats()
{
    $out = array('goods' => 0, 'on' => 0, 'orders' => 0, 'sign_today' => 0, 'points' => 0, 'members' => 0);
    if (!moe_pt_ready()) return $out;
    try {
        $out['goods'] = (int)one('SELECT COUNT(*) FROM ' . moe_pt_table('goods'));
        $out['on'] = (int)one('SELECT COUNT(*) FROM ' . moe_pt_table('goods') . " WHERE status = 'on'");
        $out['orders'] = (int)one('SELECT COUNT(*) FROM ' . moe_pt_table('orders'));
        $out['sign_today'] = (int)one('SELECT COUNT(*) FROM ' . moe_pt_table('sign') . ' WHERE sign_date = ?', array(date('Y-m-d')));
        $out['points'] = (int)one('SELECT COALESCE(SUM(balance),0) FROM ' . moe_pt_table('points'));
        $out['members'] = (int)one('SELECT COUNT(*) FROM ' . moe_pt_table('points') . ' WHERE balance > 0');
    } catch (Throwable $e) { /* 忽略 */ }
    return $out;
}

/* ============================================================
   九、前台视图（用户中心页签 / 商城页 / 下载端点）
   ============================================================ */

/**
 * 下载链接：用 download.php?g=ID（Apache / Nginx 都能直连，不依赖伪静态规则）
 * /download/{id} 也支持，作为好看一点的别名保留。
 */
function moe_pt_download_url($gid)
{
    return base_url() . 'api/download.php?g=' . (int)$gid;
}

/**
 * 正文内嵌下载卡片（2.1.6）
 * Markdown 里写 @[download](资源ID) 即渲染成一张下载卡：
 *   已拥有 → 立即下载；未兑换 → 用积分兑换（表单直接提交，成功后回到本文档同位置）；
 *   未登录 → 登录入口；资源不存在/下架 → 返回空（正文显示一行提示）。
 * @param int $gid 积分商城里的资源 ID
 */
function moe_pt_dl_card($gid)
{
    $gid = (int)$gid;
    if ($gid <= 0 || !function_exists('moe_pt_good')) return '';
    $g = moe_pt_good($gid);
    if (!$g || (string)$g['status'] !== 'on') return '';

    $uid    = function_exists('moe_pt_uid') ? (int)moe_pt_uid() : 0;
    $unit   = moe_pt_name();
    $cn     = moe_pt_coin_name();   // 2.2.20：金币自定义名称（修复改名后文章卡片仍显示「金币」）
    // 2.2.7：定价三选一 —— 萌豆价不支持（null）时改用金币价与金币兑换
    $price  = moe_pt_price_of($g);
    $useCur = 'points';
    if ($price === null) {
        $price  = moe_pt_coins_price_of($g) ?? 0;
        $useCur = 'coins';
    }
    $coinPrice = moe_pt_coins_price_of($g);
    $pn     = moe_pt_num($price);
    $title  = (string)$g['title'];
    $summary = trim((string)$g['summary']);
    if ($summary === '') $summary = $price > 0 ? ('用 ' . $pn . ' ' . ($useCur === 'coins' ? $cn : $unit) . '兑换后可下载') : '免费资源，登录后即可领取';
    $bought = $uid > 0 && moe_pt_has_bought($uid, $gid);
    $bal    = $uid > 0 ? moe_pt_balance($uid) : 0;
    $coinBal = ($uid > 0 && function_exists('moe_pt_coins')) ? (float)moe_pt_coins($uid) : 0;
    $uc     = base_url() . 'user';
    $dl     = moe_pt_download_url($gid);

    // 兑换成功后回到本文档的这张卡片
    $host = (!empty($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
    $back = ($host !== ''
        ? ((is_ssl() ? 'https://' : 'http://') . $host . (isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '/'))
        : '') . '#dl-' . $gid;

    $btnBase = 'display:inline-flex;align-items:center;gap:5px;padding:9px 15px;border-radius:10px;'
             . 'font-size:12.5px;font-weight:600;text-decoration:none;border:0;cursor:pointer;line-height:1.2;';
    $btnMain = $btnBase . 'background:linear-gradient(135deg,#3aa79f,#5cc9c0);color:#fff;box-shadow:0 4px 14px rgba(58,167,159,.28);';
    $btnGhost = $btnBase . 'background:#fff;color:#3d8e88;border:1px solid #cfe8e5;box-shadow:0 2px 8px rgba(31,58,82,.05);';

    if ($bought) {
        $act = '<a class="pt-dl-btn" href="' . e($dl) . '" style="' . $btnGhost . '">⬇ 立即下载</a>';
    } elseif ($uid <= 0) {
        $act = '<a class="pt-dl-btn" href="' . e($uc . '?a=login&back=shop') . '" style="' . $btnGhost . '">🔐 登录后下载</a>';
    } elseif ($price > 0) {
        /* 2.2.20：余额智能判断 —— 双币资源自动挑够用的那种币；
           两种都不够时，金币直接给「充值金币」（跳商城充值区扫码），积分给「去赚积分」 */
        $canPts    = ($useCur === 'points');
        $canCoin   = ($coinPrice !== null);
        $ptsEnough = $canPts && $bal >= $price;
        $coinEnough = $canCoin && $coinPrice > 0 && $coinBal >= (float)$coinPrice && function_exists('moe_rc_on') && moe_rc_on();
        if ($ptsEnough) {
            $act = '<form method="post" action="' . e($uc . '?a=shop') . '" style="margin:0">' . csrf_field()
                 . '<input type="hidden" name="act" value="buy">'
                 . '<input type="hidden" name="gid" value="' . $gid . '">'
                 . '<input type="hidden" name="currency" value="points">'
                 . '<input type="hidden" name="back_url" value="' . e($back) . '">'
                 . '<button class="pt-dl-btn" type="submit" style="' . $btnMain . '">'
                 . '🎁 用 ' . moe_pt_num($price) . ' ' . e($unit) . '兑换</button></form>';
        } elseif ($coinEnough || ($canCoin && !$canPts)) {
            $act = '<form method="post" action="' . e($uc . '?a=shop') . '" style="margin:0">' . csrf_field()
                 . '<input type="hidden" name="act" value="buy">'
                 . '<input type="hidden" name="gid" value="' . $gid . '">'
                 . '<input type="hidden" name="currency" value="coins">'
                 . '<input type="hidden" name="back_url" value="' . e($back) . '">'
                 . '<button class="pt-dl-btn" type="submit" style="' . $btnMain . '">'
                 . '💰 用 ' . moe_pt_num((float)$coinPrice) . ' ' . e($cn) . '兑换</button></form>';
        } else {
            // 两种都不够：金币不足 → 充值按钮（直达扫码充值区）；积分不足 → 去赚积分
            $acts = array();
            if ($canCoin) {
                $acts[] = '<a class="pt-dl-btn" href="' . e($uc . '?a=shop&sub=recharge') . '" style="' . $btnMain . '">💰 充值' . e($cn)
                        . ($coinPrice > 0 ? '（还差 ' . moe_pt_num(round((float)$coinPrice - $coinBal, 2)) . '）' : '') . '</a>';
            }
            if ($canPts) {
                $acts[] = '<a class="pt-dl-btn" href="' . e($uc . '?a=points') . '" style="' . $btnGhost . '">还差 '
                        . moe_pt_num(round($price - $bal, 2)) . ' ' . e($unit) . '，去赚' . e($unit) . '</a>';
            }
            $act = '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">' . implode('', $acts) . '</div>';
        }
    } else {
        $act = '<form method="post" action="' . e($uc . '?a=shop') . '" style="margin:0">' . csrf_field()
             . '<input type="hidden" name="act" value="buy">'
             . '<input type="hidden" name="gid" value="' . $gid . '">'
             . '<input type="hidden" name="currency" value="' . $useCur . '">'
             . '<input type="hidden" name="back_url" value="' . e($back) . '">'
             . '<button class="pt-dl-btn" type="submit" style="' . $btnMain . '">'
             . ($price > 0 ? '🎁 用 ' . $pn . ' ' . ($useCur === 'coins' ? e($cn) : e($unit)) . '兑换' : '🎁 免费领取') . '</button></form>';
    }

    $meta = array();
    if ($bought) $meta[] = '✅ 已拥有';
    // 2.2.7：按定价方式展示（仅萌豆 / 仅金币 / 双币同售）；2.2.20：💰 代替 🪙（🪙 在部分系统缺字体显示为方框）+ 金币名称跟随设置
    $canCoinsHere = $coinPrice !== null;
    if ($useCur === 'coins') {
        $meta[] = '💰 ' . moe_pt_num((float)($g['price_coins'] ?? 0)) . ' ' . e($cn);
    } elseif ($canCoinsHere && $coinPrice > 0 && $price > 0) {
        $meta[] = '💎 ' . $pn . ' ' . e($unit) . ' / 💰 ' . moe_pt_num($coinPrice) . ' ' . e($cn);
    } else {
        $meta[] = $price > 0 ? ('💎 ' . $pn . ' ' . e($unit)) : '💎 免费';
    }
    $meta[] = '📥 ' . (int)$g['downloads'] . ' 次下载';
    // 2.1.7：资源设置了下载密码 —— 已兑换的直接展示密码，未兑换显示锁定标记
    $dlPwd = trim((string)($g['download_pwd'] ?? ''));
    if ($dlPwd !== '') $meta[] = $bought ? ('🔑 ' . e($dlPwd)) : '🔒 需密码';

    // 2.2.5：卡片左侧显示资源封面（外链防盗链 no-referrer；加载失败降级回 📦 图标）
    $cover = trim((string)($g['cover'] ?? ''));
    $coverHtml = '<div style="flex:none;width:46px;height:46px;border-radius:13px;background:#fff;display:flex;'
        . 'align-items:center;justify-content:center;font-size:22px;box-shadow:0 3px 12px rgba(31,58,82,.08);overflow:hidden">📦</div>';
    if ($cover !== '') {
        $coverHtml = '<div style="flex:none;width:46px;height:46px;border-radius:13px;background:#fff;display:flex;'
            . 'align-items:center;justify-content:center;font-size:22px;box-shadow:0 3px 12px rgba(31,58,82,.08);overflow:hidden">'
            . '<img src="' . e(media_url($cover)) . '" alt="' . e($title) . '" loading="lazy" decoding="async" referrerpolicy="no-referrer"'
            . ' style="width:100%;height:100%;object-fit:cover;display:block"'
            . ' onerror="this.parentNode.textContent=\'📦\';this.remove();"></div>';
    }

    return '<div class="pt-dlcard" id="dl-' . $gid . '" style="display:flex;flex-wrap:wrap;gap:14px;align-items:center;'
        . 'margin:22px 0;padding:16px 18px;border:1px solid #e2eef1;border-radius:16px;'
        . 'background:linear-gradient(135deg,#f8fdfd 0%,#f3f9ff 100%)">'
        . $coverHtml
        . '<div style="flex:1;min-width:170px">'
        . '<div style="font-size:15px;font-weight:600;color:#243b4d;line-height:1.4">' . e($title) . '</div>'
        . '<div style="font-size:12px;color:#7d93a3;margin-top:3px">' . e($summary) . '</div>'
        . '<div style="font-size:11.5px;color:#95a9b7;margin-top:7px">' . implode(' · ', $meta) . '</div>'
        . '</div><div style="flex:none">' . $act . '</div></div>';
}

/** 正文下载卡片的占位提示（资源不存在 / 已下架时） */
function moe_pt_dl_card_missing($gid)
{
    return '<p class="pt-dlcard-missing" style="margin:18px 0;padding:10px 14px;border:1px dashed #e3d6e9;'
        . 'border-radius:10px;font-size:12.5px;color:#9b8bb0">📦 下载卡片 #' . (int)$gid . '：资源不存在或已下架，'
        . '请到后台「积分商城」检查这个资源。</p>';
}

/** 商品封面：空封面用渐变底 + 首字 */
function moe_pt_cover_html($g, $cls = 'pt-goods-cover')
{
    $cover = trim((string)($g['cover'] ?? ''));
    if ($cover !== '') {
        // 2.2.2：no-referrer 防图床防盗链；加载失败自动降级为首字占位
        return '<div class="' . e($cls) . '"><img src="' . e(media_url($cover)) . '" alt="' . e((string)$g['title'])
             . '" loading="lazy" decoding="async" referrerpolicy="no-referrer"'
             . ' onerror="var d=this.parentNode;d.classList.add(\'is-empty\');'
             . 'var s=document.createElement(\'span\');s.textContent=' . json_encode(mb_substr(trim((string)($g['title'] ?? '源')), 0, 1, 'UTF-8'))
             . ';d.appendChild(s);this.remove();"></div>';
    }
    $ch = mb_substr(trim((string)($g['title'] ?? '资源')), 0, 1, 'UTF-8');
    return '<div class="' . e($cls) . ' is-empty"><span>' . e($ch) . '</span></div>';
}

/** 积分卡片（我的主页 / 签到积分页共用头部） */
function moe_pt_balance_card($u, $inline = false)
{
    $uid = (int)$u['id'];
    $bal = moe_pt_balance($uid);
    $st  = moe_pt_sign_status($uid);
    $unit = moe_pt_name();
    $uc = base_url() . 'user';
    $h = '<div class="pt-hero' . ($inline ? ' is-inline' : '') . '">'
       . '<div class="pt-hero-main"><div class="pt-hero-label">我的' . e($unit) . '</div>'
       . '<div class="pt-hero-num">' . (int)$bal . '<small>' . e($unit) . '</small></div>'
       . (function_exists('moe_rc_on') && moe_rc_on()
            ? '<div class="pt-hero-label">💰 ' . e(moe_pt_coin_name()) . ' <b>' . moe_pt_coins($uid) . '</b>（充值获得，商城兑换时可选）</div>' : '')
       . '<div class="pt-hero-sub">'
       . ($st['signed']
            ? '今日已签到 · 连签 <b>' . (int)$st['streak'] . '</b> 天'
            : ($st['streak'] > 0 ? '已连签 <b>' . (int)$st['streak'] . '</b> 天，今天还没签到' : '还没签到，今天开始吧'))
       . '</div></div>'
       . '<div class="pt-hero-act">';
    if ($st['signed']) {
        $h .= '<span class="pt-signed-ok">✅ 今天已签到</span>';
    } else {
        $h .= '<form method="post" style="margin:0">' . csrf_field()
            . '<input type="hidden" name="act" value="signin">'
            . '<input type="hidden" name="back" value="points">'
            . '<button class="pt-sign-btn" type="submit">签到领 ' . (int)$st['next_points'] . ' ' . e($unit) . '</button></form>';
    }
    $h .= '<a class="pt-hero-link" href="' . e($uc . '?a=shop') . '">🛒 积分商城</a>'
        . '<a class="pt-hero-link" href="' . e($uc . '?a=downloads') . '">📥 我的下载</a>'
        . '</div></div>';
    return $h;
}

/** 排行榜卡片（用户中心「签到积分」页 + 模板侧栏共用样式） */
function moe_pt_rank_card($uid = 0)
{
    $uid    = (int)$uid;
    $period = moe_pt_rank_period(isset($_GET['rk']) ? $_GET['rk'] : 'week');
    $board  = moe_pt_rank_board($period, 10);
    $me     = $uid > 0 ? moe_pt_rank_me($uid, $period) : null;
    $unit   = moe_pt_name();
    $uc     = base_url() . 'user';
    $medals = array(1 => '🥇', 2 => '🥈', 3 => '🥉');

    $h = '<div class="card" id="rank"><h2>🏆 签到排行榜</h2>'
        . '<div class="pt-rank-tabs">';
    foreach (moe_pt_rank_periods() as $k => $label) {
        $h .= '<a class="' . ($k === $period ? 'is-on' : '') . '" href="'
            . e($uc . '?a=points&rk=' . $k . '#rank') . '">' . e($label) . '</a>';
    }
    $h .= '<span class="pt-rank-meta">共 ' . (int)$board['signers'] . ' 人参与 · 今日 ' . (int)$board['today'] . ' 人已签</span></div>';

    if (!$board['rows']) {
        $h .= '<p class="hint">' . e(moe_pt_rank_label($period)) . '还没有人签到，来做第一个吧～</p>';
    } else {
        $h .= '<div class="pt-rank-list">';
        foreach ($board['rows'] as $i => $r) {
            $no   = $i + 1;
            $isMe = $uid > 0 && (int)$r['uid'] === $uid;
            $h .= '<div class="pt-rank-row' . ($isMe ? ' is-me' : '') . ($no <= 3 ? ' is-top' : '') . '">'
                . '<span class="pt-rank-no n' . $no . '">' . (isset($medals[$no]) ? $medals[$no] : $no) . '</span>'
                . '<img class="pt-rank-ava" src="' . e($r['avatar']) . '" alt="" width="32" height="32" loading="lazy" decoding="async">'
                . '<div class="pt-rank-info"><b>' . e($r['name']) . ($isMe ? '<i>我</i>' : '') . '</b>'
                . '<span>' . ((int)$r['streak'] > 0 ? '连签 ' . (int)$r['streak'] . ' 天' : '今日未签')
                . ' · 累计 ' . (int)$r['points'] . ' ' . e($unit) . '</span></div>'
                . '<div class="pt-rank-val"><b>' . (int)$r['days'] . '</b><span>天</span></div>'
                . '</div>';
        }
        $h .= '</div>';
    }

    if ($me) {
        $h .= '<div class="pt-rank-me">';
        if ($me['rank'] > 0) {
            $h .= '我的排名 <b>#' . (int)$me['rank'] . '</b> <span>·</span> '
                . e(moe_pt_rank_label($period)) . '签到 <b>' . (int)$me['days'] . '</b> 天'
                . ' <span>·</span> 共 ' . (int)$me['total'] . ' 人上榜';
        } else {
            $h .= '你' . e(moe_pt_rank_label($period)) . '还没有签到，签到后就能上榜啦';
        }
        $h .= '</div>';
    }
    return $h . '</div>';
}

/** 签到积分页 */
function moe_pt_view_points($u)
{
    $uid  = (int)$u['id'];
    $unit = moe_pt_name();
    $st   = moe_pt_sign_status($uid);
    $base = max(0, (int)moe_pt_opt('sign_base', '5'));
    $bonus = max(0, (int)moe_pt_opt('sign_bonus', '2'));
    $cap  = max(0, (int)moe_pt_opt('sign_maxdays', '6'));
    $cmt  = max(0, (int)moe_pt_opt('comment', '2'));
    $cmtLimit = max(0, (int)moe_pt_opt('comment_daily', '3'));
    $left = moe_pt_comment_left($uid);

    $h = moe_pt_balance_card($u);

    // 近 14 天签到条
    $recent = moe_pt_sign_recent($uid, 14);
    $h .= '<div class="card"><h2>📅 最近 14 天签到</h2><div class="pt-week">';
    $wkn = array('日', '一', '二', '三', '四', '五', '六');
    foreach ($recent as $d) {
        $cls = 'pt-day' . ($d['signed'] ? ' is-on' : '') . ($d['today'] ? ' is-today' : '');
        $h .= '<div class="' . $cls . '" title="' . e($d['date']) . ($d['signed'] ? ' · +' . $d['points'] . $unit : '') . '">'
            . '<b>' . (int)$d['day'] . '</b><span>' . e($wkn[$d['week']]) . '</span>'
            . ($d['signed'] ? '<i>+' . (int)$d['points'] . '</i>' : '<i>·</i>')
            . '</div>';
    }
    $h .= '</div><p class="hint">本月已签到 <b>' . (int)moe_pt_sign_month_count($uid) . '</b> 天；'
        . '连签加成按天累加，最多算 ' . (int)$cap . ' 天。</p></div>';

    // 签到排行榜（本周 / 本月 / 总榜）
    $h .= moe_pt_rank_card($uid);

    // 规则
    $h .= '<div class="card"><h2>📖 积分怎么来</h2><div class="pt-rules">'
        . '<div class="pt-rule"><b>每日签到</b><span>+ ' . (int)$base . ' ' . e($unit) . ' 起，连签每天多 +' . (int)$bonus . '</span></div>'
        . '<div class="pt-rule"><b>发表评论</b><span>' . ($cmt > 0 ? '+ ' . (int)$cmt . ' ' . e($unit) . ' / 条，每天最多 ' . (int)$cmtLimit . ' 次（今天还剩 ' . (int)$left . ' 次）' : '暂未开启') . '</span></div>'
        . '<div class="pt-rule"><b>兑换资源</b><span>在商城用' . e($unit) . '兑换，兑换后永久可下载</span></div>'
        . '<div class="pt-rule"><b>积分用途</b><span>积分不可提现、不可转让，仅用于本站资源兑换</span></div>'
        . '</div></div>';

    // 流水
    $logs = moe_pt_logs($uid, 20);
    $h .= '<div class="card"><h2>🧾 积分明细（最近 ' . count($logs) . ' 条）</h2>';
    if (!$logs) {
        $h .= '<p class="hint">还没有积分记录，今天签个到就有啦～</p>';
    } else {
        $h .= '<div class="pt-logs">';
        foreach ($logs as $l) {
            $amt = (int)$l['amount'];
            $h .= '<div class="pt-log">'
                . '<div class="pt-log-main"><b>' . e(moe_pt_type_label((string)$l['type'])) . '</b>'
                . '<span>' . e((string)$l['note']) . '</span></div>'
                . '<div class="pt-log-right"><b class="' . ($amt >= 0 ? 'is-plus' : 'is-minus') . '">' . ($amt >= 0 ? '+' : '') . $amt . '</b>'
                . '<small>' . e(date('m-d H:i', strtotime((string)$l['created_at']))) . '</small></div>'
                . '</div>';
        }
        $h .= '</div>';
    }
    return $h . '</div>';
}

/** 商城页（用户中心页签 & /shop 共用）；2.2.22：二级页签（商城 / 充值 / 积分兑换 / 投稿 / 友链申请）
 *  $subBase：二级页签链接前缀，需以 sub= 结尾（用户中心传 user?a=shop&sub=，独立商城页传 shop?sub=） */
function moe_pt_view_shop($u, $subBase = '')
{
    $uid  = $u ? (int)$u['id'] : 0;
    $unit = moe_pt_name();
    $goods = moe_pt_goods(true);
    $orders = $uid > 0 ? moe_pt_orders($uid) : array();
    $bal = $uid > 0 ? moe_pt_balance($uid) : 0;
    $uc = base_url() . 'user';
    // 2.2.22：从独立的 /shop 页进来时自己带二级页签；从用户中心进来时页签由用户中心统一渲染，避免两层重复
    $standalone = ($subBase !== '');
    if ($subBase === '') $subBase = $uc . '?a=shop&sub=';
    $rcOn = function_exists('moe_rc_on') && moe_rc_on();

    /* ---- 2.2.22：二级页签，功能多了不再全挤在一页 ---- */
    $sub = trim((string)($_GET['sub'] ?? 'shop'));
    if (!in_array($sub, array('shop', 'recharge', 'exchange', 'contribute', 'friendlink'), true)) $sub = 'shop';
    if ($sub === 'recharge' && !$rcOn) $sub = 'shop';
    if ($uid <= 0 && in_array($sub, array('recharge', 'exchange', 'contribute'), true)) $sub = 'shop';

    $h = '';
    if ($uid > 0) {
        $st = moe_pt_sign_status($uid);
        $h .= '<div class="pt-bar">'
            . '<div class="pt-bar-left">我的' . e($unit) . '：<b>' . (int)$bal . '</b>'
            . ($rcOn ? '　💰 ' . e(moe_pt_coin_name()) . '：<b>' . moe_pt_coins($uid) . '</b>' : '')
            . ($st['signed'] ? '<span class="pt-bar-tag is-on">今日已签到</span>' : '<span class="pt-bar-tag">今日未签到</span>') . '</div>'
            . '<div class="pt-bar-right">'
            . ($st['signed'] ? '' : '<form method="post" style="margin:0;display:inline">' . csrf_field()
                . '<input type="hidden" name="act" value="signin"><input type="hidden" name="back" value="shop">'
                . '<button class="btn sm" type="submit">签到 +' . (int)$st['next_points'] . '</button></form>')
            . ($rcOn ? '<a class="btn ghost sm" href="' . e($subBase . 'recharge') . '">💰 充值' . e(moe_pt_coin_name()) . '</a>' : '')
            . '<a class="btn ghost sm" href="' . e($uc . '?a=downloads') . '">📥 我的下载</a>'
            . '<a class="btn ghost sm" href="' . e($uc . '?a=points') . '">🧾 积分明细</a>'
            . '</div></div>';
    } else {
        $h .= '<div class="pt-bar"><div class="pt-bar-left">登录后可用' . e($unit) . '兑换资源</div>'
            . '<div class="pt-bar-right"><a class="btn sm" href="' . e($uc) . '">👤 登录 / 注册</a></div></div>';
    }

    /* 二级页签行（仅独立商城页需要；用户中心已有一级/二级导航） */
    if ($standalone) {
        $subs = array('shop' => '🛒 商城');
        if ($uid > 0 && $rcOn) $subs['recharge'] = '💰 充值';
        if ($uid > 0 && (round((float)setting('points_ex_p2c', '0'), 2) > 0 || round((float)setting('points_ex_c2p', '0'), 2) > 0)) $subs['exchange'] = '🔄 积分兑换';
        if ($uid > 0) $subs['contribute'] = '📝 投稿';
        $subs['friendlink'] = '🔗 友链申请';
        $h .= '<div class="uc-tabs" style="margin:0 0 16px">';
        foreach ($subs as $k => $label) {
            $h .= '<a class="' . ($sub === $k ? 'cur' : '') . '" href="' . e($subBase . $k) . '">' . e($label) . '</a>';
        }
        $h .= '</div>';
    }

    /* ---- 二级页签内容分发 ---- */
    if ($sub === 'recharge') {
        $h .= '<div id="rc-top"></div>' . (function_exists('moe_uc_view_recharge')
            ? moe_uc_view_recharge($u, $uc)
            : '<div class="card"><p class="hint">充值模块缺失：请重新上传 includes/user.php</p></div>');
        return $h;
    }
    if ($sub === 'exchange') {
        $h .= moe_pt_exchange_card($u);
        $h .= '<p class="hint">兑换完成后可到 <a href="' . e($subBase . 'shop') . '">&gt; 商城</a> 消费，充值记录在充值页下方查看。</p>';
        return $h;
    }
    if ($sub === 'contribute') {
        $h .= function_exists('moe_uc_view_contribute')
            ? moe_uc_view_contribute($u)
            : '<div class="card"><p class="hint">投稿模块缺失：请重新上传 includes/user.php</p></div>';
        return $h;
    }
    if ($sub === 'friendlink') {
        $h .= function_exists('moe_uc_view_friendlink')
            ? moe_uc_view_friendlink($u)
            : '<div class="card"><p class="hint">友链模块缺失：请重新上传 includes/user.php</p></div>';
        return $h;
    }

    if (!$goods) {
        $h .= '<div class="card"><p class="hint" style="margin:0">商城还没有上架资源，站长可在后台「积分商城」添加。</p></div>';
        return $h;
    }

    // 2.2.2：分类筛选（后台资源可设置分类）；2.2.7：按后台「分类管理」维护的清单展示，只显示有资源的分类
    $cats = array();
    $managed = array();
    foreach (preg_split('/[\r\n,，]+/u', (string)setting('pt_cats', '')) as $mc) {
        $mc = trim($mc);
        if ($mc !== '') $managed[] = $mc;
    }
    foreach ($goods as $g) {
        $c = trim((string)($g['cat'] ?? ''));
        if ($c !== '') $cats[$c] = ($cats[$c] ?? 0) + 1;
    }
    $catList = array();
    foreach ($managed as $mc) { if (isset($cats[$mc])) $catList[$mc] = $cats[$mc]; }
    foreach ($cats as $c => $n) { if (!isset($catList[$c])) $catList[$c] = $n; }
    $cur = trim((string)($_GET['cat'] ?? ''));
    if ($catList) {
        $h .= '<div class="uc-tabs" style="margin:0 0 16px">';
        $h .= '<a class="' . ($cur === '' ? 'on' : '') . '" href="' . e($uc . '?a=shop') . '">全部 (' . count($goods) . ')</a>';
        foreach ($catList as $c => $n) {
            $h .= '<a class="' . ($cur === $c ? 'on' : '') . '" href="' . e($uc . '?a=shop&cat=' . urlencode($c)) . '">' . e($c) . ' (' . $n . ')</a>';
        }
        $h .= '</div>';
        if ($cur !== '') {
            $filtered = array();
            foreach ($goods as $g) {
                if (trim((string)($g['cat'] ?? '')) === $cur) $filtered[] = $g;
            }
            $goods = $filtered;
            if (!$goods) {
                return $h . '<div class="card"><p class="hint" style="margin:0">该分类下暂无资源。</p></div>';
            }
        }
    }

    $h .= '<div class="pt-goods">';
    foreach ($goods as $g) {
        $gid = (int)$g['id'];
        $price = moe_pt_price_of($g);
        $coinPrice = moe_pt_coins_price_of($g);
        $bought = $uid > 0 && isset($orders[$gid]);
        // 2.2.5：关联文章 —— 封面和标题可点击前往（未关联时不可点）
        $postUrl = moe_pt_post_url_of($g['post_id'] ?? 0);
        $coverHtml = moe_pt_cover_html($g);
        if ($postUrl !== '') {
            $coverHtml = '<a href="' . e($postUrl) . '" target="_blank" rel="noopener" style="display:block;color:inherit;text-decoration:none">' . $coverHtml . '</a>';
        }
        $h .= '<div class="pt-goods-card">' . $coverHtml;
        if ($bought) $h .= '<span class="pt-goods-badge">已兑换</span>';
        $titleHtml = e((string)$g['title']);
        if ($postUrl !== '') {
            $titleHtml = '<a href="' . e($postUrl) . '" target="_blank" rel="noopener" style="color:inherit;text-decoration:none" title="前往文章介绍">'
                . $titleHtml . ' <span style="font-size:11px;opacity:.65">↗</span></a>';
        }
        $h .= '<div class="pt-goods-body">'
            . '<h3>' . $titleHtml . '</h3>'
            . '<p>' . e((string)$g['summary'] !== '' ? (string)$g['summary'] : '用' . $unit . '兑换后可下载') . '</p>'
            . '<div class="pt-goods-meta"><span class="pt-price">' . moe_pt_price_label_of($g)
            . '</span><span class="pt-dl-num">📥 ' . (int)$g['downloads'] . '</span></div>'
            . '<div class="pt-goods-act">';
        // 2.2.7：定价三选一 —— 按资源支持的币种渲染兑换按钮
        $canPoints = moe_pt_price_of($g) !== null;
        $canCoins  = moe_pt_coins_price_of($g) !== null;
        if ($bought) {
            // 2.2.22：授权码商品买过之后，重点是「看授权码 + 下程序」
            if (trim((string)($g['cat'] ?? '')) === '授权码') {
                $h .= '<a class="btn sm" href="' . e($uc . '?a=auth') . '">🔑 查看授权码</a>'
                    . '<a class="btn ghost sm" href="' . e(moe_pt_download_url($gid)) . '">⬇ 下载程序</a>';
            } else {
                $h .= '<a class="btn sm" href="' . e(moe_pt_download_url($gid)) . '">⬇ 下载资源</a>';
            }
        } elseif ($uid <= 0) {
            $h .= '<a class="btn ghost sm" href="' . e($uc) . '">登录后兑换</a>';
        } elseif ($uid > 0 && trim((string)($g['cat'] ?? '')) === '授权码') {
            // 2.2.22：授权码商品 —— 购买时填写绑定域名，付款成功自动签发授权码并进「我的授权码」
            $h .= '<form method="post" style="width:100%">' . csrf_field()
                . '<input type="hidden" name="act" value="buy"><input type="hidden" name="gid" value="' . $gid . '"><input type="hidden" name="back" value="shop">'
                . '<div class="field" style="margin:0 0 8px"><input type="text" name="auth_domain" required placeholder="绑定域名，如 example.com" style="width:100%"></div>';
            if ($canPoints && $canCoins) {
                $h .= '<div class="field" style="margin:0 0 8px"><select name="currency" style="width:100%">'
                    . '<option value="points">' . e($unit) . '支付（' . moe_pt_num($price) . '）</option>'
                    . '<option value="coins">' . e(moe_pt_coin_name()) . '支付（' . moe_pt_num($coinPrice) . '）</option></select></div>';
                $h .= '<button class="btn sm" type="submit" style="width:100%">🔑 购买授权码</button>';
            } elseif ($canPoints) {
                $h .= '<input type="hidden" name="currency" value="points">'
                    . '<button class="btn sm" type="submit" style="width:100%">🔑 购买授权码（' . moe_pt_num($price) . ' ' . e($unit) . '）</button>';
            } elseif ($canCoins) {
                $h .= '<input type="hidden" name="currency" value="coins">'
                    . '<button class="btn sm" type="submit" style="width:100%">🔑 购买授权码（' . moe_pt_num($coinPrice) . ' ' . e(moe_pt_coin_name()) . '）</button>';
            } else {
                $h .= '<button class="btn ghost sm" type="button" disabled style="width:100%">站长还没设置价格</button>';
            }
            $h .= '<p class="hint" style="margin:6px 0 0">购买后自动签发永久授权码并绑定该域名（填过的域名不能重复），购买完成请下载程序部署。</p></form>';
        } elseif ($canPoints && $canCoins && $price > 0 && function_exists('moe_rc_on') && moe_rc_on()) {
            // 双币同售：自动识别余额 —— 哪种够用就高亮哪种；金币不够时按钮直接变「充值金币」（点击到商城充值区扫码）
            $coinBal = moe_pt_coins($uid);
            $coinShort = round((float)$coinPrice - (float)$coinBal, 2) > 0;
            $h .= '<div style="display:flex;gap:6px;flex-wrap:wrap">'
                . '<form method="post" style="margin:0">' . csrf_field()
                . '<input type="hidden" name="act" value="buy"><input type="hidden" name="gid" value="' . $gid . '">'
                . '<input type="hidden" name="currency" value="points"><input type="hidden" name="back" value="shop">'
                . '<button class="btn ' . ($bal < $price ? 'ghost' : 'sm') . '" type="submit">' . ($bal >= $price ? '🎁 用' . moe_pt_num($price) . ' ' . e($unit) . '兑换' : '🎁 用' . e($unit) . '兑换（差 ' . moe_pt_num(round($price - $bal, 2)) . '）') . '</button></form>'
                . ($coinShort
                    ? '<a class="btn ghost sm" href="' . e($subBase . 'recharge') . '" title="当前' . e(moe_pt_coin_name()) . '余额 ' . moe_pt_num($coinBal) . '">💰 充值' . e(moe_pt_coin_name()) . '兑换（差 ' . moe_pt_num(round((float)$coinPrice - (float)$coinBal, 2)) . '）</a>'
                    : '<form method="post" style="margin:0">' . csrf_field()
                    . '<input type="hidden" name="act" value="buy"><input type="hidden" name="gid" value="' . $gid . '">'
                    . '<input type="hidden" name="currency" value="coins"><input type="hidden" name="back" value="shop">'
                    . '<button class="btn ghost sm" type="submit" title="' . e(moe_pt_coin_name()) . '余额 ' . moe_pt_num($coinBal) . '">💰 用' . moe_pt_num($coinPrice) . ' ' . e(moe_pt_coin_name()) . ' 兑换</button></form>')
                . '</div>';
        } elseif (!$canCoins && $canPoints && round($price - $bal, 2) > 0) {
            // 仅萌豆定价且余额不足：引导去赚积分（积分靠签到 / 评论获得，不是充值）
            $h .= '<a class="btn ghost sm" href="' . e($uc . '?a=points') . '">还差 ' . moe_pt_num(round($price - $bal, 2)) . ' ' . e($unit) . '，去赚' . e($unit) . '</a>';
        } elseif ($canCoins && !$canPoints && function_exists('moe_rc_on') && moe_rc_on()) {
            // 仅金币定价：只出金币兑换按钮
            $h .= '<form method="post" style="margin:0">' . csrf_field()
                . '<input type="hidden" name="act" value="buy"><input type="hidden" name="gid" value="' . $gid . '">'
                . '<input type="hidden" name="currency" value="coins"><input type="hidden" name="back" value="shop">'
                . '<button class="btn sm" type="submit">💰 用' . moe_pt_num($coinPrice) . ' ' . e(moe_pt_coin_name()) . ' 兑换</button></form>';
        } elseif ($canPoints) {
            $h .= '<form method="post" style="margin:0">' . csrf_field()
                . '<input type="hidden" name="act" value="buy"><input type="hidden" name="gid" value="' . $gid . '">'
                . '<input type="hidden" name="currency" value="points"><input type="hidden" name="back" value="shop">'
                . '<button class="btn sm" type="submit">' . ($price > 0 ? '兑换 ' . moe_pt_num($price) . ' ' . e($unit) : '免费领取') . '</button></form>';
        } elseif ($canCoins) {
            // 仅金币但支付开关未开 —— 提示用金币
            $h .= '<form method="post" style="margin:0">' . csrf_field()
                . '<input type="hidden" name="act" value="buy"><input type="hidden" name="gid" value="' . $gid . '">'
                . '<input type="hidden" name="currency" value="coins"><input type="hidden" name="back" value="shop">'
                . '<button class="btn sm" type="submit">💰 用' . moe_pt_num($coinPrice) . ' ' . e(moe_pt_coin_name()) . ' 兑换</button></form>';
        }
        $h .= '</div></div></div>';
    }
    $h .= '</div><p class="hint" style="margin-top:14px">兑换后到「我的下载」随时重新下载，不限次数；'
        . '资源仅供个人学习使用。</p>';
    return $h;
}

/** 下载中心（我的下载） */
function moe_pt_view_downloads($u)
{
    $uid = (int)$u['id'];
    $unit = moe_pt_name();
    $orders = moe_pt_orders($uid);
    $all = moe_pt_goods(true);
    $history = moe_pt_download_history($uid, 8);

    // 2.2.7：已兑换列表改为商城同款卡片网格
    $h = '<div class="card"><h2>📥 我已兑换的资源（' . count($orders) . '）</h2>';
    if (!$orders) {
        $h .= '<p class="hint">还没有兑换记录。<a href="' . e(base_url() . 'user?a=shop') . '">去积分商城看看 →</a></p>';
    } else {
        $h .= '<div class="pt-goods">';
        foreach ($orders as $gid => $o) {
            $title = trim((string)($o['title'] ?? ''));
            $h .= '<div class="pt-goods-card">'
                . moe_pt_cover_html(array(
                    'title' => $title !== '' ? $title : '资源',
                    'cover' => (string)($o['cover'] ?? ''),
                ))
                . '<div class="pt-goods-body"><h3>' . e($title !== '' ? $title : '（资源已删除）') . '</h3>'
                . '<div class="pt-goods-meta"><span class="pt-price">兑换于 ' . e(date('m-d H:i', strtotime((string)$o['created_at']))) . '</span>'
                . '<span class="pt-dl-num">💎 ' . moe_pt_num($o['price']) . ' ' . e($unit) . '</span></div>'
                . '<div class="pt-goods-act">';
            if ($title !== '') {
                $h .= '<a class="btn sm" href="' . e(moe_pt_download_url($gid)) . '">⬇ 下载</a>';
            }
            $h .= '</div></div></div>';
        }
        $h .= '</div>';
    }
    $h .= '</div>';

    // 全部资源与拥有状态（2.2.7：商城同款卡片网格，带封面与已兑换角标）
    $h .= '<div class="card"><h2>🛒 全部资源（' . count($all) . '）</h2>';
    if (!$all) {
        $h .= '<p class="hint">商城还没有上架资源。</p>';
    } else {
        $h .= '<div class="pt-goods">';
        foreach ($all as $g) {
            $gid = (int)$g['id'];
            $owned = isset($orders[$gid]);
            $h .= '<div class="pt-goods-card">' . moe_pt_cover_html($g);
            if ($owned) $h .= '<span class="pt-goods-badge">已兑换</span>';
            $h .= '<div class="pt-goods-body"><h3>' . e((string)$g['title']) . '</h3>'
                . '<div class="pt-goods-meta"><span class="pt-price">'
                . e(moe_pt_price_label_of($g))
                . '</span><span class="pt-dl-num">📥 ' . (int)$g['downloads'] . '</span></div>'
                . '<div class="pt-goods-act">';
            if ($owned) {
                $h .= '<a class="btn ghost sm" href="' . e(moe_pt_download_url($gid)) . '">⬇ 下载</a>';
            } else {
                $h .= '<a class="btn ghost sm" href="' . e(base_url() . 'user?a=shop') . '">🛒 去兑换</a>';
            }
            $h .= '</div></div></div>';
        }
        $h .= '</div>';
    }
    $h .= '</div>';

    if ($history) {
        $h .= '<div class="card"><h2>🕘 最近下载记录</h2><div class="pt-logs">';
        foreach ($history as $d) {
            $t = trim((string)($d['title'] ?? ''));
            $h .= '<div class="pt-log"><div class="pt-log-main"><b>' . e($t !== '' ? $t : '（资源已删除）') . '</b>'
                . '<span>下载记录</span></div>'
                . '<div class="pt-log-right"><small>' . e(date('m-d H:i', strtotime((string)$d['created_at']))) . '</small></div></div>';
        }
        $h .= '</div></div>';
    }
    return $h;
}

/** 独立商城页 /shop */
function moe_pt_shop_page()
{
    $u = current_user();
    $unit = moe_pt_name();

    /* 2.2.10：商城页自己的互兑提交（act=ex_p2c / ex_c2p），处理完回到商城 */
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $act = (string)($_POST['act'] ?? '');
        if (($act === 'ex_p2c' || $act === 'ex_c2p') && $u) {
            csrf_verify();
            $r = moe_pt_exchange_run($act, (int)$u['id']);
            moe_uc_flash((string)$r[1], !empty($r[0]) ? 'ok' : 'bad');
            redirect(base_url() . 'shop');
        }
    }

    if (!moe_pt_shop_on()) {
        $body = '<div class="card"><h2>积分商城暂未开放</h2>'
              . '<p class="hint" style="font-size:13px">站长可以在后台「积分商城」里开启商城并上架资源。</p>'
              . '<p style="margin-top:14px"><a class="btn ghost sm" href="' . e(base_url()) . '">← 返回首页</a></p></div>';
    } else {
        $body = moe_pt_view_shop($u, base_url() . 'shop?sub=');
    }
    if (function_exists('moe_uc_shell')) {
        moe_uc_shell('积分商城', '用' . $unit . '兑换本站资源，兑换后永久可下载', $body, $u);
    } else {
        echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
           . '<title>积分商城</title></head><body>' . $body . '</body></html>';
    }
    exit;
}

/**
 * 下载端点：校验登录 + 兑换记录 → 记一次下载 → 跳转/流式输出
 * @param int $gid 商品 id
 */
function moe_pt_download_serve($gid)
{
    $gid = (int)$gid;
    $uid = moe_pt_uid();
    $unit = moe_pt_name();

    if ($uid <= 0) {
        redirect(base_url() . 'user?a=login&back=shop');
    }

    $g = moe_pt_good($gid);
    if (!$g) {
        moe_pt_error_page('资源不存在', '这个资源可能已经被删除了。', base_url() . 'user?a=shop', '去积分商城');
    }
    if (!moe_pt_has_bought($uid, $gid)) {
        moe_pt_error_page('还没有兑换这个资源', '请先在积分商城用' . $unit . '兑换，兑换成功后才能下载。',
            base_url() . 'user?a=shop', '去兑换');
    }

    $t = moe_pt_download_target($uid, $gid);
    if (!$t) {
        moe_pt_error_page('下载地址不可用', '资源没有配置下载地址，或者地址格式不正确，请联系站长。',
            base_url() . 'user?a=downloads', '返回我的下载');
    }

    moe_pt_download_record($uid, $gid);

    if ($t['type'] === 'remote') {
        // 2.2.23：外链是「直链文件」时代理流式输出并强制 attachment 头 —— 用户点「下载」浏览器直接弹保存框，
        // 不再跳到文件页；网盘「页面」链接（蓝奏/微云分享页）无法代理，仍然 302 跳转
        $ext = strtolower(pathinfo((string)parse_url((string)$t['url'], PHP_URL_PATH), PATHINFO_EXTENSION));
        $directExts = array('zip', 'rar', '7z', 'tar', 'gz', 'tgz', 'bz2', 'xz', 'apk', 'exe', 'dmg', 'pkg', 'iso',
                            'mp3', 'mp4', 'webm', 'pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'txt', 'md',
                            'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico', 'ttf', 'woff', 'woff2', 'otf');
        if ($ext !== '' && in_array($ext, $directExts, true) && function_exists('curl_init')) {
            $tmp = @tmpfile();   // 先落到临时文件：确认拿到的是真文件再输出，避免把网盘 403 错误页存成"文件"
            if ($tmp) {
                $ch = curl_init((string)$t['url']);
                curl_setopt_array($ch, array(
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS      => 5,
                    CURLOPT_TIMEOUT        => 0,
                    CURLOPT_CONNECTTIMEOUT => 10,
                    CURLOPT_SSL_VERIFYPEER => false,
                    CURLOPT_FILE           => $tmp,
                    CURLOPT_HTTPHEADER     => array('User-Agent: Mozilla/5.0 MoeZ/' . MOE_VERSION),
                ));
                curl_exec($ch);
                $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                $stat = @fstat($tmp);
                $size = $stat ? (int)$stat['size'] : 0;
                if ($code > 0 && $code < 400 && $size > 0) {
                    while (ob_get_level() > 0) @ob_end_clean();
                    $name = rawurlencode((string)$t['name'] !== '' ? (string)$t['name'] : ('download.' . $ext));
                    header('Content-Type: application/octet-stream');
                    header('Content-Length: ' . $size);
                    header('Content-Disposition: attachment; filename="' . $name . '"; filename*=UTF-8\'\'' . $name);
                    header('X-Content-Type-Options: nosniff');
                    header('Cache-Control: no-store');
                    rewind($tmp);
                    @fpassthru($tmp);
                    fclose($tmp);
                    exit;
                }
                fclose($tmp);
            }
            // 代理失败（防盗链 / 断链 / 网络异常）→ 回退 302 跳转，用户至少还能手动去网盘取
        }
        header('Location: ' . $t['url'], true, 302);
        exit;
    }

    // 站内文件：直接流式输出，避免浏览器把 zip 当成文本打开
    $path = (string)$t['path'];
    $name = basename($path);
    $size = @filesize($path);
    if (!is_file($path) || $size === false) {
        moe_pt_error_page('文件已被删除', '这个资源文件不在服务器上了，请联系站长补档。',
            base_url() . 'user?a=downloads', '返回我的下载');
    }
    if (function_exists('set_time_limit')) @set_time_limit(0);
    while (ob_get_level() > 0) @ob_end_clean();
    header('Content-Type: application/octet-stream');
    header('Content-Length: ' . $size);
    header('Content-Disposition: attachment; filename="' . rawurlencode($name) . '"; filename*=UTF-8\'\'' . rawurlencode($name));
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: no-store');
    $fp = @fopen($path, 'rb');
    if ($fp) {
        while (!feof($fp)) {
            $buf = fread($fp, 262144);
            if ($buf === false) break;
            echo $buf;
            @flush();
        }
        fclose($fp);
    }
    exit;
}

/** 统一的错误页（下载/兑换失败时用，样式与用户中心一致） */
function moe_pt_error_page($title, $desc, $backUrl, $backText = '返回')
{
    http_response_code(200);
    $body = '<div class="card" style="text-align:center">'
          . '<div style="font-size:42px;line-height:1">🔒</div>'
          . '<h2 style="justify-content:center;margin-top:12px">' . e($title) . '</h2>'
          . '<p class="hint" style="font-size:13.5px;margin:10px 0 20px">' . e($desc) . '</p>'
          . '<a class="btn" href="' . e($backUrl) . '">' . e($backText) . '</a>'
          . ' <a class="btn ghost" href="' . e(base_url()) . '">返回首页</a></div>';
    if (function_exists('moe_uc_shell')) {
        moe_uc_shell($title, '', $body, current_user());
    } else {
        echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><title>' . e($title) . '</title></head><body>' . $body . '</body></html>';
    }
    exit;
}
