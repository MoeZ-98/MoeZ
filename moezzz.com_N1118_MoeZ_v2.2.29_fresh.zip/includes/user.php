<?php
/**
 * MoeZ 2.0.0 · 用户中心 / 多作者体系
 *
 * 三种角色：
 *   admin   站长   —— 后台全部权限 + 用户管理
 *   author  作者   —— 可进后台写文章 / 管理内容，不能改站点设置 / 模板 / 用户
 *   member  会员   —— 仅前台：登录、改资料、发评论、看自己的评论
 *
 * 会话统一用 $_SESSION['moe_uid']；is_admin() 只放行 admin / author（见 functions.php）。
 * 前台 /user 是完全独立的页面，不依赖任何一套模板；/author/{id} 为公开作者主页。
 */

/* ============================================================
   一、数据迁移（幂等，字段由 moe_ensure_schema() 补齐）
   ============================================================ */
function moe_users_upgrade()
{
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        if ((string)setting('user_schema_v2', '') === '1') return;
        $t = moe_table('users');
        // 老站点只有站长一个账号：最小 id 升级为 admin，其余保持 member
        $first = row('SELECT id FROM ' . $t . ' ORDER BY id ASC LIMIT 1');
        if ($first) {
            q('UPDATE ' . $t . " SET role = 'admin', status = 'active' WHERE id = ?", array((int)$first['id']));
            q('UPDATE ' . $t . " SET status = 'active' WHERE status IS NULL OR status = ''");
        }
        setting_set('user_schema_v2', '1');
    } catch (Throwable $e) {
        // 表未就绪 / 字段还没补上：下次请求自动重试
    }
}

/* ============================================================
   二、角色与权限
   ============================================================ */
function moe_user_role($u = null)
{
    if ($u === null) $u = current_user();
    if (!$u) return '';
    if (!array_key_exists('role', (array)$u)) return 'admin';   // 老结构兜底
    $r = trim((string)$u['role']);
    return $r !== '' ? $r : 'admin';
}

function moe_user_active($u = null)
{
    if ($u === null) $u = current_user();
    if (!$u) return false;
    return !isset($u['status']) || (string)$u['status'] === 'active';
}

function moe_is_owner()
{
    $u = current_user();
    return $u && moe_user_role($u) === 'admin' && moe_user_active($u);
}

function moe_user_role_label($role)
{
    $map = array('admin' => '站长', 'author' => '作者', 'member' => '会员');
    return isset($map[$role]) ? $map[$role] : '会员';
}

/** 后台页面级守卫：作者只能访问内容类页面，会员一律进不了后台 */
function moe_admin_guard()
{
    if (moe_is_owner()) return;
    $script   = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $ownerOnly = array('settings.php', 'themes.php', 'theme-settings.php', 'users.php',
                       'links.php', 'categories.php', 'tags.php', 'spiders.php', 'resources.php',
                       'plugins.php', 'update-check.php', 'points.php', 'theme-shop.php');   // 2.1.0
    if (!in_array($script, $ownerOnly, true)) return;
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    echo '<div style="max-width:480px;margin:12vh auto;padding:28px;font:15px/1.8 -apple-system,\'PingFang SC\',\'Microsoft YaHei\',sans-serif;'
       . 'background:#fff;border-radius:18px;box-shadow:0 14px 40px rgba(146,120,200,.18);color:#4a4060;text-align:center">'
       . '<div style="font-size:38px">🔒</div><h2 style="margin:8px 0">没有访问权限</h2>'
       . '<p style="color:#8e83a5">该页面仅站长可用。你可以继续管理文章，或返回前台。</p>'
       . '<p style="margin-top:18px"><a href="index.php" style="color:#8f7bff;text-decoration:none">← 返回仪表盘</a>　'
       . '<a href="' . e(base_url()) . '" style="color:#8f7bff;text-decoration:none">返回前台 ↗</a></p></div>';
    exit;
}

/* ============================================================
   三、用户读取
   ============================================================ */
function moe_user_by($id)
{
    $id = (int)$id;
    if ($id <= 0) return null;
    try {
        return row('SELECT * FROM ' . moe_table('users') . ' WHERE id = ?', array($id));
    } catch (Throwable $e) { return null; }
}

function moe_user_display($u)
{
    if (!$u) return '访客';
    $n = trim((string)($u['nickname'] ?? ''));
    if ($n === '') $n = trim((string)($u['username'] ?? ''));
    return $n !== '' ? $n : '用户' . (int)$u['id'];
}

function moe_user_avatar($u)
{
    $a = $u ? trim((string)($u['avatar'] ?? '')) : '';
    if ($a === '') $a = trim((string)setting('site_avatar', ''));
    if ($a === '') $a = 'templates/default/assets/avatar.svg';
    return media_url($a);
}

function moe_user_url($u)
{
    return base_url() . 'author/' . ($u ? (int)$u['id'] : 0);
}

function moe_user_stats($uid)
{
    $uid = (int)$uid;
    $out = array('posts' => 0, 'comments' => 0);
    try {
        $out['posts'] = (int)one('SELECT COUNT(*) FROM ' . moe_table('posts')
            . " WHERE user_id = ? AND type = 'post' AND status = 'published'", array($uid));
        $out['comments'] = (int)one('SELECT COUNT(*) FROM ' . moe_table('comments')
            . ' WHERE user_id = ?', array($uid));
    } catch (Throwable $e) { /* 字段未就绪时忽略 */ }
    return $out;
}

/**
 * 2.1.2：会员编辑自己发表的评论
 * 归属判定：user_id 直接匹配；历史游客评论（user_id=0）按邮箱匹配
 * @return array[bool, string]
 */
function moe_user_edit_comment($uid, $email, $cid, $content)
{
    $uid     = (int)$uid;
    $cid     = (int)$cid;
    $content = trim((string)$content);
    if (setting('comment_edit', '1') !== '1') return array(false, '本站未开启评论编辑功能');
    if ($content === '' || mb_strlen($content, 'UTF-8') > 2000) return array(false, '评论内容需要 1-2000 个字');
    if ($uid <= 0 || $cid <= 0) return array(false, '请先登录');

    $cm = null;
    try {
        $cm = row('SELECT * FROM ' . moe_table('comments') . ' WHERE id = ?', array($cid));
    } catch (Throwable $e) { $cm = null; }
    $mine = $cm && ((int)$cm['user_id'] === $uid
        || ((int)$cm['user_id'] === 0 && trim((string)$cm['email']) !== ''
            && strtolower(trim((string)$cm['email'])) === strtolower(trim((string)$email))));
    if (!$mine) return array(false, '只能编辑自己发表的评论');

    q('UPDATE ' . moe_table('comments') . ' SET content = ? WHERE id = ?', array($content, $cid));
    if (function_exists('moe_content_changed')) moe_content_changed();
    return array(true, '评论已更新 ✏️');
}

/* ============================================================
   四、登录 / 注册 / 资料
   ============================================================ */
function moe_user_login($name, $pass, $allowMember = true)
{
    $name = trim((string)$name);
    $pass = (string)$pass;
    if ($name === '' || $pass === '') return array(false, '请填写用户名和密码', null);
    $u = null;
    try {
        $u = row('SELECT * FROM ' . moe_table('users')
            . ' WHERE username = ? OR email = ? ORDER BY id ASC LIMIT 1', array($name, $name));
    } catch (Throwable $e) { /* 老表无 email 时回落 */ }
    if (!$u) {
        try { $u = row('SELECT * FROM ' . moe_table('users') . ' WHERE username = ?', array($name)); }
        catch (Throwable $e) { $u = null; }
    }
    if (!$u || !password_verify($pass, (string)$u['password'])) {
        usleep(350000);   // 简单防爆破
        return array(false, '用户名或密码不正确', null);
    }
    if (!moe_user_active($u)) return array(false, '该账号已被停用，请联系站长', null);
    if (!$allowMember && moe_user_role($u) === 'member') {
        return array(false, '会员账号请从前台「用户中心」登录', null);
    }
    if (session_status() === PHP_SESSION_NONE) @session_start();
    @session_regenerate_id(true);
    $_SESSION['moe_uid']    = (int)$u['id'];
    $_SESSION['moe_welcome'] = 1;
    try {
        q('UPDATE ' . moe_table('users') . ' SET last_login = NOW() WHERE id = ?', array((int)$u['id']));
    } catch (Throwable $e) { /* 字段未就绪时忽略 */ }
    return array(true, '登录成功', $u);
}

function moe_user_logout()
{
    $_SESSION = array();
    if (session_status() !== PHP_SESSION_NONE) @session_destroy();
}

function moe_user_register($d)
{
    if (setting('user_register', '0') !== '1') return array(false, '本站暂未开放注册', 0);
    $name  = trim((string)($d['username'] ?? ''));
    $nick  = trim((string)($d['nickname'] ?? ''));
    $mail  = trim((string)($d['email'] ?? ''));
    $pass  = (string)($d['password'] ?? '');
    $pass2 = (string)($d['password2'] ?? '');
    if (!preg_match('/^[\x{4e00}-\x{9fa5}A-Za-z0-9_]{2,32}$/u', $name)) {
        return array(false, '用户名需 2~32 位，支持中文、字母、数字、下划线', 0);
    }
    if ($pass === '' || strlen($pass) < 6) return array(false, '密码至少 6 位', 0);
    if ($pass !== $pass2) return array(false, '两次输入的密码不一致', 0);
    if ($mail !== '' && !filter_var($mail, FILTER_VALIDATE_EMAIL)) return array(false, '邮箱格式不正确', 0);
    if (mb_strlen($nick, 'UTF-8') > 30) return array(false, '昵称最多 30 个字', 0);
    // 算术验证码
    $ans = isset($_SESSION['moe_uc_cap']) ? (int)$_SESSION['moe_uc_cap'] : -1;
    unset($_SESSION['moe_uc_cap']);
    if ($ans < 0 || (int)($d['captcha'] ?? 0) !== $ans) return array(false, '验证答案不正确，请重新计算', 0);
    $t = moe_table('users');
    if (row('SELECT id FROM ' . $t . ' WHERE username = ?', array($name))) return array(false, '该用户名已被占用', 0);
    if ($mail !== '' && row('SELECT id FROM ' . $t . ' WHERE email = ?', array($mail))) {
        return array(false, '该邮箱已被注册', 0);
    }
    // 注册一律是会员，角色提升只能由站长在后台操作
    try {
        q('INSERT INTO ' . $t . ' (username,password,email,nickname,role,status,created_at) VALUES (?,?,?,?,?,?,NOW())',
            array($name, password_hash($pass, PASSWORD_DEFAULT), $mail, $nick !== '' ? $nick : $name, 'member', 'active'));
    } catch (Throwable $e) {
        return array(false, '注册失败，请稍后再试', 0);
    }
    $id = function_exists('last_id') ? (int)last_id() : 0;
    return array(true, '注册成功，现在可以登录啦', $id);
}

function moe_user_save_profile($uid, $d)
{
    $uid  = (int)$uid;
    $nick = trim((string)($d['nickname'] ?? ''));
    $mail = trim((string)($d['email'] ?? ''));
    $ava  = trim((string)($d['avatar'] ?? ''));
    $bio  = trim((string)($d['bio'] ?? ''));
    $qq   = trim((string)($d['qq'] ?? ''));
    $site = trim((string)($d['site'] ?? ''));
    if ($nick !== '' && mb_strlen($nick, 'UTF-8') > 30) return array(false, '昵称最多 30 个字');
    if ($mail !== '' && !filter_var($mail, FILTER_VALIDATE_EMAIL)) return array(false, '邮箱格式不正确');
    if ($qq !== '' && !preg_match('/^\d{5,12}$/', $qq)) return array(false, 'QQ 号需为 5~12 位数字');
    if ($site !== '' && !preg_match('#^https?://#i', $site) && strpos($site, '/') !== 0) $site = 'https://' . $site;
    if (mb_strlen($bio, 'UTF-8') > 120) $bio = mb_substr($bio, 0, 120, 'UTF-8');
    $t = moe_table('users');
    if ($mail !== '' && row('SELECT id FROM ' . $t . ' WHERE email = ? AND id <> ?', array($mail, $uid))) {
        return array(false, '该邮箱已被其他账号使用');
    }
    try {
        q('UPDATE ' . $t . ' SET nickname=?, email=?, avatar=?, bio=?, qq=?, site=? WHERE id=?',
            array($nick, $mail, $ava, $bio, $qq, $site, $uid));
    } catch (Throwable $e) {
        return array(false, '资料保存失败，请稍后再试');
    }
    return array(true, '资料已保存 ✅');
}

function moe_user_change_password($uid, $cur, $new, $new2)
{
    $u = moe_user_by($uid);
    if (!$u) return array(false, '用户不存在');
    if (!password_verify((string)$cur, (string)$u['password'])) return array(false, '当前密码不正确');
    if (strlen((string)$new) < 6) return array(false, '新密码至少 6 位');
    if ($new !== $new2) return array(false, '两次输入的新密码不一致');
    q('UPDATE ' . moe_table('users') . ' SET password = ? WHERE id = ?',
        array(password_hash($new, PASSWORD_DEFAULT), (int)$uid));
    return array(true, '密码已修改 ✅ 下次登录请使用新密码');
}

/** 修改登录账户（用户名 / 密码），必须验证当前密码。返回 array(ok, msg, warn) */
function moe_user_change_account($uid, $d)
{
    $u = moe_user_by($uid);
    if (!$u) return array(false, '用户不存在', false);
    if (!password_verify((string)($d['cur_pass'] ?? ''), (string)$u['password'])) {
        return array(false, '当前密码不正确，无法修改账户信息', false);
    }
    $newName = trim((string)($d['username'] ?? ''));
    $newPass = (string)($d['new_pass'] ?? '');
    $newPass2 = (string)($d['new_pass2'] ?? '');
    $upd = array(); $args = array();
    if ($newName !== '' && $newName !== (string)$u['username']) {
        if (!preg_match('/^[\x{4e00}-\x{9fa5}A-Za-z0-9_]{2,32}$/u', $newName)) {
            return array(false, '用户名需 2~32 位，仅支持中文、字母、数字、下划线', false);
        }
        if (row('SELECT id FROM ' . moe_table('users') . ' WHERE username = ? AND id <> ?', array($newName, (int)$uid))) {
            return array(false, '用户名「' . $newName . '」已被占用', false);
        }
        $upd[] = 'username = ?'; $args[] = $newName;
    }
    if ($newPass !== '') {
        if (strlen($newPass) < 6) return array(false, '新密码至少 6 位', false);
        if ($newPass !== $newPass2) return array(false, '两次输入的新密码不一致', false);
        $upd[] = 'password = ?'; $args[] = password_hash($newPass, PASSWORD_DEFAULT);
    }
    if (empty($upd)) return array(false, '没有需要修改的内容（改用户名或填新密码才会生效）', true);
    $args[] = (int)$uid;
    q('UPDATE ' . moe_table('users') . ' SET ' . implode(', ', $upd) . ' WHERE id = ?', $args);
    return array(true, '账户信息已更新 ✅ 下次登录请使用新的用户名 / 密码', false);
}

/* ============================================================
   五、社交与展示（2.0.1：从「站点设置」移植到用户中心）
   ============================================================ */

/**
 * 清洗社交链接 JSON：过滤空行、限长、拦截危险协议。
 * 数据仍存 settings.social_links，前台 moe_social_list() / 模板无需改动。
 */
function moe_social_clean($raw)
{
    $arr = json_decode((string)$raw, true);
    $out = array();
    if (is_array($arr)) {
        foreach ($arr as $r) {
            if (!is_array($r)) continue;
            $url = trim((string)($r['url'] ?? ''));
            if ($url === '') continue;
            // 拦掉 javascript:/data: 之类，其它（含历史站点的裸域名）保持兼容
            if (preg_match('#^\s*(javascript|data|vbscript|file)\s*:#i', $url)) $url = '#';
            $out[] = array(
                'name' => mb_substr(trim((string)($r['name'] ?? '')), 0, 30, 'UTF-8'),
                'url'  => mb_substr($url, 0, 255, 'UTF-8'),
                'icon' => mb_substr(trim((string)($r['icon'] ?? '')), 0, 255, 'UTF-8'),
            );
        }
    }
    return json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

/** 只读预览：给非站长与前台用户中心看，胶囊式链接列表 */
function moe_social_preview_html($list = null)
{
    if ($list === null) $list = function_exists('moe_social_list') ? moe_social_list() : array();
    if (empty($list)) return '<p class="hint">还没有添加社交链接，站长可在后台「用户中心」添加。</p>';
    $h = '<div style="display:flex;gap:9px;flex-wrap:wrap">';
    foreach ($list as $r) {
        $url  = (string)($r['url'] ?? '');
        if (preg_match('#^\s*(javascript|data|vbscript|file)\s*:#i', $url)) $url = '#';
        $icon = trim((string)($r['icon'] ?? ''));
        $name = (string)($r['name'] ?? '');
        // 2.1.5：图标为空或 emoji 时，按名称去 assets/social/ 自动匹配图片
        $img  = function_exists('moe_social_icon') ? moe_social_icon($icon, $name) : '';
        if ($img === '' && function_exists('social_icon_url')) $img = social_icon_url($icon);
        if ($img !== '') {
            $ico = '<img src="' . e($img) . '" alt="" style="width:17px;height:17px;border-radius:5px;object-fit:cover">';
        } else {
            $ico = '<span>' . e($icon !== '' ? $icon : '🔗') . '</span>';
        }
        $h .= '<a href="' . e($url) . '" target="_blank" rel="noopener" '
            . 'style="display:inline-flex;align-items:center;gap:6px;padding:8px 13px;border:1.5px solid #eee7f5;'
            . 'border-radius:999px;background:#fdfcff;color:#5b4d78;font-size:13px;text-decoration:none;'
            . 'max-width:100%;overflow-wrap:anywhere">'
            . $ico . '<span>' . e((string)($r['name'] ?? '链接')) . '</span></a>';
    }
    return $h . '</div>';
}

/**
 * 社交链接动态编辑器：输出 HTML + 自带脚本，放进 <form> 内即可。
 * 支持 新增 / 删除 / 改名 / 图标上传 / 常用平台一键添加 / 邮箱自动 mailto:
 * @param array  $list   当前链接数组（moe_social_list() 的返回值）
 * @param string $upload 上传接口地址（后台为 upload.php）
 * @param string $token  CSRF 令牌
 */
function moe_social_editor_html($list, $upload = 'upload.php', $token = '')
{
    $list = array_values(is_array($list) ? $list : array());
    $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
    $presets = array(
        array('GitHub', '🐱', 'https://github.com/'),
        array('哔哩哔哩', '📺', 'https://space.bilibili.com/'),
        array('微博', '🔥', 'https://weibo.com/'),
        array('X / Twitter', '🐦', 'https://x.com/'),
        array('邮箱', '✉️', 'you@example.com'),
        array('Telegram', '✈️', 'https://t.me/'),
        array('知乎', '🧐', 'https://www.zhihu.com/people/'),
        array('抖音', '🎵', 'https://www.douyin.com/'),
        array('小红书', '📕', 'https://www.xiaohongshu.com/user/profile/'),
        array('QQ', '🐧', 'https://qm.qq.com/cgi-bin/qm/qr?k='),
        array('微信', '💬', 'https://weixin.qq.com/'),
        array('支付宝', '💰', 'https://www.alipay.com/'),
    );
    $presetHtml = '';
    foreach ($presets as $p) {
        // 2.1.5：assets/social/ 里有同名图标就用图片（如 oauth-wb.png），没有则回落 emoji
        $img = function_exists('moe_social_auto_icon') ? moe_social_auto_icon($p[0]) : '';
        if ($img !== '') {
            $icoHtml = '<img src="' . e(social_icon_url($img)) . '" alt="" style="width:16px;height:16px;border-radius:4px;object-fit:cover;vertical-align:-3px;margin-right:4px">' . e($p[0]);
            $iconVal = $img; // 一键添加时直接把图片路径写进图标栏
        } else {
            $icoHtml = e($p[1] . ' ' . $p[0]);
            $iconVal = $p[1];
        }
        $presetHtml .= '<button type="button" class="btn ghost sm soc-preset"'
            . ' data-name="' . e($p[0]) . '" data-icon="' . e($iconVal) . '" data-url="' . e($p[2]) . '">'
            . $icoHtml . '</button> ';
    }
    $tpl = <<<'HTML'
<div id="socialRows"></div>
<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:14px 0 4px">
  <button class="btn ghost sm" type="button" id="socialAdd">➕ 新增一条</button>
  <span class="hint" style="margin:0">邮箱类链接直接填 <code>you@example.com</code> 会自动转成 mailto:</span>
</div>
<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:10px 0 4px">
  <span class="hint" style="margin:0">常用平台一键添加：</span>
  __PRESETS__
</div>
<input type="hidden" name="social_links" id="socialJson" value="__HIDDEN__">
<script>
(function () {
  var rowsBox = document.getElementById('socialRows');
  var jsonBox = document.getElementById('socialJson');
  var addBtn  = document.getElementById('socialAdd');
  if (!rowsBox || !jsonBox) return;
  var UP = __UP__, TK = __TK__;
  var socialData = __DATA__;
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function sync() {
    var out = [], rows = rowsBox.querySelectorAll('.soc-row');
    Array.prototype.forEach.call(rows, function (row) {
      var icon = row.querySelector('.soc-icon').value.trim();
      var name = row.querySelector('.soc-name').value.trim();
      var url  = row.querySelector('.soc-url').value.trim();
      if (url === '') return;
      if (url.indexOf('@') !== -1 && url.indexOf('/') === -1 && url.indexOf('mailto:') !== 0) url = 'mailto:' + url;
      out.push({ name: name, url: url, icon: icon });
    });
    jsonBox.value = JSON.stringify(out);
  }
  function render() {
    if (!socialData.length) {
      rowsBox.innerHTML = '<p class="hint" style="margin:0">还没有社交链接，点下面「新增一条」添加吧～</p>';
      sync();
      return;
    }
    var html = '';
    for (var i = 0; i < socialData.length; i++) {
      var r = socialData[i];
      html += '<div class="soc-row" data-i="' + i + '">'
        + '<input type="text" class="soc-icon" value="' + esc(r.icon) + '" placeholder="图标 emoji / 图片地址" title="可填 emoji（如 🐱）或图片地址">'
        + '<input type="text" class="soc-name" value="' + esc(r.name) + '" placeholder="名称（如 GitHub）">'
        + '<input type="text" class="soc-url" value="' + esc(r.url) + '" placeholder="https://…">'
        + '<label class="btn ghost sm soc-up" title="上传图标">🖼<input type="file" accept="image/*" style="display:none"></label>'
        + '<button type="button" class="soc-del" title="删除">✕</button>'
        + '</div>';
    }
    rowsBox.innerHTML = html;
    sync();
  }
  rowsBox.addEventListener('input', sync);
  rowsBox.addEventListener('click', function (ev) {
    var del = ev.target.closest ? ev.target.closest('.soc-del') : null;
    if (!del) return;
    var i = parseInt(del.parentNode.getAttribute('data-i'), 10);
    socialData.splice(i, 1);
    render();
  });
  rowsBox.addEventListener('change', function (ev) {
    var fi = ev.target;
    if (!fi.matches || !fi.matches('.soc-up input[type=file]') || !fi.files[0]) return;
    var fd = new FormData(), xhr = new XMLHttpRequest();
    fd.append('file', fi.files[0]);
    fd.append('_token', TK);
    fd.append('type', 'image');
    xhr.open('POST', UP);
    xhr.onload = function () {
      try {
        var d = JSON.parse(xhr.responseText);
        if (d.ok) {
          fi.closest('.soc-row').querySelector('.soc-icon').value = d.url;
          sync();
        } else { alert('上传失败：' + d.msg); }
      } catch (e) { alert('上传失败'); }
    };
    xhr.send(fd);
  });
  if (addBtn) addBtn.addEventListener('click', function () {
    socialData.push({ name: '', url: '', icon: '' });
    render();
    var rows = rowsBox.querySelectorAll('.soc-row');
    if (rows.length) rows[rows.length - 1].querySelector('.soc-name').focus();
  });
  document.querySelectorAll('.soc-preset').forEach(function (btn) {
    btn.addEventListener('click', function () {
      socialData.push({
        name: btn.getAttribute('data-name') || '',
        icon: btn.getAttribute('data-icon') || '',
        url:  btn.getAttribute('data-url') || ''
      });
      render();
      var rows = rowsBox.querySelectorAll('.soc-row');
      if (rows.length) {
        var last = rows[rows.length - 1].querySelector('.soc-url');
        last.focus(); last.select();
      }
    });
  });
  render();
})();
</script>
HTML;
    // nowdoc 的结束标识符必须顶格（兼容 PHP 7.2）；strtr 一次性替换，避免链式误替换
    return strtr($tpl, array(
        '__PRESETS__' => $presetHtml,
        '__HIDDEN__'  => e(json_encode($list, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)),
        '__UP__'      => json_encode((string)$upload, $flags),
        '__TK__'      => json_encode((string)$token, $flags),
        '__DATA__'    => json_encode($list, $flags),
    ));
}

/* ============================================================
   六、前台入口组件（2.1.5 已移除）
   前台左下角的「昵称 · 我的中心」浮标与导航里的用户入口重复，
   且 fomalhaut 等主题一直是靠 JS 扫描 DOM 来隐藏它，浪费性能。
   现直接删除组件本体，模板里相关的隐藏脚本与设置项一并移除。
   ============================================================ */

/* ============================================================
   七、前台用户中心页面（独立完整 HTML）
   ============================================================ */
function moe_uc_flash($msg, $type = 'ok')
{
    $_SESSION['moe_uc_flash'] = array('msg' => $msg, 'type' => $type);
}
function moe_uc_take_flash()
{
    $f = isset($_SESSION['moe_uc_flash']) ? $_SESSION['moe_uc_flash'] : null;
    unset($_SESSION['moe_uc_flash']);
    return $f;
}
function moe_uc_goto($a = '', $anchor = 0)
{
    header('Location: ' . base_url() . 'user' . ($a !== '' ? '?a=' . urlencode($a) : '')
        . ($anchor > 0 ? '#uc-cm-' . (int)$anchor : ''));
    exit;
}
function moe_uc_captcha()
{
    $x = random_int(2, 9); $y = random_int(1, 9);
    $_SESSION['moe_uc_cap'] = $x + $y;
    return $x . ' + ' . $y . ' = ?';
}

/**
 * 2.2.22：用户中心主题自适应 —— 读取当前主题 style.css 的 :root 配色变量，
 * 把用户中心 / 商城页的所有硬编码粉紫色替换为跟随主题的 CSS 变量。
 */
if (!function_exists('moe_uc_theme_vars')) {
    function moe_uc_theme_vars()
    {
        static $vars = null;
        if ($vars !== null) return $vars;
        $vars = array('pink' => '#ff7eb3', 'violet' => '#a18cd1', 'blue' => '#8ec5fc',
                      'bg' => '#f6f2ff', 'card' => '#ffffff', 'text' => '#4a4060',
                      'muted' => '#9a8fae', 'line' => '#efe9f8');
        $css = MOE_ROOT . '/templates/' . theme() . '/assets/style.css';
        if (is_file($css)) {
            $s = (string)@file_get_contents($css);
            $root = '';
            if (preg_match('/:root\s*\{(.*?)\}/s', $s, $m)) $root = $m[1];   // 只读第一段 :root（浅色），深色覆盖不读
            foreach (array('pink', 'violet', 'blue', 'bg', 'card', 'text', 'muted', 'line') as $k) {
                if (preg_match('/--' . $k . '\s*:\s*([^;]+);/i', $root, $m2)) {
                    $v = trim($m2[1]);
                    if ($v === '' || strpos($v, 'var(') === 0 || strpos($v, 'linear-gradient') !== false) continue;
                    $vars[$k] = $v;
                }
            }
        }
        return $vars;
    }
}

/** 2.2.22：用户中心 CSS 的变量声明块（跟随当前主题） */
if (!function_exists('moe_uc_css_root')) {
    function moe_uc_css_root()
    {
        $v = moe_uc_theme_vars();
        return ':root{'
            . '--uc-pink:' . $v['pink'] . ';'
            . '--uc-violet:' . $v['violet'] . ';'
            . '--uc-blue:' . $v['blue'] . ';'
            . '--uc-text:' . $v['text'] . ';'
            . '--uc-muted:' . $v['muted'] . ';'
            . '--uc-line:' . $v['line'] . ';'
            . '--uc-bg-soft:' . $v['bg'] . ';'
            . '--uc-card:' . $v['card'] . ';'
            . '--uc-pink-deep:color-mix(in srgb,' . $v['pink'] . ' 62%,#7a3a5a);'
            . '--uc-violet-deep:color-mix(in srgb,' . $v['violet'] . ' 66%,#4a3a70);'
            . '--uc-text-soft:color-mix(in srgb,' . $v['text'] . ' 78%,' . $v['muted'] . ');'
            . '--uc-blue-bg:color-mix(in srgb,' . $v['blue'] . ' 18%,#ffffff);'
            . '--uc-violet-bg:color-mix(in srgb,' . $v['violet'] . ' 16%,#ffffff);'
            // 兼容用户中心内部视图里直接使用的主题变量名（--line / --muted / --grad 等）
            . '--pink:' . $v['pink'] . ';--violet:' . $v['violet'] . ';--blue:' . $v['blue'] . ';'
            . '--bg:' . $v['bg'] . ';--card:' . $v['card'] . ';--text:' . $v['text'] . ';'
            . '--muted:' . $v['muted'] . ';--line:' . $v['line'] . ';'
            . '--grad:linear-gradient(135deg,' . $v['pink'] . ',' . $v['violet'] . ');'
            . '}';
    }
}

/** 2.2.22：把用户中心 CSS 里的硬编码粉紫色换成主题变量（带原始值兜底，旧主题也能正常显示） */
if (!function_exists('moe_uc_css_themify')) {
    function moe_uc_css_themify($css)
    {
        $map = array(
            '#ff7eb3' => 'var(--uc-pink,#ff7eb3)',
            '#ff9ac4' => 'var(--uc-pink,#ff9ac4)',
            '#ffd9e8' => 'var(--uc-pink,#ffd9e8)',
            '#ffe0ee' => 'var(--uc-pink,#ffe0ee)',
            '#ffe7f1' => 'var(--uc-pink,#ffe7f1)',
            '#fdeef1' => 'var(--uc-pink,#fdeef1)',
            '#d5568e' => 'var(--uc-pink-deep,#d5568e)',
            '#c05a8f' => 'var(--uc-pink-deep,#c05a8f)',
            '#b98aa6' => 'var(--uc-pink-deep,#b98aa6)',
            '#d9506b' => 'var(--uc-pink-deep,#d9506b)',
            '#a18cd1' => 'var(--uc-violet,#a18cd1)',
            '#7a63c0' => 'var(--uc-violet-deep,#7a63c0)',
            '#7a4fae' => 'var(--uc-violet-deep,#7a4fae)',
            '#7257c9' => 'var(--uc-violet-deep,#7257c9)',
            '#8f7bff' => 'var(--uc-violet-deep,#8f7bff)',
            '#5b3fb0' => 'var(--uc-violet-deep,#5b3fb0)',
            '#b9a2ea' => 'var(--uc-violet,#b9a2ea)',
            '#c9b3ee' => 'var(--uc-violet,#c9b3ee)',
            '#8ec5fc' => 'var(--uc-blue,#8ec5fc)',
            '#3d82bf' => 'var(--uc-blue,#3d82bf)',
            '#dcf0ff' => 'var(--uc-blue-bg,#dcf0ff)',
            '#e8f4ff' => 'var(--uc-blue-bg,#e8f4ff)',
            '#eef7ff' => 'var(--uc-blue-bg,#eef7ff)',
            '#e7dcff' => 'var(--uc-violet-bg,#e7dcff)',
            '#e2d8ff' => 'var(--uc-violet-bg,#e2d8ff)',
            '#e6dcff' => 'var(--uc-violet-bg,#e6dcff)',
            '#eae4ff' => 'var(--uc-violet-bg,#eae4ff)',
            '#f5f0ff' => 'var(--uc-violet-bg,#f5f0ff)',
            '#efe9f8' => 'var(--uc-line,#efe9f8)',
            '#ece5f7' => 'var(--uc-line,#ece5f7)',
            '#eee7f5' => 'var(--uc-line,#eee7f5)',
            '#f0eaf8' => 'var(--uc-line,#f0eaf8)',
            '#f1ebf9' => 'var(--uc-line,#f1ebf9)',
            '#e8e2f0' => 'var(--uc-line,#e8e2f0)',
            '#e0cdf5' => 'var(--uc-line,#e0cdf5)',
            '#d9cdf0' => 'var(--uc-line,#d9cdf0)',
            '#fdfcff' => 'var(--uc-bg-soft,#fdfcff)',
            '#f6f2ff' => 'var(--uc-bg-soft,#f6f2ff)',
            '#f2eefb' => 'var(--uc-bg-soft,#f2eefb)',
            '#f4f0ff' => 'var(--uc-bg-soft,#f4f0ff)',
            '#fdfaff' => 'var(--uc-bg-soft,#fdfaff)',
            '#fff5fa' => 'var(--uc-bg-soft,#fff5fa)',
            '#9a8fae' => 'var(--uc-muted,#9a8fae)',
            '#8e83a5' => 'var(--uc-muted,#8e83a5)',
            '#b0a6c2' => 'var(--uc-muted,#b0a6c2)',
            '#c9c0d8' => 'var(--uc-muted,#c9c0d8)',
            '#7d7196' => 'var(--uc-muted,#7d7196)',
            '#6f6488' => 'var(--uc-text-soft,#6f6488)',
            '#5b4d78' => 'var(--uc-text-soft,#5b4d78)',
            '#4a4060' => 'var(--uc-text,#4a4060)',
            '#453a54' => 'var(--uc-text,#453a54)',
        );
        return strtr((string)$css, $map);
    }
}

/**
 * 2.1.0：积分 / 签到 / 商城 / 下载的附加样式
 * 单独成函数，用户中心与独立商城页（/shop）共用同一套视觉。
 */
function moe_uc_css_extra()
{
    return moe_uc_css_themify('<style>' . moe_uc_css_root()
        // —— 积分卡 ——
        . '.pt-hero{background:linear-gradient(135deg,#ff7eb3 0%,#a18cd1 52%,#8ec5fc 100%);border-radius:20px;'
        . 'padding:22px 26px;color:#fff;display:flex;align-items:center;justify-content:space-between;gap:20px;'
        . 'flex-wrap:wrap;box-shadow:0 14px 34px rgba(161,140,209,.32);margin-bottom:16px}'
        . '.pt-hero-label{font-size:13px;opacity:.9;letter-spacing:.5px}'
        . '.pt-hero-num{font-size:40px;font-weight:800;line-height:1.1;margin:4px 0 6px;letter-spacing:-.5px}'
        . '.pt-hero-num small{font-size:14px;font-weight:600;opacity:.85;margin-left:6px;letter-spacing:0}'
        . '.pt-hero-sub{font-size:12.5px;opacity:.92}'
        . '.pt-hero-act{display:flex;flex-direction:column;align-items:stretch;gap:8px;min-width:170px}'
        . '.pt-sign-btn{width:100%;border:0;cursor:pointer;padding:11px 18px;border-radius:12px;'
        . 'background:#fff;color:#7a4fae;font:700 14px inherit;box-shadow:0 8px 20px rgba(60,40,110,.18)}'
        . '.pt-sign-btn:hover{transform:translateY(-1px)}'
        . '.pt-signed-ok{display:block;text-align:center;padding:11px 18px;border-radius:12px;'
        . 'background:rgba(255,255,255,.22);font-weight:700;font-size:13.5px}'
        . '.pt-hero-link{display:block;text-align:center;padding:8px 14px;border-radius:11px;'
        . 'background:rgba(255,255,255,.16);color:#fff;font-size:12.5px;text-decoration:none}'
        . '.pt-hero-link:hover{background:rgba(255,255,255,.28);text-decoration:none}'
        // —— 签到日历条 ——
        . '.pt-week{display:flex;gap:7px;flex-wrap:wrap}'
        . '.pt-day{flex:1 1 44px;min-width:44px;border:1.5px solid #ece5f7;border-radius:12px;background:#fdfcff;'
        . 'padding:8px 4px;text-align:center;line-height:1.25}'
        . '.pt-day b{display:block;font-size:13.5px;color:#5b4d78}'
        . '.pt-day span{display:block;font-size:10.5px;color:#b0a6c2}'
        . '.pt-day i{display:block;font-style:normal;font-size:10.5px;color:#c9c0d8;margin-top:2px}'
        . '.pt-day.is-on{background:linear-gradient(160deg,#ffd9e8,#e6dcff);border-color:#e0cdf5}'
        . '.pt-day.is-on i{color:#c05a8f;font-weight:700}'
        . '.pt-day.is-today{border-color:#a18cd1;box-shadow:0 0 0 3px rgba(161,140,209,.16)}'
        // —— 规则 ——
        . '.pt-rules{display:grid;grid-template-columns:1fr 1fr;gap:10px}'
        . '.pt-rule{border:1px solid #efe9f8;border-radius:13px;padding:12px 14px;background:#fdfcff}'
        . '.pt-rule b{display:block;font-size:13px;color:#5b4d78;margin-bottom:3px}'
        . '.pt-rule span{font-size:12.5px;color:#8e83a5;line-height:1.6}'
        // —— 流水 ——
        . '.pt-logs{display:flex;flex-direction:column}'
        . '.pt-log{display:flex;align-items:center;justify-content:space-between;gap:12px;'
        . 'padding:11px 0;border-bottom:1px dashed #f1ebf9}'
        . '.pt-log:last-child{border-bottom:0;padding-bottom:0}'
        . '.pt-log-main{min-width:0}.pt-log-main b{display:block;font-size:13px;color:#4a4060}'
        . '.pt-log-main span{display:block;font-size:12px;color:#9a8fae;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
        . '.pt-log-right{text-align:right;flex:none}'
        . '.pt-log-right b{font-size:15px;font-weight:800}.pt-log-right b.is-plus{color:#d5568e}'
        . '.pt-log-right b.is-minus{color:#8e83a5}.pt-log-right small{display:block;font-size:11px;color:#b0a6c2}'
        // —— 商城顶栏 ——
        . '.pt-bar{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;'
        . 'background:#fff;border:1px solid #efe9f8;border-radius:16px;padding:13px 16px;margin-bottom:16px;'
        . 'box-shadow:0 4px 18px rgba(146,120,200,.08)}'
        . '.pt-bar-left{font-size:13px;color:#6f6488;display:flex;align-items:center;gap:9px;flex-wrap:wrap}'
        . '.pt-bar-left b{font-size:19px;color:#7a63c0}'
        . '.pt-bar-tag{font-size:11.5px;padding:2px 9px;border-radius:999px;background:#f2eefb;color:#8e83a5}'
        . '.pt-bar-tag.is-on{background:#eafaf1;color:#268a5b}'
        . '.pt-bar-right{display:flex;gap:8px;align-items:center;flex-wrap:wrap}'
        // —— 商品网格 ——
        . '.pt-goods{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px}'
        . '.pt-goods-card{position:relative;background:#fff;border:1px solid #efe9f8;border-radius:17px;'
        . 'overflow:hidden;box-shadow:0 5px 20px rgba(146,120,200,.09);display:flex;flex-direction:column;'
        . 'transition:transform .16s,box-shadow .16s}'
        . '.pt-goods-card:hover{transform:translateY(-3px);box-shadow:0 12px 30px rgba(146,120,200,.18)}'
        . '.pt-goods-cover{aspect-ratio:16/10;background:#f6f2ff;overflow:hidden;display:flex;align-items:center;justify-content:center}'
        . '.pt-goods-cover img{width:100%;height:100%;object-fit:cover;display:block}'
        . '.pt-goods-cover.is-empty{background:linear-gradient(135deg,#ffe0ee,#e7dcff 60%,#dcf0ff)}'
        . '.pt-goods-cover.is-empty span{font-size:32px;font-weight:800;color:#fff;text-shadow:0 2px 8px rgba(120,90,170,.35)}'
        . '.pt-goods-badge{position:absolute;top:10px;right:10px;background:rgba(38,138,91,.92);color:#fff;'
        . 'font-size:11px;padding:3px 9px;border-radius:999px;font-weight:600}'
        . '.pt-goods-body{padding:13px 15px 15px;display:flex;flex-direction:column;flex:1}'
        . '.pt-goods-body h3{font-size:14px;color:#4a4060;margin-bottom:5px;line-height:1.45;'
        . 'display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}'
        . '.pt-goods-body p{font-size:12.5px;color:#9a8fae;line-height:1.6;flex:1;'
        . 'display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}'
        . '.pt-goods-meta{display:flex;align-items:center;justify-content:space-between;margin:10px 0 11px}'
        . '.pt-price{font-size:17px;font-weight:800;color:#d5568e}.pt-price i{font-size:11.5px;font-style:normal;font-weight:600;color:#b98aa6;margin-left:2px}'
        . '.pt-dl-num{font-size:11.5px;color:#b0a6c2}'
        . '.pt-goods-act form{width:100%}.pt-goods-act .btn{width:100%}'
        // —— 下载中心 ——
        . '.pt-dl-list{display:flex;flex-direction:column;gap:10px}'
        . '.pt-dl-item{display:flex;align-items:center;gap:12px;border:1px solid #efe9f8;border-radius:14px;'
        . 'padding:10px 13px;background:#fdfcff}'
        . '.pt-dl-cover{width:52px;height:52px;border-radius:11px;overflow:hidden;flex:none;background:#f4f0ff;'
        . 'display:flex;align-items:center;justify-content:center}'
        . '.pt-dl-cover img{width:100%;height:100%;object-fit:cover}'
        . '.pt-dl-cover.is-empty{background:linear-gradient(135deg,#ffe0ee,#e2d8ff);color:#fff;font-weight:800;font-size:19px}'
        . '.pt-dl-main{flex:1;min-width:0}'
        . '.pt-dl-main b{display:block;font-size:13.5px;color:#4a4060;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
        . '.pt-dl-main span{display:block;font-size:12px;color:#9a8fae;margin-top:2px}'
        . '.pt-dl-all{display:flex;flex-direction:column}'
        . '.pt-dl-row{display:flex;align-items:center;gap:12px;padding:11px 0;border-bottom:1px dashed #f1ebf9}'
        . '.pt-dl-row:last-child{border-bottom:0;padding-bottom:0}'
        // —— 排行榜 ——
        . '.pt-rank-tabs{display:flex;align-items:center;gap:8px;margin:-2px 0 12px;flex-wrap:wrap}'
        . '.pt-rank-tabs a{padding:5px 13px;border-radius:999px;border:1px solid #ece5f7;background:#fdfcff;'
        . 'font-size:12.5px;color:#8e83a5;text-decoration:none;line-height:1.7}'
        . '.pt-rank-tabs a:hover{border-color:#d9cdf0;color:#7a63c0;text-decoration:none}'
        . '.pt-rank-tabs a.is-on{background:linear-gradient(135deg,#ff9ac4,#a18cd1);border-color:transparent;'
        . 'color:#fff;font-weight:600;box-shadow:0 4px 12px rgba(161,140,209,.28)}'
        . '.pt-rank-meta{margin-left:auto;font-size:11.5px;color:#b0a6c2}'
        . '.pt-rank-list{display:flex;flex-direction:column;gap:6px}'
        . '.pt-rank-row{display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:12px;border:1px solid transparent}'
        . '.pt-rank-row.is-top{background:linear-gradient(90deg,#fffaf0,#fdfcff);border-color:#f6eeda}'
        . '.pt-rank-row.is-me{background:#f4f0ff;border-color:#e2d8ff}'
        . '.pt-rank-no{width:26px;text-align:center;font-size:13px;font-weight:800;color:#b9aecb;flex:none}'
        . '.pt-rank-row.is-top .pt-rank-no{font-size:17px}'
        . '.pt-rank-ava{width:32px;height:32px;border-radius:50%;object-fit:cover;flex:none;background:#f2eefb}'
        . '.pt-rank-info{flex:1;min-width:0}'
        . '.pt-rank-info b{display:block;font-size:13px;color:#4a4060;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}'
        . '.pt-rank-info b i{font-style:normal;font-size:10px;background:#a18cd1;color:#fff;border-radius:999px;'
        . 'padding:1px 6px;margin-left:5px;vertical-align:1px}'
        . '.pt-rank-info span{display:block;font-size:11.5px;color:#a397b6}'
        . '.pt-rank-val{text-align:right;flex:none;min-width:38px}'
        . '.pt-rank-val b{font-size:16px;font-weight:800;color:#d5568e}'
        . '.pt-rank-val span{font-size:10.5px;color:#b98aa6;margin-left:2px}'
        . '.pt-rank-me{margin-top:12px;padding:10px 13px;border-radius:12px;background:#fdfcff;'
        . 'border:1px dashed #ece5f7;font-size:12.5px;color:#8e83a5}'
        . '.pt-rank-me b{color:#7a63c0;font-size:14px}.pt-rank-me span{color:#c9c0d8;margin:0 2px}'
        // —— 评论编辑（2.1.2） ——
        . '.uc-edit{margin-top:9px}'
        . '.uc-edit summary{cursor:pointer;font-size:12.5px;color:#8f7bff;list-style:none;display:inline-block}'
        . '.uc-edit summary::before{content:"▸ ";font-size:11px}'
        . '.uc-edit[open] summary::before{content:"▾ "}'
        . '.uc-edit textarea{width:100%;margin-top:9px;padding:11px 13px;border:1.5px solid #ece5f7;border-radius:12px;'
        . 'background:#fdfcff;color:#4a4060;font:13px/1.7 inherit;resize:vertical;min-height:96px;outline:none}'
        . '.uc-edit textarea:focus{border-color:#c9b6ee;box-shadow:0 0 0 3px rgba(161,140,209,.14)}'
        // —— 响应式 ——
        . '@media(max-width:760px){.pt-goods{grid-template-columns:repeat(2,1fr)}.pt-rules{grid-template-columns:1fr}}'
        . '@media(max-width:560px){.pt-hero{padding:18px;border-radius:17px}.pt-hero-num{font-size:32px}'
        . '.pt-hero-act{min-width:0;width:100%}.pt-day{flex:1 1 38px;min-width:38px;padding:7px 2px}'
        . '.pt-goods{grid-template-columns:1fr}.pt-log-main span{white-space:normal}.pt-rank-meta{display:none}}'
        . '</style>');
}

/** 页面外壳 */
function moe_uc_shell($title, $sub, $body, $u)
{
    $siteName = setting('site_name', 'MoeZ');
    $home     = base_url();
    $uc       = base_url() . 'user';
    $head = '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">'
          . '<meta name="viewport" content="width=device-width,initial-scale=1">'
          . '<meta name="robots" content="noindex,nofollow">'
          . '<title>' . e($title) . ' · ' . e($siteName) . '</title>'
          . moe_uc_css_themify('<style>' . moe_uc_css_root()
          . '*{box-sizing:border-box;margin:0;padding:0}'
          . 'body{font:14px/1.7 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif;color:#4a4060;'
          . 'background:linear-gradient(135deg,#fff5fa 0%,#f6f2ff 45%,#eef7ff 100%);min-height:100vh;padding-bottom:60px}'
          . 'a{color:#8f7bff;text-decoration:none}a:hover{text-decoration:underline}'
          . '.uc-top{background:rgba(255,255,255,.82);backdrop-filter:blur(14px);border-bottom:1px solid #eee7f5;'
          . 'padding:13px 20px;display:flex;align-items:center;gap:12px;flex-wrap:wrap}'
          . '.uc-top .brand{font-weight:700;font-size:16px;color:#4a4060;display:flex;align-items:center;gap:8px}'
          . '.uc-top .sp{flex:1}.uc-top .lnk{font-size:13px;color:#8e83a5}'
          . '.uc-top .me{display:flex;align-items:center;gap:7px;font-size:13px;color:#5b4d78}'
          . '.uc-top .me img{width:26px;height:26px;border-radius:50%;object-fit:cover}'
          . '.uc-wrap{max-width:1080px;margin:28px auto;padding:0 16px;font-size:clamp(13.5px, 13px + 0.14vw, 15.5px)}'
          . '.uc-hd{margin-bottom:20px}.uc-hd h1{font-size:clamp(22px, 20px + 0.4vw, 26px);letter-spacing:.5px}'
          . '.uc-hd p{color:#8e83a5;font-size:13px;margin-top:4px}'
          . '.uc-tabs{display:flex;flex-wrap:wrap;gap:8px;padding:5px;margin-bottom:18px;background:#fff;'
          . 'border:1px solid #eee7f5;border-radius:14px}'
          . '.uc-tabs a{flex:0 0 auto;padding:9px 16px;border-radius:10px;font-size:13.5px;color:#7d7196;white-space:nowrap}'
          . '.uc-tabs a.cur{background:#a18cd1;background:linear-gradient(135deg,#ff7eb3,#a18cd1);color:#fff;font-weight:600}'
          // 2.2.22：二级导航 —— 一级为功能分组，二级为组内页面
          . '.uc-grp{display:flex;flex-wrap:wrap;gap:7px;margin-bottom:11px}'
          . '.uc-grp a{padding:8px 15px;border-radius:11px;font-size:13.5px;font-weight:600;color:#7d7196;'
          . 'background:#fff;border:1px solid #eee7f5}'
          . '.uc-grp a:hover{text-decoration:none;border-color:#e0cdf5}'
          . '.uc-grp a.cur{color:#d5568e;border-color:#ffe7f1;background:#fff;'
          . 'box-shadow:0 4px 14px rgba(146,120,200,.16)}'
          . '.uc-tabs.sub{background:transparent;border:0;padding:0;gap:7px;margin-bottom:18px}'
          . '.uc-tabs.sub a{background:#fff;border:1px solid #eee7f5;border-radius:10px;padding:7px 14px;font-size:13px}'
          // 选中态需高于 .uc-tabs.sub a 的白底（同优先级后者会胜出），故显式重设背景与文字色
          . '.uc-tabs.sub a.cur{background:#a18cd1;background:linear-gradient(135deg,#ff7eb3,#a18cd1);color:#fff;font-weight:600;border-color:transparent}'
          . '.card{background:#fff;border:1px solid #efe9f8;border-radius:18px;padding:22px 24px;margin-bottom:16px;'
          . 'box-shadow:0 4px 20px rgba(146,120,200,.09)}'
          . '.card h2{font-size:15.5px;margin-bottom:16px;display:flex;align-items:center;gap:8px}'
          . '.card h2::before{content:"";width:4px;height:16px;border-radius:4px;background:linear-gradient(#ff7eb3,#a18cd1)}'
          . '.field{margin-bottom:15px}.field label{display:block;font-size:13px;font-weight:600;margin-bottom:6px;color:#5b4d78}'
          . '.field input,.field textarea{width:100%;padding:10px 13px;border:1.5px solid #e8e2f0;border-radius:10px;'
          . 'outline:none;font:14px/1.6 inherit;color:#4a4060;background:#fdfcff}'
          . '.field input:focus,.field textarea:focus{border-color:#b9a2ea}'
          . '.field textarea{resize:vertical;min-height:76px}'
          . '.grid2{display:grid;grid-template-columns:1fr 1fr;gap:0 14px}'
          . '.btn{display:inline-flex;align-items:center;justify-content:center;gap:6px;border:0;cursor:pointer;'
          . 'padding:11px 20px;border-radius:11px;font:600 14px inherit;color:#fff;'
          . 'background:linear-gradient(135deg,#ff7eb3,#a18cd1,#8ec5fc);box-shadow:0 6px 18px rgba(161,140,209,.35)}'
          . '.btn:hover{text-decoration:none;transform:translateY(-1px)}'
          . '.btn.ghost{background:#fff;color:#6f6488;border:1.5px solid #e8e2f0;box-shadow:none}'
          . '.btn.sm{padding:7px 13px;font-size:12.5px;border-radius:9px}'
          . '.hint{color:#9a8fae;font-size:12.5px;margin-top:6px}'
          . '.alert{padding:12px 15px;border-radius:11px;font-size:13px;margin-bottom:16px}'
          . '.alert.ok{background:#eafaf1;color:#268a5b}.alert.bad{background:#fdeef1;color:#d9506b}'
          . '.alert.warn{background:#fff7e8;color:#a8791c}'
          . '.pill{display:inline-block;padding:2px 9px;border-radius:999px;font-size:11.5px;font-weight:600}'
          . '.pill.admin{background:#ffe7f1;color:#d5568e}.pill.author{background:#eae4ff;color:#7257c9}'
          . '.pill.member{background:#e8f4ff;color:#3d82bf}'
          . '.profile-head{display:flex;align-items:center;gap:18px;flex-wrap:wrap}'
          . '.profile-head img{width:84px;height:84px;border-radius:50%;object-fit:cover;border:3px solid #fff;'
          . 'box-shadow:0 6px 20px rgba(146,120,200,.25)}'
          . '.profile-head .nm{font-size:20px;font-weight:700}.profile-head .sub{color:#9a8fae;font-size:13px;margin-top:3px}'
          . '.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:18px}'
          . '.stat{background:linear-gradient(160deg,#fdfaff,#f5f0ff);border:1px solid #efe9f8;border-radius:13px;'
          . 'padding:14px;text-align:center}.stat b{display:block;font-size:22px;color:#7a63c0}.stat span{font-size:12px;color:#9a8fae}'
          . '.quick{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:11px}'
          . '.quick a{display:block;padding:15px;border:1.5px solid #eee7f5;border-radius:13px;background:#fdfcff;'
          . 'color:#5b4d78;font-weight:600;font-size:13.5px;transition:transform .15s,border-color .15s}'
          . '.quick a:hover{text-decoration:none;transform:translateY(-2px);border-color:#c9b3ee}'
          . '.quick a small{display:block;color:#9a8fae;font-weight:400;font-size:12px;margin-top:4px}'
          . '.list-item{padding:13px 0;border-bottom:1px dashed #f0eaf8}.list-item:last-child{border-bottom:0}'
          . '.list-item a.t{font-weight:600;color:#4a4060;font-size:14px}'
          . '.list-item .m{color:#9a8fae;font-size:12px;margin-top:3px}'
          . '.list-item .txt{color:#6f6488;font-size:13px;margin-top:6px;word-break:break-word}'
          . '.foot{text-align:center;color:#9a8fae;font-size:12.5px;margin-top:34px;padding-top:16px;border-top:1px dashed #eee7f5;line-height:2}'
          . '.foot a{color:#7a63c0;text-decoration:none}'
          . '.foot a:hover{color:#5b3fb0;text-decoration:underline}'
          . '@media(max-width:600px){.card{padding:17px 15px;border-radius:15px}.grid2{grid-template-columns:1fr}'
          . '.uc-top{padding:11px 13px}.uc-wrap{margin:18px auto;padding:0 11px}.stats{gap:8px}.stat b{font-size:19px}}'
          . '</style>') . moe_uc_css_extra() . '</head><body>';
    /* 2.1.8：顶栏站标优先用当前主题设置的 Logo 图片（图片模式），没有则回落 emoji + 站名 */
    $ucLogo = '';
    if (function_exists('theme_opt')) {
        $ucLogoFile = trim((string)theme_opt('logo', ''));
        if ($ucLogoFile !== '' && theme_opt('logo_mode', 'text') === 'image') $ucLogo = media_url($ucLogoFile);
    }
    $ucBrand = $ucLogo !== ''
        ? '<img src="' . e($ucLogo) . '" alt="' . e($siteName) . '" style="height:26px;width:auto;max-width:150px;object-fit:contain;border-radius:6px">'
        : '🌸 ' . e($siteName);
    $top = '<div class="uc-top"><a class="brand" href="' . e($home) . '">' . $ucBrand . '</a>'
         . '<span class="sp"></span>'
         . ($u ? '<a class="me" href="' . e($uc) . '"><img src="' . e(moe_user_avatar($u)) . '" alt="">'
                . e(moe_user_display($u)) . '</a>' : '')
         // 退出放在顶栏：手机端一眼可见，不必把页签横滑到底
         . ($u ? '<form method="post" style="display:inline;margin:0">' . csrf_field()
                . '<input type="hidden" name="act" value="logout">'
                . '<button class="btn ghost sm" type="submit">退出</button></form>' : '')
         . '<a class="lnk" href="' . e($home) . '">← 返回站点</a></div>';
    /* 2.1.9：页脚改为首页底部样式（版权 + 返回首页） */
    $foot = '<div class="foot">© ' . date('Y') . ' ' . e($siteName) . ' · 用户中心<br>'
          . '<a href="' . e($home) . '">← 返回首页</a></div></body></html>';
    echo $head . $top . '<div class="uc-wrap"><div class="uc-hd"><h1>' . e($title) . '</h1>'
       . ($sub !== '' ? '<p>' . e($sub) . '</p>' : '') . '</div>' . $body
       . (strpos($body, 'id="ctForm"') !== false ? moe_uc_contribute_js() : '')
       . $foot;
}

/* ============================================================
   2.2.5 · 我的授权码（用户中心自助）
   购买了「程序」类资源的会员，可在这里给自己的站点域名自助签发永久授权码；
   授权码用官方密钥 HMAC 签发，终端站点填进后台即可在线验证 + 更新。
   ============================================================ */
if (!function_exists('moe_uc_auth_codes_file')) {
    /** 会员授权码档案：content/updates/user-auth-codes.json */
    function moe_uc_auth_codes_file()
    {
        return MOE_ROOT . '/content/updates/user-auth-codes.json';
    }
    function moe_uc_auth_codes_load()
    {
        $f = moe_uc_auth_codes_file();
        $j = is_file($f) ? json_decode((string)@file_get_contents($f), true) : null;
        return is_array($j) ? $j : array();
    }
    function moe_uc_auth_codes_save($all)
    {
        $f = moe_uc_auth_codes_file();
        if (!is_dir(dirname($f))) @mkdir(dirname($f), 0755, true);
        @file_put_contents($f, json_encode(array_values($all),
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), LOCK_EX);
    }
}

/** 会员是否拥有「程序」类资源（cat=程序/授权码，或名称 / 简介含「程序」）→ 才可以自助签发授权码 */
if (!function_exists('moe_uc_auth_can')) {
    function moe_uc_auth_can($uid)
    {
        $uid = (int)$uid;
        if ($uid <= 0 || !function_exists('moe_pt_ready') || !moe_pt_ready()) return false;
        try {
            $r = row('SELECT COUNT(*) AS n FROM ' . moe_pt_table('orders') . ' o'
                . ' LEFT JOIN ' . moe_pt_table('goods') . ' g ON g.id = o.goods_id'
                . ' WHERE o.user_id = ? AND (g.cat = ? OR g.cat = ? OR g.title LIKE ? OR g.summary LIKE ?)',
                array($uid, '程序', '授权码', '%程序%', '%程序%'));
            return (int)($r['n'] ?? 0) > 0;
        } catch (Throwable $e) {
            return false;
        }
    }
}

/** 会员的授权码列表 */
if (!function_exists('moe_uc_auth_codes_of')) {
    function moe_uc_auth_codes_of($uid)
    {
        $uid = (int)$uid;
        $out = array();
        foreach (moe_uc_auth_codes_load() as $c) {
            if ((int)($c['user_id'] ?? 0) === $uid) $out[] = $c;
        }
        return $out;
    }
}

/** 会员自助签发授权码（每域名一个，每人最多 5 个域名；写入官方站点档案便于统一管控；2.2.6 需邮箱验证） */
if (!function_exists('moe_uc_auth_issue')) {
    function moe_uc_auth_issue($uid, $domain, $email = '')
    {
        $uid = (int)$uid;
        if (!function_exists('moe_auth_code_generate')) return array('ok' => false, 'msg' => '授权模块缺失：请更新 includes/auth.php');
        if ((string)setting('update_hub_secret', '') === '') return array('ok' => false, 'msg' => '站长还没有初始化授权服务，请联系站长开通');
        $domain = trim((string)$domain);
        if ($domain === '' || !preg_match('/^[\w\.-]+\.[a-zA-Z]{2,}$/u', $domain)) {
            return array('ok' => false, 'msg' => '域名格式不正确，例如 example.com');
        }
        $email = trim((string)$email);
        if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return array('ok' => false, 'msg' => '请填写正确的接收邮箱');
        }
        $all = moe_uc_auth_codes_load();
        $mine = array(); $nd = 0;
        foreach ($all as $c) {
            if ((int)($c['user_id'] ?? 0) !== $uid) continue;
            $nd++;
            if (strcasecmp((string)$c['domain'], strtolower(trim($domain))) === 0) {
                return array('ok' => false, 'msg' => '这个域名已经签发过授权码了，下方列表可直接查看');
            }
        }
        if ($nd >= 5) return array('ok' => false, 'msg' => '每个账号最多绑定 5 个站点域名');
        $r = moe_auth_code_generate($domain, 0, (string)setting('update_hub_secret', ''));   // 永久授权
        if (empty($r['ok'])) return array('ok' => false, 'msg' => (string)$r['msg']);
        $rec = array(
            'user_id' => $uid, 'domain' => $r['domain'], 'code' => $r['code'],
            'email' => $email,
            'expire' => $r['expire'], 'issued_at' => date('Y-m-d H:i:s'),
        );
        $all[] = $rec;
        moe_uc_auth_codes_save($all);
        // 同步写进官方站点档案（后台「授权站点档案」里可统一管理 / 违规下架）
        $sf = MOE_ROOT . '/content/updates/auth-sites.json';
        $sites = is_file($sf) ? json_decode((string)@file_get_contents($sf), true) : null;
        if (is_array($sites)) {
            $uEmail = $email;
            if ($uEmail === '') {
                try {
                    $ur = row('SELECT email FROM ' . moe_table('users') . ' WHERE id = ? LIMIT 1', array($uid));
                    if ($ur && filter_var((string)$ur['email'], FILTER_VALIDATE_EMAIL)) $uEmail = (string)$ur['email'];
                } catch (Throwable $e) { /* 忽略 */ }
            }
            array_unshift($sites, array(
                'tail' => substr($r['code'], -8), 'domain' => $r['domain'],
                'email' => $uEmail,
                'expire' => $r['expire'], 'note' => '用户中心自助签发 · 用户 #' . $uid,
                'status' => 'ok', 'status_note' => '', 'issued_at' => $rec['issued_at'],
            ));
            @file_put_contents($sf, json_encode(array_values(array_slice($sites, 0, 500)),
                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), LOCK_EX);
        }
        return array('ok' => true, 'msg' => '授权码已签发（永久有效）', 'record' => $rec);
    }
}

/** 「我的授权码」视图 */
if (!function_exists('moe_uc_view_auth')) {
    function moe_uc_view_auth($u)
    {
        $uid = (int)$u['id'];
        $codes = moe_uc_auth_codes_of($uid);
        $can = moe_uc_auth_can($uid);
        $h = '';
        if (!$can) {
            return '<div class="card"><h2>🔑 我的授权码</h2>'
                . '<p class="hint">授权码用于把你购买的程序部署到自己的域名：填进程序后台即可在线验证授权与更新。</p>'
                . '<p class="hint">你还没有购买「程序」类资源——先去 <a href="' . e(base_url() . 'user?a=shop') . '">积分商城</a> 兑换程序授权，再回到这里签发。</p></div>';
        }
        // 2.2.22：购买授权码后引导下载程序（取商城里最后一个程序/授权码类资源）
        try {
            if (function_exists('moe_pt_table') && function_exists('moe_pt_download_url')) {
                $dg = row('SELECT id, title FROM ' . moe_pt_table('goods')
                    . " WHERE status = 'on' AND download_url <> '' AND (cat = ? OR cat = ?) ORDER BY id DESC LIMIT 1",
                    array('授权码', '程序'));
                if ($dg) {
                    $h .= '<div class="card" style="box-shadow:none;border:1.5px dashed var(--line)">'
                        . '<h2>⬇ 下载程序</h2>'
                        . '<p class="hint" style="margin:0 0 12px">授权码已经绑定了你的域名，接下来把程序部署到服务器：'
                        . '下载安装包 → 上传解压 → 访问站点按提示安装 → 在后台「授权与主题更新」里填入上面的授权码即可验证授权与在线更新。</p>'
                        . '<a class="btn" href="' . e(moe_pt_download_url((int)$dg['id'])) . '">⬇ 下载「' . e((string)$dg['title']) . '」</a></div>';
                }
            }
        } catch (Throwable $e) { /* 未开启商城 */ }

        $h .= '<div class="card"><h2>🔑 签发授权码</h2>'            . '<p class="hint">输入你要部署程序的<b>站点域名</b>（如 example.com，不带 https://），先获取<b>邮箱验证码</b>确认是本人操作；签发后授权码<b>永久有效</b>，一个域名一个码，最多绑定 5 个域名。</p>'
            . '<form method="post">' . csrf_field()
            . '<div class="field" style="max-width:420px"><label>站点域名</label>'
            . '<input type="text" name="domain" required placeholder="example.com"></div>'
            . '<div class="field" style="max-width:420px"><label>接收邮箱</label>'
            . '<input type="email" name="email" required placeholder="you@example.com" value="' . e((string)($u['email'] ?? '')) . '"></div>'
            . '<div class="field" style="max-width:420px"><label>邮件验证码</label>'
            . '<div style="display:flex;gap:8px"><input type="text" name="vcode" maxlength="6" inputmode="numeric" placeholder="6 位数字" required style="flex:1;min-width:0">'
            . '<button class="btn ghost" type="submit" name="act" value="auth_sendcode" formnovalidate>发送验证码</button></div>'
            . '<p class="hint">验证码发送到上面填的邮箱，10 分钟内有效；每次签发只需验证一次。</p></div>'
            . '<button class="btn" type="submit" name="act" value="auth_issue">🔑 签发永久授权码</button></form></div>';
        $h .= '<div class="card"><h2>我的授权码（' . count($codes) . '）</h2>';
        if (!$codes) {
            $h .= '<p class="hint">还没有签发过授权码，用上面的表单绑定第一个域名。</p>';
        } else {
            foreach ($codes as $c) {
                $h .= '<div style="border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin-bottom:10px">'
                    . '<div style="display:flex;justify-content:space-between;flex-wrap:wrap;gap:6px;align-items:center">'
                    . '<b>🌐 ' . e((string)$c['domain']) . '</b>'
                    . '<span class="pill ok">' . e((string)($c['expire'] ?? '永久')) . '</span></div>'
                    . '<div style="margin-top:8px"><code style="word-break:break-all;font-size:12.5px">' . e((string)$c['code']) . '</code></div>'
                    . '<div style="color:var(--muted);font-size:12px;margin-top:6px">签发于 ' . e((string)$c['issued_at'])
                    . ' · 部署时填进程序后台「授权与主题更新」即可</div></div>';
            }
        }
        $h .= '</div>';
        return $h;
    }
}

/* ============================================================
   2.2.22 · 投稿（用户中心）
   编辑器跟随后台设置（Markdown / UEditorPlus），可上传封面 / 附件并上架资源；
   投稿保存为「待审」状态，站长审核通过后正式发布、资源同步上架，并发邮件通知作者。
   ============================================================ */
if (!function_exists('moe_uc_view_contribute')) {
    function moe_uc_view_contribute($u)
    {
        $uid  = (int)$u['id'];
        $ued  = function_exists('moe_editor_mode') && moe_editor_mode() === 'ueditor';
        $base = base_url();
        $unit = moe_pt_name();
        $cn   = function_exists('moe_pt_coin_name') ? moe_pt_coin_name() : '金币';

        $cats = array();
        try { $cats = rows('SELECT * FROM ' . moe_table('categories') . ' ORDER BY sort, id'); } catch (Throwable $e) {}
        $resCats = array();
        foreach (preg_split('/[\r\n,，]+/u', (string)setting('pt_cats', '')) as $mc) {
            $mc = trim($mc); if ($mc !== '') $resCats[] = $mc;
        }
        foreach (array('主题', '插件', '程序') as $def) {
            if (!in_array($def, $resCats, true)) array_unshift($resCats, $def);
        }

        /* 我的投稿列表 */
        $mine = array();
        try {
            $mine = rows('SELECT id, title, status, created_at FROM ' . moe_table('posts')
                . " WHERE user_id = ? AND type = 'post' AND src = 'contribute' ORDER BY id DESC LIMIT 20", array($uid));
        } catch (Throwable $e) {}
        $stLabel = array('pending' => array('待站长审核', '#fff7e8;color:#a8791c'), 'published' => array('已发布', '#eafaf1;color:#268a5b'), 'draft' => array('草稿 / 已退回', '#f2eefb;color:#8e83a5'));

        $h = '<div class="card"><h2>📝 投稿说明</h2>'
           . '<p class="hint" style="margin:0 0 4px">投稿会进入<b>待审核</b>状态，站长在后台「文章管理」审核；通过后正式发布并邮件通知你，你的资源也会同步上架到积分商城。</p>'
           . '<p class="hint" style="margin:0">编辑器与站长后台一致（' . ($ued ? 'UEditorPlus 富文本' : 'Markdown') . '）；上传主题 / 插件请打包成 zip 作为附件，并勾选「同时上架资源」。</p></div>';

        $h .= '<div class="card"><h2>✍️ 写投稿</h2>'
            . '<form method="post" id="ctForm">' . csrf_field() . '<input type="hidden" name="act" value="contribute_submit">'
            . '<div class="grid2">'
            . '<div class="field"><label>标题 *</label><input type="text" name="title" required placeholder="例如：星辉 Fomalhaut 主题 v1.2"></div>'
            . '<div class="field"><label>分类</label><select name="category_id">';
        foreach ($cats as $c) $h .= '<option value="' . (int)$c['id'] . '">' . e((string)$c['name']) . '</option>';
        $h .= '</select></div></div>';

        if ($ued) {
            $h .= '<div class="field"><label>正文 *</label>'
                . '<div style="border:1px solid var(--line);border-radius:10px;overflow:hidden;background:#fff">'
                . '<textarea name="content" id="ctText" style="width:100%;height:360px"></textarea></div></div>';
        } else {
            $h .= '<div class="field"><label>正文 *（支持 Markdown）</label>'
                . '<textarea name="content" required style="min-height:300px" placeholder="介绍你的主题 / 插件：功能亮点、截图（可直接粘贴图片链接）、使用方法…"></textarea></div>';
        }

        $h .= '<div class="grid2">'
            . '<div class="field"><label>封面图（选填）</label>'
            . '<input type="text" name="cover" id="ctCover" placeholder="留空自动取正文第一张图">'
            . '<div style="margin-top:6px"><button type="button" class="btn ghost sm" id="ctCoverBtn">🖼 上传封面</button>'
            . '<span class="hint" id="ctCoverName" style="display:inline-block;margin-left:8px"></span></div></div>'
            . '<div class="field"><label>标签（选填，逗号分隔）</label><input type="text" name="tags" placeholder="主题, 二次元, 星空"></div>'
            . '</div>';

        /* 资源上架 */
        $h .= '<div style="border-top:1px dashed var(--line);padding-top:14px;margin-top:4px">'
            . '<label style="display:flex;align-items:center;gap:8px;font-weight:600;font-size:13.5px">'
            . '<input type="checkbox" name="res_on" id="resOn" value="1" checked> 📦 同时上架资源到积分商城（审核通过后自动上架）</label>'
            . '<div id="resBox" style="margin-top:10px">'
            . '<div class="grid2">'
            . '<div class="field"><label>资源分类</label><select name="res_cat">';
        foreach ($resCats as $rc) $h .= '<option value="' . e($rc) . '">' . e($rc) . '</option>';
        $h .= '</select></div>'
            . '<div class="field"><label>资源附件 *（zip / 压缩包 / 文档）</label>'
            . '<input type="hidden" name="attach_url" id="ctAttach" value="">'
            . '<div style="display:flex;gap:8px;align-items:center"><button type="button" class="btn ghost sm" id="ctAttachBtn">📎 上传附件</button>'
            . '<span class="hint" id="ctAttachName" style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">未选择文件</span></div></div>'
            . '</div>'
            . '<div class="grid2">'
            . '<div class="field"><label>资源价格 · ' . e($unit) . '（0 = 免费）</label><input type="number" name="res_price" value="0" min="0" step="1"></div>'
            . '<div class="field"><label>资源价格 · ' . e($cn) . '（0 = 不用' . e($cn) . '购买）</label><input type="number" name="res_coins" value="0" min="0" step="0.01"></div>'
            . '</div>'
            . '<p class="hint">两个价格都填了表示两种币都能购买（用户会自动用够用的那种）；只想收一种就把另一个填 0。</p>'
            . '</div></div>';

        $h .= '<div style="margin-top:6px"><button class="btn" type="submit">📮 提交投稿</button>'
            . '<span class="hint" style="margin-left:10px">提交后自动发送「投稿成功」邮件到你的账号邮箱（需站长配置好 SMTP）</span></div>'
            . '</form></div>';

        /* 我的投稿 */
        $h .= '<div class="card"><h2>🗂 我的投稿（' . count($mine) . '）</h2>';
        if (!$mine) {
            $h .= '<p class="hint" style="margin:0">还没有投稿记录，上面的表单提交第一篇吧～</p>';
        } else {
            foreach ($mine as $p) {
                $lab = $stLabel[$p['status']] ?? array((string)$p['status'], '#f2eefb;color:#8e83a5');
                $h .= '<div class="list-item" style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap">'
                    . '<div><b>' . e((string)$p['title']) . '</b>'
                    . '<div class="m">' . e(date('Y-m-d H:i', strtotime((string)$p['created_at']))) . '</div></div>'
                    . '<span class="pill" style="background:' . $lab[1] . '">' . e($lab[0]) . '</span></div>';
            }
        }
        $h .= '</div>';

        /* 编辑器脚本（UEditorPlus 跟随后台设置） */
        if ($ued) {
            $h .= '<link rel="stylesheet" href="' . e($base) . 'assets/editor/ueditor/themes/iframe.css">'
                . '<script>window.UEDITOR_HOME_URL = ' . json_encode($base . 'assets/editor/ueditor/') . ';</script>'
                . '<script src="' . e($base) . 'assets/editor/ueditor/ueditor.config.js"></script>'
                . '<script src="' . e($base) . 'assets/editor/ueditor/ueditor.all.js"></script>';
        }
        return $h;
    }
}

/** 2.2.22：投稿页的上传 / 编辑器 / 资源显隐脚本（放在 shell 底部脚本区） */
if (!function_exists('moe_uc_contribute_js')) {
    function moe_uc_contribute_js()
    {
        $ued  = function_exists('moe_editor_mode') && moe_editor_mode() === 'ueditor';
        $base = base_url();
        $js = '(function(){' .
            'var B=' . json_encode($base) . ',T=' . json_encode(csrf_token()) . ';' .
            'function up(btnId,urlId,nameId){var b=document.getElementById(btnId);if(!b)return;' .
            'b.addEventListener("click",function(){var i=document.createElement("input");i.type="file";' .
            'i.onchange=function(){var f=i.files[0];if(!f)return;' .
            'var fd=new FormData();fd.append("file",f);' .
            'var x=new XMLHttpRequest();x.open("POST",B+"api/upload.php");' .
            'x.setRequestHeader("X-CSRF-Token",T);' .
            'x.onload=function(){try{var d=JSON.parse(x.responseText);' .
            'if(d.ok){var el=document.getElementById(urlId);if(el){el.value=d.url;}' .
            'var nm=document.getElementById(nameId);if(nm){nm.textContent=f.name+"（上传成功）";}}' .
            'else{alert(d.msg||"上传失败");}}catch(e){alert("上传失败："+x.responseText.slice(0,120));}};' .
            'x.send(fd);};i.click();});}' .
            'up("ctCoverBtn","ctCover","ctCoverName");up("ctAttachBtn","ctAttach","ctAttachName");' .
            'var ro=document.getElementById("resOn"),rb=document.getElementById("resBox");' .
            'if(ro&&rb){var sync=function(){rb.style.display=ro.checked?"":"none";};ro.addEventListener("change",sync);sync();}' .
            ($ued ?
            'var ready=false;function edInit(){if(!window.UE){setTimeout(edInit,150);return;}' .
            'try{var ed=UE.getEditor("ctText",{initialFrameHeight:360,autoHeightEnabled:false,' .
            'serverUrl:B+"api/ueditor-server.php?_token="+encodeURIComponent(T)});' .
            'ed.addListener("ready",function(){ready=true;});' .
            'var f=document.getElementById("ctForm");' .
            'if(f)f.addEventListener("submit",function(){try{if(ready)ed.sync();}catch(e2){}});}' .
            'catch(e){var t=document.getElementById("ctText");if(t){t.style.display="block";t.style.height="300px";}}}' .
            'edInit();' : '') .
            '})();';
        return '<script>' . $js . '</script>';
    }
}

/* ============================================================
   2.2.22 · 友链申请（用户中心二级页签，复用前台 api/link.php 的检测逻辑）
   ============================================================ */
if (!function_exists('moe_uc_view_friendlink')) {
    function moe_uc_view_friendlink($u)
    {
        $h = '<div class="card"><h2>🔗 申请友情链接</h2>'
           . '<p class="hint" style="margin:0 0 14px">提交时会自动抓取你的站点名称并检测是否已添加本站链接：<b>已加本站链接 → 自动通过上架</b>；未检测到 → 转站长人工审核，结果会邮件通知。</p>'
           . '<form method="post">' . csrf_field() . '<input type="hidden" name="act" value="friend_apply">'
           . '<div class="grid2">'
           . '<div class="field"><label>站点名称（留空自动抓取）</label><input type="text" name="name" placeholder="你的站名"></div>'
           . '<div class="field"><label>站点地址 *</label><input type="text" name="url" required placeholder="https://example.com"></div>'
           . '</div>'
           . '<div class="grid2">'
           . '<div class="field"><label>联系方式（选填，用于接收审核通知）</label><input type="text" name="contact" placeholder="邮箱 / QQ"></div>'
           . '<div class="field"><label>本站链接地址</label><input type="text" value="' . e(base_url()) . '" readonly style="color:var(--muted)"></div>'
           . '</div>'
           . '<p class="hint">请先把本站链接加到你站点的友链位置（首页或友链页均可，支持常见内页路径），再提交申请。</p>'
           . '<button class="btn" type="submit">📨 提交申请</button></form></div>';

        /* 我申请过的友链 */
        try {
            $mine = rows('SELECT name, url, status, check_result, created_at FROM ' . moe_table('links')
                . ' WHERE contact = ? OR contact = ? ORDER BY id DESC LIMIT 10',
                array((string)($u['email'] ?? ''), (string)($u['username'] ?? '')));
        } catch (Throwable $e) { $mine = array(); }
        if ($mine) {
            $h .= '<div class="card"><h2>📋 我申请的友链</h2>';
            foreach ($mine as $l) {
                $lab = $l['status'] === 'approved' ? array('已通过', '#eafaf1;color:#268a5b')
                    : ($l['status'] === 'pending' ? array('待审核', '#fff7e8;color:#a8791c') : array('未通过', '#fdeef1;color:#d9506b'));
                $h .= '<div class="list-item"><a class="t" href="' . e((string)$l['url']) . '" target="_blank" rel="noopener">' . e((string)$l['name']) . ' ↗</a>'
                    . '<div class="m">' . e(date('Y-m-d', strtotime((string)$l['created_at']))) . ' · <span class="pill" style="background:' . $lab[1] . '">' . $lab[0] . '</span>'
                    . ($l['check_result'] !== '' ? ' · ' . e((string)$l['check_result']) : '') . '</div></div>';
            }
            $h .= '</div>';
        }
        return $h;
    }
}

/** 2.2.22：投稿保存（待审状态）+ 可选资源上架 + 成功邮件 */
if (!function_exists('moe_uc_contribute_save')) {
    function moe_uc_contribute_save($uid, $in)
    {
        $uid = (int)$uid;
        $title = trim((string)($in['title'] ?? ''));
        $content = (string)($in['content'] ?? '');
        $cover = trim((string)($in['cover'] ?? ''));
        $tags = function_exists('moe_tags_normalize') ? moe_tags_normalize((string)($in['tags'] ?? '')) : '';
        $catId = (int)($in['category_id'] ?? 0);
        $ued = function_exists('moe_editor_mode') && moe_editor_mode() === 'ueditor';
        $format = $ued ? 'html' : 'markdown';

        if ($title === '') return array('ok' => false, 'msg' => '标题不能为空');
        if (trim($content) === '') return array('ok' => false, 'msg' => '正文不能为空');

        try {
            q('INSERT INTO ' . moe_table('posts') . ' (user_id,category_id,type,title,slug,excerpt,content,content_format,cover,status,is_top,tags,url_num,draft_of,auto_draft,src,created_at,updated_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,0,0,0,?,NOW(),NOW())',
                array($uid, $catId, 'post', $title, '', '', $content, $format, $cover, 'pending', 0, $tags, 'contribute'));
            $pid = (int)last_id();
        } catch (Throwable $e) {
            return array('ok' => false, 'msg' => '保存投稿失败：' . $e->getMessage());
        }

        /* 可选：同时上架资源（附件 + 双币价格；审核通过后自动上架） */
        $resMsg = '';
        if (!empty($in['res_on']) && function_exists('moe_pt_table') && function_exists('moe_pt_ready') && moe_pt_ready()) {
            $attachUrl = trim((string)($in['attach_url'] ?? ''));
            if ($attachUrl === '') {
                $resMsg = '；但资源附件未上传，本次未上架资源（可让站长在后台手动添加）';
            } else {
                $resCat = trim((string)($in['res_cat'] ?? '其他'));
                $resCat = mb_substr($resCat, 0, 20, 'UTF-8');
                $price  = round(max(0, (float)($in['res_price'] ?? 0)), 2);
                $coins  = round(max(0, (float)($in['res_coins'] ?? 0)), 2);
                try {
                    q('INSERT INTO ' . moe_pt_table('goods') . ' (title,summary,cat,post_id,cover,price,price_coins,download_url,status,sort,created_at,updated_at)
                       VALUES (?,?,?,?,?,?,?,?,?,0,NOW(),NOW())',
                        array($title, '作者投稿资源，审核通过后自动上架', $resCat, $pid, $cover, $price, $coins, $attachUrl, 'off'));
                    $resMsg = '；资源已登记，审核通过后自动上架';
                } catch (Throwable $e) {
                    $resMsg = '；资源上架登记失败：' . $e->getMessage();
                }
            }
        }

        /* 成功邮件（SMTP 未配置时静默跳过） */
        try {
            $ur = row('SELECT email FROM ' . moe_table('users') . ' WHERE id = ?', array($uid));
            $email = trim((string)($ur['email'] ?? ''));
            if ($email !== '' && function_exists('moe_mail_ready') && moe_mail_ready() && function_exists('moe_mail_send') && function_exists('moe_mail_template')) {
                $site = function_exists('moe_mail_from_name') ? moe_mail_from_name() : setting('site_name', 'MoeZ');
                $html = moe_mail_template('投稿成功，等待审核', array(
                    '你在 <b>' . e($site) . '</b> 提交的投稿「<b>' . e($title) . '</b>」已成功提交！',
                    '站长会在后台审核你的投稿；审核通过后会正式发布并再次邮件通知你。',
                    '如有附带资源，审核通过后会同步上架到积分商城。',
                ));
                moe_mail_send($email, '【' . $site . '】投稿成功提醒 · ' . $title, $html);
            }
        } catch (Throwable $e) { /* 邮件失败不影响投稿 */ }

        return array('ok' => true, 'msg' => '投稿成功 ✅ 已提交给站长审核' . $resMsg, 'post_id' => $pid);
    }
}

/** 2.2.22：用户中心友链申请（与 api/link.php 同一套校验 / 回链检测 / 自动通过逻辑） */
if (!function_exists('moe_uc_friend_apply')) {
    function moe_uc_friend_apply($name, $url, $contact)
    {
        if (!function_exists('moe_check_backlink')) {
            $f = MOE_ROOT . '/includes/linkcheck.php';
            if (is_file($f)) require_once $f;
        }
        if (!function_exists('moe_check_backlink')) return array('ok' => false, 'msg' => '友链检测模块缺失（includes/linkcheck.php）');
        $url = trim($url);
        if ($url === '') return array('ok' => false, 'msg' => '请填写你的站点地址');
        if (!preg_match('#^https?://#i', $url)) $url = 'https://' . ltrim($url, '/');
        if (!filter_var($url, FILTER_VALIDATE_URL)) return array('ok' => false, 'msg' => '站点地址格式不正确');
        if (function_exists('mb_strlen') && mb_strlen($contact, 'UTF-8') > 60) return array('ok' => false, 'msg' => '联系方式太长啦');

        $host = moe_url_host($url);
        if ($host === '') return array('ok' => false, 'msg' => '站点地址格式不正确');
        try {
            foreach ((array)rows('SELECT name, status FROM ' . moe_table('links')) as $l) {
                if (moe_url_host((string)$l['url']) === $host) {
                    $st = $l['status'] === 'approved' ? '已在友链列表中展示' : '已在待审核列表中，等待站长处理';
                    return array('ok' => false, 'msg' => '「' . $l['name'] . '」' . $st . '，请勿重复提交');
                }
            }
        } catch (Throwable $e) {}

        @set_time_limit(30);
        $check = moe_check_backlink($url);
        $name = trim($name);
        if ($name === '') $name = $check['title'] !== '' ? $check['title'] : $host;
        if (function_exists('mb_strlen') && mb_strlen($name, 'UTF-8') > 60) $name = mb_substr($name, 0, 60, 'UTF-8');
        $autoOk = !empty($check['ok']);
        $status = $autoOk ? 'approved' : 'pending';
        $logo = !empty($check['icon']) ? $check['icon'] : '';
        $desc = !empty($check['desc']) ? $check['desc'] : '';
        q('INSERT INTO ' . moe_table('links') . ' (name,url,logo,description,contact,status,check_result,last_check,sort,created_at)
           VALUES (?,?,?,?,?,?,?,?,0,NOW())',
            array($name, $url, $logo, $desc, $contact, $status, $check['msg'], date('Y-m-d H:i:s')));
        if ($autoOk) {
            if (function_exists('moe_notify_link_result')) moe_notify_link_result($name, $url, true, $contact);
            return array('ok' => true, 'msg' => '检测到你已添加本站链接，友链「' . $name . '」已自动通过并展示 🎉');
        }
        return array('ok' => true, 'msg' => '未检测到本站链接（可能被 JS 动态渲染），申请已提交，站长会尽快人工审核～');
    }
}

/** 2.2.22：投稿/审核邮件通知（SMTP 就绪才发送） */
if (!function_exists('moe_uc_contribute_notify')) {
    function moe_uc_contribute_notify($postTitle, $authorId, $approved)
    {
        try {
            $ur = row('SELECT email FROM ' . moe_table('users') . ' WHERE id = ?', array((int)$authorId));
            $email = trim((string)($ur['email'] ?? ''));
            if ($email === '' || !function_exists('moe_mail_ready') || !moe_mail_ready()
                || !function_exists('moe_mail_send') || !function_exists('moe_mail_template')) return;
            $site = function_exists('moe_mail_from_name') ? moe_mail_from_name() : setting('site_name', 'MoeZ');
            if ($approved) {
                $html = moe_mail_template('投稿审核通过 🎉', array(
                    '恭喜！你的投稿「<b>' . e($postTitle) . '</b>」已通过审核并正式发布。',
                    '如有附带资源，也已同步上架到积分商城，其他用户现在可以兑换下载了。',
                    '感谢你的分享，欢迎继续投稿～',
                ));
                moe_mail_send($email, '【' . $site . '】投稿已通过 · ' . $postTitle, $html);
            } else {
                $html = moe_mail_template('投稿退回提醒', array(
                    '很抱歉，你的投稿「<b>' . e($postTitle) . '</b>」暂时未通过审核，已转存为草稿。',
                    '可联系站长了解具体原因，修改后欢迎再次投稿。',
                ));
                moe_mail_send($email, '【' . $site . '】投稿退回提醒 · ' . $postTitle, $html);
            }
        } catch (Throwable $e) { /* 忽略 */ }
    }
}

/**
 * 2.2.22：用户中心二级导航
 * 第一级 = 功能分组（我的主页 / 内容 / 创作 / 商城 / 账号），第二级 = 组内具体页面。
 * 每个 item 的 key 就是路由串，例如 'shop'、'shop&sub=recharge'、'contribute'
 * （用 '&' 拼接的参数会原样接在 ?a= 后面，PHP 会正确解析为 a=shop&sub=recharge）。
 */
function moe_uc_tabs($u, $a, $uc)
{
    $shopOn = function_exists('moe_pt_shop_on') && moe_pt_shop_on();
    $ptOn   = function_exists('moe_pt_on') && moe_pt_on();
    $role   = moe_user_role($u);
    $sub    = trim((string)($_GET['sub'] ?? ''));

    // 分组：array(组名 => array(图标+标题, array(路由 => 名称)))
    $groups = array();
    $groups['home'] = array('🏠 我的主页', array('' => '🏠 概览'));

    $zone = array();
    if ($role === 'admin' || $role === 'author') $zone['posts'] = '📝 我的文章';
    $zone['comments'] = '💬 我的评论';
    $groups['zone'] = array('📚 内容', $zone);

    $create = array();
    $create['contribute'] = '📤 投稿作品';
    $create['friendlink'] = '🔗 友链申请';
    $groups['create'] = array('✍️ 创作', $create);

    $shop = array();
    if ($ptOn)     $shop['points']  = '🎁 签到积分';
    if ($shopOn) {
        $shop['shop']        = '🛒 积分商城';
        $shop['shop&sub=recharge'] = '💰 充值';
        $shop['shop&sub=exchange'] = '🔄 积分兑换';
        $shop['downloads']   = '📥 我的下载';
    }
    if (moe_uc_auth_can($u['id'])) $shop['auth'] = '🔑 我的授权码';
    if ($shop) $groups['shop'] = array('🛒 商城', $shop);

    $groups['me'] = array('⚙️ 账号', array('profile' => '✏️ 我的资料'));

    // 当前所在分组
    $curGroup = 'home';
    foreach ($groups as $gkey => $g) {
        foreach ($g[1] as $k => $_) {
            if (moe_uc_tab_match($k, $a, $sub)) { $curGroup = $gkey; break 2; }
        }
    }
    // 兼容旧路由：?a=shop&sub=contribute / friendlink 归到「创作」组
    if ($a === 'shop' && in_array($sub, array('contribute', 'friendlink'), true)) $curGroup = 'create';

    // 第一级
    $h  = '<div class="uc-grp">';
    foreach ($groups as $gkey => $g) {
        $ks = array_keys($g[1]);
        $first = (string)$ks[0];
        $h .= '<a class="' . ($gkey === $curGroup ? 'cur' : '') . '" href="'
            . e($first === '' ? $uc : $uc . '?a=' . $first)
            . '">' . e($g[0]) . '</a>';
    }
    $h .= '</div>';

    // 第二级（只有一个页面的组不重复显示）
    $items = $groups[$curGroup][1];
    if (count($items) > 1) {
        $h .= '<div class="uc-tabs sub">';
        foreach ($items as $k => $label) {
            $h .= '<a class="' . (moe_uc_tab_match($k, $a, $sub) ? 'cur' : '') . '" href="'
                . e($uc . ($k !== '' ? '?a=' . $k : '')) . '">' . e($label) . '</a>';
        }
        $h .= '</div>';
    }
    return $h;
}

/** 判断某个路由串（如 'shop&sub=recharge'）是否是当前页面 */
function moe_uc_tab_match($key, $a, $sub)
{
    if ($key === '') return $a === '' || $a === 'home';
    $parts = explode('&', $key);
    $kv = array('a' => $parts[0]);
    for ($i = 1; $i < count($parts); $i++) {
        $p = explode('=', $parts[$i], 2);
        $kv[$p[0]] = isset($p[1]) ? $p[1] : '';
    }
    if ((string)$kv['a'] !== (string)$a) return false;
    return (string)(isset($kv['sub']) ? $kv['sub'] : '') === (string)$sub;
}

function moe_uc_view_login($base, $registerOn, $cap)
{
    $h = '<div class="card"><h2>登录账号</h2>'
       . '<form method="post">' . csrf_field() . '<input type="hidden" name="act" value="login">'
       . '<div class="field"><label>用户名 / 邮箱</label><input type="text" name="username" required autofocus autocomplete="username"></div>'
       . '<div class="field"><label>密码</label><input type="password" name="password" required autocomplete="current-password"></div>'
       . '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">'
       . '<button class="btn" type="submit">登 录</button>'
       . ($registerOn ? '<a class="btn ghost" href="' . e($base . '?a=register') . '">注册新账号</a>' : '<span class="hint">本站暂未开放注册</span>')
       . '</div></form></div>'
       . '<div class="card"><h2>为什么需要用户中心？</h2>'
       . '<p class="hint" style="font-size:13px;line-height:1.9">登录后评论会自动带上你的昵称和邮箱，还能每日签到攒'
       . e(moe_pt_name()) . '、用' . e(moe_pt_name()) . '兑换下载资源，随时查看自己的评论与已兑换的资源。'
       . '作者和站长登录后可以直接进后台写文章。</p>'
       . (function_exists('moe_pt_shop_on') && moe_pt_shop_on()
            ? '<p style="margin-top:12px"><a class="btn ghost sm" href="' . e(base_url() . 'shop') . '">🛒 先逛逛积分商城 ↗</a></p>'
            : '')
       . '<p style="margin-top:12px"><a class="btn ghost sm" href="' . e(base_url() . 'admin/login.php') . '">前往后台登录 ↗</a></p></div>';
    return $h;
}

function moe_uc_view_register($base, $cap)
{
    return '<div class="card"><h2>注册新账号</h2>'
         . '<form method="post">' . csrf_field() . '<input type="hidden" name="act" value="register">'
         . '<div class="grid2">'
         . '<div class="field"><label>用户名 *（2~32 位，中文/字母/数字/下划线）</label><input type="text" name="username" required></div>'
         . '<div class="field"><label>昵称（留空用用户名）</label><input type="text" name="nickname"></div>'
         . '<div class="field"><label>邮箱（选填，用于找回与通知）</label><input type="email" name="email"></div>'
         . '<div class="field"><label>验算 <b>' . e($cap) . '</b></label><input type="text" name="captcha" required inputmode="numeric" placeholder="请输入计算结果"></div>'
         . '<div class="field"><label>密码 *（至少 6 位）</label><input type="password" name="password" required autocomplete="new-password"></div>'
         . '<div class="field"><label>确认密码 *</label><input type="password" name="password2" required autocomplete="new-password"></div>'
         . '</div><button class="btn" type="submit">注 册</button>　'
         . '<a class="btn ghost" href="' . e($base . '?a=login') . '">已有账号？去登录</a>'
         . '<p class="hint">注册账号默认为「会员」，只能在前台评论与改资料；作者权限需由站长在后台授予。</p>'
         . '</form></div>';
}

function moe_uc_view_recharge($u, $uc)
{
    $rate   = (float)setting('recharge_rate', '1');
    // 2.2.20：多张收款码（recharge_qrcodes JSON，兼容旧单码字段 recharge_qrcode）
    $qrs = array();
    $qrJson = trim((string)setting('recharge_qrcodes', ''));
    if ($qrJson !== '') $qrs = array_values(array_filter((array)json_decode($qrJson, true)));
    if (!$qrs) {
        $legacyQr = trim((string)setting('recharge_qrcode', ''));
        if ($legacyQr !== '') $qrs = array($legacyQr);
    }
    $qrNames = array('微信 / 默认', '支付宝', 'QQ', '渠道 4', '渠道 5');
    $apiOn  = trim((string)setting('recharge_api_url', '')) !== '';
    $name   = moe_pt_name();
    $cn     = function_exists('moe_pt_coin_name') ? moe_pt_coin_name() : '金币';
    $h = '<div class="card"><h2>💰 充值' . e($cn) . '</h2>'
       . '<p class="hint" style="margin:0 0 14px">充值比例 <b>1 元 = ' . e($rate) . ' ' . e($cn) . '</b>，支付完成后' . e($cn) . '自动入账。'
       . '充值记录可在下方查看，有问题请联系站长。</p>';
       // 2.2.6：去掉这里重复的萌豆余额大卡片 —— 页面顶部栏和「我的主页」都已展示余额，不再重复渲染

    // 2.2.3：支付状态实时跟踪 —— 有待确认订单（或刚提交订单跳回）时显示，
    // 每 4 秒轮询 pay-status.php，到账自动刷新页面（余额即时可见，无需手动返回）
    $trackNo = trim((string)($_GET['rc_no'] ?? ''));
    $pending = array();
    foreach (moe_rc_user_orders((int)$u['id'], 10) as $o) {
        if (($o['status'] ?? '') === 'pending') $pending[] = $o;
    }
    if ($trackNo !== '' || $pending) {
        $h .= '<div class="card" id="rc-track" data-uid="' . (int)$u['id'] . '" data-base="' . e(base_url()) . '"'
            . ' data-name="' . e($cn) . '"'
            . ' style="box-shadow:none;border:1.5px dashed #d5568e;margin-top:6px">'
            . '<h2 style="color:#d5568e">⏳ 支付状态实时跟踪</h2>'
            . '<div id="rc-track-body"><p class="hint" style="margin:0">正在检测您的充值订单状态（每 4 秒自动刷新），'
            . '站长确认到账后<b>本页面会自动刷新</b>，' . e($cn) . '即时到账，无需手动刷新或重新进入。</p></div></div>';
    }

    // 方式一：收款码扫码 + 提交订单（2.2.20：多张收款码页签切换；转账单号改为选填，扫码付完直接提交金额即可开始跟踪）
    $h .= '<div class="card" style="box-shadow:none;margin-top:6px"><h2>📷 方式一：扫码支付</h2>';
    if ($qrs) {
        $h .= '<div style="display:flex;gap:18px;flex-wrap:wrap;align-items:flex-start">';
        if (count($qrs) > 1) {
            $h .= '<div style="flex:none;width:190px">'
                . '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px" id="rc-qr-tabs">';
            foreach ($qrs as $qi => $qu) {
                $h .= '<button type="button" class="btn ghost sm rc-qr-tab' . ($qi === 0 ? ' cur' : '') . '" data-idx="' . $qi . '"'
                    . ($qi === 0 ? ' style="background:var(--grad);color:#fff;border-color:transparent"' : '') . '>' . e($qrNames[$qi] ?? ('渠道 ' . ($qi + 1))) . '</button>';
            }
            $h .= '</div>';
            foreach ($qrs as $qi => $qu) {
                $h .= '<img class="rc-qr-img" data-idx="' . $qi . '" src="' . e($qu) . '" alt="收款二维码' . ($qi + 1) . '"'
                    . ' style="width:190px;height:190px;object-fit:contain;border:1px solid #eee7f5;border-radius:12px;background:#fff;display:' . ($qi === 0 ? 'block' : 'none') . '">';
            }
            $h .= '</div>';
        } else {
            $h .= '<img src="' . e($qrs[0]) . '" alt="收款二维码" style="width:190px;height:190px;object-fit:contain;border:1px solid #eee7f5;border-radius:12px;background:#fff">';
        }
        $h .= '<form method="post" style="flex:1;min-width:230px">' . csrf_field() . '<input type="hidden" name="act" value="recharge_submit">'
            . '<div class="field"><label>实付金额（元）</label><input type="number" name="amount" min="0.1" step="0.01" required placeholder="如 10.00"></div>'
            . '<div class="field"><label>转账单号 / 转账时间后四位（选填）</label><input type="text" name="trans" maxlength="64" placeholder="支付记录里可以查到，方便站长快速核对"></div>'
            . '<div class="field"><label>联系方式（选填，便于核对）</label><input type="text" name="contact" maxlength="60"></div>'
            . '<button class="btn" type="submit">提交充值订单</button>'
            . '<p class="hint">扫码付款后填好金额直接提交即可，提交后进入「支付状态实时跟踪」，站长确认到账的瞬间页面自动刷新、' . e($cn) . '自动入账；转账单号填了核对更快，不填也不影响提交。</p>'
            . '</form></div>';
        if (count($qrs) > 1) {
            $h .= <<<'MOE_QR_TABS'
<script>
(function () {
  var tabs = document.querySelectorAll(".rc-qr-tab");
  if (!tabs.length) return;
  Array.prototype.forEach.call(tabs, function (t) {
    t.addEventListener("click", function () {
      var idx = t.getAttribute("data-idx");
      Array.prototype.forEach.call(tabs, function (x) {
        x.classList.remove("cur");
        x.style.background = "";
        x.style.color = "";
        x.style.borderColor = "";
      });
      t.classList.add("cur");
      t.style.background = "var(--grad)";
      t.style.color = "#fff";
      t.style.borderColor = "transparent";
      Array.prototype.forEach.call(document.querySelectorAll(".rc-qr-img"), function (im) {
        im.style.display = im.getAttribute("data-idx") === idx ? "block" : "none";
      });
    });
  });
})();
</script>
MOE_QR_TABS;
        }
    } else {
        $h .= '<p class="hint">站长还没有上传收款二维码（后台「金币充值」可设置，支持多张），可先用下方在线支付。</p>';
    }
    $h .= '</div>';

    // 方式二：第三方支付接口（配置了网关才显示）
    if ($apiOn) {
        $h .= '<div class="card" style="box-shadow:none"><h2>⚡ 方式二：在线支付（自动到账）</h2>'
            . '<form method="post">' . csrf_field() . '<input type="hidden" name="act" value="recharge_go">'
            . '<div class="field"><label>支付金额（元）</label><input type="number" name="amount" min="0.1" step="0.01" required placeholder="如 10.00"></div>'
            . '<button class="btn" type="submit">前往支付 →</button>'
            . '<p class="hint">跳转到支付网关完成付款后自动回调入账，无需人工确认。</p>'
            . '</form></div>';
    }

    // 2.2.9：积分 ⇄ 金币互兑（2.2.10 起改用 points.php 共享卡片，金币名称后台可自定义）
    if (function_exists('moe_pt_exchange_card')) {
        $h .= moe_pt_exchange_card($u);
    }

    // 我的充值记录
    $orders = function_exists('moe_rc_user_orders') ? moe_rc_user_orders((int)$u['id'], 10) : array();
    $h .= '<div class="card" style="box-shadow:none"><h2>🧾 我的充值记录</h2>';
    if (!$orders) {
        $h .= '<p class="hint">还没有充值记录。</p>';
    } else {
        $h .= '<table style="width:100%;border-collapse:collapse;font-size:13px"><tr style="color:#9a8fae;text-align:left">'
            . '<th style="padding:6px 4px">时间</th><th>金额</th><th>' . e($name) . '</th><th>状态</th></tr>';
        foreach ($orders as $o) {
            $st = function_exists('moe_rc_status_label') ? moe_rc_status_label((string)($o['status'] ?? '')) : (string)($o['status'] ?? '');
            $color = ($o['status'] ?? '') === 'approved' ? '#268a5b' : (($o['status'] ?? '') === 'rejected' ? '#d9506b' : '#a8791c');
            $h .= '<tr style="border-top:1px solid #f0eaf8">'
                . '<td style="padding:8px 4px">' . e($o['time'] ?? '') . '</td>'
                . '<td>¥' . e($o['amount'] ?? '') . '</td>'
                . '<td>+' . e($o['coins'] ?? '') . '</td>'
                . '<td style="color:' . $color . '">' . e($st) . '</td></tr>';
        }
        $h .= '</table>';
    }
    $h .= '</div>';

    // 2.2.3：实时跟踪轮询脚本（nowdoc 零转义；仅渲染了跟踪面板时输出，JS 自检 #rc-track 存在才执行）
    if ($trackNo !== '' || $pending) {
        $h .= <<<'MOE_RC_TRACK'
<script>
(function () {
  var el = document.getElementById("rc-track");
  if (!el) return;
  var base = el.getAttribute("data-base");
  var cname = el.getAttribute("data-name") || "金币";
  var body = document.getElementById("rc-track-body");
  var seen = {};          // 订单号 -> 上次状态
  var done = false;       // 已触发自动刷新
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      if (c === "&") return "&amp;";
      if (c === "<") return "&lt;";
      if (c === ">") return "&gt;";
      if (c === "'") return "&#39;";
      return "&quot;";
    });
  }
  function label(s) {
    return s === "approved" ? "✅ 已到账" : (s === "rejected" ? "❌ 已驳回" : "⏳ 待确认");
  }
  function poll() {
    if (done) return;
    fetch(base + "pay/pay-status.php", { credentials: "same-origin", cache: "no-store" })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.ok) return;
        var orders = d.orders || [];
        var hit = null;
        orders.forEach(function (o) {
          if (seen[o.no] === "pending" && o.status === "approved") hit = o;
          seen[o.no] = o.status;
        });
        if (hit) {
          done = true;
          body.innerHTML = '<p style="color:#268a5b;font-weight:600;margin:0">🎉 充值成功！'
            + esc(hit.coins) + " 个" + esc(cname) + "已到账，页面正在自动刷新…</p>";
          setTimeout(function () { location.reload(); }, 1600);
          return;
        }
        var rows = orders.filter(function (o) { return o.status !== "approved"; });
        if (!rows.length) {
          body.innerHTML = '<p class="hint" style="margin:0">暂无待确认的充值订单。</p>';
          return;
        }
        var html = "";
        rows.forEach(function (o) {
          var c = o.status === "rejected" ? "#d9506b" : "#a8791c";
          html += '<div style="display:flex;justify-content:space-between;gap:10px;padding:7px 0;'
            + 'border-bottom:1px dashed #f0eaf8;font-size:13.5px"><span>订单 ' + esc(o.no)
            + " · ¥" + esc(o.amount) + "（+" + esc(o.coins) + "）</span><b style=\"color:" + c + "\">"
            + label(o.status)
            + (o.status === "rejected" && o.note ? "：" + esc(o.note) : "")
            + "</b></div>";
        });
        body.innerHTML = html
          + '<p class="hint" style="margin:8px 0 0">站长确认到账（或网关回调成功）后本页面会自动刷新，' . e(function_exists('moe_pt_coin_name') ? moe_pt_coin_name() : '金币') . '即时可见。</p>';
      })
      .catch(function () { /* 网络抖动：下一轮继续 */ });
  }
  poll();
  setInterval(poll, 4000);
})();
</script>
MOE_RC_TRACK;
    }
    return $h;
}

function moe_uc_view_home($u, $uc, $stats)
{
    $role = moe_user_role($u);
    $h = '<div class="card"><div class="profile-head">'
       . '<img src="' . e(moe_user_avatar($u)) . '" alt="">'
       . '<div><div class="nm">' . e(moe_user_display($u)) . ' '
       . '<span class="pill ' . e($role) . '">' . e(moe_user_role_label($role)) . '</span></div>'
       . '<div class="sub">@' . e($u['username']) . ' · 加入于 ' . e(date('Y-m-d', strtotime((string)$u['created_at']))) . '</div>'
       . '<div class="sub">' . (trim((string)($u['bio'] ?? '')) !== '' ? e($u['bio']) : '这个人很懒，还没有写简介～') . '</div></div></div>'
       . '<div class="stats"><div class="stat"><b>' . (int)$stats['posts'] . '</b><span>已发布文章</span></div>'
       . '<div class="stat"><b>' . (int)$stats['comments'] . '</b><span>我的评论</span></div>'
       . '<div class="stat"><b>' . e(moe_user_role_label($role)) . '</b><span>账号身份</span></div></div></div>';
    // 2.1.0：积分卡（余额 / 今日签到 / 连签）
    if (function_exists('moe_pt_balance_card') && moe_pt_on()) {
        $h .= moe_pt_balance_card($u, true);
    }
    $h .= '<div class="card"><h2>快捷入口</h2><div class="quick">'
        . '<a href="' . e($uc . '?a=profile') . '">✏️ 编辑资料<small>头像 / 昵称 / 邮箱 / 简介</small></a>'
        . '<a href="' . e($uc . '?a=comments') . '">💬 我的评论<small>查看参与过的讨论</small></a>'
        . '<a href="' . e(moe_user_url($u)) . '">🌐 公开主页<small>别人看到的作者页</small></a>';
    if (function_exists('moe_pt_on') && moe_pt_on()) {
        $h .= '<a href="' . e($uc . '?a=points') . '">🎁 签到积分<small>每日签到 · 积分明细</small></a>';
    }
    if (function_exists('moe_pt_shop_on') && moe_pt_shop_on()) {
        $h .= '<a href="' . e($uc . '?a=shop') . '">🛒 积分商城<small>兑换资源 · 充值' . e(function_exists('moe_pt_coin_name') ? moe_pt_coin_name() : '金币') . '</small></a>'
            . '<a href="' . e($uc . '?a=downloads') . '">📥 我的下载<small>已兑换资源随时下</small></a>';
    }
    if ($role === 'admin' || $role === 'author') {
        $h .= '<a href="' . e(base_url() . 'admin/index.php') . '">📝 进入后台<small>写文章 / 管理内容</small></a>';
    }
    $h .= '</div></div>';
    return $h;
}

function moe_uc_view_profile($u, $uc)
{
    $qq = trim((string)($u['qq'] ?? ''));
    return '<div class="card"><h2>编辑个人资料</h2>'
        . '<form method="post">' . csrf_field() . '<input type="hidden" name="act" value="profile">'
        . '<div class="grid2">'
        . '<div class="field"><label>昵称</label><input type="text" name="nickname" value="' . e($u['nickname'] ?? '') . '"></div>'
        . '<div class="field"><label>邮箱</label><input type="email" name="email" value="' . e($u['email'] ?? '') . '"></div>'
        . '<div class="field"><label>QQ 号（可一键获取头像）</label><input type="text" id="ucQQ" name="qq" value="' . e($qq) . '" placeholder="5~12 位数字"></div>'
        . '<div class="field"><label>个人网站</label><input type="text" name="site" value="' . e($u['site'] ?? '') . '" placeholder="https://..."></div>'
        . '</div>'
        . '<div class="field"><label>头像地址</label>'
        . '<div style="display:flex;gap:9px;align-items:center;flex-wrap:wrap">'
        . '<img id="ucAvaPrev" src="' . e(moe_user_avatar($u)) . '" alt="" style="width:56px;height:56px;border-radius:50%;object-fit:cover">'
        . '<input type="text" id="ucAva" name="avatar" value="' . e($u['avatar'] ?? '') . '" placeholder="图片地址，留空使用站点默认头像" style="flex:1;min-width:180px">'
        . '<button class="btn ghost sm" type="button" id="ucQQBtn">🐧 用 QQ 头像</button></div>'
        . '<p class="hint">QQ 头像使用官方接口；也可以直接粘贴任意图片地址。头像用于前台评论与作者主页。</p></div>'
        . '<div class="field"><label>个人简介</label><textarea name="bio" maxlength="120" placeholder="一句话介绍自己">' . e($u['bio'] ?? '') . '</textarea></div>'
        . '<button class="btn" type="submit">💾 保存资料</button></form></div>'
        . '<div class="card"><h2>🔐 修改密码</h2>'
        . '<form method="post">' . csrf_field() . '<input type="hidden" name="act" value="password">'
        . '<div class="grid2">'
        . '<div class="field"><label>当前密码 *</label><input type="password" name="cur_pass" required autocomplete="current-password"></div>'
        . '<div class="field"><label>新密码（至少 6 位）</label><input type="password" name="new_pass" required autocomplete="new-password"></div>'
        . '<div class="field"><label>确认新密码</label><input type="password" name="new_pass2" required autocomplete="new-password"></div>'
        . '</div><button class="btn" type="submit">🔐 修改密码</button></form></div>'
        . '<script>document.getElementById("ucQQBtn").addEventListener("click",function(){'
        . 'var q=(document.getElementById("ucQQ").value||"").trim();'
        . 'if(!/^\d{5,12}$/.test(q)){alert("请填写正确的 QQ 号（5~12 位数字）");return;}'
        . 'var url="https://q1.qlogo.cn/g?b=qq&nk="+q+"&s=640";'
        . 'document.getElementById("ucAva").value=url;document.getElementById("ucAvaPrev").src=url;});</script>'
        // 2.0.1：社交与展示在前台的只读呼应，编辑入口统一在后台用户中心
        . '<div class="card"><h2>💬 社交与展示</h2>'
        . '<p class="hint" style="margin:-6px 0 14px">前台首页展示的社交链接，由站长在后台「用户中心」维护。</p>'
        . moe_social_preview_html()
        . (function_exists('moe_is_owner') && moe_is_owner()
            ? '<p style="margin-top:14px"><a class="btn ghost sm" href="'
              . e(base_url() . 'admin/profile.php#social') . '">✏️ 去后台编辑社交链接 ↗</a></p>'
            : '')
        . '</div>';
}

function moe_uc_view_comments($u)
{
    $mail = trim((string)($u['email'] ?? ''));
    $rows = array();
    try {
        $sql = 'SELECT c.*, p.title AS post_title, p.id AS pid FROM ' . moe_table('comments') . ' c '
             . 'LEFT JOIN ' . moe_table('posts') . ' p ON p.id = c.post_id WHERE c.user_id = ?';
        $args = array((int)$u['id']);
        if ($mail !== '') { $sql .= ' OR (c.user_id = 0 AND c.email = ?)'; $args[] = $mail; }
        $sql .= ' ORDER BY c.id DESC LIMIT 40';
        $rows = rows($sql, $args);
    } catch (Throwable $e) { $rows = array(); }
    $h = '<div class="card"><h2>我的评论（' . count($rows) . '）</h2>';
    if (empty($rows)) {
        $h .= '<p class="hint">还没有评论记录。去文章下面聊两句吧～</p>';
    } else {
        $uc      = base_url() . 'user';
        $editId  = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
        $canEdit = setting('comment_edit', '1') === '1';
        // 2.2.7：改为评论卡片（文章标题 + 状态胶囊 + 时间 + 内容 + 编辑）
        foreach ($rows as $c) {
            $cid    = (int)$c['id'];
            $title  = trim((string)($c['post_title'] ?? ''));
            $link   = (int)($c['pid'] ?? 0) > 0 ? post_url(array('id' => (int)$c['pid'], 'slug' => '')) : base_url();
            $shown  = (string)$c['status'] === 'approved';
            $h .= '<div id="uc-cm-' . $cid . '" style="border:1px solid #efe9f8;border-radius:15px;'
                . 'padding:14px 17px;margin-bottom:12px;background:#fff;box-shadow:0 2px 10px rgba(146,120,200,.06)">'
                . '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">'
                . '<a href="' . e($link) . '" style="font-weight:700;color:#4a4060;text-decoration:none;font-size:14px">📄 '
                . e($title !== '' ? $title : '（文章已删除）') . '</a>'
                . '<span style="flex:none;font-size:11.5px;padding:3px 11px;border-radius:99px;font-weight:600;'
                . ($shown ? 'background:#e5f6ec;color:#268a5b' : 'background:#fff4e0;color:#a8791c') . '">'
                . ($shown ? '已展示' : '待审核') . '</span></div>'
                . '<div style="color:#9a8fae;font-size:12px;margin-top:4px">' . e((string)$c['created_at']) . '</div>'
                . '<div style="margin-top:8px;font-size:13.5px;line-height:1.75;color:#544a6b;word-break:break-word">'
                . e(mb_substr((string)$c['content'], 0, 200, 'UTF-8')) . '</div>';
            if ($canEdit) {
                $h .= '<details class="uc-edit"' . ($cid === $editId ? ' open' : '') . '>'
                    . '<summary>✏️ 编辑这条评论</summary>'
                    . '<form method="post" action="' . e($uc . '?a=comments') . '">'
                    . csrf_field()
                    . '<input type="hidden" name="act" value="edit_comment"><input type="hidden" name="cid" value="' . $cid . '">'
                    . '<textarea name="content" rows="4" maxlength="2000" required>' . e((string)$c['content']) . '</textarea>'
                    . '<p style="margin-top:9px;display:flex;gap:9px;align-items:center">'
                    . '<button class="btn sm" type="submit">保存修改</button>'
                    . '<span class="hint" style="margin:0">保存后立即在前台生效</span></p>'
                    . '</form></details>';
            }
            $h .= '</div>';
        }
    }
    return $h . '</div>';
}

function moe_uc_view_posts($u)
{
    $rows = array();
    try {
        $rows = rows('SELECT * FROM ' . moe_table('posts')
            . " WHERE user_id = ? AND type = 'post' AND auto_draft = 0 AND draft_of = 0 ORDER BY id DESC LIMIT 30",
            array((int)$u['id']));
    } catch (Throwable $e) { $rows = array(); }
    $h = '<div class="card"><h2>我的文章（' . count($rows) . '）</h2>';
    if (empty($rows)) $h .= '<p class="hint">还没有文章，去后台写第一篇吧～</p>';
    // 2.2.7：改为封面卡片网格（复用商城卡片样式）
    $h .= '<div class="pt-goods">';
    foreach ($rows as $p) {
        $h .= '<a class="pt-goods-card" href="' . e(post_url($p)) . '" style="text-decoration:none">'
            . moe_pt_cover_html(array('title' => (string)$p['title'], 'cover' => (string)($p['cover'] ?? '')))
            . '<div class="pt-goods-body"><h3>' . e($p['title']) . '</h3>'
            . '<div class="pt-goods-meta"><span class="pt-price">'
            . ((string)$p['status'] === 'published' ? '✅ 已发布' : '📝 草稿')
            . '</span><span class="pt-dl-num">👁 ' . (int)$p['views'] . '</span></div>'
            . '<p style="margin:0">' . e(date('Y-m-d H:i', strtotime((string)$p['created_at']))) . '</p>'
            . '</div></a>';
    }
    $h .= '</div>';
    $h .= '<p style="margin-top:16px"><a class="btn sm" href="' . e(base_url() . 'admin/post-edit.php') . '">✏️ 写新文章</a></p></div>';
    return $h;
}

function moe_uc_view_author($au)
{
    $role  = moe_user_role($au);
    $stats = moe_user_stats($au['id']);
    $posts = array();
    try {
        $posts = rows('SELECT * FROM ' . moe_table('posts')
            . " WHERE user_id = ? AND type = 'post' AND status = 'published' ORDER BY created_at DESC LIMIT 20",
            array((int)$au['id']));
    } catch (Throwable $e) { $posts = array(); }
    $h = '<div class="card"><div class="profile-head">'
       . '<img src="' . e(moe_user_avatar($au)) . '" alt="">'
       . '<div><div class="nm">' . e(moe_user_display($au)) . ' <span class="pill ' . e($role) . '">'
       . e(moe_user_role_label($role)) . '</span></div>'
       . '<div class="sub">@' . e($au['username']) . ' · 加入于 ' . e(date('Y-m-d', strtotime((string)$au['created_at']))) . '</div>'
       . '<div class="sub">' . (trim((string)($au['bio'] ?? '')) !== '' ? e($au['bio']) : '这个人很懒，还没有写简介～') . '</div>'
       . (trim((string)($au['site'] ?? '')) !== '' ? '<div class="sub"><a href="' . e($au['site']) . '" target="_blank" rel="noopener">🔗 ' . e($au['site']) . '</a></div>' : '')
       . '</div></div><div class="stats">'
       . '<div class="stat"><b>' . (int)$stats['posts'] . '</b><span>发布文章</span></div>'
       . '<div class="stat"><b>' . (int)$stats['comments'] . '</b><span>参与评论</span></div>'
       . '<div class="stat"><b>' . e(moe_user_role_label($role)) . '</b><span>身份</span></div></div></div>';
    $h .= '<div class="card"><h2>TA 的文章（' . count($posts) . '）</h2>';
    if (empty($posts)) $h .= '<p class="hint">暂时还没有公开发布的文章。</p>';
    foreach ($posts as $p) {
        $h .= '<div class="list-item"><a class="t" href="' . e(post_url($p)) . '">' . e($p['title']) . '</a>'
            . '<div class="m">' . e((string)$p['created_at']) . ' · ' . (int)$p['views'] . ' 次浏览</div>'
            . '<div class="txt">' . e(excerpt_text(render_content($p['content'] ?? '', $p['content_format'] ?? 'markdown'), 110)) . '</div></div>';
    }
    return $h . '</div>';
}

/**
 * 用户中心入口：index.php 在路由阶段直接调用，不走 render() / 页面缓存
 * @param string $mode user | author
 * @param string $seg  路径第二段（如 /user/profile）
 */
function moe_user_center_page($mode = 'user', $seg = '')
{
    $uc  = base_url() . 'user';
    $u   = current_user();
    $a   = isset($_GET['a']) ? (string)$_GET['a'] : '';
    if ($a === '' && $seg !== '') $a = $seg;
    $err = '';
    $okMsg = '';
    $f  = moe_uc_take_flash();
    if ($f) { if ($f['type'] === 'bad') $err = $f['msg']; else $okMsg = $f['msg']; }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        csrf_verify();
        $act = (string)($_POST['act'] ?? '');
        if ($act === 'logout') {
            moe_user_logout();
            header('Location: ' . $uc . '?a=login');
            exit;
        }
        if ($act === 'login') {
            $r = moe_user_login($_POST['username'] ?? '', $_POST['password'] ?? '', true);
            if ($r[0]) { moe_uc_flash('欢迎回来，' . moe_user_display($r[2]) . ' 🌸'); moe_uc_goto(); }
            $err = $r[1];
            $a = 'login';
        } elseif ($act === 'register') {
            $r = moe_user_register($_POST);
            if ($r[0]) { moe_uc_flash($r[1]); moe_uc_goto('login'); }
            $err = $r[1];
            $a = 'register';
        } elseif ($act === 'profile' && $u) {
            $r = moe_user_save_profile($u['id'], $_POST);
            if ($r[0]) { moe_uc_flash($r[1]); moe_uc_goto('profile'); }
            $err = $r[1];
            $a = 'profile';
        } elseif ($act === 'password' && $u) {
            $r = moe_user_change_password($u['id'], $_POST['cur_pass'] ?? '', $_POST['new_pass'] ?? '', $_POST['new_pass2'] ?? '');
            if ($r[0]) { moe_uc_flash($r[1], 'warn'); moe_uc_goto('profile'); }
            $err = $r[1];
            $a = 'profile';
        } elseif ($act === 'signin' && $u) {
            // 2.1.0：每日签到（表单提交，无需 JS；每人每天一次由数据库唯一键兜底）
            $back = (string)($_POST['back'] ?? 'points');
            if (!in_array($back, array('points', 'shop', 'downloads'), true)) $back = 'points';
            if (function_exists('moe_pt_sign_do')) {
                $r = moe_pt_sign_do((int)$u['id']);
                moe_uc_flash((string)$r['msg'], !empty($r['ok']) ? 'ok' : 'bad');
            } else {
                moe_uc_flash('积分模块未加载', 'bad');
            }
            moe_uc_goto($back);
        } elseif ($act === 'buy' && $u) {
            // 2.1.0：积分兑换（扣分 + 写订单，失败自动退回）；2.2.2：可选积分或金币
            // 2.2.22：授权码类商品（cat=授权码）—— 购买时必须绑定域名，付款成功自动签发授权码
            $gid = (int)($_POST['gid'] ?? 0);
            $currency = ($_POST['currency'] ?? 'points') === 'coins' ? 'coins' : 'points';
            if (function_exists('moe_pt_buy')) {
                $authGoods = null;
                try {
                    $g0 = row('SELECT * FROM ' . moe_pt_table('goods') . ' WHERE id = ?', array($gid));
                    if ($g0 && trim((string)($g0['cat'] ?? '')) === '授权码') $authGoods = $g0;
                } catch (Throwable $e) {}
                if ($authGoods) {
                    $domain = strtolower(trim((string)($_POST['auth_domain'] ?? '')));
                    if (!function_exists('moe_auth_code_generate') || (string)setting('update_hub_secret', '') === '') {
                        moe_uc_flash('本站授权服务还未初始化，暂时无法购买授权码类资源，请联系站长', 'bad');
                        moe_uc_goto('shop'); exit;
                    }
                    if ($domain === '' || !preg_match('/^[\w\.-]+\.[a-zA-Z]{2,}$/u', $domain)) {
                        moe_uc_flash('购买授权码需要填写要绑定的站点域名（如 example.com，不带 https://）', 'bad');
                        moe_uc_goto('shop'); exit;
                    }
                    foreach (moe_uc_auth_codes_of((int)$u['id']) as $c) {
                        if (strcasecmp((string)$c['domain'], $domain) === 0) {
                            moe_uc_flash('域名 ' . $domain . ' 已经绑定过授权码了，可在「我的授权码」查看', 'warn');
                            moe_uc_goto('auth'); exit;
                        }
                    }
                }

                $r = moe_pt_buy((int)$u['id'], $gid, $currency);
                moe_uc_flash((string)$r['msg'], !empty($r['ok']) ? 'ok' : 'bad');

                /* 2.2.22：授权码购买成功 → 自动签发并绑定域名，引导下载程序 */
                if (!empty($r['ok']) && $authGoods) {
                    $gr = moe_auth_code_generate($domain, 0, (string)setting('update_hub_secret', ''));
                    if (!empty($gr['ok'])) {
                        $all = moe_uc_auth_codes_load();
                        $all[] = array(
                            'user_id' => (int)$u['id'], 'domain' => $gr['domain'], 'code' => $gr['code'],
                            'email' => (string)($u['email'] ?? ''),
                            'expire' => $gr['expire'], 'issued_at' => date('Y-m-d H:i:s'),
                            'goods_id' => $gid, 'source' => '商城购买',
                        );
                        moe_uc_auth_codes_save($all);
                        /* 同步写进官方站点档案（后台可统一管控） */
                        $sf = MOE_ROOT . '/content/updates/auth-sites.json';
                        $sites = is_file($sf) ? json_decode((string)@file_get_contents($sf), true) : null;
                        if (is_array($sites)) {
                            array_unshift($sites, array(
                                'tail' => substr($gr['code'], -8), 'domain' => $gr['domain'],
                                'email' => (string)($u['email'] ?? ''),
                                'expire' => $gr['expire'], 'note' => '商城购买授权码 · 用户 #' . (int)$u['id'] . ' · 商品 #' . $gid,
                                'status' => 'ok', 'status_note' => '', 'issued_at' => date('Y-m-d H:i:s'),
                            ));
                            @file_put_contents($sf, json_encode(array_values(array_slice($sites, 0, 500)),
                                JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT), LOCK_EX);
                        }
                        moe_uc_flash('授权码购买成功 ✅ 已绑定域名 ' . $gr['domain'] . '（永久有效）。请到「我的授权码」查看授权码，并下载程序部署。');
                        header('Location: ' . base_url() . 'user?a=auth'); exit;
                    }
                    moe_uc_flash('授权码签发失败：' . (string)($gr['msg'] ?? '未知错误') . '。费用已扣除，请联系站长处理或手动补发。', 'bad');
                    moe_uc_goto('auth'); exit;
                }

                // 2.1.6：正文里的下载卡片兑换后回到原文章（只允许站内地址）
                $backUrl = trim((string)($_POST['back_url'] ?? ''));
                if (!empty($r['ok']) && $backUrl !== '' && strpos($backUrl, base_url()) === 0) {
                    redirect($backUrl);
                }
                // 商城里发起的兑换成功后留在商城；失败也回商城（能看到余额与充值入口）
                $fromShop = ($_POST['back'] ?? '') === 'shop';
                moe_uc_goto(!empty($r['ok']) ? ($fromShop ? 'shop' : 'downloads') : 'shop');
            }
            moe_uc_flash('积分模块未加载', 'bad');
            moe_uc_goto('shop');
        } elseif ($act === 'auth_sendcode' && $u) {
            // 2.2.6：签发授权码前先邮箱验证 —— 6 位验证码发到会员邮箱，10 分钟有效，60 秒防刷
            $email = trim((string)($_POST['email'] ?? ''));
            $msg = ''; $ok = false;
            do {
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $msg = '请先填写正确的接收邮箱'; break; }
                if (!function_exists('moe_mail_send')) { $msg = '邮件模块缺失（includes/mail.php）'; break; }
                $now = time();
                $v = isset($_SESSION['moe_auth_vcode']) && is_array($_SESSION['moe_auth_vcode']) ? $_SESSION['moe_auth_vcode'] : null;
                if ($v && (int)($v['t'] ?? 0) > $now - 60 && strcasecmp((string)($v['email'] ?? ''), $email) === 0) {
                    $msg = '发送太频繁了，请 1 分钟后再试（之前发的验证码仍然有效）'; break;
                }
                $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
                $_SESSION['moe_auth_vcode'] = array('code' => $code, 'email' => strtolower($email), 't' => $now);
                $site = function_exists('moe_mail_from_name') ? moe_mail_from_name() : 'MoeZ';
                $html = function_exists('moe_mail_template')
                    ? moe_mail_template('授权码签发验证码', array(
                        '你正在签发程序站点授权码，本次操作的验证码为：',
                        '<b style="font-size:24px;letter-spacing:6px">' . $code . '</b>',
                        '验证码 10 分钟内有效；如非本人操作，请忽略本邮件。',
                    ))
                    : '<p>验证码：' . $code . '（10 分钟内有效）</p>';
                $r2 = moe_mail_send($email, '【' . $site . '】授权码签发验证码 ' . $code, $html);
                if (!empty($r2['ok'])) {
                    $ok = true;
                    $msg = '✅ 验证码已发送到 ' . $email . '，请查收（10 分钟内有效，注意垃圾箱）';
                } else {
                    $msg = '验证码邮件发送失败' . (isset($r2['msg']) && $r2['msg'] !== '' ? '：' . $r2['msg'] : '') . '（站点需在后台配置好 SMTP）';
                }
            } while (false);
            moe_uc_flash($msg, $ok ? 'ok' : 'bad');
            moe_uc_goto('auth');
        } elseif ($act === 'auth_issue' && $u) {
            // 2.2.5：购买了程序类资源的会员自助签发站点授权码（永久）；2.2.6：需邮箱验证码
            $email = strtolower(trim((string)($_POST['email'] ?? '')));
            $vcode = trim((string)($_POST['vcode'] ?? ''));
            $v = isset($_SESSION['moe_auth_vcode']) && is_array($_SESSION['moe_auth_vcode']) ? $_SESSION['moe_auth_vcode'] : null;
            $valid = $v
                && (int)($v['t'] ?? 0) >= time() - 600
                && (string)($v['email'] ?? '') === $email
                && $vcode !== ''
                && hash_equals((string)($v['code'] ?? ''), $vcode);
            if (!$valid) {
                moe_uc_flash('邮箱验证码不正确或已过期，请重新获取后再签发', 'bad');
            } else {
                $r = moe_uc_auth_issue((int)$u['id'], (string)($_POST['domain'] ?? ''), $email);
                moe_uc_flash((string)$r['msg'], !empty($r['ok']) ? 'ok' : 'bad');
                if (!empty($r['ok'])) unset($_SESSION['moe_auth_vcode']);
            }
            moe_uc_goto('auth');
        } elseif ($act === 'recharge_submit' && $u) {
            // 2.2.1：收款码模式 —— 扫码转账后提交实付金额 + 单号，后台确认到账
            $r = function_exists('moe_rc_submit')
                ? moe_rc_submit((int)$u['id'], (float)($_POST['amount'] ?? 0), (string)($_POST['trans'] ?? ''), (string)($_POST['contact'] ?? ''))
                : array('ok' => 0, 'msg' => '充值模块未加载');
            moe_uc_flash((string)$r['msg'], !empty($r['ok']) ? 'ok' : 'bad');
            // 2.2.3：成功后带订单号跳回商城充值区，立即开启支付状态实时跟踪（2.2.22：跳充值二级页签）
            if (!empty($r['ok']) && !empty($r['no'])) {
                header('Location: ' . base_url() . 'user?a=shop&sub=recharge&rc_no=' . urlencode((string)$r['no']) . '#rc-top');
                exit;
            }
            moe_uc_goto('shop');
        } elseif ($act === 'recharge_go' && $u) {
            // 2.2.1：第三方接口模式 —— 创建订单并跳转支付网关，网关回调 pay-notify.php 自动到账
            // 2.2.3：网关带 return_url，支付完成后浏览器自动回到商城充值区并实时跟踪
            $r = function_exists('moe_rc_api_order')
                ? moe_rc_api_order((int)$u['id'], (float)($_POST['amount'] ?? 0))
                : array('ok' => 0, 'msg' => '充值模块未加载');
            if (!empty($r['ok'])) { header('Location: ' . $r['url']); exit; }
            moe_uc_flash((string)$r['msg'], 'bad');
            moe_uc_goto('shop');
        } elseif ($act === 'ex_p2c' && $u) {
            // 2.2.9：积分兑金币；2.2.10 起走 points.php 共享逻辑（金币名称后台可自定义）；2.2.22：回互兑页签
            $r = moe_pt_exchange_run('ex_p2c', (int)$u['id']);
            moe_uc_flash((string)$r[1], !empty($r[0]) ? 'ok' : 'bad');
            header('Location: ' . base_url() . 'user?a=shop&sub=exchange'); exit;
        } elseif ($act === 'ex_c2p' && $u) {
            // 2.2.9：金币兑积分；2.2.10 起走 points.php 共享逻辑；2.2.22：回互兑页签
            $r = moe_pt_exchange_run('ex_c2p', (int)$u['id']);
            moe_uc_flash((string)$r[1], !empty($r[0]) ? 'ok' : 'bad');
            header('Location: ' . base_url() . 'user?a=shop&sub=exchange'); exit;
        } elseif ($act === 'edit_comment' && $u) {
            // 2.1.2：会员修改自己的评论（后台「站点设置 → 允许会员编辑自己的评论」可关闭）
            $r = moe_user_edit_comment((int)$u['id'], (string)$u['email'],
                (int)($_POST['cid'] ?? 0), (string)($_POST['content'] ?? ''));
            moe_uc_flash($r[1], $r[0] ? 'ok' : 'bad');
            moe_uc_goto('comments', $r[0] ? (int)($_POST['cid'] ?? 0) : 0);
        } elseif ($act === 'contribute_submit' && $u) {
            // 2.2.22：会员投稿 —— 存为待审文章，可选同时上架资源；投稿成功发邮件提醒
            $r = moe_uc_contribute_save($u['id'], $_POST);
            moe_uc_flash((string)$r['msg'], !empty($r['ok']) ? 'ok' : 'bad');
            header('Location: ' . base_url() . 'user?a=contribute'); exit;
        } elseif ($act === 'friend_apply' && $u) {
            // 2.2.22：用户中心友链申请（与前台 api/link.php 同一套检测逻辑）
            $r = moe_uc_friend_apply((string)($_POST['name'] ?? ''), (string)($_POST['url'] ?? ''), (string)($_POST['contact'] ?? ''));
            moe_uc_flash((string)$r['msg'], !empty($r['ok']) ? 'ok' : 'bad');
            header('Location: ' . base_url() . 'user?a=friendlink'); exit;
        }
    }

    // 公开作者主页（无需登录）
    if ($mode === 'author') {
        $au = moe_user_by($seg);
        if (!$au) { http_response_code(404); moe_uc_shell('作者不存在', '', '<div class="card"><p class="hint">没有找到这位作者。</p></div>', $u); exit; }
        moe_uc_shell(moe_user_display($au), '作者主页',
            '<p style="margin-bottom:16px"><a class="btn ghost sm" href="' . e(base_url()) . '">← 返回站点</a></p>'
            . moe_uc_view_author($au), $u);
        exit;
    }

    $alert = ($err !== '' ? '<div class="alert bad">' . e($err) . '</div>' : '')
           . ($okMsg !== '' ? '<div class="alert ' . ($f && $f['type'] === 'warn' ? 'warn' : 'ok') . '">' . e($okMsg) . '</div>' : '');

    if (!$u) {
        $registerOn = setting('user_register', '0') === '1';
        if ($a === 'register' && $registerOn) {
            $body = moe_uc_view_register($uc, moe_uc_captcha());
            $title = '注册新账号'; $sub = '加入 ' . setting('site_name', 'MoeZ') . '，一起聊聊';
        } else {
            $body = moe_uc_view_login($uc, $registerOn, '');
            $title = '用户中心'; $sub = '登录后即可管理资料与评论';
        }
        moe_uc_shell($title, $sub, $alert . $body, null);
        exit;
    }

    // 2.2.22：投稿 / 友链申请升级为一级页面（旧链接 user?a=shop&sub=contribute 自动兼容）
    if ($a === 'shop' && in_array((string)($_GET['sub'] ?? ''), array('contribute', 'friendlink'), true)) {
        $a = (string)$_GET['sub'];
        unset($_GET['sub']);
    }

    $tabs = moe_uc_tabs($u, $a, $uc);
    $ucTitle = '用户中心';
    $ucSub   = '你好，' . moe_user_display($u) . ' 👋';
    if ($a === 'points') {
        $ucTitle = '签到积分';
        $ucSub = '每天签到、发表评论都能攒' . moe_pt_name() . '，攒够了去商城兑换资源';
    } elseif ($a === 'shop') {
        $ucTitle = '积分商城';
        $ucSub = '用' . moe_pt_name() . '兑换本站资源，兑换后永久可下载';
    } elseif ($a === 'downloads') {
        $ucTitle = '我的下载';
        $ucSub = '兑换过的资源可以随时重新下载，不限次数';
    } elseif ($a === 'auth') {
        $ucTitle = '我的授权码';
        $ucSub = '把购买的程序部署到自己的域名，签发永久授权码';
    } elseif ($a === 'comments') {
        $ucTitle = '我的评论';
        $ucSub = '你参与过的讨论都在这里';
    } elseif ($a === 'profile') {
        $ucTitle = '我的资料';
        $ucSub = '头像、昵称、邮箱与账号安全';
    } elseif ($a === 'posts') {
        $ucTitle = '我的文章';
        $ucSub = '你发布过的内容';
    } elseif ($a === 'contribute') {
        $ucTitle = '投稿作品';
        $ucSub = '提交你的主题 / 插件 / 文章，审核通过后自动发布并上架资源';
    } elseif ($a === 'friendlink') {
        $ucTitle = '友情链接';
        $ucSub = '提交你的站点，通过后展示在友链页面';
    }
    switch ($a) {
        case 'profile':  $body = moe_uc_view_profile($u, $uc); break;
        case 'comments': $body = moe_uc_view_comments($u);     break;
        case 'posts':    $body = moe_uc_view_posts($u);        break;
        case 'contribute':  $body = moe_uc_view_contribute($u);  break;
        case 'friendlink':  $body = moe_uc_view_friendlink($u);  break;
        case 'points':
            $body = function_exists('moe_pt_view_points') ? moe_pt_view_points($u)
                : '<div class="card"><p class="hint">积分模块缺失：请重新上传 includes/points.php</p></div>';
            break;
        case 'shop':
            $body = function_exists('moe_pt_view_shop') ? moe_pt_view_shop($u)
                : '<div class="card"><p class="hint">积分商城模块缺失：请重新上传 includes/points.php</p></div>';
            break;
        case 'downloads':
            $body = function_exists('moe_pt_view_downloads') ? moe_pt_view_downloads($u)
                : '<div class="card"><p class="hint">下载模块缺失：请重新上传 includes/points.php</p></div>';
            break;
        case 'auth':
            $body = moe_uc_view_auth($u);
            break;
        case 'recharge':
            // 2.2.2：充值已整合进商城，旧链接一律跳商城
            moe_uc_goto('shop');
            break;
        default:         $body = moe_uc_view_home($u, $uc, moe_user_stats($u['id']));
    }
    moe_uc_shell($ucTitle, $ucSub, $alert . $tabs . $body, $u);
    exit;
}
